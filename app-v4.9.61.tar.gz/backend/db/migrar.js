const fs = require('fs');
const path = require('path');
const pool = require('./pool');

/* Banco novo e vazio (caso de quem coloca o sistema online): cria as tabelas sozinho. */
async function criarTabelasSeFaltar() {
  const r = await pool.query(`SELECT to_regclass('public.clinicas') AS t`);
  if (r.rows[0].t) return;
  const candidatos = [path.join(__dirname, 'schema-agendamento.sql'), path.join(__dirname, '..', '..', 'schema-agendamento.sql')];
  const arq = candidatos.find((c) => fs.existsSync(c));
  if (!arq) throw new Error('Arquivo schema-agendamento.sql não encontrado para criar o banco.');
  console.log('Banco vazio: criando as tabelas...');
  await pool.query(fs.readFileSync(arq, 'utf8'));
  console.log('Tabelas criadas.');
}

/* Ajustes pequenos de banco que rodam sempre que o servidor liga.
   Servem pra quem já tem o banco criado de uma versão anterior: cada comando
   só age se a coluna ainda não existir, então é seguro rodar várias vezes. */
async function migrar() {
  await criarTabelasSeFaltar();
  await pool.query(`ALTER TABLE pacientes ADD COLUMN IF NOT EXISTS data_nascimento DATE`);
  await pool.query(`ALTER TABLE pacientes ADD COLUMN IF NOT EXISTS dados_extras JSONB DEFAULT '{}'::jsonb`);
  // OCO (vendas do gestor): base sincronizada por clínica e as últimas cópias, para voltar atrás se algo der errado
  await pool.query(`CREATE TABLE IF NOT EXISTS gestor_vendas_dados (
    clinica_id UUID PRIMARY KEY REFERENCES clinicas(id) ON DELETE CASCADE,
    versao INTEGER NOT NULL,
    dados TEXT NOT NULL,
    atualizado_em TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    atualizado_por TEXT
  )`);
  await pool.query(`CREATE TABLE IF NOT EXISTS gestor_vendas_copias (
    clinica_id UUID NOT NULL REFERENCES clinicas(id) ON DELETE CASCADE,
    versao INTEGER NOT NULL,
    dados TEXT NOT NULL,
    criado_em TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (clinica_id, versao)
  )`);
  // agenda do evento: dia + faixa de horário em que o agendador pode marcar pacientes
  await pool.query(`CREATE TABLE IF NOT EXISTS agendas (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    clinica_id UUID NOT NULL REFERENCES clinicas(id) ON DELETE CASCADE,
    unidade_id UUID NOT NULL REFERENCES unidades(id) ON DELETE CASCADE,
    data DATE NOT NULL,
    hora_inicio TIME NOT NULL,
    hora_fim TIME NOT NULL,
    tipo_atendimento_id UUID NOT NULL REFERENCES tipos_atendimento(id),
    local VARCHAR(255),
    ativa BOOLEAN DEFAULT TRUE,
    criado_em TIMESTAMP DEFAULT NOW()
  )`);
  await pool.query(`CREATE INDEX IF NOT EXISTS idx_agendas_unidade_data ON agendas(unidade_id, data) WHERE ativa`);
  await pool.query(`ALTER TABLE agendas ADD COLUMN IF NOT EXISTS buffer_min INTEGER`);
  await pool.query(`ALTER TABLE agendas ADD COLUMN IF NOT EXISTS almoco_inicio TIME`);
  await pool.query(`ALTER TABLE agendas ADD COLUMN IF NOT EXISTS almoco_fim TIME`);

  // o que cada agendador pode abrir (lista de chaves) e como imprimir os documentos
  await pool.query(`ALTER TABLE usuarios ADD COLUMN IF NOT EXISTS permissoes JSONB DEFAULT '[]'::jsonb`);
  await pool.query(`ALTER TABLE clinicas ADD COLUMN IF NOT EXISTS config_impressao JSONB DEFAULT '{}'::jsonb`);

  // cadastros de apoio
  await pool.query(`CREATE TABLE IF NOT EXISTS oticas_parceiras (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    clinica_id UUID NOT NULL REFERENCES clinicas(id) ON DELETE CASCADE,
    nome VARCHAR(150) NOT NULL, ativa BOOLEAN DEFAULT TRUE, criado_em TIMESTAMP DEFAULT NOW())`);
  await pool.query(`CREATE TABLE IF NOT EXISTS convenios (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    clinica_id UUID NOT NULL REFERENCES clinicas(id) ON DELETE CASCADE,
    nome VARCHAR(150) NOT NULL, ativo BOOLEAN DEFAULT TRUE, criado_em TIMESTAMP DEFAULT NOW())`);

  // de onde veio o agendamento e qual ótica parceira indicou
  await pool.query(`ALTER TABLE agendamentos ADD COLUMN IF NOT EXISTS origem VARCHAR(20) DEFAULT 'equipe'`);
  await pool.query(`ALTER TABLE agendamentos ADD COLUMN IF NOT EXISTS otica_parceira_id UUID REFERENCES oticas_parceiras(id) ON DELETE SET NULL`);

  // preço padrão de cada tipo de atendimento (já vem preenchido na cobrança)
  await pool.query(`ALTER TABLE tipos_atendimento ADD COLUMN IF NOT EXISTS preco_padrao NUMERIC(10,2)`);

  // financeiro
  await pool.query(`CREATE TABLE IF NOT EXISTS pagamentos (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    clinica_id UUID NOT NULL REFERENCES clinicas(id) ON DELETE CASCADE,
    agendamento_id UUID NOT NULL UNIQUE REFERENCES agendamentos(id) ON DELETE CASCADE,
    valor NUMERIC(10,2) NOT NULL CHECK (valor >= 0),
    forma VARCHAR(20),
    convenio_id UUID REFERENCES convenios(id) ON DELETE SET NULL,
    status VARCHAR(10) NOT NULL DEFAULT 'pendente' CHECK (status IN ('pendente','pago')),
    pago_em DATE,
    criado_em TIMESTAMP DEFAULT NOW())`);
  await pool.query(`CREATE TABLE IF NOT EXISTS contas_pagar (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    clinica_id UUID NOT NULL REFERENCES clinicas(id) ON DELETE CASCADE,
    descricao VARCHAR(200) NOT NULL,
    valor NUMERIC(10,2) NOT NULL CHECK (valor >= 0),
    vencimento DATE NOT NULL,
    pago BOOLEAN DEFAULT FALSE,
    pago_em DATE,
    criado_em TIMESTAMP DEFAULT NOW())`);

  // v4.4 Pix para receita e atestado (QR estático, dinheiro cai direto na chave da clínica)
  await pool.query(`ALTER TABLE clinicas ADD COLUMN IF NOT EXISTS politica_profissionais VARCHAR(30) DEFAULT 'medico_e_optometrista'`);
  await pool.query(`ALTER TABLE clinicas ADD COLUMN IF NOT EXISTS pix_chave VARCHAR(100)`);
  await pool.query(`ALTER TABLE clinicas ADD COLUMN IF NOT EXISTS pix_tipo VARCHAR(12)`);
  await pool.query(`ALTER TABLE clinicas ADD COLUMN IF NOT EXISTS pix_nome VARCHAR(25)`);
  await pool.query(`ALTER TABLE clinicas ADD COLUMN IF NOT EXISTS pix_cidade VARCHAR(15)`);
  await pool.query(`ALTER TABLE clinicas ADD COLUMN IF NOT EXISTS pix_valor_receita NUMERIC(10,2)`);
  await pool.query(`ALTER TABLE clinicas ADD COLUMN IF NOT EXISTS pix_valor_atestado NUMERIC(10,2)`);
  await pool.query(`UPDATE clinicas SET pix_chave='+5564992161203', pix_tipo='telefone' WHERE pix_chave IS NULL`);
  await pool.query(`CREATE TABLE IF NOT EXISTS cobrancas_documento (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    clinica_id UUID NOT NULL REFERENCES clinicas(id) ON DELETE CASCADE,
    unidade_id UUID,
    paciente_id UUID NOT NULL REFERENCES pacientes(id) ON DELETE CASCADE,
    tipo VARCHAR(12) NOT NULL CHECK (tipo IN ('receita','atestado','declaracao')),
    valor NUMERIC(10,2) NOT NULL CHECK (valor > 0),
    status VARCHAR(10) NOT NULL DEFAULT 'pendente' CHECK (status IN ('pendente','pago')),
    criado_em TIMESTAMP DEFAULT NOW(),
    criado_por_nome VARCHAR(150),
    pago_em TIMESTAMP,
    pago_por_nome VARCHAR(150))`);
  await pool.query(`CREATE INDEX IF NOT EXISTS ix_cobr_doc_pac ON cobrancas_documento(clinica_id, paciente_id, criado_em DESC)`);

  // v4.5 comissão do agendador por óculos vendido e retorno depois de alguns dias
  await pool.query(`ALTER TABLE clinicas ADD COLUMN IF NOT EXISTS comissao_opcao_a NUMERIC(10,2) DEFAULT 25`);
  await pool.query(`ALTER TABLE clinicas ADD COLUMN IF NOT EXISTS comissao_opcao_b NUMERIC(10,2) DEFAULT 50`);
  await pool.query(`ALTER TABLE clinicas ADD COLUMN IF NOT EXISTS pos_oculos_dias INTEGER DEFAULT 20`);
  await pool.query(`CREATE TABLE IF NOT EXISTS vendas_oculos (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    clinica_id UUID NOT NULL REFERENCES clinicas(id) ON DELETE CASCADE,
    unidade_id UUID,
    paciente_id UUID NOT NULL REFERENCES pacientes(id) ON DELETE CASCADE,
    agendamento_id UUID UNIQUE REFERENCES agendamentos(id) ON DELETE SET NULL,
    agendador_id UUID,
    agendador_nome VARCHAR(150),
    valor_venda NUMERIC(10,2),
    comissao NUMERIC(10,2) NOT NULL DEFAULT 0 CHECK (comissao >= 0),
    comissao_paga BOOLEAN NOT NULL DEFAULT FALSE,
    comissao_paga_em DATE,
    vendido_em DATE NOT NULL DEFAULT CURRENT_DATE,
    entregue_em DATE,
    observacoes TEXT,
    pos_enviado BOOLEAN NOT NULL DEFAULT FALSE,
    pos_enviado_em TIMESTAMP,
    pos_resposta TEXT,
    pos_resposta_em TIMESTAMP,
    pos_situacao VARCHAR(10) CHECK (pos_situacao IN ('ok','problema')),
    pos_obs TEXT,
    criado_por_nome VARCHAR(150),
    criado_em TIMESTAMP DEFAULT NOW())`);
  await pool.query(`CREATE INDEX IF NOT EXISTS ix_vendas_clinica ON vendas_oculos(clinica_id, vendido_em DESC)`);
  await pool.query(`CREATE INDEX IF NOT EXISTS ix_vendas_agendador ON vendas_oculos(clinica_id, agendador_id)`);

  // v4.6 resultado da venda (completa, só lente, só armação, não comprou)
  await pool.query(`ALTER TABLE vendas_oculos ADD COLUMN IF NOT EXISTS resultado VARCHAR(12) NOT NULL DEFAULT 'completa'`);
  await pool.query(`ALTER TABLE vendas_oculos ADD COLUMN IF NOT EXISTS comissao_cheia NUMERIC(10,2)`);
  await pool.query(`UPDATE vendas_oculos SET comissao_cheia = comissao WHERE comissao_cheia IS NULL`);
  await pool.query(`ALTER TABLE vendas_oculos ADD COLUMN IF NOT EXISTS garantia_ate DATE`);
  await pool.query(`ALTER TABLE vendas_oculos DROP CONSTRAINT IF EXISTS vendas_oculos_resultado_check`);
  await pool.query(`ALTER TABLE vendas_oculos ADD CONSTRAINT vendas_oculos_resultado_check CHECK (resultado IN ('completa','lente','armacao','nao_comprou'))`);
  // v4.6 gestor de vendas: novo tipo de usuário
  await pool.query(`ALTER TABLE usuarios DROP CONSTRAINT IF EXISTS usuarios_papel_check`);
  await pool.query(`ALTER TABLE usuarios ADD CONSTRAINT usuarios_papel_check CHECK (papel IN ('admin','atendente','profissional','gestor'))`);
  await pool.query(`ALTER TABLE pacientes ADD COLUMN IF NOT EXISTS aceita_promocao BOOLEAN NOT NULL DEFAULT TRUE`);
  await pool.query(`CREATE TABLE IF NOT EXISTS posvenda_ocorrencias (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    clinica_id UUID NOT NULL REFERENCES clinicas(id) ON DELETE CASCADE,
    paciente_id UUID NOT NULL REFERENCES pacientes(id) ON DELETE CASCADE,
    venda_id UUID REFERENCES vendas_oculos(id) ON DELETE SET NULL,
    tipo VARCHAR(12) NOT NULL CHECK (tipo IN ('ajuste','garantia','troca','reclamacao','outro')),
    descricao TEXT NOT NULL,
    status VARCHAR(12) NOT NULL DEFAULT 'aberta' CHECK (status IN ('aberta','andamento','resolvida')),
    prazo DATE,
    visita_em TIMESTAMP,
    resolucao TEXT,
    resolvida_em TIMESTAMP,
    criado_por_nome VARCHAR(150),
    criado_em TIMESTAMP DEFAULT NOW(),
    atualizado_em TIMESTAMP DEFAULT NOW())`);
  await pool.query(`CREATE INDEX IF NOT EXISTS ix_posv_ocor ON posvenda_ocorrencias(clinica_id, status, prazo)`);
  await pool.query(`CREATE TABLE IF NOT EXISTS posvenda_envios (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    clinica_id UUID NOT NULL REFERENCES clinicas(id) ON DELETE CASCADE,
    paciente_id UUID NOT NULL REFERENCES pacientes(id) ON DELETE CASCADE,
    campanha VARCHAR(60) NOT NULL,
    enviado_por_nome VARCHAR(150),
    enviado_em TIMESTAMP DEFAULT NOW())`);
  await pool.query(`CREATE UNIQUE INDEX IF NOT EXISTS ux_posv_envio ON posvenda_envios(clinica_id, paciente_id, campanha)`);

  // pós-exame: contato com o paciente para saber se ficou satisfeito com o exame de vista
  await pool.query(`CREATE TABLE IF NOT EXISTS posexame_contatos (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    clinica_id UUID NOT NULL REFERENCES clinicas(id) ON DELETE CASCADE,
    agendamento_id UUID NOT NULL UNIQUE REFERENCES agendamentos(id) ON DELETE CASCADE,
    paciente_id UUID NOT NULL REFERENCES pacientes(id) ON DELETE CASCADE,
    enviado_em TIMESTAMP,
    enviado_por_nome VARCHAR(150),
    resultado VARCHAR(14) CHECK (resultado IN ('satisfeito','regular','insatisfeito','sem_resposta')),
    observacao TEXT,
    acompanhar BOOLEAN NOT NULL DEFAULT FALSE,
    resolvido_em TIMESTAMP,
    resolucao TEXT,
    criado_em TIMESTAMP DEFAULT NOW(),
    atualizado_em TIMESTAMP DEFAULT NOW())`);
  await pool.query(`CREATE INDEX IF NOT EXISTS ix_posexame ON posexame_contatos(clinica_id, acompanhar, resolvido_em)`);

  // registro de quem abriu ou alterou dado de saúde (LGPD)
  await pool.query(`CREATE TABLE IF NOT EXISTS acessos_log (
    id BIGSERIAL PRIMARY KEY,
    clinica_id UUID NOT NULL REFERENCES clinicas(id) ON DELETE CASCADE,
    usuario_id UUID, usuario_nome VARCHAR(150),
    acao VARCHAR(10), area VARCHAR(30), caminho VARCHAR(200), ip VARCHAR(60),
    criado_em TIMESTAMP DEFAULT NOW())`);
  await pool.query(`CREATE INDEX IF NOT EXISTS idx_acessos_log ON acessos_log(clinica_id, criado_em DESC)`);

  // WhatsApp automático e número da clínica
  await pool.query(`ALTER TABLE clinicas ADD COLUMN IF NOT EXISTS whatsapp_numero VARCHAR(20)`);
  await pool.query(`ALTER TABLE clinicas ADD COLUMN IF NOT EXISTS whatsapp_auto BOOLEAN DEFAULT FALSE`);
  await pool.query(`ALTER TABLE agendamentos ADD COLUMN IF NOT EXISTS whatsapp_ultimo_erro VARCHAR(200)`);
  // v4.0: segurança, lista de espera, licença
  await pool.query(`ALTER TABLE usuarios ADD COLUMN IF NOT EXISTS totp_segredo TEXT`);
  await pool.query(`ALTER TABLE usuarios ADD COLUMN IF NOT EXISTS totp_ativo BOOLEAN NOT NULL DEFAULT FALSE`);
  await pool.query(`ALTER TABLE usuarios ADD COLUMN IF NOT EXISTS totp_ultimo_passo BIGINT NOT NULL DEFAULT 0`);
  await pool.query(`CREATE TABLE IF NOT EXISTS redefinicoes_senha (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    usuario_id UUID NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE,
    token_hash TEXT NOT NULL UNIQUE,
    expira_em TIMESTAMPTZ NOT NULL,
    usado_em TIMESTAMPTZ,
    criado_em TIMESTAMPTZ DEFAULT NOW())`);
  await pool.query(`CREATE TABLE IF NOT EXISTS dispositivos_login (
    usuario_id UUID NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE,
    hash TEXT NOT NULL,
    agente TEXT,
    primeiro_em TIMESTAMPTZ DEFAULT NOW(),
    visto_em TIMESTAMPTZ DEFAULT NOW(),
    PRIMARY KEY (usuario_id, hash))`);
  await pool.query(`ALTER TABLE clinicas ADD COLUMN IF NOT EXISTS licenca TEXT`);
  await pool.query(`CREATE TABLE IF NOT EXISTS lista_espera (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    clinica_id UUID NOT NULL REFERENCES clinicas(id) ON DELETE CASCADE,
    unidade_id UUID REFERENCES unidades(id) ON DELETE CASCADE,
    nome VARCHAR(150) NOT NULL,
    telefone VARCHAR(30),
    observacao VARCHAR(300),
    resolvido_em TIMESTAMP,
    criado_em TIMESTAMP DEFAULT NOW())`);
  // v4.1: CPF embaralhado + impressão para barrar CPF repetido
  await pool.query(`ALTER TABLE pacientes ALTER COLUMN cpf TYPE TEXT`);
  await pool.query(`ALTER TABLE pacientes ADD COLUMN IF NOT EXISTS cpf_idx TEXT`);
  await pool.query(`ALTER TABLE pacientes DROP CONSTRAINT IF EXISTS unique_cpf_por_clinica`);
  await pool.query(`CREATE UNIQUE INDEX IF NOT EXISTS ux_pacientes_cpf_idx ON pacientes(clinica_id, cpf_idx) WHERE cpf_idx IS NOT NULL`);
  // v4.1: Guardião do sistema
  await pool.query(`CREATE TABLE IF NOT EXISTS assistente_obrigacoes (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    clinica_id UUID NOT NULL REFERENCES clinicas(id) ON DELETE CASCADE,
    codigo TEXT, titulo TEXT NOT NULL, detalhe TEXT,
    vence_em DATE NOT NULL, repetir_dias INTEGER,
    feito_em TIMESTAMPTZ, lembrado_em DATE,
    ativo BOOLEAN NOT NULL DEFAULT TRUE,
    criado_em TIMESTAMPTZ DEFAULT NOW())`);
  await pool.query(`CREATE UNIQUE INDEX IF NOT EXISTS ux_assistente_obr_codigo ON assistente_obrigacoes(clinica_id, codigo) WHERE codigo IS NOT NULL`);
  await pool.query(`CREATE TABLE IF NOT EXISTS assistente_verificacoes (
    id BIGSERIAL PRIMARY KEY,
    clinica_id UUID NOT NULL REFERENCES clinicas(id) ON DELETE CASCADE,
    erros INTEGER NOT NULL DEFAULT 0, avisos INTEGER NOT NULL DEFAULT 0,
    resumo JSONB, criado_em TIMESTAMPTZ DEFAULT NOW())`);
  await pool.query(`CREATE INDEX IF NOT EXISTS idx_assist_verif ON assistente_verificacoes(clinica_id, criado_em DESC)`);
  await pool.query(`CREATE TABLE IF NOT EXISTS sistema_batimento (id INTEGER PRIMARY KEY, visto_em TIMESTAMPTZ NOT NULL DEFAULT NOW())`);
  await pool.query(`CREATE TABLE IF NOT EXISTS sistema_reinicios (id BIGSERIAL PRIMARY KEY, parado_min INTEGER NOT NULL DEFAULT 0, criado_em TIMESTAMPTZ DEFAULT NOW())`);
  // v4.2/v4.3: agendador offline (cada pedido do celular tem um número, para o envio repetido não duplicar)
  await pool.query(`CREATE TABLE IF NOT EXISTS agendamentos_offline (
    clinica_id UUID NOT NULL REFERENCES clinicas(id) ON DELETE CASCADE,
    cliente_id UUID NOT NULL,
    usuario_id UUID,
    resultado JSONB NOT NULL,
    criado_em TIMESTAMPTZ DEFAULT NOW(),
    PRIMARY KEY (clinica_id, cliente_id))`);
  // diagnóstico (CID) passa a caber embaralhado
  await pool.query(`DO $$ BEGIN
    IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='receitas' AND column_name='cid_codigo' AND data_type='character varying') THEN
      ALTER TABLE receitas ALTER COLUMN cid_codigo TYPE TEXT;
      ALTER TABLE receitas ALTER COLUMN cid_descricao TYPE TEXT;
    END IF; END $$`);
  await pool.query(`ALTER TABLE agendamentos ADD COLUMN IF NOT EXISTS chegou_em TIMESTAMP`);
  await pool.query(`ALTER TABLE agendamentos ADD COLUMN IF NOT EXISTS inicio_atendimento_em TIMESTAMP`);
  await pool.query(`CREATE TABLE IF NOT EXISTS feriados_locais (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    clinica_id UUID NOT NULL REFERENCES clinicas(id) ON DELETE CASCADE,
    unidade_id UUID REFERENCES unidades(id) ON DELETE CASCADE,
    data DATE NOT NULL,
    nome VARCHAR(100) NOT NULL,
    criado_em TIMESTAMP DEFAULT NOW())`);
  await pool.query(`CREATE UNIQUE INDEX IF NOT EXISTS ux_feriados_locais ON feriados_locais (clinica_id, COALESCE(unidade_id, '00000000-0000-0000-0000-000000000000'::uuid), data)`);
  await pool.query(`ALTER TABLE usuarios ADD COLUMN IF NOT EXISTS sessao_versao INTEGER NOT NULL DEFAULT 0`);
  await pool.query(`CREATE TABLE IF NOT EXISTS login_tentativas (chave TEXT PRIMARY KEY, inicio TIMESTAMPTZ NOT NULL DEFAULT NOW(), erros INTEGER NOT NULL DEFAULT 0)`);
  await pool.query(`ALTER TABLE prontuarios ADD COLUMN IF NOT EXISTS refracao JSONB`);
  await pool.query(`ALTER TABLE prontuarios ADD COLUMN IF NOT EXISTS exame JSONB`);
  await pool.query(`ALTER TABLE prontuarios ADD COLUMN IF NOT EXISTS fechado_em TIMESTAMP`);
  await pool.query(`CREATE TABLE IF NOT EXISTS prontuario_versoes (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    prontuario_id UUID NOT NULL REFERENCES prontuarios(id) ON DELETE CASCADE,
    usuario_id UUID, usuario_nome VARCHAR(150), motivo TEXT, snapshot JSONB,
    criado_em TIMESTAMP DEFAULT NOW())`);
  // duração própria da agenda (vazio = usa a duração do tipo de atendimento)
  await pool.query(`ALTER TABLE agendas ADD COLUMN IF NOT EXISTS duracao_min INTEGER`);
  // v4.7: digital e rosto (passkeys) foram retirados do sistema
  await pool.query(`DROP TABLE IF EXISTS passkeys`);
  // v4.7: preço de armações e garantias da vitrine (o administrador ajusta quando quiser)
  await pool.query(`ALTER TABLE clinicas ADD COLUMN IF NOT EXISTS vitrine_preco_armacao NUMERIC(10,2) DEFAULT 89.90`);
  await pool.query(`ALTER TABLE clinicas ADD COLUMN IF NOT EXISTS vitrine_garantia_lente_dias INTEGER DEFAULT 90`);
  await pool.query(`ALTER TABLE clinicas ADD COLUMN IF NOT EXISTS vitrine_garantia_armacao TEXT DEFAULT 'Garantia de 1 ano na armação, sujeita à análise.'`);
  // v4.7: nota fiscal SIMULADA (sem valor fiscal, só para treinar o fluxo)
  await pool.query(`CREATE TABLE IF NOT EXISTS notas_simuladas (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    clinica_id UUID NOT NULL REFERENCES clinicas(id) ON DELETE CASCADE,
    numero INTEGER NOT NULL,
    cliente_nome VARCHAR(150) NOT NULL,
    cliente_cpf VARCHAR(20),
    descricao VARCHAR(200) NOT NULL,
    valor NUMERIC(10,2) NOT NULL,
    forma VARCHAR(20),
    criado_por VARCHAR(150),
    criado_em TIMESTAMP DEFAULT NOW(),
    UNIQUE (clinica_id, numero))`);
  // v4.6.3 um usuário pode ter mais de uma cidade
  await pool.query(`CREATE TABLE IF NOT EXISTS usuarios_unidades (
    usuario_id UUID NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE,
    unidade_id UUID NOT NULL REFERENCES unidades(id) ON DELETE CASCADE,
    PRIMARY KEY (usuario_id, unidade_id))`);
  await pool.query(`INSERT INTO usuarios_unidades (usuario_id, unidade_id) SELECT id, unidade_id FROM usuarios WHERE unidade_id IS NOT NULL ON CONFLICT DO NOTHING`);
  // v4.10 formação superior do profissional (curso e instituição), impressa na receita
  await pool.query(`ALTER TABLE usuarios ADD COLUMN IF NOT EXISTS formacao VARCHAR(200)`);
  // v4.10 tipo do curso (bacharelado ou tecnológico) e portaria de reconhecimento do MEC
  await pool.query(`ALTER TABLE usuarios ADD COLUMN IF NOT EXISTS formacao_tipo VARCHAR(20)`);
  // atividade da equipe: quando cada pessoa entrou e usou o sistema pela última vez
  await pool.query(`ALTER TABLE usuarios ADD COLUMN IF NOT EXISTS ultimo_login TIMESTAMP`);
  await pool.query(`ALTER TABLE usuarios ADD COLUMN IF NOT EXISTS ultimo_acesso TIMESTAMP`);
  await pool.query(`ALTER TABLE usuarios ADD COLUMN IF NOT EXISTS loc_lat DOUBLE PRECISION`);
  await pool.query(`ALTER TABLE usuarios ADD COLUMN IF NOT EXISTS loc_lng DOUBLE PRECISION`);
  await pool.query(`ALTER TABLE usuarios ADD COLUMN IF NOT EXISTS loc_precisao INTEGER`);
  await pool.query(`ALTER TABLE usuarios ADD COLUMN IF NOT EXISTS loc_em TIMESTAMP`);
  await pool.query(`CREATE TABLE IF NOT EXISTS entradas_log (
    id BIGSERIAL PRIMARY KEY, clinica_id UUID NOT NULL, usuario_id UUID, usuario_nome TEXT, ip TEXT, aparelho TEXT,
    criado_em TIMESTAMP DEFAULT NOW())`);
  await pool.query(`ALTER TABLE entradas_log ADD COLUMN IF NOT EXISTS lat DOUBLE PRECISION`);
  await pool.query(`ALTER TABLE entradas_log ADD COLUMN IF NOT EXISTS lng DOUBLE PRECISION`);
  await pool.query(`CREATE INDEX IF NOT EXISTS idx_entradas_usuario ON entradas_log(usuario_id, criado_em DESC)`);
  await pool.query(`CREATE INDEX IF NOT EXISTS idx_entradas_clinica ON entradas_log(clinica_id, criado_em DESC)`);
  await pool.query(`ALTER TABLE usuarios ADD COLUMN IF NOT EXISTS formacao_portaria VARCHAR(160)`);
  // v4.10 código para conferir a receita pelo QR Code
  await pool.query(`ALTER TABLE receitas ADD COLUMN IF NOT EXISTS codigo_verificacao VARCHAR(16)`);
  await pool.query(`CREATE UNIQUE INDEX IF NOT EXISTS ux_receitas_codigo ON receitas(codigo_verificacao) WHERE codigo_verificacao IS NOT NULL`);
  // v4.9.20 Vigia da equipe: ocorrências, pedidos de correção que o Master autoriza e sindicância
  await pool.query(`CREATE TABLE IF NOT EXISTS vigia_ocorrencias (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    clinica_id UUID NOT NULL REFERENCES clinicas(id) ON DELETE CASCADE,
    chave VARCHAR(160) NOT NULL,
    tipo VARCHAR(40) NOT NULL,
    gravidade VARCHAR(10) NOT NULL DEFAULT 'media',
    usuario_id UUID, usuario_nome TEXT, usuario_papel VARCHAR(20),
    titulo TEXT NOT NULL, detalhe TEXT, evidencias JSONB,
    janela_inicio TIMESTAMP, janela_fim TIMESTAMP,
    status VARCHAR(20) NOT NULL DEFAULT 'aberta',
    ia_parecer TEXT, ia_recomendacao VARCHAR(30),
    parecer_master TEXT, decidido_por TEXT, decidido_em TIMESTAMP,
    criado_em TIMESTAMP DEFAULT NOW(),
    UNIQUE (clinica_id, chave))`);
  await pool.query(`CREATE INDEX IF NOT EXISTS idx_vigia_oc ON vigia_ocorrencias(clinica_id, status, criado_em DESC)`);
  await pool.query(`CREATE TABLE IF NOT EXISTS vigia_pedidos (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    clinica_id UUID NOT NULL REFERENCES clinicas(id) ON DELETE CASCADE,
    ocorrencia_id UUID REFERENCES vigia_ocorrencias(id) ON DELETE SET NULL,
    tipo VARCHAR(30) NOT NULL,
    alvo_usuario_id UUID, alvo_nome TEXT,
    motivo TEXT, origem VARCHAR(10) NOT NULL DEFAULT 'vigia',
    status VARCHAR(15) NOT NULL DEFAULT 'pendente',
    resultado TEXT, decidido_por TEXT, decidido_em TIMESTAMP,
    criado_em TIMESTAMP DEFAULT NOW())`);
  await pool.query(`CREATE UNIQUE INDEX IF NOT EXISTS ux_vigia_pedido_pendente ON vigia_pedidos(clinica_id, tipo, alvo_usuario_id) WHERE status='pendente'`);
  // v4.9.24 atendente de IA no WhatsApp da ótica (OCO)
  await pool.query(`CREATE TABLE IF NOT EXISTS atendente_config (
    clinica_id UUID PRIMARY KEY REFERENCES clinicas(id) ON DELETE CASCADE,
    ativo BOOLEAN NOT NULL DEFAULT FALSE,
    numero_otica VARCHAR(20),
    nome_atendente VARCHAR(40),
    horario TEXT,
    instrucoes TEXT,
    atualizado_em TIMESTAMPTZ DEFAULT NOW(),
    atualizado_por VARCHAR(150))`);
  await pool.query(`CREATE TABLE IF NOT EXISTS wa_conversas (
    clinica_id UUID NOT NULL REFERENCES clinicas(id) ON DELETE CASCADE,
    telefone VARCHAR(20) NOT NULL,
    nome VARCHAR(120),
    phone_id VARCHAR(40),
    equipe_ate TIMESTAMPTZ,
    precisa_equipe BOOLEAN NOT NULL DEFAULT FALSE,
    nao_lidas INTEGER NOT NULL DEFAULT 0,
    ultima_em TIMESTAMPTZ DEFAULT NOW(),
    PRIMARY KEY (clinica_id, telefone))`);
  await pool.query(`CREATE TABLE IF NOT EXISTS wa_mensagens (
    id BIGSERIAL PRIMARY KEY,
    clinica_id UUID NOT NULL REFERENCES clinicas(id) ON DELETE CASCADE,
    telefone VARCHAR(20) NOT NULL,
    autor VARCHAR(10) NOT NULL,
    texto TEXT NOT NULL,
    wa_id VARCHAR(120),
    enviado_por VARCHAR(150),
    criado_em TIMESTAMPTZ DEFAULT NOW())`);
  await pool.query(`CREATE INDEX IF NOT EXISTS ix_wa_mensagens_conversa ON wa_mensagens(clinica_id, telefone, criado_em)`);
  await pool.query(`CREATE UNIQUE INDEX IF NOT EXISTS ux_wa_mensagens_waid ON wa_mensagens(wa_id) WHERE wa_id IS NOT NULL`);

  /* v4.9.33 fase 1 do plano: tabelas novas, só acrescentando. O bloco da OCO (gestor_vendas_dados) continua igual;
     as tabelas oco abaixo são uma cópia dele, refeita a cada sincronização. Registro que some do bloco ganha removido_em. */
  await pool.query(`CREATE TABLE IF NOT EXISTS ordens_servico (
    id BIGSERIAL PRIMARY KEY,
    clinica_id UUID NOT NULL REFERENCES clinicas(id) ON DELETE CASCADE,
    origem VARCHAR(10) NOT NULL DEFAULT 'oco',
    origem_id BIGINT NOT NULL,
    numero VARCHAR(20),
    paciente_id UUID,
    cliente_nome VARCHAR(150),
    cliente_tel VARCHAR(20),
    venda_origem_id BIGINT,
    etapa VARCHAR(40) NOT NULL DEFAULT 'Pedido feito',
    aberta_em DATE,
    prazo DATE,
    entregue_em DATE,
    laboratorio VARCHAR(120),
    valor NUMERIC(12,2),
    pago BOOLEAN,
    atualizado_em TIMESTAMPTZ DEFAULT NOW(),
    removido_em TIMESTAMPTZ,
    UNIQUE (clinica_id, origem, origem_id))`);
  await pool.query(`CREATE TABLE IF NOT EXISTS os_eventos (
    id BIGSERIAL PRIMARY KEY,
    clinica_id UUID NOT NULL REFERENCES clinicas(id) ON DELETE CASCADE,
    os_id BIGINT NOT NULL REFERENCES ordens_servico(id) ON DELETE CASCADE,
    etapa_de VARCHAR(40),
    etapa_para VARCHAR(40) NOT NULL,
    usuario VARCHAR(150),
    quando DATE NOT NULL,
    UNIQUE (os_id, etapa_para, quando))`);
  await pool.query(`CREATE TABLE IF NOT EXISTS caixa_movimentos (
    id BIGSERIAL PRIMARY KEY,
    clinica_id UUID NOT NULL REFERENCES clinicas(id) ON DELETE CASCADE,
    origem VARCHAR(20) NOT NULL,
    origem_id VARCHAR(60) NOT NULL,
    data DATE NOT NULL,
    tipo VARCHAR(10) NOT NULL,
    descricao VARCHAR(200),
    forma VARCHAR(40),
    valor NUMERIC(12,2) NOT NULL,
    usuario VARCHAR(150),
    criado_em TIMESTAMPTZ DEFAULT NOW(),
    removido_em TIMESTAMPTZ,
    UNIQUE (clinica_id, origem, origem_id))`);
  await pool.query(`CREATE INDEX IF NOT EXISTS ix_caixa_mov_data ON caixa_movimentos(clinica_id, data)`);
  await pool.query(`CREATE TABLE IF NOT EXISTS contas_receber (
    id BIGSERIAL PRIMARY KEY,
    clinica_id UUID NOT NULL REFERENCES clinicas(id) ON DELETE CASCADE,
    origem VARCHAR(10) NOT NULL DEFAULT 'oco',
    origem_id BIGINT NOT NULL,
    paciente_id UUID,
    cliente_origem_id BIGINT,
    cliente_nome VARCHAR(150),
    cliente_tel VARCHAR(20),
    venda_origem_id BIGINT,
    parcela INTEGER,
    parcelas INTEGER,
    vencimento DATE,
    valor NUMERIC(12,2) NOT NULL,
    pago_em DATE,
    forma VARCHAR(40),
    pix_txid VARCHAR(35),
    removido_em TIMESTAMPTZ,
    UNIQUE (clinica_id, origem, origem_id))`);
  await pool.query(`CREATE INDEX IF NOT EXISTS ix_contas_receber_venc ON contas_receber(clinica_id, vencimento) WHERE pago_em IS NULL`);
  await pool.query(`CREATE TABLE IF NOT EXISTS vendas_oco (
    id BIGSERIAL PRIMARY KEY,
    clinica_id UUID NOT NULL REFERENCES clinicas(id) ON DELETE CASCADE,
    origem_id BIGINT NOT NULL,
    cliente_nome VARCHAR(150),
    data DATE,
    total NUMERIC(12,2),
    forma VARCHAR(40),
    parcelas INTEGER,
    vendedor VARCHAR(150),
    removido_em TIMESTAMPTZ,
    UNIQUE (clinica_id, origem_id))`);
  await pool.query(`CREATE TABLE IF NOT EXISTS oco_espelho (
    clinica_id UUID PRIMARY KEY REFERENCES clinicas(id) ON DELETE CASCADE,
    versao INTEGER, copiado_em TIMESTAMPTZ, conferencia JSONB, erro TEXT)`);
  await pool.query(`CREATE TABLE IF NOT EXISTS regua_mensagens (
    id BIGSERIAL PRIMARY KEY,
    clinica_id UUID NOT NULL REFERENCES clinicas(id) ON DELETE CASCADE,
    gatilho VARCHAR(30) NOT NULL,
    referencia_id VARCHAR(60) NOT NULL,
    telefone VARCHAR(20) NOT NULL,
    agendada_para TIMESTAMPTZ NOT NULL,
    enviada_em TIMESTAMPTZ,
    resposta TEXT,
    status VARCHAR(15) NOT NULL DEFAULT 'agendada',
    erro TEXT,
    UNIQUE (clinica_id, gatilho, referencia_id))`);
  await pool.query(`CREATE TABLE IF NOT EXISTS wa_sessoes (
    clinica_id UUID NOT NULL REFERENCES clinicas(id) ON DELETE CASCADE,
    telefone VARCHAR(20) NOT NULL,
    passo VARCHAR(20) NOT NULL,
    dados JSONB NOT NULL DEFAULT '{}',
    expira_em TIMESTAMPTZ NOT NULL,
    PRIMARY KEY (clinica_id, telefone))`);
  await pool.query(`CREATE TABLE IF NOT EXISTS ia_memoria (
    id BIGSERIAL PRIMARY KEY,
    clinica_id UUID NOT NULL REFERENCES clinicas(id) ON DELETE CASCADE,
    tipo VARCHAR(20) NOT NULL,
    resumo TEXT NOT NULL,
    dados_agregados JSONB,
    fonte_url TEXT,
    status VARCHAR(12) NOT NULL DEFAULT 'nova',
    decidido_por VARCHAR(150),
    decidido_em TIMESTAMPTZ,
    criado_em TIMESTAMPTZ DEFAULT NOW())`);
  await pool.query(`CREATE TABLE IF NOT EXISTS rotas_desempenho (
    rota VARCHAR(120) NOT NULL,
    hora TIMESTAMPTZ NOT NULL,
    chamadas INTEGER NOT NULL DEFAULT 0,
    ms_medio INTEGER,
    ms_p95 INTEGER,
    erros_5xx INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (rota, hora))`);
  await pool.query(`CREATE TABLE IF NOT EXISTS auditoria_telas (
    id BIGSERIAL PRIMARY KEY,
    clinica_id UUID REFERENCES clinicas(id) ON DELETE CASCADE,
    usuario_id UUID,
    papel VARCHAR(20),
    tela VARCHAR(60) NOT NULL,
    acao VARCHAR(10) NOT NULL DEFAULT 'ver',
    registro_id VARCHAR(60),
    ip VARCHAR(60),
    aparelho VARCHAR(200),
    quando TIMESTAMPTZ DEFAULT NOW())`);
  await pool.query(`CREATE INDEX IF NOT EXISTS ix_auditoria_telas ON auditoria_telas(clinica_id, quando DESC)`);
  await pool.query(`ALTER TABLE receitas ADD COLUMN IF NOT EXISTS tipo_receita VARCHAR(15) DEFAULT 'oculos'`);
  for (const c of ['lc_marca VARCHAR(80)', 'lc_curva_base VARCHAR(20)', 'lc_diametro VARCHAR(20)', 'lc_descarte VARCHAR(40)', 'laudo_texto TEXT'])
    await pool.query(`ALTER TABLE receitas ADD COLUMN IF NOT EXISTS ${c}`);
  for (const c of ['os_id BIGINT', 'telefone_pos_venda VARCHAR(20)', 'optou_por_nao_receber BOOLEAN DEFAULT FALSE'])
    await pool.query(`ALTER TABLE vendas_oculos ADD COLUMN IF NOT EXISTS ${c}`);
  // v4.9.36 fase 2: auditoria completa de telas e trava por IP (só acrescenta)
  for (const c of ['paciente_id UUID', 'usuario_nome VARCHAR(150)', 'caminho VARCHAR(200)', 'metodo VARCHAR(8)'])
    await pool.query(`ALTER TABLE auditoria_telas ADD COLUMN IF NOT EXISTS ${c}`);
  await pool.query(`CREATE INDEX IF NOT EXISTS ix_auditoria_usuario ON auditoria_telas(clinica_id, usuario_id, quando DESC)`);
  await pool.query(`CREATE INDEX IF NOT EXISTS ix_auditoria_paciente ON auditoria_telas(clinica_id, paciente_id, quando DESC) WHERE paciente_id IS NOT NULL`);
  await pool.query(`CREATE TABLE IF NOT EXISTS seguranca_ip (
    ip VARCHAR(60) PRIMARY KEY,
    falhas INTEGER NOT NULL DEFAULT 0,
    janela_inicio TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    bloqueado_ate TIMESTAMPTZ,
    ultimo_motivo VARCHAR(120))`);
  await pool.query(`CREATE INDEX IF NOT EXISTS ix_ia_memoria_tipo ON ia_memoria(clinica_id, tipo, status, criado_em DESC)`);
  // v4.9.34 e-mail e backup ligados pela tela do Master (valores criptografados)
  await pool.query(`CREATE TABLE IF NOT EXISTS config_servidor (
    chave VARCHAR(40) PRIMARY KEY,
    valor TEXT NOT NULL,
    atualizado_em TIMESTAMPTZ DEFAULT NOW(),
    atualizado_por VARCHAR(150))`);
  // v4.9.42 o paciente marca o horário no final do teste público; Amsler e leque do astigmatismo no teste
  await pool.query(`ALTER TABLE clinicas ADD COLUMN IF NOT EXISTS agendamento_online BOOLEAN DEFAULT TRUE`);
  await pool.query(`ALTER TABLE testes_visao ADD COLUMN IF NOT EXISTS amsler VARCHAR(20)`);
  await pool.query(`ALTER TABLE testes_visao ADD COLUMN IF NOT EXISTS leque VARCHAR(20)`);
  // v4.9.43 conversa privada entre cada Master e cada pessoa da equipe (texto trancado com a chave do sistema)
  await pool.query(`CREATE TABLE IF NOT EXISTS conversas_equipe (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    clinica_id UUID NOT NULL REFERENCES clinicas(id),
    master_id UUID NOT NULL REFERENCES usuarios(id),
    membro_id UUID NOT NULL REFERENCES usuarios(id),
    criado_em TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    ultima_em TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (master_id, membro_id))`);
  await pool.query(`CREATE TABLE IF NOT EXISTS conversas_mensagens (
    id BIGSERIAL PRIMARY KEY,
    clinica_id UUID NOT NULL REFERENCES clinicas(id),
    conversa_id UUID NOT NULL REFERENCES conversas_equipe(id),
    autor_id UUID NOT NULL REFERENCES usuarios(id),
    texto TEXT NOT NULL,
    criado_em TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    editado_em TIMESTAMPTZ,
    lida_em TIMESTAMPTZ)`);
  await pool.query(`CREATE INDEX IF NOT EXISTS ix_conversas_msg ON conversas_mensagens(conversa_id, id)`);
  await pool.query(`CREATE INDEX IF NOT EXISTS ix_conversas_naolidas ON conversas_mensagens(conversa_id) WHERE lida_em IS NULL`);
  // v4.9.44 aparelho de confiança do Master (código por e-mail) e liberação de aparelho da equipe
  await pool.query(`CREATE TABLE IF NOT EXISTS aparelhos (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    clinica_id UUID NOT NULL REFERENCES clinicas(id),
    usuario_id UUID NOT NULL REFERENCES usuarios(id),
    aparelho_hash VARCHAR(64) NOT NULL,
    status VARCHAR(12) NOT NULL,
    nome VARCHAR(120),
    ip VARCHAR(60),
    criado_em TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    expira_em TIMESTAMPTZ,
    decidido_em TIMESTAMPTZ,
    decidido_por VARCHAR(150),
    ultimo_uso TIMESTAMPTZ,
    UNIQUE (usuario_id, aparelho_hash))`);
  await pool.query(`CREATE INDEX IF NOT EXISTS ix_aparelhos_pendentes ON aparelhos(clinica_id, status)`);
  await pool.query(`CREATE TABLE IF NOT EXISTS codigos_login (
    usuario_id UUID PRIMARY KEY REFERENCES usuarios(id),
    hash VARCHAR(64) NOT NULL,
    expira_em TIMESTAMPTZ NOT NULL,
    tentativas INTEGER NOT NULL DEFAULT 0,
    enviado_em TIMESTAMPTZ NOT NULL DEFAULT NOW())`);
  await pool.query(`ALTER TABLE clinicas ADD COLUMN IF NOT EXISTS liberar_aparelhos BOOLEAN DEFAULT TRUE`);
  // v4.9.47 histórico do sistema antigo da ótica (só leitura; não entra em vendas, caixa, cobrança nem relatórios)
  await pool.query(`CREATE TABLE IF NOT EXISTS legado_clientes (
    id BIGSERIAL PRIMARY KEY,
    clinica_id UUID NOT NULL REFERENCES clinicas(id),
    chave VARCHAR(40) NOT NULL,
    nome VARCHAR(200) NOT NULL,
    nome_norm VARCHAR(200) NOT NULL,
    cpf_idx VARCHAR(100),
    tel8 VARCHAR(8),
    em_aberto NUMERIC(12,2) NOT NULL DEFAULT 0,
    dados TEXT NOT NULL,
    origem VARCHAR(120),
    importado_em TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (clinica_id, chave))`);
  await pool.query(`CREATE INDEX IF NOT EXISTS ix_legado_cpf ON legado_clientes(clinica_id, cpf_idx)`);
  await pool.query(`CREATE INDEX IF NOT EXISTS ix_legado_nome ON legado_clientes(clinica_id, nome_norm)`);
  // v4.9.49 aviso no celular quando chega mensagem nova (Web Push); cada linha é um navegador que ligou o aviso
  await pool.query(`CREATE TABLE IF NOT EXISTS push_inscricoes (
    id BIGSERIAL PRIMARY KEY,
    clinica_id UUID NOT NULL REFERENCES clinicas(id),
    usuario_id UUID NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE,
    endpoint TEXT NOT NULL UNIQUE,
    p256dh TEXT NOT NULL,
    auth TEXT NOT NULL,
    aparelho VARCHAR(120),
    falhas INTEGER NOT NULL DEFAULT 0,
    criado_em TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    ultimo_envio TIMESTAMPTZ)`);
  await pool.query(`CREATE INDEX IF NOT EXISTS ix_push_usuario ON push_inscricoes(usuario_id)`);
  // v4.9.53 controle de tarefas que rodam uma vez por dia em cada clínica (ex.: aviso dos lembretes de cobrança)
  await pool.query(`CREATE TABLE IF NOT EXISTS avisos_diarios (
    clinica_id UUID NOT NULL REFERENCES clinicas(id) ON DELETE CASCADE,
    tipo VARCHAR(30) NOT NULL,
    dia DATE NOT NULL,
    criado_em TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (clinica_id, tipo, dia))`);
  // v4.9.61 anexos da ficha do cliente na OCO (foto da receita de papel, documentos, foto do cliente). Imagem cifrada.
  await pool.query(`CREATE TABLE IF NOT EXISTS oco_anexos (
    id BIGSERIAL PRIMARY KEY,
    clinica_id UUID NOT NULL REFERENCES clinicas(id),
    cliente_id BIGINT NOT NULL,
    tipo VARCHAR(20) NOT NULL DEFAULT 'receita',
    descricao VARCHAR(200),
    imagem TEXT NOT NULL,
    tamanho INTEGER NOT NULL DEFAULT 0,
    criado_por UUID,
    criado_em TIMESTAMPTZ NOT NULL DEFAULT NOW())`);
  await pool.query(`CREATE INDEX IF NOT EXISTS ix_oco_anexos_cli ON oco_anexos(clinica_id, cliente_id)`);
}

module.exports = migrar;
