/* Assistente de textos com IA gratuita (Google Gemini) ou, se não houver, a chave da Anthropic.
   Serve só para texto geral (sem dados de paciente). A leitura de fotos continua em /leitura. */
const express = require('express');
const { exigirLogin } = require('../middleware/auth');

const router = express.Router();
router.use(exigirLogin);

const GEMINI_MODELO = process.env.GEMINI_MODEL || 'gemini-3.5-flash-lite';
const ANTHROPIC_MODELO = process.env.ANTHROPIC_MODEL || 'claude-haiku-4-5-20251001';

function provedor() {
  if (process.env.GEMINI_API_KEY) return 'gemini';
  if (process.env.ANTHROPIC_API_KEY) return 'anthropic';
  return null;
}

/* limite simples por usuário: 40 pedidos por hora, para ficar dentro da cota gratuita */
const usos = new Map();
function dentroDoLimite(id) {
  const agora = Date.now();
  const lista = (usos.get(id) || []).filter((t) => agora - t < 3600000);
  if (lista.length >= 40) { usos.set(id, lista); return false; }
  lista.push(agora); usos.set(id, lista); return true;
}

/* tira o que parece dado pessoal antes de enviar para fora */
function protegerTexto(t) {
  return String(t || '')
    .replace(/\b\d{3}\.?\d{3}\.?\d{3}-?\d{2}\b/g, '[CPF removido]')
    .replace(/[\w.+-]+@[\w-]+\.[\w.-]+/g, '[e-mail removido]')
    .replace(/(\+?55\s?)?\(?\d{2}\)?\s?9?\d{4}[-\s]?\d{4}\b/g, '[telefone removido]');
}

const SISTEMA = 'Você ajuda uma ótica e clínica de exame de vista no Brasil. Responda em português do Brasil, com frases curtas e simples, voz ativa, sem markdown, sem asteriscos, sem hashtags e sem travessões. Não invente dados clínicos. Não dê diagnóstico. Se o pedido for sobre saúde, diga que o profissional responsável decide.';

router.get('/status', (req, res) => {
  const p = provedor();
  res.json({ ligada: !!p, provedor: p, gratuita: p === 'gemini' });
});

router.post('/texto', async (req, res) => {
  const p = provedor();
  if (!p) return res.status(503).json({ erro: 'A IA não está ligada. Falta colocar a chave GEMINI_API_KEY no Render.', semIA: true });
  let pedido = String((req.body || {}).pedido || '').trim().slice(0, 1500);
  if (pedido.length < 4) return res.status(400).json({ erro: 'Escreva o que você quer.' });
  if (!dentroDoLimite(req.usuario.usuarioId)) return res.status(429).json({ erro: 'Muitos pedidos seguidos. Tente de novo mais tarde.' });
  pedido = protegerTexto(pedido);
  try {
    const ctl = new AbortController();
    const timer = setTimeout(() => ctl.abort(), 30000);
    let r, texto = '';
    if (p === 'gemini') {
      r = await fetch((process.env.GEMINI_API_BASE || 'https://generativelanguage.googleapis.com').replace(/\/$/, '') + '/v1beta/models/' + encodeURIComponent(GEMINI_MODELO) + ':generateContent', {
        method: 'POST', signal: ctl.signal,
        headers: { 'content-type': 'application/json', 'x-goog-api-key': process.env.GEMINI_API_KEY },
        body: JSON.stringify({
          systemInstruction: { parts: [{ text: SISTEMA }] },
          contents: [{ role: 'user', parts: [{ text: pedido }] }],
          generationConfig: { maxOutputTokens: 700, temperature: 0.5 },
        }),
      });
      clearTimeout(timer);
      if (!r.ok) { console.error('IA (Gemini) falhou:', r.status); return res.status(r.status === 429 ? 429 : 502).json({ erro: r.status === 429 ? 'O limite gratuito do dia acabou. Tente mais tarde.' : 'Não consegui responder agora. Tente de novo.' }); }
      const d = await r.json();
      texto = ((((d.candidates || [])[0] || {}).content || {}).parts || []).map((x) => x.text || '').join('');
    } else {
      r = await fetch((process.env.ANTHROPIC_API_BASE || 'https://api.anthropic.com').replace(/\/$/, '') + '/v1/messages', {
        method: 'POST', signal: ctl.signal,
        headers: { 'content-type': 'application/json', 'x-api-key': process.env.ANTHROPIC_API_KEY, 'anthropic-version': '2023-06-01' },
        body: JSON.stringify({ model: ANTHROPIC_MODELO, max_tokens: 700, system: SISTEMA, messages: [{ role: 'user', content: pedido }] }),
      });
      clearTimeout(timer);
      if (!r.ok) { console.error('IA (Anthropic) falhou:', r.status); return res.status(502).json({ erro: 'Não consegui responder agora. Tente de novo.' }); }
      const d = await r.json();
      texto = (d.content || []).map((c) => c.text || '').join('');
    }
    texto = texto.replace(/[*#]/g, '').replace(/\s+—\s+/g, ', ').replace(/—/g, ', ').trim();
    if (!texto) return res.status(502).json({ erro: 'A IA não devolveu texto. Tente de novo.' });
    res.json({ ok: true, texto, provedor: p });
  } catch (e) {
    console.error('IA erro:', e.message);
    res.status(502).json({ erro: 'Não consegui responder agora. Tente de novo.' });
  }
});

/* ---------- Conversa (texto ou voz): conhece o sistema e propõe correções do Guardião ---------- */
const fs = require('fs');
const path = require('path');
let FUNCOES_TXT = '';
try { FUNCOES_TXT = fs.readFileSync(path.join(__dirname, '..', 'data', 'funcoes.txt'), 'utf8'); } catch (e) { FUNCOES_TXT = ''; }
function SAUDE_OCULAR_CONVERSA() { return SAUDE_OCULAR; }

const MANUAL_BASE = `Sistema: Clínica de Visão, de exame de vista, usado pela Ótica Centro Oeste em várias cidades. Feito com Node, Postgres e hospedado no Render.
Papéis: administrador (Master, vê tudo), agendador (marca exames na cidade dele), profissional (faz receita, atestado e declaração), gestor.
Área Master (só o administrador): abas Guardião, Clínica, Agenda, Equipe, Segurança e Integrações.
O Guardião confere o sistema a cada 6 horas: obrigações (backup, teste de restauração, trocar senhas e chaves), segurança, backup, sistema e operação. Alguns itens têm botão de correção com um clique.
Variáveis que o administrador coloca no Render, em Environment: GEMINI_API_KEY (IA gratuita), SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS (e-mail), BACKUP_EMAIL_PARA, WA_TOKEN e WA_PHONE_ID (WhatsApp da Meta), CHAVE_CRIPTOGRAFIA (guardar uma cópia fora do sistema).
Vigia da equipe (aba Equipe): a cada hora confere o que a equipe faz (madrugada, muitas fichas abertas, exclusões, marcações em massa, entrada de dois lugares distantes, backup baixado, conta de Master nova, senhas erradas). Cria alertas e pedidos (encerrar sessões, bloquear conta) que só rodam quando o Master autoriza. O Master pode pedir a opinião da IA, abrir sindicância, ver a linha do tempo da pessoa, escrever o parecer e concluir como arquivada ou procedente.\nCadastro de cidades: aba Equipe, quadro Cidades de exame de vista, ou aba Agenda, quadro Exame em outra cidade.\nLimites desta IA: ela não vê dados de pacientes, não altera nada sozinha, e só dispara correção do Guardião ou pedido do Vigia quando o administrador confirma.`;

async function chamarIA(sistema, historico, json) {
  const p = provedor();
  const ctl = new AbortController();
  const timer = setTimeout(() => ctl.abort(), 40000);
  try {
    if (p === 'gemini') {
      const r = await fetch((process.env.GEMINI_API_BASE || 'https://generativelanguage.googleapis.com').replace(/\/$/, '') + '/v1beta/models/' + encodeURIComponent(GEMINI_MODELO) + ':generateContent', {
        method: 'POST', signal: ctl.signal,
        headers: { 'content-type': 'application/json', 'x-goog-api-key': process.env.GEMINI_API_KEY },
        body: JSON.stringify({
          systemInstruction: { parts: [{ text: sistema }] },
          contents: historico.map((m) => ({ role: m.papel === 'ia' ? 'model' : 'user', parts: [{ text: m.texto }] })),
          generationConfig: Object.assign({ maxOutputTokens: 900, temperature: 0.4 }, json ? { responseMimeType: 'application/json' } : {}),
        }),
      });
      if (!r.ok) { const e = new Error('http ' + r.status); e.status = r.status; throw e; }
      const d = await r.json();
      return ((((d.candidates || [])[0] || {}).content || {}).parts || []).map((x) => x.text || '').join('');
    }
    const r = await fetch((process.env.ANTHROPIC_API_BASE || 'https://api.anthropic.com').replace(/\/$/, '') + '/v1/messages', {
      method: 'POST', signal: ctl.signal,
      headers: { 'content-type': 'application/json', 'x-api-key': process.env.ANTHROPIC_API_KEY, 'anthropic-version': '2023-06-01' },
      body: JSON.stringify({ model: ANTHROPIC_MODELO, max_tokens: 900, system: sistema, messages: historico.map((m) => ({ role: m.papel === 'ia' ? 'assistant' : 'user', content: m.texto })) }),
    });
    if (!r.ok) { const e = new Error('http ' + r.status); e.status = r.status; throw e; }
    const d = await r.json();
    return (d.content || []).map((c) => c.text || '').join('');
  } finally { clearTimeout(timer); }
}

router.post('/conversa', async (req, res) => {
  if (!provedor()) return res.status(503).json({ erro: 'A IA não está ligada. Falta colocar a chave GEMINI_API_KEY no Render.', semIA: true });
  const bruto = Array.isArray((req.body || {}).mensagens) ? req.body.mensagens.slice(-10) : [];
  const historico = bruto.map((m) => ({ papel: m && m.papel === 'ia' ? 'ia' : 'eu', texto: protegerTexto(String((m && m.texto) || '').slice(0, 1200)) })).filter((m) => m.texto.trim());
  if (!historico.length || historico[historico.length - 1].papel !== 'eu') return res.status(400).json({ erro: 'Escreva ou fale algo.' });
  if (!dentroDoLimite(req.usuario.usuarioId)) return res.status(429).json({ erro: 'Muitos pedidos seguidos. Tente de novo mais tarde.' });
  const ehAdmin = req.usuario.papel === 'admin';
  let estado = 'Estado do Guardião: não disponível para este perfil.';
  const permitidas = new Map();
  if (ehAdmin) {
    try {
      const v = await require('../utils/guardiao').verificar(req.usuario.clinicaId);
      const itens = v.itens.filter((i) => i.nivel === 'erro' || i.nivel === 'aviso');
      estado = itens.length ? 'Itens do Guardião que precisam de atenção agora:\n' + itens.map((i) => {
        let a = '';
        if (i.acao && i.acao.tipo === 'corrigir') { permitidas.set(i.acao.id, i.acao.rotulo); a = ` [correção possível: id=${i.acao.id}, botão "${i.acao.rotulo}"]`; }
        else if (i.acao && i.acao.tipo === 'passos') a = ` [passos manuais: ${(i.acao.passos || []).join(' | ')}]`;
        else if (i.acao && i.acao.tipo === 'obrigacao') a = ' [obrigação: o administrador marca Já fiz ou Adiar na tela do Guardião]';
        else if (i.acao && i.acao.tipo === 'ir') a = ` [tela: ${i.acao.rotulo}]`;
        return `- (${i.nivel}) ${i.titulo}: ${protegerTexto(i.detalhe || '')}${a}`;
      }).join('\n') : 'Estado do Guardião: tudo em ordem, nenhum item precisa de atenção.';
    } catch (e) { estado = 'Estado do Guardião: não consegui ler agora.'; }
    /* o que o Vigia da equipe achou e os pedidos que esperam o sim do Master */
    try {
      const pool = require('../db/pool');
      const oc = (await pool.query(`SELECT titulo, gravidade, status, ia_parecer FROM vigia_ocorrencias WHERE clinica_id=$1 AND status IN ('aberta','sindicancia') ORDER BY criado_em DESC LIMIT 8`, [req.usuario.clinicaId])).rows;
      const pe = (await pool.query(`SELECT id, tipo, alvo_nome, motivo FROM vigia_pedidos WHERE clinica_id=$1 AND status='pendente' ORDER BY criado_em DESC LIMIT 8`, [req.usuario.clinicaId])).rows;
      const nomesPed = require('../utils/vigia').PEDIDOS;
      for (const p of pe) permitidas.set('pedido:' + p.id, `${nomesPed[p.tipo] || p.tipo}: ${p.alvo_nome || ''}`);
      estado += '\n\nVigia da equipe (aba Equipe do Master). Alertas abertos: ' + (oc.length ? '\n' + oc.map((o) => `- (${o.gravidade}, ${o.status}) ${o.titulo}${o.ia_parecer ? '. Sua opinião anterior: ' + o.ia_parecer : ''}`).join('\n') : 'nenhum.') +
        '\nPedidos esperando o sim do Master: ' + (pe.length ? '\n' + pe.map((p) => `- ${nomesPed[p.tipo] || p.tipo} de ${p.alvo_nome || 'alguém'} (motivo: ${p.motivo || ''}) [correção possível: id=pedido:${p.id}, botão "${nomesPed[p.tipo] || p.tipo}: ${p.alvo_nome || ''}"]`).join('\n') : 'nenhum.') +
        '\nVocê pode explicar os alertas, sugerir abrir sindicância (botão Abrir sindicância no alerta) e oferecer um pedido. Nunca acuse: um alerta não prova culpa.';
    } catch (e) { /* sem vigia */ }
  }
  const sistema = SISTEMA + '\n\nVocê é o assistente de voz do administrador. Fale como numa conversa: respostas curtas, de 1 a 4 frases, fáceis de ouvir, sem listas e sem símbolos. Quando indicar onde clicar, diga a tela e a aba. Se a pergunta for sobre o sistema, use só o manual abaixo. Se não estiver no manual, diga que não sabe.\n' +
    'Se um item do Guardião tiver correção possível e o administrador pedir para arrumar, explique em uma frase o que será feito e pergunte se pode fazer. Nesse caso devolva o id da correção em acao_id. Nunca diga que já corrigiu: quem executa é o botão que o sistema mostra depois que ele confirmar. Para itens sem correção possível, explique os passos.\n' +
    'Responda SEMPRE só com um JSON neste formato: {"fala": string, "acao_id": string ou null}.\n\nMANUAL\n' + MANUAL_BASE + '\n\nFUNÇÕES DO SISTEMA\n' + FUNCOES_TXT + '\n\nSAÚDE OCULAR (para explicar e orientar, nunca diagnosticar)\n' + SAUDE_OCULAR_CONVERSA() + '\n\n' + estado;
  try {
    const texto = await chamarIA(sistema, historico, true);
    let fala = '', acao = null;
    const m = /\{[\s\S]*\}/.exec(texto);
    try { const j = JSON.parse(m ? m[0] : texto); fala = String(j.fala || ''); if (j.acao_id && permitidas.has(String(j.acao_id))) acao = { id: String(j.acao_id), rotulo: permitidas.get(String(j.acao_id)) }; }
    catch (e) { fala = texto; }
    fala = fala.replace(/[*#]/g, '').replace(/\s+—\s+/g, ', ').replace(/—/g, ', ').trim();
    if (!fala) return res.status(502).json({ erro: 'A IA não devolveu resposta. Tente de novo.' });
    res.json({ ok: true, fala, acao });
  } catch (e) {
    console.error('IA conversa erro:', e.message);
    res.status(e.status === 429 ? 429 : 502).json({ erro: e.status === 429 ? 'O limite gratuito do dia acabou. Tente mais tarde.' : 'Não consegui responder agora. Tente de novo.' });
  }
});

/* ---------- FOTOS PARA A IA ----------
   Foto de paciente é dado de saúde. Só vai para IA que não usa os dados para treinar:
   a chave da Anthropic (paga por uso) ou o Gemini com faturamento ligado (o Master confirma
   colocando IA_FOTO_PAGA=1 no Render). No plano grátis do Gemini as fotos ficam desligadas. */
function provedorFoto() {
  if (process.env.ANTHROPIC_API_KEY) return 'anthropic';
  if (process.env.GEMINI_API_KEY && process.env.IA_FOTO_PAGA === '1') return 'gemini';
  return null;
}
async function chamarIAImagem(sistema, texto, mime, base64, json, maxTokens) {
  /* aceita uma foto (mime, base64) ou várias: mime = [{mime, data}, ...] */
  const fotos = Array.isArray(mime) ? mime : [{ mime, data: base64 }];
  const p = provedorFoto();
  if (!p) { const e = new Error('sem ia de foto'); e.semIA = true; throw e; }
  const ctl = new AbortController();
  const timer = setTimeout(() => ctl.abort(), 50000);
  try {
    if (p === 'gemini') {
      const r = await fetch((process.env.GEMINI_API_BASE || 'https://generativelanguage.googleapis.com').replace(/\/$/, '') + '/v1beta/models/' + encodeURIComponent(GEMINI_MODELO) + ':generateContent', {
        method: 'POST', signal: ctl.signal,
        headers: { 'content-type': 'application/json', 'x-goog-api-key': process.env.GEMINI_API_KEY },
        body: JSON.stringify({
          systemInstruction: sistema ? { parts: [{ text: sistema }] } : undefined,
          contents: [{ role: 'user', parts: [...fotos.map((f) => ({ inlineData: { mimeType: f.mime, data: f.data } })), { text: texto }] }],
          generationConfig: Object.assign({ maxOutputTokens: maxTokens || 1200, temperature: 0.2 }, json ? { responseMimeType: 'application/json' } : {}),
        }),
      });
      if (!r.ok) { const e = new Error('http ' + r.status); e.status = r.status; throw e; }
      const d = await r.json();
      return ((((d.candidates || [])[0] || {}).content || {}).parts || []).map((x) => x.text || '').join('');
    }
    const r = await fetch((process.env.ANTHROPIC_API_BASE || 'https://api.anthropic.com').replace(/\/$/, '') + '/v1/messages', {
      method: 'POST', signal: ctl.signal,
      headers: { 'content-type': 'application/json', 'x-api-key': process.env.ANTHROPIC_API_KEY, 'anthropic-version': '2023-06-01' },
      body: JSON.stringify({ model: ANTHROPIC_MODELO, max_tokens: maxTokens || 1200, system: sistema || undefined,
        messages: [{ role: 'user', content: [...fotos.map((f) => ({ type: 'image', source: { type: 'base64', media_type: f.mime, data: f.data } })), { type: 'text', text: texto }] }] }),
    });
    if (!r.ok) { const e = new Error('http ' + r.status); e.status = r.status; throw e; }
    const d = await r.json();
    return (d.content || []).map((c) => c.text || '').join('');
  } finally { clearTimeout(timer); }
}

let SAUDE_OCULAR = '';
try { SAUDE_OCULAR = fs.readFileSync(path.join(__dirname, '..', 'data', 'saude-ocular.txt'), 'utf8'); } catch (e) { SAUDE_OCULAR = ''; }

const FOTO_TIPOS = {
  receita: 'Foto de uma receita de óculos, papel com grau ou visor de aparelho (autorrefrator, lensômetro).',
  olho: 'Foto do olho do paciente (parte branca, córnea, íris, pupila).',
  palpebra: 'Foto da pálpebra ou da pele em volta do olho, com uma lesão, caroço, mancha ou ferida.',
  oct: 'Foto ou print de laudo de OCT (tomografia de coerência óptica): nervo óptico e RNFL, mácula, ou cortes B-scan.',
  retinografia: 'Foto de retinografia ou fundo de olho (disco óptico, vasos, mácula, retina).',
  campo_visual: 'Foto de laudo de campo visual (campimetria, Humphrey ou parecido).',
  topografia: 'Foto de topografia ou tomografia de córnea (Pentacam, Orbscan, topógrafo), ou paquimetria.',
  exame: 'Foto de outro laudo de exame dos olhos (pressão intraocular, autorrefrator com ceratometria, biometria, teste de cores, acuidade).',
};
const TIPOS_EXAME = ['oct', 'retinografia', 'campo_visual', 'topografia', 'exame'];
const URGENCIAS = ['urgente', 'prioridade', 'rotina', 'sem_alerta'];

router.get('/foto/status', (req, res) => {
  const p = provedorFoto();
  res.json({ ligada: !!p, provedor: p, motivo: p ? null : (process.env.GEMINI_API_KEY ? 'gemini_gratis' : 'sem_chave') });
});

router.post('/foto', async (req, res) => {
  if (!['admin', 'profissional'].includes(req.usuario.papel)) return res.status(403).json({ erro: 'Só o Master e o profissional enviam foto para a IA.' });
  const b = req.body || {};
  const tipo = FOTO_TIPOS[b.tipo] ? b.tipo : null;
  if (!tipo) return res.status(400).json({ erro: 'Escolha o tipo da foto: receita, olho ou pálpebra.' });
  if (tipo !== 'receita' && b.consentimento !== true) return res.status(400).json({ erro: 'Marque que o paciente autorizou o envio da foto.' });
  const brutas = (Array.isArray(b.imagens) ? b.imagens : [b.imagem]).filter(Boolean).slice(0, 3);
  const fotos = [];
  for (const im of brutas) {
    const mm = /^data:(image\/(?:jpeg|png|webp));base64,([A-Za-z0-9+/=]+)$/.exec(String(im || ''));
    if (!mm) return res.status(400).json({ erro: 'Envie uma foto válida (JPG, PNG ou WEBP).' });
    if (mm[2].length > 7 * 1024 * 1024) return res.status(413).json({ erro: 'Foto grande demais. Tire de novo ou reduza.' });
    fotos.push({ mime: mm[1], data: mm[2] });
  }
  if (!fotos.length) return res.status(400).json({ erro: 'Envie pelo menos uma foto.' });
  if (!provedorFoto()) return res.status(503).json({ semIA: true, erro: process.env.GEMINI_API_KEY
    ? 'A análise de fotos de paciente está desligada porque o Gemini grátis pode usar as fotos para treinar. Ligue o faturamento no Google AI Studio e coloque IA_FOTO_PAGA=1 no Render.'
    : 'A análise de fotos ainda não está ligada. Falta a chave da IA no Render.' });
  if (!dentroDoLimite(req.usuario.usuarioId)) return res.status(429).json({ erro: 'Muitos pedidos seguidos. Tente de novo mais tarde.' });
  const pergunta = protegerTexto(String(b.pergunta || '').slice(0, 600));
  const sistema = `Você é a assistente clínica de uma equipe de exame de vista no Brasil (optometrista e Master). Você apoia a leitura de exames e o raciocínio diagnóstico do profissional, como uma segunda opinião técnica.
Você lê os números e os mapas, compara com os valores de referência da base abaixo, aponta o que está normal, limítrofe ou alterado, e lista as hipóteses mais prováveis com o grau de confiança. Escreva "achados compatíveis com" ou "sugere", nunca "o paciente tem". Você NÃO fecha diagnóstico, NÃO receita remédio e NÃO afirma que algo é câncer: quem confirma é o médico oftalmologista. Diga se precisa encaminhar e com que pressa, e dê orientações de prevenção.
Leia só o que está visível. Se um número estiver cortado, coberto (por exemplo por um dedo ou um anúncio) ou ilegível, diga que não deu para ler, nunca invente. Ignore nome, documento e data de nascimento impressos e não os repita.
Se a foto estiver ruim (escura, tremida, longe, reflexo), diga o que melhorar. Se não houver nada de alerta, diga isso e lembre que foto não substitui exame.
Português do Brasil, frases curtas, voz ativa, sem markdown, sem asteriscos e sem travessões.

BASE DE SAÚDE OCULAR
${SAUDE_OCULAR}`;
  const formatoExame = '{"exame_identificado": string (qual exame e aparelho, por exemplo "OCT Cirrus, análise de nervo óptico e RNFL dos dois olhos"), "qualidade": string (por exemplo "força de sinal 8 de 10, boa"), "valores": [{"campo": string, "od": string ou null, "oe": string ou null, "referencia": string ou null, "situacao": "normal" ou "limitrofe" ou "alterado" ou "nao_lido"}], "descricao": string com os achados principais em linguagem simples, "sinais": [strings dos achados alterados], "possibilidades": [até 3 strings no formato "Compatível com X (confiança alta|média|baixa): motivo"], "exames_complementares": [strings de exames que ajudariam a confirmar], "urgencia": "urgente" ou "prioridade" ou "rotina" ou "sem_alerta", "encaminhar": true ou false, "motivo_encaminhamento": string ou null, "orientacoes": [strings], "qualidade_foto": "boa" ou "ruim", "melhorar_foto": string ou null}';
  const formato = TIPOS_EXAME.includes(tipo) ? formatoExame : tipo === 'receita'
    ? '{"leitura": {"od": {"esf": string ou null, "cil": string ou null, "eixo": string ou null, "dnp": string ou null}, "oe": {"esf": string ou null, "cil": string ou null, "eixo": string ou null, "dnp": string ou null}, "adicao": string ou null, "dp": string ou null}, "explicacao": string curta explicando o grau em palavras simples, "urgencia": "rotina", "sinais": [], "encaminhar": false, "orientacoes": [strings], "qualidade_foto": "boa" ou "ruim"}'
    : '{"descricao": string com o que se vê, "sinais": [strings com os sinais de alerta encontrados, vazio se nenhum], "possibilidades": [até 3 strings do tipo "pode ser compatível com X", sempre como hipótese a confirmar], "urgencia": "urgente" ou "prioridade" ou "rotina" ou "sem_alerta", "encaminhar": true ou false, "motivo_encaminhamento": string ou null, "orientacoes": [strings de cuidado e prevenção], "qualidade_foto": "boa" ou "ruim", "melhorar_foto": string ou null}';
  const texto = `${FOTO_TIPOS[tipo]}${fotos.length > 1 ? `\nSão ${fotos.length} fotos do mesmo exame ou paciente: leia todas juntas.` : ''}${pergunta ? '\nPergunta da equipe: ' + pergunta : ''}\nResponda SÓ com JSON neste formato: ${formato}`;
  try {
    const bruto = await chamarIAImagem(sistema, texto, fotos, null, true, 2500);
    const mm = /\{[\s\S]*\}/.exec(bruto);
    let j; try { j = JSON.parse(mm ? mm[0] : bruto); } catch (e) { return res.status(422).json({ erro: 'A IA não conseguiu analisar essa foto. Tente com mais luz e mais perto.' }); }
    const limpa = (t) => String(t == null ? '' : t).replace(/[*#<>]/g, '').replace(/\s+—\s+/g, ', ').replace(/—/g, ', ').trim().slice(0, 1200);
    const lista = (a, n) => (Array.isArray(a) ? a : []).map(limpa).filter(Boolean).slice(0, n);
    const out = {
      ok: true, tipo,
      urgencia: URGENCIAS.includes(j.urgencia) ? j.urgencia : 'rotina',
      encaminhar: !!j.encaminhar,
      motivo_encaminhamento: limpa(j.motivo_encaminhamento) || null,
      descricao: limpa(j.descricao || j.explicacao),
      sinais: lista(j.sinais, 8), possibilidades: lista(j.possibilidades, 4), orientacoes: lista(j.orientacoes, 6),
      qualidade_foto: j.qualidade_foto === 'ruim' ? 'ruim' : 'boa', melhorar_foto: limpa(j.melhorar_foto) || null,
      aviso: 'Triagem por IA para apoio. Não é diagnóstico. Quem confirma é o médico oftalmologista.',
    };
    if (tipo === 'receita' && j.leitura) out.leitura = j.leitura;
    if (TIPOS_EXAME.includes(tipo)) {
      out.exame_identificado = limpa(j.exame_identificado) || null;
      out.qualidade = limpa(j.qualidade) || null;
      out.exames_complementares = lista(j.exames_complementares, 5);
      const SIT = ['normal', 'limitrofe', 'alterado', 'nao_lido'];
      out.valores = (Array.isArray(j.valores) ? j.valores : []).slice(0, 30).map((v) => ({
        campo: limpa(v && v.campo).slice(0, 80), od: v && v.od != null ? limpa(v.od).slice(0, 40) : null, oe: v && v.oe != null ? limpa(v.oe).slice(0, 40) : null,
        referencia: v && v.referencia != null ? limpa(v.referencia).slice(0, 60) : null, situacao: SIT.includes(v && v.situacao) ? v.situacao : 'nao_lido' })).filter((v) => v.campo);
      out.aviso = 'Leitura de apoio feita por IA. Confira os números no laudo original. O diagnóstico é do médico oftalmologista.';
    }
    if (out.urgencia === 'urgente') out.encaminhar = true;
    const pool = require('../db/pool');
    pool.query(`INSERT INTO acessos_log (clinica_id, usuario_id, usuario_nome, acao, area, caminho, ip) VALUES ($1,$2,$3,'POST','ia_foto',$4,$5)`,
      [req.usuario.clinicaId, req.usuario.usuarioId, req.usuario.nome || null, '/ia/foto/' + tipo, req.ip]).catch(() => {});
    res.json(out);
  } catch (e) {
    console.error('IA foto erro:', e.message);
    res.status(e.status === 429 ? 429 : 502).json({ erro: e.status === 429 ? 'O limite da IA acabou por agora. Tente mais tarde.' : 'A IA não respondeu agora. Tente de novo.' });
  }
});

router.provedor = provedor;
router.chamarIA = chamarIA;
router.provedorFoto = provedorFoto;
router.chamarIAImagem = chamarIAImagem;
module.exports = router;
