/* Conferências feitas no servidor. A tela já confere, mas quem chama a API direto (ou um erro de tela) não pode gravar lixo. */
function cpfValido(bruto) {
  const c = String(bruto == null ? '' : bruto).replace(/\D/g, '');
  if (c.length !== 11 || /^(\d)\1{10}$/.test(c)) return false;
  for (const t of [9, 10]) {
    let s = 0;
    for (let i = 0; i < t; i++) s += parseInt(c[i], 10) * (t + 1 - i);
    let d = (s * 10) % 11; if (d === 10) d = 0;
    if (d !== parseInt(c[t], 10)) return false;
  }
  return true;
}
/* telefone brasileiro: 10 ou 11 números (com DDD), podendo vir com 55 na frente */
function telefoneValido(bruto) {
  const d = String(bruto == null ? '' : bruto).replace(/\D/g, '');
  return d.length >= 10 && d.length <= 13;
}
/* devolve a mensagem de erro, ou null se estiver tudo certo. Campo vazio é aceito: a obrigatoriedade é regra de cada clínica. */
function conferirContato({ cpf, telefone }) {
  if (cpf && !cpfValido(cpf)) return 'CPF inválido. Confira os números.';
  if (telefone && !telefoneValido(telefone)) return 'Telefone inválido. Informe o DDD e o número.';
  return null;
}
module.exports = { cpfValido, telefoneValido, conferirContato };
