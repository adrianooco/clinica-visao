/* Código de 6 números do celular (padrão TOTP, igual Google Authenticator), sem biblioteca externa */
const crypto = require('crypto');
const A = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';

function novoSegredo() {
  const b = crypto.randomBytes(20); let bits = '', s = '';
  for (const x of b) bits += x.toString(2).padStart(8, '0');
  for (let i = 0; i + 5 <= bits.length; i += 5) s += A[parseInt(bits.slice(i, i + 5), 2)];
  return s;
}
function decodificar(s) {
  let bits = '';
  for (const c of String(s).replace(/=+$/, '').toUpperCase()) { const v = A.indexOf(c); if (v < 0) continue; bits += v.toString(2).padStart(5, '0'); }
  const out = []; for (let i = 0; i + 8 <= bits.length; i += 8) out.push(parseInt(bits.slice(i, i + 8), 2));
  return Buffer.from(out);
}
function codigo(segredo, passo) {
  const buf = Buffer.alloc(8); buf.writeBigUInt64BE(BigInt(passo));
  const h = crypto.createHmac('sha1', decodificar(segredo)).update(buf).digest();
  const o = h[h.length - 1] & 0xf;
  const n = ((h[o] & 0x7f) << 24) | (h[o + 1] << 16) | (h[o + 2] << 8) | h[o + 3];
  return String(n % 1000000).padStart(6, '0');
}
const passoAtual = (agora = Date.now()) => Math.floor(agora / 30000);
/* aceita o código do passo atual, do anterior e do próximo (relógio um pouco fora). Devolve o passo usado ou null. */
function conferir(segredo, texto, ultimoPasso = 0, agora = Date.now()) {
  const t = String(texto || '').replace(/\s/g, '');
  if (!/^\d{6}$/.test(t)) return null;
  const p = passoAtual(agora);
  for (const d of [0, -1, 1]) {
    const passo = p + d;
    if (passo <= ultimoPasso) continue; // código já usado
    const a = Buffer.from(codigo(segredo, passo)), b = Buffer.from(t);
    if (crypto.timingSafeEqual(a, b)) return passo;
  }
  return null;
}
const urlApp = (segredo, email, emissor = 'Clínica de Visão') => `otpauth://totp/${encodeURIComponent(emissor)}:${encodeURIComponent(email)}?secret=${segredo}&issuer=${encodeURIComponent(emissor)}&digits=6&period=30`;
module.exports = { novoSegredo, codigo, conferir, passoAtual, urlApp };
