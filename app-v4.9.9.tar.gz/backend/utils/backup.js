const crypto = require('crypto');
const pool = require('../db/pool');
const cripto = require('./cripto');

/* Cópia completa dos dados da clínica: todas as tabelas, incluindo
   senhas (já embaralhadas), prontuários, histórico de correções e registro de acessos.
   Serve para restaurar o sistema inteiro num banco novo. */
async function gerarBackupCompleto(clinicaId) {
  const t = await pool.query(`SELECT table_name FROM information_schema.tables WHERE table_schema='public' AND table_type='BASE TABLE' ORDER BY table_name`);
  const comClinica = await pool.query(`SELECT table_name FROM information_schema.columns WHERE table_schema='public' AND column_name='clinica_id'`);
  const temClinica = new Set(comClinica.rows.map((r) => r.table_name));
  const copia = { formato: 'clinica-visao-backup-2', gerado_em: new Date().toISOString(), clinica_id: clinicaId, tabelas: {} };
  for (const { table_name: nome } of t.rows) {
    if (!/^[a-z_]+$/.test(nome)) continue;
    let sql, params = [];
    if (nome === 'clinicas') { sql = `SELECT to_jsonb(x) AS j FROM clinicas x WHERE id=$1`; params = [clinicaId]; }
    else if (temClinica.has(nome)) { sql = `SELECT to_jsonb(x) AS j FROM ${nome} x WHERE clinica_id=$1`; params = [clinicaId]; }
    else if (nome === 'prontuario_versoes') { sql = `SELECT to_jsonb(x) AS j FROM prontuario_versoes x WHERE prontuario_id IN (SELECT id FROM prontuarios WHERE clinica_id=$1)`; params = [clinicaId]; }
    else continue;
    let linhas = (await pool.query(sql, params)).rows.map((r) => r.j);
    // dentro do backup os dados vão abertos; o arquivo todo é trancado com a senha do administrador
    if (nome === 'prontuarios') linhas = linhas.map(cripto.abrirProntuario);
    else if (nome === 'usuarios') linhas = linhas.map((l) => ({ ...l, totp_segredo: l.totp_segredo ? cripto.decifrar(l.totp_segredo) : l.totp_segredo }));
    else if (nome === 'receitas') linhas = linhas.map(cripto.abrirReceita);
    else if (nome === 'pacientes') linhas = linhas.map(cripto.abrirPaciente);
    else if (nome === 'gestor_vendas_dados' || nome === 'gestor_vendas_copias') linhas = linhas.map((l) => ({ ...l, dados: cripto.decifrar(l.dados) }));
    else if (nome === 'prontuario_versoes') linhas = linhas.map((l) => ({ ...l, snapshot: l.snapshot && typeof l.snapshot === 'object' ? cripto.abrirProntuario(l.snapshot) : l.snapshot }));
    copia.tabelas[nome] = linhas;
  }
  return copia;
}

/* Tranca o backup com senha: scrypt + AES-256-GCM. Sem a senha, o arquivo não abre. */
function protegerBackup(obj, senha) {
  const salt = crypto.randomBytes(16), iv = crypto.randomBytes(12);
  const chave = crypto.scryptSync(String(senha), salt, 32, { N: 16384, r: 8, p: 1 });
  const c = crypto.createCipheriv('aes-256-gcm', chave, iv);
  const dados = Buffer.concat([c.update(JSON.stringify(obj), 'utf8'), c.final()]);
  return { formato: 'clinica-visao-backup-protegido-1', gerado_em: obj.gerado_em, kdf: 'scrypt', salt: salt.toString('base64'), iv: iv.toString('base64'), tag: c.getAuthTag().toString('base64'), dados: dados.toString('base64') };
}
function abrirBackupProtegido(env, senha) {
  const chave = crypto.scryptSync(String(senha), Buffer.from(env.salt, 'base64'), 32, { N: 16384, r: 8, p: 1 });
  const d = crypto.createDecipheriv('aes-256-gcm', chave, Buffer.from(env.iv, 'base64'));
  d.setAuthTag(Buffer.from(env.tag, 'base64'));
  try { return JSON.parse(Buffer.concat([d.update(Buffer.from(env.dados, 'base64')), d.final()]).toString('utf8')); }
  catch (e) { throw new Error('Senha errada ou arquivo danificado.'); }
}

module.exports = { gerarBackupCompleto, protegerBackup, abrirBackupProtegido };
