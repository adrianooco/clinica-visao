/* Aviso de aparelho novo: quando alguém entra de um aparelho que nunca usou o sistema, o dono da conta recebe um e-mail. */
const crypto = require('crypto');
const pool = require('../db/pool');
const email = require('./email');

async function registrarDispositivo(req, usuario) {
  try {
    const ua = String(req.headers['user-agent'] || 'desconhecido').slice(0, 300);
    const hash = crypto.createHash('sha256').update(ua).digest('hex');
    const antes = await pool.query(`SELECT COUNT(*)::int AS n, COUNT(*) FILTER (WHERE hash=$2)::int AS este FROM dispositivos_login WHERE usuario_id=$1`, [usuario.id, hash]);
    const { n, este } = antes.rows[0];
    await pool.query(
      `INSERT INTO dispositivos_login (usuario_id, hash, agente) VALUES ($1,$2,$3)
       ON CONFLICT (usuario_id, hash) DO UPDATE SET visto_em = NOW()`, [usuario.id, hash, ua]);
    // só avisa se a pessoa já tinha entrado antes por outro aparelho
    if (n > 0 && este === 0 && email.ativo() && usuario.email) {
      await email.enviar({
        para: usuario.email,
        assunto: 'Novo aparelho entrou na sua conta',
        texto: `Olá, ${usuario.nome || ''}.\n\nSua conta na Clínica de Visão foi aberta agora de um aparelho novo.\n\nAparelho: ${ua}\nEndereço de rede: ${req.ip}\n\nSe foi você, pode ignorar. Se não foi, entre no sistema, abra Meu perfil e toque em "Sair de todos os aparelhos". Depois troque sua senha.`,
      });
    }
  } catch (e) { console.error('Aviso de aparelho:', e.message); }
}
module.exports = { registrarDispositivo };
