/* Embaralha o que ainda está aberto no banco (prontuários, receitas, fotos).
   Com { reescrever: true } troca a chave: abre com a chave antiga e grava de novo com a nova.
   Pode rodar quantas vezes quiser: o que já está embaralhado é ignorado. */
const pool = require('../db/pool');
const cripto = require('./cripto');

const ehString = (v) => typeof v === 'string';
/* texto: vazio continua vazio */
function texto(v, reescrever) {
  if (v === null || v === undefined || v === '') return { valor: v, mudou: false };
  if (cripto.jaCifrado(v)) return reescrever ? { valor: cripto.cifrar(cripto.decifrar(v)), mudou: true } : { valor: v, mudou: false };
  return { valor: cripto.cifrar(v), mudou: true };
}
/* json (guardado como texto embaralhado dentro do jsonb) */
function json(v, reescrever) {
  if (v === null || v === undefined) return { valor: null, mudou: false };
  if (ehString(v) && cripto.jaCifrado(v)) return reescrever ? { valor: cripto.cifrarJson(cripto.decifrarJson(v)), mudou: true } : { valor: JSON.stringify(v), mudou: false };
  return { valor: cripto.cifrarJson(v), mudou: true };
}

async function tabela(nome, colsTexto, colsJson, reescrever) {
  const cols = [...colsTexto, ...colsJson];
  const r = await pool.query(`SELECT id, ${cols.join(', ')} FROM ${nome}`);
  let n = 0;
  for (const l of r.rows) {
    let mudou = false; const valores = [];
    for (const c of colsTexto) { const x = texto(l[c], reescrever); mudou = mudou || x.mudou; valores.push(x.valor); }
    for (const c of colsJson) { const x = json(l[c], reescrever); mudou = mudou || x.mudou; valores.push(x.valor); }
    if (!mudou) continue;
    const sets = cols.map((c, i) => `${c}=$${i + 1}`).join(', ');
    await pool.query(`UPDATE ${nome} SET ${sets} WHERE id=$${cols.length + 1}`, [...valores, l.id]);
    n++;
  }
  return n;
}

/* CPF: embaralha o número e mantém a impressão (cpf_idx) sempre certa, mesmo depois de trocar a chave */
async function protegerCpf(reescrever) {
  const r = await pool.query(`SELECT id, cpf, cpf_idx FROM pacientes WHERE cpf IS NOT NULL AND cpf <> ''`);
  let n = 0;
  for (const l of r.rows) {
    let aberto;
    try { aberto = cripto.decifrar(l.cpf); } catch (e) { continue; }
    const idx = cripto.indiceCpf(aberto);
    const novo = cripto.ativa() ? (cripto.jaCifrado(l.cpf) && !reescrever ? l.cpf : cripto.cifrar(aberto)) : l.cpf;
    if (novo === l.cpf && idx === l.cpf_idx) continue;
    try { await pool.query(`UPDATE pacientes SET cpf=$1, cpf_idx=$2 WHERE id=$3`, [novo, idx, l.id]); n++; }
    catch (e) { console.error('Aviso: CPF repetido não foi protegido no paciente', l.id); }
  }
  return n;
}

async function protegerExistentes({ reescrever = false } = {}) {
  const cpfs = await protegerCpf(reescrever);
  if (!cripto.ativa()) return { prontuarios: 0, fotos: 0, cpfs, aviso: 'sem chave' };
  let pr = 0, fo = 0;
  pr += await tabela('prontuarios', cripto.CAMPOS_TEXTO, cripto.CAMPOS_JSON, reescrever);
  pr += await tabela('receitas', cripto.REC_TEXTO, cripto.REC_JSON, reescrever);
  // histórico de correções: o conteúdo está dentro do snapshot
  const v = await pool.query(`SELECT id, snapshot FROM prontuario_versoes WHERE snapshot IS NOT NULL`);
  for (const l of v.rows) {
    const o = l.snapshot; if (!o || typeof o !== 'object') continue;
    let mudou = false;
    for (const c of cripto.CAMPOS_TEXTO) { const x = texto(o[c], reescrever); if (x.mudou) { o[c] = x.valor; mudou = true; } }
    for (const c of cripto.CAMPOS_JSON) {
      if (o[c] === null || o[c] === undefined) continue;
      if (ehString(o[c]) && cripto.jaCifrado(o[c])) { if (reescrever) { o[c] = cripto.cifrar(cripto.decifrar(o[c])); mudou = true; } }
      else { o[c] = cripto.cifrar(JSON.stringify(o[c])); mudou = true; }
    }
    if (mudou) { await pool.query(`UPDATE prontuario_versoes SET snapshot=$1 WHERE id=$2`, [JSON.stringify(o), l.id]); pr++; }
  }
  fo += await tabela('pacientes', ['foto_receita_url', 'foto_armacao_url'], [], reescrever);
  return { prontuarios: pr, fotos: fo, cpfs };
}
module.exports = protegerExistentes;
