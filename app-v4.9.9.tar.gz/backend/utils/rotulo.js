/* Texto da cidade do exame de vista, montado no banco.
   rotulo('u')  -> "Santa Cruz · Exame de vista" (telas do agendador); sem cidade preenchida, só o nome
   cidade('u')  -> "Santa Cruz" (mensagens para o paciente); sem cidade preenchida, o nome */
const rotulo = (a) => `(CASE WHEN COALESCE(${a}.cidade,'')='' OR position(lower(${a}.cidade) in lower(${a}.nome))>0 THEN ${a}.nome ELSE ${a}.cidade || ' · ' || ${a}.nome END)`;
const cidade = (a) => `COALESCE(NULLIF(${a}.cidade,''), ${a}.nome)`;
module.exports = { rotulo, cidade };
