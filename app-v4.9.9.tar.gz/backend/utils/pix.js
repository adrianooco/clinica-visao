/* Pix "copia e cola" (BR Code estático do Banco Central). Sem taxa e sem intermediário:
   o dinheiro cai direto na chave da clínica. */
const TIPOS = ['telefone', 'cpf', 'cnpj', 'email', 'aleatoria'];

function normalizarChave(tipo, bruto) {
  const t = String(bruto || '').trim();
  const d = t.replace(/\D/g, '');
  if (tipo === 'telefone') {
    const n = d.replace(/^55(?=\d{10,11}$)/, '');
    if (!/^\d{10,11}$/.test(n)) return null;
    return '+55' + n;
  }
  if (tipo === 'cpf') return d.length === 11 ? d : null;
  if (tipo === 'cnpj') return d.length === 14 ? d : null;
  if (tipo === 'email') return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(t) && t.length <= 77 ? t.toLowerCase() : null;
  if (tipo === 'aleatoria') return /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(t) ? t.toLowerCase() : null;
  return null;
}

const campo = (id, valor) => id + String(valor.length).padStart(2, '0') + valor;
const limpar = (t, max) => String(t || '').normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^A-Za-z0-9 ]/g, ' ').replace(/\s+/g, ' ').trim().toUpperCase().slice(0, max);

function crc16(texto) {
  let crc = 0xFFFF;
  for (let i = 0; i < texto.length; i++) {
    crc ^= texto.charCodeAt(i) << 8;
    for (let b = 0; b < 8; b++) crc = (crc & 0x8000) ? ((crc << 1) ^ 0x1021) & 0xFFFF : (crc << 1) & 0xFFFF;
  }
  return crc.toString(16).toUpperCase().padStart(4, '0');
}

function gerarPayload({ chave, nome, cidade, valor }) {
  const v = Number(valor);
  if (!chave) throw new Error('Chave Pix não configurada.');
  if (!(v > 0) || v > 99999999) throw new Error('Valor inválido.');
  const conta = campo('00', 'br.gov.bcb.pix') + campo('01', chave);
  const base = campo('00', '01') + campo('01', '11') + campo('26', conta) + campo('52', '0000') + campo('53', '986')
    + campo('54', v.toFixed(2)) + campo('58', 'BR') + campo('59', limpar(nome, 25) || 'CLINICA') + campo('60', limpar(cidade, 15) || 'BRASIL')
    + campo('62', campo('05', '***')) + '6304';
  return base + crc16(base);
}

module.exports = { TIPOS, normalizarChave, gerarPayload, crc16 };
