/* Gera os horários de uma agenda do exame de vista.
   O intervalo entre exames pode vir da própria agenda (inclusive 0, sem intervalo) ou do tipo de atendimento.
   A pausa de almoço (opcional) não gera horários: o primeiro exame depois dela começa na hora em que o almoço termina. */
const horaParaMin = (h) => { const [a, b] = String(h).split(':').map(Number); return a * 60 + b; };

function bufferEfetivo(a) {
  return a.buffer_agenda !== null && a.buffer_agenda !== undefined ? Number(a.buffer_agenda) : Number(a.buffer_tipo || 0);
}

function gerarSlots(a) {
  const dur = Number(a.duracao_efetiva !== undefined && a.duracao_efetiva !== null ? a.duracao_efetiva : a.duracao_min), buf = bufferEfetivo(a);
  const ini = horaParaMin(a.hora_inicio), fim = horaParaMin(a.hora_fim);
  const temAlmoco = a.almoco_inicio && a.almoco_fim;
  const alI = temAlmoco ? horaParaMin(a.almoco_inicio) : null, alF = temAlmoco ? horaParaMin(a.almoco_fim) : null;
  const passo = dur + buf, saida = [];
  for (let m = ini; m + dur <= fim; m += passo) {
    if (temAlmoco && m < alF && m + dur > alI) { m = Math.max(m, alF - passo); continue; }
    saida.push({ min: m, buffer: buf });
  }
  return saida;
}

module.exports = { gerarSlots, bufferEfetivo, horaParaMin };
