/* Backup semanal por e-mail, trancado com senha. Liga sozinho quando o servidor tem:
   SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS, EMAIL_DE, BACKUP_EMAIL_PARA e BACKUP_SENHA (8+ caracteres). */
const pool = require('../db/pool');
const email = require('./email');
const { gerarBackupCompleto, protegerBackup } = require('./backup');

const LIMITE_ANEXO = 20 * 1024 * 1024;
const ativo = () => email.ativo() && !!process.env.BACKUP_EMAIL_PARA && String(process.env.BACKUP_SENHA || '').length >= 8;

async function rodarUmaVez(forcar = false) {
  if (!ativo()) return { feito: false, motivo: 'desligado' };
  const clinicas = (await pool.query(`SELECT id, nome_fantasia FROM clinicas WHERE ativa=TRUE`)).rows;
  let enviados = 0;
  for (const c of clinicas) {
    const u = (await pool.query(`SELECT FLOOR(EXTRACT(EPOCH FROM (LOCALTIMESTAMP - MAX(criado_em))) / 86400) AS dias FROM acessos_log WHERE clinica_id=$1 AND area='backup'`, [c.id])).rows[0];
    if (!forcar && u.dias !== null && Number(u.dias) < 7) continue;
    const cop = protegerBackup(await gerarBackupCompleto(c.id), process.env.BACKUP_SENHA);
    const texto = JSON.stringify(cop);
    const data = new Date().toISOString().slice(0, 10);
    let r;
    if (Buffer.byteLength(texto) > LIMITE_ANEXO) {
      r = await email.enviar({ para: process.env.BACKUP_EMAIL_PARA, assunto: `Backup de ${c.nome_fantasia} grande demais para e-mail`, texto: 'O backup passou de 20 MB e não coube no e-mail. Entre no sistema, abra Master, aba Segurança, e baixe o backup à mão.' });
    } else {
      r = await email.enviar({ para: process.env.BACKUP_EMAIL_PARA, assunto: `Backup semanal de ${c.nome_fantasia} (${data})`, texto: 'Segue o backup trancado com a senha que você definiu no servidor (BACKUP_SENHA). Guarde este e-mail. Sem a senha o arquivo não abre.', anexos: [{ filename: `backup-${data}.json`, content: texto }] });
    }
    if (r.ok) {
      await pool.query(`INSERT INTO acessos_log (clinica_id, usuario_nome, acao, area, caminho) VALUES ($1,'Sistema','AUTO','backup','/backup-automatico')`, [c.id]).catch(() => {});
      enviados++;
    }
  }
  return { feito: true, enviados };
}
function iniciar() {
  if (!ativo()) return;
  setTimeout(() => rodarUmaVez().catch((e) => console.error('Backup automático falhou:', e.message)), 120000).unref();
  setInterval(() => rodarUmaVez().catch((e) => console.error('Backup automático falhou:', e.message)), 6 * 3600000).unref();
  console.log('Backup semanal por e-mail ligado.');
}
module.exports = { iniciar, rodarUmaVez, ativo };
