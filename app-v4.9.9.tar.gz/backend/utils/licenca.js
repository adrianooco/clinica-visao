/* Licença por clínica. A chave é gerada por você (db/gerar-licenca.js) e colada no Master.
   Só vale se o servidor tiver LICENCA_SEGREDO. Para travar de verdade, ligue LICENCA_OBRIGATORIA=true. */
const crypto = require('crypto');

const segredo = () => process.env.LICENCA_SEGREDO || '';
const obrigatoria = () => process.env.LICENCA_OBRIGATORIA === 'true' && !!segredo();
const b64 = (o) => Buffer.from(JSON.stringify(o)).toString('base64url');
const assinar = (corpo) => crypto.createHmac('sha256', segredo()).update(corpo).digest('base64url');

function gerar(slug, ate, plano = 'completo') {
  const corpo = b64({ s: slug, a: ate, p: plano });
  return `CV1.${corpo}.${assinar(corpo)}`;
}
/* devolve { valida, motivo, ate, dias } */
function conferir(chave, slug, agora = new Date()) {
  if (!segredo()) return { valida: true, motivo: 'sem_controle' };
  if (!chave) return { valida: false, motivo: 'sem_chave' };
  const [v, corpo, ass] = String(chave).trim().split('.');
  if (v !== 'CV1' || !corpo || !ass) return { valida: false, motivo: 'formato' };
  const esperado = assinar(corpo);
  const a = Buffer.from(ass), b = Buffer.from(esperado);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return { valida: false, motivo: 'assinatura' };
  let d; try { d = JSON.parse(Buffer.from(corpo, 'base64url').toString('utf8')); } catch (e) { return { valida: false, motivo: 'formato' }; }
  if (d.s !== slug) return { valida: false, motivo: 'outra_clinica' };
  const fim = new Date(d.a + 'T23:59:59');
  const dias = Math.ceil((fim - agora) / 86400000);
  // 7 dias de carência depois do vencimento
  return { valida: dias >= -7, motivo: dias >= 0 ? 'ok' : (dias >= -7 ? 'carencia' : 'vencida'), ate: d.a, dias };
}
module.exports = { gerar, conferir, obrigatoria };
