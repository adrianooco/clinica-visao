/* Envio de e-mail (recuperar senha, aviso de aparelho novo, backup semanal).
   Fica desligado até você colocar no servidor: SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS e EMAIL_DE.
   Serviços simples que servem: Brevo, Resend (SMTP), Gmail com senha de app. */
const nodemailer = require('nodemailer');

let transporte = null;
const TESTE = process.env.SMTP_HOST === 'teste-em-memoria' && process.env.NODE_ENV !== 'production';
const enviados = []; // só usado nos testes

function ativo() {
  return TESTE || !!(process.env.SMTP_HOST && process.env.SMTP_USER && process.env.SMTP_PASS && process.env.EMAIL_DE);
}
function pegar() {
  if (transporte) return transporte;
  transporte = TESTE
    ? nodemailer.createTransport({ jsonTransport: true })
    : nodemailer.createTransport({
        host: process.env.SMTP_HOST,
        port: parseInt(process.env.SMTP_PORT, 10) || 587,
        secure: parseInt(process.env.SMTP_PORT, 10) === 465,
        auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS },
      });
  return transporte;
}
async function enviar({ para, assunto, texto, anexos }) {
  if (!ativo()) return { ok: false, motivo: 'nao_configurado' };
  try {
    const msg = { from: process.env.EMAIL_DE || 'teste@clinica.local', to: para, subject: assunto, text: texto, attachments: anexos };
    await pegar().sendMail(msg);
    if (TESTE) enviados.push({ para, assunto, texto, anexos: (anexos || []).map((a) => a.filename) });
    return { ok: true };
  } catch (e) {
    console.error('Falha ao enviar e-mail:', e.message);
    return { ok: false, motivo: 'falha' };
  }
}
module.exports = { ativo, enviar, enviados };
