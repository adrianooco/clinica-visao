/* Recuperação de emergência: só roda quando o dono do servidor coloca, no painel da Render,
   as variáveis RECUPERAR_EMAIL e RECUPERAR_SENHA. Troca a senha daquele usuário, derruba as
   sessões e libera o bloqueio de tentativas. Depois de entrar, apague as duas variáveis. */
const bcrypt = require('bcryptjs');
const pool = require('../db/pool');
const { validarSenha } = require('./senha');

module.exports = async function recuperarAcesso() {
  const email = String(process.env.RECUPERAR_EMAIL || '').toLowerCase().trim();
  const senha = process.env.RECUPERAR_SENHA;
  if (!email || !senha) return;
  const erroSenha = validarSenha(senha);
  if (erroSenha) { console.error('Recuperação de acesso: ' + erroSenha); return; }
  const r = await pool.query('SELECT id FROM usuarios WHERE email=$1', [email]);
  if (!r.rows.length) {
    const lista = await pool.query(`SELECT email, papel, ativo FROM usuarios ORDER BY criado_em LIMIT 20`);
    console.error('Recuperação de acesso: e-mail não encontrado. Contas existentes: ' + lista.rows.map((u) => `${u.email} (${u.papel}${u.ativo ? '' : ', inativo'})`).join('; '));
    return;
  }
  const hash = await bcrypt.hash(senha, 10);
  await pool.query(`UPDATE usuarios SET senha_hash=$1, ativo=TRUE, sessao_versao = sessao_versao + 1${process.env.RECUPERAR_TOTP === '1' ? ', totp_ativo=FALSE, totp_segredo=NULL' : ''} WHERE id=$2`, [hash, r.rows[0].id]);
  await pool.query('DELETE FROM login_tentativas');
  console.log('Recuperação de acesso: senha trocada para ' + email + '. Entre e apague as variáveis RECUPERAR_EMAIL e RECUPERAR_SENHA na Render.');
};
