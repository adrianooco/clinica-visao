const express = require('express');
const pool = require('../db/pool');
const { exigirLogin } = require('../middleware/auth');

/* Pós-exame: depois do exame de vista, o gestor entra em contato com o paciente para saber se ele ficou satisfeito.
   Quem ficou regular ou insatisfeito vai para a lista de acompanhamento até o gestor resolver. */
const router = express.Router();
router.use(exigirLogin);
router.use((req, res, next) => {
  if (req.usuario.papel !== 'gestor' && req.usuario.papel !== 'admin') return res.status(403).json({ erro: 'Esta área é do gestor de vendas.' });
  next();
});

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const RESULTADOS = ['satisfeito', 'regular', 'insatisfeito', 'sem_resposta'];
const AGORA_BR = `(NOW() AT TIME ZONE 'America/Sao_Paulo')`;

function filtroCidade(req, params, alias) {
  if (!req.usuario.unidadeId) return '';
  params.push(req.usuario.unidadeIds);
  return ` AND ${alias}.unidade_id=ANY($${params.length})`;
}
function diasOk(v, padrao) { const n = parseInt(v, 10); return n >= 1 && n <= 90 ? n : padrao; }

/* o exame precisa ter acontecido (status realizado) e ser da clínica e da cidade do gestor */
async function exameDaClinica(req, id) {
  if (!UUID.test(String(id || ''))) return null;
  const params = [id, req.usuario.clinicaId];
  const f = filtroCidade(req, params, 'a');
  const r = await pool.query(`SELECT a.id, a.paciente_id FROM agendamentos a WHERE a.id=$1 AND a.clinica_id=$2 AND a.status='realizado'${f}`, params);
  return r.rows[0] || null;
}

router.get('/hoje', async (req, res) => {
  const dias = diasOk(req.query.dias, 7);
  const params = [req.usuario.clinicaId, dias];
  const f = filtroCidade(req, params, 'a');
  const r = await pool.query(
    `SELECT a.id AS agendamento_id, to_char(a.data_hora,'YYYY-MM-DD"T"HH24:MI') AS data_hora,
            p.id AS paciente_id, p.nome_completo, p.telefone, COALESCE(p.aceita_promocao, TRUE) AS aceita_contato,
            t.nome AS tipo, un.nome AS cidade,
            c.enviado_em, c.resultado, c.observacao, c.acompanhar, c.resolvido_em, c.resolucao
     FROM agendamentos a
     JOIN pacientes p ON p.id=a.paciente_id
     LEFT JOIN tipos_atendimento t ON t.id=a.tipo_atendimento_id
     LEFT JOIN unidades un ON un.id=a.unidade_id
     LEFT JOIN posexame_contatos c ON c.agendamento_id=a.id
     WHERE a.clinica_id=$1 AND a.status='realizado' AND p.deletado_em IS NULL
       AND a.data_hora >= ${AGORA_BR} - ($2::int * INTERVAL '1 day')${f}
     ORDER BY a.data_hora DESC LIMIT 400`, params);
  const lista = r.rows;
  res.json({
    dias,
    a_contatar: lista.filter((x) => !x.resultado && !x.enviado_em),
    aguardando: lista.filter((x) => !x.resultado && x.enviado_em),
    respondidos: lista.filter((x) => x.resultado),
  });
});

/* regular e insatisfeito que ainda não foram resolvidos, de qualquer data */
router.get('/acompanhar', async (req, res) => {
  const params = [req.usuario.clinicaId];
  const f = filtroCidade(req, params, 'a');
  const r = await pool.query(
    `SELECT a.id AS agendamento_id, to_char(a.data_hora,'YYYY-MM-DD"T"HH24:MI') AS data_hora,
            p.id AS paciente_id, p.nome_completo, p.telefone, t.nome AS tipo, un.nome AS cidade,
            c.resultado, c.observacao, c.enviado_em
     FROM posexame_contatos c
     JOIN agendamentos a ON a.id=c.agendamento_id
     JOIN pacientes p ON p.id=a.paciente_id
     LEFT JOIN tipos_atendimento t ON t.id=a.tipo_atendimento_id
     LEFT JOIN unidades un ON un.id=a.unidade_id
     WHERE c.clinica_id=$1 AND c.acompanhar AND c.resolvido_em IS NULL AND p.deletado_em IS NULL${f}
     ORDER BY CASE c.resultado WHEN 'insatisfeito' THEN 0 ELSE 1 END, a.data_hora DESC LIMIT 200`, params);
  res.json(r.rows);
});

router.get('/resumo', async (req, res) => {
  const dias = diasOk(req.query.dias, 30);
  const params = [req.usuario.clinicaId, dias];
  const f = filtroCidade(req, params, 'a');
  const r = await pool.query(
    `SELECT COUNT(*)::int AS exames,
            COUNT(c.id) FILTER (WHERE c.enviado_em IS NOT NULL OR c.resultado IS NOT NULL)::int AS contatados,
            COUNT(*) FILTER (WHERE c.resultado='satisfeito')::int AS satisfeitos,
            COUNT(*) FILTER (WHERE c.resultado='regular')::int AS regulares,
            COUNT(*) FILTER (WHERE c.resultado='insatisfeito')::int AS insatisfeitos,
            COUNT(*) FILTER (WHERE c.resultado='sem_resposta')::int AS sem_resposta,
            COUNT(*) FILTER (WHERE c.acompanhar AND c.resolvido_em IS NULL)::int AS em_acompanhamento
     FROM agendamentos a LEFT JOIN posexame_contatos c ON c.agendamento_id=a.id
     WHERE a.clinica_id=$1 AND a.status='realizado' AND a.data_hora >= ${AGORA_BR} - ($2::int * INTERVAL '1 day')${f}`, params);
  res.json({ dias, ...r.rows[0] });
});

/* o gestor abriu o WhatsApp para perguntar: marca como enviado */
router.post('/enviado', async (req, res) => {
  const ex = await exameDaClinica(req, req.body.agendamento_id);
  if (!ex) return res.status(404).json({ erro: 'Exame não encontrado.' });
  await pool.query(
    `INSERT INTO posexame_contatos (clinica_id, agendamento_id, paciente_id, enviado_em, enviado_por_nome)
     VALUES ($1,$2,$3,NOW(),$4)
     ON CONFLICT (agendamento_id) DO UPDATE SET enviado_em=COALESCE(posexame_contatos.enviado_em, NOW()), enviado_por_nome=COALESCE(posexame_contatos.enviado_por_nome, $4), atualizado_em=NOW()`,
    [req.usuario.clinicaId, ex.id, ex.paciente_id, req.usuario.nome]);
  res.json({ ok: true });
});

/* resposta do paciente */
router.post('/resultado', async (req, res) => {
  const resultado = String(req.body.resultado || '');
  if (!RESULTADOS.includes(resultado)) return res.status(400).json({ erro: 'Escolha como foi a resposta do paciente.' });
  const ex = await exameDaClinica(req, req.body.agendamento_id);
  if (!ex) return res.status(404).json({ erro: 'Exame não encontrado.' });
  const obs = String(req.body.observacao || '').trim().slice(0, 1000) || null;
  const acompanhar = resultado === 'regular' || resultado === 'insatisfeito';
  await pool.query(
    `INSERT INTO posexame_contatos (clinica_id, agendamento_id, paciente_id, enviado_em, enviado_por_nome, resultado, observacao, acompanhar)
     VALUES ($1,$2,$3,NOW(),$4,$5,$6,$7)
     ON CONFLICT (agendamento_id) DO UPDATE SET resultado=$5, observacao=$6, acompanhar=$7,
       resolvido_em=CASE WHEN $7 THEN NULL ELSE posexame_contatos.resolvido_em END,
       enviado_em=COALESCE(posexame_contatos.enviado_em, NOW()), atualizado_em=NOW()`,
    [req.usuario.clinicaId, ex.id, ex.paciente_id, req.usuario.nome, resultado, obs, acompanhar]);
  res.json({ ok: true });
});

/* o gestor resolveu o problema do paciente que ficou regular ou insatisfeito */
router.patch('/:agendamentoId/resolver', async (req, res) => {
  const ex = await exameDaClinica(req, req.params.agendamentoId);
  if (!ex) return res.status(404).json({ erro: 'Exame não encontrado.' });
  const resolucao = String(req.body.resolucao || '').trim().slice(0, 1000) || null;
  const r = await pool.query(`UPDATE posexame_contatos SET resolvido_em=NOW(), resolucao=$3, atualizado_em=NOW() WHERE agendamento_id=$1 AND clinica_id=$2 AND acompanhar RETURNING id`, [ex.id, req.usuario.clinicaId, resolucao]);
  if (!r.rows.length) return res.status(404).json({ erro: 'Este paciente não está em acompanhamento.' });
  res.json({ ok: true });
});

module.exports = router;
