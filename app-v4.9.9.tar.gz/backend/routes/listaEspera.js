const express = require('express');
const { rotulo, cidade: cidadeSql } = require('../utils/rotulo');
const pool = require('../db/pool');
const { exigirLogin, cidadeEscolhida } = require('../middleware/auth');

const router = express.Router();
router.use(exigirLogin);

const filtro = (req, params) => { if (!req.usuario.unidadeId) return ''; params.push(req.usuario.unidadeIds); return ` AND (l.unidade_id=ANY($${params.length}) OR l.unidade_id IS NULL)`; };

router.get('/', async (req, res) => {
  const params = [req.usuario.clinicaId];
  const f = filtro(req, params);
  const r = await pool.query(
    `SELECT l.id, l.nome, l.telefone, l.observacao, l.unidade_id, ${rotulo('u')} AS cidade, l.criado_em
     FROM lista_espera l LEFT JOIN unidades u ON u.id = l.unidade_id
     WHERE l.clinica_id=$1 AND l.resolvido_em IS NULL${f} ORDER BY l.criado_em`, params);
  res.json(r.rows);
});

router.post('/', async (req, res) => {
  const nome = String(req.body.nome || '').trim().slice(0, 150);
  if (!nome) return res.status(400).json({ erro: 'Informe o nome.' });
  const unidade_id = cidadeEscolhida(req.usuario, req.body.unidade_id);
  if (unidade_id) {
    const u = await pool.query(`SELECT 1 FROM unidades WHERE id=$1 AND clinica_id=$2`, [unidade_id, req.usuario.clinicaId]);
    if (!u.rows.length) return res.status(400).json({ erro: 'Cidade inválida.' });
  }
  const r = await pool.query(
    `INSERT INTO lista_espera (clinica_id, unidade_id, nome, telefone, observacao) VALUES ($1,$2,$3,$4,$5) RETURNING id`,
    [req.usuario.clinicaId, unidade_id, nome, String(req.body.telefone || '').slice(0, 30) || null, String(req.body.observacao || '').slice(0, 300) || null]);
  res.status(201).json({ id: r.rows[0].id });
});

/* some da lista (agendado ou desistiu) */
router.delete('/:id', async (req, res) => {
  const params = [req.params.id, req.usuario.clinicaId];
  let f = '';
  if (req.usuario.unidadeId) { params.push(req.usuario.unidadeIds); f = ` AND (unidade_id=ANY($3) OR unidade_id IS NULL)`; }
  const r = await pool.query(`UPDATE lista_espera SET resolvido_em=NOW() WHERE id=$1 AND clinica_id=$2${f} RETURNING id`, params);
  if (!r.rows.length) return res.status(404).json({ erro: 'Não encontrado.' });
  res.json({ ok: true });
});

module.exports = router;
