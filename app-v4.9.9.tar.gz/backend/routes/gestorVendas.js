const express = require('express');
const pool = require('../db/pool');
const cripto = require('../utils/cripto');
const { exigirLogin } = require('../middleware/auth');

/* Sincronização do OCO (sistema de vendas do gestor). O app guarda tudo no aparelho e funciona sem internet.
   Quando a internet volta, ele junta o que tem com o que está aqui. Cada clínica tem uma única base.
   O servidor só guarda e controla a versão; quem junta os registros é o aparelho. */
const router = express.Router();
router.use(exigirLogin);
router.use((req, res, next) => {
  if (req.usuario.papel !== 'gestor' && req.usuario.papel !== 'admin') return res.status(403).json({ erro: 'Esta área é do gestor de vendas.' });
  next();
});

const COLECOES = ['clientes', 'vendas', 'ordens', 'contas', 'estoque', 'caixaMovimentos', 'fornecedores', 'compras', 'feedbacks', 'precos', 'lentesProntas'];
const MAX_REGISTROS = 200000;
const COPIAS_GUARDADAS = 15;

function validar(dados, tomb) {
  if (!dados || typeof dados !== 'object' || Array.isArray(dados)) return 'Dados inválidos.';
  let total = 0;
  for (const c of COLECOES) {
    const lista = dados[c];
    if (lista === undefined) continue;
    if (!Array.isArray(lista)) return 'Coleção inválida: ' + c;
    total += lista.length;
    for (const r of lista) if (!r || typeof r !== 'object' || Array.isArray(r) || typeof r.id !== 'number') return 'Registro sem número em ' + c;
  }
  if (total > MAX_REGISTROS) return 'Registros demais.';
  if (dados.loja !== undefined && (typeof dados.loja !== 'object' || dados.loja === null || Array.isArray(dados.loja))) return 'Dados da loja inválidos.';
  if (tomb !== undefined && (typeof tomb !== 'object' || tomb === null || Array.isArray(tomb))) return 'Exclusões inválidas.';
  return null;
}

router.get('/dados', async (req, res) => {
  const r = await pool.query(`SELECT versao, dados, atualizado_em, atualizado_por FROM gestor_vendas_dados WHERE clinica_id=$1`, [req.usuario.clinicaId]);
  if (!r.rows.length) return res.json({ versao: 0, dados: null, tomb: {}, clinica_id: req.usuario.clinicaId });
  const linha = r.rows[0];
  let corpo;
  try { corpo = JSON.parse(cripto.decifrar(linha.dados)); } catch (e) { console.error(e); return res.status(500).json({ erro: 'Não consegui abrir os dados guardados.' }); }
  res.json({ clinica_id: req.usuario.clinicaId, versao: linha.versao, dados: corpo.dados || null, tomb: corpo.tomb || {}, atualizado_em: linha.atualizado_em, atualizado_por: linha.atualizado_por });
});

router.put('/dados', async (req, res) => {
  const { base_versao, dados, tomb } = req.body || {};
  if (!Number.isInteger(base_versao) || base_versao < 0) return res.status(400).json({ erro: 'Versão inválida.' });
  const erro = validar(dados, tomb);
  if (erro) return res.status(400).json({ erro });
  const texto = cripto.cifrar(JSON.stringify({ dados, tomb: tomb || {} }));
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const atual = await client.query(`SELECT versao FROM gestor_vendas_dados WHERE clinica_id=$1 FOR UPDATE`, [req.usuario.clinicaId]);
    const versaoAtual = atual.rows.length ? atual.rows[0].versao : 0;
    if (versaoAtual !== base_versao) { await client.query('ROLLBACK'); return res.status(409).json({ erro: 'Outro aparelho enviou dados antes. Vou juntar e tentar de novo.', versao: versaoAtual }); }
    const nova = versaoAtual + 1;
    if (!atual.rows.length) {
      await client.query(`INSERT INTO gestor_vendas_dados (clinica_id, versao, dados, atualizado_em, atualizado_por) VALUES ($1,$2,$3,NOW(),$4)`, [req.usuario.clinicaId, nova, texto, req.usuario.usuarioId]);
    } else {
      await client.query(`UPDATE gestor_vendas_dados SET versao=$2, dados=$3, atualizado_em=NOW(), atualizado_por=$4 WHERE clinica_id=$1`, [req.usuario.clinicaId, nova, texto, req.usuario.usuarioId]);
    }
    await client.query(`INSERT INTO gestor_vendas_copias (clinica_id, versao, dados, criado_em) VALUES ($1,$2,$3,NOW())`, [req.usuario.clinicaId, nova, texto]);
    await client.query(`DELETE FROM gestor_vendas_copias WHERE clinica_id=$1 AND versao <= $2`, [req.usuario.clinicaId, nova - COPIAS_GUARDADAS]);
    await client.query('COMMIT');
    res.json({ versao: nova });
  } catch (e) {
    await client.query('ROLLBACK').catch(() => {});
    console.error(e);
    res.status(500).json({ erro: 'Não consegui guardar os dados.' });
  } finally { client.release(); }
});

module.exports = router;
