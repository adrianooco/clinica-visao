const express = require('express');
const { rotulo, cidade: cidadeSql } = require('../utils/rotulo');
const pool = require('../db/pool');
const { exigirLogin } = require('../middleware/auth');

const router = express.Router();
router.use(exigirLogin);

/* Envios programados: para cada agendamento, as mensagens que devem sair antes e depois do atendimento.
   O sistema monta o texto pronto e mostra o que está na hora de mandar. Quem atende toca em "WhatsApp",
   a conversa abre com a mensagem pronta e o envio fica registrado. Quando o WhatsApp automático estiver
   ligado (n8n), ele usa as mesmas marcações e nada se repete. */
const ETAPAS = {
  confirmacao: { coluna: 'lembrete_confirmacao_enviado', nome: 'Confirmação do agendamento', depoisDoAtendimento: false },
  '24h': { coluna: 'lembrete_24h_enviado', nome: 'Lembrete de 24 horas', depoisDoAtendimento: false },
  '2h': { coluna: 'lembrete_2h_enviado', nome: 'Lembrete de 2 horas', depoisDoAtendimento: false },
  pos_consulta: { coluna: 'lembrete_pos_consulta_enviado', nome: 'Pós atendimento', depoisDoAtendimento: true },
};

/* retorno do óculos vendido: sai alguns dias depois da venda (ou da entrega, se foi informada) */
const ETAPA_OCULOS = { tabela: 'vendas_oculos', coluna: 'pos_enviado', nome: 'Como está o óculos', depoisDoAtendimento: true };

const HORA = 3600 * 1000;
const dd = (iso) => { const [y, m, d] = iso.slice(0, 10).split('-'); return `${d}/${m}/${y}`; };

function fmtTel(t) { const d = String(t || '').replace(/\D/g, ''); return d.length === 11 ? `(${d.slice(0, 2)}) ${d.slice(2, 7)}-${d.slice(7)}` : d; }
function montarMensagem(etapa, a, clinicaNome, contato) {
  const nome = (a.nome_completo || '').trim().split(/\s+/)[0];
  const data = dd(String(a.data_hora)), hora = String(a.data_hora).slice(11, 16);
  const local = a.local_final ? ` Local: ${a.local_final}.` : '';
  const evento = a.unidade_nome ? ` Cidade: ${a.unidade_nome}.` : '';
  switch (etapa) {
    case 'confirmacao':
      return `Olá, ${nome}! Seu exame de vista na ${clinicaNome} está marcado.${evento} Dia ${data} às ${hora}.${local} Responda SIM para confirmar.`;
    case '24h':
      return `Olá, ${nome}! Lembrando que amanhã, dia ${data}, às ${hora}, é o seu exame de vista.${local} Responda SIM para confirmar ou NÃO para cancelar.`;
    case '2h':
      return `Olá, ${nome}! Seu exame de vista é hoje, às ${hora}.${local} Estamos esperando você.`;
    default:
      return `Olá, ${nome}! Obrigado por fazer seu exame de vista na ${clinicaNome}. Se tiver qualquer dúvida sobre sua receita ou seus óculos, é só responder esta mensagem${contato ? ` ou chamar no WhatsApp ${fmtTel(contato)}` : ''}.`;
  }
}

function mensagemOculos(nomeCompleto, clinicaNome, contato, dias) {
  const nome = (nomeCompleto || '').trim().split(/\s+/)[0];
  return `Olá, ${nome}! Aqui é da ${clinicaNome}. Já faz uns ${dias} dias que você está com seus óculos novos. Como está a adaptação? Sente algum incômodo, dor de cabeça, tontura ou algo que precise de ajuste? Responda esta mensagem contando como está. Se precisar, ajustamos sem custo${contato ? ' ou você chama no ' + fmtTel(contato) : ''}.`;
}

async function listarEnvios(clinicaId, unidadeId) {
  const params = [clinicaId];
  let filtro = '';
  const restrito = Array.isArray(unidadeId) && unidadeId.length > 0;
  if (restrito) { params.push(unidadeId); filtro = ' AND a.unidade_id=ANY($2)'; }
  const clin = await pool.query(`SELECT nome_fantasia, local_exame_padrao, whatsapp_numero FROM clinicas WHERE id=$1`, [clinicaId]);
  const clinicaNome = clin.rows[0].nome_fantasia;
  const contato = clin.rows[0].whatsapp_numero;
  const r = await pool.query(
    `SELECT a.id, a.data_hora, a.criado_em, a.status, a.lembrete_confirmacao_enviado, a.lembrete_24h_enviado,
            a.lembrete_2h_enviado, a.lembrete_pos_consulta_enviado,
            COALESCE(NULLIF(a.local,''), un.local, $${params.length + 1}) AS local_final,
            p.nome_completo, p.telefone, ${cidadeSql('un')} AS unidade_nome
     FROM agendamentos a
     JOIN pacientes p ON p.id = a.paciente_id
     LEFT JOIN unidades un ON un.id = a.unidade_id
     WHERE a.clinica_id=$1 AND a.status <> 'cancelado'
       AND a.data_hora BETWEEN NOW() - INTERVAL '30 days' AND NOW() + INTERVAL '90 days'${filtro}
     ORDER BY a.data_hora`,
    [...params, clin.rows[0].local_exame_padrao]
  );

  const clinCfg = await pool.query(`SELECT COALESCE(pos_oculos_dias,20) AS dias FROM clinicas WHERE id=$1`, [clinicaId]);
  const diasPos = Number(clinCfg.rows[0].dias);
  const pv = restrito ? [clinicaId, unidadeId] : [clinicaId];
  const vendas = { rows: [] }; // venda de ótica agora fica só no OCO
  const agora = Date.now();
  const agoraLista = [], programados = [], enviados = [];
  for (const a of r.rows) {
    const consulta = new Date(String(a.data_hora).slice(0, 19) + '-03:00').getTime(); // horário marcado é de Brasília
    for (const [etapa, cfg] of Object.entries(ETAPAS)) {
      const base = {
        agendamento_id: a.id, etapa, etapa_nome: cfg.nome, paciente_nome: a.nome_completo, telefone: a.telefone,
        data_hora: a.data_hora, mensagem: montarMensagem(etapa, a, clinicaNome, contato),
      };
      if (a[cfg.coluna]) { enviados.push(base); continue; }
      if (a.status === 'faltou' && cfg.depoisDoAtendimento) continue;
      if (a.status === 'confirmado' && etapa === 'confirmacao') continue; // já confirmou: não pede confirmação de novo
      let devido;
      if (etapa === 'confirmacao') devido = 0; // sai assim que o agendamento é feito
      else if (etapa === '24h') devido = consulta - 24 * HORA;
      else if (etapa === '2h') devido = consulta - 2 * HORA;
      else devido = consulta + 2 * HORA;
      base.devido_em = devido ? new Date(devido).toISOString() : null;
      if (etapa === '24h' && consulta - agora < 12 * HORA) continue; // agendou em cima da hora: o lembrete de 24 h não faz sentido
      if (etapa === '2h' && consulta - agora < 20 * 60000) continue;
      if (!cfg.depoisDoAtendimento && consulta < agora) continue; // lembrete de algo que já passou não faz sentido
      if (cfg.depoisDoAtendimento && a.status === 'agendado' && consulta > agora) continue;
      (devido <= agora ? agoraLista : programados).push(base);
    }
  }
  for (const v of vendas.rows) {
    const baseData = String(v.base instanceof Date ? v.base.toISOString() : v.base).slice(0, 10);
    const item = {
      venda_id: v.id, agendamento_id: null, etapa: 'pos_oculos', etapa_nome: ETAPA_OCULOS.nome, paciente_nome: v.nome_completo, telefone: v.telefone,
      data_hora: baseData + 'T00:00:00', mensagem: mensagemOculos(v.nome_completo, clinicaNome, contato, diasPos),
    };
    if (v.pos_enviado) { enviados.push(item); continue; }
    const devido = new Date(baseData + 'T12:00:00-03:00').getTime() + diasPos * 24 * HORA;
    item.devido_em = new Date(devido).toISOString();
    (devido <= agora ? agoraLista : programados).push(item);
  }
  programados.sort((x, y) => x.devido_em.localeCompare(y.devido_em));
  enviados.sort((x, y) => String(y.data_hora).localeCompare(String(x.data_hora)));
  return { agora: agoraLista, programados: programados.slice(0, 200), enviados: enviados.slice(0, 100), contato };
}

router.get('/', async (req, res) => {
  res.json(await listarEnvios(req.usuario.clinicaId, req.usuario.unidadeIds));
});

/* registra (ou desfaz) que a mensagem foi enviada */
router.post('/:agendamentoId/marcar', async (req, res) => {
  if (req.body.etapa === 'pos_oculos') {
    if (!/^[0-9a-f-]{36}$/i.test(req.params.agendamentoId)) return res.status(400).json({ erro: 'Venda inválida.' });
    const marcar = req.body.enviado === false ? false : true;
    const prm = [marcar, req.params.agendamentoId, req.usuario.clinicaId];
    let flt = '';
    if (req.usuario.unidadeId) { prm.push(req.usuario.unidadeIds); flt = ' AND unidade_id=ANY($4)'; }
    const rv = await pool.query(`UPDATE vendas_oculos SET pos_enviado=$1::boolean, pos_enviado_em=CASE WHEN $1::boolean THEN NOW() END WHERE id=$2 AND clinica_id=$3${flt} RETURNING id`, prm);
    if (!rv.rows.length) return res.status(404).json({ erro: 'Venda não encontrada.' });
    return res.json({ ok: true });
  }
  const cfg = ETAPAS[req.body.etapa];
  if (!cfg) return res.status(400).json({ erro: 'Etapa inválida.' });
  const params = [req.body.enviado === false ? false : true, req.params.agendamentoId, req.usuario.clinicaId];
  let filtro = '';
  if (req.usuario.unidadeId) { params.push(req.usuario.unidadeIds); filtro = ' AND unidade_id=ANY($4)'; }
  const r = await pool.query(`UPDATE agendamentos SET ${cfg.coluna}=$1 WHERE id=$2 AND clinica_id=$3${filtro} RETURNING id`, params);
  if (!r.rows.length) return res.status(404).json({ erro: 'Agendamento não encontrado.' });
  res.json({ ok: true });
});

router.listarEnvios = listarEnvios;
router.ETAPAS = ETAPAS;
router.ETAPA_OCULOS = ETAPA_OCULOS;
module.exports = router;
