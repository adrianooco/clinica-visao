const express = require('express');
const pool = require('../db/pool');

const { estadoDe, estadosResolvidos, limparExtras, CAMPOS } = require('../utils/ficha');
const cripto = require('../utils/cripto');
const { conferirContato } = require('../utils/validar');
const fotoGrava = (v) => (v ? cripto.cifrar(v) : null);
const router = express.Router();

async function buscarClinicaPorSlug(slug) {
  const r = await pool.query(`SELECT * FROM clinicas WHERE slug=$1 AND ativa=TRUE`, [slug]);
  return r.rows[0] || null;
}

/* resolve a cidade pelo slug (?u=) se vier na URL; sem isso, segue sem cidade (modo clínica única) */
async function buscarUnidade(clinicaId, unidadeSlug) {
  if (!unidadeSlug) return null;
  const r = await pool.query(`SELECT * FROM unidades WHERE clinica_id=$1 AND slug=$2 AND ativa=TRUE`, [clinicaId, unidadeSlug]);
  return r.rows[0] || null;
}

/* Conferir um documento (receita, atestado, declaração) pelo QR Code impresso.
   Mostra só o que prova que o documento existe: clínica, profissional, data e o primeiro nome do paciente.
   Nada de grau, CID ou texto do atestado. */
const consultasVerificacao = new Map();
router.get('/verificar/:codigo', async (req, res) => {
  const agora = Date.now(), t = consultasVerificacao.get(req.ip);
  if (!t || agora - t.inicio > 60000) consultasVerificacao.set(req.ip, { inicio: agora, n: 1 });
  else if (++t.n > 30) return res.status(429).json({ erro: 'Muitas consultas seguidas. Tente de novo em um minuto.' });
  const codigo = String(req.params.codigo || '').toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 16);
  if (codigo.length < 8) return res.status(404).json({ valido: false });
  const r = await pool.query(
    `SELECT r.data_emissao, r.criado_em, (r.atestado_texto IS NOT NULL) AS tem_atestado, (r.declaracao_texto IS NOT NULL) AS tem_declaracao,
            (r.longe IS NOT NULL OR r.perto IS NOT NULL) AS tem_receita,
            c.nome_fantasia, p.nome_completo, u.nome AS prof_nome, u.registro_conselho, u.formacao, u.formacao_tipo, u.formacao_portaria
     FROM receitas r JOIN clinicas c ON c.id = r.clinica_id JOIN pacientes p ON p.id = r.paciente_id
     LEFT JOIN usuarios u ON u.id = r.profissional_id
     WHERE r.codigo_verificacao = $1`, [codigo]);
  if (!r.rows.length) return res.status(404).json({ valido: false });
  const x = r.rows[0];
  const nomes = String(x.nome_completo || '').trim().split(/\s+/);
  const paciente = nomes.length > 1 ? `${nomes[0]} ${nomes[nomes.length - 1][0]}.` : nomes[0];
  const documentos = []; if (x.tem_receita) documentos.push('Receita de óculos'); if (x.tem_atestado) documentos.push('Atestado'); if (x.tem_declaracao) documentos.push('Declaração de comparecimento');
  res.json({
    valido: true, codigo, clinica: x.nome_fantasia, emitido_em: x.data_emissao, registrado_em: x.criado_em, paciente, documentos,
    profissional: x.prof_nome ? { nome: x.prof_nome, registro: x.registro_conselho, formacao: x.formacao, formacao_tipo: x.formacao_tipo, formacao_portaria: x.formacao_portaria } : null,
  });
});
setInterval(() => { const a = Date.now(); for (const [k, t] of consultasVerificacao) if (a - t.inicio > 60000) consultasVerificacao.delete(k); }, 120000).unref();

/* dados públicos pra montar a tela: nome, campos obrigatórios, local do exame,
   e, se a URL trouxer ?u=slug-da-cidade, os dados dessa cidade específica */
router.get('/:slug/config', async (req, res) => {
  const clinica = await buscarClinicaPorSlug(req.params.slug);
  if (!clinica) return res.status(404).json({ erro: 'Clínica não encontrada.' });
  const unidade = await buscarUnidade(clinica.id, req.query.u);
  if (req.query.u && !unidade) return res.status(404).json({ erro: 'Cidade não encontrado ou encerrado.' });
  res.json({
    nomeClinica: unidade ? `${clinica.nome_fantasia} · ${unidade.nome}` : clinica.nome_fantasia,
    localExame: unidade ? (unidade.local || clinica.local_exame_padrao) : clinica.local_exame_padrao,
    camposObrigatorios: clinica.campos_obrigatorios,
    ficha: estadosResolvidos(clinica.campos_obrigatorios),
    linkSite: clinica.link_site,
    unidade: unidade ? { nome: unidade.nome, cidade: unidade.cidade, dataInicio: unidade.data_inicio, dataFim: unidade.data_fim } : null,
  });
});

/* autocadastro do paciente (cadastro-paciente.html) */
router.post('/:slug/pacientes', async (req, res) => {
  const clinica = await buscarClinicaPorSlug(req.params.slug);
  if (!clinica) return res.status(404).json({ erro: 'Clínica não encontrada.' });
  const unidade = await buscarUnidade(clinica.id, req.query.u);
  if (req.query.u && !unidade) return res.status(404).json({ erro: 'Cidade não encontrado ou encerrado.' });
  const { nome_completo, cpf, telefone, cep, endereco, bairro, cidade, foto_receita_url, foto_armacao_url, data_nascimento } = req.body;
  if (!nome_completo) return res.status(400).json({ erro: 'Informe o nome.' });
  const msgContato = conferirContato({ cpf, telefone }); if (msgContato) return res.status(400).json({ erro: msgContato });
  if (cripto.fotoGrande(foto_receita_url) || cripto.fotoGrande(foto_armacao_url)) return res.status(413).json({ erro: 'Foto muito grande. Tire outra com menos qualidade.' });
  if (req.body.aceite_lgpd !== true) return res.status(400).json({ erro: 'É preciso aceitar o aviso de privacidade.' });
  const extras = limparExtras(req.body.dados_extras);
  const valores = { telefone, cpf, cep, endereco, bairro, data_nascimento, foto_receita: foto_receita_url || extras.receita_digitada || (extras.receita_status === 'nao_tem' ? 'nao_tem' : ''), foto_armacao: foto_armacao_url, ...extras };
  for (const [chave, rotulo] of CAMPOS) {
    if (estadoDe(clinica.campos_obrigatorios, chave) === 'obrigatorio' && !valores[chave]) {
      return res.status(400).json({ erro: `${rotulo} é obrigatório.` });
    }
  }
  try {
    const r = await pool.query(
      `INSERT INTO pacientes (clinica_id, unidade_id, nome_completo, cpf, telefone, cep, endereco, bairro, cidade, agendado_por, foto_receita_url, foto_armacao_url, data_nascimento, dados_extras, termo_lgpd_aceito_em, termo_lgpd_versao, cpf_idx)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,'Autocadastro',$10,$11,$12,$13,NOW(),'2026-10-v1',$14) RETURNING id`,
      [clinica.id, unidade ? unidade.id : null, nome_completo, cpf ? cripto.cifrar(cpf) : null, telefone || null, cep || null, endereco || null, bairro || null, cidade || null, fotoGrava(foto_receita_url), fotoGrava(foto_armacao_url), data_nascimento || null, JSON.stringify(extras), cripto.indiceCpf(cpf)]
    );
    res.status(201).json({ ok: true, id: r.rows[0].id });
  } catch (e) {
    if (e.code === '23505') return res.status(409).json({ erro: 'Já existe um cadastro com esse CPF nesta clínica.' });
    console.error(e); res.status(500).json({ erro: 'Erro ao salvar cadastro.' });
  }
});

/* resultado do teste de visão (teste-visao.html) */
router.post('/:slug/testes-visao', async (req, res) => {
  const clinica = await buscarClinicaPorSlug(req.params.slug);
  if (!clinica) return res.status(404).json({ erro: 'Clínica não encontrada.' });
  const unidade = await buscarUnidade(clinica.id, req.query.u);
  if (req.query.u && !unidade) return res.status(404).json({ erro: 'Cidade não encontrado ou encerrado.' });
  const { nome_informado, distancia_cm, menor_linha, equivalente_snellen } = req.body;
  const r = await pool.query(
    `INSERT INTO testes_visao (clinica_id, unidade_id, nome_informado, distancia_cm, menor_linha, equivalente_snellen)
     VALUES ($1,$2,$3,$4,$5,$6) RETURNING id`,
    [clinica.id, unidade ? unidade.id : null, nome_informado || null, distancia_cm || null, menor_linha || null, equivalente_snellen || null]
  );
  res.status(201).json({ ok: true, id: r.rows[0].id });
});

module.exports = router;
