/* Gera a chave de licença de uma clínica.
   Uso:  LICENCA_SEGREDO=seu-segredo node db/gerar-licenca.js identificador-da-clinica 2027-10-10 */
const licenca = require('../utils/licenca');
const [slug, ate] = process.argv.slice(2);
if (!process.env.LICENCA_SEGREDO || !slug || !/^\d{4}-\d{2}-\d{2}$/.test(ate || '')) {
  console.error('Uso: LICENCA_SEGREDO=... node db/gerar-licenca.js identificador AAAA-MM-DD'); process.exit(1);
}
console.log(licenca.gerar(slug, ate));
