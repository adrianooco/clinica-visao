/* Restaura um backup (.json baixado no painel) num banco novo e vazio.
   Uso:  DATABASE_URL=... BACKUP_SENHA=senha CHAVE_CRIPTOGRAFIA=chave node db/restaurar.js backup-2026-10-10.json
   Se o banco estiver vazio, as tabelas são criadas sozinhas.
   Linhas que já existem são mantidas, nada é apagado. */
const fs = require('fs');
const pool = require('./pool');
const migrar = require('./migrar');
const cripto = require('../utils/cripto');
const { abrirBackupProtegido } = require('../utils/backup');

const ORDEM = ['clinicas', 'unidades', 'usuarios', 'tipos_atendimento', 'pacientes', 'agendas', 'agendamentos', 'receitas', 'prontuarios', 'prontuario_versoes', 'testes_visao', 'pagamentos', 'contas_pagar', 'convenios', 'oticas_parceiras', 'acessos_log'];

async function main() {
  const arq = process.argv[2];
  if (!arq) { console.error('Informe o arquivo de backup.'); process.exit(1); }
  let b = JSON.parse(fs.readFileSync(arq, 'utf8'));
  if (b.formato === 'clinica-visao-backup-protegido-1') {
    if (!process.env.BACKUP_SENHA) { console.error('Backup com senha. Rode com BACKUP_SENHA=suasenha na frente.'); process.exit(1); }
    try { b = abrirBackupProtegido(b, process.env.BACKUP_SENHA); } catch (e) { console.error(e.message); process.exit(1); }
  }
  if (!b.tabelas) { console.error('Arquivo antigo (formato 1): não tem todas as tabelas. Use um backup novo.'); process.exit(1); }
  await migrar(); // cria as tabelas se o banco estiver vazio
  // ordem pelas ligações entre tabelas: quem é referenciado entra primeiro
  const fk = (await pool.query(`SELECT c.conrelid::regclass::text AS filho, c.confrelid::regclass::text AS pai FROM pg_constraint c WHERE c.contype='f' AND c.connamespace='public'::regnamespace`)).rows;
  const presentes = Object.keys(b.tabelas);
  const feitos = new Set(), nomes = [];
  const visitar = (n, pilha = []) => {
    if (feitos.has(n) || pilha.includes(n)) return;
    for (const e of fk) if (e.filho === n && e.pai !== n && presentes.includes(e.pai)) visitar(e.pai, [...pilha, n]);
    feitos.add(n); nomes.push(n);
  };
  [...ORDEM.filter((n) => presentes.includes(n)), ...presentes].forEach((n) => visitar(n));
  const c = await pool.connect();
  try {
    await c.query('BEGIN');
    for (const n of nomes) {
      const linhas = b.tabelas[n] || [];
      if (!linhas.length || !/^[a-z_]+$/.test(n)) { console.log(n + ': 0'); continue; }
      // colunas calculadas pelo banco (ex.: periodo_ocupado) não entram na cópia
      // se o servidor novo tem chave, os dados sensíveis voltam embaralhados
      if (n === 'prontuarios') linhas.forEach((l) => { for (const c of cripto.CAMPOS_TEXTO) if (l[c]) l[c] = cripto.cifrar(l[c]); for (const c of cripto.CAMPOS_JSON) if (l[c] != null) l[c] = JSON.parse(cripto.cifrarJson(l[c])); });
      if (n === 'prontuario_versoes') linhas.forEach((l) => { const o = l.snapshot; if (o && typeof o === 'object') { for (const c of cripto.CAMPOS_TEXTO) if (o[c]) o[c] = cripto.cifrar(o[c]); for (const c of cripto.CAMPOS_JSON) if (o[c] != null && typeof o[c] !== 'string') o[c] = cripto.cifrar(JSON.stringify(o[c])); } });
      if (n === 'usuarios') linhas.forEach((l) => { if (l.totp_segredo) l.totp_segredo = cripto.cifrar(l.totp_segredo); });
      if (n === 'receitas') linhas.forEach((l) => { for (const c of cripto.REC_TEXTO) if (l[c]) l[c] = cripto.cifrar(l[c]); for (const c of cripto.REC_JSON) if (l[c] != null) l[c] = JSON.parse(cripto.cifrarJson(l[c])); });
      if (n === 'pacientes') linhas.forEach((l) => { for (const c of ['foto_receita_url', 'foto_armacao_url']) if (l[c]) l[c] = cripto.cifrar(l[c]); l.cpf_idx = cripto.indiceCpf(l.cpf); if (l.cpf) l.cpf = cripto.cifrar(l.cpf); });
      const cols = (await c.query(`SELECT column_name FROM information_schema.columns WHERE table_schema='public' AND table_name=$1 AND is_generated='NEVER' ORDER BY ordinal_position`, [n])).rows.map((x) => '"' + x.column_name + '"').join(', ');
      const r = await c.query(`INSERT INTO ${n} (${cols}) SELECT ${cols} FROM jsonb_populate_recordset(NULL::${n}, $1::jsonb) ON CONFLICT DO NOTHING`, [JSON.stringify(linhas)]);
      console.log(`${n}: ${r.rowCount} de ${linhas.length}`);
    }
    await c.query('COMMIT');
    console.log('Restauração concluída.');
  } catch (e) {
    await c.query('ROLLBACK');
    console.error('Falhou, nada foi gravado:', e.message);
    process.exitCode = 1;
  } finally { c.release(); await pool.end(); }
}
main();
