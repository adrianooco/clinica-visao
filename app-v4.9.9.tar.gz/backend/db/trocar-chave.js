/* Troca a chave de criptografia, sem perder dado.
   1) Gere uma chave nova:  openssl rand -base64 36
   2) No servidor, coloque CHAVE_CRIPTOGRAFIA_ANTIGA = chave atual e CHAVE_CRIPTOGRAFIA = chave nova
   3) O servidor reescreve tudo sozinho ao reiniciar. Para rodar à mão:  node db/trocar-chave.js
   4) Quando o registro disser que terminou, apague CHAVE_CRIPTOGRAFIA_ANTIGA. Faça um backup antes. */
const pool = require('./pool');
const proteger = require('../utils/protegerExistentes');
if (!process.env.CHAVE_CRIPTOGRAFIA || !process.env.CHAVE_CRIPTOGRAFIA_ANTIGA) { console.error('Defina CHAVE_CRIPTOGRAFIA (nova) e CHAVE_CRIPTOGRAFIA_ANTIGA.'); process.exit(1); }
if (process.env.CHAVE_CRIPTOGRAFIA === process.env.CHAVE_CRIPTOGRAFIA_ANTIGA) { console.error('As duas chaves são iguais.'); process.exit(1); }
proteger({ reescrever: true }).then((r) => { console.log('Chave trocada.', r); return pool.end(); }).catch((e) => { console.error('Falhou:', e.message); process.exit(1); });
