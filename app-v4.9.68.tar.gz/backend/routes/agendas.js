const express = require('express');
const { rotulo, cidade: cidadeSql } = require('../utils/rotulo');
const pool = require('../db/pool');
const { exigirLogin, exigirAdmin } = require('../middleware/auth');

const router = express.Router();
router.use(exigirLogin);

const FORMATO_HORA = /^\d{2}:\d{2}(:\d{2})?$/;
const FORMATO_DIA = /^\d{4}-\d{2}-\d{2}$/;
const dois = (n) => String(n).padStart(2, '0');
const minParaHora = (m) => `${dois(Math.floor(m / 60))}:${dois(m % 60)}`;
const { gerarSlots, bufferEfetivo, horaParaMin } = require('../utils/horarios');

/* Horários livres e ocupados das agendas de evento.
   Agendador (atendente) só enxerga a cidade dele. Admin e profissional podem filtrar por ?unidade_id. */
router.get('/horarios', async (req, res) => {
  const { de, ate } = req.query;
  const params = [req.usuario.clinicaId, de || null, ate || null];
  let filtro = '';
  const pedida = req.query.unidade_id ? String(req.query.unidade_id) : null;
  const cidadesFiltro = req.usuario.unidadeId ? (pedida && req.usuario.unidadeIds.includes(pedida) ? [pedida] : req.usuario.unidadeIds) : (pedida ? [pedida] : null);
  if (cidadesFiltro) { params.push(cidadesFiltro); filtro = ` AND a.unidade_id=ANY($4)`; }

  const ags = await pool.query(
    `SELECT a.id, a.unidade_id, a.data, a.hora_inicio, a.hora_fim, a.local, a.tipo_atendimento_id, a.almoco_inicio, a.almoco_fim,
            t.nome AS tipo_nome, t.cor AS tipo_cor, COALESCE(a.duracao_min, t.duracao_min) AS duracao_efetiva, t.buffer_min AS buffer_tipo, a.buffer_min AS buffer_agenda
     FROM agendas a JOIN tipos_atendimento t ON t.id = a.tipo_atendimento_id
     WHERE a.clinica_id=$1 AND a.ativa=TRUE
       AND ($2::date IS NULL OR a.data >= $2) AND ($3::date IS NULL OR a.data <= $3)${filtro}
     ORDER BY a.data, a.hora_inicio`,
    params
  );
  if (!ags.rows.length) return res.json([]);

  const unidades = [...new Set(ags.rows.map((a) => a.unidade_id))];
  const menorData = ags.rows[0].data, maiorData = ags.rows[ags.rows.length - 1].data;
  const ocup = await pool.query(
    `SELECT ag.id, ag.unidade_id, ag.data_hora, ag.status, ag.paciente_id, p.nome_completo AS paciente_nome, p.telefone AS paciente_telefone
     FROM agendamentos ag JOIN pacientes p ON p.id = ag.paciente_id
     WHERE ag.clinica_id=$1 AND ag.status <> 'cancelado' AND ag.unidade_id = ANY($2::uuid[])
       AND ag.data_hora::date BETWEEN $3 AND $4`,
    [req.usuario.clinicaId, unidades, menorData, maiorData]
  );
  const mapa = new Map(ocup.rows.map((o) => [`${o.unidade_id}|${String(o.data_hora).slice(0, 16)}`, o]));

  const saida = [];
  for (const a of ags.rows) {
    for (const sl of gerarSlots(a)) {
      const hora = minParaHora(sl.min);
      const data_hora = `${a.data}T${hora}:00`;
      const o = mapa.get(`${a.unidade_id}|${a.data}T${hora}`);
      saida.push({
        agenda_id: a.id, unidade_id: a.unidade_id, data: a.data, hora, data_hora,
        tipo_atendimento_id: a.tipo_atendimento_id, tipo_nome: a.tipo_nome, tipo_cor: a.tipo_cor, local: a.local, buffer_min: sl.buffer, duracao_min: Number(a.duracao_efetiva),
        agendamento: o ? { id: o.id, status: o.status, paciente_id: o.paciente_id, paciente_nome: o.paciente_nome, telefone: o.paciente_telefone || null } : null,
      });
    }
  }
  res.json(saida);
});

/* lista das agendas criadas (admin e profissional), com contagem de ocupação */
router.get('/', async (req, res) => {
  if (req.usuario.papel === 'atendente') return res.status(403).json({ erro: 'Seu acesso não permite abrir essa parte do sistema.' });
  const r = await pool.query(
    `SELECT a.*, ${rotulo('u')} AS unidade_nome, t.nome AS tipo_nome, t.duracao_min AS duracao_tipo, COALESCE(a.duracao_min, t.duracao_min) AS duracao_efetiva, t.buffer_min AS buffer_tipo, a.buffer_min AS buffer_agenda
     FROM agendas a JOIN unidades u ON u.id = a.unidade_id JOIN tipos_atendimento t ON t.id = a.tipo_atendimento_id
     WHERE a.clinica_id=$1 AND a.ativa=TRUE ORDER BY a.data DESC, a.hora_inicio`,
    [req.usuario.clinicaId]
  );
  res.json(r.rows.map((a) => ({
    ...a,
    buffer_efetivo: bufferEfetivo(a),
    total_horarios: gerarSlots(a).length,
  })));
});

/* Confere os campos que o POST e o PUT têm em comum. Devolve { erro } ou os valores limpos. */
function lerCamposAgenda(b) {
  const bufRaw = b.buffer_min;
  const buf = bufRaw === undefined || bufRaw === null || bufRaw === '' ? null : parseInt(bufRaw, 10);
  if (buf !== null && (isNaN(buf) || buf < 0 || buf > 120)) return { erro: 'Intervalo entre exames inválido.' };
  const durRaw = b.duracao_min;
  const dur = durRaw === undefined || durRaw === null || durRaw === '' ? null : parseInt(durRaw, 10);
  if (dur !== null && (isNaN(dur) || dur < 5 || dur > 180)) return { erro: 'A duração de cada exame precisa ficar entre 5 e 180 minutos.' };
  const alI = b.almoco_inicio || null, alF = b.almoco_fim || null;
  if ((alI && !alF) || (!alI && alF)) return { erro: 'Informe o início e o fim do almoço.' };
  if (alI && (!FORMATO_HORA.test(String(alI)) || !FORMATO_HORA.test(String(alF)) || horaParaMin(alF) <= horaParaMin(alI))) return { erro: 'O fim do almoço precisa ser depois do início.' };
  return { buf, dur, alI, alF };
}

/* Só o admin define a data e os horários do exame de vista. Pode criar vários dias de uma vez (data_fim). */
router.post('/', exigirAdmin, async (req, res) => {
  const { unidade_id, data, data_fim, hora_inicio, hora_fim, tipo_atendimento_id, local } = req.body;
  const campos = lerCamposAgenda(req.body);
  if (campos.erro) return res.status(400).json({ erro: campos.erro });
  const { buf: bufAgenda, dur: durAgenda, alI, alF } = campos;
  if (!unidade_id || !data || !hora_inicio || !hora_fim || !tipo_atendimento_id) {
    return res.status(400).json({ erro: 'Informe a cidade, a data, o horário de início e fim e o tipo de atendimento.' });
  }
  if (!FORMATO_HORA.test(String(hora_inicio)) || !FORMATO_HORA.test(String(hora_fim)) || !FORMATO_DIA.test(String(data)) || (data_fim && !FORMATO_DIA.test(String(data_fim)))) return res.status(400).json({ erro: 'Data ou horário em formato inválido.' });
  if (horaParaMin(hora_fim) <= horaParaMin(hora_inicio)) return res.status(400).json({ erro: 'O horário final precisa ser depois do inicial.' });
  const un = await pool.query(`SELECT id FROM unidades WHERE id=$1 AND clinica_id=$2 AND ativa=TRUE`, [unidade_id, req.usuario.clinicaId]);
  const tp = await pool.query(`SELECT id, duracao_min FROM tipos_atendimento WHERE id=$1 AND clinica_id=$2`, [tipo_atendimento_id, req.usuario.clinicaId]);
  if (!un.rows.length) return res.status(400).json({ erro: 'Cidade inválida.' });
  if (!tp.rows.length) return res.status(400).json({ erro: 'Tipo de atendimento inválido.' });
  if (horaParaMin(hora_fim) - horaParaMin(hora_inicio) < (durAgenda || tp.rows[0].duracao_min)) return res.status(400).json({ erro: 'O intervalo é menor que a duração do atendimento.' });

  const dias = [];
  const ini = new Date(data + 'T12:00:00Z'), fim = new Date((data_fim || data) + 'T12:00:00Z');
  if (fim < ini) return res.status(400).json({ erro: 'A data final precisa ser depois da inicial.' });
  if ((fim - ini) / 86400000 > 60) return res.status(400).json({ erro: 'Crie no máximo 60 dias por vez.' });
  for (let d = new Date(ini); d <= fim; d.setUTCDate(d.getUTCDate() + 1)) dias.push(d.toISOString().slice(0, 10));

  // não deixa abrir duas agendas que se cruzam na mesma cidade e no mesmo dia (os horários apareceriam repetidos)
  const cruzam = await pool.query(
    `SELECT data FROM agendas WHERE clinica_id=$1 AND unidade_id=$2 AND ativa=TRUE AND data = ANY($3::date[])
       AND hora_inicio < $5::time AND hora_fim > $4::time ORDER BY data`,
    [req.usuario.clinicaId, unidade_id, dias, hora_inicio, hora_fim]);
  if (cruzam.rows.length) {
    const lista = cruzam.rows.slice(0, 5).map((x) => String(x.data).split('-').reverse().join('/')).join(', ');
    return res.status(409).json({ erro: `Já existe agenda nessa cidade em horário que se cruza, no dia ${lista}. Apague a anterior ou mude o horário.` });
  }

  const criadas = [];
  for (const dia of dias) {
    const r = await pool.query(
      `INSERT INTO agendas (clinica_id, unidade_id, data, hora_inicio, hora_fim, tipo_atendimento_id, local, buffer_min, almoco_inicio, almoco_fim, duracao_min)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11) RETURNING *`,
      [req.usuario.clinicaId, unidade_id, dia, hora_inicio, hora_fim, tipo_atendimento_id, local || null, bufAgenda, alI, alF, durAgenda]
    );
    criadas.push(r.rows[0]);
  }
  res.status(201).json(criadas);
});

/* Muda uma agenda que já existe (dia, cidade, horário, duração, intervalo, almoço, tipo, local) sem precisar apagar.
   Só vale enquanto não houver paciente marcado nela: senão os horários marcados poderiam sumir. */
router.put('/:id', exigirAdmin, async (req, res) => {
  const a = await pool.query(`SELECT * FROM agendas WHERE id=$1 AND clinica_id=$2 AND ativa=TRUE`, [req.params.id, req.usuario.clinicaId]);
  if (!a.rows.length) return res.status(404).json({ erro: 'Agenda não encontrada.' });
  const ag = a.rows[0];
  const hora_inicio = req.body.hora_inicio || String(ag.hora_inicio).slice(0, 5), hora_fim = req.body.hora_fim || String(ag.hora_fim).slice(0, 5);
  const tipoId = req.body.tipo_atendimento_id || ag.tipo_atendimento_id;
  /* v4.9.63: também dá para mudar o dia e a cidade, sem apagar a agenda */
  const diaAntigo = ag.data instanceof Date ? ag.data.toISOString().slice(0, 10) : String(ag.data).slice(0, 10);
  const novoDia = req.body.data ? String(req.body.data) : diaAntigo;
  if (!FORMATO_DIA.test(novoDia)) return res.status(400).json({ erro: 'Data em formato inválido.' });
  const novaCidade = req.body.unidade_id ? String(req.body.unidade_id) : String(ag.unidade_id);
  if (novaCidade !== String(ag.unidade_id)) {
    const un = await pool.query(`SELECT id FROM unidades WHERE id=$1 AND clinica_id=$2 AND ativa=TRUE`, [novaCidade, req.usuario.clinicaId]);
    if (!un.rows.length) return res.status(400).json({ erro: 'Cidade inválida.' });
  }
  const campos = lerCamposAgenda(req.body);
  if (campos.erro) return res.status(400).json({ erro: campos.erro });
  if (!FORMATO_HORA.test(hora_inicio) || !FORMATO_HORA.test(hora_fim) || horaParaMin(hora_fim) <= horaParaMin(hora_inicio)) return res.status(400).json({ erro: 'O horário final precisa ser depois do inicial.' });
  const tp = await pool.query(`SELECT id, duracao_min FROM tipos_atendimento WHERE id=$1 AND clinica_id=$2`, [tipoId, req.usuario.clinicaId]);
  if (!tp.rows.length) return res.status(400).json({ erro: 'Tipo de atendimento inválido.' });
  if (horaParaMin(hora_fim) - horaParaMin(hora_inicio) < (campos.dur || tp.rows[0].duracao_min)) return res.status(400).json({ erro: 'O intervalo é menor que a duração do atendimento.' });
  const ocup = await pool.query(
    `SELECT COUNT(*)::int AS n FROM agendamentos WHERE clinica_id=$1 AND unidade_id=$2 AND status <> 'cancelado' AND data_hora::date = $3
       AND data_hora::time >= $4 AND data_hora::time < $5`,
    [req.usuario.clinicaId, ag.unidade_id, ag.data, ag.hora_inicio, ag.hora_fim]);
  if (ocup.rows[0].n > 0) return res.status(409).json({ erro: `Essa agenda já tem ${ocup.rows[0].n} paciente(s) marcado(s). Cancele os agendamentos antes de mudar os horários.` });
  const cruza = await pool.query(
    `SELECT 1 FROM agendas WHERE clinica_id=$1 AND unidade_id=$2 AND ativa=TRUE AND data=$3 AND id<>$6 AND hora_inicio < $5::time AND hora_fim > $4::time LIMIT 1`,
    [req.usuario.clinicaId, novaCidade, novoDia, hora_inicio, hora_fim, ag.id]);
  if (cruza.rows.length) return res.status(409).json({ erro: `Já existe outra agenda nessa cidade no dia ${novoDia.split('-').reverse().join('/')} em horário que se cruza.` });
  const r = await pool.query(
    `UPDATE agendas SET hora_inicio=$1, hora_fim=$2, tipo_atendimento_id=$3, local=$4, buffer_min=$5, almoco_inicio=$6, almoco_fim=$7, duracao_min=$8, data=$11, unidade_id=$12 WHERE id=$9 AND clinica_id=$10 RETURNING *`,
    [hora_inicio, hora_fim, tipoId, req.body.local !== undefined ? (req.body.local || null) : ag.local, campos.buf, campos.alI, campos.alF, campos.dur, ag.id, req.usuario.clinicaId, novoDia, novaCidade]);
  res.json(r.rows[0]);
});

router.delete('/:id', exigirAdmin, async (req, res) => {
  const a = await pool.query(`SELECT * FROM agendas WHERE id=$1 AND clinica_id=$2 AND ativa=TRUE`, [req.params.id, req.usuario.clinicaId]);
  if (!a.rows.length) return res.status(404).json({ erro: 'Agenda não encontrada.' });
  const ag = a.rows[0];
  const ocup = await pool.query(
    `SELECT COUNT(*)::int AS n FROM agendamentos WHERE clinica_id=$1 AND unidade_id=$2 AND status <> 'cancelado' AND data_hora::date = $3
       AND data_hora::time >= $4 AND data_hora::time < $5`,
    [req.usuario.clinicaId, ag.unidade_id, ag.data, ag.hora_inicio, ag.hora_fim]
  );
  if (ocup.rows[0].n > 0) return res.status(409).json({ erro: `Essa agenda já tem ${ocup.rows[0].n} paciente(s) marcado(s). Cancele os agendamentos antes de apagar.` });
  await pool.query(`UPDATE agendas SET ativa=FALSE WHERE id=$1 AND clinica_id=$2`, [req.params.id, req.usuario.clinicaId]);
  res.json({ ok: true });
});

module.exports = router;
