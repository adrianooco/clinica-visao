/* ========================= APARÊNCIA (letra, contraste, tema) ========================= */
function lerAparencia(){ try{ return JSON.parse(localStorage.getItem('agend_ap')||'{}'); }catch(e){ return {}; } }
function aplicarAparencia(){
  const a = lerAparencia(), r = document.documentElement;
  if(a.fonte) r.setAttribute('data-fonte', a.fonte); else r.removeAttribute('data-fonte');
  if(a.contraste) r.setAttribute('data-contraste', a.contraste); else r.removeAttribute('data-contraste');
  let tema = a.tema;
  if(!tema && window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches && a.auto) tema = 'escuro';
  if(tema) r.setAttribute('data-tema', tema); else r.removeAttribute('data-tema');
}
function mudarAparencia(chave, valor){
  const a = lerAparencia(); if(valor) a[chave] = valor; else delete a[chave];
  try{ localStorage.setItem('agend_ap', JSON.stringify(a)); }catch(e){}
  aplicarAparencia();
}
function aparenciaHtml(){
  const a = lerAparencia();
  const grupo = (chave, rotulo, ops)=>`<label>${rotulo}</label><div class="ap-linha">${ops.map(([v,t])=>`<button type="button" data-ap="${chave}" data-v="${v}" class="${(a[chave]||'')===v?'on':''}">${t}</button>`).join('')}</div>`;
  return `${grupo('fonte','Tamanho da letra',[['','Normal'],['grande','Grande'],['enorme','Muito grande']])}
    ${grupo('contraste','Contraste',[['','Normal'],['alto','Alto']])}
    ${grupo('tema','Tema',[['','Claro'],['escuro','Escuro']])}`;
}
function ligarAparencia(raiz){
  raiz.querySelectorAll('button[data-ap]').forEach(b=> b.onclick = ()=>{
    mudarAparencia(b.dataset.ap, b.dataset.v);
    raiz.querySelectorAll(`button[data-ap="${b.dataset.ap}"]`).forEach(x=> x.classList.toggle('on', x===b));
  });
}
/* Instalar no celular: Android e computador abrem o aviso do próprio navegador; no iPhone o jeito é pelo botão Compartilhar */
let eventoInstalar = null;
const jaInstalado = ()=> (window.matchMedia && matchMedia('(display-mode: standalone)').matches) || window.navigator.standalone === true;
const ehIphone = ()=> /iphone|ipad|ipod/i.test(navigator.userAgent) || (navigator.platform==='MacIntel' && navigator.maxTouchPoints>1);
function atualizarBotoesInstalar(){
  const mostrar = !jaInstalado();
  document.querySelectorAll('.btn-instalar').forEach(b=> b.style.display = mostrar ? '' : 'none');
  const l = document.getElementById('lkInstalar'); if(l) l.style.display = mostrar ? '' : 'none';
}
async function instalarApp(){
  if(eventoInstalar){
    eventoInstalar.prompt();
    try{ await eventoInstalar.userChoice; }catch(e){}
    eventoInstalar = null; atualizarBotoesInstalar(); return;
  }
  const passos = ehIphone()
    ? ['Abra este endereço no Safari.', 'Toque no botão Compartilhar, o quadrado com a seta para cima.', 'Role e toque em Adicionar à Tela de Início.', 'Toque em Adicionar. O ícone aparece na tela do celular.']
    : ['Abra este endereço no Chrome.', 'Toque nos três pontinhos no canto de cima.', 'Toque em Instalar app ou Adicionar à tela inicial.', 'Confirme. O ícone aparece na tela do celular.'];
  openModal(`<h2>Instalar o app</h2><ol style="padding-left:20px;line-height:1.55;">${passos.map(p=>`<li style="margin:6px 0;">${p}</li>`).join('')}</ol><div class="btn-row"><button class="btn btn-primary" onclick="closeModal()">Entendi</button></div>`);
}
window.addEventListener('beforeinstallprompt', (e)=>{ e.preventDefault(); eventoInstalar = e; atualizarBotoesInstalar(); });
window.addEventListener('appinstalled', ()=>{ eventoInstalar = null; atualizarBotoesInstalar(); toast('App instalado.'); });
aplicarAparencia();
(function(){
  const li = document.getElementById('lkInstalar'); if(li){ li.onclick = (e)=>{ e.preventDefault(); instalarApp(); }; }
  setTimeout(atualizarBotoesInstalar, 0);
})();
(function(){
  const f=document.getElementById('lkFonte'), c=document.getElementById('lkContraste'), t=document.getElementById('lkTema');
  if(f) f.onclick = (e)=>{ e.preventDefault(); const a=lerAparencia(); mudarAparencia('fonte', !a.fonte ? 'grande' : a.fonte==='grande' ? 'enorme' : ''); };
  if(c) c.onclick = (e)=>{ e.preventDefault(); mudarAparencia('contraste', lerAparencia().contraste ? '' : 'alto'); };
  if(t) t.onclick = (e)=>{ e.preventDefault(); mudarAparencia('tema', lerAparencia().tema ? '' : 'escuro'); };
})();
window.addEventListener('load', ()=>{ const s = document.getElementById('splash'); if(s){ setTimeout(()=>{ s.classList.add('some'); setTimeout(()=>s.remove(), 400); }, 500); } });
function atualizarOffline(){ document.body.classList.toggle('offline', !navigator.onLine); }
window.addEventListener('online', atualizarOffline); window.addEventListener('offline', atualizarOffline);
window.addEventListener('load', atualizarOffline);

/* ========================= CONEXÃO COM A API ========================= */
const qs = new URLSearchParams(location.search);
const SERVIDOR_PROPRIO = /^https?:$/.test(location.protocol); // a página veio do próprio servidor (no ar ou em localhost)
let API_BASE = qs.get('api') || (SERVIDOR_PROPRIO ? location.origin : '') || localStorage.getItem('agend_api_base') || '';
let authToken = localStorage.getItem('agend_token') || '';
let usuarioAtual = JSON.parse(localStorage.getItem('agend_usuario') || 'null');

async function api(path, { method = 'GET', body, semAuth = false } = {}) {
  const headers = { 'Content-Type': 'application/json' };
  if (!semAuth && authToken) headers['Authorization'] = 'Bearer ' + authToken;
  let res;
  try {
    res = await fetch(API_BASE + path, { method, headers, body: body ? JSON.stringify(body) : undefined });
  } catch (e) {
    throw new Error('Não consegui falar com o servidor. Confira o endereço da API e sua internet.');
  }
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.erro || 'Erro na requisição (' + res.status + ').');
  return data;
}

/* ===== digital ou rosto (passkey): o celular confere, o servidor só recebe a prova ===== */
const bioSuportada = ()=> !!(window.PublicKeyCredential && navigator.credentials);
function b64uParaBuf(t){ t=t.replace(/-/g,'+').replace(/_/g,'/'); t+='='.repeat((4-t.length%4)%4); const bin=atob(t), u=new Uint8Array(bin.length); for(let i=0;i<bin.length;i++) u[i]=bin.charCodeAt(i); return u.buffer; }
function bufParaB64u(b){ const u=new Uint8Array(b); let t=''; for(let i=0;i<u.length;i++) t+=String.fromCharCode(u[i]); return btoa(t).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,''); }
function opcoesParaNavegador(o){
  o.challenge = b64uParaBuf(o.challenge);
  if(o.user) o.user.id = b64uParaBuf(o.user.id);
  (o.excludeCredentials||[]).forEach(c=>{ c.id = b64uParaBuf(c.id); });
  (o.allowCredentials||[]).forEach(c=>{ c.id = b64uParaBuf(c.id); });
  return o;
}
function credencialParaJson(c){
  const r = c.response;
  const out = { id:c.id, rawId:bufParaB64u(c.rawId), type:c.type, clientExtensionResults:(c.getClientExtensionResults?c.getClientExtensionResults():{}), authenticatorAttachment:c.authenticatorAttachment };
  if(r.attestationObject) out.response = { clientDataJSON:bufParaB64u(r.clientDataJSON), attestationObject:bufParaB64u(r.attestationObject), transports:(r.getTransports?r.getTransports():[]) };
  else out.response = { clientDataJSON:bufParaB64u(r.clientDataJSON), authenticatorData:bufParaB64u(r.authenticatorData), signature:bufParaB64u(r.signature), userHandle:(r.userHandle?bufParaB64u(r.userHandle):undefined) };
  return out;
}
function erroBio(e){
  if(e && (e.name==='NotAllowedError' || e.name==='AbortError')) return 'A confirmação foi cancelada ou demorou demais. Tente de novo.';
  if(e && e.name==='InvalidStateError') return 'Este aparelho já está cadastrado.';
  return e && e.message ? e.message : 'Não consegui usar a digital ou o rosto.';
}
async function pedirBiometria(caminhoOpcoes, corpoOpcoes, caminhoVerificar, extra){
  const o = await api(caminhoOpcoes, { method:'POST', semAuth:true, body:corpoOpcoes||{} });
  const cred = await navigator.credentials.get({ publicKey: opcoesParaNavegador(o.options) });
  return api(caminhoVerificar, { method:'POST', semAuth:true, body:{ ...(extra||{}), estado:o.estado, resposta:credencialParaJson(cred) } });
}
async function cadastrarBiometria(nome){
  const o = await api('/auth/passkey/registrar/opcoes', { method:'POST', body:{} });
  const cred = await navigator.credentials.create({ publicKey: opcoesParaNavegador(o.options) });
  return api('/auth/passkey/registrar/verificar', { method:'POST', body:{ estado:o.estado, resposta:credencialParaJson(cred), nome_aparelho:nome } });
}
function nomeDoAparelho(){
  const ua = navigator.userAgent;
  const so = /Android/.test(ua) ? 'Android' : /iPhone|iPad/.test(ua) ? 'iPhone' : /Windows/.test(ua) ? 'Windows' : /Mac/.test(ua) ? 'Mac' : 'Aparelho';
  const nav = /Edg\//.test(ua) ? 'Edge' : /Chrome\//.test(ua) ? 'Chrome' : /Safari\//.test(ua) ? 'Safari' : /Firefox\//.test(ua) ? 'Firefox' : '';
  return (so+' '+nav).trim();
}

function uid(){ return Date.now().toString(36)+Math.random().toString(36).slice(2,7); }
function minParaHora(min){ const h=Math.floor(min/60)%24, m=min%60; return String(h).padStart(2,'0')+':'+String(m).padStart(2,'0'); }
function horaParaMin(hora){ const [h,m]=hora.split(':').map(Number); return h*60+m; }
function tipoById(id){ return tiposAtendimento.find(t=>t.id===id) || tiposAtendimento[0]; }
function soData(iso){ return iso ? iso.slice(0,10) : ''; }
function soHora(iso){ return iso ? iso.slice(11,16) : ''; }
function fmtData(iso){ if(!iso) return ''; const [y,m,d]=iso.slice(0,10).split('-'); return `${d}/${m}/${y}`; }

function toast(msg){
  const t = document.getElementById('toast');
  t.textContent = msg; t.classList.add('show');
  setTimeout(()=>t.classList.remove('show'), 2600);
}
function erroApi(e){ toast(e.message || 'Algo deu errado.'); console.error(e); }

/* ========================= ESTADO EM MEMÓRIA (carregado da API) ========================= */
let pacientes = [];
let agendamentos = [];
let tiposAtendimento = [];
let receitas = [];
let testesVisaoRecentes = [];
let clinicaAtual = null;

let unidades = []; // cidades/eventos: admin vê todas, atendente restrito vê só a própria
let oticas = [];
let convenios = [];
let profissionais = []; // quem tem papel 'profissional', pra escolher na receita quem assina

let feriadosLocais = [];
async function carregarTudo(){
  const [pac, tipos, cli, unid, prof] = await Promise.all([
    api('/pacientes'),
    api('/tipos-atendimento'),
    api('/clinica'),
    api('/unidades'),
    api('/clinica/profissionais'),
  ]);
  pacientes = pac;
  tiposAtendimento = tipos.length ? tipos : tiposAtendimento;
  clinicaAtual = cli;
  unidades = unid;
  profissionais = prof;
  // agendamentos: carrega uma janela de +-60 dias a partir de hoje, suficiente pro calendário
  const hoje = new Date();
  const de = new Date(hoje); de.setDate(de.getDate()-60);
  const ate = new Date(hoje); ate.setDate(ate.getDate()+90);
  agendamentos = await api(`/agendamentos?de=${de.toISOString().slice(0,10)}&ate=${ate.toISOString().slice(0,10)}`);
  testesVisaoRecentes = [];
  if(usuarioAtual?.papel !== 'atendente' || (usuarioAtual.permissoes||[]).includes('assistente')){
    try{ testesVisaoRecentes = await api('/testes-visao'); }catch(e){ testesVisaoRecentes = []; }
  }
  try{ feriadosLocais = await api('/feriados-locais'); }catch(e){ feriadosLocais = []; }
  try{ oticas = await api('/cadastros/oticas'); }catch(e){ oticas = []; }
  try{ convenios = await api('/cadastros/convenios'); }catch(e){ convenios = []; }
}
function minhaUnidade(){ return usuarioAtual?.unidadeId ? unidades.find(u=>u.id===usuarioAtual.unidadeId) : null; }

/* ========================= LOGIN / CRIAÇÃO DE CONTA ========================= */
const lockScreen = document.getElementById('lockScreen');
const mainApp = document.getElementById('mainApp');
const lockMsg = document.getElementById('lockMsg');
const lockBtn = document.getElementById('lockBtn');
const lockApi = document.getElementById('lockApi');
const lockEmail = document.getElementById('lockEmail');
const lockPass = document.getElementById('lockPass');
const lockToggle = document.getElementById('lockToggle');
const lockTitulo = document.getElementById('lockTitulo');
const lockSub = document.getElementById('lockSub');

lockApi.value = API_BASE;
if(SERVIDOR_PROPRIO && !qs.get('api')) document.getElementById('lockApiBox').style.display = 'none';

let modoCriarConta = false;

const ENTRADAS = {
  atendente:{ titulo:'Entrada do agendador', sub:'Para quem marca os horários dos pacientes.' },
  profissional:{ titulo:'Entrada do profissional', sub:'Para quem faz o exame de vista.' },
  admin:{ titulo:'Entrada do administrador', sub:'Acesso a todas as partes do sistema.' },
};
let entradaEscolhida = 'atendente';
try{ const q = qs.get('entrada'); entradaEscolhida = ENTRADAS[q] ? q : (ENTRADAS[localStorage.getItem('agend_entrada')] ? localStorage.getItem('agend_entrada') : 'atendente'); }catch(e){}
function aplicarEntrada(){
  const l = document.getElementById('lockScreen');
  l.classList.remove('entrada-atendente','entrada-profissional','entrada-admin'); l.classList.add('entrada-'+entradaEscolhida);
  document.querySelectorAll('#lockEntradas button').forEach(b=> b.classList.toggle('ativa', b.dataset.e===entradaEscolhida));
  if(!modoCriarConta){ lockTitulo.textContent = ENTRADAS[entradaEscolhida].titulo; lockSub.textContent = ENTRADAS[entradaEscolhida].sub+' Entre com o e-mail e a senha.'; }
}
document.getElementById('lockEntradas').addEventListener('click', e=>{
  const b = e.target.closest('button[data-e]'); if(!b) return;
  entradaEscolhida = b.dataset.e; try{ localStorage.setItem('agend_entrada', entradaEscolhida); }catch(err){}
  aplicarEntrada();
});

function renderLockExtra(){
  { const b = document.getElementById('lockBio'); if(b) b.style.display = (!modoCriarConta && bioSuportada()) ? '' : 'none'; }
  document.getElementById('lockEntradas').style.display = modoCriarConta ? 'none' : 'flex';
  if(modoCriarConta){
    lockTitulo.textContent = 'Criar minha clínica';
    lockSub.textContent = 'Isso cria a conta da sua clínica e o primeiro usuário administrador.';
    lockBtn.textContent = 'Criar conta';
    lockToggle.textContent = 'Já tenho conta, quero entrar';
    document.getElementById('lockSetupExtra').innerHTML = `
      <label class="req">Nome da clínica</label>
      <input type="text" id="lockNomeClinica" placeholder="Clínica de Visão">
      <label class="req">Identificador único (sem espaços, usado nos links públicos)</label>
      <input type="text" id="lockSlug" placeholder="clinica-de-visao">
      <label class="req">Seu nome</label>
      <input type="text" id="lockNomeAdmin" placeholder="Seu nome completo">`;
  } else {
    aplicarEntrada();
    lockBtn.textContent = 'Entrar';
    lockToggle.textContent = 'Ainda não tenho uma conta, quero criar minha clínica';
    document.getElementById('lockSetupExtra').innerHTML = '';
  }
}
renderLockExtra();
const lockBio = document.getElementById('lockBio');
lockBio.addEventListener('click', async ()=>{
  lockMsg.textContent = '';
  API_BASE = lockApi.value.trim().replace(/\/$/,'');
  if(!API_BASE){ lockMsg.textContent = 'Informe o endereço do servidor (API).'; return; }
  localStorage.setItem('agend_api_base', API_BASE);
  lockBio.disabled = true;
  try{
    const resp = await pedirBiometria('/auth/passkey/entrar/opcoes', {}, '/auth/passkey/entrar/verificar');
    usuarioAtual = resp.usuario; authToken = resp.token;
    localStorage.setItem('agend_token', authToken);
    localStorage.setItem('agend_usuario', JSON.stringify(usuarioAtual));
    await entrarNoApp();
  }catch(e){ lockMsg.textContent = erroBio(e); }
  finally{ lockBio.disabled = false; }
});
lockToggle.addEventListener('click', (e)=>{ e.preventDefault(); modoCriarConta=!modoCriarConta; lockMsg.textContent=''; renderLockExtra(); });

lockBtn.addEventListener('click', async ()=>{
  lockMsg.textContent = '';
  API_BASE = lockApi.value.trim().replace(/\/$/,'');
  if(!API_BASE){ lockMsg.textContent = 'Informe o endereço do servidor (API).'; return; }
  localStorage.setItem('agend_api_base', API_BASE);
  const email = lockEmail.value.trim();
  const senha = lockPass.value;
  if(!email || !senha){ lockMsg.textContent = 'Preencha e-mail e senha.'; return; }

  lockBtn.disabled = true; lockBtn.textContent = 'Aguarde...';
  try{
    let resp;
    if(modoCriarConta){
      const nomeClinica = document.getElementById('lockNomeClinica').value.trim();
      const slug = document.getElementById('lockSlug').value.trim().toLowerCase().replace(/[^a-z0-9-]/g,'-');
      const nomeAdmin = document.getElementById('lockNomeAdmin').value.trim();
      if(!nomeClinica || !slug || !nomeAdmin){ lockMsg.textContent = 'Preencha todos os campos.'; lockBtn.disabled=false; renderLockExtra(); return; }
      resp = await api('/auth/setup', { method:'POST', semAuth:true, body:{ slug, nomeClinica, nomeAdmin, email, senha } });
      usuarioAtual = { nome: nomeAdmin, papel:'admin', clinica: nomeClinica, slug };
    } else {
      resp = await api('/auth/login', { method:'POST', semAuth:true, body:{ email, senha } });
      if(resp.etapa === 'biometria'){
        lockMsg.textContent = 'Senha certa. Agora confirme com a sua digital ou o seu rosto.';
        try{ resp = await pedirBiometria('/auth/passkey/segundo/opcoes', { pendente:resp.pendente }, '/auth/passkey/segundo/verificar', { pendente:resp.pendente }); }
        catch(e2){ throw new Error(erroBio(e2)); }
      }
      if(resp.etapa === 'totp'){
        lockMsg.textContent = 'Senha certa. Agora digite o código do aplicativo no celular.';
        const cod = await pedirCodigoCelular();
        resp = await api('/auth/totp/entrar', { method:'POST', semAuth:true, body:{ pendente:resp.pendente, codigo:cod } });
      }
      usuarioAtual = resp.usuario;
    }
    authToken = resp.token;
    localStorage.setItem('agend_token', authToken);
    localStorage.setItem('agend_usuario', JSON.stringify(usuarioAtual));
    await entrarNoApp();
  }catch(e){
    lockMsg.textContent = e.message;
  }finally{
    lockBtn.disabled = false; renderLockExtra();
  }
});

/* ---------- código de 6 números do celular e recuperar senha ---------- */
function pedirCodigoCelular(){
  return new Promise((resolve, reject)=>{
    openModal(`<h2>Código do celular</h2><p class="sub">Abra o aplicativo de códigos (Google Authenticator, Microsoft Authenticator ou parecido) e digite os 6 números.</p>
      <input type="text" id="tpCod" inputmode="numeric" maxlength="7" autocomplete="one-time-code" style="font-size:24px;text-align:center;letter-spacing:6px;">
      <div class="btn-row"><button class="btn btn-primary" id="tpOk">Entrar</button><button class="btn btn-outline" id="tpNo">Cancelar</button></div>`);
    const cx = document.getElementById('tpCod'); setTimeout(()=>cx.focus(), 100);
    let feito = false;
    const ok = ()=>{ const v = cx.value.replace(/\D/g,''); if(v.length!==6){ cx.style.borderColor='#C1462F'; return; } feito = true; closeModal(); resolve(v); };
    document.getElementById('tpOk').onclick = ok;
    cx.onkeydown = (e)=>{ if(e.key==='Enter') ok(); };
    document.getElementById('tpNo').onclick = ()=>{ feito = true; closeModal(); reject(new Error('Entrada cancelada.')); };
  });
}
(function(){
  const l = document.getElementById('lockEsqueci'); if(!l) return;
  l.onclick = (e)=>{
    e.preventDefault();
    openModal(`<h2>Esqueci minha senha</h2><p class="sub">Digite o e-mail do seu acesso. Enviamos um link para escolher uma senha nova. O link vale 30 minutos.</p>
      <input type="email" id="esqEmail" value="${esc(document.getElementById('lockEmail')?.value||'')}" placeholder="seu@email.com">
      <p id="esqMsg" class="sub"></p>
      <div class="btn-row"><button class="btn btn-primary" id="esqEnviar">Enviar link</button><button class="btn btn-outline" onclick="closeModal()">Fechar</button></div>`);
    document.getElementById('esqEnviar').onclick = async ()=>{
      const m = document.getElementById('esqMsg');
      try{ const r = await api('/auth/esqueci', { method:'POST', semAuth:true, body:{ email: document.getElementById('esqEmail').value } }); m.style.color=''; m.textContent = r.mensagem; }
      catch(err){ m.style.color='#C1462F'; m.textContent = err.message; }
    };
  };
})();
function abrirRedefinicao(token){
  openModal(`<h2>Senha nova</h2><p class="sub">Escolha uma senha com pelo menos 10 caracteres, com letras e números.</p>
    <label>Senha nova</label><input type="password" id="rdSenha" autocomplete="new-password">
    <label>Repita a senha</label><input type="password" id="rdSenha2" autocomplete="new-password">
    <p id="rdMsg" class="sub"></p>
    <div class="btn-row"><button class="btn btn-primary" id="rdOk">Salvar senha</button></div>`);
  document.getElementById('rdOk').onclick = async ()=>{
    const a = document.getElementById('rdSenha').value, b = document.getElementById('rdSenha2').value, m = document.getElementById('rdMsg');
    if(a!==b){ m.style.color='#C1462F'; m.textContent='As duas senhas não são iguais.'; return; }
    try{ await api('/auth/redefinir', { method:'POST', semAuth:true, body:{ token, senha:a } }); history.replaceState(null,'',location.pathname+location.search); closeModal(); toast('Senha trocada. Agora entre com a senha nova.'); }
    catch(err){ m.style.color='#C1462F'; m.textContent = err.message; }
  };
}
window.addEventListener('load', ()=>{ const m = /#reset=([a-f0-9]{20,})/.exec(location.hash); if(m) setTimeout(()=>abrirRedefinicao(m[1]), 700); });

async function entrarNoApp(){
  try{
    await carregarTudo();
  }catch(e){
    lockMsg.textContent = e.message;
    return;
  }
  lockScreen.style.display = 'none';
  mainApp.style.display = 'flex';
  if(usuarioAtual?.papel === 'admin'){
    api('/clinica/backup-status').then(st=>{
      if(st.dias===null || st.dias>=7) toast(st.dias===null ? 'Você ainda não fez backup dos dados. Vá em Master e baixe um.' : 'Faz '+st.dias+' dias sem backup. Vá em Master e baixe um novo.');
    }).catch(()=>{});
  }
  document.getElementById('hdrNome').textContent = clinicaAtual?.nome_fantasia || 'Agenda de Exame de Vista';
  document.getElementById('hdrLocal').textContent = clinicaAtual?.local_exame_padrao || 'Agendando exame de vista';
  // Prontuário é clínico: só quem tem papel profissional ou admin vê essa aba.
  // Quem só agenda (atendente) nunca enxerga o botão, nem consegue abrir a tela.
  const podeVerProntuario = usuarioAtual?.papel === 'profissional' || usuarioAtual?.papel === 'admin' || (usuarioAtual?.permissoes||[]).includes('prontuario');
  document.getElementById('navProntuario').style.display = podeVerProntuario ? '' : 'none';
  // Agendador (atendente) só usa Calendário e Confirmação. O resto fica escondido.
  const agendador = usuarioAtual?.papel === 'atendente';
  document.querySelectorAll('#pillnav button').forEach(b=>{
    if(agendador && !agendadorPodeAbrir(b.dataset.view)) b.style.display = 'none';
  });
  document.getElementById('navFinanceiro').style.display = usuarioAtual?.papel === 'admin' ? '' : 'none';
  /* cada tipo de usuário tem seu visual e seu menu */
  const papelUI = usuarioAtual?.papel || 'admin';
  document.body.classList.remove('modo-admin','modo-profissional','modo-atendente'); document.body.classList.add('modo-'+papelUI);
  if(papelUI==='profissional'){
    document.querySelectorAll('#pillnav button').forEach(b=>{ if(!VIEWS_PROFISSIONAL.includes(b.dataset.view)) b.style.display = 'none'; });
  }
  montarTopoPrancheta();
  try{ if(localStorage.getItem('agend_menu')==='fechado') { mainApp.classList.add('colapsado'); document.getElementById('btnMenu').textContent = '›'; } }catch(e){}
  const btnTopo = document.getElementById('btnMasterAccess');
  btnTopo.textContent = usuarioAtual?.papel === 'admin' ? 'Área Master' : 'Sair';
  gdSeloEm = 0; setTimeout(()=>guardiaoSelo(true), 400);
  if(usuarioAtual?.papel !== 'admin') document.querySelector('#pillnav button[data-view=master]').style.display = 'none';
  let primeira = false;
  try{ const k='agend_bv_'+(usuarioAtual?.email||''); if(!localStorage.getItem(k)){ primeira=true; localStorage.setItem(k,'1'); } }catch(e){}
  switchView(primeira ? 'inicio' : (agendador ? 'agenda' : (papelUI==='profissional' ? 'prontuario' : 'painel')));
  baseLegalPrimeira();
  { let tent = 0; const quando = setInterval(()=>{ tent++; if(!document.getElementById('modalOverlay').classList.contains('show')){ clearInterval(quando); ofertarBiometria(); } else if(tent>12) clearInterval(quando); }, 2500); }
}
/* uma vez por aparelho: oferece ativar a digital ou o rosto */
async function ofertarBiometria(){
  if(!bioSuportada() || !usuarioAtual?.email) return;
  const k = 'agend_bio_'+usuarioAtual.email;
  try{ if(localStorage.getItem(k)) return; }catch(e){ return; }
  try{
    const l = await api('/auth/passkeys');
    if(l.length) { localStorage.setItem(k,'1'); return; }
  }catch(e){ return; }
  const adm = usuarioAtual.papel==='admin';
  openModal(`<h2>Entrar com digital ou rosto</h2>
    <p class="sub">${adm ? 'Mais segurança para o Master: depois da senha, o celular pede a sua digital ou o seu rosto.' : 'Entre mais rápido, sem digitar a senha: o celular pede a sua digital ou o seu rosto.'} O sistema não guarda a sua digital nem o seu rosto, só o celular guarda.</p>
    <button class="btn btn-primary btn-block" id="bioSim">Ativar agora</button>
    <button class="btn btn-ghost btn-block" id="bioNao" style="margin-top:8px;">Agora não</button>
    <p id="bioErr" style="color:#C1462F;font-size:12.5px;margin-top:8px;"></p>`);
  document.getElementById('bioNao').onclick = ()=>{ try{ localStorage.setItem(k,'1'); }catch(e){} closeModal(); };
  document.getElementById('bioSim').onclick = async ()=>{
    try{ await cadastrarBiometria(nomeDoAparelho()); try{ localStorage.setItem(k,'1'); }catch(e){} closeModal(); toast('Digital ou rosto ativado neste aparelho.'); }
    catch(e){ document.getElementById('bioErr').textContent = erroBio(e); }
  };
}

/* versão do sistema: aparece no login, no menu, na tela Início e no Master */
let versaoSistema = null;
async function carregarVersao(){
  try{
    const r = await fetch((API_BASE||'')+'/versao', { cache:'no-store' });
    if(!r.ok) return;
    versaoSistema = await r.json();
    document.querySelectorAll('.verApp').forEach(el=>{ el.textContent = 'Versão '+versaoSistema.versao; });
  }catch(e){}
}
carregarVersao();

/* tenta entrar sozinho se já tiver token salvo */
(async function tentarAutoLogin(){
  if(authToken && API_BASE){
    try{ await entrarNoApp(); }
    catch(e){ /* token inválido/expirado: fica na tela de login */ }
  }
})();

document.getElementById('btnMenu').addEventListener('click', ()=>{
  const fechado = mainApp.classList.toggle('colapsado');
  document.getElementById('btnMenu').textContent = fechado ? '›' : '‹';
  try{ localStorage.setItem('agend_menu', fechado ? 'fechado' : 'aberto'); }catch(e){}
});
const VIEWS_AGENDADOR = ['inicio','agenda','fila','espera','confirmacao','envios','relatorio','perfil'];
const VIEWS_PROFISSIONAL = ['inicio','agenda','fila','espera','prontuario','receita','retornos','teste','pacientes','perfil'];
/* barra de cima do modo prancheta (só do agendador) */
function montarTopoPrancheta(){
  const el = document.getElementById('topoPrancheta'); if(!el) return;
  if(usuarioAtual?.papel!=='atendente'){ el.style.display='none'; el.innerHTML=''; return; }
  const un = minhaUnidade();
  el.style.display = 'flex';
  el.innerHTML = `<div class="tp-nome"><b>${esc(clinicaAtual?.nome_fantasia||'Agenda')}</b><small>${esc(usuarioAtual.nome||'')}${un?' · '+esc(un.nome):''}</small></div>
    <button type="button" data-view="inicio">Guia</button><button type="button" data-view="perfil">Perfil</button><button type="button" id="tpSair">Sair</button>`;
  el.querySelectorAll('button[data-view]').forEach(b=> b.onclick = ()=> switchView(b.dataset.view));
  document.getElementById('tpSair').onclick = sair;
}
/* telas extras que o administrador libera para cada agendador (tela de Acessos no Master) */
const ACESSOS_EXTRAS = [
  { chave:'calendario', nome:'Calendário', views:['calendario'] },
  { chave:'pacientes', nome:'Pacientes (ficha completa)', views:['pacientes'] },
  { chave:'assistente', nome:'Assistente e Teste na tela', views:['assistente','teste'] },
  { chave:'receita', nome:'Receita, atestado e declaração', views:['receita'] },
  { chave:'prontuario', nome:'Prontuário', views:['prontuario'] },
  { chave:'retornos', nome:'Retornos e aniversariantes', views:['retornos'] },
];
function agendadorPodeAbrir(view){
  if(VIEWS_AGENDADOR.includes(view)) return true;
  const perm = usuarioAtual?.permissoes || [];
  return ACESSOS_EXTRAS.some(a=> perm.includes(a.chave) && a.views.includes(view));
}
document.getElementById('btnMasterAccess').addEventListener('click', ()=>{
  if(usuarioAtual?.papel !== 'admin'){ sair(); return; }
  switchView('master');
});

function sair(){
  authToken=''; usuarioAtual=null;
  localStorage.removeItem('agend_token'); localStorage.removeItem('agend_usuario');
  location.reload();
}

/* ========================= NAVEGAÇÃO ========================= */
const pillnav = document.getElementById('pillnav');
pillnav.addEventListener('click', (e)=>{
  const btn = e.target.closest('button[data-view]');
  if(!btn) return;
  switchView(btn.dataset.view);
});
function switchView(view){
  if(usuarioAtual?.papel === 'atendente' && !agendadorPodeAbrir(view)) view = 'agenda';
  if(usuarioAtual?.papel === 'profissional' && !VIEWS_PROFISSIONAL.includes(view)) view = 'prontuario';
  if((view === 'financeiro' || view === 'master') && usuarioAtual?.papel !== 'admin') view = usuarioAtual?.papel === 'atendente' ? 'agenda' : 'painel';
  [...pillnav.children].forEach(b=> b.classList.toggle('active', b.dataset.view===view));
  guardiaoSelo();
  renderView(view);
  if(view==='inicio' || view==='painel') guardiaoAvisoInicio();
}
function renderView(view){
  pararVozExame();
  const main = document.getElementById('main');
  main.innerHTML = '';
  if(view==='inicio') renderInicio(main);
  else if(view==='agenda') renderAgendaEvento(main);
  else if(view==='calendario') renderCalendario(main);
  else if(view==='pacientes') renderPacientes(main);
  else if(view==='assistente') renderAssistente(main);
  else if(view==='receita') renderReceita(main);
  else if(view==='prontuario') renderProntuario(main);
  else if(view==='fila') renderFila(main);
  else if(view==='espera') renderEspera(main);
  else if(view==='confirmacao') renderConfirmacao(main);
  else if(view==='envios') renderEnvios(main);
  else if(view==='relatorio') renderRelatorioDia(main);
  else if(view==='retornos') renderRetornos(main);
  else if(view==='painel') renderPainel(main);
  else if(view==='financeiro') renderFinanceiro(main);
  else if(view==='teste') renderTesteTela(main);
  else if(view==='perfil') renderPerfil(main);
  else if(view==='master') renderMaster(main);
}
function openModal(html){
  document.getElementById('modalBody').innerHTML = html;
  document.getElementById('modalOverlay').classList.add('show');
}
function closeModal(){ document.getElementById('modalOverlay').classList.remove('show'); }
document.getElementById('modalOverlay').addEventListener('click',(e)=>{ if(e.target.id==='modalOverlay') closeModal(); });

function pacienteNome(id){ const p = pacientes.find(p=>p.id===id); return p? p.nome_completo : '(paciente removido)'; }

/* ---- validações compartilhadas: CPF, telefone, CEP ---- */
function cpfValido(cpfRaw){
  const cpf = cpfRaw.replace(/\D/g,'');
  if(cpf.length!==11) return false;
  if(/^(\d)\1{10}$/.test(cpf)) return false;
  let soma=0, resto;
  for(let i=1;i<=9;i++) soma += parseInt(cpf.substring(i-1,i)) * (11-i);
  resto = (soma*10) % 11; if(resto===10||resto===11) resto=0;
  if(resto !== parseInt(cpf.substring(9,10))) return false;
  soma=0;
  for(let i=1;i<=10;i++) soma += parseInt(cpf.substring(i-1,i)) * (12-i);
  resto = (soma*10) % 11; if(resto===10||resto===11) resto=0;
  if(resto !== parseInt(cpf.substring(10,11))) return false;
  return true;
}
function maskCpf(v){ v=v.replace(/\D/g,'').slice(0,11); return v.replace(/(\d{3})(\d)/,'$1.$2').replace(/(\d{3})(\d)/,'$1.$2').replace(/(\d{3})(\d{1,2})$/,'$1-$2'); }
function maskTelefone(v){
  v=v.replace(/\D/g,'').slice(0,11);
  if(v.length>10) v=v.replace(/(\d{2})(\d{5})(\d{0,4})/,'($1) $2-$3');
  else if(v.length>5) v=v.replace(/(\d{2})(\d{4})(\d{0,4})/,'($1) $2-$3');
  else if(v.length>2) v=v.replace(/(\d{2})(\d{0,5})/,'($1) $2');
  else if(v.length>0) v=v.replace(/(\d{0,2})/,'($1');
  return v.trim();
}
function maskCep(v){ v=v.replace(/\D/g,'').slice(0,8); if(v.length>5) v=v.replace(/(\d{5})(\d{0,3})/,'$1-$2'); return v; }

/* ========================= FERIADOS ========================= */
/* Feriados nacionais do ano, mais Carnaval e Corpus Christi (ponto facultativo). Feriado estadual e municipal não entram. */
function feriadosDoAno(ano){
  const f = {};
  const iso = (dt)=> `${dt.getFullYear()}-${String(dt.getMonth()+1).padStart(2,'0')}-${String(dt.getDate()).padStart(2,'0')}`;
  const fixo = (m,d,nome,tipo)=>{ f[`${ano}-${String(m).padStart(2,'0')}-${String(d).padStart(2,'0')}`] = {nome, tipo: tipo||'feriado'}; };
  fixo(1,1,'Confraternização Universal'); fixo(4,21,'Tiradentes'); fixo(5,1,'Dia do Trabalho');
  fixo(9,7,'Independência do Brasil'); fixo(10,12,'Nossa Senhora Aparecida'); fixo(11,2,'Finados');
  fixo(11,15,'Proclamação da República'); fixo(11,20,'Consciência Negra'); fixo(12,25,'Natal');
  // Páscoa (algoritmo de Meeus/Jones/Butcher)
  const a=ano%19, b=Math.floor(ano/100), c=ano%100, d=Math.floor(b/4), e=b%4, g=Math.floor((8*b+13)/25);
  const h=(19*a+b-d-g+15)%30, i=Math.floor(c/4), k=c%4, l=(32+2*e+2*i-h-k)%7, mm=Math.floor((a+11*h+22*l)/451);
  const mes=Math.floor((h+l-7*mm+114)/31), dia=((h+l-7*mm+114)%31)+1;
  const pascoa = new Date(ano, mes-1, dia);
  const somar = (n)=>{ const x = new Date(pascoa); x.setDate(x.getDate()+n); return iso(x); };
  f[somar(-48)] = {nome:'Carnaval (segunda)', tipo:'facultativo'};
  f[somar(-47)] = {nome:'Carnaval (terça)', tipo:'facultativo'};
  f[somar(-2)]  = {nome:'Sexta-feira Santa', tipo:'feriado'};
  f[iso(pascoa)] = {nome:'Páscoa', tipo:'feriado'};
  f[somar(60)]  = {nome:'Corpus Christi', tipo:'facultativo'};
  return f;
}
const _cacheFeriados = {};
function feriadoDe(isoData){
  const ano = parseInt(isoData.slice(0,4),10);
  if(!_cacheFeriados[ano]) _cacheFeriados[ano] = feriadosDoAno(ano);
  const nac = _cacheFeriados[ano][isoData];
  if(nac) return nac;
  const loc = feriadosLocais.filter(f=>f.data===isoData);
  if(loc.length) return { nome: loc.map(f=>f.nome+(f.cidade?' ('+f.cidade+')':'')).join(', '), tipo: 'feriado' };
  return null;
}

/* ========================= CALENDÁRIO ========================= */
let calRef = new Date();
const DOW = ['D','S','T','Q','Q','S','S'];
const MESES = ['Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'];

function renderCalendario(main){
  const y = calRef.getFullYear(), m = calRef.getMonth();
  const first = new Date(y,m,1);
  const startDow = first.getDay();
  const daysInMonth = new Date(y,m+1,0).getDate();
  const daysInPrev = new Date(y,m,0).getDate();
  const todayStr = new Date().toISOString().slice(0,10);

  let cells = '';
  const listaFer = [];
  for(let i=0;i<startDow;i++){ const d=daysInPrev-startDow+1+i; cells += `<div class="cal-day muted"><span>${d}</span></div>`; }
  for(let d=1; d<=daysInMonth; d++){
    const iso = `${y}-${String(m+1).padStart(2,'0')}-${String(d).padStart(2,'0')}`;
    const dayAg = agendamentos.filter(a=>soData(a.data_hora)===iso);
    const statuses = [...new Set(dayAg.map(a=>a.status))];
    const dots = statuses.map(s=>`<span class="dot dot-${s}"></span>`).join('');
    const fer = feriadoDe(iso);
    if(fer) listaFer.push(`<div><span class="${fer.tipo==='feriado'?'fer':'fac'}">${d}</span> ${esc(fer.nome)}${fer.tipo==='facultativo'?' (ponto facultativo)':''}</div>`);
    cells += `<div class="cal-day ${iso===todayStr?'today':''} ${fer?fer.tipo:''}" data-date="${iso}" ${fer?`title="${esc(fer.nome)}"`:''}><span>${d}</span><div class="dots">${dots}</div></div>`;
  }
  const totalCells = startDow + daysInMonth;
  const trailing = (7 - (totalCells % 7)) % 7;
  for(let d=1; d<=trailing; d++) cells += `<div class="cal-day muted"><span>${d}</span></div>`;

  main.innerHTML = `
    <div class="card">
      <div class="cal-head">
        <div class="cal-nav"><button id="calPrev">‹</button></div>
        <div class="mlabel">${MESES[m]} ${y}</div>
        <div class="cal-nav"><button id="calNext">›</button></div>
      </div>
      <div class="cal-grid">
        ${DOW.map(d=>`<div class="cal-dow">${d}</div>`).join('')}
        ${cells}
      </div>
      <div class="legend">
        <span><span class="dot dot-agendado"></span> Agendado</span>
        <span><span class="dot dot-confirmado"></span> Confirmado</span>
        <span><span class="dot dot-realizado"></span> Realizado</span>
        <span><span class="dot dot-cancelado"></span> Cancelado</span>
      </div>
      <div class="lista-feriados">${listaFer.length ? '<strong>Feriados do mês</strong>'+listaFer.join('') : '<span class="sub">Sem feriados neste mês.</span>'}<div class="sub" style="margin-top:4px;">Número vermelho: feriado. Número laranja: ponto facultativo. Feriado estadual e municipal não aparecem.</div></div>
    </div>
    <button class="btn btn-primary btn-block" id="btnNovoAg">+ Novo agendamento</button>
  `;
  document.getElementById('calPrev').onclick = ()=>{ calRef.setMonth(calRef.getMonth()-1); renderCalendario(main); };
  document.getElementById('calNext').onclick = ()=>{ calRef.setMonth(calRef.getMonth()+1); renderCalendario(main); };
  document.getElementById('btnNovoAg').onclick = ()=> openAgendamentoForm(todayStr);
  main.querySelectorAll('.cal-day[data-date]').forEach(el=> el.addEventListener('click', ()=> openDiaModal(el.dataset.date)));
}

function openDiaModal(iso){
  const dayAg = agendamentos.filter(a=>soData(a.data_hora)===iso).sort((a,b)=>a.data_hora.localeCompare(b.data_hora));
  const rows = dayAg.length ? dayAg.map(a=>{
    const tipo = tipoById(a.tipo_atendimento_id);
    const hora = soHora(a.data_hora);
    const horaFim = minParaHora(horaParaMin(hora) + (tipo?tipo.duracao_min:0));
    return `
    <div class="list-item">
      <div>
        <div class="name">${hora}–${horaFim} · ${pacienteNome(a.paciente_id)}</div>
        <div class="meta"><span class="pill-tag status-${a.status}">${a.status}</span> ${tipo?tipo.nome:''} · ${a.local||clinicaAtual?.local_exame_padrao||''}</div>
      </div>
      <div style="display:flex;gap:6px;"><button class="btn btn-ghost btn-sm" onclick="editAgendamento('${a.id}')">Editar</button></div>
    </div>`;}).join('') : `<div class="empty"><div class="ic">🗓️</div>Nenhum horário marcado neste dia.</div>`;
  openModal(`
    <h2>${fmtData(iso)}</h2>
    ${(()=>{ const fer = feriadoDe(iso); return fer ? `<p class="sub" style="color:${fer.tipo==='feriado'?'#c0392b':'#b9770e'};font-weight:600;margin:6px 0 0;">${fer.tipo==='feriado'?'Feriado':'Ponto facultativo'}: ${esc(fer.nome)}</p>` : ''; })()}
    <div style="margin:10px 0 16px;">${rows}</div>
    <button class="btn btn-primary btn-block" onclick="closeModal(); openAgendamentoForm('${iso}')">+ Marcar horário neste dia</button>
  `);
}

function openAgendamentoForm(dataIni, editId){
  const editing = editId ? agendamentos.find(a=>a.id===editId) : null;
  const opts = pacientes.map(p=>`<option value="${p.id}" ${editing&&editing.paciente_id===p.id?'selected':''}>${esc(p.nome_completo)}</option>`).join('');
  const tipoAtualId = editing? editing.tipo_atendimento_id : (tiposAtendimento[0] && tiposAtendimento[0].id);
  const tipoOpts = tiposAtendimento.map(t=>`<option value="${t.id}" ${tipoAtualId===t.id?'selected':''}>${esc(t.nome)} · ${t.duracao_min} min</option>`).join('');
  openModal(`
    <h2>${editing?'Editar agendamento':'Novo agendamento'}</h2>
    <label class="req">Paciente</label>
    <select id="fAgPac"><option value="">Selecione...</option>${opts}</select>
    <button type="button" class="link-discreto" id="fAgNovoPacBtn">+ Paciente novo (nome e telefone)</button>
    <div id="fAgNovoPac" style="display:none;margin-top:6px;">
      <label class="req">Nome completo</label>
      <input type="text" id="fAgNovoNome" placeholder="Nome do paciente">
      <label>Telefone (WhatsApp)</label>
      <input type="text" inputmode="tel" id="fAgNovoTel" placeholder="(64) 99999-9999">
    </div>
    <label class="req">Tipo de atendimento</label>
    <select id="fAgTipo">${tipoOpts}</select>
    <div class="row2">
      <div><label class="req">Data</label><input type="date" id="fAgData" value="${editing?soData(editing.data_hora):dataIni}"></div>
      <div><label class="req">Horário</label><input type="time" id="fAgHora" value="${editing?soHora(editing.data_hora):'09:00'}"></div>
    </div>
    <p class="sub" id="fAgPreview" style="margin-top:-6px;"></p>
    <label>Intervalo depois do exame</label>
    <select id="fAgBuf"><option value="">Padrão do tipo</option><option value="0">Sem intervalo</option><option value="5">5 minutos</option><option value="10">10 minutos</option><option value="15">15 minutos</option></select>
    <label>Local do exame</label>
    <input type="text" id="fAgLocal" value="${editing?(editing.local||''):(clinicaAtual?.local_exame_padrao||'')}" placeholder="Endereço / consultório">
    <label class="req">Agendado por</label>
    <input type="text" id="fAgPor" value="${editing?(editing.agendado_por||''):(usuarioAtual?usuarioAtual.nome:'')}" placeholder="Nome de quem marcou">
    <label>Status</label>
    <select id="fAgStatus">
      ${['agendado','confirmado','realizado','cancelado'].map(s=>`<option value="${s}" ${editing&&editing.status===s?'selected':''}>${s}</option>`).join('')}
    </select>
    ${editing?'':oticaSelectHtml('fAgOtica')}
    <label>Observações</label>
    <textarea id="fAgObs">${editing?(editing.observacoes||''):''}</textarea>
    <div class="btn-row">
      <button class="btn btn-primary" id="fAgSalvar">Salvar</button>
      ${editing && usuarioAtual?.papel==='admin' ?'<button class="btn btn-danger" id="fAgExcluir">Excluir</button>':''}
      <button class="btn btn-outline" onclick="closeModal()">Cancelar</button>
    </div>
    <p id="fAgErr" style="color:#C1462F;font-size:12.5px;margin-top:8px;"></p>
  `);

  function atualizarPreview(){
    const tipo = tipoById(document.getElementById('fAgTipo').value);
    const hora = document.getElementById('fAgHora').value;
    if(!hora || !tipo) return;
    const fimMin = horaParaMin(hora) + tipo.duracao_min;
    const bufSel = document.getElementById('fAgBuf').value;
    const buf = bufSel==='' ? tipo.buffer_min : parseInt(bufSel,10);
    document.getElementById('fAgPreview').textContent = buf>0
      ? `${hora} às ${minParaHora(fimMin)} (${tipo.duracao_min} min) · próximo horário liberado às ${minParaHora(fimMin + buf)}, com ${buf} min de intervalo`
      : `${hora} às ${minParaHora(fimMin)} (${tipo.duracao_min} min) · sem intervalo, o próximo horário pode começar às ${minParaHora(fimMin)}`;
  }
  let novoPacAberto = false;
  document.getElementById('fAgNovoPacBtn').onclick = ()=>{
    novoPacAberto = !novoPacAberto;
    document.getElementById('fAgNovoPac').style.display = novoPacAberto ? 'block' : 'none';
    document.getElementById('fAgPac').disabled = novoPacAberto;
    document.getElementById('fAgNovoPacBtn').textContent = novoPacAberto ? 'Escolher paciente já cadastrado' : '+ Paciente novo (nome e telefone)';
  };
  document.getElementById('fAgTipo').addEventListener('change', atualizarPreview);
  document.getElementById('fAgBuf').addEventListener('change', atualizarPreview);
  if(editing && editing.buffer_min!=null && editing.buffer_min!==(tipoById(editing.tipo_atendimento_id)||{}).buffer_min){ document.getElementById('fAgBuf').value = [0,5,10,15].includes(editing.buffer_min) ? String(editing.buffer_min) : ''; }
  document.getElementById('fAgHora').addEventListener('input', atualizarPreview);
  atualizarPreview();

  let pacCriadoAg = null; // evita paciente duplicado quando o salvamento do horário falha e o usuário tenta de novo
  document.getElementById('fAgSalvar').onclick = async (ev)=>{
    const btnSalvar = ev.currentTarget; if(btnSalvar.disabled) return;
    let paciente_id = document.getElementById('fAgPac').value;
    const data = document.getElementById('fAgData').value;
    const hora = document.getElementById('fAgHora').value;
    const tipo_atendimento_id = document.getElementById('fAgTipo').value;
    const status = document.getElementById('fAgStatus').value;
    const errEl = document.getElementById('fAgErr');
    errEl.textContent = '';
    const novoNome = document.getElementById('fAgNovoNome').value.trim();
    if(pacCriadoAg && !paciente_id) paciente_id = pacCriadoAg;
    if(novoPacAberto && novoNome && !pacCriadoAg){
      try{
        const novo = await api('/pacientes', { method:'POST', body:{ nome_completo: novoNome, telefone: document.getElementById('fAgNovoTel').value.trim(), agendado_por: document.getElementById('fAgPor').value } });
        pacientes.push(novo); paciente_id = novo.id; pacCriadoAg = novo.id;
      }catch(e){ errEl.textContent = e.message; return; }
    }
    if(!paciente_id || !data || !hora){ toast('Preencha paciente, data e horário.'); return; }

    const payload = {
      paciente_id, tipo_atendimento_id, data_hora: `${data}T${hora}:00`,
      local: document.getElementById('fAgLocal').value,
      agendado_por: document.getElementById('fAgPor').value,
      status, observacoes: document.getElementById('fAgObs').value,
      otica_parceira_id: (document.getElementById('fAgOtica')||{}).value || null,
      buffer_min: document.getElementById('fAgBuf').value
    };
    btnSalvar.disabled = true;
    try{
      if(editing){ await api(`/agendamentos/${editing.id}`, { method:'PUT', body:payload }); }
      else { await api('/agendamentos', { method:'POST', body:payload }); }
      agendamentos = await api(`/agendamentos?de=${data}&ate=${data}`).then(novos=>{
        // recarrega só o necessário: mantém o resto e substitui o dia alterado
        const outros = agendamentos.filter(a=>soData(a.data_hora)!==data);
        return [...outros, ...novos];
      });
      closeModal(); toast('Agendamento salvo.'); renderView('calendario');
    }catch(e){
      errEl.textContent = e.message; btnSalvar.disabled = false;
    }
  };
  if(editing){
    const bExcA = document.getElementById('fAgExcluir'); if(bExcA) bExcA.onclick = async ()=>{
      if(!confirm('Excluir este agendamento?')) return;
      try{
        await api(`/agendamentos/${editing.id}`, { method:'DELETE' });
        agendamentos = agendamentos.filter(a=>a.id!==editing.id);
        closeModal(); toast('Agendamento excluído.'); renderView('calendario');
      }catch(e){ erroApi(e); }
    };
  }
}
function editAgendamento(id){ closeModal(); openAgendamentoForm(null, id); }

/* ========================= PACIENTES ========================= */
function renderPacientes(main){
  const list = pacientes.length ? pacientes.map(p=>`
    <div class="list-item">
      <div>
        <div class="name">${esc(p.nome_completo)}</div>
        <div class="meta">${esc(p.telefone||'')} ${p.cidade? ' · '+esc(p.cidade) : ''}</div>
      </div>
      <div style="display:flex;gap:6px;"><button class="btn btn-ghost btn-sm" onclick="openPacienteForm('${p.id}')">Editar</button></div>
    </div>`).join('') : `<div class="empty"><div class="ic">👤</div>Nenhum paciente cadastrado ainda.</div>`;

  main.innerHTML = `
    <div class="card">
      <h2>Pacientes</h2>
      <p class="sub">${pacientes.length} cadastrado(s)</p>
      ${list}
    </div>
    <button class="btn btn-primary btn-block" id="btnNovoPac">+ Novo paciente</button>
    <button class="btn btn-outline btn-block" id="btnLinkPublico" style="margin-top:10px;">Copiar link do paciente (teste de visão + cadastro)</button>
    ${renderTestesRecentes()}
  `;
  document.getElementById('btnNovoPac').onclick = ()=> openPacienteForm();
  document.getElementById('btnLinkPublico').onclick = ()=>{
    const minha = minhaUnidade();
    const sufixo = minha ? `&u=${encodeURIComponent(minha.slug)}` : '';
    const url = (clinicaAtual?.link_site || location.href.replace(/modulo-agendamento\.html.*$/, '')) + `cadastro-paciente.html?c=${clinicaAtual.slug}&api=${encodeURIComponent(API_BASE)}${sufixo}`;
    navigator.clipboard && navigator.clipboard.writeText(url).catch(()=>{});
    toast(minha ? `Link copiado (já com a cidade ${minha.cidade||minha.nome}).` : 'Link copiado.');
  };
}
function renderTestesRecentes(){
  if(!testesVisaoRecentes.length) return '';
  const rows = testesVisaoRecentes.slice(0,5).map(t=>`
    <div class="list-item">
      <div>
        <div class="name">${t.nome_informado || 'Teste sem nome'}</div>
        <div class="meta">${t.equivalente_snellen||''} (${t.menor_linha||''}) · ${new Date(t.criado_em).toLocaleDateString('pt-BR')}</div>
      </div>
    </div>`).join('');
  return `<div class="card" style="margin-top:14px;"><h2>Testes de visão recentes</h2><p class="sub">Feitos pelos próprios pacientes antes de agendar</p>${rows}</div>`;
}

/* ficha do paciente: cada campo pode ser oculto, opcional ou obrigatorio (escolha no Master) */
const FICHA_DEF = [
  ['telefone','Telefone / WhatsApp','tel','opcional'],
  ['cpf','CPF','cpf','obrigatorio'],
  ['data_nascimento','Data de nascimento','date','opcional'],
  ['email','E-mail','email','oculto'],
  ['sexo','Sexo','select','oculto',['Feminino','Masculino','Outro','Prefiro não informar']],
  ['profissao','Profissão','text','oculto'],
  ['cep','CEP','cep','obrigatorio'],
  ['endereco','Endereço (rua e número)','text','opcional'],
  ['bairro','Bairro','text','opcional'],
  ['usa_oculos','Já usa óculos ou lentes','select','oculto',['Não','Óculos','Lentes de contato','Óculos e lentes']],
  ['queixa','O que incomoda na visão','textarea','oculto'],
  ['ultimo_exame','Quando fez o último exame de vista','text','oculto'],
  ['doencas','Doenças (diabetes, pressão alta e outras)','text','oculto'],
  ['alergias','Alergias','text','oculto'],
  ['medicamentos','Remédios que usa','text','oculto'],
  ['cirurgia_ocular','Cirurgia nos olhos','text','oculto'],
  ['historico_familiar','Casos na família (glaucoma, catarata)','text','oculto'],
  ['indicacao','Como conheceu a clínica','text','oculto'],
  ['observacoes','Observações','textarea','oculto'],
  ['foto_receita','Foto da última receita','foto','opcional'],
  ['foto_armacao','Foto da armação desejada','foto','opcional'],
];
const FICHA_EXTRAS = ['email','sexo','profissao','usa_oculos','queixa','ultimo_exame','doencas','alergias','medicamentos','cirurgia_ocular','historico_familiar','indicacao','observacoes','receita_status','receita_digitada'];
function fichaEstado(k){
  const d = FICHA_DEF.find(x=>x[0]===k); const v = (clinicaAtual?.campos_obrigatorios||{})[k];
  if(v===true) return 'obrigatorio'; if(v===false) return 'opcional';
  return ['oculto','opcional','obrigatorio'].includes(v) ? v : d[3];
}
function camposObrig(){ const o={}; FICHA_DEF.forEach(d=>{ o[d[0]] = fichaEstado(d[0])==='obrigatorio'; }); return o; }
function campoExtraHtml(k, valor){
  const d = FICHA_DEF.find(x=>x[0]===k); const [,rot,tipo,,ops] = d;
  const id = 'fx_'+k; let inp;
  if(tipo==='select') inp = `<select id="${id}"><option value=""></option>${ops.map(o=>`<option ${o===valor?'selected':''}>${esc(o)}</option>`).join('')}</select>`;
  else if(tipo==='textarea') inp = `<textarea id="${id}" rows="2">${esc(valor||'')}</textarea>`;
  else inp = `<input type="${tipo==='email'?'email':'text'}" id="${id}" value="${esc(valor||'')}">`;
  return `<div data-campo="${k}" style="${fichaEstado(k)==='oculto'?'display:none':''}"><label class="${fichaEstado(k)==='obrigatorio'?'req':''}">${rot}</label>${inp}</div>`;
}
function imprimirFicha(p){
  const ex = p.dados_extras || {};
  const linhas = [['Nome',p.nome_completo],['Telefone',p.telefone],['CPF',p.cpf],['Nascimento',p.data_nascimento?new Date(p.data_nascimento+'T12:00:00').toLocaleDateString('pt-BR'):''],
    ['E-mail',ex.email],['Sexo',ex.sexo],['Profissão',ex.profissao],['CEP',p.cep],['Endereço',[p.endereco,p.bairro,p.cidade].filter(Boolean).join(', ')],
    ['Usa óculos ou lentes',ex.usa_oculos],['O que incomoda',ex.queixa],['Último exame de vista',ex.ultimo_exame],['Cirurgia nos olhos',ex.cirurgia_ocular],['Receita anterior',ex.receita_status==='digitar'?ex.receita_digitada:(ex.receita_status==='nao_tem'?'Não tem ou não lembra':(ex.receita_status==='foto'?'Foto anexada':''))],
    ['Doenças',ex.doencas],['Alergias',ex.alergias],['Remédios',ex.medicamentos],['Casos na família',ex.historico_familiar],['Como conheceu',ex.indicacao],['Observações',ex.observacoes]].filter(l=>l[1]);
  const w = window.open('','_blank'); if(!w){ toast('Libere as janelas do navegador para imprimir.'); return; }
  w.document.write(`<html><head><title>Ficha de ${esc(p.nome_completo)}</title><style>body{font-family:Arial,sans-serif;margin:30px;color:#111}h1{font-size:20px;margin:0 0 4px}h2{font-size:14px;color:#555;font-weight:400;margin:0 0 18px}table{border-collapse:collapse;width:100%}td{border-bottom:1px solid #ddd;padding:8px 6px;font-size:14px;vertical-align:top}td:first-child{width:34%;color:#555}</style></head><body>${clinicaAtual?.logo_url?`<img src="${clinicaAtual.logo_url}" style="max-height:60px;display:block;margin-bottom:8px;">`:''}<h1>Ficha do paciente</h1><h2>${esc(clinicaAtual?.nome_fantasia||'')} · ${new Date().toLocaleDateString('pt-BR')}</h2><table>${linhas.map(l=>`<tr><td>${esc(l[0])}</td><td>${esc(l[1])}</td></tr>`).join('')}</table></body></html>`);
  w.document.close(); w.focus(); setTimeout(()=>w.print(),300);
}

async function lerPorIA(tipo, dataUrl){
  return api('/leitura', { method:'POST', body:{ tipo, imagem:dataUrl } });
}
/* leitura no próprio celular (sem IA), usada quando a leitura por IA não está ligada */
function carregarTesseract(){
  if(window.Tesseract) return Promise.resolve(window.Tesseract);
  return new Promise((ok,err)=>{
    const sc = document.createElement('script'); sc.src = 'https://cdn.jsdelivr.net/npm/tesseract.js@5.1.1/dist/tesseract.min.js';
    sc.onload = ()=> ok(window.Tesseract); sc.onerror = ()=> err(new Error('Sem internet para carregar o leitor.')); document.head.appendChild(sc);
  });
}
async function lerDocumentoLocal(dataUrl){
  const T = await carregarTesseract();
  const r = await T.recognize(dataUrl, 'por');
  const texto = r.data.text || '';
  const achado = { nome_completo:null, cpf:null, data_nascimento:null };
  const cpfs = texto.match(/\d{3}[\.\s]?\d{3}[\.\s]?\d{3}[-\s]?\d{2}/g) || [];
  achado.cpf = cpfs.map(c=>c.replace(/\D/g,'')).find(c=>cpfValido(c)) || null;
  const dt = texto.match(/(\d{2})[\/\.\s-](\d{2})[\/\.\s-](\d{4})/g) || [];
  for(const d of dt){ const [dd,mm,aa] = d.split(/\D+/); if(+aa>1900 && +aa<=new Date().getFullYear() && +mm>=1 && +mm<=12 && +dd>=1 && +dd<=31){ achado.data_nascimento = `${aa}-${mm}-${dd}`; break; } }
  const linhas = texto.split(/\n/).map(l=>l.trim()).filter(Boolean);
  const iNome = linhas.findIndex(l=>/^nome\b/i.test(l));
  if(iNome>=0){ const cand = (linhas[iNome].replace(/^nome[:\s]*/i,'') || linhas[iNome+1] || '').replace(/[^A-Za-zÀ-ÿ\s]/g,'').trim(); if(cand.split(/\s+/).length>=2) achado.nome_completo = cand.toUpperCase(); }
  return achado;
}
const fmtGrau = o=> [o.esf, o.cil, o.eixo?('x'+o.eixo):''].filter(Boolean).join(' ');
function textoReceita(d){
  const partes = [];
  if(fmtGrau(d.od)) partes.push('OD: '+fmtGrau(d.od));
  if(fmtGrau(d.oe)) partes.push('OE: '+fmtGrau(d.oe));
  if(d.adicao) partes.push('Adição '+d.adicao);
  if(d.dp) partes.push('DP '+d.dp);
  return partes.join('  ');
}
async function lerDocumentoPorFoto(url){
  try{ return (await lerPorIA('documento', url)).dados; }
  catch(e){
    if(/não está ligada/i.test(e.message||'')) return lerDocumentoLocal(url);
    throw e;
  }
}

function openPacienteForm(editId){
  const editing = editId ? pacientes.find(p=>p.id===editId) : null;
  const req = camposObrig();
  const ex = (editing && editing.dados_extras) || {};
  const cx = (k, html)=> `<div data-campo="${k}" style="${fichaEstado(k)==='oculto'?'display:none':''}">${html}</div>`;
  openModal(`
    <h2>${editing?'Editar paciente':'Novo paciente'}</h2>
    <div class="foto-atalhos">
      <button type="button" class="btn btn-outline" id="btnFotoDoc">📷 Fotografar documento</button>
      <button type="button" class="btn btn-outline" id="btnFotoRec">📷 Fotografar receita ou óculos</button>
      <input type="file" id="inFotoDoc" accept="image/*" capture="environment" style="display:none">
      <input type="file" id="inFotoRec" accept="image/*" capture="environment" style="display:none">
    </div>
    <p class="sub" id="fotoMsg">Tire a foto do RG, CNH ou CPF e o sistema preenche nome, CPF e nascimento. Confira tudo antes de salvar.</p>
    <label class="req">Nome completo</label>
    <input type="text" id="fPNome" value="${editing?esc(editing.nome_completo):''}">
    ${cx('cpf',`<label class="${req.cpf?'req':''}">CPF</label>
    <input type="text" id="fPCpf" value="${editing?esc(editing.cpf||''):''}" placeholder="000.000.000-00" inputmode="numeric">
    <p class="fieldmsg" id="fPCpfMsg"></p>`)}
    ${cx('data_nascimento',`<label class="${req.data_nascimento?'req':''}">Data de nascimento <span style="font-weight:400;color:var(--ink-soft);">(usada em aniversários e na idade da receita)</span></label>
    <input type="date" id="fPNasc" value="${editing?(editing.data_nascimento||''):''}">`)}
    ${cx('telefone',`<label class="${req.telefone?'req':''}">Telefone / WhatsApp</label>
    <input type="tel" id="fPTel" value="${editing?esc(editing.telefone||''):''}" placeholder="(00) 00000-0000" inputmode="numeric">
    <p class="fieldmsg" id="fPTelMsg"></p>`)}
    ${['email','sexo','profissao'].map(k=>campoExtraHtml(k, ex[k])).join('')}
    ${cx('cep',`<div class="row2">
      <div><label class="${req.cep?'req':''}">CEP</label><input type="text" id="fPCep" value="${editing?(editing.cep||''):''}" placeholder="00000-000" inputmode="numeric"><p class="fieldmsg" id="fPCepMsg"></p></div>
      <div><label>Cidade</label><input type="text" id="fPCidade" value="${editing?esc(editing.cidade||''):''}" readonly></div>
    </div>`)}
    ${cx('endereco',`<label class="${req.endereco?'req':''}">Endereço</label>
    <input type="text" id="fPEndereco" value="${editing?esc(editing.endereco||''):''}">`)}
    ${cx('bairro',`<label class="${req.bairro?'req':''}">Bairro</label>
    <input type="text" id="fPBairro" value="${editing?esc(editing.bairro||''):''}">`)}
    ${['usa_oculos','queixa','ultimo_exame','cirurgia_ocular','doencas','alergias','medicamentos','historico_familiar','indicacao','observacoes'].map(k=>campoExtraHtml(k, ex[k])).join('')}
    <label>Agendado por</label>
    <input type="text" id="fPPor" value="${editing?esc(editing.agendado_por||''):''}">
    ${cx('foto_receita',`<label class="${req.foto_receita?'req':''}">Última receita</label>
    <select id="fx_receita_status"><option value=""></option>${[['foto','Tenho a foto'],['digitar','Vou digitar o grau'],['nao_tem','Não tem ou não lembra']].map(([v,t])=>`<option value="${v}" ${ex.receita_status===v?'selected':''}>${t}</option>`).join('')}</select>
    <div id="blocoReceitaDig" style="display:${ex.receita_status==='digitar'?'block':'none'};"><label>Grau digitado (OD e OE, longe e perto)</label><textarea id="fx_receita_digitada" rows="3" placeholder="OD: -1.00 -0.50 x90  OE: -1.25 -0.25 x80  Adição +1.50">${esc(ex.receita_digitada||'')}</textarea></div>
    <label>Foto da receita (se tiver)</label>
    <input type="file" id="fPFotoReceita" accept="image/*">
    ${editing&&editing.tem_foto_receita?`<p class="sub">Já existe uma foto salva. <a href="#" class="ver-foto" data-q="foto_receita_url">Ver foto</a></p>`:''}`)}
    ${cx('foto_armacao',`<label class="${req.foto_armacao?'req':''}">Foto do modelo de armação</label>
    <input type="file" id="fPFotoArmacao" accept="image/*">
    ${editing&&editing.tem_foto_armacao?`<p class="sub">Já existe uma foto salva. <a href="#" class="ver-foto" data-q="foto_armacao_url">Ver foto</a></p>`:''}`)}
    ${editing?'':`<label style="display:flex;gap:8px;align-items:flex-start;font-weight:400;margin-top:10px;"><input type="checkbox" id="fPLgpd" style="margin-top:4px;"> <span>O paciente leu o aviso de privacidade e concorda com o uso dos dados e com lembretes por WhatsApp.</span></label>`}
    <div class="btn-row">
      <button class="btn btn-primary" id="fPSalvar">Salvar</button>
      ${editing?'<button class="btn btn-outline" id="fPFicha">Imprimir ficha</button>':''}${editing && usuarioAtual?.papel==='admin' ?'<button class="btn btn-danger" id="fPExcluir">Excluir</button>':''}
      <button class="btn btn-outline" onclick="closeModal()">Cancelar</button>
    </div>
    <p id="fPErr" style="color:#C1462F;font-size:12.5px;margin-top:8px;"></p>
  `);

  const stRec = document.getElementById('fx_receita_status'); if(stRec) stRec.onchange = ()=>{ document.getElementById('blocoReceitaDig').style.display = stRec.value==='digitar' ? 'block' : 'none'; };
  const fPCpf = document.getElementById('fPCpf'), fPCpfMsg = document.getElementById('fPCpfMsg');
  fPCpf.addEventListener('input', ()=>{
    fPCpf.value = maskCpf(fPCpf.value);
    const digitos = fPCpf.value.replace(/\D/g,'');
    fPCpf.classList.remove('field-ok','field-bad');
    if(digitos.length < 11){ fPCpfMsg.textContent=''; fPCpfMsg.className='fieldmsg'; return; }
    if(cpfValido(fPCpf.value)){ fPCpfMsg.textContent='CPF válido'; fPCpfMsg.className='fieldmsg ok'; fPCpf.classList.add('field-ok'); }
    else{ fPCpfMsg.textContent='CPF inválido, confira os números'; fPCpfMsg.className='fieldmsg bad'; fPCpf.classList.add('field-bad'); }
  });
  const fPTel = document.getElementById('fPTel'), fPTelMsg = document.getElementById('fPTelMsg');
  fPTel.addEventListener('input', ()=>{
    fPTel.value = maskTelefone(fPTel.value);
    const digitos = fPTel.value.replace(/\D/g,'');
    fPTel.classList.remove('field-ok','field-bad');
    if(digitos.length === 0){ fPTelMsg.textContent=''; fPTelMsg.className='fieldmsg'; return; }
    if(digitos.length===10 || digitos.length===11){ fPTelMsg.textContent='Número válido'; fPTelMsg.className='fieldmsg ok'; fPTel.classList.add('field-ok'); }
    else{ fPTelMsg.textContent='Informe o DDD + número completo'; fPTelMsg.className='fieldmsg bad'; fPTel.classList.add('field-bad'); }
  });
  const fPCep = document.getElementById('fPCep'), fPCepMsg = document.getElementById('fPCepMsg');
  fPCep.addEventListener('input', ()=>{
    fPCep.value = maskCep(fPCep.value);
    fPCep.classList.remove('field-ok','field-bad');
    if(fPCep.value.replace(/\D/g,'').length < 8){ fPCepMsg.textContent=''; fPCepMsg.className='fieldmsg'; }
  });
  fPCep.addEventListener('blur', buscarCep);
  async function buscarCep(){
    const cep = fPCep.value.replace(/\D/g,'');
    if(cep.length!==8){ if(cep.length>0){ fPCepMsg.textContent='CEP incompleto'; fPCepMsg.className='fieldmsg bad'; fPCep.classList.add('field-bad'); } return; }
    fPCepMsg.textContent = 'Buscando endereço...'; fPCepMsg.className='fieldmsg';
    try{
      const r = await fetch(`https://viacep.com.br/ws/${cep}/json/`);
      const d = await r.json();
      if(!d.erro){
        document.getElementById('fPCidade').value = d.localidade + '/' + d.uf;
        document.getElementById('fPBairro').value = d.bairro || '';
        document.getElementById('fPEndereco').value = d.logradouro || document.getElementById('fPEndereco').value;
        fPCepMsg.textContent = 'Endereço encontrado'; fPCepMsg.className='fieldmsg ok'; fPCep.classList.add('field-ok');
      } else { fPCepMsg.textContent = 'CEP não encontrado, confira os números'; fPCepMsg.className='fieldmsg bad'; fPCep.classList.add('field-bad'); }
    }catch(e){ fPCepMsg.textContent = 'Sem internet para buscar o endereço agora.'; fPCepMsg.className='fieldmsg bad'; }
  }

  function readFile(input){
    return new Promise(res=>{
      const f = input.files[0];
      if(!f){ res(null); return; }
      // a foto é reduzida antes de enviar (mais leve para o celular e para o banco)
      reduzirImagem(f, 1280, 0.7).then(res).catch(()=>{ const r = new FileReader(); r.onload = ()=> res(r.result); r.readAsDataURL(f); });
    });
  }

  /* leitura por foto: documento e receita/óculos */
  const fotoMsg = document.getElementById('fotoMsg');
  const marcarLido = el=>{ if(el){ el.classList.add('campo-lido'); el.addEventListener('input', ()=>el.classList.remove('campo-lido'), {once:true}); } };
  function dispararInput(el){ el.dispatchEvent(new Event('input',{bubbles:true})); }
  function preencher(id, valor){
    const el = document.getElementById(id); if(!el || !valor) return false;
    el.value = valor; dispararInput(el); marcarLido(el); return true;
  }
  function ligarBotaoFoto(btnId, inputId, tratar){
    const btn = document.getElementById(btnId), inp = document.getElementById(inputId);
    btn.onclick = ()=> inp.click();
    inp.onchange = async ()=>{
      const f = inp.files[0]; if(!f) return;
      btn.disabled = true; const rot = btn.textContent; btn.textContent = 'Lendo a foto...';
      fotoMsg.textContent = 'Lendo a foto. Aguarde alguns segundos.'; fotoMsg.style.color = '';
      try{ const url = await reduzirImagem(f, 1280, 0.7); await tratar(url, f); }
      catch(e){ fotoMsg.textContent = e.message || 'Não consegui ler a foto.'; fotoMsg.style.color = '#C1462F'; }
      btn.disabled = false; btn.textContent = rot; inp.value = '';
    };
  }
  function aplicarDocumento(d){
    let n = 0;
    if(d.nome_completo && !document.getElementById('fPNome').value.trim() && preencher('fPNome', d.nome_completo)) n++;
    else if(d.nome_completo && document.getElementById('fPNome').value.trim()!==d.nome_completo){ if(confirm('O documento diz: '+d.nome_completo+'\nTrocar o nome que já está escrito?')){ preencher('fPNome', d.nome_completo); n++; } }
    if(d.cpf && preencher('fPCpf', d.cpf)) n++;
    if(d.data_nascimento && preencher('fPNasc', d.data_nascimento)) n++;
    if(d.cpf_ilegivel) { fotoMsg.textContent = 'O CPF da foto saiu com número errado. Tire de novo ou digite.'; fotoMsg.style.color = '#C1462F'; return; }
    fotoMsg.style.color = n ? '#2e9d5b' : '#C1462F';
    fotoMsg.textContent = n ? `Li ${n} campo(s). Eles estão em verde. Confira com o documento antes de salvar.` : 'Não achei dados legíveis. Tire a foto de novo, reta e com boa luz, ou digite.';
  }
  ligarBotaoFoto('btnFotoDoc','inFotoDoc', async (url)=>{ aplicarDocumento(await lerDocumentoPorFoto(url)); });
  ligarBotaoFoto('btnFotoRec','inFotoRec', async (url, arquivo)=>{
    // a foto sempre fica anexada na ficha (campo "Foto da receita")
    const alvo = document.getElementById('fPFotoReceita');
    if(alvo && window.DataTransfer){ try{ const bin = atob(url.split(',')[1]); const bytes = new Uint8Array(bin.length); for(let i=0;i<bin.length;i++) bytes[i]=bin.charCodeAt(i); const blob = new Blob([bytes],{type:'image/jpeg'}); const dt = new DataTransfer(); dt.items.add(new File([blob],'receita.jpg',{type:'image/jpeg'})); alvo.files = dt.files; }catch(e){} }
    let dados = null;
    try{ dados = (await lerPorIA('receita', url)).dados; }
    catch(e){
      if(e.semIA || /não está ligada/i.test(e.message||'')){
        fotoMsg.style.color = '#b26a00';
        fotoMsg.textContent = 'Foto anexada na ficha. A leitura automática do grau precisa da IA ligada. Digite o grau olhando a foto.';
      } else throw e;
    }
    const st = document.getElementById('fx_receita_status');
    if(dados){
      const t = textoReceita(dados);
      if(t && st){
        st.value = 'digitar'; st.dispatchEvent(new Event('change'));
        const cx = document.getElementById('fx_receita_digitada'); if(cx){ cx.value = t; marcarLido(cx); }
        fotoMsg.style.color = '#2e9d5b';
        fotoMsg.textContent = 'Li o grau e anexei a foto. O texto está em verde na parte da receita. Confira com a foto antes de salvar.';
      } else {
        if(st && !st.value){ st.value = 'foto'; st.dispatchEvent(new Event('change')); }
        fotoMsg.style.color = '#b26a00';
        fotoMsg.textContent = 'A foto ficou anexada, mas não consegui ler o grau. Digite olhando a foto ou tire outra, reta e com boa luz.';
      }
    } else if(st && !st.value){ st.value = 'foto'; st.dispatchEvent(new Event('change')); }
  });

  document.querySelectorAll('.ver-foto').forEach(a=> a.onclick = async (ev)=>{
    ev.preventDefault();
    try{
      const f = await api('/pacientes/'+editing.id+'/fotos');
      const src = f[a.dataset.q]; if(!src){ toast('Sem foto.'); return; }
      const ov = document.createElement('div');
      ov.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.85);z-index:200;display:flex;align-items:center;justify-content:center;padding:12px;';
      ov.innerHTML = '<img alt="Foto" style="max-width:100%;max-height:100%;border-radius:8px;">';
      ov.firstChild.src = src; ov.onclick = ()=> ov.remove(); document.body.appendChild(ov);
    }catch(e){ erroApi(e); }
  });
  document.getElementById('fPSalvar').onclick = async ()=>{
    const nome_completo = document.getElementById('fPNome').value.trim();
    const cpf = document.getElementById('fPCpf').value.trim();
    const tel = document.getElementById('fPTel').value.trim();
    const cep = document.getElementById('fPCep').value.trim();
    const errEl = document.getElementById('fPErr');
    if(!nome_completo){ errEl.textContent = 'Informe o nome.'; return; }
    if(cpf && !cpfValido(cpf)){ errEl.textContent = 'O CPF informado não é válido.'; return; }
    if(tel && ![10,11].includes(tel.replace(/\D/g,'').length)){ errEl.textContent = 'Telefone incompleto.'; return; }
    const dadosExtras = {}; FICHA_EXTRAS.forEach(k=>{ const el = document.getElementById('fx_'+k); if(el) dadosExtras[k] = el.value.trim(); });
    const valores = { telefone:tel, cpf, cep, endereco:document.getElementById('fPEndereco').value.trim(), bairro:document.getElementById('fPBairro').value.trim(), data_nascimento:document.getElementById('fPNasc').value,
      foto_receita: (document.getElementById('fPFotoReceita').files[0] || (editing&&editing.tem_foto_receita) || dadosExtras.receita_digitada || dadosExtras.receita_status==='nao_tem') ? 'x' : '',
      foto_armacao: (document.getElementById('fPFotoArmacao').files[0] || (editing&&editing.tem_foto_armacao)) ? 'x' : '', ...dadosExtras };
    for(const d of FICHA_DEF){ if(fichaEstado(d[0])==='obrigatorio' && !valores[d[0]]){ errEl.textContent = d[1]+' é obrigatório.'; return; } }

    const fotoReceita = await readFile(document.getElementById('fPFotoReceita'));
    const fotoArmacao = await readFile(document.getElementById('fPFotoArmacao'));
    const payload = {
      nome_completo, cpf: cpf||null, telefone: tel||null, cep: cep||null,
      cidade: document.getElementById('fPCidade').value,
      bairro: document.getElementById('fPBairro').value,
      endereco: document.getElementById('fPEndereco').value,
      agendado_por: document.getElementById('fPPor').value,
      data_nascimento: document.getElementById('fPNasc').value || null,
      foto_receita_url: fotoReceita, foto_armacao_url: fotoArmacao, dados_extras: dadosExtras,
      aceite_lgpd: !!(document.getElementById('fPLgpd') && document.getElementById('fPLgpd').checked),
    };
    try{
      if(editing){ const r = await api(`/pacientes/${editing.id}`, { method:'PUT', body:payload }); Object.assign(editing, r); }
      else { const r = await api('/pacientes', { method:'POST', body:payload }); pacientes.push(r); }
      closeModal(); toast('Paciente salvo.'); renderView('pacientes');
    }catch(e){ errEl.textContent = e.message; }
  };
  if(editing){
    document.getElementById('fPFicha').onclick = ()=> imprimirFicha(editing);
    const bExcP = document.getElementById('fPExcluir'); if(bExcP) bExcP.onclick = async ()=>{
      if(!confirm('Excluir este paciente? O histórico de exames é mantido, só o cadastro sai da lista.')) return;
      try{
        await api(`/pacientes/${editing.id}`, { method:'DELETE' });
        pacientes = pacientes.filter(p=>p.id!==editId);
        closeModal(); toast('Paciente excluído.'); renderView('pacientes');
      }catch(e){ erroApi(e); }
    };
  }
}

/* ========================= ASSISTENTE POR CONVERSA ========================= */
let chatState = { step:'nome', dados:{} };
const DIAS_SEMANA = {'domingo':0,'segunda':1,'segunda-feira':1,'terça':2,'terca':2,'terça-feira':2,'terca-feira':2,'quarta':3,'quarta-feira':3,'quinta':4,'quinta-feira':4,'sexta':5,'sexta-feira':5,'sábado':6,'sabado':6};

function renderAssistente(main){
  main.innerHTML = `
    <div class="card">
      <h2>Assistente de agendamento</h2>
      <p class="sub">Converse normalmente. Ele entende dia, horário, e confirma o agendamento.</p>
      <div class="chat-box" id="chatBox"></div>
      <div class="chat-input-row">
        <input type="text" id="chatInput" placeholder="Digite aqui...">
        <button class="btn btn-primary" id="chatSend">Enviar</button>
      </div>
    </div>
  `;
  chatState = { step:'nome', dados:{} };
  const box = document.getElementById('chatBox');
  addBotMsg(box, 'Olá! Vamos marcar um exame de vista. Qual o nome completo do paciente?');
  document.getElementById('chatSend').onclick = sendChat;
  document.getElementById('chatInput').addEventListener('keydown', e=>{ if(e.key==='Enter') sendChat(); });
}
function addBotMsg(box, text){ box.insertAdjacentHTML('beforeend', `<div class="msg bot">${text}</div>`); box.scrollTop = box.scrollHeight; }
function addUserMsg(box, text){ box.insertAdjacentHTML('beforeend', `<div class="msg user">${text}</div>`); box.scrollTop = box.scrollHeight; }

function parseDataHora(texto){
  const t = texto.toLowerCase();
  let data = null;
  const hoje = new Date();
  if(t.includes('hoje')) data = new Date(hoje);
  else if(t.includes('amanhã') || t.includes('amanha')) { data = new Date(hoje); data.setDate(data.getDate()+1); }
  else {
    const dm = t.match(/(\d{1,2})\/(\d{1,2})(?:\/(\d{2,4}))?/);
    if(dm){ data = new Date(hoje.getFullYear(), parseInt(dm[2])-1, parseInt(dm[1])); }
    else {
      for(const k in DIAS_SEMANA){
        if(t.includes(k)){
          data = new Date(hoje);
          let target = DIAS_SEMANA[k];
          let diff = (target - data.getDay() + 7) % 7;
          if(diff===0) diff = 7;
          data.setDate(data.getDate()+diff);
          break;
        }
      }
    }
  }
  let hora = null;
  const hm = t.match(/(\d{1,2})[h:](\d{2})?/);
  if(hm){ hora = `${hm[1].padStart(2,'0')}:${(hm[2]||'00').padStart(2,'0')}`; }
  return { data: data? data.toISOString().slice(0,10): null, hora };
}

function sendChat(){
  const input = document.getElementById('chatInput');
  const box = document.getElementById('chatBox');
  const val = input.value.trim();
  if(!val) return;
  addUserMsg(box, val);
  input.value = '';

  if(chatState.step==='nome'){
    chatState.dados.nome = val;
    const existente = pacientes.find(p=>p.nome_completo.toLowerCase()===val.toLowerCase());
    if(existente) chatState.dados.pacienteId = existente.id;
    chatState.step = 'telefone';
    addBotMsg(box, existente? `Encontrei ${existente.nome_completo} já cadastrado(a). Qual o telefone para confirmar?` : 'Certo. Qual o telefone de contato?');
  }
  else if(chatState.step==='telefone'){
    chatState.dados.telefone = val;
    chatState.step = 'quando';
    addBotMsg(box, 'Para quando você quer marcar? (ex: "amanhã às 14h" ou "sexta-feira 10h30")');
  }
  else if(chatState.step==='quando'){
    const {data, hora} = parseDataHora(val);
    if(!data || !hora){ addBotMsg(box, 'Não entendi bem a data/horário. Pode repetir, por exemplo: "quinta-feira às 15h"?'); return; }
    chatState.dados.data = data; chatState.dados.hora = hora;
    chatState.step = 'confirma';
    addBotMsg(box, `Confirmando: ${chatState.dados.nome}, dia ${fmtData(data)} às ${hora}. Posso agendar? (responda "sim" ou "não")`);
  }
  else if(chatState.step==='confirma'){
    if(/sim|pode|confirmo|ok/i.test(val)){
      confirmarAgendamentoChat(box);
    } else {
      addBotMsg(box, 'Sem problema, não vou agendar. Se quiser recomeçar, digite o nome do paciente.');
      chatState = {step:'nome', dados:{}};
    }
  }
  else {
    chatState = {step:'telefone', dados:{nome: val}};
    addBotMsg(box, 'Vamos marcar outro horário. Qual o telefone de contato?');
  }
}

async function confirmarAgendamentoChat(box){
  try{
    let pacienteId = chatState.dados.pacienteId;
    if(!pacienteId){
      const novo = await api('/pacientes', { method:'POST', body:{ nome_completo: chatState.dados.nome, telefone: chatState.dados.telefone, agendado_por:'Assistente' } });
      pacientes.push(novo); pacienteId = novo.id;
    }
    const tipoPadrao = tiposAtendimento[0];
    await api('/agendamentos', { method:'POST', body:{
      paciente_id: pacienteId, tipo_atendimento_id: tipoPadrao.id,
      data_hora: `${chatState.dados.data}T${chatState.dados.hora}:00`,
      agendado_por: 'Assistente'
    }});
    agendamentos = await api(`/agendamentos?de=${chatState.dados.data}&ate=${chatState.dados.data}`).then(novos=>{
      const outros = agendamentos.filter(a=>soData(a.data_hora)!==chatState.dados.data);
      return [...outros, ...novos];
    });
    addBotMsg(box, `Pronto! Agendamento criado para ${fmtData(chatState.dados.data)} às ${chatState.dados.hora}. ✅`);
  }catch(e){
    addBotMsg(box, `Não consegui agendar: ${e.message}`);
  }
  chatState = {step:'fim', dados:{}};
}

/* ========================= RECEITA E ATESTADO ========================= */
const CID_LIST = [
  {cid:'H52.0', desc:'Hipermetropia'}, {cid:'H52.1', desc:'Miopia'}, {cid:'H52.2', desc:'Astigmatismo'},
  {cid:'H52.4', desc:'Presbiopia'}, {cid:'H25', desc:'Catarata senil'}, {cid:'H26.9', desc:'Catarata não especificada'},
  {cid:'H40', desc:'Glaucoma'}, {cid:'H35.3', desc:'Degeneração macular'}, {cid:'H10', desc:'Conjuntivite'},
  {cid:'H04.1', desc:'Síndrome do olho seco'}, {cid:'H53.1', desc:'Distúrbios visuais subjetivos'},
  {cid:'H53.2', desc:'Diplopia (visão dupla)'}, {cid:'H54', desc:'Cegueira e visão subnormal'},
  {cid:'H00.0', desc:'Hordéolo (terçol)'}, {cid:'H02.4', desc:'Ptose palpebral'}, {cid:'Z01.0', desc:'Exame dos olhos e da visão'},
];
const TIPOS_LENTE = ['Monofocal','Bifocal','Multifocal'];
const LISTA_SINTOMAS = ['Visão embaçada','Dificuldade pra enxergar de longe','Dificuldade pra enxergar de perto','Dor de cabeça','Lacrimejamento','Coceira ou ardência','Sensibilidade à luz','Fadiga visual','Visão dupla','Olho seco'];
/* sintomas que pedem encaminhamento ao oftalmologista (aparecem em vermelho e geram alerta) */
const SINTOMAS_ALERTA = ['Flashes de luz','Moscas volantes novas','Perda súbita de visão','Dor no olho','Trauma recente no olho','Olho vermelho com dor','Visão dupla'];
LISTA_SINTOMAS.splice(LISTA_SINTOMAS.indexOf('Visão dupla'),1);
LISTA_SINTOMAS.push(...SINTOMAS_ALERTA);

/* Gabarito de acuidade visual: mesma estrutura de um exame em papel, serve tanto
   pra exame comum quanto admissional de empresa (campos de empresa ficam em branco
   quando não é o caso). Letras e faixas abaixo seguem o padrão de 8 linhas comum
   nesse tipo de teste (20/20 até 20/200). */
const LINHAS_ACUIDADE = [
  { faixa:'20/20',  od:'T I X L U', oe:'L V T I U' },
  { faixa:'20/25',  od:'O H F Z U', oe:'O H I N T' },
  { faixa:'20/30',  od:'D N O H S', oe:'O S D H N' },
  { faixa:'20/40',  od:'H L E N Z', oe:'Z H E L N' },
  { faixa:'20/50',  od:'R D L Z H', oe:'Z G L R H' },
  { faixa:'20/70',  od:'B F T P',   oe:'P F B T' },
  { faixa:'20/100', od:'L P E',     oe:'T O Z' },
  { faixa:'20/200', od:'F',         oe:'E' },
];
function gabaritoVazio(){
  return {
    idadePaciente:'', empresa:'', funcao:'', setor:'',
    usaOculos:'', frequenciaUso:'', tipoLenteAtual:'', tempoUsoAtual:'', ultimaConsultaEspecialista:'',
    jaFezExameEspecialista:'', possuiDoencaOcular:'', doencaOcularQual:'',
    senteDificuldadeVisual:'', dificuldadeQual:'',
    testeComCorrecao:'',
    linhasOD: Array(8).fill(null), linhasOE: Array(8).fill(null), // true=acertou, false=errou, null=não marcado
    resultadoOD:'', resultadoOE:'',
    avLongeSemOD:'', avLongeSemOE:'', avLongeSemAO:'',
    avLongeComOD:'', avLongeComOE:'', avLongeComAO:'',
    avPertoOD:'', avPertoOE:'', avPertoAO:'',
    testeCores:'', testeCoresAcertos:'',
    condutaGabarito:'', observacoesGabarito:''
  };
}
const TRATAMENTOS = ['Antirreflexo','Blue Control (filtro de luz azul)','Fotocromática (Transitions)','Anti-risco','Proteção UV','Antiembaçante','Hidro/Oleofóbica (repele água e gordura)','Polarizada'];

let receitaAtual = { pacienteId:'', idade:'', profissionalId:'', longe:{od:{esf:'',cil:'',eixo:''},oe:{esf:'',cil:'',eixo:''}}, perto:{od:{esf:'',cil:'',eixo:''},oe:{esf:'',cil:'',eixo:''}}, adicao:'', tipoLente:TIPOS_LENTE[0], tratamentos:[], cid:null, atestadoTexto:'', declaracaoTexto:'',
  extras:{avOd:'',avOe:'',dnpOd:'',dnpOe:'',dp:''},
  pertoAuto:true, adicaoSugeridaAceita:false }; // pertoAuto: enquanto true, o Perto acompanha Longe+adição no multifocal; vira false assim que o atendente edita o Perto manualmente

/* Adição de referência por faixa etária (presbiopia), tabela clínica usual:
   40-44: +1,00 · 45-49: +1,50 · 50-54: +2,00 · 55-59: +2,50 · 60+: +3,00
   É só uma sugestão de partida: o campo de adição continua 100% digitável,
   porque a acomodação visual varia de pessoa pra pessoa. */
function adicaoSugeridaPorIdade(idade){
  const n = parseInt(idade, 10);
  if(isNaN(n) || n < 40) return null;
  if(n <= 44) return '+1.00';
  if(n <= 49) return '+1.50';
  if(n <= 54) return '+2.00';
  if(n <= 59) return '+2.50';
  return '+3.00';
}

/* ---- listas de opção pro combobox próprio (não usa <datalist> nativo) ----
   O <datalist> do navegador tem um problema sério no iOS: quando a lista passa de
   poucas opções, o painel de sugestão cobre o campo inteiro na tela. Por isso o menu
   de sugestão aqui é feito à mão, em HTML/CSS normal, e se comporta igual em
   qualquer celular. */
function opcoesEsf(){ const o=[]; for(let v=-20;v<=20;v+=0.25) o.push((v>0?'+':'')+v.toFixed(2)); return o; }
function opcoesCil(){ const o=['0.00']; for(let v=-0.25;v>=-10;v-=0.25) o.push(v.toFixed(2)); return o; }
function opcoesAdicao(){ const o=[]; for(let v=0.25;v<=4;v+=0.25) o.push('+'+v.toFixed(2)); return o; }
/* eixo: só os valores mais usados na prática aparecem como sugestão rápida (180 opções
   cobririam a tela toda); qualquer grau de 1 a 180 continua aceito digitando direto */
function opcoesEixo(){ return [180,90,45,135,30,60,120,150,10,20,70,100,160,170].map(v=>v+'°'); }

/* esférico aceita -20.00 a +20.00 */
function normalizarEsf(v){
  v = v.trim().replace(',', '.');
  if(v===''){ return ''; }
  const n = parseFloat(v);
  if(isNaN(n)) return v; // deixa como digitado, não trava o campo
  return (n>0?'+':'') + n.toFixed(2);
}
/* cilíndrico é sempre negativo por convenção clínica */
function normalizarCil(v){
  v = v.trim().replace(',', '.');
  if(v===''){ return ''; }
  const n = parseFloat(v);
  if(isNaN(n)) return v;
  const neg = n>0 ? -n : n;
  return neg===0 ? '0.00' : neg.toFixed(2);
}
/* eixo é cíclico entre 1 e 180: 0° e 180° são o mesmo meridiano, então por convenção
   nunca se escreve "0", sempre "180". Qualquer valor fora da faixa dá a volta
   (ex: 181 vira 1, 360 vira 180), em vez de simplesmente cortar no limite. */
function normalizarEixo(v){
  v = v.trim().replace('°','').replace(',', '.');
  if(v==='') return '';
  const n = parseInt(v,10);
  if(isNaN(n)) return v;
  const ciclico = ((n - 1) % 180 + 180) % 180 + 1;
  return ciclico + '°';
}

/* mostra embaixo do campo, por 2.5s, o que mudou quando o valor digitado é
   corrigido automaticamente (sinal do cilindro, eixo fora da faixa, etc.) */
function avisarCorrecao(campoId, valorDigitado, valorFinal){
  const msg = document.getElementById(campoId+'_msg');
  if(!msg) return;
  if(valorDigitado && valorDigitado!==valorFinal){
    msg.textContent = `Ajustado para ${valorFinal}`;
    msg.className = 'fieldmsg bad';
  } else if(valorFinal){
    msg.textContent = 'OK';
    msg.className = 'fieldmsg ok';
  } else {
    msg.textContent = ''; msg.className = 'fieldmsg';
  }
}

function olhoBlock(dist, olho, label){
  const d = receitaAtual[dist][olho];
  return `<div class="row3">
      <div><div class="combo-wrap"><label>${label} Esf.</label><input type="text" inputmode="decimal" id="r_${dist}_${olho}_esf" value="${d.esf}" placeholder="-1.00" autocomplete="off"></div><p class="fieldmsg" id="r_${dist}_${olho}_esf_msg"></p></div>
      <div><div class="combo-wrap"><label>${label} Cil.</label><input type="text" inputmode="decimal" id="r_${dist}_${olho}_cil" value="${d.cil}" placeholder="-0.75" autocomplete="off"></div><p class="fieldmsg" id="r_${dist}_${olho}_cil_msg"></p></div>
      <div><div class="combo-wrap"><label>${label} Eixo</label><input type="text" inputmode="numeric" id="r_${dist}_${olho}_eixo" value="${d.eixo}" placeholder="90°" autocomplete="off"></div><p class="fieldmsg" id="r_${dist}_${olho}_eixo_msg"></p></div>
    </div>`;
}

/* perto = longe + adição (sempre positiva), cilindro e eixo repetem os de longe.
   Só recalcula automático quando o tipo é Multifocal, a adição está preenchida,
   e o atendente ainda não editou o Perto manualmente (pertoAuto). */
function calcularPerto(){
  if(!receitaAtual.adicao || !receitaAtual.pertoAuto) return false;
  const adicao = parseFloat(receitaAtual.adicao.replace('+',''));
  if(isNaN(adicao)) return false;
  ['od','oe'].forEach(olho=>{
    const esfLonge = parseFloat((receitaAtual.longe[olho].esf||'0').replace('+','')) || 0;
    const novoEsf = esfLonge + adicao;
    receitaAtual.perto[olho].esf = (novoEsf>0?'+':'') + novoEsf.toFixed(2);
    receitaAtual.perto[olho].cil = receitaAtual.longe[olho].cil;
    receitaAtual.perto[olho].eixo = receitaAtual.longe[olho].eixo;
  });
  return true;
}
function atualizarCamposPerto(){
  ['od','oe'].forEach(olho=>['esf','cil','eixo'].forEach(campo=>{
    const el = document.getElementById(`r_perto_${olho}_${campo}`);
    if(el) el.value = receitaAtual.perto[olho][campo];
  }));
}

/* combobox próprio: um <div> de sugestões posicionado embaixo do campo, sem depender
   do <datalist> nativo do navegador */
function montarCombo(inputId, opcoes){
  const input = document.getElementById(inputId);
  if(!input) return;
  const wrap = input.closest('.combo-wrap');
  const panel = document.createElement('div');
  panel.className = 'combo-panel';
  wrap.appendChild(panel);
  function render(){
    const filtro = input.value.trim().toLowerCase();
    const lista = filtro ? opcoes.filter(o=>o.toLowerCase().includes(filtro)) : opcoes;
    if(!lista.length){ panel.classList.remove('show'); return; }
    panel.innerHTML = lista.map(o=>`<div class="combo-opt">${o}</div>`).join('');
    panel.classList.add('show');
  }
  input.addEventListener('focus', render);
  input.addEventListener('input', render);
  input.addEventListener('blur', ()=> setTimeout(()=> panel.classList.remove('show'), 180));
  panel.addEventListener('mousedown', e=>{
    const opt = e.target.closest('.combo-opt');
    if(!opt) return;
    input.value = opt.textContent;
    panel.classList.remove('show');
    input.dispatchEvent(new Event('blur'));
  });
}

function podeCidAqui(){
  const prof = profissionalSelecionado();
  return !!prof && /^\s*CRM/i.test(prof.registro_conselho||'');
}
function renderReceita(main){
  const pacOpts = pacientes.map(p=>`<option value="${p.id}" ${receitaAtual.pacienteId===p.id?'selected':''}>${esc(p.nome_completo)}</option>`).join('');
  main.innerHTML = `
    <div class="card">
      <h2>Receita e atestado</h2>
      <p class="sub">Monte a receita óptica, gere atestado/declaração com CID e envie por WhatsApp ou imprima. Nos campos de grau, digite o valor ou toque pra ver sugestões.</p>
      <label class="req">Paciente</label>
      <select id="rPac"><option value="">Selecione...</option>${pacOpts}</select>
      <label>Profissional responsável <span style="font-weight:400;color:var(--ink-soft);">(carimbo e assinatura que saem na receita)</span></label>
      <select id="rProfissional"><option value="">Selecione...</option>${profissionais.map(p=>`<option value="${p.id}" ${receitaAtual.profissionalId===p.id?'selected':''}>${esc(p.nome)}</option>`).join('')}</select>
      ${!profissionais.length ? '<p class="fieldmsg bad">Nenhum profissional cadastrado ainda. Cadastre em Master &gt; Usuários.</p>' : ''}
      <h3 style="margin-top:18px;font-size:15px;">Longe</h3>
      ${olhoBlock('longe','od','OD')}${olhoBlock('longe','oe','OE')}
      <h3 style="margin-top:18px;font-size:15px;">Perto
        ${receitaAtual.adicao ? (receitaAtual.pertoAuto
          ? '<span style="font-weight:400;color:var(--ink-soft);font-size:12px;">(calculado automático: longe + adição)</span>'
          : `<button type="button" class="link-discreto" id="btnRecalcularPerto" style="display:inline;width:auto;margin:0 0 0 6px;font-size:12px;">recalcular automático</button>`)
          : ''}
      </h3>
      ${olhoBlock('perto','od','OD')}${olhoBlock('perto','oe','OE')}
      <h3 style="margin-top:18px;font-size:15px;">Medidas complementares</h3>
      <div class="row2">
        <div><label>Acuidade OD</label><input type="text" id="rAvOd" value="${esc(receitaAtual.extras.avOd)}" placeholder="20/20"></div>
        <div><label>Acuidade OE</label><input type="text" id="rAvOe" value="${esc(receitaAtual.extras.avOe)}" placeholder="20/20"></div>
      </div>
      <div class="row3">
        <div><label>DNP OD (mm)</label><input type="text" inputmode="decimal" id="rDnpOd" value="${esc(receitaAtual.extras.dnpOd)}" placeholder="31"></div>
        <div><label>DNP OE (mm)</label><input type="text" inputmode="decimal" id="rDnpOe" value="${esc(receitaAtual.extras.dnpOe)}" placeholder="32"></div>
        <div><label>DP (mm)</label><input type="text" inputmode="decimal" id="rDp" value="${esc(receitaAtual.extras.dp)}" placeholder="63"></div>
      </div>
      <label>Idade do paciente <span style="font-weight:400;color:var(--ink-soft);">(sugere a adição a partir dos 40 anos)</span></label>
      <input type="text" inputmode="numeric" id="rIdade" value="${receitaAtual.idade}" placeholder="Ex: 52" maxlength="3" style="max-width:120px;">
      <div id="sugestaoAdicaoBox"></div>
      <div class="combo-wrap"><label>Adição <span style="font-weight:400;color:var(--ink-soft);">(sempre positiva)</span></label>
      <input type="text" inputmode="decimal" id="rAdicao" value="${receitaAtual.adicao}" placeholder="+2.00" autocomplete="off"></div>
      <p class="fieldmsg" id="rAdicao_msg"></p>
      <label>Tipo de lente</label><select id="rTipoLente">${TIPOS_LENTE.map(t=>`<option ${receitaAtual.tipoLente===t?'selected':''}>${t}</option>`).join('')}</select>
      <label>Tratamentos</label>
      <div class="check-grid">${TRATAMENTOS.map(t=>`<label class="check-item"><input type="checkbox" value="${t}" class="rTrat" ${receitaAtual.tratamentos.includes(t)?'checked':''}> ${t}</label>`).join('')}</div>
      <button class="btn btn-ghost btn-block" style="margin-top:16px;" id="btnSalvarReceita">Salvar receita</button>
    </div>
    <div class="card">
      <h2>Atestado / Declaração${podeCidAqui()?' com CID':''}</h2>
      ${podeCidAqui() ? `<label>Buscar CID</label>
      <input type="text" id="cidSearch" placeholder="Digite o código ou a descrição...">
      <div id="cidResults"></div>
      <div id="cidSelected">${receitaAtual.cid? cidChipHtml() : ''}</div>` : `<p class="sub">O CID é um diagnóstico e só entra quando o profissional responsável é médico (registro CRM). Aqui o atestado sai sem CID, só com o comparecimento.</p><div id="cidSelected"></div>`}
      <label>Texto do atestado</label>
      <textarea id="rAtestado" placeholder="Atesto que o(a) paciente esteve em consulta oftalmológica...">${receitaAtual.atestadoTexto}</textarea>
      <label>Texto da declaração de comparecimento</label>
      <textarea id="rDeclaracao" placeholder="Declaro que o(a) paciente compareceu a esta clínica em...">${receitaAtual.declaracaoTexto}</textarea>
      <div class="btn-row">
        <button class="btn btn-amber" id="btnImprimirReceita">Imprimir receita</button>
        <button class="btn btn-amber" id="btnImprimirAtestado">Imprimir atestado</button>
        <button class="btn btn-amber" id="btnImprimirDeclaracao">Imprimir declaração</button>
        <button class="btn btn-wpp" id="btnWppReceita">Enviar receita (WhatsApp)</button>
        <button class="btn btn-wpp" id="btnWppAtestado">Enviar atestado (WhatsApp)</button>
      </div>
    </div>
  `;
  if(calcularPerto()) atualizarCamposPerto();

  document.getElementById('rPac').onchange = e=>{
    receitaAtual.pacienteId = e.target.value;
    const pac = pacientes.find(x=>x.id===e.target.value);
    const idade = pac ? idadeDe(pac.data_nascimento) : null;
    if(idade !== null){ receitaAtual.idade = String(idade); receitaAtual.adicaoSugeridaAceita = false; renderReceita(main); }
  };
  [['rAvOd','avOd'],['rAvOe','avOe'],['rDnpOd','dnpOd'],['rDnpOe','dnpOe'],['rDp','dp']].forEach(([id,k])=>{
    document.getElementById(id).addEventListener('input', e=>{ receitaAtual.extras[k] = e.target.value.trim(); });
  });
  document.getElementById('rProfissional').onchange = e=>{ receitaAtual.profissionalId = e.target.value; if(!podeCidAqui()) receitaAtual.cid = null; renderReceita(main); };

  function renderSugestaoAdicao(){
    const box = document.getElementById('sugestaoAdicaoBox');
    if(!box) return;
    const sugestao = adicaoSugeridaPorIdade(receitaAtual.idade);
    if(!sugestao || receitaAtual.adicaoSugeridaAceita){ box.innerHTML=''; return; }
    box.innerHTML = `<div class="sugestao-chip">
      Faixa de ${receitaAtual.idade} anos costuma usar ${sugestao} de adição
      <button type="button" id="btnAceitarSugestaoAdicao">Usar ${sugestao}</button>
      <button type="button" class="dispensar" id="btnDispensarSugestaoAdicao">Paciente tem acomodação melhor, ignorar</button>
    </div>`;
    document.getElementById('btnAceitarSugestaoAdicao').onclick = ()=>{
      document.getElementById('rAdicao').value = sugestao;
      receitaAtual.adicao = sugestao;
      receitaAtual.adicaoSugeridaAceita = true;
      if(calcularPerto()) atualizarCamposPerto();
      box.innerHTML = '';
    };
    document.getElementById('btnDispensarSugestaoAdicao').onclick = ()=>{
      receitaAtual.adicaoSugeridaAceita = true; // não insiste de novo pra essa idade já informada
      box.innerHTML = '';
    };
  }
  renderSugestaoAdicao();

  document.getElementById('rIdade').addEventListener('input', e=>{
    const digitos = e.target.value.replace(/\D/g,'').slice(0,3);
    e.target.value = digitos;
    receitaAtual.idade = digitos;
    receitaAtual.adicaoSugeridaAceita = false; // idade mudou, pode sugerir de novo
    renderSugestaoAdicao();
  });

  montarCombo('rAdicao', opcoesAdicao());
  document.getElementById('rAdicao').addEventListener('blur', e=>{
    const digitado = e.target.value.trim();
    let v = digitado.replace(',','.');
    if(v){ const n = parseFloat(v.replace('+','')); if(!isNaN(n)) v = '+'+Math.abs(n).toFixed(2); }
    e.target.value = v;
    avisarCorrecao('rAdicao', digitado, v);
    receitaAtual.adicao = v;
    if(calcularPerto()){ atualizarCamposPerto(); }
  });

  document.getElementById('rTipoLente').onchange = e=>{
    receitaAtual.tipoLente = e.target.value;
    receitaAtual.pertoAuto = true; // ao trocar o tipo de lente, volta a calcular o perto sozinho
    renderReceita(main);
  };
  main.querySelectorAll('.rTrat').forEach(cb=> cb.onchange = ()=>{ receitaAtual.tratamentos = [...main.querySelectorAll('.rTrat:checked')].map(c=>c.value); });

  const btnRecalcular = document.getElementById('btnRecalcularPerto');
  if(btnRecalcular) btnRecalcular.onclick = ()=>{
    receitaAtual.pertoAuto = true;
    if(calcularPerto()) atualizarCamposPerto();
    renderReceita(main);
  };

  ['longe','perto'].forEach(dist=> ['od','oe'].forEach(olho=>{
    const elEsf = document.getElementById(`r_${dist}_${olho}_esf`);
    const elCil = document.getElementById(`r_${dist}_${olho}_cil`);
    const elEixo = document.getElementById(`r_${dist}_${olho}_eixo`);
    montarCombo(`r_${dist}_${olho}_esf`, opcoesEsf());
    montarCombo(`r_${dist}_${olho}_cil`, opcoesCil());
    montarCombo(`r_${dist}_${olho}_eixo`, opcoesEixo());

    if(elEsf) elEsf.addEventListener('blur', e=>{
      const digitado = e.target.value.trim();
      const v = normalizarEsf(digitado);
      e.target.value = v;
      avisarCorrecao(`r_${dist}_${olho}_esf`, digitado, v);
      receitaAtual[dist][olho].esf = v;
      if(dist==='longe' && calcularPerto()) atualizarCamposPerto();
      else if(dist==='perto' && receitaAtual.adicao && receitaAtual.pertoAuto){ receitaAtual.pertoAuto = false; renderReceita(main); }
    });
    if(elCil) elCil.addEventListener('blur', e=>{
      const digitado = e.target.value.trim();
      const v = normalizarCil(digitado);
      e.target.value = v;
      avisarCorrecao(`r_${dist}_${olho}_cil`, digitado, v);
      receitaAtual[dist][olho].cil = v;
      if(dist==='longe' && calcularPerto()) atualizarCamposPerto();
      else if(dist==='perto' && receitaAtual.adicao && receitaAtual.pertoAuto){ receitaAtual.pertoAuto = false; renderReceita(main); }
    });
    if(elEixo) elEixo.addEventListener('blur', e=>{
      const digitado = e.target.value.trim();
      const v = normalizarEixo(digitado);
      e.target.value = v;
      avisarCorrecao(`r_${dist}_${olho}_eixo`, digitado, v);
      receitaAtual[dist][olho].eixo = v;
      if(dist==='longe' && calcularPerto()) atualizarCamposPerto();
      else if(dist==='perto' && receitaAtual.adicao && receitaAtual.pertoAuto){ receitaAtual.pertoAuto = false; renderReceita(main); }
    });
  }));
  const cidBusca = document.getElementById('cidSearch');
  if(cidBusca) cidBusca.addEventListener('input', e=>{
    const q = e.target.value.trim().toLowerCase();
    const res = document.getElementById('cidResults');
    if(!q){ res.innerHTML=''; return; }
    const found = CID_LIST.filter(c=> c.cid.toLowerCase().includes(q) || c.desc.toLowerCase().includes(q)).slice(0,6);
    res.innerHTML = found.map(c=>`<div class="cid-result" onclick="selecionarCid('${c.cid}','${c.desc.replace(/'/g,"\\'")}')">${c.cid} — ${c.desc}</div>`).join('') || '<p class="sub">Nenhum CID encontrado.</p>';
  });
  document.getElementById('rAtestado').onchange = e=> receitaAtual.atestadoTexto = e.target.value;
  document.getElementById('rDeclaracao').onchange = e=> receitaAtual.declaracaoTexto = e.target.value;
  document.getElementById('btnSalvarReceita').onclick = async ()=>{
    if(!receitaAtual.pacienteId){ toast('Selecione um paciente.'); return; }
    try{
      await api('/receitas', { method:'POST', body:{
        paciente_id: receitaAtual.pacienteId, profissional_id: receitaAtual.profissionalId || null, idade_paciente: receitaAtual.idade || null,
        longe: { ...receitaAtual.longe, extras: receitaAtual.extras }, perto: receitaAtual.perto, adicao: receitaAtual.adicao,
        tipo_lente: receitaAtual.tipoLente, tratamentos: receitaAtual.tratamentos,
        cid_codigo: receitaAtual.cid?.cid||null, cid_descricao: receitaAtual.cid?.desc||null,
        atestado_texto: receitaAtual.atestadoTexto, declaracao_texto: receitaAtual.declaracaoTexto
      }});
      toast('Receita salva.');
    }catch(e){ erroApi(e); }
  };
  const exigePaciente = ()=>{ if(!receitaAtual.pacienteId){ toast('Selecione o paciente primeiro.'); return false; } return true; };
  document.getElementById('btnImprimirReceita').onclick = ()=>{ if(exigePaciente()) imprimirDocumento(gerarHtmlReceita()); };
  document.getElementById('btnImprimirAtestado').onclick = ()=>{
    if(!exigePaciente()) return;
    if(!receitaAtual.atestadoTexto.trim()){ toast('Escreva o texto do atestado.'); return; }
    imprimirDocumento(gerarHtmlAtestado());
  };
  document.getElementById('btnImprimirDeclaracao').onclick = ()=>{
    if(!exigePaciente()) return;
    if(!receitaAtual.declaracaoTexto.trim()){ toast('Escreva o texto da declaração.'); return; }
    imprimirDocumento(gerarHtmlDeclaracao());
  };
  document.getElementById('btnWppReceita').onclick = ()=>{ if(exigePaciente()) enviarWhatsapp(gerarTextoReceita()); };
  document.getElementById('btnWppAtestado').onclick = ()=>{ if(exigePaciente()) enviarWhatsapp(gerarTextoAtestado()); };
}
function selecionarCid(cid, desc){ receitaAtual.cid={cid,desc}; document.getElementById('cidSelected').innerHTML=cidChipHtml(); document.getElementById('cidResults').innerHTML=''; document.getElementById('cidSearch').value=''; }
function removerCid(){ receitaAtual.cid=null; document.getElementById('cidSelected').innerHTML=''; }
function cidChipHtml(){ return `<div class="cid-chip">${receitaAtual.cid.cid} — ${receitaAtual.cid.desc} <button onclick="removerCid()">×</button></div>`; }
function profissionalSelecionado(){ return profissionais.find(p=>p.id===receitaAtual.profissionalId) || null; }
/* ===== Documentos impressos (receita, atestado, declaração) =====
   Cada documento abre num quadro invisível com página própria em A4, sem depender
   da tela do sistema. Assim a impressão sai igual em qualquer navegador. */
function esc(v){ return String(v==null?'':v).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'); }
function dataExtenso(d){ return (d||new Date()).toLocaleDateString('pt-BR',{day:'numeric',month:'long',year:'numeric'}); }
function idadeDe(iso){
  if(!iso) return null;
  const [y,m,d] = iso.slice(0,10).split('-').map(Number); const h = new Date();
  let n = h.getFullYear() - y;
  if(h.getMonth()+1 < m || (h.getMonth()+1 === m && h.getDate() < d)) n--;
  return n >= 0 && n < 130 ? n : null;
}
function pacienteDaReceita(){ return pacientes.find(p=>p.id===receitaAtual.pacienteId) || null; }

const FOLHAS = { A4:[210,297], A5:[148,210], Letter:[216,279] };
function configImpressao(){
  const c = clinicaAtual?.config_impressao || {};
  return { papel: FOLHAS[c.papel]?c.papel:'A4', orientacao: c.orientacao==='landscape'?'landscape':'portrait', cor: c.cor==='pb'?'pb':'colorido', margem_mm: c.margem_mm||14, rodape: c.rodape||'' };
}
function medidasFolha(){
  const c = configImpressao(); let [l,a] = FOLHAS[c.papel]; if(c.orientacao==='landscape') [l,a] = [a,l]; return { l, a };
}
function cssImpressao(){
  const c = configImpressao();
  let css = CSS_IMPRESSAO.replace('@page{size:A4;margin:14mm 16mm;}', `@page{size:${c.papel} ${c.orientacao};margin:${c.margem_mm}mm ${c.margem_mm+2}mm;}`);
  if(c.papel==='A5') css += 'body{zoom:.78;}';
  if(c.cor==='pb') css += `*{color:#000 !important;} table.grau th,table.lista th{background:#fff !important;} table.grau tr.sec td{background:#fff !important;border-top:2px solid #000;border-bottom:2px solid #000;} .cab{border-bottom-color:#000 !important;} h1{color:#000 !important;}`;
  return css;
}
const CSS_IMPRESSAO = `
  @page{size:A4;margin:14mm 16mm;}
  *{box-sizing:border-box;}
  body{font-family:Georgia,'Times New Roman',serif;color:#1b1b1b;font-size:12.5pt;line-height:1.45;margin:0;}
  .cab{display:flex;align-items:center;gap:16px;padding-bottom:10px;border-bottom:2.5px solid #0f4c4a;}
  .cab img{max-height:64px;max-width:150px;object-fit:contain;}
  .cab .dados{flex:1;}
  .cab .nome{font-size:17pt;font-weight:bold;color:#0f4c4a;letter-spacing:.3px;}
  .cab .linha{font-size:9.5pt;color:#444;font-family:Arial,sans-serif;}
  .filete{height:1px;background:#bbb;margin:3px 0 0;}
  h1{font-family:Arial,sans-serif;text-align:center;font-size:15pt;letter-spacing:4px;text-transform:uppercase;margin:20px 0 14px;color:#0f4c4a;}
  .paciente{border:1px solid #999;border-radius:4px;padding:8px 12px;font-family:Arial,sans-serif;font-size:10.5pt;display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap;}
  .paciente b{font-size:11.5pt;}
  table.grau{width:100%;border-collapse:collapse;margin-top:16px;font-family:Arial,sans-serif;font-size:11pt;}
  table.grau th,table.grau td{border:1px solid #777;padding:7px 8px;text-align:center;}
  table.grau th{background:#e8f0ef;font-weight:bold;}
  table.grau td.olho{text-align:left;font-weight:bold;width:34%;}
  table.grau tr.sec td{background:#0f4c4a;color:#fff;font-weight:bold;letter-spacing:2px;text-align:left;}
  .info{margin-top:14px;font-family:Arial,sans-serif;font-size:11pt;}
  .info div{padding:5px 0;border-bottom:1px dotted #aaa;}
  .info b{display:inline-block;min-width:130px;}
  .texto{font-size:13pt;text-align:justify;margin:6px 0 0;white-space:pre-wrap;line-height:1.7;}
  .cid{margin-top:14px;font-family:Arial,sans-serif;font-size:11pt;}
  .rodape{margin-top:46px;text-align:center;}
  .local-data{text-align:right;font-size:11.5pt;margin-bottom:34px;}
  .assin{display:inline-block;min-width:260px;text-align:center;}
  .assin img{max-height:62px;display:block;margin:0 auto 2px;}
  .assin .traco{border-top:1.5px solid #222;padding-top:5px;font-family:Arial,sans-serif;font-size:10.5pt;}
  .assin .traco b{font-size:11.5pt;}
  table.lista{width:100%;border-collapse:collapse;margin-top:14px;font-family:Arial,sans-serif;font-size:10.5pt;}
  table.lista th,table.lista td{border-bottom:1px solid #bbb;padding:6px 6px;text-align:left;}
  table.lista th{background:#e8f0ef;}
  .aviso{margin-top:22px;font-family:Arial,sans-serif;font-size:8.5pt;color:#666;text-align:center;border-top:1px solid #ccc;padding-top:6px;}
`;

function cabecalhoDocHtml(){
  const c = clinicaAtual || {};
  const logo = c.logo_url ? `<img src="${esc(c.logo_url)}" alt="">` : '';
  let un = minhaUnidade();
  try{ if(!un && typeof pacienteDaReceita==='function'){ const pp = pacienteDaReceita(); if(pp && pp.unidade_id) un = unidades.find(u=>u.id===pp.unidade_id) || null; } }catch(e){}
  const linhas = [un ? 'Atendimento em '+un.nome+(un.local?' · '+un.local:'') : c.endereco, c.telefone ? 'Telefone: '+c.telefone : '', c.cnpj ? 'CNPJ: '+c.cnpj : ''].filter(Boolean).map(l=>`<div class="linha">${esc(l)}</div>`).join('');
  return `<div class="cab">${logo}<div class="dados"><div class="nome">${esc(c.nome_fantasia||'')}</div>${linhas}</div></div>`;
}
function pacienteDocHtml(extra){
  const p = pacienteDaReceita();
  const idade = receitaAtual.idade ? ` · ${esc(receitaAtual.idade)} anos` : '';
  return `<div class="paciente"><div>Paciente<br><b>${esc(p?p.nome_completo:'')}</b>${idade}</div><div style="text-align:right;">Data<br><b>${fmtData(new Date().toISOString())}</b></div></div>${extra||''}`;
}
function assinaturaDocHtml(){
  const prof = profissionalSelecionado();
  if(!prof) return `<div class="assin"><div style="height:56px;"></div><div class="traco">Assinatura e carimbo do profissional</div></div>`;
  const img = prof.assinatura_url ? `<img src="${esc(prof.assinatura_url)}" alt="">` : '<div style="height:56px;"></div>';
  const carimbo = prof.carimbo_texto ? esc(prof.carimbo_texto).replace(/\n/g,'<br>') : `<b>${esc(prof.nome)}</b>`;
  return `<div class="assin">${img}<div class="traco">${carimbo}${prof.registro_conselho ? `<br>${esc(prof.registro_conselho)}`:''}</div></div>`;
}
function localDataDocHtml(){
  const cidade = (minhaUnidade()?.nome) || '';
  return `<div class="local-data">${cidade ? esc(cidade)+', ' : ''}${dataExtenso()}</div>`;
}
function paginaDoc(titulo, corpo){
  return `<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><title>${esc(titulo)}</title><style>${cssImpressao()}</style></head><body>${cabecalhoDocHtml()}<h1>${esc(titulo)}</h1>${corpo}${configImpressao().rodape?`<div class="aviso">${esc(configImpressao().rodape)}</div>`:''}</body></html>`;
}
function celulaGrau(v, sufixo){ return v ? esc(v)+(sufixo||'') : '—'; }
function linhaGrau(rotulo, o){ return `<tr><td class="olho">${rotulo}</td><td>${celulaGrau(o.esf)}</td><td>${celulaGrau(o.cil)}</td><td>${celulaGrau(o.eixo,'°')}</td></tr>`; }

function gerarHtmlReceita(){
  const r = receitaAtual;
  const tabela = `<table class="grau">
    <tr><th></th><th>Esférico</th><th>Cilíndrico</th><th>Eixo</th></tr>
    <tr class="sec"><td colspan="4">VISÃO DE LONGE</td></tr>
    ${linhaGrau('Olho direito (OD)', r.longe.od)}${linhaGrau('Olho esquerdo (OE)', r.longe.oe)}
    <tr class="sec"><td colspan="4">VISÃO DE PERTO</td></tr>
    ${linhaGrau('Olho direito (OD)', r.perto.od)}${linhaGrau('Olho esquerdo (OE)', r.perto.oe)}
  </table>`;
  const info = `<div class="info">
    ${(r.extras.avOd||r.extras.avOe) ? `<div><b>Acuidade visual:</b> OD ${esc(r.extras.avOd||'—')} · OE ${esc(r.extras.avOe||'—')}</div>` : ''}
    ${(r.extras.dnpOd||r.extras.dnpOe||r.extras.dp) ? `<div><b>Distância pupilar:</b> ${r.extras.dp ? 'DP '+esc(r.extras.dp)+' mm' : ''}${(r.extras.dnpOd||r.extras.dnpOe) ? ` · DNP OD ${esc(r.extras.dnpOd||'—')} · OE ${esc(r.extras.dnpOe||'—')} mm` : ''}</div>` : ''}
    <div><b>Adição:</b> ${esc(r.adicao||'—')}</div>
    <div><b>Tipo de lente:</b> ${esc(r.tipoLente||'—')}</div>
    <div><b>Tratamentos:</b> ${esc(r.tratamentos.join(', ')||'—')}</div>
  </div>`;
  return paginaDoc('Receita de Óculos', `${pacienteDocHtml()}${tabela}${info}<div class="rodape">${localDataDocHtml()}${assinaturaDocHtml()}</div><div class="aviso">Este exame de refração não substitui a consulta com médico oftalmologista. Em caso de dor, perda de visão ou suspeita de doença nos olhos, procure um oftalmologista. Esta receita pertence ao paciente, que pode usá-la em qualquer ótica.</div>`);
}
function gerarHtmlAtestado(){
  const r = receitaAtual, p = pacienteDaReceita();
  const cid = r.cid ? `<div class="cid"><b>CID-10:</b> ${esc(r.cid.cid)} — ${esc(r.cid.desc)}</div>` : '';
  return paginaDoc('Atestado', `${pacienteDocHtml()}<div style="margin-top:22px;"><p class="texto">${esc(r.atestadoTexto)}</p></div>${cid}<div class="rodape">${localDataDocHtml()}${assinaturaDocHtml()}</div>`);
}
function gerarHtmlDeclaracao(){
  return paginaDoc('Declaração de Comparecimento', `${pacienteDocHtml()}<div style="margin-top:22px;"><p class="texto">${esc(receitaAtual.declaracaoTexto)}</p></div><div class="rodape">${localDataDocHtml()}${assinaturaDocHtml()}</div>`);
}

/* mesma lógica das versões em texto, usadas no WhatsApp */
function textoCarimbo(){
  const prof = profissionalSelecionado();
  if(!prof) return '';
  return `\n\n${prof.carimbo_texto || prof.nome}${prof.registro_conselho? '\n'+prof.registro_conselho : ''}`;
}
function gerarTextoReceita(){
  const p = pacienteDaReceita(); const nome = p? p.nome_completo : '';
  const r = receitaAtual;
  const f = o=>`Esf ${o.esf||'-'} | Cil ${o.cil||'-'} | Eixo ${o.eixo? o.eixo+'°':'-'}`;
  return `*RECEITA DE ÓCULOS*\n${clinicaAtual?.nome_fantasia||''}\n\nPaciente: ${nome}\nData: ${fmtData(new Date().toISOString())}\n\n*LONGE*\nOD: ${f(r.longe.od)}\nOE: ${f(r.longe.oe)}\n\n*PERTO*\nOD: ${f(r.perto.od)}\nOE: ${f(r.perto.oe)}\n\n${(r.extras.dp||r.extras.dnpOd||r.extras.dnpOe) ? 'DP: '+(r.extras.dp||'-')+' mm | DNP OD: '+(r.extras.dnpOd||'-')+' | OE: '+(r.extras.dnpOe||'-')+'\n' : ''}Adição: ${r.adicao||'-'}\nTipo de lente: ${r.tipoLente}\nTratamentos: ${r.tratamentos.join(', ')||'-'}${textoCarimbo()}\n\n_Este exame de refração não substitui a consulta com médico oftalmologista. Em caso de dor, perda de visão ou suspeita de doença nos olhos, procure um oftalmologista. Esta receita pertence ao paciente, que pode usá-la em qualquer ótica._`;
}
function gerarTextoAtestado(){
  const p = pacienteDaReceita(); const nome = p? p.nome_completo : '';
  const cidTxt = receitaAtual.cid? `\nCID-10: ${receitaAtual.cid.cid} (${receitaAtual.cid.desc})` : '';
  return `*ATESTADO*\n${clinicaAtual?.nome_fantasia||''}\n\nPaciente: ${nome}\nData: ${fmtData(new Date().toISOString())}\n\n${receitaAtual.atestadoTexto}${cidTxt}${textoCarimbo()}`;
}

/* Abre a impressão num quadro invisível, depois que as imagens (logo, assinatura) carregam. */
function imprimirDocumento(html){
  const f = document.createElement('iframe');
  f.setAttribute('aria-hidden','true');
  const fo = medidasFolha();
  f.style.cssText = `position:fixed;left:-9999px;top:0;width:${fo.l}mm;height:${fo.a}mm;border:0;`;
  document.body.appendChild(f);
  const d = f.contentWindow.document;
  d.open(); d.write(html); d.close();
  const imgs = [...d.images];
  const prontas = Promise.all(imgs.map(i=> i.complete ? null : new Promise(ok=>{ i.onload = i.onerror = ok; })));
  const limite = new Promise(ok=>setTimeout(ok, 2500));
  Promise.race([prontas, limite]).then(()=>{
    try{ f.contentWindow.focus(); f.contentWindow.print(); }
    catch(e){ toast('Não consegui abrir a impressão. Tente de novo.'); console.error(e); }
    setTimeout(()=>f.remove(), 60000);
  });
}
/* compatibilidade com o gabarito do prontuário, que ainda usa o nome antigo */
function imprimir(html){ imprimirDocumento(`<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><title>Documento</title><style>body{font-family:Arial,sans-serif;padding:14mm;}</style></head><body>${html}</body></html>`); }

function abrirWhatsapp(telefone, texto){
  let tel = (telefone||'').replace(/\D/g,'');
  if(tel.startsWith('55') && tel.length>=12) tel = tel.slice(2);
  if(tel.length < 10){ toast('Esse paciente está sem telefone com DDD. Edite o cadastro dele.'); return; }
  const url = `https://api.whatsapp.com/send?phone=55${tel}&text=${encodeURIComponent(texto)}`;
  const w = window.open(url, '_blank');
  if(!w) location.href = url; // navegador bloqueou a nova aba
}
function enviarWhatsapp(texto){ const p = pacienteDaReceita(); abrirWhatsapp(p ? p.telefone : '', texto); }


/* ========================= AGENDA DO EVENTO ========================= */
/* O administrador abre os dias e horários do evento (Master). O agendador só marca pacientes
   dentro desses horários e não enxerga mais nada do sistema. */
let agendaEstado = { unidadeId:'', dia:'' };
const STATUS_AGENDA = { agendado:'Agendado', confirmado:'Confirmado', realizado:'Atendido', faltou:'Não compareceu', cancelado:'Cancelado' };

async function renderAgendaEvento(main){
  const ehAdminOuProf = usuarioAtual?.papel !== 'atendente';
  const minha = minhaUnidade();
  if(!agendaEstado.unidadeId) agendaEstado.unidadeId = minha ? minha.id : (unidades[0]?.id || '');
  const unidSel = ehAdminOuProf && !minha && unidades.length > 1
    ? `<label>Cidade do exame de vista</label><select id="agUn">${unidades.map(u=>`<option value="${u.id}" ${u.id===agendaEstado.unidadeId?'selected':''}>${esc(u.nome)}</option>`).join('')}</select>` : '';
  main.innerHTML = `<div class="card"><h2>Agenda de exame de vista</h2>
    <p class="sub" id="agTitulo">${esc((unidades.find(u=>u.id===agendaEstado.unidadeId)||{}).nome || '')}</p>${unidSel}
    <div id="agCorpo"><p class="sub">Carregando...</p></div></div>`;
  const sel = document.getElementById('agUn');
  if(sel) sel.onchange = e=>{ agendaEstado.unidadeId = e.target.value; agendaEstado.dia = ''; renderAgendaEvento(main); };

  const corpo = document.getElementById('agCorpo');
  let slots = [];
  try{ slots = await api(`/agendas/horarios${agendaEstado.unidadeId && ehAdminOuProf ? '?unidade_id='+agendaEstado.unidadeId : ''}`); }
  catch(e){ corpo.innerHTML = `<p class="fieldmsg bad">${esc(e.message)}</p>`; return; }
  if(!slots.length){
    corpo.innerHTML = `<div class="empty"><div class="ic">📅</div>${ehAdminOuProf ? 'Nenhum horário aberto. Abra os dias do exame de vista em Master, no cartão "Agenda de exame de vista".' : 'O administrador ainda não abriu horários para este exame de vista.'}</div>`;
    return;
  }
  const dias = [...new Set(slots.map(s=>s.data))];
  const hoje = new Date().toISOString().slice(0,10);
  if(!dias.includes(agendaEstado.dia)) agendaEstado.dia = dias.find(d=>d>=hoje) || dias[0];
  const doDia = slots.filter(s=>s.data===agendaEstado.dia);
  const ocupados = doDia.filter(s=>s.agendamento).length;
  const confirmados = doDia.filter(s=>s.agendamento?.status==='confirmado').length;
  const abas = dias.map(d=>`<button class="btn ${d===agendaEstado.dia?'btn-primary':'btn-outline'} btn-sm" data-dia="${d}" style="margin:0 6px 6px 0;width:auto;">${['dom','seg','ter','qua','qui','sex','sáb'][new Date(d+'T12:00:00').getDay()]} ${fmtData(d).slice(0,5)}</button>`).join('');
  corpo.innerHTML = `<div style="margin:6px 0 10px;">${abas}</div>
    <p class="sub">${fmtData(agendaEstado.dia)} · ${doDia.length - ocupados} livre(s) · ${ocupados} marcado(s) · ${confirmados} confirmado(s) · ${Math.round(ocupados/doDia.length*100)}% de ocupação${doDia[0].local ? ' · '+esc(doDia[0].local) : ''}</p>
    <div class="check-grid" style="grid-template-columns:repeat(auto-fill,minmax(150px,1fr));">${doDia.map((s,i)=> s.agendamento
      ? `<button class="check-item" data-i="${i}" style="justify-content:flex-start;flex-direction:column;align-items:flex-start;cursor:pointer;background:var(--teal-100);"><b>${s.hora}</b><span style="font-size:12px;">${esc(s.agendamento.paciente_nome)}</span><span style="font-size:11px;color:var(--ink-soft);">${STATUS_AGENDA[s.agendamento.status]||s.agendamento.status}</span></button>`
      : `<button class="check-item" data-i="${i}" style="justify-content:flex-start;flex-direction:column;align-items:flex-start;cursor:pointer;"><b>${s.hora}</b><span style="font-size:12px;color:#116A4F;">Livre</span></button>`).join('')}</div>`;
  corpo.querySelectorAll('button[data-dia]').forEach(b=> b.onclick = ()=>{ agendaEstado.dia = b.dataset.dia; renderAgendaEvento(main); });
  corpo.querySelectorAll('button[data-i]').forEach(b=> b.onclick = ()=>{
    const s = doDia[+b.dataset.i];
    if(s.agendamento) abrirHorarioOcupado(s, main); else abrirMarcarHorario(s, main);
  });
}

function normNome(t){ return String(t||'').normalize('NFD').replace(/[̀-ͯ]/g,'').toLowerCase().replace(/\s+/g,' ').trim(); }
function soDigitos(t){ return String(t||'').replace(/\D/g,''); }

function mensagemConfirmacao(nome, slot){
  const primeiro = String(nome||'').trim().split(/\s+/)[0];
  const un = (unidades.find(u=>u.id===slot.unidade_id)||{}).nome;
  const local = slot.local || clinicaAtual?.local_exame_padrao || '';
  return `Olá, ${primeiro}! Seu exame de vista na ${clinicaAtual?.nome_fantasia||'clínica'} está marcado.${un?` Cidade: ${un}.`:''} Dia ${fmtData(slot.data)} às ${slot.hora}.${local?` Local: ${local}.`:''} Responda SIM para confirmar.`;
}

function abrirMarcarHorario(slot, main){
  openModal(`
    <h2>${fmtData(slot.data)} às ${slot.hora}</h2>
    <p class="sub">${esc(slot.tipo_nome)}${slot.local ? ' · '+esc(slot.local) : ''}</p>
    <div class="foto-atalhos">
      <button type="button" class="btn btn-outline" id="mhFotoDocBtn">📷 Fotografar documento</button>
      <button type="button" class="btn btn-outline" id="mhFotoRecBtn">📷 Fotografar receita</button>
      <input type="file" id="mhFotoDoc" accept="image/*" capture="environment" style="display:none">
      <input type="file" id="mhFotoRec" accept="image/*" capture="environment" style="display:none">
    </div>
    <p class="sub" id="mhFotoMsg">Com a foto do RG ou CNH o sistema preenche o nome. Confira antes de marcar.</p>
    <label>Já é paciente? Digite o nome ou o telefone</label>
    <input type="text" id="mhBusca" placeholder="Comece a digitar..." autocomplete="off">
    <div id="mhAchados"></div>
    <div id="mhEscolhido" style="display:none;" class="sugestao-chip"></div>
    <p class="sub" style="margin:10px 0 2px;" id="mhOuNovo">Se não aparecer, cadastre um novo:</p>
    <label>Nome completo</label><input type="text" id="mhNome" placeholder="Nome do paciente">
    <label>Telefone (WhatsApp)</label><input type="tel" inputmode="tel" id="mhTel" placeholder="(64) 99999-9999">
    <p class="fieldmsg bad" id="mhSemTel" style="display:none;">Sem telefone, este paciente não vai receber lembrete de WhatsApp.</p>
    ${oticaSelectHtml('mhOtica')}
    <label>Observações</label><textarea id="mhObs"></textarea>
    <div class="btn-row"><button class="btn btn-primary" id="mhSalvar">Marcar</button><button class="btn btn-outline" onclick="closeModal()">Cancelar</button></div>
    <p id="mhErr" style="color:#C1462F;font-size:12.5px;margin-top:8px;"></p>`);

  let escolhido = null;   // paciente já cadastrado
  let extras = {};        // dados lidos das fotos (cpf, nascimento, receita)
  const elTel = document.getElementById('mhTel'), elNome = document.getElementById('mhNome');
  elTel.addEventListener('input', e=>{ e.target.value = maskTelefone(e.target.value); avisoTel(); });
  elNome.addEventListener('input', avisoTel);
  function avisoTel(){
    const falta = !escolhido && elNome.value.trim() && soDigitos(elTel.value).length < 10;
    document.getElementById('mhSemTel').style.display = falta ? 'block' : 'none';
  }

  /* busca de paciente por nome ou telefone */
  const achados = document.getElementById('mhAchados'), chip = document.getElementById('mhEscolhido');
  function escolher(p){
    escolhido = p;
    achados.innerHTML = ''; document.getElementById('mhBusca').value = '';
    chip.style.display = 'block';
    chip.innerHTML = `Paciente: <b>${esc(p.nome_completo)}</b>${p.telefone?' · '+esc(p.telefone):''} <button type="button" class="dispensar" id="mhTrocar">trocar</button>`;
    document.getElementById('mhTrocar').onclick = ()=>{ escolhido = null; chip.style.display='none'; avisoTel(); };
    avisoTel();
  }
  document.getElementById('mhBusca').addEventListener('input', e=>{
    const q = normNome(e.target.value), qd = soDigitos(e.target.value);
    if(q.length < 2 && qd.length < 4){ achados.innerHTML = ''; return; }
    const lista = pacientes.filter(p=> normNome(p.nome_completo).includes(q) || (qd.length>=4 && soDigitos(p.telefone).includes(qd))).slice(0,6);
    achados.innerHTML = lista.length
      ? lista.map(p=>`<button type="button" class="btn btn-outline btn-block" data-pid="${p.id}" style="text-align:left;margin-top:6px;">${esc(p.nome_completo)}${p.telefone?'<br><span style="font-size:12px;color:var(--ink-soft);">'+esc(p.telefone)+'</span>':''}</button>`).join('')
      : '<p class="sub">Ninguém com esse nome. Cadastre abaixo.</p>';
    achados.querySelectorAll('button[data-pid]').forEach(b=> b.onclick = ()=> escolher(pacientes.find(p=>p.id===b.dataset.pid)));
  });

  /* fotos */
  const fMsg = document.getElementById('mhFotoMsg');
  function ligarFoto(btnId, inId, tratar){
    const btn = document.getElementById(btnId), inp = document.getElementById(inId);
    btn.onclick = ()=> inp.click();
    inp.onchange = async ()=>{
      const f = inp.files[0]; if(!f) return;
      const rot = btn.textContent; btn.disabled = true; btn.textContent = 'Lendo...';
      fMsg.style.color = ''; fMsg.textContent = 'Lendo a foto. Aguarde alguns segundos.';
      try{ await tratar(await reduzirImagem(f, 1280, 0.7)); }
      catch(e){ fMsg.style.color = '#C1462F'; fMsg.textContent = e.message || 'Não consegui ler a foto.'; }
      btn.disabled = false; btn.textContent = rot; inp.value = '';
    };
  }
  ligarFoto('mhFotoDocBtn','mhFotoDoc', async url=>{
    const d = await lerDocumentoPorFoto(url);
    if(d.cpf_ilegivel){ fMsg.style.color = '#C1462F'; fMsg.textContent = 'O CPF saiu com número errado. Tire a foto de novo.'; return; }
    const jaCadastrado = d.cpf ? pacientes.find(p=>soDigitos(p.cpf)===d.cpf) : null;
    if(jaCadastrado){ escolher(jaCadastrado); fMsg.style.color = '#2e9d5b'; fMsg.textContent = 'Esse paciente já está cadastrado. Selecionei ele.'; return; }
    if(d.nome_completo){ elNome.value = d.nome_completo; elNome.classList.add('campo-lido'); }
    if(d.cpf) extras.cpf = maskCpf(d.cpf);
    if(d.data_nascimento) extras.data_nascimento = d.data_nascimento;
    avisoTel();
    fMsg.style.color = d.nome_completo ? '#2e9d5b' : '#C1462F';
    fMsg.textContent = d.nome_completo ? 'Li o nome'+(d.cpf?' e o CPF':'')+'. Confira com o documento e digite o telefone.' : 'Não consegui ler o nome. Tire a foto de novo, reta e com boa luz, ou digite.';
  });
  ligarFoto('mhFotoRecBtn','mhFotoRec', async url=>{
    extras.foto_receita_url = url;
    let dados = null;
    try{ dados = (await lerPorIA('receita', url)).dados; }
    catch(e){ if(!/não está ligada/i.test(e.message||'')) throw e; }
    const t = dados ? textoReceita(dados) : '';
    extras.receita_status = t ? 'digitar' : 'foto';
    if(t) extras.receita_digitada = t;
    fMsg.style.color = t ? '#2e9d5b' : '#b26a00';
    fMsg.textContent = t ? 'Li o grau e guardei a foto na ficha. Quem for atender confere.' : 'A foto da receita ficou guardada na ficha do paciente.';
  });

  let pidCriado = null; // se o horário falhar depois de criar o paciente, a nova tentativa usa o mesmo paciente
  document.getElementById('mhSalvar').onclick = async (ev)=>{
    const btn = ev.currentTarget; if(btn.disabled) return;
    const err = document.getElementById('mhErr'); err.textContent = '';
    let pid = (escolhido && escolhido.id) || pidCriado;
    const nome = elNome.value.trim();
    const tel = elTel.value.trim();
    if(!pid){
      if(!nome){ err.textContent = 'Escolha um paciente ou digite o nome.'; return; }
      if(tel && ![10,11].includes(soDigitos(tel).length)){ err.textContent = 'Telefone incompleto. Use DDD + número.'; return; }
      // evita cadastro repetido
      const igual = pacientes.find(p=> (soDigitos(tel).length>=10 && soDigitos(p.telefone)===soDigitos(tel)) || normNome(p.nome_completo)===normNome(nome));
      if(igual && confirm(`Já existe "${igual.nome_completo}"${igual.telefone?' ('+igual.telefone+')':''}. Usar esse cadastro?`)){ escolher(igual); pid = igual.id; }
      else if(!tel && !confirm('Sem telefone, o paciente não recebe lembrete de WhatsApp. Marcar mesmo assim?')) return;
    }
    btn.disabled = true;
    try{
      if(!pid){
        const corpo = { nome_completo: nome, telefone: tel||null, agendado_por: usuarioAtual?.nome||'' };
        if(extras.cpf) corpo.cpf = extras.cpf;
        if(extras.data_nascimento) corpo.data_nascimento = extras.data_nascimento;
        if(extras.foto_receita_url){ corpo.foto_receita_url = extras.foto_receita_url; corpo.dados_extras = { receita_status: extras.receita_status, receita_digitada: extras.receita_digitada||'' }; }
        const novo = await api('/pacientes', { method:'POST', body: corpo });
        pacientes.push(novo); pid = novo.id; pidCriado = novo.id;
      }
      const ag = await api('/agendamentos', { method:'POST', body:{ paciente_id: pid, tipo_atendimento_id: slot.tipo_atendimento_id, unidade_id: slot.unidade_id, data_hora: slot.data_hora, local: slot.local || clinicaAtual?.local_exame_padrao || '', agendado_por: usuarioAtual?.nome||'', observacoes: document.getElementById('mhObs').value, otica_parceira_id: (document.getElementById('mhOtica')||{}).value || null } });
      const pac = pacientes.find(p=>p.id===pid) || {};
      mostrarMarcado(slot, pac, ag, main);
    }catch(e){ err.textContent = e.message; btn.disabled = false; }
  };
}

/* depois de marcar: oferece mandar a confirmação pelo WhatsApp na hora */
function mostrarMarcado(slot, pac, ag, main){
  const tel = soDigitos(pac.telefone);
  const auto = !!clinicaAtual?.whatsapp_auto;
  openModal(`
    <h2>Horário marcado</h2>
    <p class="sub"><b>${esc(pac.nome_completo||'')}</b><br>${fmtData(slot.data)} às ${slot.hora}</p>
    ${tel.length>=10 && !auto ? `<button class="btn btn-wpp btn-block" id="mmZap">Enviar confirmação pelo WhatsApp</button>` : ''}
    ${tel.length<10 ? '<p class="fieldmsg bad">Paciente sem telefone. Ele não vai receber lembrete.</p>' : ''}
    ${auto && tel.length>=10 ? '<p class="sub">O WhatsApp automático vai avisar o paciente.</p>' : ''}
    <div class="btn-row" style="margin-top:10px;"><button class="btn btn-primary" id="mmOk">Pronto</button></div>`);
  const fechar = ()=>{ closeModal(); renderAgendaEvento(main); };
  document.getElementById('mmOk').onclick = fechar;
  const z = document.getElementById('mmZap');
  if(z) z.onclick = async ()=>{
    abrirWhatsapp(pac.telefone, mensagemConfirmacao(pac.nome_completo, slot));
    if(ag && ag.id){ try{ await api(`/envios/${ag.id}/marcar`, { method:'POST', body:{ etapa:'confirmacao', enviado:true } }); }catch(e){} }
    toast('WhatsApp aberto. Toque em enviar lá.');
    z.disabled = true; z.textContent = 'Confirmação aberta';
  };
}

function abrirHorarioOcupado(slot, main){
  const a = slot.agendamento;
  const tel = soDigitos(a.telefone);
  openModal(`
    <h2>${slot.hora} · ${esc(a.paciente_nome)}</h2>
    <p class="sub">${fmtData(slot.data)} · ${esc(STATUS_AGENDA[a.status]||a.status)}</p>
    ${tel.length>=10 ? `<p style="margin:4px 0 10px;"><b>${esc(a.telefone)}</b></p>
    <div class="btn-row"><button class="btn btn-wpp" id="hoZap">Chamar no WhatsApp</button><a class="btn btn-outline" href="tel:+55${tel}" style="text-align:center;text-decoration:none;">Ligar</a></div>` : '<p class="fieldmsg bad">Sem telefone cadastrado.</p>'}
    <label style="margin-top:12px;">Situação</label>
    <select id="hoStatus">${Object.entries(STATUS_AGENDA).map(([k,v])=>`<option value="${k}" ${k===a.status?'selected':''}>${v}</option>`).join('')}</select>
    <div class="btn-row"><button class="btn btn-primary" id="hoSalvar">Salvar</button><button class="btn btn-outline" onclick="closeModal()">Fechar</button></div>
    <button class="btn btn-danger btn-block" id="hoCancelar" style="margin-top:14px;">Cancelar este horário</button>
    <p class="sub" style="margin-top:6px;">Cancelar libera o horário para outro paciente.</p>`);
  const zap = document.getElementById('hoZap');
  if(zap) zap.onclick = ()=> abrirWhatsapp(a.telefone, `Olá, ${String(a.paciente_nome||'').split(' ')[0]}! Aqui é da ${clinicaAtual?.nome_fantasia||'clínica'}, sobre o seu exame de vista do dia ${fmtData(slot.data)} às ${slot.hora}.`);
  async function mudar(status, msg){
    try{ await api(`/agendamentos/${a.id}/status`, { method:'PATCH', body:{ status } }); closeModal(); toast(msg); renderAgendaEvento(main); if(status==='cancelado') setTimeout(avisarListaEspera, 2600); }
    catch(e){ erroApi(e); }
  }
  document.getElementById('hoSalvar').onclick = ()=> mudar(document.getElementById('hoStatus').value, 'Situação atualizada.');
  document.getElementById('hoCancelar').onclick = ()=>{ if(confirm('Cancelar o horário de '+a.paciente_nome+'?')) mudar('cancelado', 'Horário cancelado e liberado.'); };
}

/* opções de duração e de intervalo (o valor vazio usa o do tipo de atendimento) */
const DURACOES_EXAME = [10,15,20,25,30,40,45,60];
const INTERVALOS_EXAME = [0,5,10,15];
function opcoesDuracao(sel){
  const v = (sel===null||sel===undefined) ? '' : String(sel);
  const lista = DURACOES_EXAME.slice(); if(v!=='' && !lista.includes(+v)) lista.push(+v);
  return '<option value="">Padrão do tipo de atendimento</option>' + lista.sort((a,b)=>a-b).map(n=>`<option value="${n}" ${String(n)===v?'selected':''}>${n} minutos</option>`).join('');
}
function opcoesIntervalo(sel){
  const v = (sel===null||sel===undefined) ? '' : String(sel);
  const lista = INTERVALOS_EXAME.slice(); if(v!=='' && !lista.includes(+v)) lista.push(+v);
  return '<option value="">Padrão do tipo de atendimento</option>' + lista.sort((a,b)=>a-b).map(n=>`<option value="${n}" ${String(n)===v?'selected':''}>${n===0?'Sem intervalo':n+' minutos'}</option>`).join('');
}
/* conta quantos horários uma agenda gera (mesma regra do servidor) */
function contarHorariosAgenda(ini, fim, dur, buf, alI, alF){
  if(!ini || !fim || !dur) return 0;
  const m = (h)=>{ const [a,b]=h.split(':').map(Number); return a*60+b; };
  const passo = dur + buf, a = m(ini), z = m(fim), temAl = alI && alF, i0 = temAl ? m(alI) : 0, f0 = temAl ? m(alF) : 0;
  let n = 0;
  for(let t=a; t+dur<=z; t+=passo){
    if(temAl && t < f0 && t+dur > i0){ t = Math.max(t, f0-passo); continue; }
    n++;
  }
  return n;
}
function textoPrevAgenda(ini, fim, durSel, bufSel, alI, alF, tipoId){
  const tp = tiposAtendimento.find(t=>t.id===tipoId) || tiposAtendimento[0];
  const dur = durSel!=='' ? +durSel : (tp ? tp.duracao_min : 0);
  const buf = bufSel!=='' ? +bufSel : (tp ? (tp.buffer_min||0) : 0);
  const n = contarHorariosAgenda(ini, fim, dur, buf, alI, alF);
  return n ? `Isso gera ${n} horários (${dur} min cada${buf?' + '+buf+' min de intervalo':', sem intervalo'}).` : 'Esses horários não geram nenhum atendimento. Confira a hora e a duração.';
}

/* cartão do Master: o administrador abre os dias e horários do evento */
function feriadosLocaisCardHtml(){
  return `<div class="card"><h2>Feriados da cidade</h2>
    <p class="sub">Cadastre o aniversário da cidade, folgas e eventos locais. Eles aparecem no calendário. Os feriados nacionais já vêm prontos.</p>
    <div id="flLista"></div>
    <div class="row2"><div><label>Data</label><input type="date" id="flData"></div><div><label>Nome</label><input type="text" id="flNome" placeholder="Aniversário da cidade"></div></div>
    <label>Cidade</label><select id="flUnidade"><option value="">Todas as cidades</option>${unidades.map(u=>`<option value="${u.id}">${esc(u.nome)}</option>`).join('')}</select>
    <button class="btn btn-ghost btn-block" id="flAdd" style="margin-top:10px;">+ Adicionar feriado</button></div>`;
}
function ligarFeriadosLocais(){
  const lista = document.getElementById('flLista'); if(!lista) return;
  const desenhar = ()=>{
    lista.innerHTML = feriadosLocais.length ? feriadosLocais.map(f=>`<div class="list-item"><div><div class="name">${esc(fmtData(f.data))} · ${esc(f.nome)}</div><div class="meta">${esc(f.cidade||'Todas as cidades')}</div></div><button class="btn btn-danger btn-sm" data-fl="${f.id}">Remover</button></div>`).join('') : '<p class="sub">Nenhum feriado local cadastrado.</p>';
    lista.querySelectorAll('[data-fl]').forEach(b=> b.onclick = async ()=>{ try{ await api('/feriados-locais/'+b.dataset.fl, { method:'DELETE' }); feriadosLocais = feriadosLocais.filter(x=>x.id!==b.dataset.fl); desenhar(); }catch(e){ erroApi(e); } });
  };
  desenhar();
  document.getElementById('flAdd').onclick = async ()=>{
    try{
      await api('/feriados-locais', { method:'POST', body:{ data: document.getElementById('flData').value, nome: document.getElementById('flNome').value, unidade_id: document.getElementById('flUnidade').value || null } });
      feriadosLocais = await api('/feriados-locais'); document.getElementById('flNome').value = ''; desenhar(); toast('Feriado adicionado.');
    }catch(e){ erroApi(e); }
  };
}
function agendaMasterCardHtml(){
  return `<div class="card"><h2>Agenda de exame de vista</h2>
    <p class="sub">Abra aqui os dias e horários. O agendador só consegue marcar pacientes dentro deles.</p>
    <div id="listaAgendas"><p class="sub">Carregando...</p></div>
    ${unidades.length ? `
    <label style="margin-top:12px;">Cidade do exame de vista</label>
    <select id="agmUn">${unidades.map(u=>`<option value="${u.id}">${esc(u.nome)}</option>`).join('')}</select>
    <div class="row2"><div><label>Primeiro dia</label><input type="date" id="agmData"></div><div><label>Último dia <span style="font-weight:400;color:var(--ink-soft);">(opcional)</span></label><input type="date" id="agmDataFim"></div></div>
    <div class="row2"><div><label>Das</label><input type="time" id="agmIni" value="08:00"></div><div><label>Até</label><input type="time" id="agmFim" value="17:00"></div></div>
    <label>Tipo de atendimento</label>
    <select id="agmTipo">${tiposAtendimento.map(t=>`<option value="${t.id}">${esc(t.nome)} · ${t.duracao_min} min</option>`).join('')}</select>
    <label>Duração de cada exame</label>
    <select id="agmDur">${opcoesDuracao('')}</select>
    <label>Intervalo entre os exames</label>
    <select id="agmBuf">${opcoesIntervalo('')}</select>
    <label>Pausa de almoço <span style="font-weight:400;color:var(--ink-soft);">(opcional, não gera horários nesse período)</span></label>
    <div class="row2"><div><input type="time" id="agmAlmIni" placeholder="Início"></div><div><input type="time" id="agmAlmFim" placeholder="Fim"></div></div>
    <p class="sub" id="agmAlmDica">Deixe os dois vazios para não ter pausa.</p>
    <p class="sub" id="agmPrev" style="font-weight:700;"></p>
    <label>Local <span style="font-weight:400;color:var(--ink-soft);">(opcional)</span></label><input type="text" id="agmLocal" value="${esc(clinicaAtual?.local_exame_padrao||'')}">
    <button class="btn btn-ghost btn-block" id="agmCriar" style="margin-top:10px;">+ Abrir horários</button>` : '<p class="sub">Cadastre primeiro uma cidade no cartão acima.</p>'}
  </div>`;
}
/* muda uma agenda que já existe, sem apagar (só enquanto não houver paciente marcado) */
function editarAgenda(a, recarregar){
  if(!a) return;
  const hh = (t)=> String(t||'').slice(0,5);
  openModal(`<h2>Mudar a agenda de ${fmtData(a.data)}</h2>
    <p class="sub">${esc(a.unidade_nome)}. Só dá para mudar enquanto não houver paciente marcado.</p>
    <div class="row2"><div><label>Das</label><input type="time" id="edIni" value="${hh(a.hora_inicio)}"></div><div><label>Até</label><input type="time" id="edFim" value="${hh(a.hora_fim)}"></div></div>
    <label>Tipo de atendimento</label>
    <select id="edTipo">${tiposAtendimento.map(t=>`<option value="${t.id}" ${t.id===a.tipo_atendimento_id?'selected':''}>${esc(t.nome)} · ${t.duracao_min} min</option>`).join('')}</select>
    <label>Duração de cada exame</label>
    <select id="edDur">${opcoesDuracao(a.duracao_min)}</select>
    <label>Intervalo entre os exames</label>
    <select id="edBuf">${opcoesIntervalo(a.buffer_agenda)}</select>
    <label>Pausa de almoço <span style="font-weight:400;color:var(--ink-soft);">(opcional)</span></label>
    <div class="row2"><div><input type="time" id="edAlIni" value="${hh(a.almoco_inicio)}"></div><div><input type="time" id="edAlFim" value="${hh(a.almoco_fim)}"></div></div>
    <label>Local <span style="font-weight:400;color:var(--ink-soft);">(opcional)</span></label><input type="text" id="edLocal" value="${esc(a.local||'')}">
    <p class="sub" id="edPrev" style="font-weight:700;margin-top:8px;"></p>
    <div class="btn-row"><button class="btn btn-primary" id="edSalvar">Salvar</button><button class="btn btn-outline" onclick="closeModal()">Fechar</button></div>`);
  const v = (id)=> document.getElementById(id).value;
  const prev = ()=>{ document.getElementById('edPrev').textContent = textoPrevAgenda(v('edIni'), v('edFim'), v('edDur'), v('edBuf'), v('edAlIni'), v('edAlFim'), v('edTipo')); };
  ['edIni','edFim','edTipo','edDur','edBuf','edAlIni','edAlFim'].forEach(id=>{ const e=document.getElementById(id); e.addEventListener('input',prev); e.addEventListener('change',prev); });
  prev();
  document.getElementById('edSalvar').onclick = async ()=>{
    if((v('edAlIni') && !v('edAlFim')) || (!v('edAlIni') && v('edAlFim'))){ toast('Preencha o início e o fim do almoço, ou deixe os dois vazios.'); return; }
    try{
      await api('/agendas/'+a.id, { method:'PUT', body:{ hora_inicio:v('edIni'), hora_fim:v('edFim'), tipo_atendimento_id:v('edTipo'), duracao_min:v('edDur'), buffer_min:v('edBuf'), almoco_inicio:v('edAlIni')||null, almoco_fim:v('edAlFim')||null, local:v('edLocal') } });
      closeModal(); toast('Agenda atualizada.'); recarregar();
    }catch(e){ erroApi(e); }
  };
}

async function ligarAgendaMaster(main){
  const lista = document.getElementById('listaAgendas'); if(!lista) return;
  async function carregar(){
    try{
      const ags = await api('/agendas');
      lista.innerHTML = ags.length ? ags.map(a=>`<div class="list-item"><div><div class="name">${fmtData(a.data)} · ${a.hora_inicio.slice(0,5)} às ${a.hora_fim.slice(0,5)}</div><div class="meta">${esc(a.unidade_nome)} · ${esc(a.tipo_nome)} · ${a.total_horarios} horário(s) de ${a.duracao_efetiva} min · ${a.buffer_efetivo?a.buffer_efetivo+' min de intervalo':'sem intervalo'}${a.almoco_inicio?' · almoço '+a.almoco_inicio.slice(0,5)+' às '+a.almoco_fim.slice(0,5):''}</div></div><div style="display:flex;gap:6px;"><button class="btn btn-outline btn-sm" data-edit="${a.id}">Editar</button><button class="btn btn-danger btn-sm" data-del="${a.id}">Apagar</button></div></div>`).join('') : '<p class="sub">Nenhum horário aberto ainda.</p>';
      lista.querySelectorAll('button[data-edit]').forEach(b=> b.onclick = ()=> editarAgenda(ags.find(x=>x.id===b.dataset.edit), carregar));
      lista.querySelectorAll('button[data-del]').forEach(b=> b.onclick = async ()=>{
        if(!confirm('Apagar este dia da agenda?')) return;
        try{ await api(`/agendas/${b.dataset.del}`, { method:'DELETE' }); carregar(); }catch(e){ erroApi(e); }
      });
    }catch(e){ lista.innerHTML = `<p class="fieldmsg bad">${esc(e.message)}</p>`; }
  }
  carregar();
  function atualizarPrev(){
    const el = document.getElementById('agmPrev'); if(!el) return;
    const v = (id)=> document.getElementById(id).value;
    el.textContent = textoPrevAgenda(v('agmIni'), v('agmFim'), v('agmDur'), v('agmBuf'), v('agmAlmIni'), v('agmAlmFim'), v('agmTipo'));
  }
  ['agmIni','agmFim','agmDur','agmBuf','agmAlmIni','agmAlmFim','agmTipo'].forEach(id=>{ const e = document.getElementById(id); if(e){ e.addEventListener('input', atualizarPrev); e.addEventListener('change', atualizarPrev); } });
  atualizarPrev();
  const criar = document.getElementById('agmCriar');
  if(criar) criar.onclick = async ()=>{
    const body = { unidade_id: document.getElementById('agmUn').value, data: document.getElementById('agmData').value, data_fim: document.getElementById('agmDataFim').value || null,
      hora_inicio: document.getElementById('agmIni').value, hora_fim: document.getElementById('agmFim').value, tipo_atendimento_id: document.getElementById('agmTipo').value, local: document.getElementById('agmLocal').value,
      buffer_min: document.getElementById('agmBuf').value, duracao_min: document.getElementById('agmDur').value, almoco_inicio: document.getElementById('agmAlmIni').value || null, almoco_fim: document.getElementById('agmAlmFim').value || null };
    if((body.almoco_inicio && !body.almoco_fim) || (!body.almoco_inicio && body.almoco_fim)){ toast('Preencha o início e o fim do almoço, ou deixe os dois vazios.'); return; }
    if(!body.data){ toast('Escolha o primeiro dia.'); return; }
    try{ await api('/agendas', { method:'POST', body }); toast('Horários abertos.'); carregar(); }catch(e){ erroApi(e); }
  };
}


/* ========================= ENVIOS PROGRAMADOS ========================= */
let enviosAba = 'agora';
async function renderEnvios(main){
  main.innerHTML = `<div class="card"><h2>Envios programados</h2>
    <p class="sub">Mensagens de WhatsApp antes e depois do atendimento. Toque em WhatsApp: a conversa abre com o texto pronto.</p>
    <div id="envAbas" style="margin:6px 0 10px;"></div><div id="envCorpo"><p class="sub">Carregando...</p></div></div>`;
  let dados;
  try{ dados = await api('/envios'); }catch(e){ document.getElementById('envCorpo').innerHTML = `<p class="fieldmsg bad">${esc(e.message)}</p>`; return; }
  const abas = [['agora','Enviar agora',dados.agora],['programados','Programados',dados.programados],['enviados','Enviados',dados.enviados]];
  document.getElementById('envAbas').innerHTML = abas.map(([k,n,l])=>`<button class="btn ${k===enviosAba?'btn-primary':'btn-outline'} btn-sm" data-aba="${k}" style="margin:0 6px 6px 0;width:auto;">${n} (${l.length})</button>`).join('');
  document.querySelectorAll('#envAbas button').forEach(b=> b.onclick = ()=>{ enviosAba = b.dataset.aba; renderEnvios(main); });
  const lista = (abas.find(a=>a[0]===enviosAba) || abas[0])[2];
  const corpo = document.getElementById('envCorpo');
  if(!lista.length){ corpo.innerHTML = `<div class="empty"><div class="ic">📨</div>${enviosAba==='agora' ? 'Nenhuma mensagem para enviar agora.' : 'Nada por aqui.'}</div>`; return; }
  corpo.innerHTML = lista.map((e,i)=>`<div class="list-item"><div><div class="name">${esc(e.paciente_nome)}</div><div class="meta">${esc(e.etapa_nome)} · exame ${fmtData(e.data_hora)} às ${soHora(e.data_hora)}${e.devido_em && enviosAba==='programados' ? ' · sai em '+new Date(e.devido_em).toLocaleString('pt-BR',{day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'}) : ''}${e.telefone ? '' : ' · sem telefone'}</div></div>
    ${enviosAba==='agora' ? `<button class="btn btn-wpp btn-sm" data-i="${i}">WhatsApp</button>` : enviosAba==='enviados' ? `<button class="btn btn-outline btn-sm" data-undo="${i}">Desfazer</button>` : ''}</div>`).join('');
  corpo.querySelectorAll('button[data-i]').forEach(b=> b.onclick = async ()=>{
    const e = lista[+b.dataset.i];
    if(!e.telefone){ toast('Esse paciente está sem telefone.'); return; }
    abrirWhatsapp(e.telefone, e.mensagem);
    try{ await api(`/envios/${e.agendamento_id}/marcar`, { method:'POST', body:{ etapa:e.etapa, enviado:true } }); renderEnvios(main); }catch(er){ erroApi(er); }
  });
  corpo.querySelectorAll('button[data-undo]').forEach(b=> b.onclick = async ()=>{
    const e = lista[+b.dataset.undo];
    try{ await api(`/envios/${e.agendamento_id}/marcar`, { method:'POST', body:{ etapa:e.etapa, enviado:false } }); renderEnvios(main); }catch(er){ erroApi(er); }
  });
}

/* ========================= LISTA DE ESPERA ========================= */
async function renderEspera(main){
  main.innerHTML = `<div class="card"><h2>Lista de espera</h2><p class="sub">Pacientes que querem um horário mais cedo. Quando alguém cancelar, ofereça o horário pelo WhatsApp.</p>
    <div class="row2"><div><label>Nome</label><input type="text" id="leNome"></div><div><label>Telefone</label><input type="tel" id="leTel" inputmode="tel" placeholder="(64) 99999-9999"></div></div>
    ${usuarioAtual?.unidadeId ? '' : `<label>Cidade</label><select id="leUn"><option value="">Qualquer cidade</option>${unidades.map(u=>`<option value="${u.id}">${esc(u.nome)}</option>`).join('')}</select>`}
    <label>Observação (ex.: só de manhã)</label><input type="text" id="leObs">
    <button class="btn btn-primary btn-block" id="leAdd" style="margin-top:10px;">Colocar na lista</button>
    <div id="leLista" style="margin-top:14px;"><p class="sub">Carregando...</p></div></div>`;
  async function carregar(){
    const box = document.getElementById('leLista'); if(!box) return;
    let l; try{ l = await api('/lista-espera'); }catch(e){ box.innerHTML = `<p class="fieldmsg bad">${esc(e.message)}</p>`; return; }
    if(!l.length){ box.innerHTML = '<div class="empty"><div class="ic">⏳</div>Ninguém na lista de espera.</div>'; return; }
    box.innerHTML = l.map(x=>`<div class="list-item"><div><div class="name">${esc(x.nome)}</div><div class="meta">${esc(x.telefone||'sem telefone')}${x.cidade?' · '+esc(x.cidade):''}${x.observacao?' · '+esc(x.observacao):''}</div></div>
      <div style="display:flex;gap:6px;flex-wrap:wrap;">${x.telefone?`<button class="btn btn-wpp btn-sm" data-of="${x.id}">Oferecer horário</button>`:''}<button class="btn btn-outline btn-sm" data-rm="${x.id}">Tirar</button></div></div>`).join('');
    box.querySelectorAll('[data-of]').forEach(b=> b.onclick = ()=>{ const x = l.find(y=>y.id===b.dataset.of); abrirWhatsapp(x.telefone, `Olá, ${String(x.nome).split(' ')[0]}! Aqui é da ${clinicaAtual?.nome_fantasia||'clínica'}. Abriu um horário para o exame de vista${x.cidade?' em '+x.cidade:''}. Você ainda tem interesse? Responda aqui que eu reservo para você.`); });
    box.querySelectorAll('[data-rm]').forEach(b=> b.onclick = async ()=>{ try{ await api('/lista-espera/'+b.dataset.rm, { method:'DELETE' }); carregar(); }catch(e){ erroApi(e); } });
  }
  document.getElementById('leAdd').onclick = async ()=>{
    try{
      await api('/lista-espera', { method:'POST', body:{ nome: document.getElementById('leNome').value, telefone: document.getElementById('leTel').value, observacao: document.getElementById('leObs').value, unidade_id: document.getElementById('leUn')?.value || null } });
      ['leNome','leTel','leObs'].forEach(i=> document.getElementById(i).value=''); toast('Colocado na lista.'); carregar();
    }catch(e){ erroApi(e); }
  };
  carregar();
}
async function avisarListaEspera(){
  try{ const l = await api('/lista-espera'); if(l.length) toast(`Horário liberado. Há ${l.length} pessoa(s) na Lista de espera para oferecer.`); }catch(e){}
}

/* ========================= FILA DO DIA ========================= */
let filaTimer = null;
async function renderFila(main){
  clearInterval(filaTimer);
  const hoje = new Date().toISOString().slice(0,10);
  main.innerHTML = `<div class="card"><h2>Fila do dia</h2><p class="sub">Quem já chegou, quem espera e quem está sendo atendido. Atualiza sozinha a cada 30 segundos.</p><div id="filaCorpo"><p class="sub">Carregando...</p></div></div>
    <button class="btn btn-outline btn-block" id="filaEspera">Ver lista de espera</button>`;
  document.getElementById('filaEspera').onclick = ()=> switchView('espera');
  const podeIniciar = usuarioAtual?.papel !== 'atendente';
  async function acao(id, a){ try{ await api('/agendamentos/'+id+'/fila', { method:'POST', body:{ acao:a } }); carregar(); }catch(e){ erroApi(e); } }
  async function finalizar(id){ try{ await api('/agendamentos/'+id+'/status', { method:'PATCH', body:{ status:'realizado' } }); carregar(); }catch(e){ erroApi(e); } }
  async function carregar(){
    const corpo = document.getElementById('filaCorpo');
    if(!corpo){ clearInterval(filaTimer); return; }
    let lista; try{ lista = await api('/agendamentos/fila'); }catch(e){ corpo.innerHTML = `<p class="fieldmsg bad">${esc(e.message)}</p>`; return; }
    if(!lista.length){ corpo.innerHTML = '<div class="empty"><div class="ic">🪑</div>Nenhum paciente marcado para hoje.</div>'; return; }
    const grupos = [['atendendo','Em atendimento'],['aguardando','Aguardando'],['chegada_pendente','Ainda não chegou'],['atendido','Atendidos'],['faltou','Não compareceu']];
    const min = (t)=> Math.max(0, Math.round((Date.now() - new Date(String(t).replace(' ','T').slice(0,19)+'Z').getTime())/60000));
    corpo.innerHTML = grupos.map(([k,t])=>{
      const l = lista.filter(x=>x.fila===k); if(!l.length) return '';
      return `<h3 style="margin:14px 0 4px;font-size:15px;">${t} (${l.length})</h3>` + l.map(x=>{
        let info = soHora(x.data_hora) + (x.tipo_nome? ' · '+esc(x.tipo_nome):'');
        if(k==='aguardando' && x.chegou_em) info += ' · espera há '+min(x.chegou_em)+' min';
        let bts = '';
        if(k==='chegada_pendente') bts = `<button class="btn btn-primary btn-sm" data-f="chegou" data-id="${x.id}">Chegou</button>`;
        else if(k==='aguardando') bts = (podeIniciar? `<button class="btn btn-primary btn-sm" data-f="iniciar" data-id="${x.id}">Iniciar</button>`:'') + `<button class="btn btn-ghost btn-sm" data-f="voltar" data-id="${x.id}">Desfazer</button>`;
        else if(k==='atendendo') bts = podeIniciar ? `<button class="btn btn-primary btn-sm" data-f="finalizar" data-id="${x.id}">Finalizar</button>` : '';
        return `<div class="list-item"><div><div class="name">${esc(x.nome_completo)}</div><div class="meta">${info}</div></div><div style="display:flex;gap:6px;">${bts}</div></div>`;
      }).join('');
    }).join('');
    corpo.querySelectorAll('button[data-f]').forEach(b=> b.onclick = ()=> b.dataset.f==='finalizar' ? finalizar(b.dataset.id) : acao(b.dataset.id, b.dataset.f));
  }
  await carregar();
  filaTimer = setInterval(()=>{ if(document.getElementById('filaCorpo')) carregar(); else clearInterval(filaTimer); }, 30000);
}

/* ========================= RELATÓRIO DO DIA ========================= */
let relatorioData = new Date().toISOString().slice(0,10);
async function renderRelatorioDia(main){
  main.innerHTML = `${usuarioAtual?.papel!=='atendente' ? `<div class="card"><h2>Resumo por cidade</h2>
    <div class="row2"><div><label>De</label><input type="date" id="pcDe" value="${new Date().toISOString().slice(0,8)}01"></div><div><label>Até</label><input type="date" id="pcAte" value="${relatorioData}"></div></div>
    <div id="pcCorpo"><p class="sub">Carregando...</p></div></div>` : ''}<div class="card"><h2>Relatório do dia</h2>
    <label>Data</label><input type="date" id="relData" value="${relatorioData}" style="max-width:200px;">
    <div id="relCorpo"><p class="sub">Carregando...</p></div></div>`;
  document.getElementById('relData').onchange = e=>{ relatorioData = e.target.value; renderRelatorioDia(main); };
  if(document.getElementById('pcCorpo')){
    const carregarCidades = async ()=>{
      const corpo = document.getElementById('pcCorpo');
      try{
        const l = await api(`/relatorios/por-cidade?de=${document.getElementById('pcDe').value}&ate=${document.getElementById('pcAte').value}`);
        const adm = usuarioAtual?.papel==='admin';
        corpo.innerHTML = l.length ? `<div style="overflow-x:auto;"><table style="width:100%;font-size:13.5px;border-collapse:collapse;"><tr><th align="left">Cidade</th><th>Marcados</th><th>Atendidos</th><th>Faltas</th><th>Cancel.</th>${adm?'<th>Recebido</th><th>A receber</th>':''}</tr>${l.map(x=>`<tr><td>${esc(x.cidade)}</td><td align="center">${x.marcados}</td><td align="center">${x.atendidos}</td><td align="center">${x.faltas}</td><td align="center">${x.cancelados}</td>${adm?`<td align="right">${fmtMoeda(x.recebido)}</td><td align="right">${fmtMoeda(x.a_receber)}</td>`:''}</tr>`).join('')}</table></div>` : '<div class="empty"><div class="ic">📍</div>Nada nesse período.</div>';
      }catch(e){ corpo.innerHTML = `<p class="fieldmsg bad">${esc(e.message)}</p>`; }
    };
    document.getElementById('pcDe').onchange = carregarCidades; document.getElementById('pcAte').onchange = carregarCidades;
    carregarCidades();
  }
  let lista = [];
  try{ lista = await api(`/agendamentos?de=${relatorioData}&ate=${relatorioData}`); }
  catch(e){ document.getElementById('relCorpo').innerHTML = `<p class="fieldmsg bad">${esc(e.message)}</p>`; return; }
  const corpo = document.getElementById('relCorpo');
  if(!lista.length){ corpo.innerHTML = '<div class="empty"><div class="ic">📋</div>Nenhum agendamento nesse dia.</div>'; return; }
  const cont = st=> lista.filter(a=>a.status===st).length;
  const linhas = lista.map(a=>`<div class="list-item"><div><div class="name">${soHora(a.data_hora)} · ${esc(a.nome_completo)}</div><div class="meta">${esc(a.tipo_nome||'')} · ${esc(a.status)}${a.local? ' · '+esc(a.local):''}</div></div></div>`).join('');
  corpo.innerHTML = `<p class="sub">${lista.length} no total · ${cont('agendado')} agendado(s) · ${cont('confirmado')} confirmado(s) · ${cont('realizado')} realizado(s) · ${cont('cancelado')} cancelado(s)</p>${linhas}
    <button class="btn btn-amber btn-block" id="btnImprimirDia" style="margin-top:14px;">Imprimir relatório</button>`;
  document.getElementById('btnImprimirDia').onclick = ()=>{
    const trs = lista.map(a=>`<tr><td>${soHora(a.data_hora)}</td><td>${esc(a.nome_completo)}</td><td>${esc(a.tipo_nome||'')}</td><td>${esc(a.status)}</td></tr>`).join('');
    imprimirDocumento(paginaDoc('Agenda do dia '+fmtData(relatorioData), `<p style="font-family:Arial,sans-serif;font-size:10.5pt;">${lista.length} no total · ${cont('confirmado')} confirmado(s) · ${cont('realizado')} realizado(s) · ${cont('cancelado')} cancelado(s)</p><table class="lista"><tr><th>Hora</th><th>Paciente</th><th>Atendimento</th><th>Situação</th></tr>${trs}</table>`));
  };
}

/* ========================= RETORNOS E ANIVERSARIANTES ========================= */
/* ========================= PAINEL ========================= */
const fmtMoeda = v => Number(v||0).toLocaleString('pt-BR',{style:'currency',currency:'BRL'});
const ORIGENS = { equipe:'Equipe', whatsapp:'WhatsApp', portal:'Link online', otica:'Ótica parceira' };
function cartaoNumero(rotulo, valor, nota){
  return `<div class="card" style="margin:0;text-align:center;padding:14px 10px;"><div class="display" style="font-size:30px;color:var(--teal-900);line-height:1.1;">${valor}</div><div style="font-size:12.5px;font-weight:600;margin-top:4px;">${rotulo}</div>${nota?`<div class="sub" style="margin:2px 0 0;">${nota}</div>`:''}</div>`;
}
async function renderPainel(main){
  main.innerHTML = '<div class="card"><h2>Painel</h2><p class="sub">Carregando...</p></div>';
  let d;
  try{ d = await api('/relatorios/painel'); }
  catch(e){ main.innerHTML = `<div class="card"><h2>Painel</h2><p class="fieldmsg bad">${esc(e.message)}</p></div>`; return; }
  const grade = 'display:grid;grid-template-columns:repeat(auto-fit,minmax(130px,1fr));gap:10px;margin-bottom:14px;';
  let html = `<div class="card"><h2>Hoje</h2><div style="${grade}">
      ${cartaoNumero('Consultas', d.hoje.total)}${cartaoNumero('Confirmadas', d.hoje.confirmadas)}${cartaoNumero('Aguardando', d.hoje.aguardando)}</div></div>`;
  html += `<div class="card"><h2>Este mês</h2><div style="${grade}">
      ${cartaoNumero('Atendidos', d.mes.realizados)}
      ${cartaoNumero('Ocupação', d.mes.ocupacao==null?'-':d.mes.ocupacao+'%', d.mes.vagas?`${d.mes.marcados} de ${d.mes.vagas} horários`:'abra horários na agenda')}
      ${cartaoNumero('Não compareceram', d.mes.nao_comparecimento+'%', d.mes.faltaram+' faltas')}</div>`;
  if(d.faturamento){
    const f = d.faturamento;
    html += `<div style="${grade}">${cartaoNumero('Recebido no mês', fmtMoeda(f.mes))}${cartaoNumero('Mês passado', fmtMoeda(f.anterior))}${cartaoNumero('A receber', fmtMoeda(f.a_receber))}${cartaoNumero('Projeção do mês', fmtMoeda(f.projecao), 'no ritmo atual')}</div>`;
  }
  html += `</div>`;
  html += `<div class="card"><h2>De onde vêm os agendamentos</h2>${d.origens.length ? d.origens.map(o=>`<div class="list-item"><div class="name">${ORIGENS[o.origem]||esc(o.origem)}</div><div>${o.qtd}</div></div>`).join('') : '<p class="sub">Nenhum agendamento neste mês.</p>'}</div>`;
  html += `<div class="card"><h2>Próximas consultas</h2>${d.proximas.length ? d.proximas.map(a=>`<div class="list-item"><div><div class="name">${esc(a.nome_completo)}</div><div class="meta">${fmtData(a.data_hora)} às ${soHora(a.data_hora)} · ${esc(a.tipo_nome||'')} · ${esc(a.status)}</div></div></div>`).join('') : '<p class="sub">Nada marcado pela frente.</p>'}</div>`;
  html += `<div class="card"><h2>Receitas perto de vencer</h2><p class="sub">Receita emitida há 10 a 12 meses. Vale avisar o paciente.</p><div id="pnReceitas"></div></div>
    <div class="card"><h2>Retornos vencendo</h2><p class="sub">Último exame há 11 a 12 meses e nada marcado.</p><div id="pnRetornos"></div></div>`;
  main.innerHTML = html;
  const lista = (id, itens, dataCampo, texto)=>{
    const box = document.getElementById(id);
    if(!itens.length){ box.innerHTML = '<div class="empty"><div class="ic">✅</div>Ninguém por agora.</div>'; return; }
    box.innerHTML = itens.map((r,i)=>`<div class="list-item"><div><div class="name">${esc(r.nome_completo)}</div><div class="meta">${fmtData(r[dataCampo])} · ${esc(r.telefone||'sem telefone')}</div></div><button class="btn btn-wpp btn-sm" data-i="${i}">WhatsApp</button></div>`).join('');
    box.querySelectorAll('button[data-i]').forEach(b=> b.onclick = ()=>{ const r = itens[+b.dataset.i]; abrirWhatsapp(r.telefone, texto(r)); });
  };
  const nomeCli = clinicaAtual?.nome_fantasia||'clínica';
  lista('pnReceitas', d.receitas_vencendo, 'emissao', r=>`Olá, ${primeiroNome(r.nome_completo)}! Aqui é da ${nomeCli}. Sua receita de óculos está perto de completar 1 ano. Quer marcar um novo exame?`);
  lista('pnRetornos', d.retornos_vencendo, 'ultimo_exame', r=>`Olá, ${primeiroNome(r.nome_completo)}! Aqui é da ${nomeCli}. Seu último exame de vista está perto de completar 1 ano. Quer marcar seu retorno?`);
}

/* ========================= FINANCEIRO (só administrador) ========================= */
const FORMAS_PAG = { dinheiro:'Dinheiro', pix:'Pix', debito:'Débito', credito:'Crédito', convenio:'Convênio' };
let finAba = 'receber', finDe = '', finAte = '';
function periodoMes(){
  const h = new Date(), f = d=>`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
  return [f(new Date(h.getFullYear(),h.getMonth(),1)), f(new Date(h.getFullYear(),h.getMonth()+1,0))];
}
function renderFinanceiro(main){
  if(!finDe){ [finDe, finAte] = periodoMes(); }
  main.innerHTML = `<div class="card"><h2>Financeiro</h2>
    <div class="btn-row" style="margin-bottom:10px;">
      ${[['receber','Recebíveis'],['contas','Contas a pagar'],['resumo','Resumo']].map(([k,n])=>`<button class="btn ${finAba===k?'btn-primary':'btn-ghost'}" data-aba="${k}">${n}</button>`).join('')}
    </div>
    ${finAba==='contas' ? '' : `<div class="row2"><div><label>De</label><input type="date" id="finDe" value="${finDe}"></div><div><label>Até</label><input type="date" id="finAte" value="${finAte}"></div></div>`}
    <div id="finCorpo"><p class="sub">Carregando...</p></div></div>`;
  main.querySelectorAll('button[data-aba]').forEach(b=> b.onclick = ()=>{ finAba = b.dataset.aba; renderFinanceiro(main); });
  const de = document.getElementById('finDe'), ate = document.getElementById('finAte');
  if(de) de.onchange = ()=>{ finDe = de.value; renderFinanceiro(main); };
  if(ate) ate.onchange = ()=>{ finAte = ate.value; renderFinanceiro(main); };
  const corpo = document.getElementById('finCorpo');
  const falha = e=>{ corpo.innerHTML = `<p class="fieldmsg bad">${esc(e.message)}</p>`; };
  if(finAba==='receber') finReceber(main, corpo).catch(falha);
  else if(finAba==='contas') finContas(main, corpo).catch(falha);
  else finResumo(corpo).catch(falha);
}
async function finReceber(main, corpo){
  const d = await api(`/financeiro/recebiveis?de=${finDe}&ate=${finAte}`);
  const soma = l=> l.reduce((t,x)=>t+Number(x.valor||0),0);
  const linha = (x, rot)=>`<div class="list-item"><div><div class="name">${esc(x.paciente_nome)}</div><div class="meta">${fmtData(x.data_hora)} · ${esc(x.tipo_nome||'')}${x.otica_nome?' · '+esc(x.otica_nome):''}${x.convenio_nome?' · '+esc(x.convenio_nome):''}${x.forma?' · '+FORMAS_PAG[x.forma]:''}</div></div><div style="text-align:right;">${x.valor!=null?`<div class="name">${fmtMoeda(x.valor)}</div>`:''}<button class="btn btn-ghost btn-sm" data-id="${x.agendamento_id}">${rot}</button></div></div>`;
  const bloco = (titulo, lista, rot, vazio)=>`<h3 style="margin:14px 0 4px;font-size:15px;">${titulo}${lista.length&&lista[0].valor!=null?` · ${fmtMoeda(soma(lista))}`:''}</h3>${lista.length? lista.map(x=>linha(x,rot)).join('') : `<p class="sub">${vazio}</p>`}`;
  corpo.innerHTML = bloco('Sem cobrança registrada', d.sem_cobranca, 'Cobrar', 'Todos os atendimentos já têm cobrança.')
    + bloco('A receber', d.a_receber, 'Receber', 'Nada pendente.')
    + bloco('Recebidos', d.recebidos, 'Ver', 'Nada recebido no período.');
  const todos = [...d.sem_cobranca, ...d.a_receber, ...d.recebidos];
  corpo.querySelectorAll('button[data-id]').forEach(b=> b.onclick = ()=> abrirCobranca(todos.find(x=>x.agendamento_id===b.dataset.id), main));
}
function abrirCobranca(x, main){
  openModal(`<h2>${esc(x.paciente_nome)}</h2><p class="sub">${fmtData(x.data_hora)} · ${esc(x.tipo_nome||'')}</p>
    <label class="req">Valor (R$)</label><input type="text" inputmode="decimal" id="cbValor" value="${x.valor!=null?String(x.valor).replace('.',','):(x.preco_padrao!=null?String(x.preco_padrao).replace('.',','):'')}" placeholder="150,00">
    <label>Forma de pagamento</label>
    <select id="cbForma"><option value="">Não informada</option>${Object.entries(FORMAS_PAG).map(([k,v])=>`<option value="${k}" ${x.forma===k?'selected':''}>${v}</option>`).join('')}</select>
    <label>Convênio</label>
    <select id="cbConv"><option value="">Particular</option>${convenios.map(c=>`<option value="${c.id}" ${x.convenio_nome===c.nome?'selected':''}>${esc(c.nome)}</option>`).join('')}</select>
    <label style="display:flex;gap:8px;align-items:center;margin-top:12px;"><input type="checkbox" id="cbPago" style="width:auto;" ${x.status==='pago'?'checked':''}> Já foi pago</label>
    <div class="btn-row"><button class="btn btn-primary" id="cbSalvar">Salvar</button>${x.pagamento_id?'<button class="btn btn-danger" id="cbRemover">Remover cobrança</button>':''}<button class="btn btn-outline" onclick="closeModal()">Fechar</button></div>
    <p id="cbErr" style="color:#C1462F;font-size:12.5px;margin-top:8px;"></p>`);
  document.getElementById('cbSalvar').onclick = async ()=>{
    try{
      await api('/financeiro/pagamentos', { method:'POST', body:{ agendamento_id:x.agendamento_id, valor:document.getElementById('cbValor').value, forma:document.getElementById('cbForma').value||null, convenio_id:document.getElementById('cbConv').value||null, pago:document.getElementById('cbPago').checked }});
      closeModal(); toast('Cobrança salva.'); renderFinanceiro(main);
    }catch(e){ document.getElementById('cbErr').textContent = e.message; }
  };
  const rem = document.getElementById('cbRemover');
  if(rem) rem.onclick = async ()=>{
    if(!confirm('Remover esta cobrança?')) return;
    try{ await api(`/financeiro/pagamentos/${x.pagamento_id}`, { method:'DELETE' }); closeModal(); renderFinanceiro(main); }catch(e){ erroApi(e); }
  };
}
async function finContas(main, corpo){
  const lista = await api('/financeiro/contas');
  const hoje = new Date().toISOString().slice(0,10);
  corpo.innerHTML = `<div class="row2"><div><label>Descrição</label><input type="text" id="ctDesc" placeholder="Ex: aluguel do espaço"></div><div><label>Valor (R$)</label><input type="text" inputmode="decimal" id="ctValor" placeholder="300,00"></div></div>
    <label>Vencimento</label><input type="date" id="ctVenc" style="max-width:200px;">
    <button class="btn btn-ghost btn-block" id="ctAdd" style="margin-top:10px;">+ Adicionar conta</button>
    <div style="margin-top:14px;">${lista.length ? lista.map(c=>`<div class="list-item"><div><div class="name">${esc(c.descricao)} · ${fmtMoeda(c.valor)}</div><div class="meta" style="${!c.pago&&c.vencimento<hoje?'color:#C1462F;font-weight:600;':''}">${c.pago?'Paga em '+fmtData(c.pago_em):(c.vencimento<hoje?'Vencida em ':'Vence em ')+fmtData(c.vencimento)}</div></div><div><button class="btn btn-ghost btn-sm" data-pg="${c.id}" data-pago="${c.pago}">${c.pago?'Desfazer':'Pagar'}</button> <button class="btn btn-outline btn-sm" data-del="${c.id}">Excluir</button></div></div>`).join('') : '<p class="sub">Nenhuma conta cadastrada.</p>'}</div>`;
  document.getElementById('ctAdd').onclick = async ()=>{
    try{ await api('/financeiro/contas', { method:'POST', body:{ descricao:document.getElementById('ctDesc').value.trim(), valor:document.getElementById('ctValor').value, vencimento:document.getElementById('ctVenc').value }}); toast('Conta adicionada.'); renderFinanceiro(main); }
    catch(e){ erroApi(e); }
  };
  corpo.querySelectorAll('button[data-pg]').forEach(b=> b.onclick = async ()=>{
    try{ await api(`/financeiro/contas/${b.dataset.pg}/pagar`, { method:'PATCH', body:{ pago: b.dataset.pago!=='true' }}); renderFinanceiro(main); }catch(e){ erroApi(e); }
  });
  corpo.querySelectorAll('button[data-del]').forEach(b=> b.onclick = async ()=>{
    if(!confirm('Excluir esta conta?')) return;
    try{ await api(`/financeiro/contas/${b.dataset.del}`, { method:'DELETE' }); renderFinanceiro(main); }catch(e){ erroApi(e); }
  });
}
async function finResumo(corpo){
  const r = await api(`/financeiro/resumo?de=${finDe}&ate=${finAte}`);
  const grade = 'display:grid;grid-template-columns:repeat(auto-fit,minmax(130px,1fr));gap:10px;margin:10px 0;';
  const tabela = (t, itens)=>`<h3 style="margin:14px 0 4px;font-size:15px;">${t}</h3>${itens.length? itens.map(i=>`<div class="list-item"><div class="name">${FORMAS_PAG[i.nome]||esc(i.nome)}</div><div>${fmtMoeda(i.total)} <span class="meta">(${i.qtd})</span></div></div>`).join('') : '<p class="sub">Sem valores no período.</p>'}`;
  corpo.innerHTML = `<div style="${grade}">${cartaoNumero('Recebido', fmtMoeda(r.recebido), r.n_recebido+' atendimentos')}${cartaoNumero('A receber', fmtMoeda(r.a_receber), r.n_a_receber+' atendimentos')}${cartaoNumero('Contas a pagar', fmtMoeda(r.contas_a_pagar))}${cartaoNumero('Saldo', fmtMoeda(r.saldo), 'recebido menos contas pagas')}</div>`
    + tabela('Por forma de pagamento', r.por_forma) + tabela('Por ótica parceira', r.por_otica) + tabela('Por convênio', r.por_convenio);
}

/* ========================= TESTE DE VISÃO NA TELA ========================= */
const LETRAS_SLOAN = 'CDHKNORSVZ'.split('');
const LINHAS_AV = [200,100,70,50,40,30,25,20,15,10];
let tt = { pxmm: 3.78, dist: 6000, linha: 7, espelho: false, modo: 'letras', olho: 'AO', letras: [] };
try{ const s = localStorage.getItem('tt_pxmm'); if(s) tt.pxmm = parseFloat(s) || tt.pxmm; }catch(e){}
function sortearLetras(n){
  const l = []; while(l.length<n){ const c = LETRAS_SLOAN[Math.floor(Math.random()*LETRAS_SLOAN.length)]; if(l[l.length-1]!==c) l.push(c); } return l;
}
function alturaMm(den){ // 20/den: letra com 5 minutos de arco x (den/20), na distância escolhida
  const ang = (5/60) * (den/20) * Math.PI/180;
  return 2 * tt.dist * Math.tan(ang/2);
}
function renderTesteTela(main){
  main.innerHTML = `<div class="card"><h2>Teste de visão na tela</h2>
    <p class="sub">Primeiro calibre a tela com um cartão de banco. Depois afaste o paciente na distância escolhida e abra o optotipo. São 19 testes: letras, números, E direcional, C de Landolt, cores, duocromo, dial astigmático, luzes de Worth, desenhos, Amsler, fixação, leitura de perto, contraste, educação ocular, cruz de afinamento, contraste por letras, tabela ETDRS, Amsler vermelho e tabela de Snellen.</p>
    <div class="btn-row"><button class="btn btn-ghost" id="ttCalib">1. Calibrar a tela</button>
    <button class="btn btn-primary" id="ttIniciar">2. Abrir o optotipo</button></div>
    <div style="margin-top:10px;"><label>Distância do paciente</label>
      <select id="ttDist">${[[3000,'3 metros'],[4000,'4 metros'],[5000,'5 metros'],[6000,'6 metros'],[1000,'1 metro'],[400,'40 cm (perto)']].map(([v,n])=>`<option value="${v}" ${tt.dist===v?'selected':''}>${n}</option>`).join('')}</select></div>
    <label style="display:flex;gap:8px;align-items:center;margin-top:10px;"><input type="checkbox" id="ttEsp" style="width:auto;" ${tt.espelho?'checked':''}> Modo espelho (para sala pequena com espelho)</label>
    <p class="sub" id="ttInfo" style="margin-top:8px;"></p>
    <p class="sub">Dentro do optotipo, aperte <b>?</b> para ver os atalhos do teclado. O botão "Conectar celular" mostra um QR Code para controlar o teste pelo celular.</p></div>`;
  const info = ()=>{ document.getElementById('ttInfo').textContent = `Letra 20/20 nesta distância: ${alturaMm(20).toFixed(1)} mm de altura. Calibração atual: ${tt.pxmm.toFixed(2)} pixels por mm.`; };
  document.getElementById('ttDist').onchange = e=>{ tt.dist = +e.target.value; info(); };
  document.getElementById('ttEsp').onchange = e=>{ tt.espelho = e.target.checked; };
  document.getElementById('ttCalib').onclick = ()=> calibrarTela(info);
  document.getElementById('ttIniciar').onclick = ()=> iniciarTeste();
  tt.dist = +document.getElementById('ttDist').value; info();
}
function calibrarTela(depois){
  openModal(`<h2>Calibrar a tela</h2><p class="sub">Encoste um cartão de banco na tela, deitado. Mexa na barra até o retângulo ficar do mesmo tamanho do cartão. O cartão mede 8,56 cm por 5,40 cm.</p>
    <div style="overflow:auto;"><div id="calRet" style="height:${53.98*tt.pxmm}px;width:${85.6*tt.pxmm}px;border:2px solid var(--teal-700);border-radius:8px;background:var(--teal-100);margin:10px 0;"></div></div>
    <input type="range" id="calBar" min="1.5" max="9" step="0.01" value="${tt.pxmm}" style="width:100%;">
    <div class="btn-row"><button class="btn btn-primary" id="calOk">Está do tamanho do cartão</button><button class="btn btn-outline" onclick="closeModal()">Cancelar</button></div>`);
  const bar = document.getElementById('calBar'), ret = document.getElementById('calRet');
  bar.oninput = ()=>{ ret.style.width = (85.6*bar.value)+'px'; ret.style.height = (53.98*bar.value)+'px'; };
  document.getElementById('calOk').onclick = ()=>{
    tt.pxmm = parseFloat(bar.value);
    try{ localStorage.setItem('tt_pxmm', String(tt.pxmm)); }catch(e){}
    closeModal(); toast('Tela calibrada.'); depois();
  };
}
function iniciarTeste(){
  if(typeof abrirOptotipo !== 'function'){ toast('Arquivo optotipo.js não encontrado na pasta do sistema.'); return; }
  abrirOptotipo();
}
function svgE(h){ // E em grade 5x5: traço de 1/5 da altura, como manda o optotipo padrão
  return `<svg viewBox="0 0 5 5" width="${h}" height="${h}" style="display:block;"><path fill="#000" d="M0 0h5v1H1v1h3v1H1v1h4v1H0z"/></svg>`;
}

/* ========================= ÓTICAS PARCEIRAS E CONVÊNIOS (Master) ========================= */
function cadastrosMasterCardHtml(){
  return ['oticas','convenios'].map(k=>{
    const nome = k==='oticas' ? 'Óticas parceiras' : 'Convênios';
    const sub = k==='oticas' ? 'Óticas que indicam pacientes. Aparecem na hora de marcar o horário e nos números do financeiro.' : 'Planos e convênios aceitos. Aparecem na hora de registrar a cobrança.';
    return `<div class="card"><h2>${nome}</h2><p class="sub">${sub}</p><div id="lista_${k}"></div>
      <div class="row2" style="margin-top:8px;"><div><input type="text" id="novo_${k}" placeholder="Nome"></div><div><button class="btn btn-ghost btn-block" id="add_${k}">+ Adicionar</button></div></div></div>`;
  }).join('');
}
function impressaoMasterCardHtml(){
  const c = configImpressao();
  const opt = (v,n,atual)=>`<option value="${v}" ${atual===v?'selected':''}>${n}</option>`;
  return `<div class="card"><h2>Impressão</h2><p class="sub">Tamanho da folha e aparência da receita, do atestado e da declaração.</p>
    <div class="row2"><div><label>Tamanho da folha</label><select id="imPapel">${opt('A4','A4 (folha inteira)',c.papel)}${opt('A5','A5 (meia folha)',c.papel)}${opt('Letter','Carta',c.papel)}</select></div>
      <div><label>Posição</label><select id="imOri">${opt('portrait','Em pé',c.orientacao)}${opt('landscape','Deitada',c.orientacao)}</select></div></div>
    <div class="row2"><div><label>Cor</label><select id="imCor">${opt('colorido','Colorido',c.cor)}${opt('pb','Preto e branco (impressora a laser)',c.cor)}</select></div>
      <div><label>Margem (mm)</label><input type="number" id="imMargem" min="5" max="30" value="${c.margem_mm}"></div></div>
    <label>Texto no rodapé dos documentos <span style="font-weight:400;color:var(--ink-soft);">(opcional)</span></label>
    <input type="text" id="imRodape" maxlength="300" value="${esc(c.rodape)}" placeholder="Ex: Receita válida por 12 meses. Faça revisão anual da visão.">
    <button class="btn btn-ghost btn-block" id="imSalvar" style="margin-top:10px;">Salvar impressão</button></div>`;
}
function ligarImpressaoMaster(){
  const b = document.getElementById('imSalvar'); if(!b) return;
  b.onclick = async ()=>{
    try{
      const cfg = await api('/clinica/impressao', { method:'PUT', body:{ papel:document.getElementById('imPapel').value, orientacao:document.getElementById('imOri').value, cor:document.getElementById('imCor').value, margem_mm:document.getElementById('imMargem').value, rodape:document.getElementById('imRodape').value }});
      clinicaAtual.config_impressao = cfg; toast('Impressão salva.');
    }catch(e){ erroApi(e); }
  };
}
function ligarCadastrosMaster(main){
  [['oticas',()=>oticas,v=>{oticas=v;}],['convenios',()=>convenios,v=>{convenios=v;}]].forEach(([k,get,set])=>{
    const box = document.getElementById('lista_'+k); if(!box) return;
    const desenhar = ()=>{
      const l = get();
      box.innerHTML = l.length ? l.map(x=>`<div class="list-item"><div class="name">${esc(x.nome)}</div><button class="btn btn-outline btn-sm" data-del="${x.id}">Remover</button></div>`).join('') : '<p class="sub">Nenhum cadastrado.</p>';
      box.querySelectorAll('button[data-del]').forEach(b=> b.onclick = async ()=>{
        if(!confirm('Remover da lista?')) return;
        try{ await api(`/cadastros/${k}/${b.dataset.del}`, { method:'DELETE' }); set(get().filter(x=>x.id!==b.dataset.del)); desenhar(); }catch(e){ erroApi(e); }
      });
    };
    desenhar();
    document.getElementById('add_'+k).onclick = async ()=>{
      const inp = document.getElementById('novo_'+k), nome = inp.value.trim(); if(!nome) return;
      try{ const novo = await api(`/cadastros/${k}`, { method:'POST', body:{ nome } }); set([...get(), novo].sort((a,b)=>a.nome.localeCompare(b.nome))); inp.value=''; desenhar(); }catch(e){ erroApi(e); }
    };
  });
}
function oticaSelectHtml(id){
  if(!oticas.length) return '';
  return `<label>Ótica parceira que indicou <span style="font-weight:400;color:var(--ink-soft);">(opcional)</span></label><select id="${id}"><option value="">Nenhuma</option>${oticas.map(o=>`<option value="${o.id}">${esc(o.nome)}</option>`).join('')}</select>`;
}

let retornosMeses = 12, aniversarioMes = new Date().getMonth()+1;
async function renderRetornos(main){
  main.innerHTML = `
    <div class="card"><h2>Retorno vencido</h2>
      <p class="sub">Pacientes que fizeram exame há mais tempo e não têm nada marcado.</p>
      <label>Último exame há mais de</label>
      <select id="retMeses" style="max-width:200px;">${[6,12,18,24].map(m=>`<option value="${m}" ${m===retornosMeses?'selected':''}>${m} meses</option>`).join('')}</select>
      <div id="retLista"><p class="sub">Carregando...</p></div></div>
    <div class="card"><h2>Aniversariantes</h2>
      <label>Mês</label>
      <select id="aniMes" style="max-width:200px;">${['Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'].map((n,i)=>`<option value="${i+1}" ${i+1===aniversarioMes?'selected':''}>${n}</option>`).join('')}</select>
      <div id="aniLista"><p class="sub">Carregando...</p></div></div>`;
  document.getElementById('retMeses').onchange = e=>{ retornosMeses = +e.target.value; carregarRetornos(); };
  document.getElementById('aniMes').onchange = e=>{ aniversarioMes = +e.target.value; carregarAniversarios(); };
  carregarRetornos(); carregarAniversarios();
}
const primeiroNome = n=> (n||'').trim().split(/\s+/)[0];
async function carregarRetornos(){
  const box = document.getElementById('retLista'); if(!box) return;
  try{
    const lista = await api(`/relatorios/retornos?meses=${retornosMeses}`);
    if(!lista.length){ box.innerHTML = '<div class="empty"><div class="ic">✅</div>Nenhum retorno vencido.</div>'; return; }
    box.innerHTML = lista.map((r,i)=>`<div class="list-item"><div><div class="name">${esc(r.nome_completo)}</div><div class="meta">Último exame: ${fmtData(r.ultimo_exame)} · ${esc(r.telefone||'sem telefone')}</div></div><button class="btn btn-wpp btn-sm" data-i="${i}">WhatsApp</button></div>`).join('');
    box.querySelectorAll('button[data-i]').forEach(b=> b.onclick = ()=>{
      const r = lista[+b.dataset.i];
      abrirWhatsapp(r.telefone, `Olá, ${primeiroNome(r.nome_completo)}! Aqui é da ${clinicaAtual?.nome_fantasia||'clínica'}. Já faz mais de ${retornosMeses} meses do seu último exame de vista. Quer marcar seu retorno?`);
    });
  }catch(e){ box.innerHTML = `<p class="fieldmsg bad">${esc(e.message)}</p>`; }
}
async function carregarAniversarios(){
  const box = document.getElementById('aniLista'); if(!box) return;
  try{
    const lista = await api(`/relatorios/aniversariantes?mes=${aniversarioMes}`);
    if(!lista.length){ box.innerHTML = '<div class="empty"><div class="ic">🎂</div>Nenhum aniversariante neste mês. Cadastre a data de nascimento dos pacientes.</div>'; return; }
    box.innerHTML = lista.map((r,i)=>`<div class="list-item"><div><div class="name">${esc(r.nome_completo)}</div><div class="meta">Dia ${r.data_nascimento.slice(8,10)} · ${esc(r.telefone||'sem telefone')}</div></div><button class="btn btn-wpp btn-sm" data-i="${i}">Parabenizar</button></div>`).join('');
    box.querySelectorAll('button[data-i]').forEach(b=> b.onclick = ()=>{
      const r = lista[+b.dataset.i];
      abrirWhatsapp(r.telefone, `Olá, ${primeiroNome(r.nome_completo)}! A equipe da ${clinicaAtual?.nome_fantasia||'clínica'} deseja um feliz aniversário, com muita saúde e boa visão!`);
    });
  }catch(e){ box.innerHTML = `<p class="fieldmsg bad">${esc(e.message)}</p>`; }
}

/* ========================= CONFIRMAÇÃO DO DIA ========================= */
/* ========================= PRONTUÁRIO (só profissional/admin) ========================= */
let prontuarioState = { pacienteId:'', lista:[] };
let gabaritoAtual = gabaritoVazio();
let gabaritoAberto = false; // só mostra o bloco grande quando o profissional pedir
let meuCarimbo = null; // dados de carimbo/assinatura do profissional logado, pro gabarito impresso

function linhaAcuidadeHtml(olho, i, linha){
  const campo = olho==='od' ? gabaritoAtual.linhasOD : gabaritoAtual.linhasOE;
  const v = campo[i];
  return `<div class="gab-linha">
    <span class="gab-linha-faixa">${i+1} - ${linha.faixa}</span>
    <span class="gab-linha-letras">${linha[olho]}</span>
    <label class="gab-radio"><input type="radio" name="gab_${olho}_${i}" value="acertou" ${v===true?'checked':''}> Acertou</label>
    <label class="gab-radio"><input type="radio" name="gab_${olho}_${i}" value="errou" ${v===false?'checked':''}> Errou</label>
  </div>`;
}

function gabaritoHtml(){
  const g = gabaritoAtual;
  return `
    <div class="gab-wrap">
      <h3 style="font-size:14px;margin-top:14px;">Identificação</h3>
      <label>Idade do paciente</label>
      <input type="text" inputmode="numeric" id="gIdade" value="${g.idadePaciente}" style="max-width:120px;">
      <p class="sub" style="margin:4px 0 0;">Dados de empresa, só pra exame admissional; deixe em branco se não for o caso.</p>
      <div class="row3">
        <div><label>Empresa</label><input type="text" id="gEmpresa" value="${g.empresa}"></div>
        <div><label>Função</label><input type="text" id="gFuncao" value="${g.funcao}"></div>
        <div><label>Setor</label><input type="text" id="gSetor" value="${g.setor}"></div>
      </div>

      <h3 style="font-size:14px;margin-top:14px;">Questionário</h3>
      <label>Usa óculos?</label>
      <select id="gUsaOculos"><option value="">Selecione...</option><option value="Sim" ${g.usaOculos==='Sim'?'selected':''}>Sim</option><option value="Não" ${g.usaOculos==='Não'?'selected':''}>Não</option></select>
      <label>Frequência</label>
      <select id="gFrequencia"><option value="">Selecione...</option>${['Sempre','Algumas vezes','Só para leitura'].map(o=>`<option ${g.frequenciaUso===o?'selected':''}>${o}</option>`).join('')}</select>
      <label>Tipo de lente atual</label>
      <select id="gTipoLenteAtual"><option value="">Selecione...</option>${['Visão simples','Multifocal','Bifocal','Lente de contato'].map(o=>`<option ${g.tipoLenteAtual===o?'selected':''}>${o}</option>`).join('')}</select>
      <div class="row2">
        <div><label>Há quanto tempo usa os óculos atuais</label><input type="text" id="gTempoUso" value="${g.tempoUsoAtual}" placeholder="Ex: 2 anos"></div>
        <div><label>Última consulta com especialista</label><input type="text" id="gUltimaConsulta" value="${g.ultimaConsultaEspecialista}" placeholder="Ex: há 1 ano"></div>
      </div>
      <label>Já fez exame com especialista em visão?</label>
      <select id="gJaFezExame"><option value="">Selecione...</option><option ${g.jaFezExameEspecialista==='Sim'?'selected':''}>Sim</option><option ${g.jaFezExameEspecialista==='Não'?'selected':''}>Não</option></select>
      <div class="row2">
        <div><label>Possui doença ocular?</label><select id="gPossuiDoenca"><option value="">Selecione...</option><option ${g.possuiDoencaOcular==='Sim'?'selected':''}>Sim</option><option ${g.possuiDoencaOcular==='Não'?'selected':''}>Não</option></select></div>
        <div><label>Qual</label><input type="text" id="gDoencaQual" value="${g.doencaOcularQual}"></div>
      </div>
      <div class="row2">
        <div><label>Sente dificuldade visual?</label><select id="gDificuldade"><option value="">Selecione...</option><option ${g.senteDificuldadeVisual==='Sim'?'selected':''}>Sim</option><option ${g.senteDificuldadeVisual==='Não'?'selected':''}>Não</option></select></div>
        <div><label>Qual (longe, perto, noite, cores...)</label><input type="text" id="gDificuldadeQual" value="${g.dificuldadeQual}"></div>
      </div>

      <h3 style="font-size:14px;margin-top:14px;">Teste de longe</h3>
      <label>Realizado</label>
      <select id="gComCorrecao"><option value="">Selecione...</option><option value="Com lentes corretivas" ${g.testeComCorrecao==='Com lentes corretivas'?'selected':''}>Com lentes corretivas</option><option value="Sem lentes corretivas" ${g.testeComCorrecao==='Sem lentes corretivas'?'selected':''}>Sem lentes corretivas</option></select>

      <div class="gab-olho-titulo">Olho direito (OD)</div>
      ${LINHAS_ACUIDADE.map((l,i)=>linhaAcuidadeHtml('od',i,l)).join('')}
      <label>Resultado OD <span style="font-weight:400;color:var(--ink-soft);">(20/___)</span></label>
      <input type="text" id="gResultadoOD" value="${g.resultadoOD}" placeholder="Ex: 40">

      <div class="gab-olho-titulo">Olho esquerdo (OE)</div>
      ${LINHAS_ACUIDADE.map((l,i)=>linhaAcuidadeHtml('oe',i,l)).join('')}
      <label>Resultado OE <span style="font-weight:400;color:var(--ink-soft);">(20/___)</span></label>
      <input type="text" id="gResultadoOE" value="${g.resultadoOE}" placeholder="Ex: 40">

      <h3 style="font-size:14px;margin-top:14px;">Resumo do exame</h3>
      <label>AV longe sem correção (OD / OE / AO)</label>
      <div class="row3">
        <input type="text" id="gAvSemOD" value="${g.avLongeSemOD}" placeholder="20/__">
        <input type="text" id="gAvSemOE" value="${g.avLongeSemOE}" placeholder="20/__">
        <input type="text" id="gAvSemAO" value="${g.avLongeSemAO}" placeholder="20/__">
      </div>
      <label>AV longe com correção (OD / OE / AO)</label>
      <div class="row3">
        <input type="text" id="gAvComOD" value="${g.avLongeComOD}" placeholder="20/__">
        <input type="text" id="gAvComOE" value="${g.avLongeComOE}" placeholder="20/__">
        <input type="text" id="gAvComAO" value="${g.avLongeComAO}" placeholder="20/__">
      </div>
      <label>AV perto, Jaeger (OD / OE / AO)</label>
      <div class="row3">
        <input type="text" id="gAvPertoOD" value="${g.avPertoOD}" placeholder="J__">
        <input type="text" id="gAvPertoOE" value="${g.avPertoOE}" placeholder="J__">
        <input type="text" id="gAvPertoAO" value="${g.avPertoAO}" placeholder="J__">
      </div>

      <label>Teste de cores (Ishihara)</label>
      <div class="row2">
        <select id="gTesteCores"><option value="">Selecione...</option>${['Normal','Alterado','Não realizado'].map(o=>`<option ${g.testeCores===o?'selected':''}>${o}</option>`).join('')}</select>
        <input type="text" id="gTesteCoresAcertos" value="${g.testeCoresAcertos}" placeholder="Acertos, ex: 8/10">
      </div>

      <label>Conduta</label>
      <select id="gConduta"><option value="">Selecione...</option>${['Visão dentro do padrão','Indicada correção óptica','Encaminhar ao oftalmologista'].map(o=>`<option ${g.condutaGabarito===o?'selected':''}>${o}</option>`).join('')}</select>
      <label>Observações do gabarito</label>
      <textarea id="gObservacoes">${g.observacoesGabarito}</textarea>

      <button type="button" class="btn btn-ghost btn-block" id="btnImprimirGabarito" style="margin-top:12px;">Imprimir gabarito</button>
      <p class="sub" style="margin-top:6px;">Este exame é uma triagem de acuidade visual. Não substitui consulta com oftalmologista. A aptidão para a função cabe ao médico do trabalho.</p>
    </div>`;
}

/* Gabarito impresso de propósito SEM logo nem nome da clínica: é um documento de
   exame de acuidade visual, usado inclusive pra admissão em empresa, e não é um
   serviço comercial da loja. Só identifica o profissional que assina. */
function gerarHtmlGabarito(paciente){
  const g = gabaritoAtual;
  const linha = (olho,i)=>{
    const v = olho==='od'?g.linhasOD[i]:g.linhasOE[i];
    return `${LINHAS_ACUIDADE[i].faixa}: ${v===true?'Acertou':v===false?'Errou':'-'}`;
  };
  // examinador é quem está logado fazendo o exame agora, não o profissional
  // escolhido na tela de Receita (são contextos diferentes)
  const dadosExaminador = meuCarimbo || (usuarioAtual?.papel==='profissional' ? { nome: usuarioAtual.nome } : null);
  const examinador = dadosExaminador ? `${dadosExaminador.carimbo_texto||dadosExaminador.nome}${dadosExaminador.registro_conselho?' — '+dadosExaminador.registro_conselho:''}` : '____________________';
  return `<h2>Gabarito do Exame de Acuidade Visual</h2>
    <pre style="white-space:pre-wrap;font-family:inherit;">Nome: ${paciente?.nome_completo||''}
Idade: ${g.idadePaciente||'-'}    Data: ${fmtData(new Date().toISOString())}
Empresa: ${g.empresa||'-'}    Função: ${g.funcao||'-'}    Setor: ${g.setor||'-'}

QUESTIONÁRIO
Usa óculos: ${g.usaOculos||'-'}    Frequência: ${g.frequenciaUso||'-'}    Tipo de lente: ${g.tipoLenteAtual||'-'}
Tempo de uso dos óculos atuais: ${g.tempoUsoAtual||'-'}    Última consulta com especialista: ${g.ultimaConsultaEspecialista||'-'}
Já fez exame com especialista: ${g.jaFezExameEspecialista||'-'}
Possui doença ocular: ${g.possuiDoencaOcular||'-'}  Qual: ${g.doencaOcularQual||'-'}
Sente dificuldade visual: ${g.senteDificuldadeVisual||'-'}  Qual: ${g.dificuldadeQual||'-'}

TESTE DE LONGE (${g.testeComCorrecao||'não informado'})
OD: ${LINHAS_ACUIDADE.map((_,i)=>linha('od',i)).join(' | ')}
Resultado OD: 20/${g.resultadoOD||'___'}

OE: ${LINHAS_ACUIDADE.map((_,i)=>linha('oe',i)).join(' | ')}
Resultado OE: 20/${g.resultadoOE||'___'}

RESUMO DO EXAME
AV longe sem correção — OD: ${g.avLongeSemOD||'-'}  OE: ${g.avLongeSemOE||'-'}  AO: ${g.avLongeSemAO||'-'}
AV longe com correção — OD: ${g.avLongeComOD||'-'}  OE: ${g.avLongeComOE||'-'}  AO: ${g.avLongeComAO||'-'}
AV perto (Jaeger) — OD: ${g.avPertoOD||'-'}  OE: ${g.avPertoOE||'-'}  AO: ${g.avPertoAO||'-'}
Teste de cores (Ishihara): ${g.testeCores||'-'}    Acertos: ${g.testeCoresAcertos||'-'}

Conduta: ${g.condutaGabarito||'-'}
Observações: ${g.observacoesGabarito||'-'}</pre>
    <div style="margin-top:34px;display:flex;justify-content:space-between;gap:20px;">
      <div style="flex:1;text-align:center;padding-top:10px;border-top:1px solid #999;">${examinador}<br><span style="font-size:11px;color:#666;">Examinador(a) / registro</span></div>
      <div style="flex:1;text-align:center;padding-top:10px;border-top:1px solid #999;">&nbsp;<br><span style="font-size:11px;color:#666;">Assinatura do(a) examinado(a)</span></div>
    </div>
    <p style="font-size:11px;color:#666;margin-top:14px;">Este exame é uma triagem de acuidade visual. Não substitui consulta com oftalmologista. A aptidão para a função cabe ao médico do trabalho.</p>`;
}

/*VOZ-INICIO*/
/* ===== Comando de voz no exame: transforma o que o profissional fala em valores nos campos ===== */
const VOZ_NUM = { zero:0, um:1, uma:1, dois:2, duas:2, tres:3, quatro:4, cinco:5, seis:6, sete:7, oito:8, nove:9, dez:10, onze:11, doze:12, treze:13, quatorze:14, catorze:14, quinze:15, dezesseis:16, dezessete:17, dezoito:18, dezenove:19 };
const VOZ_DEZ = { vinte:20, trinta:30, quarenta:40, cinquenta:50, sessenta:60, setenta:70, oitenta:80, noventa:90 };
const VOZ_CENT = { cem:100, cento:100, duzentos:200, trezentos:300 };
function vozLimpar(t){
  return String(t||'').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g,'')
    .replace(/(\d),(\d)/g,'$1.$2').replace(/[^a-z0-9.+\- ]/g,' ').replace(/\s+/g,' ').trim().split(' ').filter(Boolean);
}
const vozEhNum = (t)=> /^[+-]?\d+(\.\d+)?$/.test(t);
/* lê um inteiro por extenso ou em dígitos a partir da posição i. Devolve {v, p} ou null */
function vozInteiro(tk, i){
  const t = tk[i]; if(t===undefined) return null;
  if(/^\d+$/.test(t)) return { v:parseInt(t,10), p:i+1 };
  let v = 0, p = i, achou = false;
  if(VOZ_CENT[tk[p]]!==undefined){ v += VOZ_CENT[tk[p]]; p++; achou = true; if(tk[p]==='e' && (VOZ_DEZ[tk[p+1]]!==undefined || VOZ_NUM[tk[p+1]]!==undefined)) p++; }
  if(VOZ_DEZ[tk[p]]!==undefined){ v += VOZ_DEZ[tk[p]]; p++; achou = true; if(tk[p]==='e' && VOZ_NUM[tk[p+1]]!==undefined && VOZ_NUM[tk[p+1]]>0 && VOZ_NUM[tk[p+1]]<10){ v += VOZ_NUM[tk[p+1]]; p += 2; } }
  else if(VOZ_NUM[tk[p]]!==undefined && !(achou && v>0 && VOZ_NUM[tk[p]]>=10)){ v += VOZ_NUM[tk[p]]; p++; achou = true; }
  return achou ? { v, p } : null;
}
/* lê um grau (com sinal e decimais). Ex.: "menos um e vinte e cinco" = -1.25 */
function vozGrau(tk, i){
  let p = i, sinal = 1, temSinal = false;
  while(['mais','menos','positivo','negativo'].includes(tk[p])){ sinal = (tk[p]==='menos'||tk[p]==='negativo') ? -1 : 1; temSinal = true; p++; }
  if(['plano','neutro'].includes(tk[p])) return { v:0, p:p+1 };
  if(tk[p]==='meio' || tk[p]==='meia'){ return { v:sinal*0.5, p:p+1 }; }
  let t = tk[p];
  if(t!==undefined && vozEhNum(t) && /[.]/.test(t)){ const n = parseFloat(t); return { v:(/^[+-]/.test(t) ? n : sinal*n), p:p+1 }; }
  if(t!==undefined && /^[+-]\d+$/.test(t)){ sinal = t[0]==='-' ? -1 : 1; tk = tk.slice(); tk[p] = t.slice(1); temSinal = true; }
  const n1 = vozInteiro(tk, p); if(!n1) return null;
  let v = n1.v; p = n1.p;
  let decimal = null;
  if(tk[p]==='virgula' || tk[p]==='ponto'){
    const d = vozInteiro(tk, p+1);
    if(d){ decimal = d.v<10 ? d.v/10 : d.v/100; p = d.p; }
  } else if(tk[p]==='e' && (tk[p+1]==='meio' || tk[p+1]==='meia')){ decimal = 0.5; p += 2; }
  else if(tk[p]==='e'){ const d = vozInteiro(tk, p+1); if(d && [25,50,75].includes(d.v)){ decimal = d.v/100; p = d.p; } }
  else { const d = vozInteiro(tk, p); if(d && [25,50,75].includes(d.v) && !['mais','menos'].includes(tk[p-1])){ decimal = d.v/100; p = d.p; } }
  if(decimal===null && v>=25 && v%25===0) v = v/100; // "menos cinquenta" = -0,50
  return { v: sinal*(v + (decimal||0)), p };
}
const vozFmtGrau = (v)=> (v>0?'+':'')+v.toFixed(2);
const VOZ_CAMPOS = { ar:['Esf','Cil','Eixo'], fn:['Esf','Cil','Eixo','Add'] };
const VOZ_ROTULO = { Esf:'esférico', Cil:'cilíndrico', Eixo:'eixo', Add:'adição' };
function vozEstadoNovo(etapa){ return { olho:null, grupo: etapa===2 ? 'av' : 'ar', idx:0, avSub:'ls', avDist:'longe' }; }

/* interpreta uma frase. est guarda o contexto (olho, grupo, campo) entre uma frase e outra */
function vozInterpretar(texto, est){
  const tk = vozLimpar(texto);
  const out = { acoes:[], cmd:null, avisos:[] };
  const add = (id, valor, rot)=>{ out.acoes.push({ id, valor, texto:rot+': '+valor }); };
  let i = 0;
  while(i<tk.length){
    const t = tk[i];
    // comandos de tela
    if((t==='proxima'||t==='proximo'||t==='avancar') && (tk.length<=2 || tk[i+1]==='etapa' || tk[i+1]==='passo')){ out.cmd='proximo'; i++; continue; }
    if((t==='voltar'||t==='anterior') && (tk.length<=2 || tk[i+1]==='etapa' || tk[i+1]==='passo')){ out.cmd='voltar'; i++; continue; }
    if(t==='etapa'||t==='passo'){ i++; continue; }
    // observação: o resto da frase é texto livre
    if(['observacao','observacoes','obs','anotacao'].includes(t)){
      const resto = String(texto).split(/observa[cç][aã]o|observa[cç][oõ]es|anota[cç][aã]o|obs\b/i).slice(1).join(' ').trim();
      if(resto) add('tsObs', resto, 'Observação');
      break;
    }
    // grupos
    if(['autorrefrator','autorefrator','refrator','auto'].includes(t)){ est.grupo='ar'; est.idx=0; i++; continue; }
    if(['final','confirmado','definitivo'].includes(t)){ est.grupo='fn'; est.idx=0; i++; continue; }
    if(t==='acuidade'){ est.grupo='av'; i++; continue; }
    if(t==='longe'){ est.grupo='av'; est.avDist='longe'; i++; continue; }
    if(t==='perto'){ est.grupo='av'; est.avDist='perto'; est.avSub='ps'; i++; continue; }
    if(['pinhole','furo','buraco'].includes(t)){ est.grupo='av'; est.avDist='longe'; est.avSub='ph'; i++; continue; }
    if(est.grupo==='av' && (t==='sem'||t==='com') && ['oculos','correcao','lentes'].includes(tk[i+1])){ est.avSub = (est.avDist==='perto' ? (t==='sem'?'ps':'pc') : (t==='sem'?'ls':'lc')); i += 2; continue; }
    if(['pressao','tonometria','pio'].includes(t)){ est.grupo='pio'; i++; continue; }
    if(['ppc','convergencia'].includes(t)){ est.grupo='ppc'; i++; continue; }
    if(['movimento','motilidade','pupilas','cores'].includes(t)){
      const alvo = tk[i+1];
      const mapa = { movimento:['tsMotil','Movimento dos olhos'], motilidade:['tsMotil','Movimento dos olhos'], pupilas:['tsPupilas','Pupilas'], cores:['tsCores','Visão de cores'] }[t];
      const normal = ['normal','normais'].includes(alvo), alterado = ['alterado','alterada','alterados','alteradas'].includes(alvo);
      if(normal||alterado){ const v = t==='pupilas' ? (normal?'Normais':'Alteradas') : t==='cores' ? (normal?'Normal':'Alterada') : (normal?'Normal':'Alterado'); add(mapa[0], v, mapa[1]); i += 2; continue; }
      if(t==='cores' && (alvo==='nao'||alvo==='sem') ){ add('tsCores','Não testado','Visão de cores'); i += 2; continue; }
      i++; continue;
    }
    // olho
    if(['direito','od','direita'].includes(t) || (t==='o' && tk[i+1]==='d')){ est.olho='Od'; est.idx=0; i += (t==='o'?2:1); if(tk[i]==='olho') i++; continue; }
    if(['esquerdo','oe','esquerda'].includes(t) || (t==='o' && tk[i+1]==='e')){ est.olho='Oe'; est.idx=0; i += (t==='o'?2:1); continue; }
    if(t==='olho'||t==='ambos'||t==='do'||t==='no'||t==='de'||t==='o'||t==='e'){ i++; continue; }
    // campos
    const mc = { esferico:'Esf', esfera:'Esf', esf:'Esf', cilindrico:'Cil', cilindro:'Cil', cil:'Cil', eixo:'Eixo', adicao:'Add', add:'Add' }[t];
    if(mc){ const lista = VOZ_CAMPOS[est.grupo]; if(lista){ const k = lista.indexOf(mc); if(k>=0) est.idx = k; } i++; continue; }
    // valores
    if(est.grupo==='ar' || est.grupo==='fn'){
      const lista = VOZ_CAMPOS[est.grupo];
      const campo = lista[est.idx];
      if(!campo){ i++; continue; }
      if(!est.olho){ if(vozGrau(tk, i)) out.avisos.push('Diga o olho: direito ou esquerdo.'); i++; continue; }
      if(campo==='Eixo'){
        const n = vozInteiro(tk, i);
        if(n){ if(n.v>=0 && n.v<=180){ add(`${est.grupo}${est.olho}Eixo`, String(n.v), `${est.grupo==='ar'?'Autorrefrator':'Grau final'} ${est.olho.toUpperCase()} eixo`); est.idx++; } else out.avisos.push('Eixo precisa ficar entre 0 e 180.'); i = n.p; continue; }
      } else {
        const g = vozGrau(tk, i);
        if(g){
          const lim = campo==='Cil' ? 10 : 30;
          if(Math.abs(g.v)>lim){ out.avisos.push(`Valor fora do normal: ${vozFmtGrau(g.v)}. Repita.`); }
          else { add(`${est.grupo}${est.olho}${campo}`, vozFmtGrau(g.v), `${est.grupo==='ar'?'Autorrefrator':'Grau final'} ${est.olho.toUpperCase()} ${VOZ_ROTULO[campo]}`);
            if(campo==='Cil' && g.v===0 && lista[est.idx+1]==='Eixo'){ est.idx += 2; } else est.idx++; }
          i = g.p; continue;
        }
      }
      i++; continue;
    }
    if(est.grupo==='av'){
      if(est.avDist==='perto'){
        let j = i; if(tk[j]==='j'||tk[j]==='jota') j++;
        else if(/^j\d+$/.test(tk[j])){ add(est.avSub==='pc'?'avPcAo':'avPsAo', tk[j].toUpperCase(), 'Perto'); i++; continue; }
        const n = vozInteiro(tk, j);
        if(n && n.v>=1 && n.v<=16 && j>i){ add(est.avSub==='pc'?'avPcAo':'avPsAo', 'J'+n.v, 'Perto '+(est.avSub==='pc'?'com':'sem')+' óculos'); i = n.p; continue; }
        i++; continue;
      }
      if(!est.olho){ out.avisos.push('Diga o olho: direito ou esquerdo.'); i++; continue; }
      const a = vozInteiro(tk, i);
      if(a){
        const b = vozInteiro(tk, a.p);
        const rot = {ls:'Longe sem óculos',lc:'Longe com óculos',ph:'Pinhole'}[est.avSub]||'Acuidade';
        if(b && a.v<=40 && b.v>=10){ add(`av${est.avSub.charAt(0).toUpperCase()+est.avSub.slice(1)}${est.olho}`, `${a.v}/${b.v}`, rot+' '+est.olho.toUpperCase()); i = b.p; }
        else { out.avisos.push('Acuidade: fale dois números, por exemplo vinte quarenta.'); i = a.p; }
        continue;
      }
      i++; continue;
    }
    if(est.grupo==='pio'){
      const n = vozInteiro(tk, i);
      if(n){ if(!est.olho) out.avisos.push('Diga o olho: direito ou esquerdo.'); else if(n.v>=5 && n.v<=80) add('tsPio'+est.olho, String(n.v), 'Pressão '+est.olho.toUpperCase()); else out.avisos.push('Pressão fora do normal: '+n.v); i = n.p; continue; }
    }
    if(est.grupo==='ppc'){
      const n = vozInteiro(tk, i);
      if(n){ add('tsPPC', String(n.v), 'Ponto de convergência'); i = n.p; continue; }
    }
    i++;
  }
  return out;
}
/*VOZ-FIM*/

/* botão de microfone e painel do comando de voz (aparece só na tela de exame) */
function pararVozExame(){
  try{ if(window._vzRec){ window._vzAtivo=false; window._vzRec.onend=null; window._vzRec.stop(); } }catch(e){}
  window._vzRec=null; window._vzAtivo=false;
  document.getElementById('vzFab')?.remove(); document.getElementById('vzPainel')?.remove();
}
function iniciarVozExame(ap){
  pararVozExame();
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  const fab = document.createElement('button'); fab.id='vzFab'; fab.type='button'; fab.textContent='🎤'; fab.setAttribute('aria-label','Falar os valores do exame');
  const painel = document.createElement('div'); painel.id='vzPainel'; painel.style.display='none';
  document.body.append(painel, fab);
  let est = vozEstadoNovo(ap.etapa()), chips = [], avisos = [], ouvido = '', status = '';
  const ETAPA_DO_CAMPO = (id)=> /^(ar|fn)/.test(id) ? 3 : /^av/.test(id) ? 2 : /^ts/.test(id) ? 4 : null;
  function desenhar(){
    painel.innerHTML = '<button type="button" class="vz-x" id="vzX" aria-label="Fechar">×</button>'
      + '<div class="vz-status">'+esc(status)+'</div>'
      + (ouvido ? '<div class="vz-ouvi">Ouvi: '+esc(ouvido)+'</div>' : '')
      + (chips.length ? '<div class="vz-chips">'+chips.slice(-6).map(c=>'<span>'+esc(c)+'</span>').join('')+'</div>' : '')
      + (avisos.length ? '<div class="vz-av">'+avisos.map(esc).join('<br>')+'</div>' : '')
      + '<div class="vz-dica">Exemplo: autorrefrator, olho direito, menos um e vinte e cinco, menos meio, eixo cento e oitenta. Diga "olho esquerdo" para trocar de olho, "grau final" para o grau confirmado, "próxima etapa" para avançar. O áudio é processado pelo navegador. Não fale nome nem CPF do paciente.</div>';
    painel.querySelector('#vzX').onclick = ()=>{ parar(); painel.style.display='none'; };
  }
  function aplicar(r, texto){
    r.acoes.forEach(a=>{
      const el = document.getElementById(a.id); if(!el) return;
      const et = ETAPA_DO_CAMPO(a.id); if(et && ap.etapa()!==et) ap.ir(et);
      if(el.tagName==='SELECT'){ const op = [...el.options].find(o=>o.text===a.valor || o.value===a.valor); if(op) el.value = op.value; }
      else if(a.id==='tsObs') el.value = (el.value ? el.value.trim()+' ' : '') + a.valor;
      else el.value = a.valor;
      el.dispatchEvent(new Event('input',{bubbles:true})); el.dispatchEvent(new Event('change',{bubbles:true}));
      el.classList.add('vz-ok'); setTimeout(()=>el.classList.remove('vz-ok'), 2500);
      chips.push(a.texto);
    });
    if(r.cmd==='proximo') ap.ir(ap.etapa()+1);
    if(r.cmd==='voltar') ap.ir(ap.etapa()-1);
    avisos = r.avisos.slice(); ouvido = texto;
    if(!r.acoes.length && !r.cmd && !r.avisos.length) avisos = ['Não entendi. Tente de novo.'];
    desenhar();
  }
  function iniciar(){
    if(!SR){ painel.style.display='block'; status='Este navegador não aceita comando de voz. Use o Chrome.'; desenhar(); return; }
    est = vozEstadoNovo(ap.etapa()); chips = []; avisos = []; ouvido = '';
    const rec = new SR(); rec.lang='pt-BR'; rec.continuous=true; rec.interimResults=true; rec.maxAlternatives=1;
    rec.onresult = (ev)=>{
      for(let i=ev.resultIndex;i<ev.results.length;i++){
        const res = ev.results[i], tx = res[0].transcript;
        if(res.isFinal) aplicar(vozInterpretar(tx, est), tx.trim());
        else { ouvido = tx.trim(); desenhar(); }
      }
    };
    rec.onerror = (e)=>{
      if(e.error==='not-allowed'||e.error==='service-not-allowed'){ status='Permita o microfone nas configurações do navegador.'; window._vzAtivo=false; fab.classList.remove('on'); desenhar(); }
      else if(e.error==='network'){ status='Sem internet para reconhecer a voz.'; desenhar(); }
    };
    rec.onend = ()=>{ if(window._vzAtivo){ try{ rec.start(); }catch(x){} } else fab.classList.remove('on'); };
    window._vzRec = rec; window._vzAtivo = true;
    try{ rec.start(); status='Ouvindo... fale os valores.'; fab.classList.add('on'); }catch(e){ status='Não consegui ligar o microfone.'; }
    painel.style.display='block'; desenhar();
  }
  function parar(){
    window._vzAtivo=false; try{ window._vzRec && window._vzRec.stop(); }catch(e){}
    fab.classList.remove('on'); status='Microfone desligado.'; desenhar();
  }
  fab.onclick = ()=>{ if(window._vzAtivo) parar(); else iniciar(); };
}

function renderProntuario(main){
  const souProfissional = usuarioAtual?.papel === 'profissional' || usuarioAtual?.papel === 'admin';
  if(!souProfissional){
    main.innerHTML = `<div class="card"><h2>Prontuário</h2><p class="sub">Essa área é só para o profissional que faz o exame.</p></div>`;
    return;
  }

  // dados de carimbo/assinatura de quem está logado, pro gabarito impresso puxar
  // o examinador certo (não o profissional escolhido lá na tela de Receita)
  if(usuarioAtual?.papel==='profissional' && !meuCarimbo){
    api('/clinica/usuarios/eu').then(u=> meuCarimbo = u).catch(()=>{});
  }

  // agenda por cidade: agrupa os próximos agendamentos por dia+cidade, pra ele
  // se preparar com antecedência pra onde vai estar e quem já tem marcado
  const hoje = soData(new Date().toISOString());
  const futuros = agendamentos.filter(a=> soData(a.data_hora) >= hoje && a.status!=='cancelado').sort((a,b)=> a.data_hora.localeCompare(b.data_hora));
  const grupos = {};
  futuros.forEach(a=>{
    const dia = soData(a.data_hora);
    const cidadeNome = unidades.find(u=>u.id===a.unidade_id)?.nome || 'Sem cidade definida';
    const chave = dia+'|'+cidadeNome;
    if(!grupos[chave]) grupos[chave] = { dia, cidadeNome, itens:[] };
    grupos[chave].itens.push(a);
  });
  const gruposOrdenados = Object.values(grupos).sort((a,b)=> a.dia.localeCompare(b.dia));

  const agendaHtml = gruposOrdenados.length ? gruposOrdenados.slice(0,15).map(g=>`
    <div class="agenda-cidade-item">
      <div class="agenda-cidade-head"><strong>${fmtData(g.dia)}</strong> · ${g.cidadeNome} <span style="color:var(--ink-soft);">(${g.itens.length} ${g.itens.length===1?'paciente':'pacientes'})</span></div>
      <div class="agenda-cidade-lista">${g.itens.map(a=>`<div class="agenda-item-abrir"><span>${soHora(a.data_hora)} — ${pacienteNome(a.paciente_id)}</span><button type="button" class="link-discreto btn-abrir-prontuario" data-paciente="${a.paciente_id}">abrir prontuário</button></div>`).join('')}</div>
    </div>`).join('') : '<p class="sub">Nenhum agendamento futuro ainda.</p>';

  const pacOpts = pacientes.map(p=>`<option value="${p.id}" ${prontuarioState.pacienteId===p.id?'selected':''}>${esc(p.nome_completo)}</option>`).join('');

  const sintomasHtml = LISTA_SINTOMAS.map((s,i)=>`
    <div class="sintoma-linha ${SINTOMAS_ALERTA.includes(s)?'alerta':''}">
      <span>${s}${SINTOMAS_ALERTA.includes(s)?' <small style="color:#B3261E;">(alerta)</small>':''}</span>
      <label class="sintoma-toggle"><input type="checkbox" class="pntSintoma" data-sintoma="${s}"><span class="sintoma-slider"></span></label>
    </div>`).join('');

  main.innerHTML = `
    <div class="card">
      <h2>Sua agenda por cidade</h2>
      <p class="sub">Veja com antecedência em qual cidade você vai estar e quem já está marcado, pra adiantar o preparo do exame.</p>
      ${agendaHtml}
    </div>
    <div class="card" id="pntCard">
      <h2>Atendimento</h2>
      <p class="sub">Essa área é só sua. Quem agenda não vê o que você escreve aqui.</p>
      <label class="req">Paciente</label>
      <select id="pntPac"><option value="">Selecione...</option>${pacOpts}</select>
      <div id="pntHistorico"></div>
      <div id="pntBanner"></div>
      <h3 style="margin-top:18px;font-size:15px;" id="pntTituloNovo">Novo exame</h3>
      <div class="passos" id="pntPassos">${['História','Visão atual','Grau','Outros testes','Alertas','Conclusão'].map((n,i)=>`<button type="button" class="passo" data-p="${i+1}"><span>${i+1}</span>${n}</button>`).join('')}</div>

      <div class="etapa" data-etapa="1">
        <label>Queixa principal <span style="font-weight:400;color:var(--ink-soft);">(o que o paciente relatou precisar ou sentir)</span></label>
        <textarea id="pntQueixa" placeholder="Ex: dificuldade pra ler de perto, dor de cabeça no fim do dia..."></textarea>
        <label style="margin-top:14px;">Sintomas <span style="font-weight:400;color:var(--ink-soft);">(marque o que o paciente apresenta)</span></label>
        <div class="sintomas-lista">${sintomasHtml}</div>
        <label>Outros sintomas</label>
        <textarea id="pntOutrosSintomas" placeholder="Algo que não está na lista..."></textarea>
        <h3 style="margin-top:18px;font-size:15px;">História do paciente <span style="font-weight:400;color:var(--ink-soft);font-size:12px;">(já vem da ficha. Confirme com o paciente)</span></h3>
        <label>Usa óculos ou lentes hoje?</label><input type="text" id="hxUsa" placeholder="Não usa, óculos, lentes...">
        <label>Último exame de vista</label><input type="text" id="hxUltimo" placeholder="Ex: há 2 anos">
        <label>Doenças <span style="font-weight:400;color:var(--ink-soft);">(diabetes, pressão alta e outras)</span></label><input type="text" id="hxDoencas">
        <label>Remédios que usa</label><input type="text" id="hxRemedios">
        <label>Alergias</label><input type="text" id="hxAlergias">
        <label>Casos na família <span style="font-weight:400;color:var(--ink-soft);">(glaucoma, catarata)</span></label><input type="text" id="hxFamilia">
        <label>Cirurgia nos olhos</label><input type="text" id="hxCirurgia">
        <label>Trabalho e uso de telas</label><input type="text" id="hxTrabalho" placeholder="Ex: escritório, 8 horas no computador">
      </div>

      <div class="etapa" data-etapa="2" style="display:none;">
        <h3 style="margin-top:6px;font-size:15px;">Acuidade visual <span style="font-weight:400;color:var(--ink-soft);font-size:12px;">(escreva como 20/40, 20/20)</span></h3>
        <div class="av-grade">
          <span></span><span class="refr-h">OD</span><span class="refr-h">OE</span>
          <span class="refr-l av-l">Longe sem óculos</span><input class="refr-in" id="avLsOd"><input class="refr-in" id="avLsOe">
          <span class="refr-l av-l">Longe com óculos</span><input class="refr-in" id="avLcOd"><input class="refr-in" id="avLcOe">
          <span class="refr-l av-l">Pinhole (furo)</span><input class="refr-in" id="avPhOd"><input class="refr-in" id="avPhOe">
        </div>
        <div class="row2">
          <div><label>Perto sem óculos <span style="font-weight:400;color:var(--ink-soft);">(os dois olhos)</span></label><input type="text" id="avPsAo" placeholder="J1, J2..."></div>
          <div><label>Perto com óculos</label><input type="text" id="avPcAo" placeholder="J1, J2..."></div>
        </div>
        <p class="sub">Se o paciente não usa óculos, deixe "com óculos" em branco.</p>
      </div>

      <div class="etapa" data-etapa="3" style="display:none;">
      <h3 style="margin-top:18px;font-size:15px;">Autorrefrator <span style="font-weight:400;color:var(--ink-soft);font-size:12px;">(grau sugerido pelo aparelho)</span></h3>
      <div class="refr-grade">
        <span></span><span class="refr-h">Esférico</span><span class="refr-h">Cilíndrico</span><span class="refr-h">Eixo</span>
        <span class="refr-l">OD</span><input class="refr-in" id="arOdEsf" inputmode="decimal" placeholder="-1.25"><input class="refr-in" id="arOdCil" inputmode="decimal" placeholder="-0.50"><input class="refr-in" id="arOdEixo" inputmode="numeric" placeholder="90">
        <span class="refr-l">OE</span><input class="refr-in" id="arOeEsf" inputmode="decimal" placeholder="-1.00"><input class="refr-in" id="arOeCil" inputmode="decimal" placeholder="-0.75"><input class="refr-in" id="arOeEixo" inputmode="numeric" placeholder="85">
      </div>
      <label>Foto do resultado do autorrefrator <span style="font-weight:400;color:var(--ink-soft);">(opcional)</span></label>
      <input type="file" id="arFoto" accept="image/*">
      <div id="arFotoPrev"></div>
      <h3 style="margin-top:18px;font-size:15px;">Grau final confirmado <span style="font-weight:400;color:var(--ink-soft);font-size:12px;">(depois do teste com as lentes)</span></h3>
      <div class="refr-grade refr-grade5">
        <span></span><span class="refr-h">Esférico</span><span class="refr-h">Cilíndrico</span><span class="refr-h">Eixo</span><span class="refr-h">Adição</span>
        <span class="refr-l">OD</span><input class="refr-in" id="fnOdEsf" inputmode="decimal"><input class="refr-in" id="fnOdCil" inputmode="decimal"><input class="refr-in" id="fnOdEixo" inputmode="numeric"><input class="refr-in" id="fnOdAdd" inputmode="decimal">
        <span class="refr-l">OE</span><input class="refr-in" id="fnOeEsf" inputmode="decimal"><input class="refr-in" id="fnOeCil" inputmode="decimal"><input class="refr-in" id="fnOeEixo" inputmode="numeric"><input class="refr-in" id="fnOeAdd" inputmode="decimal">
      </div>
      </div>

      <div class="etapa" data-etapa="4" style="display:none;">
        <h3 style="margin-top:6px;font-size:15px;">Outros testes <span style="font-weight:400;color:var(--ink-soft);font-size:12px;">(preencha o que você fez)</span></h3>
        <div class="row2">
          <div><label>Movimento dos olhos</label><select id="tsMotil"><option value=""></option><option>Normal</option><option>Alterado</option></select></div>
          <div><label>Pupilas</label><select id="tsPupilas"><option value=""></option><option>Normais</option><option>Alteradas</option></select></div>
        </div>
        <div class="row2">
          <div><label>Visão de cores</label><select id="tsCores"><option value=""></option><option>Normal</option><option>Alterada</option><option>Não testado</option></select></div>
          <div><label>Ponto próximo de convergência (cm)</label><input type="text" inputmode="decimal" id="tsPPC" placeholder="Ex: 8"></div>
        </div>
        <div class="row2">
          <div><label>Pressão OD (mmHg)</label><input type="text" inputmode="decimal" id="tsPioOd" placeholder="só se tiver tonômetro"></div>
          <div><label>Pressão OE (mmHg)</label><input type="text" inputmode="decimal" id="tsPioOe"></div>
        </div>
        <label>Observações dos testes</label>
        <textarea id="tsObs"></textarea>
      </div>

      <div class="etapa" data-etapa="5" style="display:none;">
        <h3 style="margin-top:6px;font-size:15px;">Alertas</h3>
        <div id="pntAlertas"></div>
        <label style="margin-top:14px;display:flex;align-items:center;gap:8px;"><input type="checkbox" id="enCheck"> Encaminhar ao oftalmologista</label>
        <div id="enBox" style="display:none;">
          <label>Motivo do encaminhamento</label>
          <textarea id="enMotivo" placeholder="Ex: flashes de luz há 2 dias no olho direito"></textarea>
          <div class="btn-row"><button type="button" class="btn btn-amber" id="btnEnImprimir">Imprimir encaminhamento</button><button type="button" class="btn btn-wpp" id="btnEnZap">Enviar por WhatsApp</button></div>
        </div>
      </div>

      <div class="etapa" data-etapa="6" style="display:none;">
        <label>Observações clínicas <span style="font-weight:400;color:var(--ink-soft);">(achados do exame)</span></label>
        <textarea id="pntObs" placeholder="O que você observou durante o exame..."></textarea>
        <label>Conduta <span style="font-weight:400;color:var(--ink-soft);">(orientação dada: óculos, uso, cuidados)</span></label>
        <textarea id="pntConduta" placeholder="O que foi indicado..."></textarea>
        <label>Voltar em quantos meses?</label>
        <input type="text" inputmode="numeric" id="rtMeses" maxlength="3" style="max-width:120px;">
        <div id="rtSugestao"></div>
        <div id="pntResumoAlertas"></div>
        <label style="margin-top:16px;display:flex;align-items:center;gap:8px;">
          <input type="checkbox" id="pntAbrirGabarito" ${gabaritoAberto?'checked':''}> Preencher gabarito de acuidade visual
          <span style="font-weight:400;color:var(--ink-soft);font-size:12px;">(opcional, exame comum ou admissional de empresa)</span>
        </label>
        <div id="gabaritoBox">${gabaritoAberto ? gabaritoHtml() : ''}</div>
        <div id="crBox" style="display:none;"><label class="req">Motivo da correção</label><input type="text" id="crMotivo" placeholder="Ex: erro de digitação no eixo do OE"></div>
      </div>

      <div class="btn-row pnt-nav">
        <button type="button" class="btn btn-outline" id="pntVoltar">Voltar</button>
        <button type="button" class="btn btn-primary" id="pntProximo">Próximo</button>
      </div>
      <div class="btn-row" id="pntFinal" style="display:none;">
        <button type="button" class="btn btn-primary" id="btnSalvarPront">Salvar e fechar o exame</button>
        <button type="button" class="btn btn-outline" id="btnRascunhoPront">Salvar como rascunho</button>
      </div>
      <div class="btn-row" id="pntPosSalvar" style="display:none;"></div>
    </div>
  `;

  function exameDe(p){ return p.exame || {}; }
  function itemHistoricoHtml(p, i){
    const ex = exameDe(p);
    const sintomasMarcados = p.sintomas ? Object.entries(p.sintomas).filter(([,v])=>v===true).map(([k])=>k) : [];
    const quando = `${fmtData(p.data_exame)} ${new Date(p.criado_em).toLocaleTimeString('pt-BR',{hour:'2-digit',minute:'2-digit'})}`;
    const av = ex.av || {};
    const avTxt = (av.lsOd||av.lsOe||av.lcOd||av.lcOe) ? `<div><strong>Acuidade:</strong> sem óculos OD ${esc(av.lsOd||'-')} · OE ${esc(av.lsOe||'-')}${(av.lcOd||av.lcOe)?` · com óculos OD ${esc(av.lcOd||'-')} · OE ${esc(av.lcOe||'-')}`:''}</div>` : '';
    return `
    <div class="pront-item">
      <div class="pront-item-head">${quando} · ${esc(p.profissional_nome||'')} <span class="pront-estado ${p.fechado_em?'fechado':'rascunho'}">${p.fechado_em?'Fechado':'Rascunho'}</span></div>
      ${p.queixa_principal? `<div><strong>Queixa:</strong> ${esc(p.queixa_principal)}</div>`:''}
      ${sintomasMarcados.length? `<div><strong>Sintomas:</strong><div class="pront-sintomas-tags">${sintomasMarcados.map(s=>`<span class="pront-sintoma-tag ${SINTOMAS_ALERTA.includes(s)?'alerta':''}">${esc(s)}</span>`).join('')}</div></div>`:''}
      ${p.sintomas?.['Outros']? `<div><strong>Outros sintomas:</strong> ${esc(p.sintomas['Outros'])}</div>`:''}
      ${avTxt}
      ${refracaoHistoricoHtml(p.refracao)}
      ${ex.testes && Object.values(ex.testes).some(Boolean) ? `<div><strong>Outros testes:</strong> ${esc(Object.entries({motil:'movimento',pupilas:'pupilas',cores:'cores',ppc:'PPC cm',pioOd:'pressão OD',pioOe:'pressão OE',obs:'obs'}).map(([k,r])=>ex.testes[k]?r+' '+ex.testes[k]:'').filter(Boolean).join(' · '))}</div>`:''}
      ${p.observacoes_clinicas? `<div><strong>Observações:</strong> ${esc(p.observacoes_clinicas)}</div>`:''}
      ${p.conduta? `<div><strong>Conduta:</strong> ${esc(p.conduta)}</div>`:''}
      ${ex.encaminhamento?.sim ? `<div class="pront-enc"><strong>Encaminhado ao oftalmologista:</strong> ${esc(ex.encaminhamento.motivo||'')}</div>`:''}
      ${ex.retorno_meses? `<div><strong>Voltar em:</strong> ${esc(ex.retorno_meses)} meses</div>`:''}
      ${p.gabarito_acuidade? `<div><strong>Gabarito de acuidade:</strong> OD 20/${esc(p.gabarito_acuidade.resultadoOD||'-')} · OE 20/${esc(p.gabarito_acuidade.resultadoOE||'-')}
        <button type="button" class="link-discreto pront-reimprimir" data-id="${p.id}" style="display:inline;width:auto;margin-left:8px;">reimprimir</button></div>`:''}
      <div class="btn-row pront-acoes">
        <button type="button" class="btn btn-outline btn-sm" data-ac="corrigir" data-i="${i}">Corrigir</button>
        <button type="button" class="btn btn-outline btn-sm" data-ac="receita" data-i="${i}">Gerar receita</button>
        ${ex.encaminhamento?.sim ? `<button type="button" class="btn btn-outline btn-sm" data-ac="encaminhar" data-i="${i}">Encaminhamento</button>`:''}
        <button type="button" class="btn btn-outline btn-sm" data-ac="versoes" data-i="${i}">Alterações</button>
      </div>
    </div>`;
  }
  async function carregarHistorico(pacId){
    const box = document.getElementById('pntHistorico');
    if(!pacId){ box.innerHTML=''; return; }
    box.innerHTML = '<p class="sub">Carregando histórico...</p>';
    try{
      const lista = await api(`/prontuarios?paciente_id=${pacId}`);
      prontuarioState.lista = lista;
      box.innerHTML = lista.length ? '<h3 style="margin-top:16px;font-size:15px;">Exames anteriores</h3>' + lista.map(itemHistoricoHtml).join('') : '<p class="sub">Nenhum exame registrado ainda para esse paciente.</p>';
      box.querySelectorAll('.pront-reimprimir').forEach(btn=>{
        btn.onclick = ()=>{
          const item = prontuarioState.lista.find(p=>p.id===btn.dataset.id);
          if(!item?.gabarito_acuidade) return;
          gabaritoAtual = { ...gabaritoVazio(), ...item.gabarito_acuidade };
          const paciente = pacientes.find(x=>x.id===pacId);
          imprimir(gerarHtmlGabarito(paciente));
        };
      });
      box.querySelectorAll('button[data-ac]').forEach(btn=>{
        btn.onclick = async ()=>{
          const item = prontuarioState.lista[+btn.dataset.i];
          if(btn.dataset.ac==='corrigir') iniciarCorrecao(item);
          else if(btn.dataset.ac==='receita') levarGrauParaReceita(item.refracao?.final, item.exame?.av, pacId);
          else if(btn.dataset.ac==='encaminhar') documentoEncaminhamento(pacId, item.exame?.encaminhamento?.motivo||'', item, 'imprimir');
          else if(btn.dataset.ac==='versoes'){
            try{
              const v = await api(`/prontuarios/${item.id}/versoes`);
              openModal(`<h2>Alterações deste exame</h2>${v.length ? v.map(x=>`<div class="list-item"><div><div class="name">${esc(x.usuario_nome||'')}</div><div class="meta">${new Date(x.criado_em).toLocaleString('pt-BR')}${x.motivo?' · '+esc(x.motivo):''}</div></div></div>`).join('') : '<p class="sub">Nenhuma correção feita.</p>'}<div class="btn-row" style="margin-top:12px;"><button class="btn btn-outline" onclick="closeModal()">Fechar</button></div>`);
            }catch(e){ erroApi(e); }
          }
        };
      });
    }catch(e){ erroApi(e); box.innerHTML=''; }
  }

  /* ----- etapas ----- */
  let etapa = 1, editandoId = null, editandoFechado = false;
  const TOTAL_ETAPAS = 6;
  const IDS_HX = {usa:'hxUsa',ultimo:'hxUltimo',doencas:'hxDoencas',remedios:'hxRemedios',alergias:'hxAlergias',familia:'hxFamilia',cirurgia:'hxCirurgia',trabalho:'hxTrabalho'};
  const IDS_AV = {lsOd:'avLsOd',lsOe:'avLsOe',lcOd:'avLcOd',lcOe:'avLcOe',phOd:'avPhOd',phOe:'avPhOe',psAo:'avPsAo',pcAo:'avPcAo'};
  const IDS_TS = {motil:'tsMotil',pupilas:'tsPupilas',cores:'tsCores',ppc:'tsPPC',pioOd:'tsPioOd',pioOe:'tsPioOe',obs:'tsObs'};
  const val = id=> (document.getElementById(id)?.value||'').trim();
  const lerGrupo = ids=>{ const o={}; Object.entries(ids).forEach(([k,id])=>{ o[k]=val(id); }); return o; };
  const gravarGrupo = (ids,o)=>{ Object.entries(ids).forEach(([k,id])=>{ const e=document.getElementById(id); if(e) e.value=(o&&o[k])||''; }); };

  function pacienteAtualObj(){ return pacientes.find(x=>x.id===prontuarioState.pacienteId); }
  function preencherHistoriaDaFicha(){
    const pac = pacienteAtualObj(); const ex = (pac && pac.dados_extras) || {};
    gravarGrupo(IDS_HX, { usa:ex.usa_oculos, ultimo:ex.ultimo_exame, doencas:ex.doencas, remedios:ex.medicamentos, alergias:ex.alergias, familia:ex.historico_familiar, cirurgia:ex.cirurgia_ocular, trabalho:ex.profissao });
    if(ex.queixa && !val('pntQueixa')) document.getElementById('pntQueixa').value = ex.queixa;
  }

  function avDen(t){
    t = String(t||'').trim().replace(',','.');
    let m = /^(\d+)\s*\/\s*(\d+)$/.exec(t); if(m && +m[1]>0) return +m[2]/+m[1];
    m = /^(\d*\.?\d+)$/.exec(t); if(m && +m[1]>0 && +m[1]<=2) return 1/+m[1];
    return null;
  }
  function calcularAlertas(){
    const al = [];
    const marcados = [...main.querySelectorAll('.pntSintoma')].filter(c=>c.checked).map(c=>c.dataset.sintoma);
    marcados.filter(x=>SINTOMAS_ALERTA.includes(x)).forEach(x=> al.push({nivel:'urgente', texto:`Sintoma de alerta: ${x}.`}));
    const hx = lerGrupo(IDS_HX);
    if(/diabet|press[aã]o alta|hipertens/i.test(hx.doencas)) al.push({nivel:'atencao', texto:'Diabetes ou pressão alta: confirme que o paciente fez fundo de olho com oftalmologista no último ano.'});
    if(/glaucoma/i.test(hx.familia)) al.push({nivel:'atencao', texto:'Glaucoma na família: sugira avaliação de pressão e nervo óptico com oftalmologista.'});
    if(hx.cirurgia) al.push({nivel:'atencao', texto:'Cirurgia ocular informada: confira se o acompanhamento com oftalmologista está em dia.'});
    const pac = pacienteAtualObj(); const idade = pac ? idadeDe(pac.data_nascimento) : null;
    const ts = lerGrupo(IDS_TS);
    if(idade!==null && idade>=40 && !ts.pioOd && !ts.pioOe) al.push({nivel:'atencao', texto:'Mais de 40 anos sem pressão do olho medida neste exame. Sugira oftalmologista para medir.'});
    const av = lerGrupo(IDS_AV);
    [['OD',av.lcOd||av.lsOd, av.phOd],['OE',av.lcOe||av.lsOe, av.phOe]].forEach(([olho,melhor])=>{
      const d = avDen(melhor); if(d!==null && d>2) al.push({nivel:'atencao', texto:`${olho} enxerga pior que 20/40 mesmo com a melhor correção registrada. Se o grau final não melhora, encaminhe.`});
    });
    if(ts.motil==='Alterado' || ts.pupilas==='Alteradas') al.push({nivel:'urgente', texto:'Movimento dos olhos ou pupilas alterados: encaminhe ao oftalmologista.'});
    return { al, idade };
  }
  function retornoSugerido(al, idade){
    if(idade!==null && (idade<18 || idade>=65)) return 12;
    return al.length ? 12 : 24;
  }
  function desenharAlertas(){
    const { al, idade } = calcularAlertas();
    const html = al.length ? al.map(a=>`<div class="faixa-alerta ${a.nivel}"><b>${a.nivel==='urgente'?'Urgente':'Atenção'}:</b> ${esc(a.texto)}</div>`).join('') : '<div class="faixa-alerta ok">Nenhum sinal de alerta encontrado com o que foi preenchido.</div>';
    document.getElementById('pntAlertas').innerHTML = html;
    const resumo = document.getElementById('pntResumoAlertas'); if(resumo) resumo.innerHTML = al.length ? `<div class="faixa-alerta ${al.some(a=>a.nivel==='urgente')?'urgente':'atencao'}">${al.length} alerta(s) neste exame. Veja a etapa 5.</div>` : '';
    const urg = al.filter(a=>a.nivel==='urgente');
    const chk = document.getElementById('enCheck');
    if(urg.length && !chk.checked && !chk.dataset.mexeu){ chk.checked = true; document.getElementById('enBox').style.display='block'; if(!val('enMotivo')) document.getElementById('enMotivo').value = urg.map(a=>a.texto.replace(/^Sintoma de alerta: /,'')).join(' ').slice(0,300); }
    const sug = retornoSugerido(al, idade);
    document.getElementById('rtSugestao').innerHTML = `<div class="sugestao-chip">Sugestão: voltar em ${sug} meses ${idade!==null&&(idade<18||idade>=65)?'(idade '+idade+' anos)':(al.length?'(há alertas)':'(adulto sem risco)')} <button type="button" id="rtUsar">Usar ${sug}</button></div>`;
    document.getElementById('rtUsar').onclick = ()=>{ document.getElementById('rtMeses').value = sug; };
    return al;
  }
  function mostrarEtapa(n){
    etapa = Math.max(1, Math.min(TOTAL_ETAPAS, n));
    main.querySelectorAll('.etapa').forEach(e=> e.style.display = (+e.dataset.etapa===etapa) ? 'block' : 'none');
    main.querySelectorAll('#pntPassos .passo').forEach(b=>{ b.classList.toggle('ativo', +b.dataset.p===etapa); b.classList.toggle('feito', +b.dataset.p<etapa); });
    document.getElementById('pntVoltar').style.visibility = etapa===1 ? 'hidden' : 'visible';
    document.getElementById('pntProximo').style.display = etapa===TOTAL_ETAPAS ? 'none' : '';
    document.getElementById('pntFinal').style.display = etapa===TOTAL_ETAPAS ? '' : 'none';
    if(etapa===5 || etapa===6) desenharAlertas();
    document.getElementById('pntPassos').scrollIntoView({behavior:'smooth', block:'start'});
  }
  document.getElementById('pntProximo').onclick = ()=>{
    if(etapa===1 && !prontuarioState.pacienteId){ toast('Selecione o paciente.'); return; }
    mostrarEtapa(etapa+1);
  };
  document.getElementById('pntVoltar').onclick = ()=> mostrarEtapa(etapa-1);
  iniciarVozExame({ etapa:()=>etapa, ir:(n)=>mostrarEtapa(n) });
  main.querySelectorAll('#pntPassos .passo').forEach(b=> b.onclick = ()=>{ if(!prontuarioState.pacienteId){ toast('Selecione o paciente.'); return; } mostrarEtapa(+b.dataset.p); });
  document.getElementById('enCheck').onchange = e=>{ e.target.dataset.mexeu = '1'; document.getElementById('enBox').style.display = e.target.checked ? 'block' : 'none'; };

  /* ----- documentos ----- */
  function prepararDocumento(pacId){
    const pac = pacientes.find(x=>x.id===pacId);
    receitaAtual.pacienteId = pacId;
    const idade = pac ? idadeDe(pac.data_nascimento) : null; if(idade!==null) receitaAtual.idade = String(idade);
    if(usuarioAtual?.papel==='profissional') receitaAtual.profissionalId = usuarioAtual.id;
    return pac;
  }
  function resumoAchados(item){
    const r = item?.refracao?.final, av = item?.exame?.av || {};
    const lin = [];
    if(av.lsOd||av.lsOe) lin.push(`Acuidade sem óculos: OD ${av.lsOd||'-'} · OE ${av.lsOe||'-'}`);
    if(r && (r.odEsf||r.oeEsf)) lin.push(`Grau medido: OD ${[r.odEsf,r.odCil,r.odEixo?'x'+r.odEixo:''].filter(Boolean).join(' ')||'-'} · OE ${[r.oeEsf,r.oeCil,r.oeEixo?'x'+r.oeEixo:''].filter(Boolean).join(' ')||'-'}`);
    return lin;
  }
  function documentoEncaminhamento(pacId, motivo, item, modo){
    const pac = prepararDocumento(pacId);
    const achados = resumoAchados(item);
    if(modo==='imprimir'){
      imprimirDocumento(paginaDoc('Encaminhamento ao oftalmologista', `${pacienteDocHtml()}
        <p style="margin-top:14px;">Encaminho o(a) paciente acima para avaliação com médico oftalmologista.</p>
        <p><b>Motivo:</b> ${esc(motivo||'')}</p>
        ${achados.length?`<p><b>Achados do exame de vista:</b><br>${achados.map(esc).join('<br>')}</p>`:''}
        <div class="rodape">${localDataDocHtml()}${assinaturaDocHtml()}</div>
        <div class="aviso">O exame de vista com refração não substitui a avaliação médica. O diagnóstico e o tratamento de doenças dos olhos são feitos pelo médico oftalmologista.</div>`));
    } else {
      const nome = pac ? primeiroNome(pac.nome_completo) : '';
      abrirWhatsapp(pac?.telefone||'', `Olá, ${nome}! Depois do seu exame de vista na ${clinicaAtual?.nome_fantasia||'clínica'}, recomendamos que você procure um médico oftalmologista. Motivo: ${motivo}. Não deixe para depois.`);
    }
  }
  document.getElementById('btnEnImprimir').onclick = ()=>{ if(!val('enMotivo')){ toast('Escreva o motivo do encaminhamento.'); return; } documentoEncaminhamento(prontuarioState.pacienteId, val('enMotivo'), { refracao:{final:lerRefracaoDoDOM()?.final}, exame:{av:lerGrupo(IDS_AV)} }, 'imprimir'); };
  document.getElementById('btnEnZap').onclick = ()=>{ if(!val('enMotivo')){ toast('Escreva o motivo do encaminhamento.'); return; } documentoEncaminhamento(prontuarioState.pacienteId, val('enMotivo'), null, 'whatsapp'); };

  function levarGrauParaReceita(f, av, pacId){
    if(!f || !(f.odEsf||f.oeEsf||f.odCil||f.oeCil)){ toast('Preencha o grau final confirmado primeiro.'); return; }
    prepararDocumento(pacId);
    ['od','oe'].forEach(o=>{
      const c = o==='od'?'Od':'Oe';
      receitaAtual.longe[o] = { esf:f[o+'Esf']||'', cil:f[o+'Cil']||'', eixo:f[o+'Eixo']||'' };
    });
    receitaAtual.adicao = (f.odAdd || f.oeAdd || '').replace(/^(\d)/,'+$1');
    receitaAtual.pertoAuto = true;
    if(av){ receitaAtual.extras.avOd = av.lcOd || av.lsOd || ''; receitaAtual.extras.avOe = av.lcOe || av.lsOe || ''; }
    toast('Grau levado para a receita. Confira e imprima.');
    switchView('receita');
  }

  /* ----- salvar, corrigir ----- */
  function lerExameCompleto(){
    return {
      historia: lerGrupo(IDS_HX), av: lerGrupo(IDS_AV), testes: lerGrupo(IDS_TS),
      encaminhamento: { sim: document.getElementById('enCheck').checked, motivo: val('enMotivo') },
      retorno_meses: val('rtMeses') || null,
      alertas: calcularAlertas().al,
    };
  }
  function limparFormularioExame(){
    ['pntQueixa','pntObs','pntConduta','pntOutrosSintomas','tsObs','enMotivo','rtMeses','crMotivo'].forEach(id=>{ const e=document.getElementById(id); if(e) e.value=''; });
    gravarGrupo(IDS_HX,{}); gravarGrupo(IDS_AV,{}); gravarGrupo(IDS_TS,{});
    main.querySelectorAll('.pntSintoma').forEach(cb=>cb.checked=false);
    const c = document.getElementById('enCheck'); c.checked=false; delete c.dataset.mexeu; document.getElementById('enBox').style.display='none';
    limparRefracaoDOM();
    gabaritoAtual = gabaritoVazio(); gabaritoAberto = false; chkGabarito.checked = false; gabaritoBox.innerHTML = '';
    editandoId = null; editandoFechado = false;
    document.getElementById('pntBanner').innerHTML=''; document.getElementById('pntTituloNovo').textContent='Novo exame'; document.getElementById('crBox').style.display='none';
    document.getElementById('pntPosSalvar').style.display='none';
  }
  function iniciarCorrecao(item){
    limparFormularioExame();
    editandoId = item.id; editandoFechado = !!item.fechado_em;
    const ex = item.exame || {};
    document.getElementById('pntQueixa').value = item.queixa_principal||'';
    document.getElementById('pntObs').value = item.observacoes_clinicas||'';
    document.getElementById('pntConduta').value = item.conduta||'';
    const sint = item.sintomas || {};
    main.querySelectorAll('.pntSintoma').forEach(cb=> cb.checked = sint[cb.dataset.sintoma]===true);
    document.getElementById('pntOutrosSintomas').value = sint['Outros']||'';
    gravarGrupo(IDS_HX, ex.historia); gravarGrupo(IDS_AV, ex.av); gravarGrupo(IDS_TS, ex.testes);
    const r = item.refracao || {};
    Object.entries(r.autorrefrator||{}).forEach(([k,v])=>{ if(k==='foto') return; const e=document.getElementById('ar'+k.charAt(0).toUpperCase()+k.slice(1)); if(e) e.value=v; });
    Object.entries(r.final||{}).forEach(([k,v])=>{ const e=document.getElementById('fn'+k.charAt(0).toUpperCase()+k.slice(1)); if(e) e.value=v; });
    refracaoFoto = r.autorrefrator?.foto || null;
    if(refracaoFoto) document.getElementById('arFotoPrev').innerHTML = `<img class="refr-foto" src="${refracaoFoto}" alt="">`;
    const en = ex.encaminhamento || {}; const c = document.getElementById('enCheck'); c.checked = !!en.sim; c.dataset.mexeu='1'; document.getElementById('enBox').style.display = en.sim ? 'block':'none'; document.getElementById('enMotivo').value = en.motivo||'';
    document.getElementById('rtMeses').value = ex.retorno_meses||'';
    if(item.gabarito_acuidade){ gabaritoAtual = { ...gabaritoVazio(), ...item.gabarito_acuidade }; gabaritoAberto = true; chkGabarito.checked = true; gabaritoBox.innerHTML = gabaritoHtml(); ligarEventosGabarito(); }
    document.getElementById('pntBanner').innerHTML = `<div class="faixa-alerta atencao">Corrigindo o exame de ${fmtData(item.data_exame)}. ${item.fechado_em?'Como já está fechado, informe o motivo na última etapa. A versão anterior fica guardada.':''}</div>`;
    document.getElementById('pntTituloNovo').textContent = 'Corrigir exame';
    document.getElementById('crBox').style.display = item.fechado_em ? 'block' : 'none';
    mostrarEtapa(1);
  }
  async function salvarExame(fechar){
    if(!prontuarioState.pacienteId){ toast('Selecione um paciente.'); return; }
    const queixa = val('pntQueixa'), obs = val('pntObs'), conduta = val('pntConduta'), outros = val('pntOutrosSintomas');
    const sintomas = {};
    main.querySelectorAll('.pntSintoma').forEach(cb=>{ sintomas[cb.dataset.sintoma] = cb.checked; });
    if(outros) sintomas['Outros'] = outros;
    if(gabaritoAberto) lerGabaritoDoDOM();
    const refracao = lerRefracaoDoDOM();
    const exame = lerExameCompleto();
    const algo = queixa||obs||conduta||outros||refracao||Object.values(sintomas).some(v=>v===true)||gabaritoAberto||Object.values(exame.av).some(Boolean)||Object.values(exame.testes).some(Boolean);
    if(!algo){ toast('Escreva ou marque alguma coisa antes de salvar.'); return; }
    if(exame.encaminhamento.sim && !exame.encaminhamento.motivo){ toast('Escreva o motivo do encaminhamento (etapa 5).'); mostrarEtapa(5); return; }
    const corpo = { queixa_principal: queixa||null, sintomas, observacoes_clinicas: obs||null, conduta: conduta||null, gabarito_acuidade: gabaritoAberto ? gabaritoAtual : null, refracao, exame, fechar };
    try{
      let salvo;
      if(editandoId){
        corpo.motivo = val('crMotivo');
        if(editandoFechado && !corpo.motivo){ toast('Informe o motivo da correção.'); return; }
        salvo = await api(`/prontuarios/${editandoId}`, { method:'PUT', body:corpo });
      } else {
        salvo = await api('/prontuarios', { method:'POST', body:{ paciente_id: prontuarioState.pacienteId, ...corpo } });
      }
      toast(fechar ? 'Exame salvo e fechado.' : 'Rascunho salvo.');
      const pacId = prontuarioState.pacienteId;
      const fnGrau = refracao?.final, avSalvo = exame.av;
      limparFormularioExame(); preencherHistoriaDaFicha();
      await carregarHistorico(pacId);
      mostrarEtapa(1);
      const pos = document.getElementById('pntPosSalvar'); pos.style.display = 'flex';
      pos.innerHTML = `<button type="button" class="btn btn-amber" id="psReceita">Gerar receita com este grau</button>${exame.encaminhamento.sim?'<button type="button" class="btn btn-outline" id="psEnc">Imprimir encaminhamento</button>':''}`;
      document.getElementById('psReceita').onclick = ()=> levarGrauParaReceita(fnGrau, avSalvo, pacId);
      const pe = document.getElementById('psEnc'); if(pe) pe.onclick = ()=> documentoEncaminhamento(pacId, exame.encaminhamento.motivo, { refracao:{final:fnGrau}, exame:{av:avSalvo} }, 'imprimir');
    }catch(e){ erroApi(e); }
  }
  document.getElementById('btnSalvarPront').onclick = ()=> salvarExame(true);
  document.getElementById('btnRascunhoPront').onclick = ()=> salvarExame(false);

  document.getElementById('pntPac').onchange = e=>{
    prontuarioState.pacienteId = e.target.value;
    limparFormularioExame(); preencherHistoriaDaFicha(); mostrarEtapa(1);
    carregarHistorico(e.target.value);
  };
  if(prontuarioState.pacienteId){ preencherHistoriaDaFicha(); carregarHistorico(prontuarioState.pacienteId); }

  // atalho de um clique: direto da agenda do dia já abre o prontuário desse paciente,
  // sem precisar procurar na lista toda durante o atendimento
  main.querySelectorAll('.btn-abrir-prontuario').forEach(btn=>{
    btn.onclick = ()=>{
      const pacId = btn.dataset.paciente;
      document.getElementById('pntPac').value = pacId;
      prontuarioState.pacienteId = pacId;
      limparFormularioExame(); preencherHistoriaDaFicha(); mostrarEtapa(1);
      carregarHistorico(pacId);
      document.getElementById('pntPac').scrollIntoView({behavior:'smooth', block:'center'});
    };
  });

  refracaoFoto = null;
  document.getElementById('arFoto').onchange = async e=>{
    const f = e.target.files[0]; const pv = document.getElementById('arFotoPrev');
    if(!f){ refracaoFoto=null; pv.innerHTML=''; return; }
    try{ refracaoFoto = await reduzirImagem(f); pv.innerHTML = `<img class="refr-foto" src="${refracaoFoto}" alt="">`; }
    catch(err){ refracaoFoto=null; pv.innerHTML=''; toast('Não consegui ler essa foto.'); }
  };

  const chkGabarito = document.getElementById('pntAbrirGabarito');
  const gabaritoBox = document.getElementById('gabaritoBox');
  if(chkGabarito) chkGabarito.onchange = ()=>{
    gabaritoAberto = chkGabarito.checked;
    gabaritoBox.innerHTML = gabaritoAberto ? gabaritoHtml() : '';
    if(gabaritoAberto) ligarEventosGabarito();
  };
  if(gabaritoAberto) ligarEventosGabarito();

  function ligarEventosGabarito(){
    const btnImprimir = document.getElementById('btnImprimirGabarito');
    if(btnImprimir) btnImprimir.onclick = ()=>{
      lerGabaritoDoDOM();
      const paciente = pacientes.find(p=>p.id===prontuarioState.pacienteId);
      imprimir(gerarHtmlGabarito(paciente));
    };
  }

  function lerGabaritoDoDOM(){
    const g = gabaritoAtual;
    g.idadePaciente = document.getElementById('gIdade').value;
    g.empresa = document.getElementById('gEmpresa').value;
    g.funcao = document.getElementById('gFuncao').value;
    g.setor = document.getElementById('gSetor').value;
    g.usaOculos = document.getElementById('gUsaOculos').value;
    g.frequenciaUso = document.getElementById('gFrequencia').value;
    g.tipoLenteAtual = document.getElementById('gTipoLenteAtual').value;
    g.tempoUsoAtual = document.getElementById('gTempoUso').value;
    g.ultimaConsultaEspecialista = document.getElementById('gUltimaConsulta').value;
    g.jaFezExameEspecialista = document.getElementById('gJaFezExame').value;
    g.possuiDoencaOcular = document.getElementById('gPossuiDoenca').value;
    g.doencaOcularQual = document.getElementById('gDoencaQual').value;
    g.senteDificuldadeVisual = document.getElementById('gDificuldade').value;
    g.dificuldadeQual = document.getElementById('gDificuldadeQual').value;
    g.testeComCorrecao = document.getElementById('gComCorrecao').value;
    g.linhasOD = LINHAS_ACUIDADE.map((_,i)=>{
      const marcado = main.querySelector(`input[name="gab_od_${i}"]:checked`);
      return marcado ? marcado.value==='acertou' : null;
    });
    g.linhasOE = LINHAS_ACUIDADE.map((_,i)=>{
      const marcado = main.querySelector(`input[name="gab_oe_${i}"]:checked`);
      return marcado ? marcado.value==='acertou' : null;
    });
    g.resultadoOD = document.getElementById('gResultadoOD').value;
    g.resultadoOE = document.getElementById('gResultadoOE').value;
    g.avLongeSemOD = document.getElementById('gAvSemOD').value;
    g.avLongeSemOE = document.getElementById('gAvSemOE').value;
    g.avLongeSemAO = document.getElementById('gAvSemAO').value;
    g.avLongeComOD = document.getElementById('gAvComOD').value;
    g.avLongeComOE = document.getElementById('gAvComOE').value;
    g.avLongeComAO = document.getElementById('gAvComAO').value;
    g.avPertoOD = document.getElementById('gAvPertoOD').value;
    g.avPertoOE = document.getElementById('gAvPertoOE').value;
    g.avPertoAO = document.getElementById('gAvPertoAO').value;
    g.testeCores = document.getElementById('gTesteCores').value;
    g.testeCoresAcertos = document.getElementById('gTesteCoresAcertos').value;
    g.condutaGabarito = document.getElementById('gConduta').value;
    g.observacoesGabarito = document.getElementById('gObservacoes').value;
  }

  mostrarEtapa(1);
}

const REFR_CAMPOS = {
  ar: ['arOdEsf','arOdCil','arOdEixo','arOeEsf','arOeCil','arOeEixo'],
  fn: ['fnOdEsf','fnOdCil','fnOdEixo','fnOdAdd','fnOeEsf','fnOeCil','fnOeEixo','fnOeAdd']
};
let refracaoFoto = null;
function lerRefracaoDoDOM(){
  const v = id=> (document.getElementById(id)?.value||'').trim().replace(',', '.');
  const r = { autorrefrator:{}, final:{} };
  REFR_CAMPOS.ar.forEach(id=>{ r.autorrefrator[id.slice(2,3).toLowerCase()+id.slice(3)] = v(id); });
  REFR_CAMPOS.fn.forEach(id=>{ r.final[id.slice(2,3).toLowerCase()+id.slice(3)] = v(id); });
  if(refracaoFoto) r.autorrefrator.foto = refracaoFoto;
  const tem = o=> Object.values(o).some(x=>x);
  if(!tem(r.autorrefrator) && !tem(r.final)) return null;
  return r;
}
function limparRefracaoDOM(){
  [...REFR_CAMPOS.ar, ...REFR_CAMPOS.fn].forEach(id=>{ const e=document.getElementById(id); if(e) e.value=''; });
  refracaoFoto = null;
  const f=document.getElementById('arFoto'); if(f) f.value='';
  const pv=document.getElementById('arFotoPrev'); if(pv) pv.innerHTML='';
}
function reduzirImagem(file, max=1200, qual=0.7){
  return new Promise((res,rej)=>{
    const img = new Image(); const url = URL.createObjectURL(file);
    img.onload = ()=>{
      const k = Math.min(1, max/Math.max(img.width,img.height));
      const c = document.createElement('canvas'); c.width = Math.round(img.width*k); c.height = Math.round(img.height*k);
      c.getContext('2d').drawImage(img,0,0,c.width,c.height);
      URL.revokeObjectURL(url); res(c.toDataURL('image/jpeg', qual));
    };
    img.onerror = ()=>{ URL.revokeObjectURL(url); rej(new Error('Imagem inválida')); };
    img.src = url;
  });
}
function refracaoHistoricoHtml(r){
  if(!r) return '';
  const bloco = (titulo, o, comAdd)=>{
    if(!o || !Object.entries(o).some(([k,x])=>k!=='foto' && x)) return '';
    const olho = (nome, p)=>`<tr><td><strong>${nome}</strong></td><td style="padding:0 10px;">${esc(o[p+'Esf']||'-')}</td><td style="padding:0 10px;">${esc(o[p+'Cil']||'-')}</td><td style="padding:0 10px;">${esc(o[p+'Eixo']||'-')}</td>${comAdd?`<td style="padding:0 10px;">${esc(o[p+'Add']||'-')}</td>`:''}</tr>`;
    return `<div style="margin-top:6px;"><strong>${titulo}</strong>
      <table style="font-size:13px;border-collapse:collapse;margin-top:4px;"><tr><th></th><th>Esf</th><th>Cil</th><th>Eixo</th>${comAdd?'<th>Adição</th>':''}</tr>${olho('OD','od')}${olho('OE','oe')}</table></div>`;
  };
  const foto = r.autorrefrator?.foto && /^data:image\//.test(r.autorrefrator.foto) ? `<img class="refr-foto" src="${r.autorrefrator.foto}" alt="Autorrefrator">` : '';
  return bloco('Autorrefrator', r.autorrefrator, false) + foto + bloco('Grau final confirmado', r.final, true);
}

function renderConfirmacao(main){
  const hoje = new Date().toISOString().slice(0,10);
  const futuros = agendamentos.filter(a=> soData(a.data_hora) >= hoje && a.status!=='cancelado').sort((a,b)=> a.data_hora.localeCompare(b.data_hora));
  if(!futuros.length){ main.innerHTML = `<div class="card"><div class="empty"><div class="ic">✅</div>Nenhum agendamento futuro para confirmar.</div></div>`; return; }
  const opts = futuros.map(a=>`<option value="${a.id}">${fmtData(a.data_hora)} ${soHora(a.data_hora)} — ${pacienteNome(a.paciente_id)}</option>`).join('');
  main.innerHTML = `
    <div class="card"><h2>Confirmação do exame</h2><label>Selecione o agendamento</label><select id="confSel">${opts}</select></div>
    <div class="card" id="confCard" style="text-align:center;"></div>`;
  function draw(){
    const a = agendamentos.find(x=>x.id===document.getElementById('confSel').value);
    if(!a) return;
    document.getElementById('confCard').innerHTML = `
      <p class="sub" style="margin-bottom:2px;">Paciente</p>
      <h2 style="margin:0 0 18px;">${pacienteNome(a.paciente_id)}</h2>
      <p class="display" style="font-size:40px;margin:0;color:var(--teal-900);">${fmtData(a.data_hora)}</p>
      <p class="display" style="font-size:26px;margin:4px 0 16px;color:var(--teal-700);">${soHora(a.data_hora)}</p>
      <p style="font-size:14.5px;color:var(--ink-soft);">${a.local||clinicaAtual?.local_exame_padrao||'Local não informado'}</p>
      <span class="pill-tag status-${a.status}" style="margin-top:10px;display:inline-block;">${a.status}</span>`;
  }
  document.getElementById('confSel').onchange = draw;
  draw();
}

/* ========================= MASTER ========================= */
function mostrarAcessoNovo(u){
  const link = (SERVIDOR_PROPRIO ? location.origin + '/' : (API_BASE || '')) + (u.papel ? `?entrada=${u.papel==='atendente'?'atendente':u.papel}` : '');
  const nomePapel = u.papel==='atendente' ? 'agendador' : (u.papel==='profissional' ? 'profissional' : 'administrador');
  const texto = `Acesso ao sistema da ${clinicaAtual?.nome_fantasia||'clínica'}\nLink: ${link}\nUsuário (e-mail): ${u.email}\nSenha: ${u.senha}${u.cidade?`\nCidade: ${u.cidade}`:''}\nDepois de entrar, troque a senha em Meu perfil.`;
  openModal(`<h2>Acesso de ${esc(u.nome)} criado</h2><p class="sub">Envie estes dados para ${esc(u.nome)} (${nomePapel}). Esta é a única vez que a senha aparece.</p>
    <textarea id="acNovoTxt" readonly style="width:100%;height:150px;font:14px/1.5 Arial,sans-serif;padding:10px;border:1px solid var(--line);border-radius:8px;">${esc(texto)}</textarea>
    <div class="btn-row" style="margin-top:10px;"><button class="btn btn-primary" id="acCopiar">Copiar</button><a class="btn btn-outline" id="acZap" target="_blank" rel="noopener" href="https://wa.me/?text=${encodeURIComponent(texto)}" style="text-align:center;text-decoration:none;">Enviar pelo WhatsApp</a><button class="btn btn-outline" onclick="closeModal()">Fechar</button></div>`);
  document.getElementById('acCopiar').onclick = async ()=>{
    try{ await navigator.clipboard.writeText(texto); toast('Copiado.'); }
    catch(e){ const t=document.getElementById('acNovoTxt'); t.select(); document.execCommand('copy'); toast('Copiado.'); }
  };
}
/* ========================= BOAS-VINDAS ========================= */
/* Base legal do exame de vista por optometrista: aviso na primeira entrada e consulta a qualquer hora (vigilância sanitária) */
const FONTES_LEGAIS = [
  ['STF, ADPF 131, liminar do ministro Gilmar Mendes (08/10/2021)','https://www.conjur.com.br/wp-content/uploads/2023/09/gilmar-impede-restricoes-atuacao.pdf'],
  ['STJ, ação rescisória 7.106 (13/05/2026)','https://www.migalhas.com.br/quentes/455888/stj-optometrista-com-diploma-superior-pode-realizar-exame-de-vista'],
  ['Procon do Ministério Público de MG, Nota Técnica 03/2025','https://www.mpmg.mp.br/data/files/00/97/28/3F/8483B91002A442B9B9A8F9C2/Nota%20Tecnica%20n%203_Atuacao%20de%20profissionais%20optometristas%20com%20formacao%20em%20curso%20superior%20_Procon-MPMG_19%20de%20dezembro%20de%202025.pdf'],
  ['CFM: STF e a posição dos médicos (2020)','https://portal.cfm.org.br/noticias/cfm-pela-seguranca-do-paciente-stf-garante-que-diagnosticos-e-prescricoes-oftalmologicos-sao-exclusivos-dos-medicos/'],
];
function baseLegalCorpoHtml(){
  const li = t=>`<li style="margin:6px 0;">${t}</li>`;
  return `
    <h3 style="margin:12px 0 4px;font-size:15px;">O que as decisões dizem</h3>
    <ul style="padding-left:18px;margin:0;">
      ${li('<b>08/10/2021, STF (ADPF 131):</b> o ministro Gilmar Mendes excluiu dos efeitos da decisão de 2020 os profissionais formados em curso superior reconhecido pelo Estado.')}
      ${li('<b>13/05/2026, STJ (ação rescisória 7.106):</b> optometrista com curso superior reconhecido pode fazer exame de vista.')}
      ${li('<b>Dezembro de 2025, Procon do Ministério Público de MG:</b> esse profissional pode examinar e prescrever óculos e lentes para erro de refração.')}
    </ul>
    <h3 style="margin:14px 0 4px;font-size:15px;">O que o optometrista não faz</h3>
    <ul style="padding-left:18px;margin:0;">
      ${li('Não diagnostica doença, não prescreve remédio e não faz procedimento invasivo.')}
      ${li('Se suspeitar de doença nos olhos, encaminha o paciente ao oftalmologista.')}
    </ul>
    <h3 style="margin:14px 0 4px;font-size:15px;">O que ter à mão se a vigilância visitar</h3>
    <ul style="padding-left:18px;margin:0;">
      ${li('Diploma de curso superior reconhecido do profissional e o número do registro, quando houver.')}
      ${li('Registro do estabelecimento no CNES.')}
      ${li('Atendimento separado da área de venda de óculos.')}
      ${li('Exame sem obrigar a compra de óculos ou lentes, mesmo quando é gratuito.')}
      ${li('Receita entregue ao paciente, que pode usá-la em qualquer ótica.')}
      ${li('Aviso de que o exame não substitui a consulta com oftalmologista. Ele sai na receita deste sistema.')}
    </ul>
    <h3 style="margin:14px 0 4px;font-size:15px;">Atenção</h3>
    <p style="margin:4px 0;">O CBO e o CFM defendem que exame de vista e prescrição são atos médicos e citam os decretos 20.931 de 1932 e 24.492 de 1934. A Justiça decide de formas diferentes conforme o estado. Para lente de contato, não há decisão de tribunal superior que trate dela de forma expressa. Estas informações não são parecer jurídico. Confirme com um advogado de saúde da sua cidade.</p>
    <h3 style="margin:14px 0 4px;font-size:15px;">Fontes</h3>
    <ul style="padding-left:18px;margin:0;">${FONTES_LEGAIS.map(([t,u])=>`<li style="margin:4px 0;"><a href="${u}" target="_blank" rel="noopener">${esc(t)}</a></li>`).join('')}</ul>`;
}
function abrirBaseLegal(primeira){
  openModal(`<h2>Base legal do exame de vista por optometrista</h2>
    ${primeira?'<p class="sub">Aviso da primeira entrada. Para ler de novo, toque em Base legal na tela Início.</p>':''}
    <div style="max-height:58vh;overflow:auto;font-size:14px;line-height:1.5;">${baseLegalCorpoHtml()}</div>
    <div class="btn-row" style="margin-top:12px;"><button class="btn btn-primary" id="blOk">Entendi</button><button class="btn btn-outline" id="blImp">Imprimir para a fiscalização</button></div>`);
  document.getElementById('blOk').onclick = closeModal;
  document.getElementById('blImp').onclick = ()=> imprimir(`<h1 style="font-size:18pt;">Base legal do exame de vista por optometrista</h1><div style="font-size:11pt;line-height:1.5;">${baseLegalCorpoHtml().replace(/target="_blank"/g,'')}</div><p style="font-size:9pt;color:#666;margin-top:14px;">${esc(clinicaAtual?.nome_fantasia||'')} · impresso em ${fmtData(new Date().toISOString())}</p>`);
}
function baseLegalPrimeira(){
  if(usuarioAtual?.papel==='atendente') return;
  try{ const k='agend_legal_'+(usuarioAtual?.email||''); if(localStorage.getItem(k)) return; localStorage.setItem(k,'1'); }catch(e){ return; }
  setTimeout(()=>abrirBaseLegal(true), 500);
}

function renderInicio(main){
  const nome = (usuarioAtual?.nome||'').split(' ')[0];
  const papel = usuarioAtual?.papel;
  const cidade = minhaUnidade()?.nome;
  const passo = (n,t,d)=>`<div style="display:flex;gap:12px;align-items:flex-start;margin:10px 0;"><div style="flex:0 0 30px;height:30px;border-radius:50%;background:#1F6F8B;color:#fff;font-weight:700;display:flex;align-items:center;justify-content:center;">${n}</div><div><b>${t}</b><div class="sub" style="margin:2px 0 0;">${d}</div></div></div>`;
  const bloco = (ic,t,d)=>`<div style="flex:1 1 220px;border:1px solid #E1E6EA;border-radius:12px;padding:14px;background:#fff;"><div style="font-size:24px;">${ic}</div><b style="display:block;margin:4px 0;">${t}</b><span class="sub" style="margin:0;">${d}</span></div>`;
  let guia = '';
  if(papel==='atendente'){
    guia = `<h3 style="margin:18px 0 4px;font-size:15px;">Como marcar um exame${cidade?' em '+esc(cidade):''}</h3>
      ${passo(1,'Abra a Agenda','Escolha o dia. Os horários livres aparecem em cada dia aberto.')}
      ${passo(2,'Toque em um horário livre','Digite o nome e o telefone do paciente e confirme.')}
      ${passo(3,'No dia do exame, abra a Fila do dia','Toque em Chegou quando o paciente chegar.')}
      ${passo(4,'Use Confirmar e Mensagens','Confirme o comparecimento e envie a mensagem ao paciente.')}
      ${passo(5,'Se alguém cancelar','Veja a Lista de espera e ofereça o horário.')}`;
  } else if(papel==='profissional'){
    guia = `<h3 style="margin:18px 0 4px;font-size:15px;">Seu dia em 5 passos</h3>
      ${passo(1,'Abra a Fila do dia','Veja quem já chegou e quem está esperando.')}
      ${passo(2,'Toque em Iniciar','O paciente passa para Em atendimento.')}
      ${passo(3,'Abra Atendimento e faça o exame','Use o botão do microfone para ditar os valores. Confira cada campo.')}
      ${passo(4,'Emita a receita','Em Receita/Atestado, o grau do exame já vem preenchido.')}
      ${passo(5,'Toque em Finalizar na Fila do dia','O paciente vai para Atendidos e entra nos relatórios.')}`;
  } else {
    guia = `<div id="bvCheck"></div><h3 style="margin:18px 0 4px;font-size:15px;">Para começar</h3>
      ${passo(1,'Cadastre as cidades','Em Master, crie cada cidade onde haverá exame de vista.')}
      ${passo(2,'Abra os dias e horários','Em Agenda de exame de vista, defina dias e horários de cada cidade.')}
      ${passo(3,'Crie os agendadores','Em Usuários da clínica, escolha o papel Agendador e a cidade. Envie o acesso pelo WhatsApp.')}
      ${passo(4,'Acompanhe','No Painel e no Financeiro você vê exames, comparecimento e valores.')}`;
  }
  main.innerHTML = `<div class="card">
    <h2>Bem-vindo${nome?', '+esc(nome):''}</h2>
    <p class="sub">Clínica de Visão: sistema de agendamento e atendimento de exame de vista em várias cidades. Versão ${esc(versaoSistema?.versao||'')}.</p>
    <p style="margin:10px 0;">Os agendadores marcam os pacientes de qualquer lugar, pelo celular ou pelo computador. Cada agendador vê só a cidade dele. A clínica recebe a agenda pronta e o paciente chega com horário e local confirmados.</p>
    <div style="display:flex;flex-wrap:wrap;gap:10px;margin:14px 0;">
      ${bloco('🗓️','Agenda por cidade','Dias e horários de cada cidade, sem choque de horário.')}
      ${bloco('✅','Confirmação e envios','Confirme o paciente e envie a mensagem com dia, hora e local.')}
      ${bloco('👁️','Teste na tela','19 testes de visão: acuidade, Snellen, leitura de perto, daltonismo e educação ocular.')}
      ${bloco('📋','Ficha do paciente','Dados, receita, atestado, prontuário e retorno em um lugar só.')}
    </div>
    ${guia}
    <button class="btn btn-primary btn-block" id="bvIr" style="margin-top:14px;">${papel==='atendente'?'Ir para a Agenda':'Ir para o Painel'}</button>
    <button class="btn btn-outline btn-block" id="bvLegal" style="margin-top:8px;">Base legal do exame de vista (vigilância)</button>
    <p class="sub" style="margin-top:10px;">Para ver esta tela de novo, toque em Início no menu.</p>
  </div>`;
  document.getElementById('bvLegal').onclick = ()=> abrirBaseLegal(false);
  if(papel!=='atendente') montarChecklistInicio();
  document.getElementById('bvIr').onclick = ()=> switchView(papel==='atendente'?'agenda':'painel');
}
async function montarChecklistInicio(){
  const box = document.getElementById('bvCheck'); if(!box) return;
  let ags=[], us=[];
  try{ ags = await api('/agendas'); }catch(e){}
  try{ us = await api('/clinica/usuarios'); }catch(e){}
  let seg = null; try{ seg = await api('/clinica/seguranca-status'); }catch(e){}
  let bk = null; try{ bk = await api('/clinica/backup-status'); }catch(e){}
  const itens = [
    ['Dados da clínica (endereço e telefone)', !!(clinicaAtual?.endereco && clinicaAtual?.telefone), 'master'],
    ['Pelo menos uma cidade cadastrada', unidades.length>0, 'master'],
    ['Tipo de atendimento com duração', tiposAtendimento.length>0, 'master'],
    ['Dias e horários abertos', Array.isArray(ags) && ags.length>0, 'master'],
    ['Pelo menos um agendador criado', Array.isArray(us) && us.some(u=>u.papel==='atendente'), 'master'],
    ...(seg ? [
      ['Backup baixado nos últimos 7 dias', !!(bk && bk.dias!==null && bk.dias<7), 'master'],
      ['Dados criptografados no servidor', seg.criptografia, 'master'],
      ['Digital, rosto ou código do celular ativo para o Master', seg.com_biometria>0 || seg.com_codigo>0, 'master'],
    ] : []),
  ];
  const feitos = itens.filter(i=>i[1]).length;
  if(feitos===itens.length){ box.innerHTML = '<p class="sub" style="margin:14px 0 0;">Configuração inicial completa.</p>'; return; }
  box.innerHTML = `<div style="margin:16px 0;border:1px solid #E1E6EA;border-radius:12px;padding:14px;background:#F7FAFB;">
    <b>Configuração inicial: ${feitos} de ${itens.length}</b>
    <div style="height:6px;background:#E1E6EA;border-radius:4px;margin:8px 0 10px;"><div style="height:6px;width:${feitos*100/itens.length}%;background:#1F6F8B;border-radius:4px;"></div></div>
    ${itens.map(i=>`<div style="margin:6px 0;color:${i[1]?'#2E7D4F':'inherit'};">${i[1]?'✔':'○'} ${i[0]}</div>`).join('')}
    <button class="btn btn-outline btn-block" id="bvMaster" style="margin-top:10px;">Abrir Master</button></div>`;
  document.getElementById('bvMaster').onclick = ()=> switchView('master');
}
async function montarTotpPerfil(){
  const box = document.getElementById('pfTpBox'); if(!box) return;
  let ativo = false; try{ ativo = (await api('/auth/totp')).ativo; }catch(e){ box.innerHTML=''; return; }
  if(ativo){
    box.innerHTML = `<p class="sub" style="color:#2E7D4F;font-weight:600;">Ativo neste usuário.</p><button class="btn btn-outline btn-block" id="pfTpOff">Desligar</button>`;
    document.getElementById('pfTpOff').onclick = async ()=>{
      const s = prompt('Para desligar, digite sua senha:'); if(!s) return;
      try{ await api('/auth/totp', { method:'DELETE', body:{ senha:s } }); toast('Código do celular desligado.'); montarTotpPerfil(); }catch(e){ erroApi(e); }
    };
    return;
  }
  box.innerHTML = `<button class="btn btn-outline btn-block" id="pfTpOn">Ativar</button>`;
  document.getElementById('pfTpOn').onclick = async ()=>{
    try{
      const r = await api('/auth/totp/iniciar', { method:'POST', body:{} });
      let img = ''; try{ const qr = qrcode(0,'M'); qr.addData(r.otpauth); qr.make(); img = qr.createImgTag(5,6); }catch(e){}
      box.innerHTML = `<p class="sub">1. Abra o aplicativo de códigos no celular e escolha adicionar conta.<br>2. Leia este quadro com a câmera, ou digite a chave abaixo.<br>3. Digite aqui os 6 números que aparecerem.</p>
        <div style="text-align:center;margin:8px 0;">${img}</div>
        <p class="sub" style="word-break:break-all;text-align:center;"><b>${esc(r.segredo)}</b></p>
        <input type="text" id="pfTpCod" inputmode="numeric" maxlength="7" placeholder="6 números" style="text-align:center;font-size:20px;">
        <button class="btn btn-primary btn-block" id="pfTpOk" style="margin-top:8px;">Confirmar e ativar</button>`;
      document.getElementById('pfTpOk').onclick = async ()=>{
        try{ await api('/auth/totp/confirmar', { method:'POST', body:{ codigo: document.getElementById('pfTpCod').value } }); toast('Código do celular ativado.'); montarTotpPerfil(); }
        catch(e){ erroApi(e); }
      };
    }catch(e){ erroApi(e); }
  };
}
function renderPerfil(main){
  main.innerHTML = `<div class="card"><h2>Meu perfil</h2>
    <p class="sub">${esc(usuarioAtual?.email||'')} · ${esc(usuarioAtual?.papel==='atendente'?'agendador':usuarioAtual?.papel||'')}${minhaUnidade()? ' · '+esc(minhaUnidade().nome):''}</p>
    <label>Meu nome</label><input type="text" id="pfNome" value="${esc(usuarioAtual?.nome||'')}">
    <h3 style="margin:16px 0 4px;font-size:15px;">Trocar senha</h3>
    <p class="sub">Deixe em branco se não quer trocar.</p>
    <label>Senha atual</label><input type="password" id="pfAtual" autocomplete="current-password">
    <label>Senha nova (mínimo 6 letras ou números)</label><input type="password" id="pfNova" autocomplete="new-password">
    <button class="btn btn-primary btn-block" id="pfSalvar" style="margin-top:12px;">Salvar</button>
    <div class="btn-instalar" style="display:none;"><h3 style="margin:20px 0 4px;font-size:15px;">Instalar no celular</h3>
    <p class="sub">Coloca o ícone da Clínica de Visão na tela do celular e abre como um aplicativo.</p>
    <button class="btn btn-ghost btn-block" id="pfInstalar" type="button">Instalar o app</button></div>
    <h3 style="margin:20px 0 4px;font-size:15px;">Aparência deste aparelho</h3>
    <div id="pfAp">${aparenciaHtml()}</div>
    <h3 style="margin:20px 0 4px;font-size:15px;">Código do celular (segunda senha)</h3>
    <p class="sub" id="pfTpTxt">Uma segurança a mais: além da senha, o sistema pede 6 números que mudam a cada 30 segundos, de um aplicativo no seu celular.</p>
    <div id="pfTpBox"></div>
    <h3 style="margin:20px 0 4px;font-size:15px;">Digital ou rosto</h3>
    <p class="sub" id="pfBioTxt">${usuarioAtual?.papel==='admin' ? 'Depois de ativar, o Master entra com e-mail e senha e confirma com a digital ou o rosto.' : 'Depois de ativar, você entra só com a digital ou o rosto, sem digitar a senha.'}</p>
    <div id="pfBioLista"></div>
    <button class="btn btn-outline btn-block" id="pfBioAtivar" style="margin-top:8px;">Ativar neste aparelho</button>
    <button class="btn btn-outline btn-block" id="pfSair" style="margin-top:8px;">Sair do sistema</button>
    <button class="btn btn-outline btn-block" id="pfSairTodos" style="margin-top:8px;">Sair de todos os aparelhos</button>
    <p class="sub">Use se perdeu o celular ou acha que alguém usou seu acesso. Todos os aparelhos precisam entrar de novo.</p>
    <p id="pfErr" style="color:#C1462F;font-size:12.5px;margin-top:8px;"></p></div>`;
  ligarAparencia(document.getElementById('pfAp'));
  const bInst = document.getElementById('pfInstalar'); if(bInst) bInst.onclick = instalarApp; atualizarBotoesInstalar();
  montarTotpPerfil();
  document.getElementById('pfSair').onclick = sair;
  document.getElementById('pfSairTodos').onclick = async ()=>{
    if(!confirm('Sair de todos os aparelhos? Você também vai precisar entrar de novo.')) return;
    try{ await api('/auth/sair-todos', { method:'POST', body:{} }); }catch(e){}
    sair();
  };
  async function listarBio(){
    const box = document.getElementById('pfBioLista'); if(!box) return;
    try{
      const l = await api('/auth/passkeys');
      box.innerHTML = l.length ? l.map(x=>`<div class="list-item"><div><div class="name">${esc(x.nome_aparelho||'Aparelho')}</div><div class="meta">Ativado em ${fmtData(x.criado_em)}</div></div><button class="btn btn-ghost btn-sm" data-pk="${x.id}">Remover</button></div>`).join('') : '<p class="sub">Nenhum aparelho ativado.</p>';
      box.querySelectorAll('[data-pk]').forEach(b=> b.onclick = async ()=>{ if(!confirm('Remover este aparelho?')) return; await api('/auth/passkeys/'+b.dataset.pk, { method:'DELETE' }); listarBio(); });
    }catch(e){ box.innerHTML = ''; }
  }
  if(!bioSuportada()){ document.getElementById('pfBioAtivar').style.display='none'; document.getElementById('pfBioTxt').textContent='Este aparelho ou navegador não aceita digital ou rosto.'; }
  else listarBio();
  document.getElementById('pfBioAtivar').onclick = async ()=>{
    try{ await cadastrarBiometria(nomeDoAparelho()); toast('Ativado. Na próxima entrada use a digital ou o rosto.'); listarBio(); }
    catch(e){ document.getElementById('pfErr').textContent = erroBio(e); }
  };
  document.getElementById('pfSalvar').onclick = async ()=>{
    const body = { nome: document.getElementById('pfNome').value.trim() };
    const nova = document.getElementById('pfNova').value;
    if(nova){ body.nova_senha = nova; body.senha_atual = document.getElementById('pfAtual').value; }
    try{
      const r = await api('/auth/eu', { method:'PATCH', body });
      usuarioAtual.nome = r.nome || body.nome;
      try{ localStorage.setItem('agend_usuario', JSON.stringify(usuarioAtual)); }catch(_){}
      document.getElementById('pfAtual').value=''; document.getElementById('pfNova').value='';
      document.getElementById('pfErr').textContent=''; toast('Perfil salvo.');
    }catch(e){ document.getElementById('pfErr').textContent = e.message; }
  };
}
/* cards recolhíveis: toque no título para abrir ou fechar. Poupa espaço na tela Master. */
function recolherCards(main, abertos){
  main.querySelectorAll('.card').forEach(card=>{
    const h = card.querySelector('h2'); if(!h || h.parentElement!==card) return;
    const corpo = document.createElement('div'); corpo.className='card-corpo';
    while(h.nextSibling) corpo.appendChild(h.nextSibling);
    card.appendChild(corpo);
    const aberto = abertos.includes(h.textContent.trim());
    corpo.style.display = aberto ? '' : 'none';
    h.style.cssText='cursor:pointer;display:flex;justify-content:space-between;align-items:center;margin:0;';
    const seta = document.createElement('span'); seta.style.cssText='font-size:14px;color:var(--ink-soft);'; seta.textContent = aberto ? '▾' : '▸';
    h.appendChild(seta);
    h.onclick = ()=>{ const fechado = corpo.style.display==='none'; corpo.style.display = fechado ? '' : 'none'; seta.textContent = fechado ? '▾' : '▸'; if(fechado) corpo.style.marginTop='12px'; };
  });
}
/* Master em abas: cada assunto numa aba, para achar tudo (backup, equipe, agenda) sem rolar a tela */
let abaMasterAtual = 'Clínica';
const ABAS_MASTER = {
  'Guardião': ['Guardião do sistema','Obrigações','Modo treino','Mapa de funções'],
  'Clínica': ['Sessão','Dados da clínica','Ficha do paciente','Tipos de atendimento','Cidades de exame de vista'],
  'Agenda': ['Agenda de exame de vista','Feriados da cidade'],
  'Equipe': ['Usuários da clínica'],
  'Segurança': ['Segurança e dados','Estado da segurança','Licença','Versões do sistema','Exportar dados'],
  'Integrações': ['Integração com assistente externo (ex: WhatsApp)','WhatsApp automático']
};
function abasMaster(main){
  const cards = [...main.querySelectorAll(':scope > .card')];
  const de = (c)=>{ const h = c.querySelector('h2'); const t = h ? h.firstChild.textContent.trim() : ''; for(const [aba, l] of Object.entries(ABAS_MASTER)) if(l.includes(t)) return aba; return 'Clínica'; };
  cards.forEach(c=> c.dataset.aba = de(c));
  const abas = Object.keys(ABAS_MASTER).filter(a=> cards.some(c=>c.dataset.aba===a));
  if(!abas.includes(abaMasterAtual)) abaMasterAtual = abas[0];
  const barra = document.createElement('div'); barra.className = 'abas-master';
  const mostrar = ()=>{ cards.forEach(c=> c.style.display = c.dataset.aba===abaMasterAtual ? '' : 'none'); barra.querySelectorAll('button').forEach(b=> b.classList.toggle('on', b.dataset.aba===abaMasterAtual)); };
  barra.innerHTML = abas.map(a=>`<button type="button" data-aba="${a}">${a}</button>`).join('');
  barra.querySelectorAll('button').forEach(b=> b.onclick = ()=>{ abaMasterAtual = b.dataset.aba; mostrar(); window.scrollTo({top:0}); });
  main.insertBefore(barra, main.firstChild);
  mostrar();
}
function fichaMasterCardHtml(){
  const grupos = [['Dados pessoais',['telefone','cpf','data_nascimento','email','sexo','profissao']],['Endereço',['cep','endereco','bairro']],['Saúde dos olhos',['usa_oculos','queixa','ultimo_exame','cirurgia_ocular']],['Saúde geral',['doencas','alergias','medicamentos','historico_familiar']],['Outros',['indicacao','observacoes']],['Fotos',['foto_receita','foto_armacao']]];
  const opt = (k,v,t)=>`<option value="${v}" ${fichaEstado(k)===v?'selected':''}>${t}</option>`;
  return `<div class="card"><h2>Ficha do paciente</h2>
    <p class="sub">Escolha o que pedir de cada paciente. Vale para o formulário que o paciente preenche e para a ficha interna. O nome é sempre obrigatório. Na ficha do paciente há o botão Imprimir ficha.</p>
    ${grupos.map(([g,ks])=>`<h3 style="margin:14px 0 4px;font-size:14px;color:var(--ink-soft);">${g}</h3>${ks.map(k=>{ const d = FICHA_DEF.find(x=>x[0]===k); return `<div style="display:flex;justify-content:space-between;align-items:center;gap:10px;margin:6px 0;"><span style="font-size:14px;">${d[1]}</span><select id="fc_${k}" style="width:auto;min-width:130px;">${opt(k,'oculto','Não pedir')}${opt(k,'opcional','Opcional')}${opt(k,'obrigatorio','Obrigatório')}</select></div>`; }).join('')}`).join('')}
    <button class="btn btn-ghost btn-block" id="mSalvarFicha" style="margin-top:14px;">Salvar ficha</button></div>`;
}
function ligarSegurancaMaster(){
  const box = document.getElementById('mSegStatus'); if(!box) return;
  (async ()=>{
    try{
      const s = await api('/clinica/seguranca-status');
      const linha = (ok, titulo, ajuda)=>`<div style="margin:8px 0;"><span style="color:${ok?'#2E7D4F':'#B26A00'};font-weight:700;">${ok?'✔':'○'}</span> <b>${titulo}</b>${ok?'':`<div class="sub" style="margin:2px 0 0 18px;">${ajuda}</div>`}</div>`;
      box.innerHTML =
        linha(s.criptografia,'Dados criptografados no banco','Falta a variável CHAVE_CRIPTOGRAFIA no servidor.') +
        linha(s.email,'Envio de e-mail (recuperar senha e avisos)','Falta ligar: SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS e EMAIL_DE na Render.') +
        linha(s.backup_automatico,'Backup semanal por e-mail','Precisa do e-mail ligado, mais BACKUP_EMAIL_PARA e BACKUP_SENHA (8+ caracteres).') +
        linha(s.whatsapp_meta,'WhatsApp automático (chave da Meta)','Faltam WA_TOKEN e WA_PHONE_ID.') +
        linha(s.com_biometria>0,'Digital ou rosto em uso', 'Ative em Meu perfil, de preferência depois de ter o domínio próprio.') +
        linha(s.com_codigo>0,'Código do celular em uso', 'Ative em Meu perfil. ' + s.com_codigo + ' de ' + s.usuarios + ' usuários usam.') +
        `<p class="sub" style="margin-top:10px;">Usuários com digital ou rosto: ${s.com_biometria} de ${s.usuarios}. Com código do celular: ${s.com_codigo} de ${s.usuarios}.</p>`;
    }catch(e){ box.innerHTML = `<p class="fieldmsg bad">${esc(e.message)}</p>`; }
  })();
  (async ()=>{
    try{
      const l = await api('/clinica/licenca');
      if(!l.controle) return; // servidor sem controle de licença: esconde o cartão
      document.getElementById('mLicencaCard').style.display = '';
      const t = document.getElementById('mLicencaInfo');
      t.textContent = l.valida ? (l.ate ? `Licença válida até ${fmtData(l.ate)} (${l.dias} dias).` : 'Licença válida.') : (l.motivo==='sem_chave' ? 'Esta clínica ainda não tem chave de licença.' : 'A licença venceu ou é inválida. Cole a chave nova.');
      t.style.color = l.valida ? '' : '#C1462F';
      document.getElementById('mLicencaSalvar').onclick = async ()=>{
        try{ const r = await api('/clinica/licenca', { method:'POST', body:{ chave: document.getElementById('mLicencaChave').value } }); toast('Licença salva. Vale até '+fmtData(r.ate)+'.'); ligarSegurancaMaster(); }
        catch(e){ erroApi(e); }
      };
    }catch(e){}
  })();
}
function renderMaster(main){
  main.innerHTML = `
    ${usuarioAtual?.papel==='admin' ? guardiaoCardsHtml() : ''}
    ${usuarioAtual?.unidadeId ? `<div class="card"><h2>Sessão</h2>
      <p class="sub">Você só vê pacientes e agendamentos de <strong>${esc(minhaUnidade()?.nome||'sua cidade')}</strong>.</p></div>` : ''}

    <div class="card">
      <h2>Dados da clínica</h2>
      <label>Nome exibido no topo do app</label>
      <input type="text" id="mNome" value="${clinicaAtual?.nome_fantasia||''}">
      <label>Endereço</label>
      <input type="text" id="mEndereco" value="${clinicaAtual?.endereco||''}">
      <label>Local padrão do exame</label>
      <input type="text" id="mLocal" value="${clinicaAtual?.local_exame_padrao||''}">
      <label>Telefone</label>
      <input type="text" id="mTelefone" value="${clinicaAtual?.telefone||''}">
      <label>Link público do site (onde o cadastro-paciente.html está hospedado)</label>
      <input type="text" id="mLinkSite" value="${clinicaAtual?.link_site||(SERVIDOR_PROPRIO?location.origin+'/':'')}" placeholder="https://clinica-visao.onrender.com/">
      <label>Logomarca <span style="font-weight:400;color:var(--ink-soft);">(aparece no topo da receita e do atestado impressos)</span></label>
      ${clinicaAtual?.logo_url ? `<img src="${clinicaAtual.logo_url}" alt="Logo atual" style="max-height:70px;display:block;margin:6px 0;">` : ''}
      <input type="file" id="mLogo" accept="image/*">
      <p class="fieldmsg" id="mLogo_msg"></p>
      <button class="btn btn-ghost btn-block" id="mSalvarDados" style="margin-top:12px;">Salvar dados</button>
    </div>

    <div class="card">
      <h2>Usuários da clínica</h2>
      <p class="sub">Cada atendente entra com seu próprio e-mail e senha.</p>
      <div id="listaUsuarios">Carregando...</div>
      <div class="row2" style="margin-top:12px;">
        <div><label>Nome</label><input type="text" id="uNome"></div>
        <div><label>E-mail</label><input type="text" id="uEmail"></div>
      </div>
      <div class="row2">
        <div><label>Senha</label><input type="password" id="uSenha"></div>
        <div><label>Papel</label><select id="uPapel"><option value="atendente">Agendador (marca os horários)</option><option value="profissional">Profissional (faz exame, acessa o prontuário)</option><option value="admin">Admin</option></select></div>
      </div>
      ${unidades.length ? `<label>Cidade responsável</label>
      <select id="uUnidade"><option value="">Todas as cidades</option>${unidades.map(u=>`<option value="${u.id}">${esc(u.nome)}</option>`).join('')}</select>` : ''}
      <div id="blocoProfissional" style="display:none;margin-top:10px;border-top:1px solid var(--line);padding-top:10px;">
        <p class="sub" style="margin-top:0;">Esses dados saem impressos na receita e no atestado.</p>
        <label>Registro no conselho <span style="font-weight:400;color:var(--ink-soft);">(ex: CRO 12345)</span></label>
        <input type="text" id="uRegistro" placeholder="CRO 12345">
        <label>Texto do carimbo</label>
        <input type="text" id="uCarimbo" placeholder="Dr(a) Fulano de Tal - CRO 12345">
        <label>Imagem da assinatura <span style="font-weight:400;color:var(--ink-soft);">(opcional, foto ou print da assinatura)</span></label>
        <input type="file" id="uAssinatura" accept="image/*">
        <p class="fieldmsg" id="uAssinatura_msg"></p>
      </div>
      <button class="btn btn-ghost btn-block" id="mAddUsuario" style="margin-top:10px;">+ Adicionar usuário</button>
    </div>

    ${usuarioAtual?.papel==='admin' ? `<div class="card">
      <h2>Integração com assistente externo (ex: WhatsApp)</h2>
      <p class="sub">Essa chave identifica sua clínica pra um assistente automático consultar horário livre e marcar sozinho, sem precisar de login de atendente. Guarde ela com cuidado, quem tiver essa chave consegue criar agendamentos na sua agenda.</p>
      <label>Identificador da clínica (slug)</label>
      <input type="text" id="mSlugIntegracao" value="${clinicaAtual?.slug||''}" readonly>
      <label>Chave de integração</label>
      <input type="text" id="mChaveIntegracao" value="Carregando..." readonly>
      <button class="btn btn-ghost btn-block" id="mCopiarChave" style="margin-top:10px;">Copiar chave</button>
    </div>` : ''}

    ${usuarioAtual?.papel==='admin' ? `<div class="card">
      <h2>WhatsApp automático</h2>
      <p class="sub">O sistema envia sozinho a confirmação, o lembrete de 24 horas, o de 2 horas e o pós atendimento, entre 8h e 20h. Se o paciente responde SIM, o exame fica confirmado. Se responde NÃO, fica cancelado.</p>
      <label>Número de WhatsApp da clínica (com DDD)</label>
      <input type="text" id="wNumero" inputmode="tel" value="${esc(clinicaAtual?.whatsapp_numero||'64992161203')}" placeholder="(64) 99216-1203">
      <label>Envio automático</label>
      <select id="wAuto"><option value="false" ${clinicaAtual?.whatsapp_auto?'':'selected'}>Desligado (a equipe toca em WhatsApp)</option><option value="true" ${clinicaAtual?.whatsapp_auto?'selected':''}>Ligado</option></select>
      <p class="sub" id="wStatus" style="margin-top:10px;">Conferindo o servidor...</p>
      <button class="btn btn-ghost btn-block" id="wSalvar" style="margin-top:10px;">Salvar WhatsApp</button>
      <label style="margin-top:14px;">Enviar uma mensagem de teste para</label>
      <input type="text" id="wTesteTel" inputmode="tel" placeholder="(64) 99999-9999">
      <button class="btn btn-outline btn-block" id="wTeste" style="margin-top:8px;">Enviar teste</button>
    </div>

    <div class="card">
      <h2>Segurança e dados</h2>
      <p class="sub">Backup: baixa uma cópia completa de todos os dados da clínica. Guarde o arquivo no seu computador e no Google Drive. Registro de acessos: mostra quem abriu ou alterou dados de pacientes, receitas e prontuários.</p>
      <p class="sub" id="mBackupInfo" style="font-weight:600;">Verificando o último backup...</p>
      <button class="btn btn-ghost btn-block" id="mBackup">Baixar backup dos dados</button>
      <button class="btn btn-outline btn-block" id="mAcessos" style="margin-top:8px;">Ver registro de acessos</button>
    </div>` : ''}


    ${usuarioAtual?.papel==='admin' ? `<div class="card">
      <h2>Estado da segurança</h2>
      <p class="sub">O que já está ligado no servidor. O que estiver pendente depende de uma chave que você coloca na Render, em Environment.</p>
      <div id="mSegStatus"><p class="sub">Verificando...</p></div>
    </div>
    <div class="card" id="mLicencaCard" style="display:none;">
      <h2>Licença</h2>
      <p class="sub" id="mLicencaInfo">Verificando...</p>
      <label>Chave de licença</label>
      <input type="text" id="mLicencaChave" placeholder="CV1...">
      <button class="btn btn-ghost btn-block" id="mLicencaSalvar" style="margin-top:10px;">Salvar chave</button>
    </div>` : ''}

    <div class="card">
      <h2>Versões do sistema</h2>
      <p class="sub">Versão em uso: <strong>${esc(versaoSistema?.versao||'?')}</strong>. Cada atualização nova tem um número maior.</p>
      ${(versaoSistema?.historico||[]).map(v=>`<div class="list-item"><div><div class="name">Versão ${esc(v.versao)} · ${esc(fmtData(v.data))}</div><div class="meta">${esc(v.notas)}</div></div></div>`).join('')}
    </div>

    ${fichaMasterCardHtml()}

    <div class="card">
      <h2>Tipos de atendimento</h2>
      <p class="sub">Cada tipo tem sua duração e o intervalo automático que fica livre depois.</p>
      ${renderTiposList()}
      <div class="row3" style="margin-top:14px;">
        <div><label>Nome</label><input type="text" id="tpNome" placeholder="Ex: Exame completo"></div>
        <div><label>Duração (min)</label><input type="text" id="tpDuracao" inputmode="numeric" placeholder="30"></div>
        <div><label>Intervalo (min)</label><input type="text" id="tpBuffer" inputmode="numeric" placeholder="10"></div>
      </div>
      <label>Preço padrão em R$ <span style="font-weight:400;color:var(--ink-soft);">(opcional, já vem preenchido na cobrança)</span></label>
      <input type="text" id="tpPreco" inputmode="decimal" placeholder="100,00" style="max-width:200px;">
      <button class="btn btn-ghost btn-block" id="mAddTipo" style="margin-top:10px;">+ Adicionar tipo de atendimento</button>
    </div>

    ${usuarioAtual?.unidadeId ? '' : `
    <div class="card">
      <h2>Cidades de exame de vista</h2>
      <p class="sub">Cada cidade tem seu próprio link de cadastro e sua própria agenda. Um atendente vinculado a uma cidade só vê o que é daquela cidade.</p>
      ${renderUnidadesList()}
      <div class="row2" style="margin-top:14px;">
        <div><label>Nome da cidade</label><input type="text" id="unNome" placeholder="Ex: São Paulo - Nov 2026"></div>
        <div><label>Identificador do link</label><input type="text" id="unSlug" placeholder="sao-paulo"></div>
      </div>
      <div class="row2">
        <div><label>Cidade</label><input type="text" id="unCidade" placeholder="São Paulo"></div>
        <div><label>Local do exame</label><input type="text" id="unLocal" placeholder="Endereço do exame"></div>
      </div>
      <button class="btn btn-ghost btn-block" id="mAddUnidade" style="margin-top:10px;">+ Adicionar cidade</button>
    </div>`}

    ${(usuarioAtual?.papel==='admin' && !usuarioAtual?.unidadeId) ? agendaMasterCardHtml() + feriadosLocaisCardHtml() : ''}
    ${usuarioAtual?.papel==='admin' ? cadastrosMasterCardHtml() + impressaoMasterCardHtml() : ''}

    <div class="card">
      <h2>Exportar dados</h2>
      <p class="sub">Backup em CSV de pacientes e agendamentos carregados nesta sessão.</p>
      <button class="btn btn-ghost btn-block" id="mExportCsv">Exportar CSV</button>
    </div>
  `;


  if(document.getElementById('wSalvar')){
    api('/clinica/whatsapp-status').then(st=>{
      const partes = [];
      partes.push(st.servidor_configurado ? 'Chaves da Meta: ligadas no servidor.' : 'Chaves da Meta: ainda não colocadas no servidor (veja o passo a passo).');
      if(st.servidor_configurado){ partes.push(st.modelo_configurado ? 'Modelo de mensagem: configurado.' : 'Modelo de mensagem: falta (a Meta só deixa a clínica começar conversa com modelo aprovado).'); partes.push(st.webhook_configurado ? 'Respostas SIM/NÃO: ligadas.' : 'Respostas SIM/NÃO: faltam WA_VERIFY_TOKEN e WA_APP_SECRET.'); }
      partes.push('Endereço do webhook: '+st.endereco_webhook);
      document.getElementById('wStatus').textContent = partes.join(' ');
    }).catch(()=>{ document.getElementById('wStatus').textContent = ''; });
    document.getElementById('wSalvar').onclick = async ()=>{
      try{
        clinicaAtual = await api('/clinica', { method:'PUT', body:{ nome_fantasia: clinicaAtual.nome_fantasia, endereco: clinicaAtual.endereco, local_exame_padrao: clinicaAtual.local_exame_padrao,
          telefone: clinicaAtual.telefone, link_site: clinicaAtual.link_site, logo_url: clinicaAtual.logo_url || null, campos_obrigatorios: clinicaAtual.campos_obrigatorios,
          whatsapp_numero: document.getElementById('wNumero').value, whatsapp_auto: document.getElementById('wAuto').value==='true' }});
        toast('WhatsApp salvo.');
      }catch(e){ erroApi(e); }
    };
    document.getElementById('wTeste').onclick = async ()=>{
      try{ await api('/clinica/whatsapp-teste', { method:'POST', body:{ telefone: document.getElementById('wTesteTel').value }}); toast('Teste enviado.'); }
      catch(e){ erroApi(e); }
    };
    async function mostrarStatusBackup(){
      const el = document.getElementById('mBackupInfo'); if(!el) return;
      try{
        const st = await api('/clinica/backup-status');
        if(st.dias===null){ el.textContent = 'Nenhum backup feito ainda. Baixe um agora.'; el.style.color = 'var(--danger,#c0392b)'; }
        else if(st.dias>=7){ el.textContent = 'Último backup há '+st.dias+' dias. Baixe um novo.'; el.style.color = 'var(--danger,#c0392b)'; }
        else { el.textContent = st.dias===0 ? 'Último backup: hoje.' : 'Último backup há '+st.dias+(st.dias===1?' dia.':' dias.'); el.style.color = ''; }
      }catch(e){ el.textContent = ''; }
    }
    mostrarStatusBackup();
    document.getElementById('mBackup').onclick = ()=>{
      openModal(`<h2>Backup protegido</h2>
        <p class="sub">Escolha uma senha para trancar o arquivo. Sem ela ninguém abre o backup, nem você. Anote em lugar seguro.</p>
        <label>Senha do backup (mínimo 8 caracteres)</label><input type="password" id="bkSenha" autocomplete="new-password">
        <label>Repita a senha</label><input type="password" id="bkSenha2" autocomplete="new-password">
        <p id="bkErr" style="color:#C1462F;font-size:13px;"></p>
        <div class="btn-row"><button class="btn btn-primary" id="bkGerar">Baixar backup</button><button class="btn btn-outline" onclick="closeModal()">Cancelar</button></div>`);
      document.getElementById('bkGerar').onclick = async ()=>{
        const a = document.getElementById('bkSenha').value, b = document.getElementById('bkSenha2').value, err = document.getElementById('bkErr');
        if(a.length<8){ err.textContent = 'A senha precisa ter pelo menos 8 caracteres.'; return; }
        if(a!==b){ err.textContent = 'As duas senhas não são iguais.'; return; }
        try{
          err.textContent = 'Gerando o backup...';
          const dados = await api('/clinica/backup', { method:'POST', body:{ senha:a } });
          const blob = new Blob([JSON.stringify(dados)], {type:'application/json'});
          const l = document.createElement('a'); l.href = URL.createObjectURL(blob); l.download = 'backup-clinica-'+new Date().toISOString().slice(0,10)+'.json'; l.click();
          setTimeout(()=>URL.revokeObjectURL(l.href), 5000);
          closeModal(); toast('Backup baixado. Guarde a senha.'); mostrarStatusBackup();
        }catch(e){ err.textContent = ''; erroApi(e); }
      };
    };
    document.getElementById('mAcessos').onclick = async ()=>{
      try{
        const lista = await api('/clinica/acessos');
        const linhas = lista.map(l=>`<tr><td>${esc(new Date(String(l.criado_em).slice(0,19)+'Z').toLocaleString('pt-BR',{dateStyle:'short',timeStyle:'short'}))}</td><td>${esc(l.usuario_nome||'')}</td><td>${esc(l.acao)} ${esc(l.area)}</td></tr>`).join('');
        openModal(`<h2>Registro de acessos</h2><p class="sub">Últimos 300 acessos a dados de saúde.</p><div style="max-height:55vh;overflow:auto;"><table style="width:100%;font-size:13px;border-collapse:collapse;"><tr><th align="left">Quando</th><th align="left">Quem</th><th align="left">O quê</th></tr>${linhas||'<tr><td colspan="3">Nenhum acesso ainda.</td></tr>'}</table></div><div class="btn-row" style="margin-top:12px;"><button class="btn btn-outline" onclick="closeModal()">Fechar</button></div>`);
      }catch(e){ erroApi(e); }
    };
  }
  ligarFeriadosLocais();
  ligarSegurancaMaster();
  ligarGuardiao();
  recolherCards(main, ['Guardião do sistema','Obrigações','Mapa de funções','Cidades de exame de vista','Agenda de exame de vista','Usuários da clínica','Segurança e dados','Estado da segurança']);
  abasMaster(main);
  const btnCopiarChave = document.getElementById('mCopiarChave');
  if(btnCopiarChave){
    (async ()=>{
      try{
        const r = await api('/clinica/chave-integracao');
        document.getElementById('mChaveIntegracao').value = r.chave_integracao || '';
      }catch(e){ document.getElementById('mChaveIntegracao').value = 'Não foi possível carregar.'; }
    })();
    btnCopiarChave.onclick = async ()=>{
      try{
        await navigator.clipboard.writeText(document.getElementById('mChaveIntegracao').value);
        toast('Chave copiada.');
      }catch(e){ toast('Não consegui copiar. Copie manualmente o texto do campo.'); }
    };
  }

  let novaLogoBase64 = null;
  const mLogoEl = document.getElementById('mLogo');
  if(mLogoEl) mLogoEl.addEventListener('change', e=>{
    const arq = e.target.files[0];
    const msg = document.getElementById('mLogo_msg');
    if(!arq){ novaLogoBase64=null; msg.textContent=''; return; }
    if(arq.size > 1.5*1024*1024){ msg.textContent='Imagem muito grande, escolha uma menor que 1,5 MB.'; msg.className='fieldmsg bad'; e.target.value=''; novaLogoBase64=null; return; }
    const leitor = new FileReader();
    leitor.onload = ()=>{ novaLogoBase64 = leitor.result; msg.textContent='Nova logo carregada, clique em Salvar dados pra confirmar.'; msg.className='fieldmsg ok'; };
    leitor.readAsDataURL(arq);
  });

  document.getElementById('mSalvarDados').onclick = async ()=>{
    try{
      clinicaAtual = await api('/clinica', { method:'PUT', body:{
        nome_fantasia: document.getElementById('mNome').value,
        endereco: document.getElementById('mEndereco').value,
        local_exame_padrao: document.getElementById('mLocal').value,
        telefone: document.getElementById('mTelefone').value,
        link_site: document.getElementById('mLinkSite').value.trim().replace(/\/$/,''),
        campos_obrigatorios: camposObrig(),
        logo_url: novaLogoBase64 || clinicaAtual.logo_url || null,
      }});
      document.getElementById('hdrNome').textContent = clinicaAtual.nome_fantasia || 'Agenda de Exame de Vista';
      document.getElementById('hdrLocal').textContent = clinicaAtual.local_exame_padrao || 'Agendando exame de vista';
      toast('Dados salvos.');
      novaLogoBase64 = null;
    }catch(e){ erroApi(e); }
  };

  document.getElementById('mSalvarFicha').onclick = async ()=>{
    try{
      const cfg = {}; FICHA_DEF.forEach(d=>{ cfg[d[0]] = document.getElementById('fc_'+d[0]).value; });
      clinicaAtual = await api('/clinica', { method:'PUT', body:{
        nome_fantasia: clinicaAtual.nome_fantasia, endereco: clinicaAtual.endereco,
        local_exame_padrao: clinicaAtual.local_exame_padrao, telefone: clinicaAtual.telefone, link_site: clinicaAtual.link_site,
        logo_url: clinicaAtual.logo_url || null, campos_obrigatorios: cfg }});
      toast('Ficha do paciente salva.');
    }catch(e){ erroApi(e); }
  };

  document.getElementById('mAddTipo').onclick = async ()=>{
    const nome = document.getElementById('tpNome').value.trim();
    const duracao_min = parseInt(document.getElementById('tpDuracao').value, 10);
    const buffer_min = parseInt(document.getElementById('tpBuffer').value, 10) || 0;
    if(!nome || !duracao_min || duracao_min<=0){ toast('Informe nome e duração válidos.'); return; }
    try{
      const cores = ['#1B5C5A','#2D8C84','#E3A23D','#8E6FB0','#C1462F'];
      const novo = await api('/tipos-atendimento', { method:'POST', body:{ nome, duracao_min, buffer_min, preco_padrao: document.getElementById('tpPreco').value.trim()||null, cor: cores[tiposAtendimento.length % cores.length] } });
      tiposAtendimento.push(novo);
      toast('Tipo de atendimento adicionado.'); renderMaster(main);
    }catch(e){ erroApi(e); }
  };

  carregarUsuarios();

  let assinaturaBase64 = '';
  const uPapelEl = document.getElementById('uPapel');
  const blocoProf = document.getElementById('blocoProfissional');
  uPapelEl.onchange = ()=>{ blocoProf.style.display = uPapelEl.value==='profissional' ? 'block' : 'none'; };

  document.getElementById('uAssinatura').addEventListener('change', e=>{
    const arq = e.target.files[0];
    const msg = document.getElementById('uAssinatura_msg');
    if(!arq){ assinaturaBase64=''; msg.textContent=''; return; }
    if(arq.size > 1.5*1024*1024){ msg.textContent='Imagem muito grande, escolha uma menor que 1,5 MB.'; msg.className='fieldmsg bad'; e.target.value=''; assinaturaBase64=''; return; }
    const leitor = new FileReader();
    leitor.onload = ()=>{ assinaturaBase64 = leitor.result; msg.textContent='Assinatura carregada.'; msg.className='fieldmsg ok'; };
    leitor.readAsDataURL(arq);
  });

  document.getElementById('mAddUsuario').onclick = async ()=>{
    const nome = document.getElementById('uNome').value.trim();
    const email = document.getElementById('uEmail').value.trim();
    const senha = document.getElementById('uSenha').value;
    const papel = document.getElementById('uPapel').value;
    const unidadeSel = document.getElementById('uUnidade');
    const unidade_id = unidadeSel ? (unidadeSel.value || null) : null;
    if(!nome || !email || !senha){ toast('Preencha nome, e-mail e senha.'); return; }
    const registro_conselho = papel==='profissional' ? document.getElementById('uRegistro').value.trim() : null;
    const carimbo_texto = papel==='profissional' ? document.getElementById('uCarimbo').value.trim() : null;
    try{
      await api('/clinica/usuarios', { method:'POST', body:{ nome, email, senha, papel, unidade_id, registro_conselho, carimbo_texto, assinatura_url: papel==='profissional'? (assinaturaBase64||null) : null } });
      toast('Usuário criado.'); carregarUsuarios();
      mostrarAcessoNovo({ nome, email, senha, papel, cidade: unidadeSel && unidade_id ? unidadeSel.options[unidadeSel.selectedIndex].text : '' });
      try{ profissionais = await api('/clinica/profissionais'); }catch(e){} // atualiza a lista pra já aparecer na receita
      document.getElementById('uNome').value=''; document.getElementById('uEmail').value=''; document.getElementById('uSenha').value='';
      document.getElementById('uRegistro').value=''; document.getElementById('uCarimbo').value=''; document.getElementById('uAssinatura').value='';
      document.getElementById('uAssinatura_msg').textContent=''; assinaturaBase64='';
    }catch(e){ erroApi(e); }
  };

  const btnAddUnidade = document.getElementById('mAddUnidade');
  if(btnAddUnidade) btnAddUnidade.onclick = async ()=>{
    const nome = document.getElementById('unNome').value.trim();
    const slug = document.getElementById('unSlug').value.trim();
    const cidade = document.getElementById('unCidade').value.trim();
    const local = document.getElementById('unLocal').value.trim();
    if(!nome || !slug){ toast('Preencha nome e identificador do link.'); return; }
    try{
      const nova = await api('/unidades', { method:'POST', body:{ nome, slug, cidade, local } });
      unidades.push(nova);
      toast('Cidade adicionada.'); renderMaster(main);
    }catch(e){ erroApi(e); }
  };

  ligarAgendaMaster(main);
  ligarCadastrosMaster(main);
  ligarImpressaoMaster();
  document.getElementById('mExportCsv').onclick = exportarCsv;
}

function renderTiposList(){
  return tiposAtendimento.map(t=>`
    <div class="list-item">
      <div>
        <div class="name"><span style="display:inline-block;width:9px;height:9px;border-radius:50%;background:${t.cor};margin-right:6px;"></span>${esc(t.nome)}</div>
        <div class="meta">${t.duracao_min} min de atendimento + ${t.buffer_min} min de intervalo · ${t.preco_padrao!=null ? 'preço padrão '+fmtMoeda(t.preco_padrao) : 'sem preço padrão'}</div>
      </div>
      <div style="display:flex;gap:6px;"><button class="btn btn-ghost btn-sm" onclick="editarPrecoTipo('${t.id}')">Preço</button>
      ${tiposAtendimento.length>1 ? `<button class="btn btn-danger btn-sm" onclick="removerTipo('${t.id}')">Remover</button>` : ''}</div>
    </div>`).join('');
}

function renderUnidadesList(){
  if(!unidades.length) return `<p class="sub">Nenhuma cidade cadastrada ainda. Enquanto isso, tudo cai no cadastro geral da clínica.</p>`;
  return unidades.map(u=>`
    <div class="list-item">
      <div>
        <div class="name">${esc(u.nome)}</div>
        <div class="meta">${u.cidade||''}${u.local? ' · '+u.local : ''}</div>
      </div>
      <div style="display:flex;gap:6px;">
        <button class="btn btn-ghost btn-sm" onclick="copiarLinkUnidade('${u.slug}')">Copiar link</button>
      </div>
    </div>`).join('');
}
function copiarLinkUnidade(slug){
  const base = clinicaAtual?.link_site || location.href.replace(/modulo-agendamento\.html.*$/, '');
  const url = `${base}cadastro-paciente.html?api=${encodeURIComponent(API_BASE)}&c=${encodeURIComponent(clinicaAtual.slug)}&u=${encodeURIComponent(slug)}`;
  navigator.clipboard && navigator.clipboard.writeText(url).catch(()=>{});
  toast('Link copiado.');
}

function editarPrecoTipo(id){
  const t = tiposAtendimento.find(x=>x.id===id); if(!t) return;
  openModal(`<h2>Preço de ${esc(t.nome)}</h2><p class="sub">Esse valor já aparece preenchido quando você registra a cobrança. Deixe vazio para tirar o preço.</p>
    <label>Preço padrão (R$)</label><input type="text" inputmode="decimal" id="tpNovoPreco" value="${t.preco_padrao!=null?String(t.preco_padrao).replace('.',','):''}" placeholder="100,00">
    <div class="btn-row"><button class="btn btn-primary" id="tpSalvarPreco">Salvar</button><button class="btn btn-outline" onclick="closeModal()">Cancelar</button></div>
    <p id="tpPrecoErr" style="color:#C1462F;font-size:12.5px;margin-top:8px;"></p>`);
  document.getElementById('tpSalvarPreco').onclick = async ()=>{
    try{
      const novo = await api(`/tipos-atendimento/${id}`, { method:'PATCH', body:{ preco_padrao: document.getElementById('tpNovoPreco').value.trim()||null } });
      Object.assign(t, novo); closeModal(); toast('Preço salvo.'); switchView('master');
    }catch(e){ document.getElementById('tpPrecoErr').textContent = e.message; }
  };
}
async function removerTipo(id){
  if(!confirm('Remover este tipo de atendimento?')) return;
  try{
    await api(`/tipos-atendimento/${id}`, { method:'DELETE' });
    tiposAtendimento = tiposAtendimento.filter(t=>t.id!==id);
    toast('Tipo removido.'); switchView('master');
  }catch(e){ erroApi(e); }
}

function abrirAcessos(u){
  const perm = u.permissoes || [];
  openModal(`<h2>Acessos de ${esc(u.nome)}</h2>
    <p class="sub">O agendador sempre vê Agenda, Confirmação, Envios e Dia. Marque o que mais ele pode abrir. A mudança vale no próximo login dele.</p>
    ${ACESSOS_EXTRAS.map(a=>`<label style="display:flex;gap:10px;align-items:center;margin:10px 0;font-weight:500;"><input type="checkbox" style="width:auto;" data-ch="${a.chave}" ${perm.includes(a.chave)?'checked':''}> ${a.nome}</label>`).join('')}
    <div class="btn-row"><button class="btn btn-primary" id="acSalvar">Salvar acessos</button><button class="btn btn-outline" onclick="closeModal()">Cancelar</button></div>`);
  document.getElementById('acSalvar').onclick = async ()=>{
    const lista = [...document.querySelectorAll('#modalBody input[data-ch]')].filter(i=>i.checked).map(i=>i.dataset.ch);
    try{ await api(`/clinica/usuarios/${u.id}/permissoes`, { method:'PUT', body:{ permissoes: lista } }); closeModal(); toast('Acessos salvos.'); carregarUsuarios(); }
    catch(e){ erroApi(e); }
  };
}

async function carregarUsuarios(){
  const el = document.getElementById('listaUsuarios');
  if(!el) return;
  try{
    const usuarios = await api('/clinica/usuarios');
    const eu = (usuarioAtual?.email||'').toLowerCase();
    el.innerHTML = usuarios.map(u=>{
      const ehEu = eu && String(u.email).toLowerCase()===eu;
      return `
      <div class="list-item" style="flex-wrap:wrap;gap:8px;${u.ativo===false?'opacity:.6;':''}">
        <div style="flex:1 1 220px;"><div class="name">${esc(u.nome)}${u.ativo===false?' (desativado)':''}${ehEu?' (você)':''}</div><div class="meta">${esc(u.email)} · ${esc(u.papel)}${u.unidade_nome? ' · '+esc(u.unidade_nome) : ' · todas as cidades'}${u.papel==='profissional' ? (u.tem_assinatura ? ' · carimbo e assinatura cadastrados' : ' · sem assinatura cadastrada ainda') : ''}${u.papel==='atendente' ? ' · acessos extras: '+((u.permissoes||[]).length||'nenhum') : ''}</div></div>
        <div style="display:flex;gap:6px;flex-wrap:wrap;">
          ${u.papel==='atendente' ? `<button class="btn btn-ghost btn-sm" data-acessos="${u.id}">Acessos</button>` : ''}
          ${u.totp_ativo ? `<button class="btn btn-ghost btn-sm" data-totpoff="${u.id}">Desligar código do celular</button>` : ''}
          <button class="btn btn-ghost btn-sm" data-senha="${u.id}">Trocar senha</button>
          ${ehEu ? '' : `<button class="btn btn-outline btn-sm" data-ativo="${u.id}">${u.ativo===false?'Reativar':'Desativar'}</button><button class="btn btn-danger btn-sm" data-excluir="${u.id}">Excluir</button>`}
        </div>
      </div>`; }).join('') || '<p class="sub">Nenhum usuário além de você.</p>';
    el.querySelectorAll('button[data-totpoff]').forEach(b=> b.onclick = async ()=>{
      if(!confirm('Desligar o código do celular desta pessoa? Ela volta a entrar só com a senha.')) return;
      try{ await api('/auth/totp/usuario/'+b.dataset.totpoff, { method:'DELETE' }); toast('Código desligado.'); const u = usuarios.find(x=>x.id===b.dataset.totpoff); if(u) u.totp_ativo = false; b.remove(); }catch(e){ erroApi(e); }
    });
    el.querySelectorAll('button[data-acessos]').forEach(b=> b.onclick = ()=> abrirAcessos(usuarios.find(u=>u.id===b.dataset.acessos)));
    el.querySelectorAll('button[data-senha]').forEach(b=> b.onclick = ()=> abrirTrocaSenhaUsuario(usuarios.find(u=>u.id===b.dataset.senha)));
    el.querySelectorAll('button[data-ativo]').forEach(b=> b.onclick = async ()=>{
      const u = usuarios.find(x=>x.id===b.dataset.ativo); const desativar = u.ativo!==false;
      if(!confirm(desativar ? `Desativar ${u.nome}? Ele perde o acesso em até 30 segundos e o histórico fica guardado.` : `Reativar ${u.nome}?`)) return;
      try{ await api(`/clinica/usuarios/${u.id}`, { method:'PUT', body:{ ativo: !desativar, unidade_id: u.unidade_id||null, registro_conselho: u.registro_conselho||null, carimbo_texto: u.carimbo_texto||null } }); toast(desativar?'Usuário desativado.':'Usuário reativado.'); carregarUsuarios(); }
      catch(e){ erroApi(e); }
    });
    el.querySelectorAll('button[data-excluir]').forEach(b=> b.onclick = async ()=>{
      const u = usuarios.find(x=>x.id===b.dataset.excluir);
      if(!confirm(`Excluir ${u.nome}? Isso não pode ser desfeito. Se ele já tem agendamentos ou receitas, o acesso é só desativado para guardar o histórico.`)) return;
      try{ const r = await api(`/clinica/usuarios/${u.id}`, { method:'DELETE' }); toast(r.excluido ? 'Usuário excluído.' : 'Usuário tem histórico: o acesso foi desativado.'); carregarUsuarios(); }
      catch(e){ erroApi(e); }
    });
  }catch(e){
    el.innerHTML = '<p class="sub">Só o admin pode ver os usuários.</p>';
  }
}
function abrirTrocaSenhaUsuario(u){
  openModal(`<h2>Trocar senha de ${esc(u.nome)}</h2>
    <p class="sub">Mínimo de 10 caracteres, com letras e números. Passe a nova senha para a pessoa.</p>
    <label>Nova senha</label><input type="text" id="nsSenha" autocomplete="off">
    <p class="err" id="nsErr" style="color:#C1462F;font-size:12.5px;"></p>
    <div class="btn-row"><button class="btn btn-primary" id="nsSalvar">Salvar senha</button><button class="btn btn-outline" onclick="closeModal()">Cancelar</button></div>`);
  document.getElementById('nsSalvar').onclick = async ()=>{
    try{ await api(`/clinica/usuarios/${u.id}/senha`, { method:'PUT', body:{ senha: document.getElementById('nsSenha').value } }); closeModal(); toast('Senha trocada.'); }
    catch(e){ document.getElementById('nsErr').textContent = e.message; }
  };
}

function montarCsv(){
  let csv = 'tipo;id;nome;cpf;telefone;cidade;data;hora;status;local\n';
  const csvSeguro = v=>{ v = String(v==null?'':v).replace(/[;\r\n]+/g,' '); return /^[=+\-@\t]/.test(v) ? "'"+v : v; };
  pacientes.forEach(p=>{ csv += `paciente;${p.id};${csvSeguro(p.nome_completo)};${csvSeguro(p.cpf)};${csvSeguro(p.telefone)};${csvSeguro(p.cidade)};;;;\n`; });
  agendamentos.forEach(a=>{ csv += `agendamento;${a.id};${csvSeguro(pacienteNome(a.paciente_id))};;;;${soData(a.data_hora)};${soHora(a.data_hora)};${csvSeguro(a.status)};${csvSeguro(a.local)}\n`; });
  return csv;
}
function exportarCsv(){
  const csv = montarCsv();
  const blob = new Blob([csv], {type:'text/csv;charset=utf-8;'});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = 'backup-agenda-' + new Date().toISOString().slice(0,10) + '.csv';
  a.click(); URL.revokeObjectURL(url);
  toast('CSV exportado.');
}

/* ====== Guardião do sistema (só o Master) ====== */
const FUNCOES = [
  {n:'Início',p:['admin','atendente','profissional'],v:'inicio',d:'Roteiro de 5 passos do seu perfil e lista do que falta configurar.',t:'comecar guia roteiro checklist'},
  {n:'Painel',p:['admin','profissional'],v:'painel',d:'Números do dia e da semana: marcados, atendidos e faltas.',t:'numeros resumo dashboard'},
  {n:'Agenda',p:['admin','atendente'],v:'agenda',d:'Escolha a cidade e o dia, veja os horários livres e marque o paciente. Horário ocupado não deixa marcar duas vezes.',t:'marcar agendar horario exame cancelar remarcar'},
  {n:'Calendário',p:['admin','atendente','profissional'],v:'calendario',d:'Visão do mês com os dias abertos e os feriados da cidade.',t:'mes feriado dias'},
  {n:'Pacientes',p:['admin','atendente','profissional'],v:'pacientes',d:'Cadastro, busca, ficha completa, fotos da receita e da armação e impressão da ficha. O CPF fica criptografado no banco.',t:'cadastro cpf telefone ficha foto imprimir buscar paciente'},
  {n:'Cadastro pelo paciente (link e QR)',p:['admin','atendente'],v:'pacientes',d:'O paciente preenche a própria ficha pelo celular, lendo o QR code ou abrindo o link. Aceita o aviso de privacidade.',t:'link qr autocadastro lgpd formulario'},
  {n:'Assistente de agendamento',p:['admin','atendente'],v:'assistente',d:'Marque horário conversando: escreva o que o paciente pediu e o assistente propõe os horários.',t:'chat conversa marcar'},
  {n:'Receita e atestado',p:['admin','profissional'],v:'receita',d:'Receita de óculos, atestado e declaração com carimbo, assinatura, cidade no cabeçalho e diagnóstico (CID). Tudo criptografado.',t:'receita atestado declaracao cid imprimir pdf oculos'},
  {n:'Atendimento (prontuário)',p:['admin','profissional'],v:'prontuario',d:'Prontuário do exame: queixa, acuidade, refração, exame externo e conduta. Ditado por voz, histórico de correções e fechamento.',t:'prontuario exame acuidade refracao voz ditar historico'},
  {n:'Fila do dia',p:['admin','atendente','profissional'],v:'fila',d:'Quem chegou, quem espera e quem está em atendimento, com o tempo de espera de cada um.',t:'chegou espera atendimento fila'},
  {n:'Lista de espera',p:['admin','atendente'],v:'espera',d:'Quem quer um horário mais cedo. Quando alguém cancela, o sistema avisa e o botão Oferecer abre o WhatsApp com a mensagem pronta.',t:'espera cancelou vaga oferecer whatsapp'},
  {n:'Confirmar presença',p:['admin','atendente'],v:'confirmacao',d:'Lista de quem precisa confirmar o comparecimento, com botão para chamar pelo WhatsApp.',t:'confirmar presenca lembrete'},
  {n:'Mensagens',p:['admin','atendente'],v:'envios',d:'Mensagens prontas de lembrete, confirmação e pós-exame, para enviar pelo WhatsApp.',t:'whatsapp mensagem lembrete envio'},
  {n:'Resumo do dia',p:['admin','atendente','profissional'],v:'relatorio',d:'Marcados, atendidos, faltas e cancelados do dia, com o resumo por cidade e valores.',t:'relatorio cidade faltas valores dia'},
  {n:'Teste na tela',p:['admin','atendente','profissional'],v:'teste',d:'Teste de acuidade na tela do computador ou do celular, com tamanho calibrado.',t:'optotipo visao acuidade teste tela snellen'},
  {n:'Retornos',p:['admin','atendente'],v:'retornos',d:'Pacientes que fizeram exame há um ano ou mais e já podem voltar. Aniversariantes também.',t:'retorno recall aniversario voltar'},
  {n:'Financeiro',p:['admin'],v:'financeiro',d:'Pagamentos recebidos, contas a pagar e totais por período.',t:'dinheiro pagamento conta receber pagar valores'},
  {n:'Meu perfil',p:['admin','atendente','profissional'],v:'perfil',d:'Troca de senha, digital ou rosto, código do celular, letra grande, alto contraste, tema escuro e Sair de todos os aparelhos.',t:'senha biometria digital codigo totp aparencia letra escuro sair aparelhos'},
  {n:'Dados da clínica e cidades',p:['admin'],v:'master',aba:'Clínica',d:'Nome, endereço, logomarca, tipos de atendimento com duração e as cidades de exame.',t:'clinica cidade unidade tipo atendimento logo'},
  {n:'Ficha do paciente (campos)',p:['admin'],v:'master',aba:'Clínica',d:'Escolha o que pedir de cada paciente: obrigatório, opcional ou oculto.',t:'campos obrigatorios ficha'},
  {n:'Agenda de exame e feriados',p:['admin'],v:'master',aba:'Agenda',d:'Abra dias e horários por cidade, com almoço e intervalo. Cadastre os feriados locais.',t:'abrir horarios agenda feriado almoco'},
  {n:'Equipe e permissões',p:['admin'],v:'master',aba:'Equipe',d:'Crie agendadores e profissionais, escolha a cidade de cada um, o que podem abrir, e desative quem saiu. Desligue o código do celular de quem perdeu o aparelho.',t:'usuarios equipe permissao desativar totp'},
  {n:'Backup protegido',p:['admin'],v:'master',aba:'Segurança',clicar:'mBackup',d:'Baixa uma cópia completa dos dados, trancada com a senha que você escolhe. Também sai sozinho toda semana por e-mail, quando o e-mail está ligado.',t:'backup copia seguranca restaurar'},
  {n:'Estado da segurança',p:['admin'],v:'master',aba:'Segurança',d:'O que está ligado no servidor: criptografia, e-mail, backup semanal, WhatsApp, digital e código.',t:'seguranca criptografia estado'},
  {n:'Licença da clínica',p:['admin'],v:'master',aba:'Segurança',d:'Chave de licença por clínica, para quando o sistema for usado por outras clínicas.',t:'licenca chave vender'},
  {n:'Versões do sistema',p:['admin'],v:'master',aba:'Segurança',d:'Histórico do que mudou em cada versão.',t:'versao novidades historico'},
  {n:'Exportar dados',p:['admin'],v:'master',aba:'Segurança',d:'Planilha CSV dos agendamentos.',t:'csv planilha exportar'},
  {n:'Integrações e WhatsApp automático',p:['admin'],v:'master',aba:'Integrações',d:'Chave de integração com assistente externo e lembretes automáticos pelo WhatsApp (precisa da chave da Meta).',t:'whatsapp meta integracao chave automatico'},
  {n:'Guardião do sistema',p:['admin'],v:'master',aba:'Guardião',d:'Vigia saúde do sistema, backup e obrigações, avisa por e-mail e corrige com um clique o que dá.',t:'saude guardiao assistente obrigacoes falhas'},
  {n:'Modo treino',p:['admin'],v:'master',aba:'Guardião',d:'Cria 5 pacientes de mentira para a equipe aprender sem medo e remove tudo depois.',t:'treino praticar aprender equipe'},
  {n:'Instalar no celular',p:['admin','atendente','profissional'],v:'inicio',d:'No celular, abra o menu do navegador e escolha Adicionar à tela inicial. O sistema vira um app com ícone.',t:'instalar app pwa celular tela inicial'},
  {n:'Recuperar senha',p:['admin','atendente','profissional'],v:'inicio',d:'Na tela de entrada, toque em Esqueci a senha. O link chega por e-mail e vale por 30 minutos (precisa do e-mail ligado).',t:'esqueci senha recuperar email'},
];
const NOME_PAPEL = {admin:'Master',atendente:'Agendador',profissional:'Profissional'};
function guardiaoIr(a){
  if(!a) return;
  const view = a.view || a.v;
  if(view==='master'){ if(a.aba) abaMasterAtual = a.aba; switchView('master'); if(a.clicar) setTimeout(()=>{ const b = document.getElementById(a.clicar); if(b) b.click(); }, 900); }
  else switchView(view);
}
function guardiaoCardsHtml(){
  return `<div class="card"><h2>Guardião do sistema</h2>
      <p class="sub">Seu assistente de saúde do programa. Confere o sistema, os backups e as suas obrigações, avisa o que está errado e corrige com um clique o que for possível.</p>
      <div id="gdResumo"><p class="sub">Conferindo...</p></div>
      <button class="btn btn-ghost btn-block" id="gdAtualizar" style="margin:6px 0 10px;">Conferir agora</button>
      <div id="gdLista"></div>
    </div>
    <div class="card"><h2>Obrigações</h2>
      <p class="sub">Tudo o que você precisa lembrar. O Guardião manda um e-mail por dia quando algo vence em até 3 dias, se o e-mail estiver ligado.</p>
      <div id="gdObrigacoes"><p class="sub">Carregando...</p></div>
      <h3 style="margin:16px 0 4px;font-size:14px;">Nova obrigação</h3>
      <label>O que precisa lembrar</label><input type="text" id="gdObrTitulo" maxlength="150" placeholder="Ex.: Pagar o domínio">
      <div class="row2"><div><label>Data</label><input type="date" id="gdObrData"></div><div><label>Repetir a cada (dias, opcional)</label><input type="number" id="gdObrRep" min="1" placeholder="365"></div></div>
      <button class="btn btn-ghost btn-block" id="gdObrAdd" style="margin-top:10px;">Adicionar</button>
    </div>
    <div class="card"><h2>Modo treino</h2>
      <p class="sub">Cria 5 pacientes de mentira, com [TREINO] no nome, para a equipe praticar agenda, ficha, prontuário e receita sem medo de errar. Depois, um toque remove os pacientes e tudo o que foi feito neles. Seus pacientes de verdade não são tocados.</p>
      <div class="btn-row"><button class="btn btn-ghost" id="gdTreinoCriar">Criar pacientes de treino</button><button class="btn btn-outline" id="gdTreinoRemover">Remover treino</button></div>
    </div>
    <div class="card"><h2>Mapa de funções</h2>
      <p class="sub">Todas as funções do sistema, por perfil. Procure pelo que você quer fazer e toque em Abrir. O tour mostra uma função de cada vez.</p>
      <input type="text" id="gdBusca" placeholder="O que você quer fazer? Ex.: backup, receita, feriado" autocomplete="off">
      <div style="display:flex;gap:8px;margin:10px 0;flex-wrap:wrap;">
        <select id="gdPerfil" style="width:auto;"><option value="">Todos os perfis</option><option value="admin">Master</option><option value="atendente">Agendador</option><option value="profissional">Profissional</option></select>
        <button class="btn btn-ghost" id="gdTour" type="button">Fazer o tour</button>
      </div>
      <div id="gdFuncoes"></div>
    </div>`;
}
const gdCor = {erro:'#C1462F', aviso:'#B26A00', ok:'#2E7D4F', info:'#4B5755'};
const gdSimbolo = {erro:'✖', aviso:'▲', ok:'✔', info:'●'};
function gdPassosModal(titulo, passos){
  openModal(`<h2>${esc(titulo)}</h2><ol style="padding-left:20px;line-height:1.55;">${passos.map(p=>`<li style="margin:6px 0;">${esc(p)}</li>`).join('')}</ol><div class="btn-row"><button class="btn btn-primary" onclick="closeModal()">Entendi</button></div>`);
}
async function gdCorrigir(id, confirmar){
  if(confirmar && !window.confirm(confirmar)) return;
  try{
    toast('Corrigindo...');
    const r = await api('/clinica/guardiao/corrigir', { method:'POST', body:{ id } });
    toast(r.mensagem || 'Pronto.');
  }catch(e){ erroApi(e); }
  carregarGuardiao(); guardiaoSelo(true);
}
function gdItemHtml(i){
  const a = i.acao; let botoes = '';
  if(a && a.tipo==='corrigir') botoes = `<button class="btn btn-ghost" data-gd="corrigir" data-id="${esc(a.id)}" data-conf="${esc(a.confirmar||'')}" style="margin-top:6px;">${esc(a.rotulo)}</button>`;
  else if(a && a.tipo==='ir') botoes = `<button class="btn btn-ghost" data-gd="ir" data-a='${esc(JSON.stringify(a))}' style="margin-top:6px;">${esc(a.rotulo)}</button>`;
  else if(a && a.tipo==='passos') botoes = `<button class="btn btn-ghost" data-gd="passos" data-t="${esc(i.titulo)}" data-p='${esc(JSON.stringify(a.passos))}' style="margin-top:6px;">${esc(a.rotulo)}</button>`;
  else if(a && a.tipo==='obrigacao') botoes = `<div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:6px;"><button class="btn btn-ghost" data-gd="feita" data-id="${esc(a.id)}">Já fiz</button><button class="btn btn-outline" data-gd="adiar" data-id="${esc(a.id)}">Adiar 7 dias</button></div>`;
  return `<div style="border-top:1px solid var(--line);padding:10px 0;"><div style="display:flex;gap:10px;align-items:flex-start;"><span style="color:${gdCor[i.nivel]};font-weight:700;flex:0 0 18px;">${gdSimbolo[i.nivel]}</span><div style="flex:1;min-width:0;"><b>${esc(i.titulo)}</b><div class="sub" style="margin:2px 0 0;">${esc(i.detalhe)}</div>${botoes}</div></div></div>`;
}
let gdMostrarOk = false;
async function carregarGuardiao(){
  const box = document.getElementById('gdLista'), res = document.getElementById('gdResumo'); if(!box) return;
  try{
    const v = await api('/clinica/guardiao');
    const r = v.resumo;
    res.innerHTML = r.erros ? `<p style="font-weight:700;color:${gdCor.erro};margin:0;">${r.erros} problema(s) para resolver${r.avisos?` e ${r.avisos} aviso(s)`:''}.</p>` :
      r.avisos ? `<p style="font-weight:700;color:${gdCor.aviso};margin:0;">Nenhum problema grave. ${r.avisos} aviso(s).</p>` : `<p style="font-weight:700;color:${gdCor.ok};margin:0;">Tudo em ordem.</p>`;
    res.innerHTML += `<p class="sub" style="margin:2px 0 0;">Conferido às ${new Date(v.gerado_em).toLocaleTimeString('pt-BR',{hour:'2-digit',minute:'2-digit'})}. O Guardião confere sozinho a cada 6 horas.</p>`;
    const grupos = ['Obrigações','Segurança','Backup','Sistema','Operação'];
    const atencao = v.itens.filter(i=>i.nivel==='erro'||i.nivel==='aviso');
    const resto = v.itens.filter(i=>i.nivel==='ok'||i.nivel==='info');
    let html = '';
    for(const g of grupos){ const it = atencao.filter(i=>i.grupo===g); if(it.length) html += `<h3 style="margin:14px 0 2px;font-size:14px;color:var(--ink-soft);">${g}</h3>` + it.map(gdItemHtml).join(''); }
    if(!atencao.length) html = '<p class="sub">Nada precisa da sua atenção agora.</p>';
    html += `<button class="btn btn-outline btn-block" id="gdVerOk" style="margin-top:12px;">${gdMostrarOk?'Esconder':'Mostrar'} o que está em dia (${resto.length})</button>`;
    if(gdMostrarOk) html += '<div>' + grupos.map(g=>{ const it = resto.filter(i=>i.grupo===g); return it.length ? `<h3 style="margin:14px 0 2px;font-size:14px;color:var(--ink-soft);">${g}</h3>` + it.map(gdItemHtml).join('') : ''; }).join('') + '</div>';
    box.innerHTML = html;
    document.getElementById('gdVerOk').onclick = ()=>{ gdMostrarOk = !gdMostrarOk; carregarGuardiao(); };
    box.querySelectorAll('[data-gd]').forEach(b=> b.onclick = async ()=>{
      const k = b.dataset.gd;
      if(k==='corrigir') gdCorrigir(b.dataset.id, b.dataset.conf);
      else if(k==='ir') guardiaoIr(JSON.parse(b.dataset.a));
      else if(k==='passos') gdPassosModal(b.dataset.t, JSON.parse(b.dataset.p));
      else if(k==='feita' || k==='adiar'){
        try{ await api(`/clinica/guardiao/obrigacoes/${b.dataset.id}/${k}`, { method:'POST', body:{ dias:7 } }); toast(k==='feita'?'Anotado.':'Adiado 7 dias.'); }catch(e){ erroApi(e); }
        carregarGuardiao(); carregarObrigacoes(); guardiaoSelo(true);
      }
    });
  }catch(e){ res.innerHTML = `<p class="fieldmsg bad">${esc(e.message)}</p>`; }
}
async function carregarObrigacoes(){
  const box = document.getElementById('gdObrigacoes'); if(!box) return;
  try{
    const l = await api('/clinica/guardiao/obrigacoes');
    const hoje = new Date().toISOString().slice(0,10);
    box.innerHTML = l.length ? l.map(o=>{
      const feita = !!o.feito_em, vencida = !feita && o.vence_em < hoje;
      return `<div style="border-top:1px solid var(--line);padding:9px 0;display:flex;gap:10px;justify-content:space-between;align-items:flex-start;">
        <div style="min-width:0;"><b style="${feita?'text-decoration:line-through;color:var(--ink-soft);':''}">${esc(o.titulo)}</b>
        <div class="sub" style="margin:2px 0 0;${vencida?'color:#C1462F;font-weight:600;':''}">${feita?'Feita':'Vence em '+fmtData(o.vence_em)}${o.repetir_dias?` · repete a cada ${o.repetir_dias} dias`:''}</div>
        ${o.detalhe && !feita ? `<details style="margin-top:4px;"><summary style="cursor:pointer;font-size:13px;color:var(--teal-700,#1F6F8B);">Como fazer</summary><div class="sub" style="margin-top:4px;">${esc(o.detalhe)}</div></details>` : ''}</div>
        <div style="display:flex;gap:6px;flex:0 0 auto;">${feita?'':`<button class="btn btn-ghost" data-ob="feita" data-id="${o.id}">Feito</button>`}<button class="btn btn-outline" data-ob="del" data-id="${o.id}" title="Remover">✕</button></div></div>`;
    }).join('') : '<p class="sub">Nenhuma obrigação.</p>';
    box.querySelectorAll('[data-ob]').forEach(b=> b.onclick = async ()=>{
      try{
        if(b.dataset.ob==='feita') await api(`/clinica/guardiao/obrigacoes/${b.dataset.id}/feita`, { method:'POST', body:{} });
        else { if(!window.confirm('Remover esta obrigação da lista?')) return; await api(`/clinica/guardiao/obrigacoes/${b.dataset.id}`, { method:'DELETE' }); }
      }catch(e){ return erroApi(e); }
      carregarObrigacoes(); carregarGuardiao(); guardiaoSelo(true);
    });
  }catch(e){ box.innerHTML = `<p class="fieldmsg bad">${esc(e.message)}</p>`; }
}
function listarFuncoes(){
  const box = document.getElementById('gdFuncoes'); if(!box) return;
  const q = (document.getElementById('gdBusca').value||'').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g,'');
  const per = document.getElementById('gdPerfil').value;
  const lista = FUNCOES.filter(f=> (!per || f.p.includes(per)) && (!q || (f.n+' '+f.d+' '+f.t).toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g,'').includes(q)));
  box.innerHTML = lista.length ? lista.map(f=>`<div style="border-top:1px solid var(--line);padding:10px 0;"><div style="display:flex;justify-content:space-between;gap:10px;align-items:flex-start;"><div style="min-width:0;"><b>${esc(f.n)}</b><div class="sub" style="margin:2px 0 0;">${esc(f.d)}</div><div class="sub" style="margin:2px 0 0;font-size:12px;">Para: ${f.p.map(x=>NOME_PAPEL[x]).join(', ')}</div></div><button class="btn btn-ghost" data-f="${FUNCOES.indexOf(f)}" style="flex:0 0 auto;">Abrir</button></div></div>`).join('') : '<p class="sub">Nada encontrado. Tente outra palavra.</p>';
  box.querySelectorAll('[data-f]').forEach(b=> b.onclick = ()=>{ const f = FUNCOES[+b.dataset.f]; closeModal(); guardiaoIr(f); });
}
function tourFuncoes(){
  const per = document.getElementById('gdPerfil').value || 'admin';
  const lista = FUNCOES.filter(f=>f.p.includes(per));
  let i = 0;
  const mostrar = ()=>{
    const f = lista[i];
    openModal(`<p class="sub" style="margin:0;">Tour do ${NOME_PAPEL[per]} · ${i+1} de ${lista.length}</p><h2 style="margin-top:4px;">${esc(f.n)}</h2><p style="line-height:1.5;">${esc(f.d)}</p>
      <div class="btn-row"><button class="btn btn-outline" id="trAnt" ${i===0?'disabled':''}>Voltar</button><button class="btn btn-primary" id="trProx">${i===lista.length-1?'Terminar':'Próxima'}</button></div>
      <button class="btn btn-ghost btn-block" id="trAbrir" style="margin-top:8px;">Abrir esta tela</button>`);
    document.getElementById('trAnt').onclick = ()=>{ i--; mostrar(); };
    document.getElementById('trProx').onclick = ()=>{ if(i===lista.length-1) closeModal(); else { i++; mostrar(); } };
    document.getElementById('trAbrir').onclick = ()=>{ closeModal(); guardiaoIr(f); };
  };
  mostrar();
}
function ligarGuardiao(){
  if(!document.getElementById('gdLista')) return;
  carregarGuardiao(); carregarObrigacoes(); listarFuncoes();
  document.getElementById('gdAtualizar').onclick = ()=>{ carregarGuardiao(); guardiaoSelo(true); };
  document.getElementById('gdBusca').oninput = listarFuncoes;
  document.getElementById('gdPerfil').onchange = listarFuncoes;
  document.getElementById('gdTour').onclick = tourFuncoes;
  document.getElementById('gdObrAdd').onclick = async ()=>{
    const titulo = document.getElementById('gdObrTitulo').value.trim(), data = document.getElementById('gdObrData').value, rep = document.getElementById('gdObrRep').value;
    if(!titulo || !data) return toast('Escreva o que lembrar e escolha a data.');
    try{ await api('/clinica/guardiao/obrigacoes', { method:'POST', body:{ titulo, vence_em:data, repetir_dias: rep||null } }); toast('Obrigação adicionada.'); document.getElementById('gdObrTitulo').value=''; carregarObrigacoes(); carregarGuardiao(); }
    catch(e){ erroApi(e); }
  };
  document.getElementById('gdTreinoCriar').onclick = ()=> gdCorrigir('treino_criar');
  document.getElementById('gdTreinoRemover').onclick = ()=> gdCorrigir('treino_remover', 'Remover os pacientes de treino e tudo o que foi feito neles?');
}
/* aviso no Início do Master quando o Guardião achou problema */
let gdObservador = null;
async function guardiaoAvisoInicio(){
  if(gdObservador){ gdObservador.disconnect(); gdObservador = null; }
  if(usuarioAtual?.papel!=='admin') return;
  try{
    const r = await api('/clinica/guardiao/resumo');
    const main = document.getElementById('main'); if(!main || (!r.erros && !r.avisos)) return;
    const pr = ()=>{
      if(document.getElementById('gdAvisoInicio') || !main.firstChild) return;
      const v = document.querySelector('#pillnav button.active')?.dataset.view; if(v!=='inicio' && v!=='painel') return;
      const d = document.createElement('div'); d.className = 'card'; d.id = 'gdAvisoInicio';
      d.innerHTML = `<h2 style="color:${r.erros?gdCor.erro:gdCor.aviso};">Guardião: ${r.erros?r.erros+' problema(s)':r.avisos+' aviso(s)'}</h2><p class="sub">O Guardião achou ${r.erros?'problemas que precisam da sua atenção':'avisos para você olhar'}. Toque para ver e corrigir.</p><button class="btn btn-primary btn-block" id="gdAbrir">Abrir o Guardião</button>`;
      main.insertBefore(d, main.firstChild);
      d.querySelector('#gdAbrir').onclick = ()=> guardiaoIr({view:'master', aba:'Guardião'});
    };
    pr();
    /* a tela do Painel carrega os números depois e refaz o conteúdo: o aviso volta junto */
    gdObservador = new MutationObserver(pr);
    gdObservador.observe(main, { childList:true });
  }catch(e){}
}
/* bolinha vermelha no menu Master com o número de problemas */
let gdSeloEm = 0;
async function guardiaoSelo(forcar){
  if(usuarioAtual?.papel!=='admin') return;
  if(!forcar && Date.now()-gdSeloEm < 60000) return;
  gdSeloEm = Date.now();
  try{
    const r = await api('/clinica/guardiao/resumo');
    const btn = document.getElementById('btnMasterAccess'); if(!btn) return;
    let s = btn.querySelector('.selo-gd'); if(!s){ s = document.createElement('span'); s.className = 'selo-gd'; btn.appendChild(s); }
    const n = r.erros || r.avisos || 0;
    s.textContent = n ? String(n) : ''; s.style.display = n ? '' : 'none';
    s.style.background = r.erros ? '#C1462F' : '#B26A00';
    s.title = r.erros ? r.erros+' problema(s) no Guardião' : n ? n+' aviso(s) no Guardião' : '';
  }catch(e){}
}

if('serviceWorker' in navigator){ window.addEventListener('load', ()=>{ navigator.serviceWorker.register('/sw.js').catch(()=>{}); }); }
