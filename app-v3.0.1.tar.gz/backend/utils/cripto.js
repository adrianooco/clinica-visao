/* Criptografia dos dados sensíveis (AES-256-GCM).
   A chave vem da variável CHAVE_CRIPTOGRAFIA (fica só no servidor, nunca no banco).
   Sem a chave, o sistema funciona igual, mas grava sem embaralhar.
   Valores embaralhados começam com "enc1:". Valores antigos (sem prefixo) continuam legíveis. */
const crypto = require('crypto');

const PREFIXO = 'enc1:';
let chave = null;
function pegarChave() {
  if (chave !== null) return chave || null;
  const bruta = process.env.CHAVE_CRIPTOGRAFIA;
  chave = bruta ? crypto.createHash('sha256').update(String(bruta)).digest() : false;
  return chave || null;
}
const ativa = () => !!pegarChave();
const jaCifrado = (v) => typeof v === 'string' && v.startsWith(PREFIXO);

function cifrar(texto) {
  if (texto === null || texto === undefined || texto === '') return texto;
  const k = pegarChave();
  if (!k || jaCifrado(texto)) return texto;
  const iv = crypto.randomBytes(12);
  const c = crypto.createCipheriv('aes-256-gcm', k, iv);
  const dados = Buffer.concat([c.update(String(texto), 'utf8'), c.final()]);
  return PREFIXO + Buffer.concat([iv, c.getAuthTag(), dados]).toString('base64');
}
function decifrar(valor) {
  if (!jaCifrado(valor)) return valor;
  const k = pegarChave();
  if (!k) throw new Error('Dados embaralhados, mas falta a variável CHAVE_CRIPTOGRAFIA.');
  const b = Buffer.from(valor.slice(PREFIXO.length), 'base64');
  const d = crypto.createDecipheriv('aes-256-gcm', k, b.subarray(0, 12));
  d.setAuthTag(b.subarray(12, 28));
  return Buffer.concat([d.update(b.subarray(28)), d.final()]).toString('utf8');
}
/* JSON: vira um texto embaralhado guardado como string dentro do jsonb */
function cifrarJson(obj) {
  if (obj === null || obj === undefined) return null;
  const k = pegarChave();
  return JSON.stringify(k ? cifrar(JSON.stringify(obj)) : obj);
}
function decifrarJson(v) {
  if (typeof v === 'string' && jaCifrado(v)) return JSON.parse(decifrar(v));
  return v;
}

const CAMPOS_TEXTO = ['queixa_principal', 'observacoes_clinicas', 'conduta'];
const CAMPOS_JSON = ['sintomas', 'gabarito_acuidade', 'refracao', 'exame'];
function abrirProntuario(l) {
  if (!l) return l;
  const o = { ...l };
  for (const c of CAMPOS_TEXTO) if (c in o) o[c] = decifrar(o[c]);
  for (const c of CAMPOS_JSON) if (c in o) o[c] = decifrarJson(o[c]);
  return o;
}
function abrirPaciente(l) {
  if (!l) return l;
  const o = { ...l };
  for (const c of ['foto_receita_url', 'foto_armacao_url']) if (c in o) o[c] = decifrar(o[c]);
  return o;
}

/* foto grande demais (texto base64): o celular já reduz antes de enviar, isto é a trava do servidor */
const fotoGrande = (v) => typeof v === 'string' && v.length > 1500000;

module.exports = { fotoGrande, ativa, cifrar, decifrar, cifrarJson, decifrarJson, jaCifrado, abrirProntuario, abrirPaciente, CAMPOS_TEXTO, CAMPOS_JSON };
