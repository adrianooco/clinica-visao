/* Ao ligar o servidor com a chave, embaralha o que ainda está aberto no banco (prontuários e fotos).
   Pode rodar quantas vezes quiser: o que já está embaralhado é ignorado. */
const pool = require('../db/pool');
const cripto = require('./cripto');

async function protegerExistentes() {
  if (!cripto.ativa()) return { prontuarios: 0, fotos: 0, aviso: 'sem chave' };
  let pr = 0, fo = 0;
  const p = await pool.query(`SELECT id, queixa_principal, observacoes_clinicas, conduta, sintomas, gabarito_acuidade, refracao, exame FROM prontuarios`);
  for (const l of p.rows) {
    const abertos = cripto.CAMPOS_TEXTO.some((c) => l[c] && !cripto.jaCifrado(l[c])) || cripto.CAMPOS_JSON.some((c) => l[c] != null && !(typeof l[c] === 'string' && cripto.jaCifrado(l[c])));
    if (!abertos) continue;
    const t = cripto.CAMPOS_TEXTO.map((c) => (l[c] ? cripto.cifrar(l[c]) : null));
    const j = cripto.CAMPOS_JSON.map((c) => (l[c] != null ? (typeof l[c] === 'string' && cripto.jaCifrado(l[c]) ? JSON.stringify(l[c]) : cripto.cifrarJson(l[c])) : null));
    await pool.query(`UPDATE prontuarios SET queixa_principal=$1, observacoes_clinicas=$2, conduta=$3, sintomas=$4, gabarito_acuidade=$5, refracao=$6, exame=$7 WHERE id=$8`, [...t, ...j, l.id]);
    pr++;
  }
  const v = await pool.query(`SELECT id, snapshot FROM prontuario_versoes WHERE snapshot IS NOT NULL`);
  for (const l of v.rows) {
    const o = l.snapshot; if (!o || typeof o !== 'object') continue;
    let mudou = false;
    for (const c of cripto.CAMPOS_TEXTO) if (o[c] && !cripto.jaCifrado(o[c])) { o[c] = cripto.cifrar(o[c]); mudou = true; }
    for (const c of cripto.CAMPOS_JSON) if (o[c] != null && !(typeof o[c] === 'string' && cripto.jaCifrado(o[c]))) { o[c] = cripto.cifrar(JSON.stringify(o[c])); mudou = true; }
    if (mudou) { await pool.query(`UPDATE prontuario_versoes SET snapshot=$1 WHERE id=$2`, [JSON.stringify(o), l.id]); pr++; }
  }
  const f = await pool.query(`SELECT id, foto_receita_url, foto_armacao_url FROM pacientes WHERE (foto_receita_url IS NOT NULL AND foto_receita_url NOT LIKE 'enc1:%') OR (foto_armacao_url IS NOT NULL AND foto_armacao_url NOT LIKE 'enc1:%')`);
  for (const l of f.rows) {
    await pool.query(`UPDATE pacientes SET foto_receita_url=$1, foto_armacao_url=$2 WHERE id=$3`, [l.foto_receita_url ? cripto.cifrar(l.foto_receita_url) : null, l.foto_armacao_url ? cripto.cifrar(l.foto_armacao_url) : null, l.id]);
    fo++;
  }
  return { prontuarios: pr, fotos: fo };
}
module.exports = protegerExistentes;
