const express = require('express');
const bcrypt = require('bcryptjs');
const pool = require('../db/pool');
const { exigirLogin, exigirAdmin, limparCacheUsuario } = require('../middleware/auth');
const { validarSenha } = require('../utils/senha');

const { limparConfig } = require('../utils/ficha');
const router = express.Router();
router.use(exigirLogin);

router.get('/', async (req, res) => {
  // chave_integracao fica fora daqui de propósito: ela dá acesso de escrita na agenda
  // sem precisar de login, então só o admin pode vê-la (rota separada abaixo)
  const r = await pool.query(
    `SELECT id, slug, nome_fantasia, cnpj, endereco, local_exame_padrao, telefone, link_site, logo_url,
            campos_obrigatorios, config_impressao, whatsapp_numero, whatsapp_auto, horario_abertura, horario_fechamento, dias_funcionamento, ativa, criado_em, atualizado_em
     FROM clinicas WHERE id=$1`,
    [req.usuario.clinicaId]
  );
  res.json(r.rows[0]);
});

/* só admin: a chave de integração dá acesso de escrita na agenda sem senha de funcionário */
router.get('/chave-integracao', exigirAdmin, async (req, res) => {
  const r = await pool.query(`SELECT chave_integracao FROM clinicas WHERE id=$1`, [req.usuario.clinicaId]);
  res.json({ chave_integracao: r.rows[0]?.chave_integracao || null });
});

router.put('/', exigirAdmin, async (req, res) => {
  const { nome_fantasia, endereco, local_exame_padrao, telefone, link_site, campos_obrigatorios, logo_url, whatsapp_numero, whatsapp_auto } = req.body;
  const wpp = String(whatsapp_numero || '').replace(/\D/g, '').replace(/^55(?=\d{10,11}$)/, '').slice(0, 11) || null;
  const antes = (await pool.query(`SELECT whatsapp_auto FROM clinicas WHERE id=$1`, [req.usuario.clinicaId])).rows[0];
  const r = await pool.query(
    `UPDATE clinicas SET nome_fantasia=$1, endereco=$2, local_exame_padrao=$3, telefone=$4, link_site=$5, campos_obrigatorios=$6, logo_url=$7,
            whatsapp_numero=COALESCE($9, whatsapp_numero), whatsapp_auto=COALESCE($10, whatsapp_auto)
     WHERE id=$8 RETURNING *`,
    [nome_fantasia, endereco || null, local_exame_padrao || null, telefone || null, link_site || null,
     JSON.stringify(limparConfig(campos_obrigatorios)), logo_url || null, req.usuario.clinicaId,
     whatsapp_numero === undefined ? null : wpp, whatsapp_auto === undefined ? null : !!whatsapp_auto]
  );
  // ao ligar o WhatsApp automático pela primeira vez, quem já estava agendado não recebe uma enxurrada de confirmações
  if (whatsapp_auto === true && antes && !antes.whatsapp_auto) {
    await pool.query(`UPDATE agendamentos SET lembrete_confirmacao_enviado=TRUE WHERE clinica_id=$1 AND criado_em < NOW()`, [req.usuario.clinicaId]);
  }
  res.json(r.rows[0]);
});

/* lista enxuta dos profissionais ativos, pra qualquer usuário logado escolher
   quem atendeu (ex: no formulário de receita). Não expõe dado administrativo. */
router.get('/profissionais', async (req, res) => {
  if (req.usuario.papel === 'atendente' && !(req.usuario.permissoes || []).includes('receita')) return res.json([]);
  // inclui carimbo/assinatura/registro aqui mesmo: é o que vai ser impresso na
  // receita, então quem monta a receita (mesmo sendo atendente) precisa enxergar
  const r = await pool.query(
    `SELECT id, nome, registro_conselho, carimbo_texto, assinatura_url
     FROM usuarios WHERE clinica_id=$1 AND papel='profissional' AND ativo=TRUE ORDER BY nome`,
    [req.usuario.clinicaId]
  );
  res.json(r.rows);
});

/* Como imprimir receita, atestado e declaração: tamanho da folha, cor, margem e rodapé */
const PAPEIS_FOLHA = ['A4', 'A5', 'Letter'];
router.put('/impressao', exigirAdmin, async (req, res) => {
  const b = req.body || {};
  const cfg = {
    papel: PAPEIS_FOLHA.includes(b.papel) ? b.papel : 'A4',
    orientacao: b.orientacao === 'landscape' ? 'landscape' : 'portrait',
    cor: b.cor === 'pb' ? 'pb' : 'colorido',
    margem_mm: Math.min(Math.max(parseInt(b.margem_mm, 10) || 14, 5), 30),
    rodape: String(b.rodape || '').slice(0, 300),
  };
  await pool.query(`UPDATE clinicas SET config_impressao=$1 WHERE id=$2`, [JSON.stringify(cfg), req.usuario.clinicaId]);
  res.json(cfg);
});

/* usuários (atendentes, profissionais) da clínica, só o admin gerencia */
router.get('/usuarios', exigirAdmin, async (req, res) => {
  const r = await pool.query(
    `SELECT u.id, u.nome, u.email, u.papel, u.ativo, u.unidade_id, un.nome AS unidade_nome,
            u.registro_conselho, u.carimbo_texto, u.permissoes, (u.assinatura_url IS NOT NULL) AS tem_assinatura
     FROM usuarios u LEFT JOIN unidades un ON un.id = u.unidade_id
     WHERE u.clinica_id=$1 ORDER BY u.nome`,
    [req.usuario.clinicaId]
  );
  res.json(r.rows);
});

const PAPEIS_VALIDOS = ['admin', 'atendente', 'profissional'];

router.post('/usuarios', exigirAdmin, async (req, res) => {
  const { nome, email, senha, papel, unidade_id, registro_conselho, carimbo_texto, assinatura_url } = req.body;
  if (!nome || !email || !senha) return res.status(400).json({ erro: 'Preencha nome, e-mail e senha.' });
  { const e = validarSenha(senha); if (e) return res.status(400).json({ erro: e }); }
  const papelFinal = PAPEIS_VALIDOS.includes(papel) ? papel : 'atendente';
  try {
    const senhaHash = await bcrypt.hash(senha, 10);
    const r = await pool.query(
      `INSERT INTO usuarios (clinica_id, unidade_id, nome, email, senha_hash, papel, registro_conselho, carimbo_texto, assinatura_url)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING id, nome, email, papel, unidade_id, registro_conselho, carimbo_texto`,
      [req.usuario.clinicaId, unidade_id || null, nome, email.toLowerCase().trim(), senhaHash, papelFinal,
       papelFinal === 'profissional' ? (registro_conselho || null) : null,
       papelFinal === 'profissional' ? (carimbo_texto || null) : null,
       papelFinal === 'profissional' ? (assinatura_url || null) : null]
    );
    res.status(201).json(r.rows[0]);
  } catch (e) {
    if (e.code === '23505') return res.status(409).json({ erro: 'Já existe um usuário com esse e-mail nesta clínica.' });
    console.error(e); res.status(500).json({ erro: 'Erro ao criar usuário.' });
  }
});

/* editar dados de um usuário, incluindo carimbo/assinatura do profissional */
router.put('/usuarios/:id', exigirAdmin, async (req, res) => {
  const { nome, papel, unidade_id, registro_conselho, carimbo_texto, assinatura_url, ativo, permissoes } = req.body;
  const CHAVES = ['calendario', 'pacientes', 'assistente', 'receita', 'prontuario', 'retornos'];
  // ninguém desativa a si mesmo nem tira o último admin ativo
  if (ativo === false || (papel && papel !== 'admin')) {
    if (String(req.params.id) === String(req.usuario.usuarioId)) return res.status(400).json({ erro: 'Você não pode desativar nem rebaixar o seu próprio acesso.' });
    const alvo = (await pool.query(`SELECT papel FROM usuarios WHERE id=$1 AND clinica_id=$2`, [req.params.id, req.usuario.clinicaId])).rows[0];
    if (alvo && alvo.papel === 'admin') {
      const outros = (await pool.query(`SELECT COUNT(*)::int AS n FROM usuarios WHERE clinica_id=$1 AND papel='admin' AND ativo=TRUE AND id<>$2`, [req.usuario.clinicaId, req.params.id])).rows[0].n;
      if (!outros) return res.status(400).json({ erro: 'Precisa sobrar pelo menos um administrador ativo.' });
    }
  }
  const permFinal = Array.isArray(permissoes) ? JSON.stringify(permissoes.filter((c) => CHAVES.includes(c))) : null;
  const papelFinal = PAPEIS_VALIDOS.includes(papel) ? papel : null;
  const r = await pool.query(
    `UPDATE usuarios SET
       nome = COALESCE($1, nome),
       papel = COALESCE($2, papel),
       unidade_id = $3,
       registro_conselho = CASE WHEN COALESCE($2,papel)='profissional' THEN $4 ELSE NULL END,
       carimbo_texto = CASE WHEN COALESCE($2,papel)='profissional' THEN $5 ELSE NULL END,
       assinatura_url = CASE WHEN COALESCE($2,papel)='profissional' THEN $6 ELSE NULL END,
       ativo = COALESCE($7, ativo),
       permissoes = COALESCE($10::jsonb, permissoes)
     WHERE id=$8 AND clinica_id=$9
     RETURNING id, nome, email, papel, unidade_id, registro_conselho, carimbo_texto, ativo`,
    [nome || null, papelFinal, unidade_id || null, registro_conselho || null, carimbo_texto || null,
     assinatura_url || null, ativo === undefined ? null : ativo, req.params.id, req.usuario.clinicaId, permFinal]
  );
  if (!r.rows.length) return res.status(404).json({ erro: 'Usuário não encontrado.' });
  limparCacheUsuario(req.params.id);
  res.json(r.rows[0]);
});

/* Excluir usuário. Se ele já tem registros (agendamentos, receitas), o banco não deixa apagar:
   nesse caso o acesso é desativado e o histórico fica preservado. */
router.delete('/usuarios/:id', exigirAdmin, async (req, res) => {
  if (String(req.params.id) === String(req.usuario.usuarioId)) return res.status(400).json({ erro: 'Você não pode excluir o seu próprio acesso.' });
  const alvo = (await pool.query(`SELECT id, papel FROM usuarios WHERE id=$1 AND clinica_id=$2`, [req.params.id, req.usuario.clinicaId])).rows[0];
  if (!alvo) return res.status(404).json({ erro: 'Usuário não encontrado.' });
  if (alvo.papel === 'admin') {
    const outros = (await pool.query(`SELECT COUNT(*)::int AS n FROM usuarios WHERE clinica_id=$1 AND papel='admin' AND ativo=TRUE AND id<>$2`, [req.usuario.clinicaId, alvo.id])).rows[0].n;
    if (!outros) return res.status(400).json({ erro: 'Precisa sobrar pelo menos um administrador ativo.' });
  }
  try {
    await pool.query(`DELETE FROM usuarios WHERE id=$1 AND clinica_id=$2`, [alvo.id, req.usuario.clinicaId]);
    limparCacheUsuario(alvo.id);
    return res.json({ ok: true, excluido: true });
  } catch (e) {
    if (e.code !== '23503') throw e;
    await pool.query(`UPDATE usuarios SET ativo=FALSE WHERE id=$1 AND clinica_id=$2`, [alvo.id, req.usuario.clinicaId]);
    limparCacheUsuario(alvo.id);
    return res.json({ ok: true, excluido: false, desativado: true });
  }
});

/* Acessos: o administrador escolhe o que cada agendador pode abrir */
router.put('/usuarios/:id/permissoes', exigirAdmin, async (req, res) => {
  const CHAVES = ['calendario', 'pacientes', 'assistente', 'receita', 'prontuario', 'retornos'];
  const lista = (Array.isArray(req.body.permissoes) ? req.body.permissoes : []).filter((c) => CHAVES.includes(c));
  const r = await pool.query(`UPDATE usuarios SET permissoes=$1::jsonb WHERE id=$2 AND clinica_id=$3 RETURNING id, permissoes`, [JSON.stringify(lista), req.params.id, req.usuario.clinicaId]);
  if (!r.rows.length) return res.status(404).json({ erro: 'Usuário não encontrado.' });
  limparCacheUsuario(req.params.id);
  res.json(r.rows[0]);
});

/* o próprio profissional logado consulta seus dados de carimbo/assinatura (pra receita puxar) */
router.get('/usuarios/eu', async (req, res) => {
  const r = await pool.query(
    `SELECT id, nome, papel, registro_conselho, carimbo_texto, assinatura_url FROM usuarios WHERE id=$1 AND clinica_id=$2`,
    [req.usuario.usuarioId, req.usuario.clinicaId]
  );
  if (!r.rows.length) return res.status(404).json({ erro: 'Usuário não encontrado.' });
  res.json(r.rows[0]);
});

router.put('/usuarios/:id/senha', exigirAdmin, async (req, res) => {
  const { senha } = req.body;
  if (!senha) return res.status(400).json({ erro: 'Informe a nova senha.' });
  { const e = validarSenha(senha); if (e) return res.status(400).json({ erro: e }); }
  const senhaHash = await bcrypt.hash(senha, 10);
  const r = await pool.query(
    `UPDATE usuarios SET senha_hash=$1 WHERE id=$2 AND clinica_id=$3 RETURNING id`,
    [senhaHash, req.params.id, req.usuario.clinicaId]
  );
  if (!r.rows.length) return res.status(404).json({ erro: 'Usuário não encontrado.' });
  res.json({ ok: true });
});

/* WhatsApp automático: situação e mensagem de teste (só o admin) */
router.get('/whatsapp-status', exigirAdmin, async (req, res) => {
  const wpp = require('../utils/whatsapp');
  const r = await pool.query(`SELECT whatsapp_numero, whatsapp_auto FROM clinicas WHERE id=$1`, [req.usuario.clinicaId]);
  res.json({
    servidor_configurado: wpp.configurado(),
    modelo_configurado: !!process.env.WA_TEMPLATE,
    webhook_configurado: !!(process.env.WA_VERIFY_TOKEN && process.env.WA_APP_SECRET),
    numero: r.rows[0]?.whatsapp_numero || null,
    automatico: !!r.rows[0]?.whatsapp_auto,
    endereco_webhook: `${req.protocol}://${req.get('host')}/whatsapp/webhook`,
  });
});

router.post('/whatsapp-teste', exigirAdmin, async (req, res) => {
  const wpp = require('../utils/whatsapp');
  if (!wpp.configurado()) return res.status(400).json({ erro: 'O servidor ainda não tem as chaves do WhatsApp (WA_TOKEN e WA_PHONE_ID).' });
  if (!wpp.normalizar(req.body.telefone)) return res.status(400).json({ erro: 'Digite um telefone com DDD.' });
  try {
    await wpp.enviarIniciada(req.body.telefone, 'Teste do WhatsApp automático da Clínica de Visão. Se você recebeu, está funcionando.');
    res.json({ ok: true });
  } catch (e) {
    res.status(502).json({ erro: `A Meta recusou o envio: ${e.message}` });
  }
});

/* Registro de acessos: quem abriu ou mexeu em dado de saúde (só o admin vê) */
router.get('/acessos', exigirAdmin, async (req, res) => {
  const r = await pool.query(
    `SELECT usuario_nome, acao, area, caminho, ip, criado_em FROM acessos_log WHERE clinica_id=$1 ORDER BY criado_em DESC LIMIT 300`,
    [req.usuario.clinicaId]);
  res.json(r.rows);
});

/* Backup: o admin baixa uma cópia completa, trancada com uma senha escolhida na hora */
router.post('/backup', exigirAdmin, async (req, res) => {
  const { gerarBackupCompleto, protegerBackup } = require('../utils/backup');
  const senha = String(req.body.senha || '');
  if (senha.length < 8) return res.status(400).json({ erro: 'A senha do backup precisa ter pelo menos 8 caracteres.' });
  const copia = await gerarBackupCompleto(req.usuario.clinicaId);
  await pool.query(`INSERT INTO acessos_log (clinica_id, usuario_id, usuario_nome, acao, area, caminho, ip) VALUES ($1,$2,$3,'POST','backup','/clinica/backup',$4)`,
    [req.usuario.clinicaId, req.usuario.usuarioId, req.usuario.nome, req.ip]).catch(() => {});
  res.setHeader('Cache-Control', 'no-store');
  res.json(protegerBackup(copia, senha));
});

/* Quando foi o último backup (o painel avisa se passou de 7 dias) */
router.get('/backup-status', exigirAdmin, async (req, res) => {
  const r = await pool.query(
    `SELECT MAX(criado_em) AS ultimo, FLOOR(EXTRACT(EPOCH FROM (LOCALTIMESTAMP - MAX(criado_em))) / 86400) AS dias FROM acessos_log WHERE clinica_id=$1 AND area='backup'`,
    [req.usuario.clinicaId]);
  const ultimo = r.rows[0].ultimo;
  res.json({ ultimo, dias: ultimo ? Math.max(0, Number(r.rows[0].dias)) : null });
});

module.exports = router;
