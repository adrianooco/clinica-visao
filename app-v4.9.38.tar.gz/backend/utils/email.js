/* Envio de e-mail (recuperar senha, aviso de aparelho novo, backup semanal).
   Fica desligado até você colocar no servidor: SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS e EMAIL_DE.
   Serviços simples que servem: Brevo, Resend (SMTP), Gmail com senha de app. */
const nodemailer = require('nodemailer');

let transporte = null;
const TESTE = process.env.SMTP_HOST === 'teste-em-memoria' && process.env.NODE_ENV !== 'production';
const enviados = []; // só usado nos testes

/* v4.9.34: a Render no plano grátis bloqueia as portas de e-mail (25, 465 e 587) desde setembro de 2025.
   Por isso o caminho principal é a API do Brevo, que vai pela porta comum da internet (443).
   Com BREVO_API_KEY e EMAIL_DE preenchidos, o e-mail sai pelo Brevo; senão tenta o SMTP antigo. */
const usaBrevo = () => !!(process.env.BREVO_API_KEY && process.env.EMAIL_DE);
const BREVO = () => (process.env.BREVO_API_BASE || 'https://api.brevo.com').replace(/\/$/, '');
function ativo() {
  return TESTE || usaBrevo() || !!(process.env.SMTP_HOST && process.env.SMTP_USER && process.env.SMTP_PASS && process.env.EMAIL_DE);
}
function resetar() { transporte = null; }
async function enviarBrevo({ para, assunto, texto, anexos }) {
  const corpo = {
    sender: { email: process.env.EMAIL_DE, name: process.env.EMAIL_NOME || 'Clínica de Visão' },
    to: String(para).split(/[,;]\s*/).filter(Boolean).map((email) => ({ email })),
    subject: assunto, textContent: texto,
  };
  if (anexos && anexos.length) corpo.attachment = anexos.map((a) => ({ name: a.filename, content: Buffer.from(a.content).toString('base64') }));
  const r = await fetch(BREVO() + '/v3/smtp/email', { method: 'POST', headers: { 'api-key': process.env.BREVO_API_KEY, 'content-type': 'application/json', accept: 'application/json' }, body: JSON.stringify(corpo), signal: AbortSignal.timeout(30000) });
  if (!r.ok) { const t = await r.text().catch(() => ''); throw new Error(`Brevo respondeu ${r.status}: ${t.slice(0, 200)}`); }
}
/* confere a chave e o remetente antes de salvar: devolve o motivo em português quando algo está errado */
async function conferirBrevo(chave, remetente) {
  const h = { 'api-key': chave, accept: 'application/json' };
  let r;
  try { r = await fetch(BREVO() + '/v3/account', { headers: h, signal: AbortSignal.timeout(15000) }); }
  catch (e) { return { ok: false, motivo: 'Não consegui falar com o Brevo agora. Tente de novo em alguns minutos.' }; }
  if (r.status === 401) return { ok: false, motivo: 'O Brevo não aceitou essa chave. Copie de novo a chave da API (começa com xkeysib-).' };
  if (!r.ok) return { ok: false, motivo: `O Brevo respondeu com erro ${r.status}.` };
  try {
    const s = await fetch(BREVO() + '/v3/senders', { headers: h, signal: AbortSignal.timeout(15000) });
    if (s.ok) {
      const lista = ((await s.json()).senders || []);
      const achou = lista.find((x) => String(x.email).toLowerCase() === String(remetente).toLowerCase());
      if (!achou) return { ok: false, motivo: `O e-mail ${remetente} não está cadastrado como remetente no Brevo. No Brevo, abra Remetentes e adicione esse e-mail.` };
      if (achou.active === false) return { ok: false, motivo: `O remetente ${remetente} ainda não foi confirmado no Brevo. Abra o e-mail de confirmação que o Brevo mandou.` };
    }
  } catch (e) { /* sem lista de remetentes: segue, o envio de teste confirma */ }
  return { ok: true };
}
function pegar() {
  if (transporte) return transporte;
  transporte = TESTE
    ? nodemailer.createTransport({ jsonTransport: true })
    : nodemailer.createTransport({
        host: process.env.SMTP_HOST,
        port: parseInt(process.env.SMTP_PORT, 10) || 587,
        secure: parseInt(process.env.SMTP_PORT, 10) === 465,
        auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS },
      });
  return transporte;
}
async function enviar({ para, assunto, texto, anexos }) {
  if (!ativo()) return { ok: false, motivo: 'nao_configurado' };
  try {
    if (!TESTE && usaBrevo()) { await enviarBrevo({ para, assunto, texto, anexos }); return { ok: true }; }
    const msg = { from: process.env.EMAIL_DE || 'teste@clinica.local', to: para, subject: assunto, text: texto, attachments: anexos };
    await pegar().sendMail(msg);
    if (TESTE) enviados.push({ para, assunto, texto, anexos: (anexos || []).map((a) => a.filename) });
    return { ok: true };
  } catch (e) {
    console.error('Falha ao enviar e-mail:', e.message);
    return { ok: false, motivo: 'falha' };
  }
}
module.exports = { ativo, enviar, enviados, resetar, conferirBrevo, usaBrevo };
