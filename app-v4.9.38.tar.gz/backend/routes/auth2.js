/* Recuperar senha por e-mail e código de 6 números do celular (segundo passo) */
const express = require('express');
const crypto = require('crypto');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const pool = require('../db/pool');
const email = require('../utils/email');
const totp = require('../utils/totp');
const cripto = require('../utils/cripto');
const { validarSenha } = require('../utils/senha');
const { SEGREDO, exigirLogin, exigirAdmin, limparCacheUsuario } = require('../middleware/auth');
const auth = require('./auth');

const router = express.Router();

/* limite simples por rede: n tentativas por janela */
const limites = new Map();
function limitar(chave, max, janelaMs) {
  const agora = Date.now(), t = limites.get(chave);
  if (!t || agora - t.inicio > janelaMs) { limites.set(chave, { inicio: agora, n: 1 }); return false; }
  t.n += 1;
  return t.n > max;
}
setInterval(() => { const a = Date.now(); for (const [k, t] of limites) if (a - t.inicio > 3600000) limites.delete(k); }, 600000).unref();

const hashToken = (t) => crypto.createHash('sha256').update(t).digest('hex');
const pergunta = (req) => process.env.URL_PUBLICA || `${req.headers['x-forwarded-proto'] || req.protocol}://${req.get('host')}`;

/* ---------- recuperar senha ---------- */
router.get('/recuperacao-ativa', (req, res) => res.json({ ativa: email.ativo() }));

router.post('/esqueci', async (req, res) => {
  const resposta = { ok: true, mensagem: 'Se esse e-mail estiver cadastrado, você vai receber um link em alguns minutos.' };
  const em = String(req.body.email || '').toLowerCase().trim();
  if (!em) return res.status(400).json({ erro: 'Informe o e-mail.' });
  if (em.length > 254) return res.status(400).json({ erro: 'E-mail inválido.' });
  if (limitar('esq|' + req.ip, 10, 3600000) || limitar('esq|' + em, 3, 3600000)) return res.status(429).json({ erro: 'Muitos pedidos. Espere uma hora e tente de novo.' });
  if (!email.ativo()) return res.status(503).json({ erro: 'O envio de e-mail ainda não foi ligado. Peça ao Master para trocar sua senha.' });
  const u = (await pool.query(`SELECT id, nome, email FROM usuarios WHERE email=$1 AND ativo=TRUE`, [em])).rows[0];
  if (u) {
    const token = crypto.randomBytes(32).toString('hex');
    await pool.query(`UPDATE redefinicoes_senha SET usado_em=NOW() WHERE usuario_id=$1 AND usado_em IS NULL`, [u.id]);
    await pool.query(`INSERT INTO redefinicoes_senha (usuario_id, token_hash, expira_em) VALUES ($1,$2, NOW() + INTERVAL '30 minutes')`, [u.id, hashToken(token)]);
    const link = `${pergunta(req)}/modulo-agendamento.html#reset=${token}`;
    await email.enviar({ para: u.email, assunto: 'Trocar sua senha', texto: `Olá, ${u.nome || ''}.\n\nPara escolher uma senha nova, abra este link em até 30 minutos:\n\n${link}\n\nSe você não pediu, ignore esta mensagem. Sua senha continua a mesma.` });
  }
  res.json(resposta);
});

router.post('/redefinir', async (req, res) => {
  if (limitar('red|' + req.ip, 20, 3600000)) return res.status(429).json({ erro: 'Muitas tentativas. Espere uma hora.' });
  const token = String(req.body.token || ''), senha = String(req.body.senha || '');
  const erroSenha = validarSenha(senha);
  if (erroSenha) return res.status(400).json({ erro: erroSenha });
  const r = (await pool.query(`SELECT id, usuario_id FROM redefinicoes_senha WHERE token_hash=$1 AND usado_em IS NULL AND expira_em > NOW()`, [hashToken(token)])).rows[0];
  if (!r) return res.status(400).json({ erro: 'Link vencido ou já usado. Peça um novo.' });
  const hash = await bcrypt.hash(senha, 10);
  await pool.query(`UPDATE usuarios SET senha_hash=$1, sessao_versao = sessao_versao + 1 WHERE id=$2`, [hash, r.usuario_id]);
  await pool.query(`UPDATE redefinicoes_senha SET usado_em=NOW() WHERE id=$1`, [r.id]);
  await pool.query(`DELETE FROM login_tentativas WHERE chave LIKE '%|' || (SELECT email FROM usuarios WHERE id=$1)`, [r.usuario_id]).catch(() => {});
  limparCacheUsuario(r.usuario_id);
  res.json({ ok: true });
});

/* ---------- código de 6 números do celular ---------- */
router.get('/totp', exigirLogin, async (req, res) => {
  const u = (await pool.query(`SELECT totp_ativo FROM usuarios WHERE id=$1`, [req.usuario.usuarioId])).rows[0];
  res.json({ ativo: !!(u && u.totp_ativo) });
});

router.post('/totp/iniciar', exigirLogin, async (req, res) => {
  const u = (await pool.query(`SELECT email, totp_ativo FROM usuarios WHERE id=$1`, [req.usuario.usuarioId])).rows[0];
  if (u.totp_ativo) return res.status(409).json({ erro: 'O código do celular já está ativo.' });
  const segredo = totp.novoSegredo();
  await pool.query(`UPDATE usuarios SET totp_segredo=$1, totp_ultimo_passo=0 WHERE id=$2`, [cripto.cifrar(segredo), req.usuario.usuarioId]);
  res.json({ segredo, otpauth: totp.urlApp(segredo, u.email) });
});

router.post('/totp/confirmar', exigirLogin, async (req, res) => {
  if (limitar('tc|' + req.usuario.usuarioId, 10, 900000)) return res.status(429).json({ erro: 'Muitas tentativas. Espere alguns minutos.' });
  const u = (await pool.query(`SELECT totp_segredo FROM usuarios WHERE id=$1`, [req.usuario.usuarioId])).rows[0];
  if (!u || !u.totp_segredo) return res.status(400).json({ erro: 'Comece pelo botão Ativar.' });
  const passo = totp.conferir(cripto.decifrar(u.totp_segredo), req.body.codigo, 0);
  if (!passo) return res.status(400).json({ erro: 'Código errado. Confira o número no aplicativo.' });
  await pool.query(`UPDATE usuarios SET totp_ativo=TRUE, totp_ultimo_passo=$1 WHERE id=$2`, [passo, req.usuario.usuarioId]);
  res.json({ ok: true });
});

router.delete('/totp', exigirLogin, async (req, res) => {
  const u = (await pool.query(`SELECT senha_hash FROM usuarios WHERE id=$1`, [req.usuario.usuarioId])).rows[0];
  if (!(await require('../utils/seguranca').senhaConfere(bcrypt, String(req.body.senha || ''), u.senha_hash))) return res.status(401).json({ erro: 'Senha errada.' });
  await pool.query(`UPDATE usuarios SET totp_ativo=FALSE, totp_segredo=NULL WHERE id=$1`, [req.usuario.usuarioId]);
  res.json({ ok: true });
});

/* o Master desliga o código de quem perdeu o celular */
router.delete('/totp/usuario/:uid', exigirLogin, exigirAdmin, async (req, res) => {
  const r = await pool.query(`UPDATE usuarios SET totp_ativo=FALSE, totp_segredo=NULL WHERE id=$1 AND clinica_id=$2 RETURNING id`, [req.params.uid, req.usuario.clinicaId]);
  if (!r.rows.length) return res.status(404).json({ erro: 'Usuário não encontrado.' });
  res.json({ ok: true });
});

/* segundo passo do login */
router.post('/totp/entrar', async (req, res) => {
  if (limitar('te|' + req.ip, 30, 900000)) return res.status(429).json({ erro: 'Muitas tentativas. Espere alguns minutos.' });
  let p;
  try { p = jwt.verify(String(req.body.pendente || ''), SEGREDO); } catch (e) { return res.status(401).json({ erro: 'Passo vencido. Entre de novo com a senha.' }); }
  if (p.fin !== 'totp') return res.status(401).json({ erro: 'Passo inválido.' });
  if (limitar('tu|' + p.uid, 8, 900000)) return res.status(429).json({ erro: 'Muitos códigos errados. Espere 15 minutos.' });
  const u = (await pool.query(`SELECT totp_segredo, totp_ultimo_passo FROM usuarios WHERE id=$1 AND ativo=TRUE AND totp_ativo=TRUE`, [p.uid])).rows[0];
  if (!u) return res.status(401).json({ erro: 'Acesso inválido.' });
  const passo = totp.conferir(cripto.decifrar(u.totp_segredo), req.body.codigo, Number(u.totp_ultimo_passo));
  if (!passo) return res.status(401).json({ erro: 'Código errado ou já usado. Espere o próximo número do aplicativo.' });
  await pool.query(`UPDATE usuarios SET totp_ultimo_passo=$1 WHERE id=$2`, [passo, p.uid]);
  res.json(await auth.respostaDeEntrada(p.uid, req));
});

/* só nos testes automáticos (nunca em produção): lê os e-mails "enviados" na memória */
if (process.env.SMTP_HOST === 'teste-em-memoria' && process.env.NODE_ENV !== 'production') {
  router.get('/_teste/emails', (req, res) => res.json(email.enviados));
}

module.exports = router;
