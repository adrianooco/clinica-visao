@echo off
title Criar atalho da Clinica de Visao
cd /d "%~dp0"
echo Criando o atalho na area de trabalho...
powershell -NoProfile -ExecutionPolicy Bypass -Command "$d=[Environment]::GetFolderPath('Desktop'); $s=(New-Object -ComObject WScript.Shell).CreateShortcut($d+'\Clinica de Visao.lnk'); $s.TargetPath='%~dp0iniciar-clinica.bat'; $s.WorkingDirectory='%~dp0'; $s.IconLocation='%~dp0clinica.ico'; $s.WindowStyle=7; $s.Description='Abre a Clinica de Visao'; $s.Save()"
if errorlevel 1 (
  echo.
  echo Nao consegui criar o atalho.
  pause
  exit /b 1
)
echo.
echo Pronto. O icone "Clinica de Visao" esta na sua area de trabalho.
echo Para abrir o sistema, de dois cliques nele.
echo.
pause
