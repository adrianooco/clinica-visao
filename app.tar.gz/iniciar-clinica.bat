@echo off
title Clinica de Visao
cd /d "%~dp0"
set "PSQL=C:\Program Files\PostgreSQL\17\bin\psql.exe"
set "PGCLIENTENCODING=UTF8"

where node >nul 2>nul
if errorlevel 1 (
  echo O Node.js nao foi encontrado. Instale o Node.js e tente de novo.
  pause
  exit /b 1
)

if exist "backend\.env" goto ligar

echo ============================================
echo  Primeira vez: vamos preparar o sistema.
echo ============================================
if not exist "%PSQL%" (
  echo O PostgreSQL 17 nao foi encontrado em C:\Program Files\PostgreSQL\17
  pause
  exit /b 1
)
echo.
set /p SENHA=Digite a senha do PostgreSQL que voce anotou e aperte Enter: 
set "PGPASSWORD=%SENHA%"

"%PSQL%" -U postgres -h localhost -c "SELECT 1" >nul 2>nul
if errorlevel 1 (
  echo.
  echo Nao consegui entrar no PostgreSQL. A senha esta errada ou o servico esta parado.
  pause
  exit /b 1
)

"%PSQL%" -U postgres -h localhost -d clinica -c "SELECT 1" >nul 2>nul
if not errorlevel 1 goto banco_pronto

echo Criando o banco de dados...
"%PSQL%" -U postgres -h localhost -c "CREATE DATABASE clinica"
if errorlevel 1 (
  echo Erro ao criar o banco.
  pause
  exit /b 1
)

echo Criando as tabelas...
"%PSQL%" -U postgres -h localhost -d clinica -v ON_ERROR_STOP=1 -q -f "schema-agendamento.sql"
if errorlevel 1 (
  echo Erro ao criar as tabelas.
  pause
  exit /b 1
)
goto banco_criado

:banco_pronto
echo O banco de dados ja existe. Seus dados foram mantidos.

:banco_criado
for /f %%i in ('powershell -NoProfile -Command "[guid]::NewGuid().ToString('N')+[guid]::NewGuid().ToString('N')"') do set JWT=%%i
(
  echo DATABASE_URL=postgres://postgres:%SENHA%@localhost:5432/clinica
  echo PGSSL=false
  echo JWT_SECRET=%JWT%
  echo PORT=3000
) > "backend\.env"

echo Instalando os componentes do sistema, aguarde...
pushd backend
call npm install
if errorlevel 1 (
  popd
  del "backend\.env" >nul 2>nul
  echo Erro ao instalar os componentes. Veja se o computador esta com internet.
  pause
  exit /b 1
)
popd

:ligar
netstat -ano | findstr /R /C:":3000 .*LISTENING" >nul
if not errorlevel 1 (start "" "%~dp0modulo-agendamento.html" & exit /b 0)
echo.
echo ============================================
echo  Sistema ligado. NAO FECHE ESTA JANELA.
echo  Para desligar, feche esta janela.
echo ============================================
start "" "%~dp0modulo-agendamento.html"
cd backend
node server.js
pause
