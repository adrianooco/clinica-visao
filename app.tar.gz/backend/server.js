require('dotenv').config();
const express = require('express');
const cors = require('cors');
const path = require('path');

// no ar, sem segredo próprio qualquer pessoa conseguiria forjar um login: não deixa ligar
if (process.env.NODE_ENV === 'production' && !process.env.JWT_SECRET) {
  console.error('ERRO: defina a variável JWT_SECRET antes de ligar o sistema no ar.');
  process.exit(1);
}

const app = express();
app.set('trust proxy', 1); // atrás do Render/Railway, pra enxergar o IP real de quem acessa
app.disable('x-powered-by');
app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'same-origin');
  next();
});
app.use(cors());
app.use(express.json({ limit: '8mb' })); // fotos em base64 podem ser grandes

app.get('/health', (req, res) => res.json({ ok: true }));

/* Páginas do sistema: o próprio servidor entrega, então quem abre o endereço já cai na tela de login.
   Só estes arquivos são públicos (nunca a pasta inteira, pra não expor o .env). */
const RAIZ = path.join(__dirname, '..');
const PAGINAS = ['modulo-agendamento.html', 'cadastro-paciente.html', 'teste-visao.html', 'optotipo.js', 'qrcode.js', 'clinica.ico'];
app.get('/', (req, res) => res.redirect('/modulo-agendamento.html'));
PAGINAS.forEach((f) => app.get('/' + f, (req, res, next) => {
  res.setHeader('Cache-Control', 'no-cache');
  res.sendFile(path.join(RAIZ, f), (err) => err && next());
}));

app.use('/auth', require('./routes/auth'));
app.use('/public', require('./routes/public'));
app.use('/integracao/:slug', require('./routes/integracao'));
app.use('/pacientes', require('./routes/pacientes'));
app.use('/agendamentos', require('./routes/agendamentos'));
app.use('/agendas', require('./routes/agendas'));
app.use('/envios', require('./routes/envios'));
app.use('/cadastros', require('./routes/cadastros'));
app.use('/financeiro', require('./routes/financeiro'));
app.use('/tipos-atendimento', require('./routes/tiposAtendimento'));
app.use('/unidades', require('./routes/unidades'));
app.use('/receitas', require('./routes/receitas'));
app.use('/prontuarios', require('./routes/prontuarios'));
app.use('/testes-visao', require('./routes/testesVisao'));
app.use('/clinica', require('./routes/clinica'));
app.use('/relatorios', require('./routes/relatorios'));
app.use('/optotipo', require('./routes/optotipo'));

app.use((req, res) => res.status(404).json({ erro: 'Rota não encontrada.' }));
app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ erro: 'Erro interno do servidor.' });
});

// um erro numa rota não pode derrubar o sistema inteiro
process.on('unhandledRejection', (e) => console.error('Erro não tratado:', e));

const PORTA = process.env.PORT || 3000;
require('./db/migrar')()
  .catch((e) => console.error('Aviso: não consegui ajustar o banco automaticamente.', e.message))
  .finally(() => app.listen(PORTA, () => console.log(`API da agenda rodando na porta ${PORTA}`)));
