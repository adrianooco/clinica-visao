/* Regra de senha: no mínimo 10 caracteres, com letra e número. Vale para senhas novas. */
function validarSenha(s) {
  const t = String(s || '');
  if (t.length < 10) return 'A senha precisa ter pelo menos 10 caracteres.';
  if (!/[A-Za-z]/.test(t) || !/[0-9]/.test(t)) return 'A senha precisa ter letras e números.';
  return null;
}
module.exports = { validarSenha };
