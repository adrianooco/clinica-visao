/* Campos da ficha do paciente. A clínica escolhe, para cada um: oculto, opcional ou obrigatorio.
   Guardado em clinicas.campos_obrigatorios (JSON). Valores antigos true/false continuam valendo. */
const CAMPOS = [
  ['telefone', 'Telefone / WhatsApp', 'opcional'],
  ['cpf', 'CPF', 'obrigatorio'],
  ['data_nascimento', 'Data de nascimento', 'opcional'],
  ['email', 'E-mail', 'oculto'],
  ['sexo', 'Sexo', 'oculto'],
  ['profissao', 'Profissão', 'oculto'],
  ['cep', 'CEP', 'obrigatorio'],
  ['endereco', 'Endereço (rua e número)', 'opcional'],
  ['bairro', 'Bairro', 'opcional'],
  ['usa_oculos', 'Já usa óculos ou lentes', 'oculto'],
  ['queixa', 'O que incomoda na visão', 'oculto'],
  ['ultimo_exame', 'Quando fez o último exame de vista', 'oculto'],
  ['doencas', 'Doenças (diabetes, pressão alta e outras)', 'oculto'],
  ['alergias', 'Alergias', 'oculto'],
  ['medicamentos', 'Remédios que usa', 'oculto'],
  ['cirurgia_ocular', 'Cirurgia nos olhos', 'oculto'],
  ['historico_familiar', 'Casos na família (glaucoma, catarata)', 'oculto'],
  ['indicacao', 'Como conheceu a clínica', 'oculto'],
  ['observacoes', 'Observações', 'oculto'],
  ['foto_receita', 'Foto da última receita', 'opcional'],
  ['foto_armacao', 'Foto da armação desejada', 'opcional'],
];
const ESTADOS = ['oculto', 'opcional', 'obrigatorio'];
/* campos que ficam em dados_extras (os outros têm coluna própria) */
const EXTRAS = ['email', 'sexo', 'profissao', 'usa_oculos', 'queixa', 'ultimo_exame', 'doencas', 'alergias', 'medicamentos', 'cirurgia_ocular', 'historico_familiar', 'indicacao', 'observacoes', 'receita_status', 'receita_digitada'];

function estadoDe(cfg, chave) {
  const padrao = (CAMPOS.find(c => c[0] === chave) || [])[2] || 'opcional';
  const v = (cfg || {})[chave];
  if (v === true) return 'obrigatorio';
  if (v === false) return 'opcional';
  return ESTADOS.includes(v) ? v : padrao;
}
function estadosResolvidos(cfg) {
  const o = {};
  CAMPOS.forEach(([k]) => { o[k] = estadoDe(cfg, k); });
  return o;
}
function limparConfig(cfg) {
  const o = {};
  CAMPOS.forEach(([k]) => {
    const v = (cfg || {})[k];
    if (ESTADOS.includes(v)) o[k] = v;
    else if (v === true) o[k] = 'obrigatorio';
    else if (v === false) o[k] = 'opcional';
  });
  return o;
}
function limparExtras(obj) {
  const o = {};
  EXTRAS.forEach(k => {
    const v = obj && obj[k];
    if (v !== undefined && v !== null && String(v).trim() !== '') o[k] = String(v).trim().slice(0, 600);
  });
  return o;
}
module.exports = { CAMPOS, EXTRAS, estadoDe, estadosResolvidos, limparConfig, limparExtras };
