/* WhatsApp automático pela API oficial da Meta (WhatsApp Cloud API).
   Variáveis no servidor:
     WA_TOKEN         token permanente do app na Meta
     WA_PHONE_ID      identificação do número no painel da Meta
     WA_VERIFY_TOKEN  senha que você inventa e digita também no painel, para ligar o webhook
     WA_APP_SECRET    segredo do app (confere que as respostas vêm mesmo da Meta)
     WA_TEMPLATE      nome do modelo de mensagem aprovado (com uma variável {{1}}); sem ele só sai texto livre
     WA_TEMPLATE_LANG idioma do modelo (padrão pt_BR)
   Sem essas variáveis o sistema continua funcionando: a equipe toca em "WhatsApp" e a conversa abre com o texto pronto. */
const VERSAO = 'v21.0';

function configurado() { return !!(process.env.WA_TOKEN && process.env.WA_PHONE_ID); }

/* deixa o número no formato da Meta: 55 + DDD + número */
function normalizar(tel) {
  let d = String(tel || '').replace(/\D/g, '');
  if (d.length === 10 || d.length === 11) d = '55' + d;
  if (d.length < 12 || d.length > 13 || !d.startsWith('55')) return null;
  return d;
}

async function chamar(corpo) {
  const r = await fetch(`${process.env.WA_API_BASE || 'https://graph.facebook.com'}/${VERSAO}/${process.env.WA_PHONE_ID}/messages`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${process.env.WA_TOKEN}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({ messaging_product: 'whatsapp', ...corpo }),
    signal: AbortSignal.timeout(15000),
  });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) {
    const e = new Error(j.error?.message || `Erro ${r.status} no WhatsApp`);
    e.codigo = j.error?.code;
    throw e;
  }
  return j;
}

/* Mensagem que a clínica começa (lembretes): a Meta só aceita por modelo aprovado, fora da janela de 24 h. */
async function enviarIniciada(telefone, texto) {
  const to = normalizar(telefone);
  if (!to) throw new Error('Telefone inválido para WhatsApp.');
  if (process.env.WA_TEMPLATE) {
    const valor = String(texto).replace(/[\r\n\t]+/g, ' ').replace(/ {2,}/g, ' ').slice(0, 900);
    return chamar({
      to, type: 'template',
      template: { name: process.env.WA_TEMPLATE, language: { code: process.env.WA_TEMPLATE_LANG || 'pt_BR' },
        components: [{ type: 'body', parameters: [{ type: 'text', text: valor }] }] },
    });
  }
  return chamar({ to, type: 'text', text: { body: String(texto).slice(0, 3500), preview_url: false } });
}

/* Resposta a quem acabou de escrever (dentro de 24 h): texto livre. */
async function responder(telefone, texto) {
  const to = normalizar(telefone);
  if (!to) return;
  return chamar({ to, type: 'text', text: { body: String(texto).slice(0, 3500) } });
}

module.exports = { configurado, normalizar, enviarIniciada, responder };
