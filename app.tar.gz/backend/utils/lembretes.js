/* Envia sozinho os lembretes que estão na hora (confirmação, 24 h, 2 h e pós atendimento).
   Roda a cada 5 minutos, só nas clínicas com "WhatsApp automático" ligado, e só entre 8h e 20h (horário de Brasília). */
const pool = require('../db/pool');
const wpp = require('./whatsapp');

function horaBrasilia() {
  return Number(new Intl.DateTimeFormat('en-GB', { hour: '2-digit', hour12: false, timeZone: 'America/Sao_Paulo' }).format(new Date()));
}

let rodando = false;
async function ciclo(ignorarHorario) {
  if (rodando || !wpp.configurado()) return;
  const h = horaBrasilia();
  if (ignorarHorario !== true && (h < 8 || h >= 20)) return;
  rodando = true;
  try {
    const { listarEnvios, ETAPAS } = require('../routes/envios');
    const clinicas = await pool.query(`SELECT id FROM clinicas WHERE ativa=TRUE AND whatsapp_auto=TRUE`);
    for (const c of clinicas.rows) {
      const { agora } = await listarEnvios(c.id, null);
      let enviados = 0;
      for (const item of agora) {
        if (enviados >= 25) break; // limite por rodada, para não passar de ritmo
        const cfg = ETAPAS[item.etapa];
        if (!wpp.normalizar(item.telefone)) continue;
        // reserva a mensagem antes de enviar: dois ciclos nunca mandam a mesma
        const reservado = await pool.query(
          `UPDATE agendamentos SET ${cfg.coluna}=TRUE WHERE id=$1 AND clinica_id=$2 AND ${cfg.coluna} IS NOT TRUE RETURNING id`,
          [item.agendamento_id, c.id]);
        if (!reservado.rows.length) continue;
        try {
          await wpp.enviarIniciada(item.telefone, item.mensagem);
          enviados++;
        } catch (e) {
          await pool.query(`UPDATE agendamentos SET ${cfg.coluna}=FALSE, whatsapp_ultimo_erro=$2 WHERE id=$1`,
            [item.agendamento_id, String(e.message).slice(0, 190)]);
          console.error('WhatsApp automático falhou:', e.message);
        }
      }
    }
  } catch (e) {
    console.error('Ciclo de lembretes falhou:', e.message);
  } finally {
    rodando = false;
  }
}

function iniciar() {
  if (!wpp.configurado()) { console.log('WhatsApp automático desligado (faltam WA_TOKEN e WA_PHONE_ID).'); return; }
  setInterval(() => ciclo(), 5 * 60 * 1000).unref();
  setTimeout(() => ciclo(), 30 * 1000).unref();
  console.log('WhatsApp automático ligado.');
}

module.exports = { iniciar, ciclo };
