# Backend da Agenda de Exame de Vista

API Node.js + Express + PostgreSQL que substitui o localStorage usado antes
em modulo-agendamento.html, cadastro-paciente.html e teste-visao.html.

Tudo aqui já foi testado de ponta a ponta: schema rodado num Postgres real,
API testada por curl e os três arquivos HTML testados num navegador de
verdade contra essa API, incluindo o bloqueio de horário conflitante.

## 1. Banco de dados

Use qualquer Postgres gerenciado (Neon, Supabase, Railway, Render têm plano
gratuito). Depois de criar o banco, rode uma vez o arquivo `schema-agendamento.sql`
que está na pasta principal, por exemplo:

    psql "SUA_CONNECTION_STRING" -f schema-agendamento.sql

## 2. Variáveis de ambiente

Crie um arquivo `.env` nesta pasta (backend/) com:

    DATABASE_URL=postgres://usuario:senha@host:5432/banco
    JWT_SECRET=troque-isto-por-um-texto-aleatorio-longo
    PORT=3000

Em produção, PGSSL não precisa ser definido (o padrão já usa SSL).

## 3. Rodar localmente pra testar

    npm install
    npm start

Teste com: `curl http://localhost:3000/health` — deve responder `{"ok":true}`.

## 4. Hospedar de verdade (sugestão: Railway ou Render)

Ambos têm plano gratuito/baixo custo, suportam Node.js direto e têm Postgres
integrado:

1. Crie uma conta e um novo projeto.
2. Aponte para este diretório `backend/` (ou suba ele para um repositório
   GitHub e conecte o repositório).
3. Configure as variáveis de ambiente do passo 2 no painel do serviço.
4. O serviço vai te dar uma URL pública, tipo `https://sua-api.up.railway.app`.

## 5. Ligar os arquivos HTML a essa URL

Os arquivos públicos (cadastro-paciente.html e modulo-agendamento.html)
hoje perguntam o endereço da API:

- No modulo-agendamento.html, o campo "Endereço do servidor (API)" na tela
  de login. Depois do primeiro login, ele fica salvo no navegador.
- No cadastro-paciente.html, o endereço vem pela própria URL (`?api=...&c=...`,
  e `&u=...` quando for o link de uma cidade específica). O link certo, com
  tudo preenchido, é gerado automaticamente pelo botão "Copiar link do
  paciente", na aba Pacientes do modulo-agendamento.html, ou pelo botão
  "Copiar link" de cada cidade na aba Master — por isso o primeiro login deve
  ser feito antes de distribuir esses links.
- teste-visao.html virou um redirecionamento pro cadastro-paciente.html,
  que agora inclui o teste de visão como primeira etapa de um assistente
  único (calibrar, testar, ver o resultado, cadastrar). Esse arquivo continua
  existindo só pra links antigos, já copiados ou impressos antes dessa
  mudança, não pararem de funcionar.

## 6. Hospedar os três arquivos HTML

Eles são estáticos, então GitHub Pages serve bem e é gratuito: suba os três
arquivos num repositório e ative o Pages nas configurações dele. Depois,
preencha "Link público do site" na aba Master do modulo-agendamento.html
com esse endereço, pra o QR code e o WhatsApp do teste de visão usarem o
link certo.

## O que a API cobre

- `/auth/setup` e `/auth/login`: criação da clínica e login individual por
  usuário (sem mais senha única compartilhada).
- `/pacientes`, `/agendamentos`, `/tipos-atendimento`, `/receitas`,
  `/testes-visao`, `/clinica`: rotas autenticadas, isoladas por clínica.
- `/public/:slug/...`: rotas sem login, usadas pelas páginas públicas. Aceitam
  `?u=slug-da-cidade` pra vincular o cadastro/teste a uma cidade específica.
- `/unidades`: cidades/eventos itinerantes. Um usuário pode ficar restrito a
  uma única cidade (só vê e cadastra pacientes/agendamentos daquela cidade) ou
  sem restrição (vê a clínica toda, uso pra quem acompanha várias cidades).
  Configurável na aba Master do modulo-agendamento.html, em "Cidades / eventos".
- O bloqueio de horário sobreposto (duração + intervalo) é garantido pelo
  próprio banco, não só pelo JavaScript — mesmo dois atendentes salvando ao
  mesmo tempo em aparelhos diferentes não conseguem conflitar. Esse bloqueio
  respeita cada cidade separadamente: duas cidades podem ter agendamento no
  mesmo horário sem problema, só a mesma cidade é protegida contra conflito.
- `/prontuarios`: prontuário clínico (queixa, observações, conduta). Só
  usuários com papel `profissional` ou `admin` acessam, atendente comum recebe
  403 mesmo tentando direto pela API.
- `/clinica/chave-integracao`: só admin. Devolve a chave usada por um
  assistente externo (ex: um bot de WhatsApp) pra se identificar.
- `/integracao/:slug/disponibilidade` e `/integracao/:slug/agendamentos`: pra
  um assistente externo consultar horário livre e marcar sozinho, sem precisar
  de login de funcionário. Em vez de token de usuário, usam a chave de
  integração da clínica no cabeçalho `x-chave-integracao`. Pensado pra ligar
  um assistente de WhatsApp (com alguma IA de function-calling por trás,
  contratada à parte) que converse com o cliente e chame essas duas rotas.
  O horário de funcionamento considerado é o cadastrado em cada cidade (ou,
  se não houver cidade, o da clínica), em Master > Dados da clínica.
- `/integracao/:slug/tipos-atendimento`: lista os exames que a clínica oferece
  (id, nome, duração), pra um assistente externo saber o que oferecer e qual
  id usar nas outras chamadas.
- `/integracao/:slug/lembretes-pendentes?etapa=confirmacao|24h|2h`: devolve os
  agendamentos que precisam de lembrete automático por WhatsApp agora, com
  nome e telefone do paciente prontos pra montar a mensagem. Pensado pra ser
  chamado periodicamente (ex: Cron a cada 15-30 min no n8n), um disparo por
  etapa. Depois de enviar a mensagem de verdade, chame
  `POST /integracao/:slug/lembretes-pendentes/:agendamento_id/marcar-enviado`
  com `{"etapa":"confirmacao"}` (ou "24h"/"2h"/"pos_consulta") pra esse
  agendamento parar de aparecer na consulta daquela etapa — sem isso, o mesmo
  lembrete seria reenviado a cada rodada do agendador. As quatro etapas são
  independentes entre si: marcar uma como enviada não afeta as outras.
  "pos_consulta" dispara de 2 a 6 horas depois do horário marcado.
- `PUT /integracao/:slug/agendamentos/:id/status` com `{"status":"confirmado"}`
  ou `{"status":"cancelado"}`: pra n8n chamar depois de interpretar a resposta
  do paciente no WhatsApp ("sim"/"não"), sem precisar de um atendente mudar
  isso na mão. Só aceita essas duas opções por essa rota — "realizado" e
  "faltou" continuam sendo decisão de quem atende.
