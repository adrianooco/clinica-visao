const fs = require('fs');
const path = require('path');
const pool = require('./pool');

/* Banco novo e vazio (caso de quem coloca o sistema online): cria as tabelas sozinho. */
async function criarTabelasSeFaltar() {
  const r = await pool.query(`SELECT to_regclass('public.clinicas') AS t`);
  if (r.rows[0].t) return;
  const candidatos = [path.join(__dirname, 'schema-agendamento.sql'), path.join(__dirname, '..', '..', 'schema-agendamento.sql')];
  const arq = candidatos.find((c) => fs.existsSync(c));
  if (!arq) throw new Error('Arquivo schema-agendamento.sql não encontrado para criar o banco.');
  console.log('Banco vazio: criando as tabelas...');
  await pool.query(fs.readFileSync(arq, 'utf8'));
  console.log('Tabelas criadas.');
}

/* Ajustes pequenos de banco que rodam sempre que o servidor liga.
   Servem pra quem já tem o banco criado de uma versão anterior: cada comando
   só age se a coluna ainda não existir, então é seguro rodar várias vezes. */
async function migrar() {
  await criarTabelasSeFaltar();
  await pool.query(`ALTER TABLE pacientes ADD COLUMN IF NOT EXISTS data_nascimento DATE`);
  await pool.query(`ALTER TABLE pacientes ADD COLUMN IF NOT EXISTS dados_extras JSONB DEFAULT '{}'::jsonb`);
  // agenda do evento: dia + faixa de horário em que o agendador pode marcar pacientes
  await pool.query(`CREATE TABLE IF NOT EXISTS agendas (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    clinica_id UUID NOT NULL REFERENCES clinicas(id) ON DELETE CASCADE,
    unidade_id UUID NOT NULL REFERENCES unidades(id) ON DELETE CASCADE,
    data DATE NOT NULL,
    hora_inicio TIME NOT NULL,
    hora_fim TIME NOT NULL,
    tipo_atendimento_id UUID NOT NULL REFERENCES tipos_atendimento(id),
    local VARCHAR(255),
    ativa BOOLEAN DEFAULT TRUE,
    criado_em TIMESTAMP DEFAULT NOW()
  )`);
  await pool.query(`CREATE INDEX IF NOT EXISTS idx_agendas_unidade_data ON agendas(unidade_id, data) WHERE ativa`);

  // o que cada agendador pode abrir (lista de chaves) e como imprimir os documentos
  await pool.query(`ALTER TABLE usuarios ADD COLUMN IF NOT EXISTS permissoes JSONB DEFAULT '[]'::jsonb`);
  await pool.query(`ALTER TABLE clinicas ADD COLUMN IF NOT EXISTS config_impressao JSONB DEFAULT '{}'::jsonb`);

  // cadastros de apoio
  await pool.query(`CREATE TABLE IF NOT EXISTS oticas_parceiras (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    clinica_id UUID NOT NULL REFERENCES clinicas(id) ON DELETE CASCADE,
    nome VARCHAR(150) NOT NULL, ativa BOOLEAN DEFAULT TRUE, criado_em TIMESTAMP DEFAULT NOW())`);
  await pool.query(`CREATE TABLE IF NOT EXISTS convenios (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    clinica_id UUID NOT NULL REFERENCES clinicas(id) ON DELETE CASCADE,
    nome VARCHAR(150) NOT NULL, ativo BOOLEAN DEFAULT TRUE, criado_em TIMESTAMP DEFAULT NOW())`);

  // de onde veio o agendamento e qual ótica parceira indicou
  await pool.query(`ALTER TABLE agendamentos ADD COLUMN IF NOT EXISTS origem VARCHAR(20) DEFAULT 'equipe'`);
  await pool.query(`ALTER TABLE agendamentos ADD COLUMN IF NOT EXISTS otica_parceira_id UUID REFERENCES oticas_parceiras(id) ON DELETE SET NULL`);

  // preço padrão de cada tipo de atendimento (já vem preenchido na cobrança)
  await pool.query(`ALTER TABLE tipos_atendimento ADD COLUMN IF NOT EXISTS preco_padrao NUMERIC(10,2)`);

  // financeiro
  await pool.query(`CREATE TABLE IF NOT EXISTS pagamentos (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    clinica_id UUID NOT NULL REFERENCES clinicas(id) ON DELETE CASCADE,
    agendamento_id UUID NOT NULL UNIQUE REFERENCES agendamentos(id) ON DELETE CASCADE,
    valor NUMERIC(10,2) NOT NULL CHECK (valor >= 0),
    forma VARCHAR(20),
    convenio_id UUID REFERENCES convenios(id) ON DELETE SET NULL,
    status VARCHAR(10) NOT NULL DEFAULT 'pendente' CHECK (status IN ('pendente','pago')),
    pago_em DATE,
    criado_em TIMESTAMP DEFAULT NOW())`);
  await pool.query(`CREATE TABLE IF NOT EXISTS contas_pagar (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    clinica_id UUID NOT NULL REFERENCES clinicas(id) ON DELETE CASCADE,
    descricao VARCHAR(200) NOT NULL,
    valor NUMERIC(10,2) NOT NULL CHECK (valor >= 0),
    vencimento DATE NOT NULL,
    pago BOOLEAN DEFAULT FALSE,
    pago_em DATE,
    criado_em TIMESTAMP DEFAULT NOW())`);

  // registro de quem abriu ou alterou dado de saúde (LGPD)
  await pool.query(`CREATE TABLE IF NOT EXISTS acessos_log (
    id BIGSERIAL PRIMARY KEY,
    clinica_id UUID NOT NULL REFERENCES clinicas(id) ON DELETE CASCADE,
    usuario_id UUID, usuario_nome VARCHAR(150),
    acao VARCHAR(10), area VARCHAR(30), caminho VARCHAR(200), ip VARCHAR(60),
    criado_em TIMESTAMP DEFAULT NOW())`);
  await pool.query(`CREATE INDEX IF NOT EXISTS idx_acessos_log ON acessos_log(clinica_id, criado_em DESC)`);

  // WhatsApp automático e número da clínica
  await pool.query(`ALTER TABLE clinicas ADD COLUMN IF NOT EXISTS whatsapp_numero VARCHAR(20)`);
  await pool.query(`ALTER TABLE clinicas ADD COLUMN IF NOT EXISTS whatsapp_auto BOOLEAN DEFAULT FALSE`);
  await pool.query(`ALTER TABLE agendamentos ADD COLUMN IF NOT EXISTS whatsapp_ultimo_erro VARCHAR(200)`);
}

module.exports = migrar;
