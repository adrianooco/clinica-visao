-- Schema revisado: agenda de exame de vista multi-clínica
-- Requer as extensões abaixo para o EXCLUDE constraint de sobreposição de horário.
CREATE EXTENSION IF NOT EXISTS "pgcrypto";
CREATE EXTENSION IF NOT EXISTS "btree_gist";

-- =========================================================
-- 1. CLÍNICAS (tenants)
-- =========================================================
CREATE TABLE clinicas (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    slug VARCHAR(60) UNIQUE NOT NULL,         -- identificador público, usado nas URLs de cadastro-paciente.html e teste-visao.html
    nome_fantasia VARCHAR(255) NOT NULL,
    cnpj VARCHAR(18) UNIQUE,                 -- nullable: profissional autônomo pode não ter CNPJ
    endereco VARCHAR(255),
    local_exame_padrao VARCHAR(255),
    telefone VARCHAR(20),
    link_site VARCHAR(255),                  -- URL pública (QR code, WhatsApp, autoagendamento)
    logo_url TEXT DEFAULT 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDYwIiBoZWlnaHQ9IjE1MCIgdmlld0JveD0iMCAwIDQ2MCAxNTAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+CiAgPHRpdGxlPkNsw61uaWNhIGRlIFZpc8OjbyAtIG9ww6fDo28gMTwvdGl0bGU+CiAgPCEtLSBvbGhvIGVtIGFtw6puZG9hLCBjb25zdHJ1w61kbyBjb20gZG9pcyBhcmNvcyAtLT4KICA8cGF0aCBkPSJNMjAgNzAgUTcwIDI4IDEyMCA3MCBRNzAgMTEyIDIwIDcwIFoiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzEyM0E1QyIgc3Ryb2tlLXdpZHRoPSI1IiBzdHJva2UtbGluZWpvaW49InJvdW5kIi8+CiAgPGNpcmNsZSBjeD0iNzAiIGN5PSI3MCIgcj0iMTYiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzEyM0E1QyIgc3Ryb2tlLXdpZHRoPSI1Ii8+CiAgPGNpcmNsZSBjeD0iNzAiIGN5PSI3MCIgcj0iNiIgZmlsbD0iIzJFQTg5QSIvPgogIDx0ZXh0IHg9IjE0OCIgeT0iNjYiIGZvbnQtZmFtaWx5PSJBcmlhbCwgSGVsdmV0aWNhLCBzYW5zLXNlcmlmIiBmb250LXNpemU9IjMwIiBmb250LXdlaWdodD0iNzAwIiBmaWxsPSIjMTIzQTVDIiBsZXR0ZXItc3BhY2luZz0iMC41Ij5DTMONTklDQTwvdGV4dD4KICA8dGV4dCB4PSIxNDgiIHk9Ijk0IiBmb250LWZhbWlseT0iQXJpYWwsIEhlbHZldGljYSwgc2Fucy1zZXJpZiIgZm9udC1zaXplPSIyMiIgZm9udC13ZWlnaHQ9IjUwMCIgZmlsbD0iIzJFQTg5QSIgbGV0dGVyLXNwYWNpbmc9IjIiPkRFIFZJU8ODTzwvdGV4dD4KICA8dGV4dCB4PSIxNDgiIHk9IjExNiIgZm9udC1mYW1pbHk9IkFyaWFsLCBIZWx2ZXRpY2EsIHNhbnMtc2VyaWYiIGZvbnQtc2l6ZT0iMTIuNSIgZm9udC13ZWlnaHQ9IjQwMCIgZmlsbD0iIzZCNzY4MCI+Y3VpZGFkbyBlIHByZWNpc8OjbyBlbSBjYWRhIGV4YW1lPC90ZXh0Pgo8L3N2Zz4K', -- logomarca padrão da Clínica de Visão (sem vínculo com a Ótica Centro Oeste); troque pelo logo real em Master quando tiver
    campos_obrigatorios JSONB NOT NULL DEFAULT '{"cpf":true,"telefone":true,"cep":true}'::jsonb,
    -- horário padrão quando não há cidade/evento (unidade) específica, ex: clínica fixa
    horario_abertura TIME DEFAULT '08:00',
    horario_fechamento TIME DEFAULT '18:00',
    dias_funcionamento SMALLINT[] DEFAULT '{1,2,3,4,5}', -- 0=domingo...6=sábado
    -- chave usada pelo assistente de WhatsApp (ou outra integração externa) pra consultar
    -- horário livre e criar agendamento sem precisar de login de funcionário
    chave_integracao VARCHAR(64) UNIQUE DEFAULT encode(gen_random_bytes(24), 'hex'),
    ativa BOOLEAN DEFAULT TRUE,               -- inativar em vez de apagar ao cancelar contrato
    criado_em TIMESTAMP DEFAULT NOW(),
    atualizado_em TIMESTAMP DEFAULT NOW()
);
CREATE UNIQUE INDEX idx_clinicas_slug ON clinicas(slug);

-- =========================================================
-- 2. UNIDADES (cidades / eventos itinerantes)
-- Uma clínica que viaja por várias cidades cria uma unidade por cidade/evento.
-- Cada usuário pode ficar restrito a uma única unidade, e só enxerga pacientes
-- e agendamentos daquela cidade. unidade_id NULL em usuarios = enxerga todas
-- as cidades (admin itinerante); unidade_id NULL em pacientes/agendamentos =
-- registro compartilhado da clínica toda (compatibilidade com quem não usa
-- cidades separadas).
-- =========================================================
CREATE TABLE unidades (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    clinica_id UUID NOT NULL REFERENCES clinicas(id) ON DELETE CASCADE,
    slug VARCHAR(60) NOT NULL,            -- identificador público desta cidade/evento nos links
    nome VARCHAR(255) NOT NULL,           -- ex: "São Paulo - Novembro 2026"
    cidade VARCHAR(100),
    local VARCHAR(255),
    data_inicio DATE,
    data_fim DATE,
    horario_abertura TIME DEFAULT '08:00',   -- usado só pra calcular horários livres (ex: assistente de WhatsApp)
    horario_fechamento TIME DEFAULT '18:00',
    dias_funcionamento SMALLINT[] DEFAULT '{1,2,3,4,5}', -- 0=domingo...6=sábado; padrão seg a sex
    ativa BOOLEAN DEFAULT TRUE,
    criado_em TIMESTAMP DEFAULT NOW(),
    CONSTRAINT unique_slug_por_clinica UNIQUE (clinica_id, slug)
);

-- =========================================================
-- 3. USUÁRIOS (login individual, não senha única compartilhada)
-- =========================================================
CREATE TABLE usuarios (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    clinica_id UUID NOT NULL REFERENCES clinicas(id) ON DELETE CASCADE,
    unidade_id UUID REFERENCES unidades(id) ON DELETE SET NULL, -- NULL = vê todas as cidades
    nome VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    senha_hash VARCHAR(255) NOT NULL,
    papel VARCHAR(20) NOT NULL DEFAULT 'atendente'
        CHECK (papel IN ('admin','atendente','profissional')),
    -- dados do profissional que assina receita/atestado: só preenchidos quando papel='profissional'
    registro_conselho VARCHAR(50),            -- ex: CRO, CREFITO, dependendo da categoria do profissional
    carimbo_texto TEXT,                       -- texto do carimbo (nome, registro, especialidade), impresso na receita
    assinatura_url TEXT,                      -- imagem da assinatura digitalizada (base64 ou referência a storage)
    ativo BOOLEAN DEFAULT TRUE,
    criado_em TIMESTAMP DEFAULT NOW(),
    CONSTRAINT unique_email_por_clinica UNIQUE (clinica_id, email)
);

-- =========================================================
-- 3. TIPOS DE ATENDIMENTO (duração + intervalo, já implementado no front)
-- =========================================================
CREATE TABLE tipos_atendimento (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    clinica_id UUID NOT NULL REFERENCES clinicas(id) ON DELETE CASCADE,
    nome VARCHAR(100) NOT NULL,
    duracao_min INTEGER NOT NULL CHECK (duracao_min > 0),
    buffer_min INTEGER NOT NULL DEFAULT 0 CHECK (buffer_min >= 0),
    cor VARCHAR(7) DEFAULT '#1B5C5A',
    ativo BOOLEAN DEFAULT TRUE,
    criado_em TIMESTAMP DEFAULT NOW()
);

-- =========================================================
-- 4. PACIENTES (dados sensíveis — LGPD)
-- =========================================================
CREATE TABLE pacientes (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    clinica_id UUID NOT NULL REFERENCES clinicas(id) ON DELETE CASCADE,
    unidade_id UUID REFERENCES unidades(id) ON DELETE SET NULL, -- cidade/evento onde foi cadastrado; NULL = compartilhado entre cidades
    nome_completo VARCHAR(255) NOT NULL,
    cpf VARCHAR(14),                          -- opcional: obrigatoriedade é regra de clínica, não de schema
    telefone VARCHAR(20),                     -- idem
    cep VARCHAR(9),
    endereco VARCHAR(255),
    bairro VARCHAR(100),
    cidade VARCHAR(100),
    data_nascimento DATE,                     -- usada em aniversariantes e idade automática na receita
    agendado_por VARCHAR(255),                -- nome de quem cadastrou (autoagendamento, atendente, assistente)
    foto_receita_url TEXT,                    -- referência a objeto em storage, não base64 na linha
    foto_armacao_url TEXT,
    termo_lgpd_aceito_em TIMESTAMP,            -- quando o consentimento foi dado (não só um booleano)
    termo_lgpd_versao VARCHAR(20),             -- qual versão do termo foi aceita
    criado_em TIMESTAMP DEFAULT NOW(),
    atualizado_em TIMESTAMP DEFAULT NOW(),
    deletado_em TIMESTAMP,                    -- soft delete: nunca apagar prontuário fisicamente
    -- CPF único por clínica, mas só quando preenchido: por padrão o Postgres trata
    -- cada NULL como diferente dos demais, então vários pacientes sem CPF convivem bem.
    -- Importante: o aplicativo deve enviar NULL (nunca string vazia '') quando o CPF não for informado,
    -- senão strings vazias repetidas vão colidir normalmente.
    CONSTRAINT unique_cpf_por_clinica UNIQUE (clinica_id, cpf)
);
CREATE INDEX idx_pacientes_clinica ON pacientes(clinica_id) WHERE deletado_em IS NULL;

-- =========================================================
-- 5. AGENDAMENTOS
-- =========================================================
CREATE TABLE agendamentos (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    clinica_id UUID NOT NULL REFERENCES clinicas(id) ON DELETE CASCADE,
    unidade_id UUID REFERENCES unidades(id) ON DELETE SET NULL, -- cidade/evento deste agendamento
    paciente_id UUID NOT NULL REFERENCES pacientes(id) ON DELETE CASCADE,
    tipo_atendimento_id UUID REFERENCES tipos_atendimento(id),
    usuario_id UUID REFERENCES usuarios(id),  -- quem marcou, para auditoria
    data_hora TIMESTAMP NOT NULL,
    -- snapshot da duração/intervalo no momento do agendamento: se o tipo mudar depois,
    -- agendamentos antigos continuam corretos
    duracao_min INTEGER NOT NULL,
    buffer_min INTEGER NOT NULL DEFAULT 0,
    -- faixa de tempo ocupada (duração + intervalo), calculada automaticamente
    periodo_ocupado TSRANGE GENERATED ALWAYS AS (
        tsrange(data_hora, data_hora + (duracao_min + buffer_min) * INTERVAL '1 minute')
    ) STORED,
    -- chave auxiliar só pra permitir o EXCLUDE abaixo: trata unidade_id NULL como uma
    -- "cidade zero" compartilhada, em vez de cada NULL ser tratado como diferente dos
    -- outros (comportamento padrão de NULL em comparações), o que deixaria passar
    -- sobreposição de horário em clínicas que não usam cidades separadas
    unidade_chave UUID GENERATED ALWAYS AS (
        COALESCE(unidade_id, '00000000-0000-0000-0000-000000000000'::uuid)
    ) STORED,
    local VARCHAR(255),
    agendado_por VARCHAR(255),                -- nome livre de quem marcou (atendente, "Autocadastro", "Assistente")
    status VARCHAR(20) NOT NULL DEFAULT 'agendado'
        CHECK (status IN ('agendado','confirmado','realizado','cancelado','faltou')),
    observacoes TEXT,
    -- controle de envio dos lembretes automáticos por WhatsApp, pra cada etapa
    -- ser enviada só uma vez (quem manda de fato é o assistente externo, aqui só
    -- fica registrado o que já saiu)
    lembrete_confirmacao_enviado BOOLEAN DEFAULT FALSE,
    lembrete_24h_enviado BOOLEAN DEFAULT FALSE,
    lembrete_2h_enviado BOOLEAN DEFAULT FALSE,
    lembrete_pos_consulta_enviado BOOLEAN DEFAULT FALSE,
    criado_em TIMESTAMP DEFAULT NOW(),
    atualizado_em TIMESTAMP DEFAULT NOW(),
    -- bloqueia sobreposição real de horário dentro da mesma cidade/evento,
    -- considerando duração + intervalo, e ignora agendamentos cancelados.
    -- Duas cidades diferentes podem ter horários simultâneos sem problema.
    CONSTRAINT sem_sobreposicao_por_unidade EXCLUDE USING gist (
        clinica_id WITH =,
        unidade_chave WITH =,
        periodo_ocupado WITH &&
    ) WHERE (status <> 'cancelado')
);
CREATE INDEX idx_agendamentos_clinica_data ON agendamentos(clinica_id, data_hora);
CREATE INDEX idx_agendamentos_paciente ON agendamentos(paciente_id);
CREATE INDEX idx_agendamentos_unidade ON agendamentos(unidade_id);
CREATE INDEX idx_pacientes_unidade ON pacientes(unidade_id);

-- =========================================================
-- 6. RECEITAS E ATESTADOS (Longe/Perto + CID)
-- =========================================================
CREATE TABLE receitas (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    clinica_id UUID NOT NULL REFERENCES clinicas(id) ON DELETE CASCADE,
    paciente_id UUID NOT NULL REFERENCES pacientes(id) ON DELETE CASCADE,
    usuario_id UUID REFERENCES usuarios(id),  -- quem registrou a receita no sistema (pode ser atendente)
    profissional_id UUID REFERENCES usuarios(id), -- profissional (papel='profissional') cujo carimbo/assinatura sai impresso
    data_emissao DATE NOT NULL DEFAULT CURRENT_DATE,
    idade_paciente SMALLINT,                  -- idade informada no momento da receita, usada pra sugerir a adição
    longe JSONB,                              -- {od:{esf,cil,eixo}, oe:{esf,cil,eixo}}
    perto JSONB,
    adicao VARCHAR(10),
    tipo_lente VARCHAR(50),
    tratamentos TEXT[],                       -- antirreflexo, blue, anti-risco, UV, fotossensível
    cid_codigo VARCHAR(10),
    cid_descricao VARCHAR(255),
    atestado_texto TEXT,
    declaracao_texto TEXT,
    criado_em TIMESTAMP DEFAULT NOW()
);
CREATE INDEX idx_receitas_paciente ON receitas(paciente_id);

-- =========================================================
-- PRONTUÁRIO CLÍNICO (exame de vista)
-- Acesso restrito: só usuários com papel='profissional' (ou 'admin') podem ler ou
-- escrever aqui. Um atendente comum, mesmo vendo o paciente normalmente nas outras
-- telas, nunca enxerga o conteúdo desta tabela — essa regra é aplicada na API,
-- não só escondida na tela.
-- =========================================================
CREATE TABLE prontuarios (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    clinica_id UUID NOT NULL REFERENCES clinicas(id) ON DELETE CASCADE,
    paciente_id UUID NOT NULL REFERENCES pacientes(id) ON DELETE CASCADE,
    profissional_id UUID NOT NULL REFERENCES usuarios(id), -- quem fez o exame e escreveu o prontuário
    data_exame DATE NOT NULL DEFAULT CURRENT_DATE,
    queixa_principal TEXT,                    -- o que o paciente relatou precisar/sentir
    sintomas JSONB,                           -- anamnese estruturada: {"Visão embaçada": true, "Dor de cabeça": false, ...}
    observacoes_clinicas TEXT,                -- achados do profissional durante o exame
    conduta TEXT,                             -- conduta/recomendação definida pelo profissional
    receita_id UUID REFERENCES receitas(id) ON DELETE SET NULL, -- receita gerada a partir deste exame, se houver
    -- gabarito completo de acuidade visual, opcional, usado tanto em exame comum quanto
    -- em exame admissional de empresa (campos de empresa ficam em branco quando não é o caso).
    -- Impresso à parte, sem logo nem marca, só com o profissional que assina.
    gabarito_acuidade JSONB,
    criado_em TIMESTAMP DEFAULT NOW(),
    atualizado_em TIMESTAMP DEFAULT NOW()
);
CREATE INDEX idx_prontuarios_paciente ON prontuarios(paciente_id);

-- =========================================================
-- 7. TESTES DE VISÃO (triagem antes do agendamento)
-- =========================================================
CREATE TABLE testes_visao (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    clinica_id UUID NOT NULL REFERENCES clinicas(id) ON DELETE CASCADE,
    unidade_id UUID REFERENCES unidades(id) ON DELETE SET NULL, -- cidade/evento onde o teste foi feito
    paciente_id UUID REFERENCES pacientes(id) ON DELETE SET NULL, -- pode ser feito antes de existir cadastro
    nome_informado VARCHAR(255),
    distancia_cm INTEGER,
    menor_linha VARCHAR(10),                  -- ex: J3
    equivalente_snellen VARCHAR(20),          -- ex: 20/30
    criado_em TIMESTAMP DEFAULT NOW()
);

-- =========================================================
-- Gatilho genérico para manter atualizado_em em dia
-- =========================================================
CREATE OR REPLACE FUNCTION set_atualizado_em()
RETURNS TRIGGER AS $$
BEGIN
  NEW.atualizado_em = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_pacientes_atualizado BEFORE UPDATE ON pacientes
  FOR EACH ROW EXECUTE FUNCTION set_atualizado_em();
CREATE TRIGGER trg_agendamentos_atualizado BEFORE UPDATE ON agendamentos
  FOR EACH ROW EXECUTE FUNCTION set_atualizado_em();
CREATE TRIGGER trg_clinicas_atualizado BEFORE UPDATE ON clinicas
  FOR EACH ROW EXECUTE FUNCTION set_atualizado_em();
CREATE TRIGGER trg_prontuarios_atualizado BEFORE UPDATE ON prontuarios
  FOR EACH ROW EXECUTE FUNCTION set_atualizado_em();
