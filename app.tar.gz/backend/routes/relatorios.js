const express = require('express');
const pool = require('../db/pool');
const { exigirLogin, exigirProfissional, exigirPermissao } = require('../middleware/auth');

const router = express.Router();
router.use(exigirLogin);

function filtroCidade(req, params, alias) {
  if (!req.usuario.unidadeId) return '';
  params.push(req.usuario.unidadeId);
  return ` AND ${alias}.unidade_id=$${params.length}`;
}

/* Pacientes que fizeram exame há mais de N meses (padrão 12) e não têm nada marcado pela frente */
router.get('/retornos', exigirPermissao('retornos'), async (req, res) => {
  const meses = Math.min(Math.max(parseInt(req.query.meses, 10) || 12, 1), 60);
  const params = [req.usuario.clinicaId, meses];
  const f = filtroCidade(req, params, 'p');
  const r = await pool.query(
    `SELECT p.id, p.nome_completo, p.telefone, p.cidade, MAX(a.data_hora) AS ultimo_exame
     FROM pacientes p
     JOIN agendamentos a ON a.paciente_id = p.id AND a.status = 'realizado'
     WHERE p.clinica_id=$1 AND p.deletado_em IS NULL${f}
       AND NOT EXISTS (SELECT 1 FROM agendamentos x WHERE x.paciente_id = p.id AND x.status <> 'cancelado' AND x.data_hora > NOW())
     GROUP BY p.id
     HAVING MAX(a.data_hora) < NOW() - make_interval(months => $2)
     ORDER BY ultimo_exame`,
    params
  );
  res.json(r.rows);
});

/* Aniversariantes do mês (?mes=1..12, padrão mês atual) */
router.get('/aniversariantes', exigirPermissao('retornos'), async (req, res) => {
  const mes = parseInt(req.query.mes, 10) || (new Date().getMonth() + 1);
  const params = [req.usuario.clinicaId, mes];
  const f = filtroCidade(req, params, 'p');
  const r = await pool.query(
    `SELECT p.id, p.nome_completo, p.telefone, p.data_nascimento
     FROM pacientes p
     WHERE p.clinica_id=$1 AND p.deletado_em IS NULL AND p.data_nascimento IS NOT NULL
       AND EXTRACT(MONTH FROM p.data_nascimento) = $2${f}
     ORDER BY EXTRACT(DAY FROM p.data_nascimento), p.nome_completo`,
    params
  );
  res.json(r.rows);
});

/* Painel: números do mês. Faturamento só aparece para o administrador. */
router.get('/painel', exigirProfissional, async (req, res) => {
  const id = req.usuario.clinicaId;
  const pPainel = req.usuario.unidadeId ? [id, req.usuario.unidadeId] : [id];
  const q = async (sql, extra = []) => {
    const params = [id, ...extra];
    const f = filtroCidade(req, params, 'a');
    return (await pool.query(sql.replace('/*F*/', f), params)).rows;
  };
  const [hoje] = await q(
    `SELECT COUNT(*) FILTER (WHERE a.status <> 'cancelado')::int AS total,
            COUNT(*) FILTER (WHERE a.status = 'confirmado')::int AS confirmadas,
            COUNT(*) FILTER (WHERE a.status = 'agendado')::int AS aguardando
     FROM agendamentos a WHERE a.clinica_id=$1 AND a.data_hora::date = CURRENT_DATE/*F*/`);
  const [mes] = await q(
    `SELECT COUNT(*) FILTER (WHERE a.status = 'realizado')::int AS realizados,
            COUNT(*) FILTER (WHERE a.status = 'faltou')::int AS faltaram,
            COUNT(*) FILTER (WHERE a.status NOT IN ('cancelado'))::int AS marcados
     FROM agendamentos a WHERE a.clinica_id=$1 AND date_trunc('month', a.data_hora) = date_trunc('month', NOW())/*F*/`);
  const finalizados = mes.realizados + mes.faltaram;
  const nao_comparecimento = finalizados ? Math.round((mes.faltaram / finalizados) * 1000) / 10 : 0;

  // ocupação: horários marcados dividido pelos horários abertos nas agendas do mês
  const agendas = await q(
    `SELECT a.hora_inicio, a.hora_fim, COALESCE(t.duracao_min,30) AS dur, COALESCE(t.buffer_min,0) AS buf
     FROM agendas a LEFT JOIN tipos_atendimento t ON t.id = a.tipo_atendimento_id
     WHERE a.clinica_id=$1 AND a.ativa AND date_trunc('month', a.data) = date_trunc('month', CURRENT_DATE)/*F*/`);
  const minutos = (h) => { const [x, y] = String(h).split(':'); return (+x) * 60 + (+y); };
  const vagas = agendas.reduce((t, g) => t + Math.max(0, Math.floor((minutos(g.hora_fim) - minutos(g.hora_inicio)) / (g.dur + g.buf))), 0);
  // só conta quem foi marcado em dia com agenda aberta; consulta avulsa não entra na ocupação
  const [oc] = await q(
    `SELECT COUNT(*)::int AS n FROM agendamentos a
     WHERE a.clinica_id=$1 AND a.status <> 'cancelado' AND date_trunc('month', a.data_hora) = date_trunc('month', NOW())
       AND EXISTS (SELECT 1 FROM agendas g WHERE g.unidade_id = a.unidade_id AND g.ativa AND g.data = a.data_hora::date)/*F*/`);
  const ocupadas = oc.n;
  const ocupacao = vagas ? Math.min(100, Math.round((ocupadas / vagas) * 1000) / 10) : null;

  const origens = await q(
    `SELECT COALESCE(a.origem,'equipe') AS origem, COUNT(*)::int AS qtd FROM agendamentos a
     WHERE a.clinica_id=$1 AND a.status <> 'cancelado' AND date_trunc('month', a.data_hora) = date_trunc('month', NOW())/*F*/ GROUP BY 1 ORDER BY 2 DESC`);
  const proximas = await q(
    `SELECT a.id, a.data_hora, a.status, p.nome_completo, t.nome AS tipo_nome
     FROM agendamentos a JOIN pacientes p ON p.id = a.paciente_id LEFT JOIN tipos_atendimento t ON t.id = a.tipo_atendimento_id
     WHERE a.clinica_id=$1 AND a.status IN ('agendado','confirmado') AND a.data_hora >= NOW()/*F*/ ORDER BY a.data_hora LIMIT 8`);

  // retornos que vencem nos próximos 30 dias: último exame entre 11 e 12 meses atrás, nada marcado
  const retornos = await q(
    `SELECT p.id, p.nome_completo, p.telefone, MAX(a.data_hora) AS ultimo_exame
     FROM pacientes p JOIN agendamentos a ON a.paciente_id = p.id AND a.status = 'realizado'
     WHERE p.clinica_id=$1 AND p.deletado_em IS NULL${req.usuario.unidadeId ? ' AND p.unidade_id=$2' : ''}
       AND NOT EXISTS (SELECT 1 FROM agendamentos x WHERE x.paciente_id = p.id AND x.status <> 'cancelado' AND x.data_hora > NOW())
     GROUP BY p.id
     HAVING MAX(a.data_hora) < NOW() - INTERVAL '11 months' AND MAX(a.data_hora) >= NOW() - INTERVAL '12 months'
     ORDER BY ultimo_exame LIMIT 20`);
  // receitas emitidas entre 10 e 12 meses atrás (validade de 12 meses)
  const receitas = (await pool.query(
    `SELECT p.id AS paciente_id, p.nome_completo, p.telefone, MAX(r.data_emissao) AS emissao
     FROM receitas r JOIN pacientes p ON p.id = r.paciente_id
     WHERE r.clinica_id=$1 AND p.deletado_em IS NULL${req.usuario.unidadeId ? ' AND p.unidade_id=$2' : ''}
     GROUP BY p.id
     HAVING MAX(r.data_emissao) <= CURRENT_DATE - INTERVAL '10 months' AND MAX(r.data_emissao) > CURRENT_DATE - INTERVAL '12 months'
     ORDER BY emissao LIMIT 20`,
    req.usuario.unidadeId ? [id, req.usuario.unidadeId] : [id])).rows;

  const saida = { hoje, mes: { ...mes, marcados: ocupadas, nao_comparecimento, vagas, ocupacao }, origens, proximas, retornos_vencendo: retornos, receitas_vencendo: receitas };

  if (req.usuario.papel === 'admin') {
    const [fin] = (await pool.query(
      `SELECT COALESCE(SUM(pg.valor) FILTER (WHERE pg.status='pago' AND date_trunc('month', a.data_hora)=date_trunc('month', NOW())),0)::float AS mes,
              COALESCE(SUM(pg.valor) FILTER (WHERE pg.status='pago' AND date_trunc('month', a.data_hora)=date_trunc('month', NOW() - INTERVAL '1 month')),0)::float AS anterior,
              COALESCE(SUM(pg.valor) FILTER (WHERE pg.status='pendente' AND date_trunc('month', a.data_hora)=date_trunc('month', NOW())),0)::float AS a_receber
       FROM pagamentos pg JOIN agendamentos a ON a.id = pg.agendamento_id WHERE pg.clinica_id=$1`, [id])).rows;
    const dia = new Date().getDate(), diasMes = new Date(new Date().getFullYear(), new Date().getMonth() + 1, 0).getDate();
    saida.faturamento = { ...fin, projecao: Math.round((fin.mes / Math.max(dia, 1)) * diasMes * 100) / 100 };
  }
  res.json(saida);
});

module.exports = router;
