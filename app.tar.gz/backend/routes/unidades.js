const express = require('express');
const pool = require('../db/pool');
const { exigirLogin, exigirAdmin } = require('../middleware/auth');

const router = express.Router();
router.use(exigirLogin);

/* Admin vê todas as cidades da clínica. Um atendente restrito a uma cidade só vê a própria. */
router.get('/', async (req, res) => {
  const r = req.usuario.unidadeId
    ? await pool.query(`SELECT * FROM unidades WHERE id=$1 AND clinica_id=$2`, [req.usuario.unidadeId, req.usuario.clinicaId])
    : await pool.query(`SELECT * FROM unidades WHERE clinica_id=$1 AND ativa=TRUE ORDER BY data_inicio DESC NULLS LAST, nome`, [req.usuario.clinicaId]);
  res.json(r.rows);
});

router.post('/', exigirAdmin, async (req, res) => {
  const { slug, nome, cidade, local, data_inicio, data_fim } = req.body;
  if (!slug || !nome) return res.status(400).json({ erro: 'Informe ao menos o identificador e o nome da cidade/evento.' });
  try {
    const r = await pool.query(
      `INSERT INTO unidades (clinica_id, slug, nome, cidade, local, data_inicio, data_fim)
       VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING *`,
      [req.usuario.clinicaId, slug.toLowerCase().trim().replace(/[^a-z0-9-]/g,'-'), nome, cidade || null, local || null, data_inicio || null, data_fim || null]
    );
    res.status(201).json(r.rows[0]);
  } catch (e) {
    if (e.code === '23505') return res.status(409).json({ erro: 'Já existe uma cidade/evento com esse identificador.' });
    console.error(e); res.status(500).json({ erro: 'Erro ao criar a cidade/evento.' });
  }
});

router.delete('/:id', exigirAdmin, async (req, res) => {
  const r = await pool.query(`UPDATE unidades SET ativa=FALSE WHERE id=$1 AND clinica_id=$2 RETURNING id`, [req.params.id, req.usuario.clinicaId]);
  if (!r.rows.length) return res.status(404).json({ erro: 'Cidade/evento não encontrado.' });
  res.json({ ok: true });
});

module.exports = router;
