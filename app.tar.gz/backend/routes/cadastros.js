const express = require('express');
const pool = require('../db/pool');
const { exigirLogin, exigirAdmin } = require('../middleware/auth');

const router = express.Router();
router.use(exigirLogin);

/* Óticas parceiras e convênios: todos os usuários podem listar (pra escolher no agendamento),
   só o administrador cadastra e remove. */
function crud(caminho, tabela, colAtivo) {
  router.get(`/${caminho}`, async (req, res) => {
    const r = await pool.query(`SELECT id, nome FROM ${tabela} WHERE clinica_id=$1 AND ${colAtivo}=TRUE ORDER BY nome`, [req.usuario.clinicaId]);
    res.json(r.rows);
  });
  router.post(`/${caminho}`, exigirAdmin, async (req, res) => {
    const nome = (req.body.nome || '').trim();
    if (!nome) return res.status(400).json({ erro: 'Informe o nome.' });
    const r = await pool.query(`INSERT INTO ${tabela} (clinica_id, nome) VALUES ($1,$2) RETURNING id, nome`, [req.usuario.clinicaId, nome]);
    res.status(201).json(r.rows[0]);
  });
  router.delete(`/${caminho}/:id`, exigirAdmin, async (req, res) => {
    const r = await pool.query(`UPDATE ${tabela} SET ${colAtivo}=FALSE WHERE id=$1 AND clinica_id=$2 RETURNING id`, [req.params.id, req.usuario.clinicaId]);
    if (!r.rows.length) return res.status(404).json({ erro: 'Não encontrado.' });
    res.json({ ok: true });
  });
}
crud('oticas', 'oticas_parceiras', 'ativa');
crud('convenios', 'convenios', 'ativo');

module.exports = router;
