const express = require('express');
const pool = require('../db/pool');
const { exigirChaveIntegracao } = require('../middleware/auth');

const router = express.Router({ mergeParams: true }); // precisa disso pra enxergar o :slug da rota pai (/integracao/:slug)
router.use(exigirChaveIntegracao);

/* GET /:slug/tipos-atendimento — pra o assistente saber quais exames existem
   e qual id passar nas outras duas rotas */
router.get('/tipos-atendimento', async (req, res) => {
  const r = await pool.query(
    `SELECT id, nome, duracao_min FROM tipos_atendimento WHERE clinica_id=$1 AND ativo=TRUE ORDER BY nome`,
    [req.clinicaIntegracao.id]
  );
  res.json(r.rows);
});

async function buscarUnidade(clinicaId, unidadeSlug) {
  if (!unidadeSlug) return null;
  const r = await pool.query(`SELECT * FROM unidades WHERE clinica_id=$1 AND slug=$2 AND ativa=TRUE`, [clinicaId, unidadeSlug]);
  return r.rows[0] || null;
}

function horaParaMin(hhmmss) {
  const [h, m] = hhmmss.split(':').map(Number);
  return h * 60 + m;
}
function minParaHora(min) {
  const h = String(Math.floor(min / 60)).padStart(2, '0');
  const m = String(min % 60).padStart(2, '0');
  return `${h}:${m}`;
}

/* GET /:slug/disponibilidade?tipo_atendimento_id=...&data_inicio=YYYY-MM-DD&data_fim=YYYY-MM-DD&u=slug-cidade
   Devolve, por dia, os horários de início ainda livres, já descontando os agendamentos existentes.
   Limita a no máximo 21 dias de intervalo por chamada, pra não devolver uma lista gigante. */
router.get('/disponibilidade', async (req, res) => {
  const clinica = req.clinicaIntegracao;
  const { tipo_atendimento_id, data_inicio, data_fim, u } = req.query;
  if (!tipo_atendimento_id || !data_inicio || !data_fim) {
    return res.status(400).json({ erro: 'Informe tipo_atendimento_id, data_inicio e data_fim.' });
  }
  const unidade = await buscarUnidade(clinica.id, u);
  if (u && !unidade) return res.status(404).json({ erro: 'Cidade/evento não encontrado.' });

  const tipoR = await pool.query(`SELECT * FROM tipos_atendimento WHERE id=$1 AND clinica_id=$2`, [tipo_atendimento_id, clinica.id]);
  if (!tipoR.rows.length) return res.status(400).json({ erro: 'Tipo de atendimento inválido.' });
  const tipo = tipoR.rows[0];
  const passoMin = tipo.duracao_min + tipo.buffer_min;

  const abertura = (unidade ? unidade.horario_abertura : clinica.horario_abertura) || '08:00:00';
  const fechamento = (unidade ? unidade.horario_fechamento : clinica.horario_fechamento) || '18:00:00';
  const diasFunc = (unidade ? unidade.dias_funcionamento : clinica.dias_funcionamento) || [1,2,3,4,5];

  const inicio = new Date(data_inicio + 'T00:00:00');
  const fim = new Date(data_fim + 'T00:00:00');
  const diffDias = Math.round((fim - inicio) / 86400000);
  if (isNaN(diffDias) || diffDias < 0 || diffDias > 21) {
    return res.status(400).json({ erro: 'Intervalo inválido: use no máximo 21 dias por consulta.' });
  }

  // agendamentos existentes no período, já filtrados pela mesma "chave de cidade"
  // que o banco usa pra bloquear conflito (unidade específica, ou nenhuma)
  const agR = await pool.query(
    `SELECT data_hora, duracao_min, buffer_min FROM agendamentos
     WHERE clinica_id=$1 AND status<>'cancelado'
       AND COALESCE(unidade_id,'00000000-0000-0000-0000-000000000000') = COALESCE($2::uuid,'00000000-0000-0000-0000-000000000000')
       AND data_hora::date BETWEEN $3 AND $4`,
    [clinica.id, unidade ? unidade.id : null, data_inicio, data_fim]
  );
  const ocupados = agR.rows.map(a => {
    const inicioMin = horaParaMin(a.data_hora.toTimeString().slice(0,8));
    return { dia: a.data_hora.toISOString().slice(0,10), inicio: inicioMin, fim: inicioMin + a.duracao_min + a.buffer_min };
  });

  const hoje = new Date();
  const resultado = [];
  for (let d = new Date(inicio); d <= fim; d.setDate(d.getDate()+1)) {
    const diaSemana = d.getDay();
    if (!diasFunc.includes(diaSemana)) continue;
    const isoDia = d.toISOString().slice(0,10);
    const slots = [];
    for (let min = horaParaMin(abertura); min + tipo.duracao_min <= horaParaMin(fechamento); min += passoMin) {
      // não oferece horário que já passou, se o dia for hoje
      if (isoDia === hoje.toISOString().slice(0,10) && min <= hoje.getHours()*60 + hoje.getMinutes()) continue;
      const conflita = ocupados.some(o => o.dia === isoDia && min < o.fim && (min + tipo.duracao_min + tipo.buffer_min) > o.inicio);
      if (!conflita) slots.push(minParaHora(min));
    }
    if (slots.length) resultado.push({ data: isoDia, horarios: slots });
  }
  res.json(resultado);
});

/* POST /:slug/agendamentos  { nome_completo, telefone, tipo_atendimento_id, data_hora, u }
   Cria o paciente (se ainda não existir pelo telefone) e o agendamento numa tacada só. */
router.post('/agendamentos', async (req, res) => {
  const clinica = req.clinicaIntegracao;
  const { nome_completo, telefone, tipo_atendimento_id, data_hora, u } = req.body;
  if (!nome_completo || !tipo_atendimento_id || !data_hora) {
    return res.status(400).json({ erro: 'Informe nome_completo, tipo_atendimento_id e data_hora.' });
  }
  const unidade = await buscarUnidade(clinica.id, u);
  if (u && !unidade) return res.status(404).json({ erro: 'Cidade/evento não encontrado.' });

  const tipoR = await pool.query(`SELECT * FROM tipos_atendimento WHERE id=$1 AND clinica_id=$2`, [tipo_atendimento_id, clinica.id]);
  if (!tipoR.rows.length) return res.status(400).json({ erro: 'Tipo de atendimento inválido.' });
  const tipo = tipoR.rows[0];

  try {
    // reaproveita o paciente se o telefone já tiver cadastro nesta clínica; senão cria um novo
    let pacienteId;
    if (telefone) {
      const pExist = await pool.query(`SELECT id FROM pacientes WHERE clinica_id=$1 AND telefone=$2 AND deletado_em IS NULL LIMIT 1`, [clinica.id, telefone]);
      if (pExist.rows.length) pacienteId = pExist.rows[0].id;
    }
    if (!pacienteId) {
      const pNovo = await pool.query(
        `INSERT INTO pacientes (clinica_id, unidade_id, nome_completo, telefone, agendado_por) VALUES ($1,$2,$3,$4,'WhatsApp') RETURNING id`,
        [clinica.id, unidade ? unidade.id : null, nome_completo, telefone || null]
      );
      pacienteId = pNovo.rows[0].id;
    }

    const r = await pool.query(
      `INSERT INTO agendamentos (clinica_id, unidade_id, paciente_id, tipo_atendimento_id, data_hora, duracao_min, buffer_min, agendado_por, status, origem)
       VALUES ($1,$2,$3,$4,$5,$6,$7,'WhatsApp','agendado','whatsapp') RETURNING *`,
      [clinica.id, unidade ? unidade.id : null, pacienteId, tipo.id, data_hora, tipo.duracao_min, tipo.buffer_min]
    );
    res.status(201).json({ ok: true, agendamento: r.rows[0] });
  } catch (e) {
    if (e.code === '23P01') {
      return res.status(409).json({ erro: 'Esse horário acabou de ser ocupado. Escolha outro.' });
    }
    console.error(e); res.status(500).json({ erro: 'Erro ao criar o agendamento.' });
  }
});

/* GET /:slug/lembretes-pendentes?etapa=confirmacao|24h|2h
   Devolve os agendamentos que precisam desse lembrete agora, com telefone e nome
   do paciente prontos pra montar a mensagem. Pensado pra ser chamado periodicamente
   (ex: a cada 15-30 min) por um agendador externo (n8n), um disparo por etapa.
   Cada agendamento só aparece uma vez por etapa: depois de enviado, chama
   POST .../marcar-enviado pra ele parar de aparecer aqui. */
router.get('/lembretes-pendentes', async (req, res) => {
  const clinica = req.clinicaIntegracao;
  const etapa = req.query.etapa;
  const janelas = {
    // confirmacao: dispara pouco depois de marcado, não depende de quando é a consulta
    confirmacao: { coluna: 'lembrete_confirmacao_enviado', condicaoExtra: `a.criado_em > NOW() - INTERVAL '2 hours'` },
    // 24h: consulta entre 23h e 28h no futuro (janela larga pra não perder ninguém
    // entre uma rodada e outra do agendador)
    '24h': { coluna: 'lembrete_24h_enviado', condicaoExtra: `a.data_hora BETWEEN NOW() + INTERVAL '23 hours' AND NOW() + INTERVAL '28 hours'` },
    // 2h: consulta entre 1h30 e 3h no futuro
    '2h': { coluna: 'lembrete_2h_enviado', condicaoExtra: `a.data_hora BETWEEN NOW() + INTERVAL '1.5 hours' AND NOW() + INTERVAL '3 hours'` },
    // pos_consulta: dispara de 2h a 6h depois do horário marcado, pra dar tempo do
    // atendimento terminar; não manda pra quem cancelou ou faltou (filtro já exclui isso acima)
    pos_consulta: { coluna: 'lembrete_pos_consulta_enviado', condicaoExtra: `a.data_hora BETWEEN NOW() - INTERVAL '6 hours' AND NOW() - INTERVAL '2 hours'` },
  };
  const cfg = janelas[etapa];
  if (!cfg) return res.status(400).json({ erro: "Informe etapa=confirmacao, etapa=24h, etapa=2h ou etapa=pos_consulta." });

  const r = await pool.query(
    `SELECT a.id AS agendamento_id, a.data_hora, p.nome_completo, p.telefone, un.nome AS cidade
     FROM agendamentos a
     JOIN pacientes p ON p.id = a.paciente_id
     LEFT JOIN unidades un ON un.id = a.unidade_id
     WHERE a.clinica_id=$1 AND a.status NOT IN ('cancelado','faltou')
       AND a.${cfg.coluna} = FALSE AND p.telefone IS NOT NULL
       AND ${cfg.condicaoExtra}
     ORDER BY a.data_hora`,
    [clinica.id]
  );
  res.json(r.rows);
});

/* POST /:slug/lembretes-pendentes/:agendamento_id/marcar-enviado  { etapa } */
router.post('/lembretes-pendentes/:agendamento_id/marcar-enviado', async (req, res) => {
  const clinica = req.clinicaIntegracao;
  const colunas = { confirmacao: 'lembrete_confirmacao_enviado', '24h': 'lembrete_24h_enviado', '2h': 'lembrete_2h_enviado', pos_consulta: 'lembrete_pos_consulta_enviado' };
  const coluna = colunas[req.body.etapa];
  if (!coluna) return res.status(400).json({ erro: "Informe etapa=confirmacao, etapa=24h, etapa=2h ou etapa=pos_consulta no corpo." });
  const r = await pool.query(
    `UPDATE agendamentos SET ${coluna}=TRUE WHERE id=$1 AND clinica_id=$2 RETURNING id`,
    [req.params.agendamento_id, clinica.id]
  );
  if (!r.rows.length) return res.status(404).json({ erro: 'Agendamento não encontrado.' });
  res.json({ ok: true });
});

/* PUT /:slug/agendamentos/:id/status  { status: "confirmado" | "cancelado" }
   Pensado pra n8n chamar depois de interpretar a resposta do paciente no WhatsApp
   ("sim" vira confirmado, "não" vira cancelado), sem precisar de um atendente
   mexer na agenda na mão. De propósito só aceita essas duas opções por aqui:
   "realizado" e "faltou" continuam sendo decisão de quem atende, não do robô. */
router.put('/agendamentos/:id/status', async (req, res) => {
  const clinica = req.clinicaIntegracao;
  const { status } = req.body;
  if (!['confirmado', 'cancelado'].includes(status)) {
    return res.status(400).json({ erro: 'status deve ser "confirmado" ou "cancelado".' });
  }
  const r = await pool.query(
    `UPDATE agendamentos SET status=$1 WHERE id=$2 AND clinica_id=$3 AND status NOT IN ('realizado') RETURNING id, status`,
    [status, req.params.id, clinica.id]
  );
  if (!r.rows.length) return res.status(404).json({ erro: 'Agendamento não encontrado, ou já foi marcado como realizado.' });
  res.json({ ok: true, agendamento: r.rows[0] });
});

module.exports = router;
