const express = require('express');
const pool = require('../db/pool');
const { exigirLogin, exigirAdmin } = require('../middleware/auth');

const router = express.Router();

// '' ou null = sem preço; texto inválido = false
function precoOuNulo(v) {
  if (v === undefined || v === null || String(v).trim() === '') return null;
  const n = Number(String(v).replace(',', '.'));
  return isNaN(n) || n < 0 ? false : n;
}
router.use(exigirLogin);

router.get('/', async (req, res) => {
  const r = await pool.query(`SELECT * FROM tipos_atendimento WHERE clinica_id=$1 AND ativo=TRUE ORDER BY criado_em`, [req.usuario.clinicaId]);
  res.json(r.rows);
});

router.post('/', exigirAdmin, async (req, res) => {
  const { nome, duracao_min, buffer_min, cor } = req.body;
  if (!nome || !duracao_min) return res.status(400).json({ erro: 'Informe nome e duração.' });
  const preco = precoOuNulo(req.body.preco_padrao);
  if (preco === false) return res.status(400).json({ erro: 'Preço inválido.' });
  const r = await pool.query(
    `INSERT INTO tipos_atendimento (clinica_id, nome, duracao_min, buffer_min, cor, preco_padrao) VALUES ($1,$2,$3,$4,$5,$6) RETURNING *`,
    [req.usuario.clinicaId, nome, duracao_min, buffer_min || 0, cor || '#1B5C5A', preco]
  );
  res.status(201).json(r.rows[0]);
});

// muda só o preço padrão (nome e duração mexem em agendas já marcadas, então ficam fixos)
router.patch('/:id', exigirAdmin, async (req, res) => {
  const preco = precoOuNulo(req.body.preco_padrao);
  if (preco === false) return res.status(400).json({ erro: 'Preço inválido.' });
  const r = await pool.query(`UPDATE tipos_atendimento SET preco_padrao=$1 WHERE id=$2 AND clinica_id=$3 RETURNING *`, [preco, req.params.id, req.usuario.clinicaId]);
  if (!r.rows.length) return res.status(404).json({ erro: 'Tipo não encontrado.' });
  res.json(r.rows[0]);
});

router.delete('/:id', exigirAdmin, async (req, res) => {
  const r = await pool.query(`UPDATE tipos_atendimento SET ativo=FALSE WHERE id=$1 AND clinica_id=$2 RETURNING id`, [req.params.id, req.usuario.clinicaId]);
  if (!r.rows.length) return res.status(404).json({ erro: 'Tipo não encontrado.' });
  res.json({ ok: true });
});

module.exports = router;
