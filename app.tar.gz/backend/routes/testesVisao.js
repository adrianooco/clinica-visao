const express = require('express');
const pool = require('../db/pool');
const { exigirLogin, exigirPermissao } = require('../middleware/auth');

const router = express.Router();
router.use(exigirLogin);
router.use(exigirPermissao('assistente'));

router.get('/', async (req, res) => {
  const params = [req.usuario.clinicaId];
  let filtro = '';
  if (req.usuario.unidadeId) { params.push(req.usuario.unidadeId); filtro = ` AND unidade_id=$2`; }
  const r = await pool.query(
    `SELECT * FROM testes_visao WHERE clinica_id=$1${filtro} ORDER BY criado_em DESC LIMIT 20`,
    params
  );
  res.json(r.rows);
});

module.exports = router;
