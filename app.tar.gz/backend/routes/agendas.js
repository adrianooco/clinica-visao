const express = require('express');
const pool = require('../db/pool');
const { exigirLogin, exigirAdmin } = require('../middleware/auth');

const router = express.Router();
router.use(exigirLogin);

const dois = (n) => String(n).padStart(2, '0');
const minParaHora = (m) => `${dois(Math.floor(m / 60))}:${dois(m % 60)}`;
const horaParaMin = (h) => { const [a, b] = String(h).split(':').map(Number); return a * 60 + b; };

/* Horários livres e ocupados das agendas de evento.
   Agendador (atendente) só enxerga a cidade dele. Admin e profissional podem filtrar por ?unidade_id. */
router.get('/horarios', async (req, res) => {
  const { de, ate } = req.query;
  const params = [req.usuario.clinicaId, de || null, ate || null];
  let filtro = '';
  const unidade = req.usuario.unidadeId || req.query.unidade_id || null;
  if (unidade) { params.push(unidade); filtro = ` AND a.unidade_id=$4`; }

  const ags = await pool.query(
    `SELECT a.id, a.unidade_id, a.data, a.hora_inicio, a.hora_fim, a.local, a.tipo_atendimento_id,
            t.nome AS tipo_nome, t.cor AS tipo_cor, t.duracao_min, t.buffer_min
     FROM agendas a JOIN tipos_atendimento t ON t.id = a.tipo_atendimento_id
     WHERE a.clinica_id=$1 AND a.ativa=TRUE
       AND ($2::date IS NULL OR a.data >= $2) AND ($3::date IS NULL OR a.data <= $3)${filtro}
     ORDER BY a.data, a.hora_inicio`,
    params
  );
  if (!ags.rows.length) return res.json([]);

  const unidades = [...new Set(ags.rows.map((a) => a.unidade_id))];
  const menorData = ags.rows[0].data, maiorData = ags.rows[ags.rows.length - 1].data;
  const ocup = await pool.query(
    `SELECT ag.id, ag.unidade_id, ag.data_hora, ag.status, p.nome_completo AS paciente_nome
     FROM agendamentos ag JOIN pacientes p ON p.id = ag.paciente_id
     WHERE ag.clinica_id=$1 AND ag.status <> 'cancelado' AND ag.unidade_id = ANY($2::uuid[])
       AND ag.data_hora::date BETWEEN $3 AND $4`,
    [req.usuario.clinicaId, unidades, menorData, maiorData]
  );
  const mapa = new Map(ocup.rows.map((o) => [`${o.unidade_id}|${String(o.data_hora).slice(0, 16)}`, o]));

  const saida = [];
  for (const a of ags.rows) {
    const passo = a.duracao_min + a.buffer_min;
    for (let m = horaParaMin(a.hora_inicio); m + a.duracao_min <= horaParaMin(a.hora_fim); m += passo) {
      const hora = minParaHora(m);
      const data_hora = `${a.data}T${hora}:00`;
      const o = mapa.get(`${a.unidade_id}|${a.data}T${hora}`);
      saida.push({
        agenda_id: a.id, unidade_id: a.unidade_id, data: a.data, hora, data_hora,
        tipo_atendimento_id: a.tipo_atendimento_id, tipo_nome: a.tipo_nome, tipo_cor: a.tipo_cor, local: a.local,
        agendamento: o ? { id: o.id, status: o.status, paciente_nome: o.paciente_nome } : null,
      });
    }
  }
  res.json(saida);
});

/* lista das agendas criadas (admin e profissional), com contagem de ocupação */
router.get('/', async (req, res) => {
  if (req.usuario.papel === 'atendente') return res.status(403).json({ erro: 'Seu acesso não permite abrir essa parte do sistema.' });
  const r = await pool.query(
    `SELECT a.*, u.nome AS unidade_nome, t.nome AS tipo_nome, t.duracao_min, t.buffer_min
     FROM agendas a JOIN unidades u ON u.id = a.unidade_id JOIN tipos_atendimento t ON t.id = a.tipo_atendimento_id
     WHERE a.clinica_id=$1 AND a.ativa=TRUE ORDER BY a.data DESC, a.hora_inicio`,
    [req.usuario.clinicaId]
  );
  res.json(r.rows.map((a) => ({
    ...a,
    total_horarios: Math.max(0, Math.floor((horaParaMin(a.hora_fim) - horaParaMin(a.hora_inicio) + a.buffer_min) / (a.duracao_min + a.buffer_min))),
  })));
});

/* Só o admin define a data e os horários do exame de vista. Pode criar vários dias de uma vez (data_fim). */
router.post('/', exigirAdmin, async (req, res) => {
  const { unidade_id, data, data_fim, hora_inicio, hora_fim, tipo_atendimento_id, local } = req.body;
  if (!unidade_id || !data || !hora_inicio || !hora_fim || !tipo_atendimento_id) {
    return res.status(400).json({ erro: 'Informe a cidade, a data, o horário de início e fim e o tipo de atendimento.' });
  }
  if (horaParaMin(hora_fim) <= horaParaMin(hora_inicio)) return res.status(400).json({ erro: 'O horário final precisa ser depois do inicial.' });
  const un = await pool.query(`SELECT id FROM unidades WHERE id=$1 AND clinica_id=$2 AND ativa=TRUE`, [unidade_id, req.usuario.clinicaId]);
  const tp = await pool.query(`SELECT id, duracao_min FROM tipos_atendimento WHERE id=$1 AND clinica_id=$2`, [tipo_atendimento_id, req.usuario.clinicaId]);
  if (!un.rows.length) return res.status(400).json({ erro: 'Cidade inválida.' });
  if (!tp.rows.length) return res.status(400).json({ erro: 'Tipo de atendimento inválido.' });
  if (horaParaMin(hora_fim) - horaParaMin(hora_inicio) < tp.rows[0].duracao_min) return res.status(400).json({ erro: 'O intervalo é menor que a duração do atendimento.' });

  const dias = [];
  const ini = new Date(data + 'T12:00:00Z'), fim = new Date((data_fim || data) + 'T12:00:00Z');
  if (fim < ini) return res.status(400).json({ erro: 'A data final precisa ser depois da inicial.' });
  if ((fim - ini) / 86400000 > 60) return res.status(400).json({ erro: 'Crie no máximo 60 dias por vez.' });
  for (let d = new Date(ini); d <= fim; d.setUTCDate(d.getUTCDate() + 1)) dias.push(d.toISOString().slice(0, 10));

  const criadas = [];
  for (const dia of dias) {
    const r = await pool.query(
      `INSERT INTO agendas (clinica_id, unidade_id, data, hora_inicio, hora_fim, tipo_atendimento_id, local)
       VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING *`,
      [req.usuario.clinicaId, unidade_id, dia, hora_inicio, hora_fim, tipo_atendimento_id, local || null]
    );
    criadas.push(r.rows[0]);
  }
  res.status(201).json(criadas);
});

router.delete('/:id', exigirAdmin, async (req, res) => {
  const a = await pool.query(`SELECT * FROM agendas WHERE id=$1 AND clinica_id=$2 AND ativa=TRUE`, [req.params.id, req.usuario.clinicaId]);
  if (!a.rows.length) return res.status(404).json({ erro: 'Agenda não encontrada.' });
  const ag = a.rows[0];
  const ocup = await pool.query(
    `SELECT COUNT(*)::int AS n FROM agendamentos WHERE clinica_id=$1 AND unidade_id=$2 AND status <> 'cancelado' AND data_hora::date = $3
       AND data_hora::time >= $4 AND data_hora::time < $5`,
    [req.usuario.clinicaId, ag.unidade_id, ag.data, ag.hora_inicio, ag.hora_fim]
  );
  if (ocup.rows[0].n > 0) return res.status(409).json({ erro: `Essa agenda já tem ${ocup.rows[0].n} paciente(s) marcado(s). Cancele os agendamentos antes de apagar.` });
  await pool.query(`UPDATE agendas SET ativa=FALSE WHERE id=$1`, [req.params.id]);
  res.json({ ok: true });
});

module.exports = router;
