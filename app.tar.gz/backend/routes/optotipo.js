const express = require('express');
const os = require('os');
const path = require('path');
const { exigirLogin } = require('../middleware/auth');

/* Controle do optotipo pelo celular.
   O PC abre uma sessão com código de 6 letras. O celular, na mesma rede Wi-Fi,
   manda comandos pra esse código e o PC busca os comandos em seguida.
   Tudo fica na memória do servidor, sem banco. */
const router = express.Router();
const sessoes = new Map(); // codigo -> { cmds:[], n:0, estado:{}, esperas:[], criada }
const LETRAS = 'ABCDEFGHJKLMNPQRSTUVWXYZ';
const VALIDADE_MS = 12 * 60 * 60 * 1000;

function novoCodigo() {
  let c;
  do { c = Array.from({ length: 6 }, () => LETRAS[Math.floor(Math.random() * LETRAS.length)]).join(''); } while (sessoes.has(c));
  return c;
}
function limpar() {
  const agora = Date.now();
  for (const [c, s] of sessoes) if (agora - s.criada > VALIDADE_MS) sessoes.delete(c);
}
function enderecosRede() {
  const lista = [];
  const ifs = os.networkInterfaces();
  for (const nome of Object.keys(ifs)) {
    for (const i of ifs[nome] || []) {
      if (i.family === 'IPv4' && !i.internal) lista.push(i.address);
    }
  }
  // redes domésticas primeiro (192.168.x.x), depois as demais
  lista.sort((a, b) => (b.startsWith('192.168.') ? 1 : 0) - (a.startsWith('192.168.') ? 1 : 0));
  return lista;
}
const sessao = (req, res) => {
  const s = sessoes.get(String(req.params.codigo || '').toUpperCase());
  if (!s) res.status(404).json({ erro: 'Código não encontrado. Gere um novo QR Code na tela do computador.' });
  return s;
};

// página do celular (sem login: quem tem o código controla só a tela do optotipo)
router.get('/celular', (req, res) => {
  res.sendFile(path.join(__dirname, '..', '..', 'optotipo-celular.html'));
});

router.get('/info', exigirLogin, (req, res) => {
  res.json({ enderecos: enderecosRede(), porta: process.env.PORT || 3000 });
});

router.post('/sessao', exigirLogin, (req, res) => {
  limpar();
  const codigo = novoCodigo();
  sessoes.set(codigo, { cmds: [], n: 0, estado: {}, esperas: [], criada: Date.now() });
  res.json({ codigo, enderecos: enderecosRede(), porta: process.env.PORT || 3000 });
});

// celular manda comando
router.post('/:codigo/cmd', (req, res) => {
  const s = sessao(req, res); if (!s) return;
  const acao = String(req.body?.acao || '').slice(0, 20);
  const valor = req.body?.valor === undefined ? null : req.body.valor;
  if (!acao) return res.status(400).json({ erro: 'Comando vazio.' });
  s.n += 1;
  s.cmds.push({ n: s.n, acao, valor });
  if (s.cmds.length > 100) s.cmds.shift();
  const esperando = s.esperas.splice(0);
  esperando.forEach((fn) => fn());
  res.json({ ok: true });
});

// PC espera comandos novos (long poll de até 20 segundos)
router.get('/:codigo/esperar', (req, res) => {
  const s = sessao(req, res); if (!s) return;
  const desde = parseInt(req.query.desde, 10) || 0;
  const responder = () => res.json({ n: s.n, cmds: s.cmds.filter((c) => c.n > desde) });
  if (s.n > desde) return responder();
  const timer = setTimeout(() => {
    s.esperas = s.esperas.filter((f) => f !== acordar);
    responder();
  }, 20000);
  const acordar = () => { clearTimeout(timer); responder(); };
  s.esperas.push(acordar);
  req.on('close', () => { clearTimeout(timer); s.esperas = s.esperas.filter((f) => f !== acordar); });
});

// PC informa o que está na tela; celular lê
router.post('/:codigo/estado', (req, res) => {
  const s = sessao(req, res); if (!s) return;
  const e = req.body || {};
  s.estado = {
    teste: Number(e.teste) || 1,
    nome: String(e.nome || '').slice(0, 60),
    rotulo: String(e.rotulo || '').slice(0, 60),
    ativo: e.ativo !== false,
  };
  res.json({ ok: true });
});
router.get('/:codigo/estado', (req, res) => {
  const s = sessao(req, res); if (!s) return;
  res.json(s.estado);
});

module.exports = router;
