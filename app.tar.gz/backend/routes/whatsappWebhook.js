/* Respostas dos pacientes no WhatsApp. A Meta chama este endereço quando alguém escreve para o número da clínica.
   "SIM" confirma o próximo agendamento, "NÃO" cancela. Qualquer outra frase recebe o contato humano. */
const express = require('express');
const crypto = require('crypto');
const pool = require('../db/pool');
const wpp = require('../utils/whatsapp');

const router = express.Router();

router.get('/webhook', (req, res) => {
  const ok = process.env.WA_VERIFY_TOKEN && req.query['hub.mode'] === 'subscribe' && req.query['hub.verify_token'] === process.env.WA_VERIFY_TOKEN;
  if (!ok) return res.sendStatus(403);
  res.status(200).send(String(req.query['hub.challenge'] || ''));
});

function assinaturaValida(req) {
  const segredo = process.env.WA_APP_SECRET;
  if (!segredo || !req.rawBody) return false;
  const esperado = 'sha256=' + crypto.createHmac('sha256', segredo).update(req.rawBody).digest('hex');
  const recebido = String(req.headers['x-hub-signature-256'] || '');
  if (esperado.length !== recebido.length) return false;
  return crypto.timingSafeEqual(Buffer.from(esperado), Buffer.from(recebido));
}

const semAcento = (t) => String(t || '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().trim();

router.post('/webhook', async (req, res) => {
  if (!assinaturaValida(req)) return res.sendStatus(403);
  res.sendStatus(200); // responde logo; a Meta repete se demorar
  try {
    for (const entrada of req.body.entry || []) {
      for (const mudanca of entrada.changes || []) {
        const v = mudanca.value || {};
        const numeroClinica = String(v.metadata?.display_phone_number || '').replace(/\D/g, '');
        for (const m of v.messages || []) {
          if (m.type !== 'text') continue;
          const de = String(m.from || '').replace(/\D/g, '');
          const fim = de.slice(-10); // DDD + número, sem o 9 extra ou o 55
          const texto = semAcento(m.text?.body);
          const quer = /^(sim|s|confirmo|confirmado|ok)\b/.test(texto) ? 'confirmado' : /^(nao|n|cancelar|cancela)\b/.test(texto) ? 'cancelado' : null;
          const clinica = await pool.query(
            `SELECT id, nome_fantasia, whatsapp_numero FROM clinicas WHERE ativa=TRUE AND RIGHT(REGEXP_REPLACE(COALESCE(whatsapp_numero,''),'\\D','','g'),10)=$1 LIMIT 1`,
            [numeroClinica.slice(-10)]);
          if (!clinica.rows.length) continue;
          const cl = clinica.rows[0];
          if (!quer) {
            await wpp.responder(de, `Olá! Aqui é a ${cl.nome_fantasia}. Para confirmar seu exame responda SIM. Para cancelar responda NÃO. Outras dúvidas, a equipe responde em horário comercial.`);
            continue;
          }
          const ag = await pool.query(
            `SELECT a.id FROM agendamentos a JOIN pacientes p ON p.id=a.paciente_id
             WHERE a.clinica_id=$1 AND a.status IN ('agendado','confirmado') AND a.data_hora > (NOW() AT TIME ZONE 'America/Sao_Paulo')
               AND RIGHT(REGEXP_REPLACE(COALESCE(p.telefone,''),'\\D','','g'),10)=$2
             ORDER BY a.data_hora LIMIT 1`, [cl.id, fim]);
          if (!ag.rows.length) { await wpp.responder(de, 'Não encontrei um exame marcado para este número. A equipe vai conferir e responder.'); continue; }
          await pool.query(`UPDATE agendamentos SET status=$1 WHERE id=$2`, [quer, ag.rows[0].id]);
          await wpp.responder(de, quer === 'confirmado' ? 'Exame confirmado. Esperamos você!' : 'Exame cancelado. Quando quiser marcar de novo, é só chamar.');
        }
      }
    }
  } catch (e) {
    console.error('Webhook do WhatsApp falhou:', e.message);
  }
});

module.exports = router;
