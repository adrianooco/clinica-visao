const express = require('express');
const pool = require('../db/pool');

const router = express.Router();

async function buscarClinicaPorSlug(slug) {
  const r = await pool.query(`SELECT * FROM clinicas WHERE slug=$1 AND ativa=TRUE`, [slug]);
  return r.rows[0] || null;
}

/* resolve a cidade/evento pelo slug (?u=) se vier na URL; sem isso, segue sem cidade (modo clínica única) */
async function buscarUnidade(clinicaId, unidadeSlug) {
  if (!unidadeSlug) return null;
  const r = await pool.query(`SELECT * FROM unidades WHERE clinica_id=$1 AND slug=$2 AND ativa=TRUE`, [clinicaId, unidadeSlug]);
  return r.rows[0] || null;
}

/* dados públicos pra montar a tela: nome, campos obrigatórios, local do exame,
   e, se a URL trouxer ?u=slug-da-cidade, os dados dessa cidade/evento específica */
router.get('/:slug/config', async (req, res) => {
  const clinica = await buscarClinicaPorSlug(req.params.slug);
  if (!clinica) return res.status(404).json({ erro: 'Clínica não encontrada.' });
  const unidade = await buscarUnidade(clinica.id, req.query.u);
  if (req.query.u && !unidade) return res.status(404).json({ erro: 'Cidade/evento não encontrado ou encerrado.' });
  res.json({
    nomeClinica: unidade ? `${clinica.nome_fantasia} · ${unidade.nome}` : clinica.nome_fantasia,
    localExame: unidade ? (unidade.local || clinica.local_exame_padrao) : clinica.local_exame_padrao,
    camposObrigatorios: clinica.campos_obrigatorios,
    linkSite: clinica.link_site,
    unidade: unidade ? { nome: unidade.nome, cidade: unidade.cidade, dataInicio: unidade.data_inicio, dataFim: unidade.data_fim } : null,
  });
});

/* autocadastro do paciente (cadastro-paciente.html) */
router.post('/:slug/pacientes', async (req, res) => {
  const clinica = await buscarClinicaPorSlug(req.params.slug);
  if (!clinica) return res.status(404).json({ erro: 'Clínica não encontrada.' });
  const unidade = await buscarUnidade(clinica.id, req.query.u);
  if (req.query.u && !unidade) return res.status(404).json({ erro: 'Cidade/evento não encontrado ou encerrado.' });
  const { nome_completo, cpf, telefone, cep, endereco, bairro, cidade, foto_receita_url, foto_armacao_url } = req.body;
  if (!nome_completo) return res.status(400).json({ erro: 'Informe o nome.' });
  const req_campos = clinica.campos_obrigatorios || {};
  if (req_campos.cpf && !cpf) return res.status(400).json({ erro: 'CPF é obrigatório.' });
  if (req_campos.telefone && !telefone) return res.status(400).json({ erro: 'Telefone é obrigatório.' });
  if (req_campos.cep && !cep) return res.status(400).json({ erro: 'CEP é obrigatório.' });
  try {
    const r = await pool.query(
      `INSERT INTO pacientes (clinica_id, unidade_id, nome_completo, cpf, telefone, cep, endereco, bairro, cidade, agendado_por, foto_receita_url, foto_armacao_url)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,'Autocadastro',$10,$11) RETURNING id`,
      [clinica.id, unidade ? unidade.id : null, nome_completo, cpf || null, telefone || null, cep || null, endereco || null, bairro || null, cidade || null, foto_receita_url || null, foto_armacao_url || null]
    );
    res.status(201).json({ ok: true, id: r.rows[0].id });
  } catch (e) {
    if (e.code === '23505') return res.status(409).json({ erro: 'Já existe um cadastro com esse CPF nesta clínica.' });
    console.error(e); res.status(500).json({ erro: 'Erro ao salvar cadastro.' });
  }
});

/* resultado do teste de visão (teste-visao.html) */
router.post('/:slug/testes-visao', async (req, res) => {
  const clinica = await buscarClinicaPorSlug(req.params.slug);
  if (!clinica) return res.status(404).json({ erro: 'Clínica não encontrada.' });
  const unidade = await buscarUnidade(clinica.id, req.query.u);
  if (req.query.u && !unidade) return res.status(404).json({ erro: 'Cidade/evento não encontrado ou encerrado.' });
  const { nome_informado, distancia_cm, menor_linha, equivalente_snellen } = req.body;
  const r = await pool.query(
    `INSERT INTO testes_visao (clinica_id, unidade_id, nome_informado, distancia_cm, menor_linha, equivalente_snellen)
     VALUES ($1,$2,$3,$4,$5,$6) RETURNING id`,
    [clinica.id, unidade ? unidade.id : null, nome_informado || null, distancia_cm || null, menor_linha || null, equivalente_snellen || null]
  );
  res.status(201).json({ ok: true, id: r.rows[0].id });
});

module.exports = router;
