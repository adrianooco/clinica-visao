const express = require('express');
const pool = require('../db/pool');
const { exigirLogin } = require('../middleware/auth');

const router = express.Router();
router.use(exigirLogin);

/* Envios programados: para cada agendamento, as mensagens que devem sair antes e depois do atendimento.
   O sistema monta o texto pronto e mostra o que está na hora de mandar. Quem atende toca em "WhatsApp",
   a conversa abre com a mensagem pronta e o envio fica registrado. Quando o WhatsApp automático estiver
   ligado (n8n), ele usa as mesmas marcações e nada se repete. */
const ETAPAS = {
  confirmacao: { coluna: 'lembrete_confirmacao_enviado', nome: 'Confirmação do agendamento', depoisDoAtendimento: false },
  '24h': { coluna: 'lembrete_24h_enviado', nome: 'Lembrete de 24 horas', depoisDoAtendimento: false },
  '2h': { coluna: 'lembrete_2h_enviado', nome: 'Lembrete de 2 horas', depoisDoAtendimento: false },
  pos_consulta: { coluna: 'lembrete_pos_consulta_enviado', nome: 'Pós atendimento', depoisDoAtendimento: true },
};

const HORA = 3600 * 1000;
const dd = (iso) => { const [y, m, d] = iso.slice(0, 10).split('-'); return `${d}/${m}/${y}`; };

function montarMensagem(etapa, a, clinicaNome) {
  const nome = (a.nome_completo || '').trim().split(/\s+/)[0];
  const data = dd(String(a.data_hora)), hora = String(a.data_hora).slice(11, 16);
  const local = a.local_final ? ` Local: ${a.local_final}.` : '';
  const evento = a.unidade_nome ? ` Evento: ${a.unidade_nome}.` : '';
  switch (etapa) {
    case 'confirmacao':
      return `Olá, ${nome}! Seu exame de vista na ${clinicaNome} está marcado.${evento} Dia ${data} às ${hora}.${local} Responda SIM para confirmar.`;
    case '24h':
      return `Olá, ${nome}! Lembrando que amanhã, dia ${data}, às ${hora}, é o seu exame de vista.${local} Responda SIM para confirmar ou NÃO para cancelar.`;
    case '2h':
      return `Olá, ${nome}! Seu exame de vista é hoje, às ${hora}.${local} Estamos esperando você.`;
    default:
      return `Olá, ${nome}! Obrigado por fazer seu exame de vista na ${clinicaNome}. Se tiver qualquer dúvida sobre sua receita ou seus óculos, é só responder esta mensagem.`;
  }
}

router.get('/', async (req, res) => {
  const params = [req.usuario.clinicaId];
  let filtro = '';
  if (req.usuario.unidadeId) { params.push(req.usuario.unidadeId); filtro = ' AND a.unidade_id=$2'; }
  const clin = await pool.query(`SELECT nome_fantasia, local_exame_padrao FROM clinicas WHERE id=$1`, [req.usuario.clinicaId]);
  const clinicaNome = clin.rows[0].nome_fantasia;

  const r = await pool.query(
    `SELECT a.id, a.data_hora, a.criado_em, a.status, a.lembrete_confirmacao_enviado, a.lembrete_24h_enviado,
            a.lembrete_2h_enviado, a.lembrete_pos_consulta_enviado,
            COALESCE(NULLIF(a.local,''), un.local, $${params.length + 1}) AS local_final,
            p.nome_completo, p.telefone, un.nome AS unidade_nome
     FROM agendamentos a
     JOIN pacientes p ON p.id = a.paciente_id
     LEFT JOIN unidades un ON un.id = a.unidade_id
     WHERE a.clinica_id=$1 AND a.status <> 'cancelado'
       AND a.data_hora BETWEEN NOW() - INTERVAL '30 days' AND NOW() + INTERVAL '90 days'${filtro}
     ORDER BY a.data_hora`,
    [...params, clin.rows[0].local_exame_padrao]
  );

  const agora = Date.now();
  const agoraLista = [], programados = [], enviados = [];
  for (const a of r.rows) {
    const consulta = new Date(a.data_hora).getTime();
    for (const [etapa, cfg] of Object.entries(ETAPAS)) {
      const base = {
        agendamento_id: a.id, etapa, etapa_nome: cfg.nome, paciente_nome: a.nome_completo, telefone: a.telefone,
        data_hora: a.data_hora, mensagem: montarMensagem(etapa, a, clinicaNome),
      };
      if (a[cfg.coluna]) { enviados.push(base); continue; }
      if (a.status === 'faltou' && cfg.depoisDoAtendimento) continue;
      let devido;
      if (etapa === 'confirmacao') devido = 0; // sai assim que o agendamento é feito
      else if (etapa === '24h') devido = consulta - 24 * HORA;
      else if (etapa === '2h') devido = consulta - 2 * HORA;
      else devido = consulta + 2 * HORA;
      base.devido_em = devido ? new Date(devido).toISOString() : null;
      if (!cfg.depoisDoAtendimento && consulta < agora) continue; // lembrete de algo que já passou não faz sentido
      if (cfg.depoisDoAtendimento && a.status === 'agendado' && consulta > agora) continue;
      (devido <= agora ? agoraLista : programados).push(base);
    }
  }
  programados.sort((x, y) => x.devido_em.localeCompare(y.devido_em));
  enviados.sort((x, y) => String(y.data_hora).localeCompare(String(x.data_hora)));
  res.json({ agora: agoraLista, programados: programados.slice(0, 200), enviados: enviados.slice(0, 100) });
});

/* registra (ou desfaz) que a mensagem foi enviada */
router.post('/:agendamentoId/marcar', async (req, res) => {
  const cfg = ETAPAS[req.body.etapa];
  if (!cfg) return res.status(400).json({ erro: 'Etapa inválida.' });
  const params = [req.body.enviado === false ? false : true, req.params.agendamentoId, req.usuario.clinicaId];
  let filtro = '';
  if (req.usuario.unidadeId) { params.push(req.usuario.unidadeId); filtro = ' AND unidade_id=$4'; }
  const r = await pool.query(`UPDATE agendamentos SET ${cfg.coluna}=$1 WHERE id=$2 AND clinica_id=$3${filtro} RETURNING id`, params);
  if (!r.rows.length) return res.status(404).json({ erro: 'Agendamento não encontrado.' });
  res.json({ ok: true });
});

module.exports = router;
