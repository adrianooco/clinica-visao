const express = require('express');
const pool = require('../db/pool');
const { exigirLogin, exigirPermissao } = require('../middleware/auth');

const router = express.Router();
router.use(exigirLogin);

/* Um usuário restrito a uma cidade só vê/edita pacientes daquela cidade.
   Sem restrição (admin itinerante), vê a clínica toda. */
function filtroUnidade(req, params, proximoIndice) {
  if (!req.usuario.unidadeId) return { sql: '', params };
  params.push(req.usuario.unidadeId);
  return { sql: ` AND unidade_id=$${proximoIndice}`, params };
}

/* agendador (atendente) só enxerga o mínimo pra marcar horário: nome e telefone.
   CPF, endereço e fotos ficam só com profissional e admin. */
const ehAgendador = (req) => req.usuario.papel === 'atendente' && !(req.usuario.permissoes || []).includes('pacientes');

router.get('/', async (req, res) => {
  const params = [req.usuario.clinicaId];
  const f = filtroUnidade(req, params, 2);
  const colunas = ehAgendador(req) ? 'id, unidade_id, nome_completo, telefone' : '*';
  const r = await pool.query(
    `SELECT ${colunas} FROM pacientes WHERE clinica_id=$1 AND deletado_em IS NULL${f.sql} ORDER BY nome_completo`,
    f.params
  );
  res.json(r.rows);
});

router.post('/', async (req, res) => {
  let { nome_completo, cpf, telefone, cep, endereco, bairro, cidade, agendado_por, foto_receita_url, foto_armacao_url, data_nascimento } = req.body;
  if (ehAgendador(req)) { cpf = cep = endereco = bairro = cidade = foto_receita_url = foto_armacao_url = data_nascimento = null; }
  if (!nome_completo) return res.status(400).json({ erro: 'Informe o nome.' });
  // quem está restrito a uma cidade sempre cadastra nessa cidade; admin pode escolher (ou deixar em branco = compartilhado)
  const unidade_id = req.usuario.unidadeId || req.body.unidade_id || null;
  try {
    const r = await pool.query(
      `INSERT INTO pacientes (clinica_id, unidade_id, nome_completo, cpf, telefone, cep, endereco, bairro, cidade, agendado_por, foto_receita_url, foto_armacao_url, data_nascimento)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13) RETURNING *`,
      [req.usuario.clinicaId, unidade_id, nome_completo, cpf || null, telefone || null, cep || null, endereco || null, bairro || null, cidade || null, agendado_por || null, foto_receita_url || null, foto_armacao_url || null, data_nascimento || null]
    );
    const novo = r.rows[0];
    res.status(201).json(ehAgendador(req) ? { id: novo.id, unidade_id: novo.unidade_id, nome_completo: novo.nome_completo, telefone: novo.telefone } : novo);
  } catch (e) {
    if (e.code === '23505') return res.status(409).json({ erro: 'Já existe um paciente com esse CPF nesta clínica.' });
    console.error(e); res.status(500).json({ erro: 'Erro ao salvar paciente.' });
  }
});

router.put('/:id', exigirPermissao('pacientes'), async (req, res) => {
  const { nome_completo, cpf, telefone, cep, endereco, bairro, cidade, agendado_por, foto_receita_url, foto_armacao_url, data_nascimento } = req.body;
  const params = [nome_completo, cpf || null, telefone || null, cep || null, endereco || null, bairro || null, cidade || null,
     agendado_por || null, foto_receita_url || null, foto_armacao_url || null, data_nascimento || null, req.params.id, req.usuario.clinicaId];
  const f = filtroUnidade(req, params, params.length + 1);
  try {
    const r = await pool.query(
      `UPDATE pacientes SET nome_completo=$1, cpf=$2, telefone=$3, cep=$4, endereco=$5, bairro=$6, cidade=$7,
        agendado_por=$8, foto_receita_url=COALESCE($9,foto_receita_url), foto_armacao_url=COALESCE($10,foto_armacao_url), data_nascimento=$11
       WHERE id=$12 AND clinica_id=$13 AND deletado_em IS NULL${f.sql} RETURNING *`,
      f.params
    );
    if (!r.rows.length) return res.status(404).json({ erro: 'Paciente não encontrado.' });
    res.json(r.rows[0]);
  } catch (e) {
    if (e.code === '23505') return res.status(409).json({ erro: 'Já existe um paciente com esse CPF nesta clínica.' });
    console.error(e); res.status(500).json({ erro: 'Erro ao atualizar paciente.' });
  }
});

/* soft delete: nunca apaga fisicamente o prontuário */
router.delete('/:id', exigirPermissao('pacientes'), async (req, res) => {
  const params = [req.params.id, req.usuario.clinicaId];
  const f = filtroUnidade(req, params, params.length + 1);
  const r = await pool.query(
    `UPDATE pacientes SET deletado_em = NOW() WHERE id=$1 AND clinica_id=$2${f.sql} RETURNING id`,
    f.params
  );
  if (!r.rows.length) return res.status(404).json({ erro: 'Paciente não encontrado.' });
  res.json({ ok: true });
});

module.exports = router;
