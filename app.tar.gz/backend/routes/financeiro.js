const express = require('express');
const pool = require('../db/pool');
const { exigirLogin, exigirAdmin } = require('../middleware/auth');

const router = express.Router();
router.use(exigirLogin);
router.use(exigirAdmin); // dinheiro da clínica: só administrador
router.use((req, res, next) => {
  // administrador preso a uma cidade/evento não vê o dinheiro da clínica inteira
  if (req.usuario.unidadeId) return res.status(403).json({ erro: 'O financeiro só abre para o administrador geral.' });
  next();
});

const FORMAS = ['dinheiro', 'pix', 'debito', 'credito', 'convenio'];

function periodo(req) {
  const hoje = new Date();
  const ini = new Date(hoje.getFullYear(), hoje.getMonth(), 1);
  const fim = new Date(hoje.getFullYear(), hoje.getMonth() + 1, 0);
  const f = (d) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  return [req.query.de || f(ini), req.query.ate || f(fim)];
}

/* Recebíveis do período: atendimentos sem cobrança, a receber e recebidos */
router.get('/recebiveis', async (req, res) => {
  const [de, ate] = periodo(req);
  const base = `SELECT a.id AS agendamento_id, a.data_hora, a.status AS situacao, p.nome_completo AS paciente_nome, t.nome AS tipo_nome, t.preco_padrao,
      un.nome AS unidade_nome, o.nome AS otica_nome,
      pg.id AS pagamento_id, pg.valor, pg.forma, pg.status, pg.pago_em, cv.nome AS convenio_nome
    FROM agendamentos a
    JOIN pacientes p ON p.id = a.paciente_id
    LEFT JOIN tipos_atendimento t ON t.id = a.tipo_atendimento_id
    LEFT JOIN unidades un ON un.id = a.unidade_id
    LEFT JOIN oticas_parceiras o ON o.id = a.otica_parceira_id
    LEFT JOIN pagamentos pg ON pg.agendamento_id = a.id
    LEFT JOIN convenios cv ON cv.id = pg.convenio_id
    WHERE a.clinica_id=$1 AND a.status <> 'cancelado' AND a.data_hora::date BETWEEN $2 AND $3`;
  const r = await pool.query(`${base} ORDER BY a.data_hora DESC`, [req.usuario.clinicaId, de, ate]);
  res.json({
    de, ate,
    sem_cobranca: r.rows.filter((x) => !x.pagamento_id),
    a_receber: r.rows.filter((x) => x.pagamento_id && x.status === 'pendente'),
    recebidos: r.rows.filter((x) => x.pagamento_id && x.status === 'pago'),
  });
});

/* cria ou atualiza a cobrança de um atendimento */
router.post('/pagamentos', async (req, res) => {
  const { agendamento_id, valor, forma, convenio_id, pago } = req.body;
  const v = Number(String(valor).replace(',', '.'));
  if (!agendamento_id || isNaN(v) || v < 0) return res.status(400).json({ erro: 'Informe o atendimento e um valor válido.' });
  if (forma && !FORMAS.includes(forma)) return res.status(400).json({ erro: 'Forma de pagamento inválida.' });
  const ag = await pool.query(`SELECT id FROM agendamentos WHERE id=$1 AND clinica_id=$2`, [agendamento_id, req.usuario.clinicaId]);
  if (!ag.rows.length) return res.status(404).json({ erro: 'Atendimento não encontrado.' });
  let conv = null;
  if (convenio_id) { const c = await pool.query(`SELECT id FROM convenios WHERE id=$1 AND clinica_id=$2`, [convenio_id, req.usuario.clinicaId]); conv = c.rows[0]?.id || null; }
  const r = await pool.query(
    `INSERT INTO pagamentos (clinica_id, agendamento_id, valor, forma, convenio_id, status, pago_em)
     VALUES ($1,$2,$3,$4,$5,$6::varchar, CASE WHEN $6::varchar='pago' THEN CURRENT_DATE END)
     ON CONFLICT (agendamento_id) DO UPDATE SET valor=EXCLUDED.valor, forma=EXCLUDED.forma, convenio_id=EXCLUDED.convenio_id,
       status=EXCLUDED.status, pago_em=CASE WHEN EXCLUDED.status='pago' THEN COALESCE(pagamentos.pago_em, CURRENT_DATE) END
     RETURNING *`,
    [req.usuario.clinicaId, agendamento_id, v, forma || null, conv, pago ? 'pago' : 'pendente']
  );
  res.status(201).json(r.rows[0]);
});

router.patch('/pagamentos/:id/pagar', async (req, res) => {
  const desfazer = req.body.pago === false;
  const forma = req.body.forma && FORMAS.includes(req.body.forma) ? req.body.forma : null;
  const r = await pool.query(
    `UPDATE pagamentos SET status=$1::varchar, pago_em=CASE WHEN $1::varchar='pago' THEN CURRENT_DATE END, forma=COALESCE($2, forma)
     WHERE id=$3 AND clinica_id=$4 RETURNING id`,
    [desfazer ? 'pendente' : 'pago', forma, req.params.id, req.usuario.clinicaId]
  );
  if (!r.rows.length) return res.status(404).json({ erro: 'Cobrança não encontrada.' });
  res.json({ ok: true });
});

router.delete('/pagamentos/:id', async (req, res) => {
  const r = await pool.query(`DELETE FROM pagamentos WHERE id=$1 AND clinica_id=$2 RETURNING id`, [req.params.id, req.usuario.clinicaId]);
  if (!r.rows.length) return res.status(404).json({ erro: 'Cobrança não encontrada.' });
  res.json({ ok: true });
});

/* contas a pagar */
router.get('/contas', async (req, res) => {
  const r = await pool.query(`SELECT id, descricao, valor, vencimento, pago, pago_em FROM contas_pagar WHERE clinica_id=$1 ORDER BY pago, vencimento`, [req.usuario.clinicaId]);
  res.json(r.rows);
});
router.post('/contas', async (req, res) => {
  const { descricao, valor, vencimento } = req.body;
  const v = Number(String(valor).replace(',', '.'));
  if (!descricao || isNaN(v) || v < 0 || !vencimento) return res.status(400).json({ erro: 'Informe descrição, valor e vencimento.' });
  const r = await pool.query(`INSERT INTO contas_pagar (clinica_id, descricao, valor, vencimento) VALUES ($1,$2,$3,$4) RETURNING *`, [req.usuario.clinicaId, descricao, v, vencimento]);
  res.status(201).json(r.rows[0]);
});
router.patch('/contas/:id/pagar', async (req, res) => {
  const desfazer = req.body.pago === false;
  const r = await pool.query(`UPDATE contas_pagar SET pago=$1::boolean, pago_em=CASE WHEN $1::boolean THEN CURRENT_DATE END WHERE id=$2 AND clinica_id=$3 RETURNING id`, [!desfazer, req.params.id, req.usuario.clinicaId]);
  if (!r.rows.length) return res.status(404).json({ erro: 'Conta não encontrada.' });
  res.json({ ok: true });
});
router.delete('/contas/:id', async (req, res) => {
  const r = await pool.query(`DELETE FROM contas_pagar WHERE id=$1 AND clinica_id=$2 RETURNING id`, [req.params.id, req.usuario.clinicaId]);
  if (!r.rows.length) return res.status(404).json({ erro: 'Conta não encontrada.' });
  res.json({ ok: true });
});

/* resumo do período */
router.get('/resumo', async (req, res) => {
  const [de, ate] = periodo(req);
  const id = req.usuario.clinicaId;
  const q = (sql, p) => pool.query(sql, p).then((r) => r.rows);
  const filtroAg = `FROM pagamentos pg JOIN agendamentos a ON a.id = pg.agendamento_id WHERE pg.clinica_id=$1 AND a.data_hora::date BETWEEN $2 AND $3`;
  const [tot] = await q(
    `SELECT COALESCE(SUM(pg.valor) FILTER (WHERE pg.status='pendente'),0)::float AS a_receber,
            COUNT(*) FILTER (WHERE pg.status='pendente')::int AS n_a_receber,
            COALESCE(SUM(pg.valor) FILTER (WHERE pg.status='pago'),0)::float AS recebido,
            COUNT(*) FILTER (WHERE pg.status='pago')::int AS n_recebido ${filtroAg}`, [id, de, ate]);
  const porForma = await q(`SELECT COALESCE(pg.forma,'sem informar') AS nome, SUM(pg.valor)::float AS total, COUNT(*)::int AS qtd ${filtroAg} AND pg.status='pago' GROUP BY 1 ORDER BY 2 DESC`, [id, de, ate]);
  const porOtica = await q(`SELECT COALESCE(o.nome,'sem ótica') AS nome, SUM(pg.valor)::float AS total, COUNT(*)::int AS qtd ${filtroAg.replace('WHERE','LEFT JOIN oticas_parceiras o ON o.id = a.otica_parceira_id WHERE')} AND pg.status='pago' GROUP BY 1 ORDER BY 2 DESC`, [id, de, ate]);
  const porConv = await q(`SELECT COALESCE(c.nome,'particular') AS nome, SUM(pg.valor)::float AS total, COUNT(*)::int AS qtd ${filtroAg.replace('WHERE','LEFT JOIN convenios c ON c.id = pg.convenio_id WHERE')} AND pg.status='pago' GROUP BY 1 ORDER BY 2 DESC`, [id, de, ate]);
  const [contas] = await q(
    `SELECT COALESCE(SUM(valor) FILTER (WHERE NOT pago),0)::float AS a_pagar, COALESCE(SUM(valor) FILTER (WHERE pago),0)::float AS pago
     FROM contas_pagar WHERE clinica_id=$1 AND vencimento BETWEEN $2 AND $3`, [id, de, ate]);
  res.json({ de, ate, ...tot, por_forma: porForma, por_otica: porOtica, por_convenio: porConv, contas_a_pagar: contas.a_pagar, contas_pagas: contas.pago, saldo: tot.recebido - contas.pago });
});

module.exports = router;
