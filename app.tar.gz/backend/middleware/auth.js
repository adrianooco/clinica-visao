const jwt = require('jsonwebtoken');

const crypto = require('crypto');
/* compara chaves sem revelar, pelo tempo de resposta, quantas letras acertou */
function iguais(a, b) {
  const x = crypto.createHash('sha256').update(String(a || '')).digest();
  const y = crypto.createHash('sha256').update(String(b || '')).digest();
  return crypto.timingSafeEqual(x, y);
}

const SEGREDO = process.env.JWT_SECRET || 'troque-este-segredo-em-producao';

/* Confere no banco se o usuário continua ativo e com o mesmo papel. Guarda o resultado por 30 segundos
   para não pesar. Assim, desativar alguém vale em até 30 segundos, e não em 12 horas. */
const cacheUsuarios = new Map();
const CACHE_MS = 30 * 1000;
async function usuarioAtual(id) {
  const c = cacheUsuarios.get(id);
  if (c && Date.now() - c.em < CACHE_MS) return c.dados;
  const pool = require('../db/pool');
  const r = await pool.query(`SELECT id, clinica_id, unidade_id, papel, nome, permissoes, ativo FROM usuarios WHERE id=$1`, [id]);
  const dados = r.rows[0] && r.rows[0].ativo ? r.rows[0] : null;
  cacheUsuarios.set(id, { em: Date.now(), dados });
  return dados;
}
function limparCacheUsuario(id) { if (id) cacheUsuarios.delete(id); else cacheUsuarios.clear(); }
setInterval(() => { const a = Date.now(); for (const [k, v] of cacheUsuarios) if (a - v.em > CACHE_MS) cacheUsuarios.delete(k); }, 60000).unref();

/* Quais partes do sistema entram no registro de acessos (quem abriu ou mexeu em dado de saúde) */
const AREAS_REGISTRADAS = { '/pacientes': 'paciente', '/prontuarios': 'prontuario', '/receitas': 'receita', '/testes-visao': 'teste_visao', '/financeiro': 'financeiro' };

function registrarAcesso(req, res) {
  const area = AREAS_REGISTRADAS[req.baseUrl];
  if (!area) return;
  res.on('finish', () => {
    if (res.statusCode >= 400) return;
    const pool = require('../db/pool');
    const u = req.usuario;
    pool.query(
      `INSERT INTO acessos_log (clinica_id, usuario_id, usuario_nome, acao, area, caminho, ip) VALUES ($1,$2,$3,$4,$5,$6,$7)`,
      [u.clinicaId, u.usuarioId, u.nome || null, req.method, area, String(req.originalUrl).slice(0, 200), req.ip]
    ).catch(() => {});
  });
}

/* Exige login: usado nas rotas administrativas (modulo-agendamento.html) */
async function exigirLogin(req, res, next) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;
  if (!token) return res.status(401).json({ erro: 'Faça login para continuar.' });
  let dados;
  try {
    dados = jwt.verify(token, SEGREDO);
  } catch (e) {
    return res.status(401).json({ erro: 'Sessão expirada ou inválida. Faça login de novo.' });
  }
  try {
    const atual = await usuarioAtual(dados.usuarioId);
    if (!atual) return res.status(401).json({ erro: 'Este acesso foi desativado. Fale com o administrador.' });
    // papel, cidade e permissões valem os do banco, não os que ficaram dentro do token
    req.usuario = { ...dados, clinicaId: atual.clinica_id, unidadeId: atual.unidade_id || null, papel: atual.papel, nome: atual.nome,
      permissoes: Array.isArray(atual.permissoes) ? atual.permissoes : [] };
    registrarAcesso(req, res);
    next();
  } catch (e) {
    console.error(e);
    return res.status(500).json({ erro: 'Erro ao conferir o acesso.' });
  }
}

/* Algumas ações (excluir, configurar) exigem papel admin */
function exigirAdmin(req, res, next) {
  if (req.usuario?.papel !== 'admin') {
    return res.status(403).json({ erro: 'Só o administrador da clínica pode fazer isso.' });
  }
  next();
}

/* Prontuário é clínico: só quem tem papel 'profissional' ou 'admin' pode ver/escrever.
   Atendente (papel 'atendente') nunca passa daqui, mesmo que veja o paciente
   normalmente nas outras telas. */
function exigirProfissional(req, res, next) {
  if (req.usuario?.papel !== 'profissional' && req.usuario?.papel !== 'admin') {
    return res.status(403).json({ erro: 'Seu acesso não permite abrir essa parte do sistema.' });
  }
  next();
}

/* Admin e profissional sempre passam. O agendador (atendente) só passa se o
   administrador liberou essa chave na tela de Acessos (ex: 'receita', 'pacientes'). */
function exigirPermissao(chave) {
  return (req, res, next) => {
    const p = req.usuario?.papel;
    if (p === 'admin' || p === 'profissional') return next();
    if (p === 'atendente' && Array.isArray(req.usuario.permissoes) && req.usuario.permissoes.includes(chave)) return next();
    return res.status(403).json({ erro: 'Seu acesso não permite abrir essa parte do sistema.' });
  };
}

function gerarToken(usuario) {
  return jwt.sign(
    { usuarioId: usuario.id, clinicaId: usuario.clinica_id, unidadeId: usuario.unidade_id || null, papel: usuario.papel, nome: usuario.nome,
      permissoes: Array.isArray(usuario.permissoes) ? usuario.permissoes : [] },
    SEGREDO,
    { expiresIn: '12h' }
  );
}

/* Pra integrações externas (ex: assistente de WhatsApp): autentica pela chave
   de integração da clínica (header x-chave-integracao), não por login de
   funcionário. Resolve a clínica pelo :slug da URL e prende em req.clinicaIntegracao. */
async function exigirChaveIntegracao(req, res, next) {
  const pool = require('../db/pool');
  const chave = String(req.headers['x-chave-integracao'] || '');
  if (!chave) return res.status(401).json({ erro: 'Informe a chave de integração no cabeçalho x-chave-integracao.' });
  const r = await pool.query(`SELECT * FROM clinicas WHERE slug=$1 AND ativa=TRUE`, [req.params.slug]);
  if (!r.rows.length) return res.status(404).json({ erro: 'Clínica não encontrada.' });
  if (!iguais(r.rows[0].chave_integracao, chave)) return res.status(401).json({ erro: 'Chave de integração inválida.' });
  req.clinicaIntegracao = r.rows[0];
  next();
}

module.exports = { exigirLogin, exigirAdmin, exigirProfissional, exigirPermissao, exigirChaveIntegracao, gerarToken, limparCacheUsuario, SEGREDO };
