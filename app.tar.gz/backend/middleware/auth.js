const jwt = require('jsonwebtoken');

const SEGREDO = process.env.JWT_SECRET || 'troque-este-segredo-em-producao';

/* Exige login: usado nas rotas administrativas (modulo-agendamento.html) */
function exigirLogin(req, res, next) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;
  if (!token) return res.status(401).json({ erro: 'Faça login para continuar.' });
  try {
    const dados = jwt.verify(token, SEGREDO);
    req.usuario = dados; // { usuarioId, clinicaId, papel }
    next();
  } catch (e) {
    return res.status(401).json({ erro: 'Sessão expirada ou inválida. Faça login de novo.' });
  }
}

/* Algumas ações (excluir, configurar) exigem papel admin */
function exigirAdmin(req, res, next) {
  if (req.usuario?.papel !== 'admin') {
    return res.status(403).json({ erro: 'Só o administrador da clínica pode fazer isso.' });
  }
  next();
}

/* Prontuário é clínico: só quem tem papel 'profissional' ou 'admin' pode ver/escrever.
   Atendente (papel 'atendente') nunca passa daqui, mesmo que veja o paciente
   normalmente nas outras telas. */
function exigirProfissional(req, res, next) {
  if (req.usuario?.papel !== 'profissional' && req.usuario?.papel !== 'admin') {
    return res.status(403).json({ erro: 'Seu acesso não permite abrir essa parte do sistema.' });
  }
  next();
}

/* Admin e profissional sempre passam. O agendador (atendente) só passa se o
   administrador liberou essa chave na tela de Acessos (ex: 'receita', 'pacientes'). */
function exigirPermissao(chave) {
  return (req, res, next) => {
    const p = req.usuario?.papel;
    if (p === 'admin' || p === 'profissional') return next();
    if (p === 'atendente' && Array.isArray(req.usuario.permissoes) && req.usuario.permissoes.includes(chave)) return next();
    return res.status(403).json({ erro: 'Seu acesso não permite abrir essa parte do sistema.' });
  };
}

function gerarToken(usuario) {
  return jwt.sign(
    { usuarioId: usuario.id, clinicaId: usuario.clinica_id, unidadeId: usuario.unidade_id || null, papel: usuario.papel, nome: usuario.nome,
      permissoes: Array.isArray(usuario.permissoes) ? usuario.permissoes : [] },
    SEGREDO,
    { expiresIn: '12h' }
  );
}

/* Pra integrações externas (ex: assistente de WhatsApp): autentica pela chave
   de integração da clínica (header x-chave-integracao), não por login de
   funcionário. Resolve a clínica pelo :slug da URL e prende em req.clinicaIntegracao. */
async function exigirChaveIntegracao(req, res, next) {
  const pool = require('../db/pool');
  const chave = req.headers['x-chave-integracao'];
  if (!chave) return res.status(401).json({ erro: 'Informe a chave de integração no cabeçalho x-chave-integracao.' });
  const r = await pool.query(`SELECT * FROM clinicas WHERE slug=$1 AND ativa=TRUE`, [req.params.slug]);
  if (!r.rows.length) return res.status(404).json({ erro: 'Clínica não encontrada.' });
  if (r.rows[0].chave_integracao !== chave) return res.status(401).json({ erro: 'Chave de integração inválida.' });
  req.clinicaIntegracao = r.rows[0];
  next();
}

module.exports = { exigirLogin, exigirAdmin, exigirProfissional, exigirPermissao, exigirChaveIntegracao, gerarToken, SEGREDO };
