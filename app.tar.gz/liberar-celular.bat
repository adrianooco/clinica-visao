@echo off
title Liberar o celular na rede
:: Pede permissao de administrador, se ainda nao tiver
net session >nul 2>&1
if %errorlevel% neq 0 (
  echo Vai aparecer uma pergunta do Windows. Clique em Sim.
  powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
  exit /b
)
echo Liberando a porta 3000 para o celular...
netsh advfirewall firewall delete rule name="Clinica de Visao" >nul 2>&1
netsh advfirewall firewall add rule name="Clinica de Visao" dir=in action=allow protocol=TCP localport=3000 profile=private,public >nul
if errorlevel 1 (
  echo Nao consegui liberar. Fale com o suporte.
  pause
  exit /b 1
)
echo.
echo Pronto. Agora o celular, no mesmo Wi-Fi, consegue abrir o controle do teste.
echo.
pause
