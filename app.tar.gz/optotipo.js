/* Optotipo na tela: 19 testes, atalhos de teclado, tela cheia e controle pelo celular.
   Usa do sistema principal: tt (calibração e distância), alturaMm(), api(), API_BASE, toast(), erroApi(). */
(function(){
  const LETRAS = ['C','D','H','K','N','O','R','S','V','Z'];
  const DIGITOS = ['2','3','4','5','6','8','9'];
  const LIN = [200,100,70,50,40,30,25,20,15,10];
  const NOMES = ['Letras','Números','E direcional','C de Landolt','Cores','Duocromo','Dial astigmático','Luzes de Worth','Desenhos','Amsler','Fixação','Leitura de perto (Jaeger)','Contraste','Educação ocular','Cruz de afinamento','Contraste por letras','Tabela de letras ETDRS','Amsler vermelho','Tabela de Snellen'];
  const TOTAL = NOMES.length;
  const COM_ACUIDADE = [1,2,3,4,9,19];
  const COM_ESPELHO = [1,2,3,4,6,9,13,16,17,19];
  const SNELLEN = ['E','FP','TOZ','LPED','PECFD','EDFCZP','FELOPZD','DEFPOTEC','LEFODPCT','FDPLTCEO'];
  const FORMAS = ['circulo','quadrado','triangulo','estrela','coracao','casa'];
  const PLACAS = [['12',true],['8'],['29'],['5'],['3'],['15'],['74'],['6'],['16'],['73'],['26']];
  const TECLAS_TESTE = { '1':1,'2':2,'3':3,'4':4,'5':5,'6':6,'7':7,'8':8,'9':9,'0':10, f:11, c:13, x:15, '+':15, d:7, a:10, j:12, e:14, b:6, p:16, l:17, r:18, s:19 };

  let O = null; // estado do optotipo aberto

  function sorteia(pool, n, prev){
    const s = [];
    for(let i=0;i<n;i++){
      let c, t = 0;
      do{ c = pool[Math.floor(Math.random()*pool.length)]; t++; }
      while(t<40 && ((i>0 && c===s[i-1]) || (prev && c===prev[i])));
      s.push(c);
    }
    return s;
  }
  function novaSequencia(){
    const n = 5, ant = O.seq;
    if(O.t===3) O.seq = sorteia([0,90,180,270], n, ant);
    else if(O.t===4) O.seq = sorteia([0,45,90,135,180,225,270,315], n, ant);
    else if(O.t===2) O.seq = sorteia(DIGITOS, n, ant);
    else if(O.t===9) O.seq = sorteia(FORMAS, n, ant);
    else O.seq = sorteia(LETRAS, n, ant);
  }
  function estilo(){
    if(document.getElementById('optoCss')) return;
    const s = document.createElement('style'); s.id = 'optoCss';
    s.textContent = `
    #opto{position:fixed;inset:0;z-index:9999;background:#fff;color:#000;font-family:Arial,Helvetica,sans-serif;display:flex;flex-direction:column;overflow:hidden;}
    #opto.escuro{background:#1b1d1f;color:#fff;}
    #opPalco{flex:1;display:flex;align-items:center;justify-content:center;overflow:hidden;padding-bottom:70px;}
    #opPalco.rola{overflow:auto;align-items:flex-start;}
    #opRodape{position:absolute;left:0;right:0;bottom:12px;display:flex;justify-content:center;align-items:center;gap:18px;pointer-events:none;}
    #opBarra{pointer-events:auto;display:flex;align-items:center;gap:2px;background:rgba(236,239,241,.96);border-radius:999px;padding:5px 10px;box-shadow:0 1px 6px rgba(0,0,0,.25);}
    #opBarra button{border:0;background:transparent;color:#37474f;min-width:30px;height:30px;border-radius:50%;font:600 13px Arial,sans-serif;cursor:pointer;padding:0 4px;}
    #opBarra button:hover{background:#cfd8dc;}
    #opBarra button.on{background:#1e88e5;color:#fff;}
    #opBarra .sep{width:10px;}
    #opRot{font:700 22px Arial,sans-serif;color:#555;pointer-events:none;}
    #opto.escuro #opRot{color:#ddd;}
    #opCel{position:absolute;top:14px;right:14px;border:0;border-radius:999px;background:#1e88e5;color:#fff;font:700 14px Arial,sans-serif;padding:9px 16px;cursor:pointer;box-shadow:0 1px 4px rgba(0,0,0,.3);}
    #opAviso{position:absolute;top:14px;left:50%;transform:translateX(-50%);background:#263238;color:#fff;padding:8px 14px;border-radius:8px;font:14px Arial,sans-serif;opacity:0;transition:opacity .3s;pointer-events:none;}
    .opDlg{position:absolute;inset:0;background:rgba(0,0,0,.45);display:flex;align-items:center;justify-content:center;z-index:5;}
    .opDlg > div{background:#fff;color:#111;border-radius:14px;padding:20px 24px;max-width:560px;max-height:88vh;overflow:auto;font:14px/1.45 Arial,sans-serif;box-shadow:0 8px 30px rgba(0,0,0,.4);}
    .opDlg h3{margin:0 0 8px;font-size:20px;font-family:Arial,Helvetica,sans-serif;} .opDlg p{margin:6px 0;}
    .opDlg button.fechar{margin-top:12px;border:0;border-radius:8px;background:#1e88e5;color:#fff;font:700 14px Arial;padding:9px 18px;cursor:pointer;}
    .opDlg code{background:#eceff1;padding:1px 6px;border-radius:4px;font-weight:700;}
    .opCol{display:grid;grid-template-columns:1fr 1fr;gap:2px 22px;}
    .opCard{background:#fff;border-radius:10px;padding:10px 12px;box-shadow:0 1px 4px rgba(0,0,0,.15);text-align:left;}
    .opCard b{display:block;font-size:15px;} .opCard span{font-size:13px;color:#555;}
    `;
    document.head.appendChild(s);
  }

  /* ---------- desenhos ---------- */
  const px = den => Math.min(alturaMm(den)*tt.pxmm, 99999);
  function tamanho(){
    const pw = O.palco.clientWidth, ph = O.palco.clientHeight - 80;
    const h = Math.min(px(LIN[O.linha]), ph*0.8, pw*0.85);
    const n = Math.max(1, Math.min(5, Math.floor(pw/(h*1.9))));
    return { h, n, pw, ph };
  }
  function linha(itens, h, fn){
    return `<div style="white-space:nowrap;display:flex;align-items:center;justify-content:center;gap:${h*0.5}px;">${itens.map(fn).join('')}</div>`;
  }
  const svgE = (h,rot)=>`<svg viewBox="0 0 5 5" width="${h}" height="${h}" style="display:block;transform:rotate(${rot}deg)"><path fill="#000" d="M0 0h5v1H1v1h3v1H1v1h4v1H0z"/></svg>`;
  const svgC = (h,rot)=>`<svg viewBox="-2.5 -2.5 5 5" width="${h}" height="${h}" style="display:block;overflow:visible;transform:rotate(${rot}deg)"><defs><mask id="mC${rot}" maskUnits="userSpaceOnUse" x="-3" y="-3" width="6" height="6"><rect x="-3" y="-3" width="6" height="6" fill="#fff"/><rect x="0" y="-.5" width="3" height="1" fill="#000"/></mask></defs><circle r="2" fill="none" stroke="#000" stroke-width="1" mask="url(#mC${rot})"/></svg>`;
  function svgForma(k,h){
    const f = {
      circulo:'<circle cx="50" cy="50" r="40"/>',
      quadrado:'<rect x="12" y="12" width="76" height="76"/>',
      triangulo:'<polygon points="50,10 90,86 10,86"/>',
      estrela:'<polygon points="50,8 61,38 93,38 67,57 77,89 50,69 23,89 33,57 7,38 39,38"/>',
      coracao:'<path d="M50 88C8 58 12 20 36 20c8 0 12 6 14 10 2-4 6-10 14-10 24 0 28 38-14 68z"/>',
      casa:'<polygon points="50,10 92,48 80,48 80,88 20,88 20,48 8,48"/>'
    }[k];
    return `<svg viewBox="0 0 100 100" width="${h}" height="${h}" style="display:block;" fill="none" stroke="#000" stroke-width="${Math.max(5,9)}" stroke-linejoin="round">${f}</svg>`;
  }

  // placas de cores (feitas na hora, sem usar as placas oficiais)
  function sementeRng(a){ return function(){ a|=0; a=a+0x6D2B79F5|0; let t=Math.imul(a^a>>>15,1|a); t=t+Math.imul(t^t>>>7,61|t)^t; return((t^t>>>14)>>>0)/4294967296; }; }
  const cachePlaca = {};
  function placaCanvas(i){
    if(cachePlaca[i]) return cachePlaca[i];
    const [num, demo] = PLACAS[i], S = 600, R = S/2-6, rng = sementeRng(1000+i*77);
    const m = document.createElement('canvas'); m.width = m.height = S;
    const mc = m.getContext('2d'); mc.fillStyle = '#000'; mc.fillRect(0,0,S,S);
    mc.fillStyle = '#fff'; mc.textAlign = 'center'; mc.textBaseline = 'middle';
    mc.font = `900 ${S*(num.length>1?0.5:0.68)}px "Arial Black",Arial,sans-serif`; mc.fillText(num, S/2, S/2+S*0.03);
    mc.strokeStyle = '#fff'; mc.lineWidth = S*0.05; mc.lineJoin = 'round'; mc.strokeText(num, S/2, S/2+S*0.03);
    const dados = mc.getImageData(0,0,S,S).data;
    const fig = demo ? ['#1f5f8b','#2e78a8','#3b86b8'] : ['#e8793a','#f09a52','#d9603a','#f2a65e'];
    const fun = demo ? ['#f1d08a','#e9c070','#f6dca0'] : ['#8fb04a','#a8c15e','#7c9c3d','#b9c97a','#9bb855'];
    const c = document.createElement('canvas'); c.width = c.height = S;
    const g = c.getContext('2d'), pts = [];
    const CEL = 24, grade = {};
    for(let t=0;t<30000;t++){
      const r = 3.5 + rng()*6, a = rng()*Math.PI*2, d = Math.sqrt(rng())*(R-r);
      const x = S/2+Math.cos(a)*d, y = S/2+Math.sin(a)*d;
      const cx = Math.floor(x/CEL), cy = Math.floor(y/CEL);
      let ok = true;
      for(let i=cx-1;i<=cx+1 && ok;i++) for(let j=cy-1;j<=cy+1 && ok;j++){
        const l = grade[i+','+j]; if(!l) continue;
        for(const p of l){ const dx = p[0]-x, dy = p[1]-y, rr = p[2]+r+1; if(dx*dx+dy*dy < rr*rr){ ok = false; break; } }
      }
      if(ok){ const q = [x,y,r]; pts.push(q); (grade[cx+','+cy] = grade[cx+','+cy] || []).push(q); }
    }
    pts.forEach(([x,y,r])=>{
      const dentro = dados[(Math.round(y)*S+Math.round(x))*4] > 128;
      const pal = dentro ? fig : fun;
      g.fillStyle = pal[Math.floor(rng()*pal.length)];
      g.beginPath(); g.arc(x,y,r,0,Math.PI*2); g.fill();
    });
    return cachePlaca[i] = c;
  }

  function dialSvg(s){
    const cx = 0, cy = 0, r0 = s*0.06, r1 = s*0.4;
    let o = `<svg viewBox="${-s*0.56} ${-s*0.56} ${s*1.12} ${s*1.12}" width="${s}" height="${s}" style="font-family:Arial,sans-serif;">`;
    for(let k=0;k<24;k++){
      const a = k*15*Math.PI/180;
      o += `<line x1="${Math.sin(a)*r0}" y1="${-Math.cos(a)*r0}" x2="${Math.sin(a)*r1}" y2="${-Math.cos(a)*r1}" stroke="#000" stroke-width="${s*0.006}" stroke-linecap="round"/>`;
    }
    for(let k=0;k<24;k++){
      const a = k*15*Math.PI/180, ang = (k*15)%180 || 180, hora = k%2===0;
      if(hora){
        const h = k/2||12;
        o += `<text x="${Math.sin(a)*s*0.45}" y="${-Math.cos(a)*s*0.45}" font-size="${s*0.05}" font-weight="700" text-anchor="middle" dominant-baseline="central" fill="#000">${h}</text>`;
        o += `<text x="${Math.sin(a)*s*0.495}" y="${-Math.cos(a)*s*0.495}" font-size="${s*0.022}" text-anchor="middle" dominant-baseline="central" fill="#888">${ang}°</text>`;
      } else {
        o += `<text x="${Math.sin(a)*s*0.43}" y="${-Math.cos(a)*s*0.43}" font-size="${s*0.022}" text-anchor="middle" dominant-baseline="central" fill="#888">${ang}°</text>`;
      }
    }
    return o + '</svg>';
  }


  function rnd(seed){ let a=seed>>>0; return function(){ a|=0; a=a+0x6D2B79F5|0; let t=Math.imul(a^a>>>15,1|a); t=t+Math.imul(t^t>>>7,61|t)^t; return ((t^t>>>14)>>>0)/4294967296; }; }
  const bez=(t,p0,p1,p2,p3)=>{ const u=1-t; return [u*u*u*p0[0]+3*u*u*t*p1[0]+3*u*t*t*p2[0]+t*t*t*p3[0], u*u*u*p0[1]+3*u*u*t*p1[1]+3*u*t*t*p2[1]+t*t*t*p3[1]]; };
  function olhoFrenteSvg(){
    const R = rnd(7);
    const A=[[150,168],[215,90],[290,66],[345,66]], B=[[345,66],[410,66],[475,100],[515,152]];   // pálpebra superior
    const C=[[515,152],[480,205],[410,228],[345,228]], D=[[345,228],[270,228],[200,215],[150,168]]; // pálpebra inferior
    const sup = u => u<0.5 ? bez(u*2,...A) : bez((u-0.5)*2,...B);
    const inf = u => u<0.5 ? bez(u*2,...C) : bez((u-0.5)*2,...D);
    const norm = (f,u,dir)=>{ const p=f(Math.max(0,u-0.01)), q=f(Math.min(1,u+0.01)); let tx=q[0]-p[0], ty=q[1]-p[1]; const m=Math.hypot(tx,ty)||1; tx/=m; ty/=m; return [ty*dir, -tx*dir, tx, ty]; };
    const cx=338, cy=150, ri=60, rp=23;
    // íris: fibras radiais
    let fib='';
    for(let i=0;i<220;i++){
      const an=R()*Math.PI*2, r1=rp+4+R()*8, r2=ri-3-R()*10, w=0.6+R()*1.6;
      const cols=['#d9a35a','#b27a36','#8c5a24','#c98f45','#6e4318','#e8c27f','#5a3512'];
      const c=cols[Math.floor(R()*cols.length)], wob=(R()-0.5)*5;
      fib+=`<path d="M${cx+Math.cos(an)*r1} ${cy+Math.sin(an)*r1} Q${cx+Math.cos(an+wob/60)*(r1+r2)/2} ${cy+Math.sin(an+wob/60)*(r1+r2)/2} ${cx+Math.cos(an)*r2} ${cy+Math.sin(an)*r2}" stroke="${c}" stroke-width="${w.toFixed(2)}" fill="none" opacity="${(0.35+R()*0.5).toFixed(2)}"/>`;
    }
    let colar=''; for(let i=0;i<=36;i++){ const an=i/36*Math.PI*2, r=rp+13+(i%2?3:-2); colar+=(i?'L':'M')+(cx+Math.cos(an)*r).toFixed(1)+' '+(cy+Math.sin(an)*r).toFixed(1); }
    // veias da esclera
    let veias='';
    for(let i=0;i<16;i++){
      const left=i<8, x0=left?152+R()*20:512-R()*20, y0=150+R()*30, dir=left?1:-1, len=40+R()*55;
      const x1=x0+dir*len, y1=y0+(R()-0.5)*50, x2=x0+dir*len*0.5, y2=y0+(R()-0.5)*30;
      veias+=`<path d="M${x0} ${y0} Q${x2} ${y2-8} ${x1} ${y1}" stroke="#c4413a" stroke-width="${(0.5+R()*0.8).toFixed(1)}" fill="none" opacity="${(0.25+R()*0.3).toFixed(2)}"/>`;
    }
    // cílios superiores e inferiores
    let cil='';
    for(let i=0;i<46;i++){
      const u=0.04+i/46*0.92, p=sup(u), n=norm(sup,u,1), len=14+Math.sin(u*Math.PI)*12+R()*5, bend=(u-0.35)*20+R()*4-2;
      const x2=p[0]+n[0]*len+n[2]*bend, y2=p[1]+n[1]*len+n[3]*bend;
      cil+=`<path d="M${p[0]} ${p[1]} Q${p[0]+n[0]*len*0.55} ${p[1]+n[1]*len*0.55} ${x2} ${y2}" stroke="#1d120c" stroke-width="${(1.4+R()*0.9).toFixed(1)}" fill="none" stroke-linecap="round"/>`;
    }
    for(let i=0;i<28;i++){
      const u=0.1+i/28*0.8, p=inf(u), n=norm(inf,u,1), len=6+R()*5, bend=(u-0.5)*10;
      const x2=p[0]-n[0]*len+n[2]*bend, y2=p[1]-n[1]*len+n[3]*bend;
      cil+=`<path d="M${p[0]} ${p[1]} L${x2} ${y2}" stroke="#2a1a12" stroke-width="1.3" fill="none" stroke-linecap="round" opacity=".85"/>`;
    }
    // sobrancelha: pelos
    let sob='';
    for(let i=0;i<340;i++){
      const u=R(), p=bez(u,[142,52],[200,8],[420,2],[522,78]); const q=bez(Math.min(1,u+0.02),[142,52],[200,8],[420,2],[522,78]);
      const th=Math.max(5,(0.25+Math.sin(u*Math.PI)*0.75)*17), off=(R()-0.5)*th, ang=Math.atan2(q[1]-p[1],q[0]-p[0])+(R()-0.5)*0.5-(u<0.35?0.5:0.1);
      const x=p[0]+off*0.1, y=p[1]+off, l=9+R()*7;
      sob+=`<path d="M${x} ${y} l${Math.cos(ang)*l} ${Math.sin(ang)*l}" stroke="${['#2b1a10','#3a2415','#1e120a','#4a2f1c'][Math.floor(R()*4)]}" stroke-width="${(1+R()*1.2).toFixed(1)}" stroke-linecap="round" opacity="${(0.7+R()*0.3).toFixed(2)}"/>`;
    }
    // glândulas de Meibomius (pontinhos na borda)
    let mei=''; for(let i=0;i<22;i++){ const u=0.18+i/22*0.64, p=sup(u), n=norm(sup,u,1); mei+=`<circle cx="${(p[0]-n[0]*3.2).toFixed(1)}" cy="${(p[1]-n[1]*3.2).toFixed(1)}" r="1.4" fill="#f2d27a" opacity=".9"/>`; }
    const lidSup=`M150 168 C215 90 290 66 345 66 C410 66 475 100 515 152`, lidInf=`M515 152 C480 205 410 228 345 228 C270 228 200 215 150 168`;
    const L=(x1,y1,x2,y2,t,ax,ay,an)=>`<line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" stroke="#51616b" stroke-width="1"/><circle cx="${x1}" cy="${y1}" r="2.4" fill="#51616b"/><text x="${ax}" y="${ay}" text-anchor="${an}" fill="#1b1b1b" font-size="14" font-weight="600">${t}</text>`;
    return `<svg viewBox="-190 0 960 360" width="960" height="360" style="font-family:Arial,sans-serif;max-width:100%;height:auto;">
      <defs>
        <radialGradient id="peleG" cx="50%" cy="45%" r="65%"><stop offset="0" stop-color="#f3d2b8"/><stop offset="0.7" stop-color="#e6b997"/><stop offset="1" stop-color="#d8a483"/></radialGradient>
        <radialGradient id="escG" cx="50%" cy="50%" r="60%"><stop offset="0.45" stop-color="#fbfaf8"/><stop offset="0.85" stop-color="#e9ddd6"/><stop offset="1" stop-color="#d3b9ae"/></radialGradient>
        <radialGradient id="irisG" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="#9a6a2f"/><stop offset="0.55" stop-color="#7c5222"/><stop offset="0.92" stop-color="#4a2d12"/><stop offset="1" stop-color="#1e1208"/></radialGradient>
        <linearGradient id="sombraLid" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#000" stop-opacity=".55"/><stop offset="0.45" stop-color="#000" stop-opacity=".12"/><stop offset="1" stop-color="#000" stop-opacity="0"/></linearGradient>
        <filter id="blur3"><feGaussianBlur stdDeviation="3"/></filter>
        <filter id="blur6"><feGaussianBlur stdDeviation="6"/></filter>
        <clipPath id="olhoClip"><path d="${lidSup} ${lidInf.replace('M515 152','')} Z"/></clipPath>
      </defs>
      <rect x="95" y="10" width="470" height="340" rx="150" fill="url(#peleG)"/>
      <path d="M130 120 C200 20 440 10 530 110" fill="none" stroke="#b9805f" stroke-width="14" opacity=".35" filter="url(#blur6)"/>
      <path d="M150 168 C215 78 300 46 350 46 C420 46 490 86 528 150" fill="none" stroke="#a96f52" stroke-width="3" opacity=".7"/>
      <path d="M150 168 C215 78 300 46 350 46 C420 46 490 86 528 150" fill="none" stroke="#fff" stroke-width="6" opacity=".12" transform="translate(0,-5)"/>
      <path d="M170 252 C260 300 420 300 500 245" fill="none" stroke="#b9805f" stroke-width="10" opacity=".25" filter="url(#blur6)"/>
      <path d="${lidSup} ${lidInf.replace('M515 152','')} Z" fill="url(#escG)"/>
      <g clip-path="url(#olhoClip)">
        ${veias}
        <circle cx="${cx}" cy="${cy}" r="${ri+2}" fill="#2a1a0c"/>
        <circle cx="${cx}" cy="${cy}" r="${ri}" fill="url(#irisG)"/>
        ${fib}
        <circle cx="${cx}" cy="${cy}" r="${ri-1}" fill="none" stroke="#1a0f06" stroke-width="5" opacity=".75" filter="url(#blur3)"/>
        <path d="${colar} Z" fill="none" stroke="#e1b56c" stroke-width="1.6" opacity=".75"/>
        <circle cx="${cx}" cy="${cy}" r="${rp}" fill="#050505"/>
        <ellipse cx="${cx-22}" cy="${cy-24}" rx="10" ry="7" fill="#fff" opacity=".92" transform="rotate(-30 ${cx-22} ${cy-24})"/>
        <ellipse cx="${cx+18}" cy="${cy+30}" rx="14" ry="6" fill="#fff" opacity=".18"/>
        <rect x="140" y="55" width="400" height="70" fill="url(#sombraLid)"/>
        <ellipse cx="${cx}" cy="${cy-48}" rx="150" ry="26" fill="#000" opacity=".12" filter="url(#blur6)"/>
      </g>
      <ellipse cx="164" cy="168" rx="16" ry="12" fill="#d77d78"/>
      <ellipse cx="161" cy="165" rx="9" ry="6" fill="#ec9f98"/>
      <path d="M182 150 Q172 168 184 188" fill="none" stroke="#c75f5c" stroke-width="2" opacity=".7"/>
      <path d="${lidSup}" fill="none" stroke="#4a2b1e" stroke-width="5.5" stroke-linecap="round"/>
      <path d="${lidInf}" fill="none" stroke="#b97a64" stroke-width="3.6" stroke-linecap="round"/>
      <path d="${lidInf}" fill="none" stroke="#f3b3a8" stroke-width="1.4" opacity=".8" transform="translate(0,-3)"/>
      ${mei}
      <circle cx="190" cy="187" r="2.8" fill="#6d1f1f"/>
      ${cil}${sob}
      ${L(300,22,150,20,'Sobrancelha',146,24,'end')}
      ${L(262,92,56,92,'Pálpebra superior',50,96,'end')}
      ${L(480,100,560,50,'Cílios',568,54,'start')}
      ${L(515,152,572,168,'Canto externo',580,172,'start')}
      ${L(cx+36,cy+34,450,320,'Íris e pupila',455,326,'start')}
      ${L(250,165,120,300,'Esclera (parte branca)',116,320,'end')}
      ${L(164,168,40,128,'Carúncula',36,126,'end')}
      ${L(190,187,40,196,'Ponto lacrimal',36,200,'end')}
      ${L(345,228,345,336,'Pálpebra inferior',345,352,'middle')}
      ${L(250,100,40,60,'Glândulas de Meibomius',36,58,'end')}
    </svg>`;
  }
  const DOENCAS = [
    ['Pálpebras', [
      ['Blefarite','Inflamação da borda da pálpebra. Dá vermelhidão, coceira, ardência e casquinhas na base dos cílios, principalmente ao acordar.','Cuidado em casa: compressa morna e limpeza das bordas. Procure o médico se não melhorar em poucos dias ou se voltar sempre.'],
      ['Terçol (hordéolo)','Infecção de uma glândula da pálpebra. Aparece um caroço vermelho e doloroso na borda, parecido com uma espinha.','Compressa morna várias vezes ao dia. Nunca esprema. Procure o médico se piorar, se a vermelhidão se espalhar ou se houver febre.'],
      ['Calázio','Caroço duro, quase sem dor, por entupimento de uma glândula da pálpebra. Pode durar semanas.','Compressa morna ajuda. Procure o médico se não sumir, crescer ou atrapalhar a visão. Às vezes precisa de procedimento simples.'],
      ['Ptose (pálpebra caída)','A pálpebra de cima fica mais baixa e cobre parte do olho. Pode ser de nascença, da idade ou de problema nos músculos e nervos.','Procure atendimento no mesmo dia se aparecer de repente, com visão dupla ou dor de cabeça forte.'],
      ['Entrópio','A pálpebra vira para dentro e os cílios raspam o olho. É mais comum na pálpebra de baixo em pessoas idosas.','Dá lacrimejamento e sensação de areia. Pode machucar a córnea. Precisa de avaliação do oftalmologista.'],
      ['Ectrópio','A pálpebra de baixo vira para fora e fica caída. O olho fica vermelho e lacrimejando.','Precisa de avaliação. O tratamento, quando necessário, é cirúrgico.'],
      ['Triquíase','Cílios que crescem para dentro e tocam o olho.','Causa dor, vermelhidão e risco de ferida na córnea. Procure o oftalmologista.'],
      ['Xantelasma','Placas amareladas e planas perto do canto interno das pálpebras. Podem ter ligação com colesterol alto.','Não machuca. Vale pedir exame de sangue ao médico e avaliar a retirada por motivo estético.'],
      ['Tremor na pálpebra','Um pequeno tremor que vai e volta. Costuma vir de cansaço, estresse, pouco sono ou excesso de café.','Normalmente passa sozinho. Procure o médico se durar semanas ou se a pálpebra fechar sozinha.'],
      ['Tumores de pele da pálpebra','Ferida que não cicatriza, caroço com borda brilhante, sangramento ou perda de cílios no local.','Procure o médico sem demora. Quanto mais cedo a retirada, melhor.']
    ]],
    ['Em volta do olho e sobrancelha', [
      ['Celulite periorbitária','Infecção da pele ao redor do olho. A pálpebra incha, fica vermelha, quente e dolorida. Pode haver febre.','É urgência. Se doer para mexer o olho, se a visão cair ou ficar dupla, vá ao pronto-socorro.'],
      ['Dacriocistite','Infecção do saco lacrimal. Aparece um inchaço dolorido no canto interno do olho, perto do nariz, com lacrimejamento.','Procure atendimento. Pode precisar de antibiótico e de desobstrução da via lacrimal.'],
      ['Herpes zóster no rosto','Bolhas dolorosas em um lado da testa, da sobrancelha ou da pálpebra de cima.','É urgência. Pode atingir o olho. Procure o médico nas primeiras 72 horas.'],
      ['Dermatite seborreica','Pele vermelha com descamação na sobrancelha e na borda das pálpebras, como uma caspa.','Costuma acompanhar a blefarite. O dermatologista ou oftalmologista indica o tratamento.'],
      ['Alergia e dermatite de contato','Pálpebra vermelha, inchada e que coça depois de maquiagem, colírio, creme ou sabonete.','Pare de usar o produto suspeito. Procure o médico se não melhorar em 2 ou 3 dias.'],
      ['Queda de cílios e sobrancelha','Pode ter relação com blefarite, problemas de tireoide, alergia ou outras doenças.','Procure o médico se for na parte externa da sobrancelha ou se vier com outros sintomas.'],
      ['Olheiras e bolsas','Quase sempre vêm de genética, sono ruim, alergia ou gordura ao redor do olho.','Em geral não são doença. Procure o médico se houver inchaço novo de um lado só.']
    ]],
    ['Olho (superfície e parte interna)', [
      ['Conjuntivite','Olho vermelho com lacrimejamento ou secreção. Pode ser viral, bacteriana ou alérgica.','Lave as mãos e não compartilhe toalha. Procure o médico se houver dor, luz incomodando ou visão borrada.'],
      ['Olho seco','Ardência, areia nos olhos e vermelhidão, principalmente em telas e ar-condicionado.','Piscar mais, pausas na tela e lágrima artificial ajudam. O médico confirma a causa.'],
      ['Pterígio','Uma película carnuda que cresce da parte branca em direção à córnea. Vem do sol, vento e poeira.','Use óculos com proteção UV. Procure o médico se crescer ou atrapalhar a visão.'],
      ['Catarata','O cristalino fica turvo. A visão fica embaçada, com brilho incômodo e cores apagadas.','O tratamento é cirurgia, indicada pelo oftalmologista quando atrapalha o dia a dia.'],
      ['Glaucoma','A pressão do olho pode lesionar o nervo óptico. Perde-se primeiro a visão lateral, quase sem sintoma.','Quem tem casos na família ou passa dos 40 anos deve medir a pressão do olho todo ano.'],
      ['Retinopatia diabética','O diabetes lesiona os vasos da retina. No início não dá sintoma.','Quem tem diabetes precisa de exame de fundo de olho todo ano.'],
      ['Degeneração macular','Perde-se a visão do centro. Linhas retas parecem tortas e aparece uma mancha no meio.','Use a tela de Amsler (teste 10) em casa. Procure o médico se as linhas entortarem.'],
      ['Ceratocone','A córnea fica fina e em forma de cone. O grau muda rápido e a visão fica distorcida.','Aparece mais em jovens. Precisa de acompanhamento e, às vezes, lente especial.'],
      ['Descolamento de retina','Aparecem muitas manchas flutuantes, clarões de luz ou uma sombra como cortina.','É urgência. Vá ao pronto-socorro de oftalmologia imediatamente.']
    ]]
  ];

  function educacaoOcularHtml(pw){
    const cartoes = DOENCAS.map(([titulo, lista])=>`<h3 style="font:700 18px Arial;margin:22px 0 8px;text-align:left;color:#0f6b66;">${titulo}</h3><div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(250px,1fr));gap:10px;">${lista.map(([n,o,c])=>`<div class="opCard"><b>${n}</b><span style="display:block;margin:2px 0 6px;">${o}</span><span style="display:block;color:#0a4a47;"><strong>O que fazer:</strong> ${c}</span></div>`).join('')}</div>`).join('');
    return `<div style="padding:16px 20px 110px;text-align:center;max-width:1000px;">
      <div style="font:700 22px Arial;margin-bottom:6px;">Educação ocular</div>
      <div style="font:600 16px Arial;margin:10px 0 2px;color:#444;">O olho por dentro</div>
      ${olhoSvg()}
      <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin-top:10px;">${EDU_PARTES.map(([a,b])=>`<div class="opCard"><b>${a}</b><span>${b}</span></div>`).join('')}</div>
      <div style="font:600 16px Arial;margin:26px 0 2px;color:#444;">O olho por fora: pálpebras e região ao redor</div>
      ${olhoFrenteSvg()}
      <div style="font:13px Arial;color:#555;background:#fff3cd;border-radius:8px;padding:8px 12px;margin:14px 0 0;text-align:left;">Esta tela serve para explicar. Só o oftalmologista faz o diagnóstico e indica o tratamento. Dor forte, perda de visão e inchaço que cresce são motivos para procurar atendimento no mesmo dia.</div>
      ${cartoes}
    </div>`;
  }
  const EDU_PARTES = [['Córnea','Lente transparente na frente do olho.'],['Íris e pupila','Controlam a entrada de luz.'],['Cristalino','Foca de longe e de perto.'],['Humor vítreo','Gel que enche o olho.'],['Esclera','Parte branca que protege.'],['Retina','Capta a imagem.'],['Mácula','Visão central e de detalhes.'],['Nervo óptico','Leva a imagem ao cérebro.']];

  function olhoSvg(){
    return `<svg viewBox="-40 0 780 380" width="780" height="380" style="font-family:Arial,sans-serif;max-width:100%;height:auto;font-size:14px;">
      <defs>
        <radialGradient id="esfG" cx="40%" cy="40%" r="75%"><stop offset="0" stop-color="#ffffff"/><stop offset="1" stop-color="#d9d4cf"/></radialGradient>
        <radialGradient id="vitG" cx="35%" cy="45%" r="75%"><stop offset="0" stop-color="#eaf6fb"/><stop offset="1" stop-color="#c3deea"/></radialGradient>
        <linearGradient id="nervoG" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#f1d58a"/><stop offset="1" stop-color="#d9b25a"/></linearGradient>
        <radialGradient id="lenteG" cx="40%" cy="40%" r="70%"><stop offset="0" stop-color="#fff8dc"/><stop offset="1" stop-color="#e8cf8a"/></radialGradient>
        <linearGradient id="irisS" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#b98443"/><stop offset="1" stop-color="#6e4318"/></linearGradient>
        <clipPath id="globoClip"><circle cx="330" cy="190" r="128"/></clipPath>
      </defs>
      <!-- esclera e coroide -->
      <circle cx="330" cy="190" r="130" fill="url(#esfG)" stroke="#b9b1aa" stroke-width="2"/>
      <circle cx="330" cy="190" r="121" fill="#7c2a2a"/>
      <!-- retina -->
      <path d="M330 69 A121 121 0 0 1 330 311" fill="none"/>
      <circle cx="330" cy="190" r="117" fill="#e4793a"/>
      <circle cx="330" cy="190" r="111" fill="url(#vitG)"/>
      <!-- vasos da retina -->
      <g stroke="#b3242b" stroke-width="2" fill="none" opacity=".75" clip-path="url(#globoClip)"><path d="M436 228 Q400 180 372 110"/><path d="M436 228 Q404 232 360 280"/><path d="M436 228 Q410 200 380 190"/><path d="M436 228 Q420 270 400 292"/></g>
      <!-- córnea (cúpula) -->
      <path d="M225 120 Q170 190 225 260 L232 252 Q192 190 232 128Z" fill="#cfe9f5" stroke="#5aa6c8" stroke-width="2.5"/>
      <path d="M232 128 Q192 190 232 252 Q290 190 232 128Z" fill="#e3f3fa" opacity=".9"/>
      <!-- íris e pupila -->
      <path d="M244 112 L254 160 L238 162 L236 120Z" fill="url(#irisS)" stroke="#4a2d12"/>
      <path d="M244 268 L254 220 L238 218 L236 260Z" fill="url(#irisS)" stroke="#4a2d12"/>
      <!-- corpo ciliar -->
      <path d="M262 100 Q282 112 286 138 L262 132Z" fill="#c98f7c"/>
      <path d="M262 280 Q282 268 286 242 L262 248Z" fill="#c98f7c"/>
      <!-- cristalino -->
      <ellipse cx="274" cy="190" rx="22" ry="42" fill="url(#lenteG)" stroke="#bfa25a" stroke-width="2"/>
      <!-- mácula e disco óptico -->
      <ellipse cx="437" cy="190" rx="4" ry="12" fill="#f2b400"/>
      <ellipse cx="434" cy="226" rx="4" ry="12" fill="#f3e3a3" stroke="#d6b560"/>
      <!-- nervo óptico -->
      <path d="M440 228 L545 262" stroke="url(#nervoG)" stroke-width="34" stroke-linecap="round"/>
      <path d="M452 226 L536 252" stroke="#fff" stroke-width="2" opacity=".5"/>
      <!-- legendas -->
      <g stroke="#51616b" stroke-width="1" fill="none">
        <path d="M190 190 L120 190"/><path d="M240 130 L200 70"/><path d="M274 150 L274 60"/><path d="M330 210 L300 360" opacity="0"/>
        <path d="M380 200 L180 340" opacity="0"/><path d="M440 100 L470 56"/><path d="M437 186 L560 150"/><path d="M545 262 L590 300"/><path d="M330 62 L330 40"/>
        <path d="M244 140 L120 300" opacity="0"/><path d="M400 300 L420 340"/><path d="M200 255 L120 300"/>
      </g>
      <g fill="#1b1b1b" font-weight="600">
        <text x="114" y="194" text-anchor="end">Córnea</text>
        <text x="196" y="62" text-anchor="end">Íris e pupila</text>
        <text x="274" y="52" text-anchor="middle">Cristalino</text>
        <text x="330" y="32" text-anchor="middle">Esclera</text>
        <text x="476" y="52">Retina</text>
        <text x="566" y="148">Mácula</text>
        <text x="594" y="316">Nervo óptico</text>
        <text x="390" y="200" text-anchor="middle" fill="#3a6b80" font-weight="400">Humor vítreo</text>
        <text x="424" y="358">Coroide</text>
        <text x="114" y="306" text-anchor="end">Corpo ciliar</text>
      </g>
    </svg>`;
  }

  /* ---------- tela de cada teste ---------- */
  function render(){
    const ov = O.ov, p = O.palco, t = O.t;
    ov.classList.toggle('escuro', t===8 || t===18);
    p.classList.toggle('rola', t===14 || t===12);
    p.style.transform = '';
    const { h, n, pw, ph } = tamanho();
    const den = LIN[O.linha];
    let html = '', rot = null, info = '';
    const min = Math.min(pw, ph);
    if(t===1) html = linha(O.seq.slice(0,n), h, c=>`<span style="font:900 ${h/0.72}px 'Arial Black',Arial,sans-serif;line-height:1;">${c}</span>`);
    else if(t===2) html = linha(O.seq.slice(0,n), h, c=>`<span style="font:900 ${h/0.72}px 'Arial Black',Arial,sans-serif;line-height:1;">${c}</span>`);
    else if(t===3) html = linha(O.seq.slice(0,n), h, d=>svgE(h,d));
    else if(t===4) html = linha(O.seq.slice(0,n), h, d=>svgC(h,d));
    else if(t===9) html = linha(O.seq.slice(0,n), h, k=>svgForma(k,h));
    else if(t===5){
      const [num, demo] = PLACAS[O.placa];
      const side = Math.min(ph*0.84, pw*0.9);
      html = `<div style="text-align:center;"><canvas id="opPlaca" width="600" height="600" style="width:${side}px;height:${side}px;"></canvas><div style="font:13px Arial;color:#888;margin-top:-4px;">Placa ${O.placa+1}/${PLACAS.length}${demo?' · Demonstração':''}</div></div>`;
      info = `Placa ${O.placa+1}/${PLACAS.length}${demo?' (demonstração)':''}. Resposta: ${num}`;
    }
    else if(t===6){
      const dens = LIN.slice(O.duo, O.duo+5);
      const col = (cor)=>`<div style="flex:1;height:100%;background:${cor};display:flex;flex-direction:column;align-items:center;justify-content:center;gap:${Math.round(ph*0.03)}px;padding-bottom:70px;">${dens.map((d,i)=>{ const hh = Math.min(px(d), ph*0.13, pw/22); return `<div style="font:900 ${hh/0.72}px 'Arial Black',Arial,sans-serif;line-height:1;letter-spacing:${hh*0.4}px;color:#111;white-space:nowrap;">${O.duoLetras[i].join('')}</div>`; }).join('')}</div>`;
      html = `<div style="position:absolute;inset:0;display:flex;">${col('#e0291c')}${col('#1fbf3f')}</div>`;
    }
    else if(t===7){ const s = Math.min(pw*0.95, ph*0.98); html = dialSvg(s); }
    else if(t===8){
      const d = Math.max(30, min*0.1*(O.worth||1)), g = d*0.25;
      const bola = (x,y,c)=>`<div style="position:absolute;left:calc(50% + ${x}px - ${d/2}px);top:calc(50% + ${y}px - ${d/2}px);width:${d}px;height:${d}px;border-radius:50%;background:${c};"></div>`;
      html = `<div style="position:relative;width:100%;height:100%;">${bola(0,-(d+g)*0.9,'#ee2e1f')}${bola(-(d+g)*0.9,0,'#12c444')}${bola((d+g)*0.9,0,'#12c444')}${bola(0,(d+g)*0.9,'#e8e8e8')}</div>`;
    }
    else if(t===10 || t===18){
      const cor = t===18 ? '#e02424' : '#000';
      const s = Math.min(pw*0.85, ph*0.85), q = s/20; let l = '';
      for(let i=0;i<=20;i++) l += `<line x1="${i*q}" y1="0" x2="${i*q}" y2="${s}" stroke="${cor}" stroke-width="1"/><line x1="0" y1="${i*q}" x2="${s}" y2="${i*q}" stroke="${cor}" stroke-width="1"/>`;
      html = `<svg width="${s}" height="${s}" viewBox="-2 -2 ${s+4} ${s+4}">${l}<circle cx="${s/2}" cy="${s/2}" r="${Math.max(3,q*0.18)}" fill="${cor}"/></svg>`;
    }
    else if(t===11){
      const L = min*0.28;
      html = `<svg width="${L*2}" height="${L*2}" viewBox="-100 -100 200 200"><line x1="-100" y1="0" x2="100" y2="0" stroke="#000" stroke-width="7"/><line x1="0" y1="-100" x2="0" y2="100" stroke="#000" stroke-width="7"/><circle r="9" fill="#000"/></svg>`;
    }
    else if(t===12){
      const LINHAS = [['1,25',1.25,'J6',4],['1,00',1.00,'J5',4],['0,75',0.75,'J4',5],['0,62',0.62,'J3',5],['0,50',0.50,'J2',6],['0,37',0.37,'J1',6]];
      if(!O.near) O.near = LINHAS.map(([,,,nd])=>({ es:[sorteia([0,90,180,270],6),sorteia([0,90,180,270],6)], dg:[sorteia(DIGITOS.concat(['1','7']),nd),sorteia(DIGITOS.concat(['1','7']),nd)] }));
      const mmM = 1.454;
      let linhasHtml = '', pequeno = false;
      LINHAS.forEach(([rot,M,J],i)=>{
        const hh = Math.max(1, M*mmM*tt.pxmm); if(hh<4) pequeno = true;
        const gap = hh*1.1, g2 = hh*0.9;
        const es = O.near[i].es.map(linha=>`<div style="display:flex;gap:${gap}px;align-items:center;">${linha.map(d=>svgE(hh,d)).join('')}</div>`).join(`<div style="height:${hh*0.7}px"></div>`);
        const dg = O.near[i].dg.map(linha=>`<div style="display:flex;gap:${g2}px;align-items:center;">${linha.map(c=>`<span style="font:400 ${hh/0.716}px Arial,sans-serif;line-height:${hh}px;height:${hh}px;display:block;">${c}</span>`).join('')}</div>`).join(`<div style="height:${hh*0.7}px"></div>`);
        linhasHtml += `<div style="display:flex;align-items:center;justify-content:space-between;gap:24px;margin:${Math.max(10,hh*1.6)}px 0;"><span style="font:600 13px Arial;color:#666;width:54px;">${rot} M</span><div style="display:flex;gap:${Math.max(24,hh*5)}px;align-items:center;"><div>${es}</div><div>${dg}</div></div><span style="font:700 15px Arial;color:#333;width:34px;text-align:right;">${J}</span></div>`;
      });
      html = `<div style="max-width:${Math.min(pw*0.96,980)}px;padding:12px 24px 110px;text-align:left;"><div style="font:700 20px Arial;text-align:center;">Tabela de leitura para perto</div><div style="font:13px Arial;color:#666;margin:4px 0 6px;text-align:center;">Segure a tela a 40 cm. Peça para o paciente ler a menor linha em que acerta quase tudo. Os tamanhos seguem a calibração da tela.${pequeno?' As linhas menores ficam abaixo do que a tela consegue mostrar. Teste em um celular ou tela de alta resolução.':''}</div>${linhasHtml}</div>`;
      info = 'Leitura de perto: E direcional e números por linha, de J6 até J1. Segure a 40 cm.';
    }
    else if(t===13){
      const niveis = [1,0.5,0.25,0.12,0.06], hc = Math.min(h, pw/9, ph*0.5);
      html = linha(niveis, hc, c=>`<span style="font:700 ${hc/0.72}px Arial,sans-serif;line-height:1;color:rgb(${Math.round(255*(1-c))},${Math.round(255*(1-c))},${Math.round(255*(1-c))});">V</span>`);
    }
    else if(t===14){
      html = educacaoOcularHtml(pw);
    }
    else if(t===16){
      const hp = Math.min(ph/19, pw/22);
      if(!O.pr) O.pr = Array.from({length:16},()=>sorteia(LETRAS,3));
      const cel = i=>{ const g = Math.round(255*(1-Math.pow(10,-0.15*i))); return `<span style="font:700 ${hp/0.72}px Arial,sans-serif;line-height:1;letter-spacing:${hp*0.45}px;color:rgb(${g},${g},${g});">${O.pr[i].join('')}</span>`; };
      let ls = ''; for(let r=0;r<8;r++) ls += `<div style="display:flex;gap:${hp*1.6}px;justify-content:center;margin:${hp*0.35}px 0;">${cel(r*2)}${cel(r*2+1)}</div>`;
      html = `<div>${ls}</div>`;
      info = 'Grupos de 3 letras, cada um mais claro. Anote o último em que leu 2 de 3. Cada letra lida vale 0,05.';
    }
    else if(t===17){
      const logs = Array.from({length:14},(_,i)=>1-i*0.1), dens = logs.map(l=>20*Math.pow(10,l));
      if(!O.et) O.et = [];
      const alvo = ph*0.96; let y = 0, i = O.etdrs, ls = '';
      while(i<14){
        const hh = Math.min(px(dens[i]), alvo/1.6), gap = i<13 ? Math.min(px(dens[i+1]), hh)*0.6 : 0;
        if(i>O.etdrs && y+hh*1.39>alvo) break;
        if(!O.et[i]) O.et[i] = sorteia(LETRAS,5,O.et[i-1]);
        const nn = Math.max(1, Math.min(5, Math.floor(pw/(hh*1.9))));
        ls += `<div style="display:flex;gap:${hh*0.8}px;justify-content:center;margin-bottom:${gap}px;">${O.et[i].slice(0,nn).map(c=>`<span style="font:900 ${hh/0.72}px 'Arial Black',Arial,sans-serif;line-height:1;">${c}</span>`).join('')}</div>`;
        y += hh*1.39+gap; i++;
      }
      html = `<div>${ls}</div>`;
      rot = `20/${Math.round(dens[O.etdrs])} (logMAR ${logs[O.etdrs].toFixed(1).replace('.',',')})`;
      info = rot;
    }
    else if(t===19){
      const alvo = ph*0.96; let y = 0, i = O.linha, ls = '';
      while(i<SNELLEN.length){
        const hh = Math.min(px(LIN[i]), alvo/1.6);
        if(i>O.linha && y+hh*1.6>alvo) break;
        const letras = SNELLEN[i].split(''), nn = Math.max(1, Math.min(letras.length, Math.floor(pw/(hh*1.9))));
        ls += `<div style="display:flex;gap:${hh*0.7}px;justify-content:center;margin-bottom:${hh*0.6}px;align-items:center;"><span style="font:600 ${Math.max(11,Math.min(16,hh*0.5))}px Arial;color:#999;width:50px;text-align:right;">${LIN[i]}</span>${letras.slice(0,nn).map(c=>`<span style="font:900 ${hh/0.72}px 'Arial Black',Arial,sans-serif;line-height:1;">${c}</span>`).join('')}</div>`;
        y += hh*1.6; i++;
      }
      html = `<div>${ls}</div>`;
    }
    else if(t===15){
      const L = min*0.45;
      html = `<svg width="${L*2}" height="${L*2}" viewBox="-100 -100 200 200"><line x1="-100" y1="0" x2="100" y2="0" stroke="#000" stroke-width="3" stroke-linecap="round"/><line x1="0" y1="-100" x2="0" y2="100" stroke="#000" stroke-width="3" stroke-linecap="round"/></svg>`;
    }
    p.innerHTML = html;
    if(COM_ESPELHO.includes(t) && tt.espelho) p.style.transform = 'scaleX(-1)';
    if(t===5){ const cv = p.querySelector('#opPlaca'); cv.getContext('2d').drawImage(placaCanvas(O.placa),0,0); }

    const dec = (20/den).toFixed(2).replace('.',',');
    O.rotulo = rot!==null ? rot : (COM_ACUIDADE.includes(t) ? `20/${den} (${dec})` : (t===5 ? '' : NOMES[t-1]));
    O.ov.querySelector('#opRot').textContent = O.rotulo;
    O.ov.querySelectorAll('#opBarra button[data-t]').forEach(b=> b.classList.toggle('on', +b.dataset.t===t));
    enviarEstado(COM_ACUIDADE.includes(t) ? `20/${den} (${dec})` : (info || ''));
  }

  /* ---------- ações ---------- */
  function irPara(t){ O.t = Math.max(1, Math.min(TOTAL, t)); O.seq = []; novaSequencia(); render(); }
  function aviso(txt){ const a = O.ov.querySelector('#opAviso'); a.textContent = txt; a.style.opacity = 1; clearTimeout(O.avT); O.avT = setTimeout(()=>{ a.style.opacity = 0; }, 1400); }
  function maior(){ if(O.t===17){ O.etdrs = Math.max(0, O.etdrs-1); } else if(O.t===6){ O.duo = Math.max(0, O.duo-1); } else if(O.t===8){ O.worth = Math.min(3,(O.worth||1)*1.25); } else O.linha = Math.max(0, O.linha-1); novaSequencia(); render(); }
  function menor(){ if(O.t===17){ O.etdrs = Math.min(13, O.etdrs+1); } else if(O.t===6){ O.duo = Math.min(LIN.length-5, O.duo+1); } else if(O.t===8){ O.worth = Math.max(0.3,(O.worth||1)/1.25); } else O.linha = Math.min(LIN.length-1, O.linha+1); novaSequencia(); render(); }
  function novas(){
    if(O.t===5){ O.placa = (O.placa+1)%PLACAS.length; }
    else if(O.t===16){ O.pr = null; }
    else if(O.t===17){ O.et = []; }
    else if(O.t===12){ O.near = null; }
    else { novaSequencia(); O.duoLetras = Array.from({length:5},()=>sorteia(LETRAS,5)); }
    render();
  }
  function placaAnt(){ O.placa = (O.placa+PLACAS.length-1)%PLACAS.length; render(); }
  function telaCheia(){
    try{ if(document.fullscreenElement) document.exitFullscreen(); else O.ov.requestFullscreen && O.ov.requestFullscreen(); }catch(e){}
  }
  function espelho(){ tt.espelho = !tt.espelho; render(); aviso(tt.espelho ? 'Modo espelho ligado' : 'Modo espelho desligado'); }
  function fechar(){
    O.vivo = false; enviarEstado('', false);
    document.removeEventListener('keydown', tecla, true);
    try{ if(document.fullscreenElement) document.exitFullscreen(); }catch(e){}
    O.ov.remove(); O = null;
  }

  function tecla(e){
    if(!O || e.ctrlKey || e.metaKey) return;
    if(O.ov.querySelector('.opDlg')){ if(e.key==='Escape'){ O.ov.querySelectorAll('.opDlg').forEach(d=>d.remove()); e.preventDefault(); } return; }
    const k = e.key.length===1 ? e.key.toLowerCase() : e.key;
    if(e.altKey && k==='f'){ telaCheia(); e.preventDefault(); return; }
    if(k==='Escape'){ fechar(); return; }
    if(k==='ArrowDown'){ menor(); e.preventDefault(); }
    else if(k==='ArrowUp'){ maior(); e.preventDefault(); }
    else if(k==='ArrowRight'){ novas(); e.preventDefault(); }
    else if(k==='ArrowLeft'){ if(O.t===5) placaAnt(); else novas(); e.preventDefault(); }
    else if(k===','){ irPara(O.t===1?TOTAL:O.t-1); }
    else if(k==='.'){ irPara(O.t===TOTAL?1:O.t+1); }
    else if(k==='?' || k==='h'){ ajuda(); }
    else if(k==='m'){ espelho(); }
    else if(TECLAS_TESTE[k]){ irPara(TECLAS_TESTE[k]); }
  }

  function comando(c){
    if(!O) return;
    switch(c.acao){
      case 'maior': maior(); break;
      case 'menor': menor(); break;
      case 'novas': novas(); break;
      case 'espelho': espelho(); break;
      case 'anterior': irPara(O.t===1?TOTAL:O.t-1); break;
      case 'proximo': irPara(O.t===TOTAL?1:O.t+1); break;
      case 'teste': irPara(parseInt(c.valor,10)||1); break;
      case 'sair': fechar(); break;
    }
  }

  /* ---------- ajuda e celular ---------- */
  function dialogo(html){
    const d = document.createElement('div'); d.className = 'opDlg';
    d.innerHTML = `<div>${html}<button class="fechar">Fechar</button></div>`;
    d.addEventListener('click', e=>{ if(e.target===d || e.target.classList.contains('fechar')) d.remove(); });
    O.ov.appendChild(d); return d;
  }
  function ajuda(){
    dialogo(`<h3>Como usar o optotipo</h3>
      <p>Mostre ao paciente na distância calibrada. Troque o teste pela barra de baixo, pelo teclado ou pelo celular.</p>
      <p>No E direcional e no C de Landolt, a posição nunca se repete na mesma casa da linha anterior.</p>
      <p><b>Teclas de atalho</b></p>
      <div class="opCol"><div><code>1</code> a <code>9</code> testes 1 a 9<br><code>F</code> Fixação<br><code>C</code> Contraste<br><code>X</code> ou <code>+</code> Cruz<br><code>D</code> Dial astigmático</div>
      <div><code>A</code> Amsler<br><code>J</code> Leitura de perto<br><code>E</code> Educação ocular<br><code>B</code> Duocromo<br><code>P</code> Contraste por letras<br><code>L</code> Tabela ETDRS<br><code>R</code> Amsler vermelho<br><code>S</code> Tabela de Snellen<br><code>M</code> Modo espelho</div></div>
      <p><b>Comandos</b></p>
      <p><code>,</code> teste anterior · <code>.</code> próximo teste<br><code>↓</code> letra menor · <code>↑</code> letra maior<br><code>←</code> <code>→</code> nova sequência (nas placas de cores, troca a placa)<br><code>Alt</code>+<code>F</code> tela cheia<br><code>Esc</code> sair · <code>?</code> ou <code>H</code> esta ajuda</p>`);
  }
  const NO_AR = () => location.protocol==='https:' && !/^(localhost|127\.|192\.168\.|10\.)/.test(location.hostname);
  function urlCelular(ip){ return NO_AR() ? `${location.origin}/optotipo/celular?c=${O.codigo}` : `http://${ip}:${O.porta}/optotipo/celular?c=${O.codigo}`; }
  function mostrarQr(){
    const ip = (O.enderecos && O.enderecos[0]) || location.hostname || 'localhost';
    const url = urlCelular(ip);
    let qr = '';
    try{ const q = qrcode(0,'M'); q.addData(url); q.make(); qr = q.createSvgTag(6,2); }catch(e){ qr = '<p>Não consegui desenhar o QR Code.</p>'; }
    const outros = NO_AR() ? '' : (O.enderecos||[]).slice(1).map(i=>`<br>${urlCelular(i)}`).join('');
    dialogo(`<h3 style="text-align:center;">Controle pelo celular</h3>
      <div style="text-align:center;width:240px;margin:0 auto;">${qr}</div>
      <p style="text-align:center;">Aponte a câmera do celular para o QR Code.<br>${NO_AR()?'O celular pode estar em qualquer internet.':'O celular precisa estar no mesmo Wi-Fi do computador.'}</p>
      <p style="text-align:center;">Código: <code>${O.codigo}</code></p>
      <p style="font-size:12px;color:#666;text-align:center;word-break:break-all;">Se não abrir, digite no celular:<br>${url}${outros}<br>Ainda não abre? Dê dois cliques em <b>liberar-celular.bat</b> na pasta do sistema.</p>`);
  }
  async function conectarCelular(){
    if(O.codigo){ mostrarQr(); return; }
    try{
      const s = await api('/optotipo/sessao', { method:'POST', body:{} });
      O.codigo = s.codigo; O.enderecos = s.enderecos; O.porta = s.porta; O.n = 0;
      mostrarQr(); enviarEstado(O.rotulo||''); esperar();
    }catch(e){ if(typeof erroApi==='function') erroApi(e); else alert(e.message); }
  }
  async function esperar(){
    const meu = O;
    while(O===meu && O.vivo && O.codigo){
      try{
        const r = await fetch(`${API_BASE}/optotipo/${O.codigo}/esperar?desde=${O.n}`);
        if(!r.ok){ O.codigo = null; break; }
        const j = await r.json(); O.n = j.n; j.cmds.forEach(comando);
      }catch(e){ await new Promise(ok=>setTimeout(ok,2000)); }
    }
  }
  function enviarEstado(rot, ativo){
    if(!O || !O.codigo) return;
    fetch(`${API_BASE}/optotipo/${O.codigo}/estado`, { method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({ teste:O.t, nome:NOMES[O.t-1], rotulo:rot||'', ativo:ativo!==false }) }).catch(()=>{});
  }

  /* ---------- abrir ---------- */
  window.abrirOptotipo = function(){
    if(O) return;
    estilo();
    const ov = document.createElement('div'); ov.id = 'opto';
    ov.innerHTML = `<div id="opPalco"></div><div id="opAviso"></div>
      <button id="opCel">📱 Conectar celular</button>
      <div id="opRodape"><div id="opBarra">${NOMES.map((n,i)=>`<button data-t="${i+1}" title="${n}">${i+1}</button>`).join('')}<span class="sep"></span><button id="opTela" title="Tela cheia">⛶</button><button id="opAj" title="Ajuda">?</button><button id="opSair" title="Sair">⎋</button></div><div id="opRot"></div></div>`;
    document.body.appendChild(ov);
    O = { ov, palco: ov.querySelector('#opPalco'), t:1, linha:0, seq:[], duo:3, duoLetras:[], placa:0, vivo:true, codigo:null, n:0, worth:1, etdrs:0, et:[], pr:null };
    novaSequencia(); O.duoLetras = Array.from({length:5},()=>sorteia(LETRAS,5));
    ov.querySelectorAll('#opBarra button[data-t]').forEach(b=> b.onclick = ()=> irPara(+b.dataset.t));
    ov.querySelector('#opTela').onclick = telaCheia;
    ov.querySelector('#opAj').onclick = ajuda;
    ov.querySelector('#opSair').onclick = fechar;
    ov.querySelector('#opCel').onclick = conectarCelular;
    document.addEventListener('keydown', tecla, true);
    window.addEventListener('resize', ()=>{ if(O) render(); });
    try{ ov.requestFullscreen && ov.requestFullscreen(); }catch(e){}
    render();
  };
})();
