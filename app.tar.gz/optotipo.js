/* Optotipo na tela: 19 testes, atalhos de teclado, tela cheia e controle pelo celular.
   Usa do sistema principal: tt (calibração e distância), alturaMm(), api(), API_BASE, toast(), erroApi(). */
(function(){
  const LETRAS = ['C','D','H','K','N','O','R','S','V','Z'];
  const DIGITOS = ['2','3','4','5','6','8','9'];
  const LIN = [200,100,70,50,40,30,25,20,15,10];
  const NOMES = ['Letras','Números','E direcional','C de Landolt','Cores','Duocromo','Dial astigmático','Luzes de Worth','Desenhos','Amsler','Fixação','Leitura de perto (Jaeger)','Contraste','Educação ocular','Cruz de afinamento','Contraste por letras','Tabela de letras ETDRS','Amsler vermelho','Tabela de Snellen'];
  const TOTAL = NOMES.length;
  const COM_ACUIDADE = [1,2,3,4,9,19];
  const COM_ESPELHO = [1,2,3,4,6,9,13,16,17,19];
  const SNELLEN = ['E','FP','TOZ','LPED','PECFD','EDFCZP','FELOPZD','DEFPOTEC','LEFODPCT','FDPLTCEO'];
  const FORMAS = ['circulo','quadrado','triangulo','estrela','coracao','casa'];
  const PLACAS = [['12',true],['8'],['29'],['5'],['3'],['15'],['74'],['6'],['16'],['73'],['26']];
  const TECLAS_TESTE = { '1':1,'2':2,'3':3,'4':4,'5':5,'6':6,'7':7,'8':8,'9':9,'0':10, f:11, c:13, x:15, '+':15, d:7, a:10, j:12, e:14, b:6, p:16, l:17, r:18, s:19 };

  let O = null; // estado do optotipo aberto

  function sorteia(pool, n, prev){
    const s = [];
    for(let i=0;i<n;i++){
      let c, t = 0;
      do{ c = pool[Math.floor(Math.random()*pool.length)]; t++; }
      while(t<40 && ((i>0 && c===s[i-1]) || (prev && c===prev[i])));
      s.push(c);
    }
    return s;
  }
  function novaSequencia(){
    const n = 5, ant = O.seq;
    if(O.t===3) O.seq = sorteia([0,90,180,270], n, ant);
    else if(O.t===4) O.seq = sorteia([0,45,90,135,180,225,270,315], n, ant);
    else if(O.t===2) O.seq = sorteia(DIGITOS, n, ant);
    else if(O.t===9) O.seq = sorteia(FORMAS, n, ant);
    else O.seq = sorteia(LETRAS, n, ant);
  }
  function estilo(){
    if(document.getElementById('optoCss')) return;
    const s = document.createElement('style'); s.id = 'optoCss';
    s.textContent = `
    #opto{position:fixed;inset:0;z-index:9999;background:#fff;color:#000;font-family:Arial,Helvetica,sans-serif;display:flex;flex-direction:column;overflow:hidden;}
    #opto.escuro{background:#1b1d1f;color:#fff;}
    #opPalco{flex:1;display:flex;align-items:center;justify-content:center;overflow:hidden;padding-bottom:70px;}
    #opPalco.rola{overflow:auto;align-items:flex-start;}
    #opRodape{position:absolute;left:0;right:0;bottom:12px;display:flex;justify-content:center;align-items:center;gap:18px;pointer-events:none;}
    #opBarra{pointer-events:auto;display:flex;align-items:center;gap:2px;background:rgba(236,239,241,.96);border-radius:999px;padding:5px 10px;box-shadow:0 1px 6px rgba(0,0,0,.25);}
    #opBarra button{border:0;background:transparent;color:#37474f;min-width:30px;height:30px;border-radius:50%;font:600 13px Arial,sans-serif;cursor:pointer;padding:0 4px;}
    #opBarra button:hover{background:#cfd8dc;}
    #opBarra button.on{background:#1e88e5;color:#fff;}
    #opBarra .sep{width:10px;}
    #opRot{font:700 22px Arial,sans-serif;color:#555;pointer-events:none;}
    #opto.escuro #opRot{color:#ddd;}
    #opCel{position:absolute;top:14px;right:14px;border:0;border-radius:999px;background:#1e88e5;color:#fff;font:700 14px Arial,sans-serif;padding:9px 16px;cursor:pointer;box-shadow:0 1px 4px rgba(0,0,0,.3);}
    #opAviso{position:absolute;top:14px;left:50%;transform:translateX(-50%);background:#263238;color:#fff;padding:8px 14px;border-radius:8px;font:14px Arial,sans-serif;opacity:0;transition:opacity .3s;pointer-events:none;}
    .opDlg{position:absolute;inset:0;background:rgba(0,0,0,.45);display:flex;align-items:center;justify-content:center;z-index:5;}
    .opDlg > div{background:#fff;color:#111;border-radius:14px;padding:20px 24px;max-width:560px;max-height:88vh;overflow:auto;font:14px/1.45 Arial,sans-serif;box-shadow:0 8px 30px rgba(0,0,0,.4);}
    .opDlg h3{margin:0 0 8px;font-size:20px;font-family:Arial,Helvetica,sans-serif;} .opDlg p{margin:6px 0;}
    .opDlg button.fechar{margin-top:12px;border:0;border-radius:8px;background:#1e88e5;color:#fff;font:700 14px Arial;padding:9px 18px;cursor:pointer;}
    .opDlg code{background:#eceff1;padding:1px 6px;border-radius:4px;font-weight:700;}
    .opCol{display:grid;grid-template-columns:1fr 1fr;gap:2px 22px;}
    .opCard{background:#fff;border-radius:10px;padding:10px 12px;box-shadow:0 1px 4px rgba(0,0,0,.15);text-align:left;}
    .opCard b{display:block;font-size:15px;} .opCard span{font-size:13px;color:#555;}
    `;
    document.head.appendChild(s);
  }

  /* ---------- desenhos ---------- */
  const px = den => Math.min(alturaMm(den)*tt.pxmm, 99999);
  function tamanho(){
    const pw = O.palco.clientWidth, ph = O.palco.clientHeight - 80;
    const h = Math.min(px(LIN[O.linha]), ph*0.8, pw*0.85);
    const n = Math.max(1, Math.min(5, Math.floor(pw/(h*1.9))));
    return { h, n, pw, ph };
  }
  function linha(itens, h, fn){
    return `<div style="white-space:nowrap;display:flex;align-items:center;justify-content:center;gap:${h*0.5}px;">${itens.map(fn).join('')}</div>`;
  }
  const svgE = (h,rot)=>`<svg viewBox="0 0 5 5" width="${h}" height="${h}" style="display:block;transform:rotate(${rot}deg)"><path fill="#000" d="M0 0h5v1H1v1h3v1H1v1h4v1H0z"/></svg>`;
  const svgC = (h,rot)=>`<svg viewBox="-2.5 -2.5 5 5" width="${h}" height="${h}" style="display:block;overflow:visible;transform:rotate(${rot}deg)"><defs><mask id="mC${rot}" maskUnits="userSpaceOnUse" x="-3" y="-3" width="6" height="6"><rect x="-3" y="-3" width="6" height="6" fill="#fff"/><rect x="0" y="-.5" width="3" height="1" fill="#000"/></mask></defs><circle r="2" fill="none" stroke="#000" stroke-width="1" mask="url(#mC${rot})"/></svg>`;
  function svgForma(k,h){
    const f = {
      circulo:'<circle cx="50" cy="50" r="40"/>',
      quadrado:'<rect x="12" y="12" width="76" height="76"/>',
      triangulo:'<polygon points="50,10 90,86 10,86"/>',
      estrela:'<polygon points="50,8 61,38 93,38 67,57 77,89 50,69 23,89 33,57 7,38 39,38"/>',
      coracao:'<path d="M50 88C8 58 12 20 36 20c8 0 12 6 14 10 2-4 6-10 14-10 24 0 28 38-14 68z"/>',
      casa:'<polygon points="50,10 92,48 80,48 80,88 20,88 20,48 8,48"/>'
    }[k];
    return `<svg viewBox="0 0 100 100" width="${h}" height="${h}" style="display:block;" fill="none" stroke="#000" stroke-width="${Math.max(5,9)}" stroke-linejoin="round">${f}</svg>`;
  }

  // placas de cores (feitas na hora, sem usar as placas oficiais)
  function sementeRng(a){ return function(){ a|=0; a=a+0x6D2B79F5|0; let t=Math.imul(a^a>>>15,1|a); t=t+Math.imul(t^t>>>7,61|t)^t; return((t^t>>>14)>>>0)/4294967296; }; }
  const cachePlaca = {};
  function placaCanvas(i){
    if(cachePlaca[i]) return cachePlaca[i];
    const [num, demo] = PLACAS[i], S = 600, R = S/2-6, rng = sementeRng(1000+i*77);
    const m = document.createElement('canvas'); m.width = m.height = S;
    const mc = m.getContext('2d'); mc.fillStyle = '#000'; mc.fillRect(0,0,S,S);
    mc.fillStyle = '#fff'; mc.textAlign = 'center'; mc.textBaseline = 'middle';
    mc.font = `900 ${S*(num.length>1?0.5:0.68)}px "Arial Black",Arial,sans-serif`; mc.fillText(num, S/2, S/2+S*0.03);
    mc.strokeStyle = '#fff'; mc.lineWidth = S*0.05; mc.lineJoin = 'round'; mc.strokeText(num, S/2, S/2+S*0.03);
    const dados = mc.getImageData(0,0,S,S).data;
    const fig = demo ? ['#1f5f8b','#2e78a8','#3b86b8'] : ['#e8793a','#f09a52','#d9603a','#f2a65e'];
    const fun = demo ? ['#f1d08a','#e9c070','#f6dca0'] : ['#8fb04a','#a8c15e','#7c9c3d','#b9c97a','#9bb855'];
    const c = document.createElement('canvas'); c.width = c.height = S;
    const g = c.getContext('2d'), pts = [];
    const CEL = 24, grade = {};
    for(let t=0;t<30000;t++){
      const r = 3.5 + rng()*6, a = rng()*Math.PI*2, d = Math.sqrt(rng())*(R-r);
      const x = S/2+Math.cos(a)*d, y = S/2+Math.sin(a)*d;
      const cx = Math.floor(x/CEL), cy = Math.floor(y/CEL);
      let ok = true;
      for(let i=cx-1;i<=cx+1 && ok;i++) for(let j=cy-1;j<=cy+1 && ok;j++){
        const l = grade[i+','+j]; if(!l) continue;
        for(const p of l){ const dx = p[0]-x, dy = p[1]-y, rr = p[2]+r+1; if(dx*dx+dy*dy < rr*rr){ ok = false; break; } }
      }
      if(ok){ const q = [x,y,r]; pts.push(q); (grade[cx+','+cy] = grade[cx+','+cy] || []).push(q); }
    }
    pts.forEach(([x,y,r])=>{
      const dentro = dados[(Math.round(y)*S+Math.round(x))*4] > 128;
      const pal = dentro ? fig : fun;
      g.fillStyle = pal[Math.floor(rng()*pal.length)];
      g.beginPath(); g.arc(x,y,r,0,Math.PI*2); g.fill();
    });
    return cachePlaca[i] = c;
  }

  function dialSvg(s){
    const cx = 0, cy = 0, r0 = s*0.06, r1 = s*0.4;
    let o = `<svg viewBox="${-s*0.56} ${-s*0.56} ${s*1.12} ${s*1.12}" width="${s}" height="${s}" style="font-family:Arial,sans-serif;">`;
    for(let k=0;k<24;k++){
      const a = k*15*Math.PI/180;
      o += `<line x1="${Math.sin(a)*r0}" y1="${-Math.cos(a)*r0}" x2="${Math.sin(a)*r1}" y2="${-Math.cos(a)*r1}" stroke="#000" stroke-width="${s*0.006}" stroke-linecap="round"/>`;
    }
    for(let k=0;k<24;k++){
      const a = k*15*Math.PI/180, ang = (k*15)%180 || 180, hora = k%2===0;
      if(hora){
        const h = k/2||12;
        o += `<text x="${Math.sin(a)*s*0.45}" y="${-Math.cos(a)*s*0.45}" font-size="${s*0.05}" font-weight="700" text-anchor="middle" dominant-baseline="central" fill="#000">${h}</text>`;
        o += `<text x="${Math.sin(a)*s*0.495}" y="${-Math.cos(a)*s*0.495}" font-size="${s*0.022}" text-anchor="middle" dominant-baseline="central" fill="#888">${ang}°</text>`;
      } else {
        o += `<text x="${Math.sin(a)*s*0.43}" y="${-Math.cos(a)*s*0.43}" font-size="${s*0.022}" text-anchor="middle" dominant-baseline="central" fill="#888">${ang}°</text>`;
      }
    }
    return o + '</svg>';
  }

  function olhoSvg(){
    return `<svg viewBox="0 0 440 260" width="560" height="330" style="font-family:Arial,sans-serif;font-size:14px;">
      <circle cx="210" cy="130" r="100" fill="#fff" stroke="#9aa" stroke-width="3"/>
      <circle cx="210" cy="130" r="93" fill="#dff0f7"/>
      <path d="M210 37A93 93 0 0 1 210 223" fill="none" stroke="#e2733a" stroke-width="8"/>
      <path d="M126 66Q76 130 126 194" fill="none" stroke="#5aa6c8" stroke-width="5"/>
      <line x1="150" y1="68" x2="150" y2="108" stroke="#8a5a2b" stroke-width="9" stroke-linecap="round"/>
      <line x1="150" y1="152" x2="150" y2="192" stroke="#8a5a2b" stroke-width="9" stroke-linecap="round"/>
      <ellipse cx="166" cy="130" rx="13" ry="30" fill="#cfe9f5" stroke="#4a90b0" stroke-width="2"/>
      <circle cx="298" cy="130" r="6" fill="#f4b400"/>
      <path d="M302 146L380 180" stroke="#e8b35a" stroke-width="18" stroke-linecap="round"/>
      <g fill="#333"><text x="14" y="128">Córnea</text><text x="30" y="224">Íris e pupila</text><text x="120" y="22">Cristalino</text><text x="196" y="130" text-anchor="middle">Humor vítreo</text><text x="290" y="22">Retina</text><text x="318" y="112">Mácula</text><text x="340" y="215">Nervo óptico</text></g>
    </svg>`;
  }

  /* ---------- tela de cada teste ---------- */
  function render(){
    const ov = O.ov, p = O.palco, t = O.t;
    ov.classList.toggle('escuro', t===8 || t===18);
    p.classList.toggle('rola', t===14 || t===12);
    p.style.transform = '';
    const { h, n, pw, ph } = tamanho();
    const den = LIN[O.linha];
    let html = '', rot = null, info = '';
    const min = Math.min(pw, ph);
    if(t===1) html = linha(O.seq.slice(0,n), h, c=>`<span style="font:900 ${h/0.72}px 'Arial Black',Arial,sans-serif;line-height:1;">${c}</span>`);
    else if(t===2) html = linha(O.seq.slice(0,n), h, c=>`<span style="font:900 ${h/0.72}px 'Arial Black',Arial,sans-serif;line-height:1;">${c}</span>`);
    else if(t===3) html = linha(O.seq.slice(0,n), h, d=>svgE(h,d));
    else if(t===4) html = linha(O.seq.slice(0,n), h, d=>svgC(h,d));
    else if(t===9) html = linha(O.seq.slice(0,n), h, k=>svgForma(k,h));
    else if(t===5){
      const [num, demo] = PLACAS[O.placa];
      const side = Math.min(ph*0.84, pw*0.9);
      html = `<div style="text-align:center;"><canvas id="opPlaca" width="600" height="600" style="width:${side}px;height:${side}px;"></canvas><div style="font:13px Arial;color:#888;margin-top:-4px;">Placa ${O.placa+1}/${PLACAS.length}${demo?' · Demonstração':''}</div></div>`;
      info = `Placa ${O.placa+1}/${PLACAS.length}${demo?' (demonstração)':''}. Resposta: ${num}`;
    }
    else if(t===6){
      const dens = LIN.slice(O.duo, O.duo+5);
      const col = (cor)=>`<div style="flex:1;height:100%;background:${cor};display:flex;flex-direction:column;align-items:center;justify-content:center;gap:${Math.round(ph*0.03)}px;padding-bottom:70px;">${dens.map((d,i)=>{ const hh = Math.min(px(d), ph*0.13, pw/22); return `<div style="font:900 ${hh/0.72}px 'Arial Black',Arial,sans-serif;line-height:1;letter-spacing:${hh*0.4}px;color:#111;white-space:nowrap;">${O.duoLetras[i].join('')}</div>`; }).join('')}</div>`;
      html = `<div style="position:absolute;inset:0;display:flex;">${col('#e0291c')}${col('#1fbf3f')}</div>`;
    }
    else if(t===7){ const s = Math.min(pw*0.95, ph*0.98); html = dialSvg(s); }
    else if(t===8){
      const d = Math.max(30, min*0.1*(O.worth||1)), g = d*0.25;
      const bola = (x,y,c)=>`<div style="position:absolute;left:calc(50% + ${x}px - ${d/2}px);top:calc(50% + ${y}px - ${d/2}px);width:${d}px;height:${d}px;border-radius:50%;background:${c};"></div>`;
      html = `<div style="position:relative;width:100%;height:100%;">${bola(0,-(d+g)*0.9,'#ee2e1f')}${bola(-(d+g)*0.9,0,'#12c444')}${bola((d+g)*0.9,0,'#12c444')}${bola(0,(d+g)*0.9,'#e8e8e8')}</div>`;
    }
    else if(t===10 || t===18){
      const cor = t===18 ? '#e02424' : '#000';
      const s = Math.min(pw*0.85, ph*0.85), q = s/20; let l = '';
      for(let i=0;i<=20;i++) l += `<line x1="${i*q}" y1="0" x2="${i*q}" y2="${s}" stroke="${cor}" stroke-width="1"/><line x1="0" y1="${i*q}" x2="${s}" y2="${i*q}" stroke="${cor}" stroke-width="1"/>`;
      html = `<svg width="${s}" height="${s}" viewBox="-2 -2 ${s+4} ${s+4}">${l}<circle cx="${s/2}" cy="${s/2}" r="${Math.max(3,q*0.18)}" fill="${cor}"/></svg>`;
    }
    else if(t===11){
      const L = min*0.28;
      html = `<svg width="${L*2}" height="${L*2}" viewBox="-100 -100 200 200"><line x1="-100" y1="0" x2="100" y2="0" stroke="#000" stroke-width="7"/><line x1="0" y1="-100" x2="0" y2="100" stroke="#000" stroke-width="7"/><circle r="9" fill="#000"/></svg>`;
    }
    else if(t===12){
      const J = [['J1',4.5],['J2',5.5],['J3',6.5],['J4',8],['J5',9],['J6',10.5],['J8',12.5],['J10',15],['J14',21]];
      const txt = ['O sol nasce todos os dias.','A casa fica perto da escola.','Meu irmão gosta de ler jornal.','Leia com calma, sem forçar a vista.'];
      html = `<div style="max-width:${pw*0.9}px;padding:20px 24px 100px;text-align:left;"><div style="font:700 20px Arial;margin-bottom:4px;">Leitura de perto (Jaeger)</div><div style="font:13px Arial;color:#666;margin-bottom:14px;">Segure o cartão a 40 cm. Tamanhos aproximados, calibrados pela tela.</div>${J.map(([n,pt],i)=>`<div style="display:flex;align-items:baseline;gap:14px;margin:${pt*0.5}px 0;"><span style="font:600 12px Arial;color:#888;width:34px;">${n}</span><span style="font:${pt*0.3528*tt.pxmm}px Arial,sans-serif;">${txt[i%txt.length]}</span></div>`).join('')}</div>`;
    }
    else if(t===13){
      const niveis = [1,0.5,0.25,0.12,0.06], hc = Math.min(h, pw/9, ph*0.5);
      html = linha(niveis, hc, c=>`<span style="font:700 ${hc/0.72}px Arial,sans-serif;line-height:1;color:rgb(${Math.round(255*(1-c))},${Math.round(255*(1-c))},${Math.round(255*(1-c))});">V</span>`);
    }
    else if(t===14){
      const parts = [['Córnea','Lente transparente na frente do olho.'],['Íris e pupila','Controlam a entrada de luz.'],['Cristalino','Foca de longe e de perto.'],['Humor vítreo','Gel que enche o olho.'],['Esclera','Parte branca que protege.'],['Retina','Capta a imagem.'],['Mácula','Visão central e de detalhes.'],['Nervo óptico','Leva a imagem ao cérebro.']];
      html = `<div style="padding:16px 20px 100px;text-align:center;max-width:900px;"><div style="font:700 22px Arial;margin-bottom:6px;">Educação ocular</div>${olhoSvg()}<div style="display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin-top:10px;">${parts.map(([a,b])=>`<div class="opCard"><b>${a}</b><span>${b}</span></div>`).join('')}</div></div>`;
    }
    else if(t===16){
      const hp = Math.min(ph/19, pw/22);
      if(!O.pr) O.pr = Array.from({length:16},()=>sorteia(LETRAS,3));
      const cel = i=>{ const g = Math.round(255*(1-Math.pow(10,-0.15*i))); return `<span style="font:700 ${hp/0.72}px Arial,sans-serif;line-height:1;letter-spacing:${hp*0.45}px;color:rgb(${g},${g},${g});">${O.pr[i].join('')}</span>`; };
      let ls = ''; for(let r=0;r<8;r++) ls += `<div style="display:flex;gap:${hp*1.6}px;justify-content:center;margin:${hp*0.35}px 0;">${cel(r*2)}${cel(r*2+1)}</div>`;
      html = `<div>${ls}</div>`;
      info = 'Grupos de 3 letras, cada um mais claro. Anote o último em que leu 2 de 3. Cada letra lida vale 0,05.';
    }
    else if(t===17){
      const logs = Array.from({length:14},(_,i)=>1-i*0.1), dens = logs.map(l=>20*Math.pow(10,l));
      if(!O.et) O.et = [];
      const alvo = ph*0.96; let y = 0, i = O.etdrs, ls = '';
      while(i<14){
        const hh = Math.min(px(dens[i]), alvo/1.6), gap = i<13 ? Math.min(px(dens[i+1]), hh)*0.6 : 0;
        if(i>O.etdrs && y+hh*1.39>alvo) break;
        if(!O.et[i]) O.et[i] = sorteia(LETRAS,5,O.et[i-1]);
        const nn = Math.max(1, Math.min(5, Math.floor(pw/(hh*1.9))));
        ls += `<div style="display:flex;gap:${hh*0.8}px;justify-content:center;margin-bottom:${gap}px;">${O.et[i].slice(0,nn).map(c=>`<span style="font:900 ${hh/0.72}px 'Arial Black',Arial,sans-serif;line-height:1;">${c}</span>`).join('')}</div>`;
        y += hh*1.39+gap; i++;
      }
      html = `<div>${ls}</div>`;
      rot = `20/${Math.round(dens[O.etdrs])} (logMAR ${logs[O.etdrs].toFixed(1).replace('.',',')})`;
      info = rot;
    }
    else if(t===19){
      const alvo = ph*0.96; let y = 0, i = O.linha, ls = '';
      while(i<SNELLEN.length){
        const hh = Math.min(px(LIN[i]), alvo/1.6);
        if(i>O.linha && y+hh*1.6>alvo) break;
        const letras = SNELLEN[i].split(''), nn = Math.max(1, Math.min(letras.length, Math.floor(pw/(hh*1.9))));
        ls += `<div style="display:flex;gap:${hh*0.7}px;justify-content:center;margin-bottom:${hh*0.6}px;align-items:center;"><span style="font:600 ${Math.max(11,Math.min(16,hh*0.5))}px Arial;color:#999;width:50px;text-align:right;">${LIN[i]}</span>${letras.slice(0,nn).map(c=>`<span style="font:900 ${hh/0.72}px 'Arial Black',Arial,sans-serif;line-height:1;">${c}</span>`).join('')}</div>`;
        y += hh*1.6; i++;
      }
      html = `<div>${ls}</div>`;
    }
    else if(t===15){
      const L = min*0.45;
      html = `<svg width="${L*2}" height="${L*2}" viewBox="-100 -100 200 200"><line x1="-100" y1="0" x2="100" y2="0" stroke="#000" stroke-width="3" stroke-linecap="round"/><line x1="0" y1="-100" x2="0" y2="100" stroke="#000" stroke-width="3" stroke-linecap="round"/></svg>`;
    }
    p.innerHTML = html;
    if(COM_ESPELHO.includes(t) && tt.espelho) p.style.transform = 'scaleX(-1)';
    if(t===5){ const cv = p.querySelector('#opPlaca'); cv.getContext('2d').drawImage(placaCanvas(O.placa),0,0); }

    const dec = (20/den).toFixed(2).replace('.',',');
    O.rotulo = rot!==null ? rot : (COM_ACUIDADE.includes(t) ? `20/${den} (${dec})` : (t===5 ? '' : NOMES[t-1]));
    O.ov.querySelector('#opRot').textContent = O.rotulo;
    O.ov.querySelectorAll('#opBarra button[data-t]').forEach(b=> b.classList.toggle('on', +b.dataset.t===t));
    enviarEstado(COM_ACUIDADE.includes(t) ? `20/${den} (${dec})` : (info || ''));
  }

  /* ---------- ações ---------- */
  function irPara(t){ O.t = Math.max(1, Math.min(TOTAL, t)); O.seq = []; novaSequencia(); render(); }
  function aviso(txt){ const a = O.ov.querySelector('#opAviso'); a.textContent = txt; a.style.opacity = 1; clearTimeout(O.avT); O.avT = setTimeout(()=>{ a.style.opacity = 0; }, 1400); }
  function maior(){ if(O.t===17){ O.etdrs = Math.max(0, O.etdrs-1); } else if(O.t===6){ O.duo = Math.max(0, O.duo-1); } else if(O.t===8){ O.worth = Math.min(3,(O.worth||1)*1.25); } else O.linha = Math.max(0, O.linha-1); novaSequencia(); render(); }
  function menor(){ if(O.t===17){ O.etdrs = Math.min(13, O.etdrs+1); } else if(O.t===6){ O.duo = Math.min(LIN.length-5, O.duo+1); } else if(O.t===8){ O.worth = Math.max(0.3,(O.worth||1)/1.25); } else O.linha = Math.min(LIN.length-1, O.linha+1); novaSequencia(); render(); }
  function novas(){
    if(O.t===5){ O.placa = (O.placa+1)%PLACAS.length; }
    else if(O.t===16){ O.pr = null; }
    else if(O.t===17){ O.et = []; }
    else { novaSequencia(); O.duoLetras = Array.from({length:5},()=>sorteia(LETRAS,5)); }
    render();
  }
  function placaAnt(){ O.placa = (O.placa+PLACAS.length-1)%PLACAS.length; render(); }
  function telaCheia(){
    try{ if(document.fullscreenElement) document.exitFullscreen(); else O.ov.requestFullscreen && O.ov.requestFullscreen(); }catch(e){}
  }
  function espelho(){ tt.espelho = !tt.espelho; render(); aviso(tt.espelho ? 'Modo espelho ligado' : 'Modo espelho desligado'); }
  function fechar(){
    O.vivo = false; enviarEstado('', false);
    document.removeEventListener('keydown', tecla, true);
    try{ if(document.fullscreenElement) document.exitFullscreen(); }catch(e){}
    O.ov.remove(); O = null;
  }

  function tecla(e){
    if(!O || e.ctrlKey || e.metaKey) return;
    if(O.ov.querySelector('.opDlg')){ if(e.key==='Escape'){ O.ov.querySelectorAll('.opDlg').forEach(d=>d.remove()); e.preventDefault(); } return; }
    const k = e.key.length===1 ? e.key.toLowerCase() : e.key;
    if(e.altKey && k==='f'){ telaCheia(); e.preventDefault(); return; }
    if(k==='Escape'){ fechar(); return; }
    if(k==='ArrowDown'){ menor(); e.preventDefault(); }
    else if(k==='ArrowUp'){ maior(); e.preventDefault(); }
    else if(k==='ArrowRight'){ novas(); e.preventDefault(); }
    else if(k==='ArrowLeft'){ if(O.t===5) placaAnt(); else novas(); e.preventDefault(); }
    else if(k===','){ irPara(O.t===1?TOTAL:O.t-1); }
    else if(k==='.'){ irPara(O.t===TOTAL?1:O.t+1); }
    else if(k==='?' || k==='h'){ ajuda(); }
    else if(k==='m'){ espelho(); }
    else if(TECLAS_TESTE[k]){ irPara(TECLAS_TESTE[k]); }
  }

  function comando(c){
    if(!O) return;
    switch(c.acao){
      case 'maior': maior(); break;
      case 'menor': menor(); break;
      case 'novas': novas(); break;
      case 'espelho': espelho(); break;
      case 'anterior': irPara(O.t===1?TOTAL:O.t-1); break;
      case 'proximo': irPara(O.t===TOTAL?1:O.t+1); break;
      case 'teste': irPara(parseInt(c.valor,10)||1); break;
      case 'sair': fechar(); break;
    }
  }

  /* ---------- ajuda e celular ---------- */
  function dialogo(html){
    const d = document.createElement('div'); d.className = 'opDlg';
    d.innerHTML = `<div>${html}<button class="fechar">Fechar</button></div>`;
    d.addEventListener('click', e=>{ if(e.target===d || e.target.classList.contains('fechar')) d.remove(); });
    O.ov.appendChild(d); return d;
  }
  function ajuda(){
    dialogo(`<h3>Como usar o optotipo</h3>
      <p>Mostre ao paciente na distância calibrada. Troque o teste pela barra de baixo, pelo teclado ou pelo celular.</p>
      <p>No E direcional e no C de Landolt, a posição nunca se repete na mesma casa da linha anterior.</p>
      <p><b>Teclas de atalho</b></p>
      <div class="opCol"><div><code>1</code> a <code>9</code> testes 1 a 9<br><code>F</code> Fixação<br><code>C</code> Contraste<br><code>X</code> ou <code>+</code> Cruz<br><code>D</code> Dial astigmático</div>
      <div><code>A</code> Amsler<br><code>J</code> Leitura de perto<br><code>E</code> Educação ocular<br><code>B</code> Duocromo<br><code>P</code> Contraste por letras<br><code>L</code> Tabela ETDRS<br><code>R</code> Amsler vermelho<br><code>S</code> Tabela de Snellen<br><code>M</code> Modo espelho</div></div>
      <p><b>Comandos</b></p>
      <p><code>,</code> teste anterior · <code>.</code> próximo teste<br><code>↓</code> letra menor · <code>↑</code> letra maior<br><code>←</code> <code>→</code> nova sequência (nas placas de cores, troca a placa)<br><code>Alt</code>+<code>F</code> tela cheia<br><code>Esc</code> sair · <code>?</code> ou <code>H</code> esta ajuda</p>`);
  }
  const NO_AR = () => location.protocol==='https:' && !/^(localhost|127\.|192\.168\.|10\.)/.test(location.hostname);
  function urlCelular(ip){ return NO_AR() ? `${location.origin}/optotipo/celular?c=${O.codigo}` : `http://${ip}:${O.porta}/optotipo/celular?c=${O.codigo}`; }
  function mostrarQr(){
    const ip = (O.enderecos && O.enderecos[0]) || location.hostname || 'localhost';
    const url = urlCelular(ip);
    let qr = '';
    try{ const q = qrcode(0,'M'); q.addData(url); q.make(); qr = q.createSvgTag(6,2); }catch(e){ qr = '<p>Não consegui desenhar o QR Code.</p>'; }
    const outros = NO_AR() ? '' : (O.enderecos||[]).slice(1).map(i=>`<br>${urlCelular(i)}`).join('');
    dialogo(`<h3 style="text-align:center;">Controle pelo celular</h3>
      <div style="text-align:center;width:240px;margin:0 auto;">${qr}</div>
      <p style="text-align:center;">Aponte a câmera do celular para o QR Code.<br>${NO_AR()?'O celular pode estar em qualquer internet.':'O celular precisa estar no mesmo Wi-Fi do computador.'}</p>
      <p style="text-align:center;">Código: <code>${O.codigo}</code></p>
      <p style="font-size:12px;color:#666;text-align:center;word-break:break-all;">Se não abrir, digite no celular:<br>${url}${outros}<br>Ainda não abre? Dê dois cliques em <b>liberar-celular.bat</b> na pasta do sistema.</p>`);
  }
  async function conectarCelular(){
    if(O.codigo){ mostrarQr(); return; }
    try{
      const s = await api('/optotipo/sessao', { method:'POST', body:{} });
      O.codigo = s.codigo; O.enderecos = s.enderecos; O.porta = s.porta; O.n = 0;
      mostrarQr(); enviarEstado(O.rotulo||''); esperar();
    }catch(e){ if(typeof erroApi==='function') erroApi(e); else alert(e.message); }
  }
  async function esperar(){
    const meu = O;
    while(O===meu && O.vivo && O.codigo){
      try{
        const r = await fetch(`${API_BASE}/optotipo/${O.codigo}/esperar?desde=${O.n}`);
        if(!r.ok){ O.codigo = null; break; }
        const j = await r.json(); O.n = j.n; j.cmds.forEach(comando);
      }catch(e){ await new Promise(ok=>setTimeout(ok,2000)); }
    }
  }
  function enviarEstado(rot, ativo){
    if(!O || !O.codigo) return;
    fetch(`${API_BASE}/optotipo/${O.codigo}/estado`, { method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({ teste:O.t, nome:NOMES[O.t-1], rotulo:rot||'', ativo:ativo!==false }) }).catch(()=>{});
  }

  /* ---------- abrir ---------- */
  window.abrirOptotipo = function(){
    if(O) return;
    estilo();
    const ov = document.createElement('div'); ov.id = 'opto';
    ov.innerHTML = `<div id="opPalco"></div><div id="opAviso"></div>
      <button id="opCel">📱 Conectar celular</button>
      <div id="opRodape"><div id="opBarra">${NOMES.map((n,i)=>`<button data-t="${i+1}" title="${n}">${i+1}</button>`).join('')}<span class="sep"></span><button id="opTela" title="Tela cheia">⛶</button><button id="opAj" title="Ajuda">?</button><button id="opSair" title="Sair">⎋</button></div><div id="opRot"></div></div>`;
    document.body.appendChild(ov);
    O = { ov, palco: ov.querySelector('#opPalco'), t:1, linha:0, seq:[], duo:3, duoLetras:[], placa:0, vivo:true, codigo:null, n:0, worth:1, etdrs:0, et:[], pr:null };
    novaSequencia(); O.duoLetras = Array.from({length:5},()=>sorteia(LETRAS,5));
    ov.querySelectorAll('#opBarra button[data-t]').forEach(b=> b.onclick = ()=> irPara(+b.dataset.t));
    ov.querySelector('#opTela').onclick = telaCheia;
    ov.querySelector('#opAj').onclick = ajuda;
    ov.querySelector('#opSair').onclick = fechar;
    ov.querySelector('#opCel').onclick = conectarCelular;
    document.addEventListener('keydown', tecla, true);
    window.addEventListener('resize', ()=>{ if(O) render(); });
    try{ ov.requestFullscreen && ov.requestFullscreen(); }catch(e){}
    render();
  };
})();
