const express = require('express');
const pool = require('../db/pool');
const { exigirLogin } = require('../middleware/auth');

/* Pós-venda: o gestor de vendas cuida do cliente depois da compra (adaptação, ajuste, garantia) e do relacionamento
   (aniversário, datas comemorativas, revisão anual). O administrador também usa. */
const router = express.Router();
router.use(exigirLogin);
router.use((req, res, next) => {
  if (req.usuario.papel !== 'gestor' && req.usuario.papel !== 'admin') return res.status(403).json({ erro: 'Esta área é do gestor de vendas.' });
  next();
});

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const DATA = /^\d{4}-\d{2}-\d{2}$/;
const hoje = () => new Date(Date.now() - 3 * 3600000).toISOString().slice(0, 10);
const dataOk = (d) => DATA.test(String(d || '')) && !isNaN(new Date(d + 'T12:00:00Z'));
const dinheiro = (v) => { if (v === '' || v == null) return null; const n = Number(String(v).replace(/\./g, '').replace(',', '.')); return isFinite(n) ? Math.round(n * 100) / 100 : NaN; };
const soNum = (t) => String(t || '').replace(/\D/g, '');

/* cidade do gestor, se ele for de uma cidade só */
function filtroCidade(req, params, alias) {
  if (!req.usuario.unidadeId) return '';
  params.push(req.usuario.unidadeId);
  return ` AND ${alias}.unidade_id=$${params.length}`;
}
async function clienteDaClinica(req, id) {
  if (!UUID.test(String(id || ''))) return null;
  const params = [id, req.usuario.clinicaId];
  const f = filtroCidade(req, params, 'p');
  const r = await pool.query(`SELECT p.id, p.nome_completo, p.telefone, p.data_nascimento, p.aceita_promocao, p.unidade_id FROM pacientes p WHERE p.id=$1 AND p.clinica_id=$2 AND p.deletado_em IS NULL${f}`, params);
  return r.rows[0] || null;
}

/* ---------- datas comemorativas ---------- */
function nesimoDiaSemana(ano, mes, diaSemana, n) { // mes 1..12, diaSemana 0=domingo
  const d = new Date(Date.UTC(ano, mes - 1, 1));
  const primeiro = (7 + diaSemana - d.getUTCDay()) % 7;
  return new Date(Date.UTC(ano, mes - 1, 1 + primeiro + (n - 1) * 7));
}
const fmt = (d) => d.toISOString().slice(0, 10);
function datasDoAno(ano) {
  const blackFriday = nesimoDiaSemana(ano, 11, 4, 4); blackFriday.setUTCDate(blackFriday.getUTCDate() + 1);
  return [
    { codigo: 'ano-novo', nome: 'Ano Novo', data: `${ano}-01-01` },
    { codigo: 'volta-aulas', nome: 'Volta às aulas', data: `${ano}-02-01` },
    { codigo: 'maes', nome: 'Dia das Mães', data: fmt(nesimoDiaSemana(ano, 5, 0, 2)) },
    { codigo: 'namorados', nome: 'Dia dos Namorados', data: `${ano}-06-12` },
    { codigo: 'pais', nome: 'Dia dos Pais', data: fmt(nesimoDiaSemana(ano, 8, 0, 2)) },
    { codigo: 'cliente', nome: 'Dia do Cliente', data: `${ano}-09-15` },
    { codigo: 'visao', nome: 'Dia Mundial da Visão', data: fmt(nesimoDiaSemana(ano, 10, 4, 2)) },
    { codigo: 'criancas', nome: 'Dia das Crianças', data: `${ano}-10-12` },
    { codigo: 'blackfriday', nome: 'Black Friday', data: fmt(blackFriday) },
    { codigo: 'natal', nome: 'Natal', data: `${ano}-12-25` },
  ].map((x) => ({ ...x, campanha: `${x.codigo}-${ano}` }));
}
router.get('/datas', (req, res) => {
  const h = hoje(), ano = Number(h.slice(0, 4));
  const todas = [...datasDoAno(ano), ...datasDoAno(ano + 1)];
  const limite = new Date(Date.parse(h) + 150 * 86400000).toISOString().slice(0, 10);
  const antes = new Date(Date.parse(h) - 5 * 86400000).toISOString().slice(0, 10);
  res.json(todas.filter((x) => x.data >= antes && x.data <= limite));
});

/* ---------- painel de hoje ---------- */
router.get('/hoje', async (req, res) => {
  const h = hoje(), mmdd = h.slice(5), ano = h.slice(0, 4), clin = req.usuario.clinicaId;
  const pa = [clin, mmdd, `aniv-${ano}`]; const fa = filtroCidade(req, pa, 'p');
  const aniv = await pool.query(
    `SELECT p.id, p.nome_completo, p.telefone, p.data_nascimento FROM pacientes p
     WHERE p.clinica_id=$1 AND p.deletado_em IS NULL AND p.data_nascimento IS NOT NULL AND to_char(p.data_nascimento,'MM-DD')=$2
       AND p.aceita_promocao AND COALESCE(p.telefone,'')<>'' AND NOT EXISTS (SELECT 1 FROM posvenda_envios e WHERE e.clinica_id=p.clinica_id AND e.paciente_id=p.id AND e.campanha=$3)${fa}
     ORDER BY p.nome_completo LIMIT 100`, pa);
  const { listarEnvios } = require('./envios');
  const env = await listarEnvios(clin, req.usuario.unidadeId);
  const adaptacao = env.agora.filter((x) => x.etapa === 'pos_oculos');
  const po = [clin, h]; const fo = filtroCidade(req, po, 'p');
  const oc = await pool.query(
    `SELECT COUNT(*) FILTER (WHERE o.status <> 'resolvida')::int AS abertas,
            COUNT(*) FILTER (WHERE o.status <> 'resolvida' AND o.prazo < $2::date)::int AS atrasadas
     FROM posvenda_ocorrencias o JOIN pacientes p ON p.id=o.paciente_id WHERE o.clinica_id=$1${fo}`, po);
  const pv = [clin, h]; const fv = filtroCidade(req, pv, 'p');
  const visitas = await pool.query(
    `SELECT o.id, o.tipo, o.visita_em, p.nome_completo AS paciente_nome, p.telefone FROM posvenda_ocorrencias o JOIN pacientes p ON p.id=o.paciente_id
     WHERE o.clinica_id=$1 AND o.status <> 'resolvida' AND o.visita_em::date=$2::date${fv} ORDER BY o.visita_em`, pv);
  const pr = [clin, h]; const fr = filtroCidade(req, pr, 'p');
  const resp = await pool.query(
    `SELECT v.id AS venda_id, p.id AS paciente_id, p.nome_completo AS paciente_nome, p.telefone, v.pos_resposta, v.pos_resposta_em
     FROM vendas_oculos v JOIN pacientes p ON p.id=v.paciente_id
     WHERE v.clinica_id=$1 AND v.pos_resposta IS NOT NULL AND v.pos_situacao IS NULL AND v.pos_resposta_em::date >= $2::date - 30${fr} ORDER BY v.pos_resposta_em DESC LIMIT 50`, pr);
  res.json({ data: h, adaptacao, aniversarios: aniv.rows, ocorrencias: oc.rows[0], visitas: visitas.rows, respostas: resp.rows });
});

/* quem recebeu o aviso de adaptação: marca enviado ou resolve o retorno */
router.post('/adaptacao/:vendaId/enviado', async (req, res) => {
  if (!UUID.test(req.params.vendaId)) return res.status(400).json({ erro: 'Venda inválida.' });
  const params = [req.params.vendaId, req.usuario.clinicaId];
  const f = req.usuario.unidadeId ? (params.push(req.usuario.unidadeId), ' AND unidade_id=$3') : '';
  const r = await pool.query(`UPDATE vendas_oculos SET pos_enviado=TRUE, pos_enviado_em=COALESCE(pos_enviado_em, NOW()) WHERE id=$1 AND clinica_id=$2${f} RETURNING id`, params);
  if (!r.rows.length) return res.status(404).json({ erro: 'Venda não encontrada.' });
  res.json({ ok: true });
});
router.patch('/vendas/:id/retorno', async (req, res) => {
  if (!UUID.test(req.params.id)) return res.status(400).json({ erro: 'Venda inválida.' });
  const sit = req.body.situacao === 'ok' || req.body.situacao === 'problema' ? req.body.situacao : null;
  const params = [sit, String(req.body.obs || '').slice(0, 500) || null, req.params.id, req.usuario.clinicaId];
  const f = req.usuario.unidadeId ? (params.push(req.usuario.unidadeId), ' AND unidade_id=$5') : '';
  const r = await pool.query(`UPDATE vendas_oculos SET pos_situacao=$1, pos_obs=$2 WHERE id=$3 AND clinica_id=$4${f} RETURNING id`, params);
  if (!r.rows.length) return res.status(404).json({ erro: 'Venda não encontrada.' });
  res.json({ ok: true });
});

/* ---------- clientes ---------- */
router.get('/clientes', async (req, res) => {
  const q = String(req.query.q || '').trim().slice(0, 60);
  if (q.length < 2) return res.json([]);
  const params = [req.usuario.clinicaId, `%${q}%`, soNum(q) ? `%${soNum(q)}%` : null];
  const f = filtroCidade(req, params, 'p');
  const r = await pool.query(
    `SELECT p.id, p.nome_completo, p.telefone, p.data_nascimento, p.aceita_promocao, un.nome AS unidade_nome,
            (SELECT MAX(v.vendido_em) FROM vendas_oculos v WHERE v.paciente_id=p.id AND v.resultado <> 'nao_comprou') AS ultima_compra
     FROM pacientes p LEFT JOIN unidades un ON un.id=p.unidade_id
     WHERE p.clinica_id=$1 AND p.deletado_em IS NULL AND (p.nome_completo ILIKE $2 OR ($3::text IS NOT NULL AND regexp_replace(COALESCE(p.telefone,''),'\\D','','g') LIKE $3))${f}
     ORDER BY p.nome_completo LIMIT 30`, params);
  res.json(r.rows);
});

router.get('/clientes/:id', async (req, res) => {
  const c = await clienteDaClinica(req, req.params.id);
  if (!c) return res.status(404).json({ erro: 'Cliente não encontrado.' });
  const compras = await pool.query(
    `SELECT id, resultado, valor_venda::float AS valor_venda, vendido_em, entregue_em, garantia_ate, observacoes, pos_enviado, pos_resposta, pos_situacao, pos_obs, agendador_nome
     FROM vendas_oculos WHERE paciente_id=$1 AND clinica_id=$2 ORDER BY vendido_em DESC`, [c.id, req.usuario.clinicaId]);
  const ocorr = await pool.query(
    `SELECT id, tipo, descricao, status, prazo, visita_em, resolucao, criado_em FROM posvenda_ocorrencias WHERE paciente_id=$1 AND clinica_id=$2 ORDER BY criado_em DESC LIMIT 30`, [c.id, req.usuario.clinicaId]);
  const envios = await pool.query(`SELECT campanha, enviado_em, enviado_por_nome FROM posvenda_envios WHERE paciente_id=$1 AND clinica_id=$2 ORDER BY enviado_em DESC LIMIT 20`, [c.id, req.usuario.clinicaId]);
  const ex = await pool.query(`SELECT MAX(data_hora) AS ultimo FROM agendamentos WHERE paciente_id=$1 AND status='realizado'`, [c.id]);
  res.json({ cliente: c, ultimo_exame: ex.rows[0].ultimo, compras: compras.rows, ocorrencias: ocorr.rows, envios: envios.rows });
});

router.patch('/clientes/:id/promocao', async (req, res) => {
  const c = await clienteDaClinica(req, req.params.id);
  if (!c) return res.status(404).json({ erro: 'Cliente não encontrado.' });
  await pool.query(`UPDATE pacientes SET aceita_promocao=$1 WHERE id=$2`, [req.body.aceita !== false, c.id]);
  res.json({ ok: true });
});

/* venda feita direto no balcão, sem agendador: entra no pós-venda e no retorno de 20 dias, sem comissão */
router.post('/vendas', async (req, res) => {
  const c = await clienteDaClinica(req, req.body.paciente_id);
  if (!c) return res.status(404).json({ erro: 'Cliente não encontrado.' });
  const resultado = ['completa', 'lente', 'armacao'].includes(req.body.resultado) ? req.body.resultado : 'completa';
  const valor = dinheiro(req.body.valor_venda);
  if (valor !== null && !(valor >= 0 && valor <= 200000)) return res.status(400).json({ erro: 'Valor da venda inválido.' });
  const vendido = req.body.vendido_em || hoje(), entregue = req.body.entregue_em || null;
  if (!dataOk(vendido) || (entregue && !dataOk(entregue))) return res.status(400).json({ erro: 'Data inválida.' });
  let garantia = req.body.garantia_ate || null;
  if (garantia && !dataOk(garantia)) return res.status(400).json({ erro: 'Data da garantia inválida.' });
  if (!garantia) { const d = new Date((entregue || vendido) + 'T12:00:00Z'); d.setUTCFullYear(d.getUTCFullYear() + 1); garantia = d.toISOString().slice(0, 10); }
  const r = await pool.query(
    `INSERT INTO vendas_oculos (clinica_id, unidade_id, paciente_id, valor_venda, comissao, comissao_cheia, resultado, vendido_em, entregue_em, garantia_ate, observacoes, criado_por_nome)
     VALUES ($1,$2,$3,$4,0,0,$5,$6,$7,$8,$9,$10) RETURNING id`,
    [req.usuario.clinicaId, c.unidade_id, c.id, valor, resultado, vendido, entregue, garantia, String(req.body.observacoes || '').slice(0, 500) || null, req.usuario.nome || null]);
  res.status(201).json({ id: r.rows[0].id });
});

/* ---------- ocorrências: ajuste, garantia, troca, reclamação ---------- */
const TIPOS_OC = ['ajuste', 'garantia', 'troca', 'reclamacao', 'outro'];
const STATUS_OC = ['aberta', 'andamento', 'resolvida'];
router.get('/ocorrencias', async (req, res) => {
  const params = [req.usuario.clinicaId];
  let filtro = '';
  if (req.query.status === 'resolvidas') filtro = " AND o.status='resolvida'"; else if (req.query.status !== 'todas') filtro = " AND o.status<>'resolvida'";
  const f = filtroCidade(req, params, 'p');
  const r = await pool.query(
    `SELECT o.id, o.paciente_id, o.tipo, o.descricao, o.status, o.prazo, o.visita_em, o.resolucao, o.resolvida_em, o.criado_em, o.criado_por_nome, p.nome_completo AS paciente_nome, p.telefone
     FROM posvenda_ocorrencias o JOIN pacientes p ON p.id=o.paciente_id
     WHERE o.clinica_id=$1${filtro}${f} ORDER BY (o.status='resolvida'), o.prazo NULLS LAST, o.criado_em DESC LIMIT 200`, params);
  res.json(r.rows);
});
router.post('/ocorrencias', async (req, res) => {
  const c = await clienteDaClinica(req, req.body.paciente_id);
  if (!c) return res.status(404).json({ erro: 'Cliente não encontrado.' });
  const tipo = TIPOS_OC.includes(req.body.tipo) ? req.body.tipo : null;
  const descricao = String(req.body.descricao || '').trim().slice(0, 1000);
  if (!tipo) return res.status(400).json({ erro: 'Escolha o tipo da ocorrência.' });
  if (descricao.length < 3) return res.status(400).json({ erro: 'Conte o que aconteceu.' });
  const prazo = req.body.prazo || null, visita = req.body.visita_em || null;
  if (prazo && !dataOk(prazo)) return res.status(400).json({ erro: 'Prazo inválido.' });
  if (visita && !/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}/.test(visita)) return res.status(400).json({ erro: 'Data da visita inválida.' });
  let vendaId = null;
  if (req.body.venda_id && UUID.test(req.body.venda_id)) { const v = await pool.query(`SELECT id FROM vendas_oculos WHERE id=$1 AND paciente_id=$2`, [req.body.venda_id, c.id]); vendaId = v.rows[0] ? v.rows[0].id : null; }
  const r = await pool.query(
    `INSERT INTO posvenda_ocorrencias (clinica_id, paciente_id, venda_id, tipo, descricao, prazo, visita_em, criado_por_nome) VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING id`,
    [req.usuario.clinicaId, c.id, vendaId, tipo, descricao, prazo, visita, req.usuario.nome || null]);
  res.status(201).json({ id: r.rows[0].id });
});
router.patch('/ocorrencias/:id', async (req, res) => {
  if (!UUID.test(req.params.id)) return res.status(400).json({ erro: 'Ocorrência inválida.' });
  const o = await pool.query(`SELECT o.id, o.paciente_id FROM posvenda_ocorrencias o WHERE o.id=$1 AND o.clinica_id=$2`, [req.params.id, req.usuario.clinicaId]);
  if (!o.rows.length || !(await clienteDaClinica(req, o.rows[0].paciente_id))) return res.status(404).json({ erro: 'Ocorrência não encontrada.' });
  const status = STATUS_OC.includes(req.body.status) ? req.body.status : null;
  const prazo = req.body.prazo === undefined ? undefined : (req.body.prazo || null), visita = req.body.visita_em === undefined ? undefined : (req.body.visita_em || null);
  if (prazo && !dataOk(prazo)) return res.status(400).json({ erro: 'Prazo inválido.' });
  if (visita && !/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}/.test(visita)) return res.status(400).json({ erro: 'Data da visita inválida.' });
  await pool.query(
    `UPDATE posvenda_ocorrencias SET status=COALESCE($1,status),
        prazo=CASE WHEN $2::boolean THEN $3::date ELSE prazo END, visita_em=CASE WHEN $4::boolean THEN $5::timestamp ELSE visita_em END,
        resolucao=COALESCE($6, resolucao), resolvida_em=CASE WHEN COALESCE($1,status)='resolvida' THEN COALESCE(resolvida_em, NOW()) ELSE NULL END, atualizado_em=NOW()
     WHERE id=$7`,
    [status, prazo !== undefined, prazo === undefined ? null : prazo, visita !== undefined, visita === undefined ? null : visita, req.body.resolucao == null ? null : String(req.body.resolucao).slice(0, 1000), req.params.id]);
  res.json({ ok: true });
});

/* ---------- campanhas: lista de quem receber e registro de quem já recebeu ---------- */
router.get('/publico', async (req, res) => {
  const tipo = req.query.tipo, camp = String(req.query.campanha || '').slice(0, 60);
  if (!['aniversario_mes', 'revisao', 'todos'].includes(tipo)) return res.status(400).json({ erro: 'Escolha o público.' });
  if (!/^[a-z0-9-]{3,60}$/.test(camp)) return res.status(400).json({ erro: 'Campanha inválida.' });
  const params = [req.usuario.clinicaId, camp];
  let filtro = '';
  if (tipo === 'aniversario_mes') { params.push(parseInt(req.query.mes, 10) || Number(hoje().slice(5, 7))); filtro = ` AND p.data_nascimento IS NOT NULL AND EXTRACT(MONTH FROM p.data_nascimento)=$${params.length}`; }
  if (tipo === 'revisao') { params.push(Math.min(Math.max(parseInt(req.query.meses, 10) || 11, 3), 36)); filtro = ` AND ult.d IS NOT NULL AND ult.d <= CURRENT_DATE - ($${params.length}::int * 30)`; }
  const f = filtroCidade(req, params, 'p');
  const r = await pool.query(
    `SELECT p.id, p.nome_completo, p.telefone, p.data_nascimento, ult.d AS ultima_compra
     FROM pacientes p
     LEFT JOIN LATERAL (SELECT MAX(v.vendido_em) AS d FROM vendas_oculos v WHERE v.paciente_id=p.id AND v.resultado <> 'nao_comprou') ult ON TRUE
     WHERE p.clinica_id=$1 AND p.deletado_em IS NULL AND p.aceita_promocao AND COALESCE(p.telefone,'')<>''
       AND NOT EXISTS (SELECT 1 FROM posvenda_envios e WHERE e.clinica_id=p.clinica_id AND e.paciente_id=p.id AND e.campanha=$2)${filtro}${f}
     ORDER BY p.nome_completo LIMIT 500`, params);
  res.json(r.rows);
});
router.post('/envios', async (req, res) => {
  const c = await clienteDaClinica(req, req.body.paciente_id);
  if (!c) return res.status(404).json({ erro: 'Cliente não encontrado.' });
  const camp = String(req.body.campanha || '');
  if (!/^[a-z0-9-]{3,60}$/.test(camp)) return res.status(400).json({ erro: 'Campanha inválida.' });
  await pool.query(`INSERT INTO posvenda_envios (clinica_id, paciente_id, campanha, enviado_por_nome) VALUES ($1,$2,$3,$4) ON CONFLICT DO NOTHING`, [req.usuario.clinicaId, c.id, camp, req.usuario.nome || null]);
  res.json({ ok: true });
});

module.exports = router;
