const jwt = require('jsonwebtoken');

const crypto = require('crypto');
/* compara chaves sem revelar, pelo tempo de resposta, quantas letras acertou */
function iguais(a, b) {
  const x = crypto.createHash('sha256').update(String(a || '')).digest();
  const y = crypto.createHash('sha256').update(String(b || '')).digest();
  return crypto.timingSafeEqual(x, y);
}

const SEGREDO = process.env.JWT_SECRET || 'troque-este-segredo-em-producao';

/* Confere no banco se o usuário continua ativo e com o mesmo papel. Guarda o resultado por 30 segundos
   para não pesar. Assim, desativar alguém vale em até 30 segundos, e não em 12 horas. */
const cacheUsuarios = new Map();
const CACHE_MS = 30 * 1000;
async function usuarioAtual(id) {
  const c = cacheUsuarios.get(id);
  if (c && Date.now() - c.em < CACHE_MS) return c.dados;
  const pool = require('../db/pool');
  const r = await pool.query(`SELECT id, clinica_id, unidade_id, papel, nome, permissoes, ativo, sessao_versao FROM usuarios WHERE id=$1`, [id]);
  let dados = r.rows[0] && r.rows[0].ativo ? r.rows[0] : null;
  if (dados) {
    const ids = new Set((await pool.query(`SELECT unidade_id FROM usuarios_unidades WHERE usuario_id=$1`, [id])).rows.map((x) => x.unidade_id));
    if (dados.unidade_id) ids.add(dados.unidade_id);
    dados = { ...dados, unidadeIds: [...ids] };
  }
  cacheUsuarios.set(id, { em: Date.now(), dados });
  return dados;
}
function limparCacheUsuario(id) { if (id) cacheUsuarios.delete(id); else cacheUsuarios.clear(); }
setInterval(() => { const a = Date.now(); for (const [k, v] of cacheUsuarios) if (a - v.em > CACHE_MS) cacheUsuarios.delete(k); }, 60000).unref();

/* Quais partes do sistema entram no registro de acessos (quem abriu ou mexeu em dado de saúde) */
const AREAS_REGISTRADAS = { '/posvenda': 'posvenda', '/pacientes': 'paciente', '/prontuarios': 'prontuario', '/receitas': 'receita', '/testes-visao': 'teste_visao', '/financeiro': 'financeiro', '/agendamentos': 'agendamento', '/agendas': 'agenda',
  /* v4.9.20: o Vigia também vê mudanças de cidade, feriado, configuração, lista de espera, pós-exame e OCO */
  '/unidades': 'cidade', '/feriados-locais': 'feriado', '/clinica': 'config', '/lista-espera': 'espera', '/posexame': 'posexame', '/gestor-vendas-api': 'oco', '/tipos-atendimento': 'config' };
/* nestas áreas só alterações entram no registro (consulta é muito frequente) */
const SO_ALTERACOES = new Set(['agendamento', 'agenda', 'posvenda', 'cidade', 'feriado', 'config', 'espera', 'posexame', 'oco']);

function registrarAcesso(req, res) {
  const area = AREAS_REGISTRADAS[req.baseUrl];
  if (!area) return;
  if (SO_ALTERACOES.has(area) && req.method === 'GET' && !(area === 'posvenda' && /\/clientes\/\d+/.test(req.originalUrl))) return;
  res.on('finish', () => {
    if (res.statusCode >= 400) return;
    const pool = require('../db/pool');
    const u = req.usuario;
    pool.query(
      `INSERT INTO acessos_log (clinica_id, usuario_id, usuario_nome, acao, area, caminho, ip) VALUES ($1,$2,$3,$4,$5,$6,$7)`,
      [u.clinicaId, u.usuarioId, u.nome || null, req.method, area, String(req.originalUrl).slice(0, 200), req.ip]
    ).catch(() => {});
  });
}

const GESTOR_PODE = new Set(['/posvenda', '/posexame', '/gestor-vendas-api', '/auth', '/clinica', '/unidades']);

/* Cidade de trabalho do Master: o administrador geral escolhe uma cidade no Perfil e o aparelho passa a
   mandar o cabeçalho x-cidade-trabalho. Nas telas de agenda, pacientes e filas o servidor então trata o
   Master como agendador daquela cidade. Telas de configuração, financeiro e comissões não entram nessa regra. */
const CIDADE_ESCOPO = new Set(['/pacientes', '/agendamentos', '/agendas', '/envios', '/feriados-locais', '/lista-espera', '/agendador-offline', '/testes-visao', '/relatorios', '/posvenda']);
const UUID_CIDADE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
async function aplicarCidadeTrabalho(req) {
  const c = String(req.headers['x-cidade-trabalho'] || '');
  if (!c || req.usuario.papel !== 'admin' || !CIDADE_ESCOPO.has(req.baseUrl) || !UUID_CIDADE.test(c)) return;
  const ok = await require('../db/pool').query(`SELECT 1 FROM unidades WHERE id=$1 AND clinica_id=$2 AND ativa=TRUE`, [c, req.usuario.clinicaId]);
  if (!ok.rowCount) return;
  req.usuario.unidadeIds = [c]; req.usuario.unidadeId = c; req.usuario.cidadeTrabalho = true;
}

/* Exige login: usado nas rotas administrativas (modulo-agendamento.html) */
/* última vez que a pessoa usou o sistema (no máximo uma gravação a cada 2 minutos por pessoa) */
const ultimoBatimento = new Map();
function batimento(id) {
  const agora = Date.now();
  if (agora - (ultimoBatimento.get(id) || 0) < 120000) return;
  ultimoBatimento.set(id, agora);
  require('../db/pool').query(`UPDATE usuarios SET ultimo_acesso=NOW() WHERE id=$1`, [id]).catch(() => {});
}
async function exigirLogin(req, res, next) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;
  if (!token) return res.status(401).json({ erro: 'Faça login para continuar.' });
  let dados;
  try {
    dados = jwt.verify(token, SEGREDO);
  } catch (e) {
    return res.status(401).json({ erro: 'Sessão expirada ou inválida. Faça login de novo.' });
  }
  try {
    const atual = await usuarioAtual(dados.usuarioId);
    if (!atual) return res.status(401).json({ erro: 'Este acesso foi desativado. Fale com o administrador.' });
    // "sair de todos os aparelhos" troca a versão da sessão e derruba os tokens antigos
    if ((dados.sv || 0) !== (atual.sessao_versao || 0)) return res.status(401).json({ erro: 'Sua sessão foi encerrada. Faça login de novo.' });
    // papel, cidade e permissões valem os do banco, não os que ficaram dentro do token
    req.usuario = { ...dados, clinicaId: atual.clinica_id, unidadeIds: atual.unidadeIds, unidadeId: atual.unidadeIds[0] || null, papel: atual.papel, nome: atual.nome,
      permissoes: Array.isArray(atual.permissoes) ? atual.permissoes : [] };
    // agendador sem cidade não abre nada (só o próprio login e perfil): evita ver agendamentos de todas as cidades
    if (req.usuario.papel === 'atendente' && !(req.usuario.unidadeIds || []).length && req.baseUrl !== '/auth') {
      return res.status(403).json({ erro: 'Seu acesso de agendador ainda não tem uma cidade. Peça ao administrador para escolher a sua cidade em Master, Equipe, botão Cidades.' });
    }
    await aplicarCidadeTrabalho(req);
    // gestor de vendas só usa o pós-venda: o resto do sistema fica fechado para ele
    if (req.usuario.papel === 'gestor' && !GESTOR_PODE.has(req.baseUrl)) return res.status(403).json({ erro: 'Seu acesso não permite abrir essa parte do sistema.' });
    if (!(await licencaOk(atual.clinica_id, req.baseUrl, req.path))) return res.status(402).json({ erro: 'A licença desta clínica venceu. O Master precisa colocar a chave nova em Master, aba Segurança.' });
    registrarAcesso(req, res);
    batimento(dados.usuarioId);
    next();
  } catch (e) {
    console.error(e);
    return res.status(500).json({ erro: 'Erro ao conferir o acesso.' });
  }
}

/* Licença da clínica (só trava se LICENCA_OBRIGATORIA=true). Backup, licença e login continuam liberados. */
const cacheLicenca = new Map();
const LIVRES = new Set(['/clinica', '/auth']);
async function licencaOk(clinicaId, baseUrl, caminho) {
  const lic = require('../utils/licenca');
  if (!lic.obrigatoria()) return true;
  if (LIVRES.has(baseUrl) && (caminho === '/' || /^\/(licenca|backup|backup-status|eu|sair-todos|chave-integracao)/.test(caminho))) return true;
  if (baseUrl === '/auth') return true;
  let c = cacheLicenca.get(clinicaId);
  if (!c || Date.now() - c.em > 60000) {
    const r = await require('../db/pool').query(`SELECT slug, licenca FROM clinicas WHERE id=$1`, [clinicaId]);
    c = { em: Date.now(), ok: lic.conferir(r.rows[0]?.licenca, r.rows[0]?.slug).valida };
    cacheLicenca.set(clinicaId, c);
  }
  return c.ok;
}
function limparCacheLicenca(id) { if (id) cacheLicenca.delete(id); else cacheLicenca.clear(); }

/* Algumas ações (excluir, configurar) exigem papel admin */
function exigirAdmin(req, res, next) {
  if (req.usuario?.papel !== 'admin') {
    return res.status(403).json({ erro: 'Só o administrador da clínica pode fazer isso.' });
  }
  next();
}

/* Prontuário é clínico: só quem tem papel 'profissional' ou 'admin' pode ver/escrever.
   Atendente (papel 'atendente') nunca passa daqui, mesmo que veja o paciente
   normalmente nas outras telas. */
function exigirProfissional(req, res, next) {
  if (req.usuario?.papel !== 'profissional' && req.usuario?.papel !== 'admin') {
    return res.status(403).json({ erro: 'Seu acesso não permite abrir essa parte do sistema.' });
  }
  next();
}

/* Admin e profissional sempre passam. O agendador (atendente) só passa se o
   administrador liberou essa chave na tela de Acessos (ex: 'receita', 'pacientes'). */
function exigirPermissao(chave) {
  return (req, res, next) => {
    const p = req.usuario?.papel;
    if (p === 'admin' || p === 'profissional') return next();
    if (p === 'atendente' && Array.isArray(req.usuario.permissoes) && req.usuario.permissoes.includes(chave)) return next();
    return res.status(403).json({ erro: 'Seu acesso não permite abrir essa parte do sistema.' });
  };
}

/* cidade em que o usuário grava um registro novo: quem não tem restrição escolhe livre; quem tem só usa as suas */
function cidadeEscolhida(usuario, pedida) {
  const ids = usuario.unidadeIds || [];
  if (!ids.length) return pedida || null;
  return pedida && ids.includes(String(pedida)) ? String(pedida) : ids[0];
}

function gerarToken(usuario) {
  return jwt.sign(
    { usuarioId: usuario.id, clinicaId: usuario.clinica_id, unidadeId: usuario.unidade_id || null, papel: usuario.papel, nome: usuario.nome,
      permissoes: Array.isArray(usuario.permissoes) ? usuario.permissoes : [], sv: usuario.sessao_versao || 0 },
    SEGREDO,
    { expiresIn: '8h' }
  );
}

/* Pra integrações externas (ex: assistente de WhatsApp): autentica pela chave
   de integração da clínica (header x-chave-integracao), não por login de
   funcionário. Resolve a clínica pelo :slug da URL e prende em req.clinicaIntegracao. */
async function exigirChaveIntegracao(req, res, next) {
  const pool = require('../db/pool');
  const chave = String(req.headers['x-chave-integracao'] || '');
  if (!chave) return res.status(401).json({ erro: 'Informe a chave de integração no cabeçalho x-chave-integracao.' });
  const r = await pool.query(`SELECT * FROM clinicas WHERE slug=$1 AND ativa=TRUE`, [req.params.slug]);
  if (!r.rows.length) return res.status(404).json({ erro: 'Clínica não encontrada.' });
  if (!iguais(r.rows[0].chave_integracao, chave)) return res.status(401).json({ erro: 'Chave de integração inválida.' });
  req.clinicaIntegracao = r.rows[0];
  next();
}

module.exports = { limparCacheLicenca, exigirLogin, exigirAdmin, exigirProfissional, exigirPermissao, exigirChaveIntegracao, gerarToken, limparCacheUsuario, cidadeEscolhida, SEGREDO };
