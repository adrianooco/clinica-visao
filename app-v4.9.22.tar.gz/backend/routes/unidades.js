const express = require('express');
const pool = require('../db/pool');
const { exigirLogin, exigirAdmin } = require('../middleware/auth');

const router = express.Router();
router.use(exigirLogin);

/* Admin vê todas as cidades da clínica. Um atendente restrito a uma cidade só vê a própria. */
router.get('/', async (req, res) => {
  const r = req.usuario.unidadeId
    ? await pool.query(`SELECT * FROM unidades WHERE id=ANY($1) AND clinica_id=$2 ORDER BY nome`, [req.usuario.unidadeIds, req.usuario.clinicaId])
    : await pool.query(`SELECT * FROM unidades WHERE clinica_id=$1 AND ativa=TRUE ORDER BY data_inicio DESC NULLS LAST, nome`, [req.usuario.clinicaId]);
  res.json(r.rows);
});

router.post('/', exigirAdmin, async (req, res) => {
  const { nome, cidade, local, data_inicio, data_fim } = req.body;
  if (!nome && !cidade) return res.status(400).json({ erro: 'Informe a cidade do exame de vista.' });
  /* sem identificador, o servidor cria um a partir da cidade e evita repetir */
  let slug = req.body.slug;
  if (!slug) {
    const base = String(cidade || nome).normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') || 'cidade';
    slug = base;
    for (let i = 2; i < 50; i++) {
      const ja = await pool.query('SELECT 1 FROM unidades WHERE clinica_id=$1 AND slug=$2', [req.usuario.clinicaId, slug]);
      if (!ja.rows.length) break;
      slug = base + '-' + i;
    }
  }
  try {
    const r = await pool.query(
      `INSERT INTO unidades (clinica_id, slug, nome, cidade, local, data_inicio, data_fim)
       VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING *`,
      [req.usuario.clinicaId, slug.toLowerCase().trim().replace(/[^a-z0-9-]/g,'-'), nome, cidade || null, local || null, data_inicio || null, data_fim || null]
    );
    res.status(201).json(r.rows[0]);
  } catch (e) {
    if (e.code === '23505') return res.status(409).json({ erro: 'Já existe uma cidade com esse identificador.' });
    console.error(e); res.status(500).json({ erro: 'Erro ao criar a cidade.' });
  }
});

router.put('/:id', exigirAdmin, async (req, res) => {
  const { nome, cidade, local } = req.body;
  const r = await pool.query(
    `UPDATE unidades SET nome=COALESCE(NULLIF($1,''),nome), cidade=COALESCE($2,cidade), local=COALESCE($3,local) WHERE id=$4 AND clinica_id=$5 RETURNING *`,
    [nome || null, cidade === undefined ? null : String(cidade).trim(), local === undefined ? null : String(local).trim(), req.params.id, req.usuario.clinicaId]);
  if (!r.rows.length) return res.status(404).json({ erro: 'Cidade não encontrada.' });
  res.json(r.rows[0]);
});

router.delete('/:id', exigirAdmin, async (req, res) => {
  const r = await pool.query(`UPDATE unidades SET ativa=FALSE WHERE id=$1 AND clinica_id=$2 RETURNING id`, [req.params.id, req.usuario.clinicaId]);
  if (!r.rows.length) return res.status(404).json({ erro: 'Cidade não encontrado.' });
  res.json({ ok: true });
});

/* ---------- cadastro em lote: até 20 cidades de uma vez ---------- */
const norm = (t) => String(t || '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().replace(/\s+/g, ' ').trim();
router.post('/lote', exigirAdmin, async (req, res) => {
  const linhas = Array.isArray((req.body || {}).linhas) ? req.body.linhas : [];
  if (!linhas.length) return res.status(400).json({ erro: 'Escreva pelo menos uma cidade.' });
  if (linhas.length > 20) return res.status(400).json({ erro: 'Mande no máximo 20 cidades por vez.' });
  const ja = (await pool.query(`SELECT id, cidade, nome FROM unidades WHERE clinica_id=$1 AND ativa=TRUE`, [req.usuario.clinicaId])).rows;
  const criadas = [], puladas = [];
  for (const l of linhas) {
    const cidade = String((l && l.cidade) || '').trim().slice(0, 120);
    const local = String((l && l.local) || '').trim().slice(0, 200) || null;
    if (!cidade) continue;
    if (ja.some((u) => norm(u.cidade) === norm(cidade)) || criadas.some((c) => norm(c.cidade) === norm(cidade))) { puladas.push({ cidade, motivo: 'já cadastrada' }); continue; }
    const base = norm(cidade).replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') || 'cidade';
    let slug = base;
    for (let i = 2; i < 50; i++) { if (!(await pool.query('SELECT 1 FROM unidades WHERE clinica_id=$1 AND slug=$2', [req.usuario.clinicaId, slug])).rows.length) break; slug = base + '-' + i; }
    const r = await pool.query(`INSERT INTO unidades (clinica_id, slug, nome, cidade, local) VALUES ($1,$2,'Exame de vista',$3,$4) RETURNING *`, [req.usuario.clinicaId, slug, cidade, local]);
    criadas.push(r.rows[0]);
  }
  res.status(201).json({ criadas, puladas });
});

module.exports = router;
