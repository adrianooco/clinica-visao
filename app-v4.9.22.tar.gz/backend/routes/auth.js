const express = require('express');
const bcrypt = require('bcryptjs');
const pool = require('../db/pool');
const { gerarToken, exigirLogin } = require('../middleware/auth');
const { validarSenha } = require('../utils/senha');
const jwt = require('jsonwebtoken');
const { SEGREDO, exigirAdmin } = require('../middleware/auth');
const { registrarDispositivo } = require('../utils/dispositivos');

const router = express.Router();

/* Trava de tentativas: 8 erros de senha em 15 minutos bloqueiam aquele e-mail naquele aparelho.
   Fica no banco, então continua valendo mesmo se o servidor reiniciar. */
const JANELA_MS = 15 * 60 * 1000, MAX_ERROS = 8;
const chaveTent = (req, email) => `${req.ip}|${String(email || '').toLowerCase().trim()}`;
async function bloqueado(chave) {
  const r = await pool.query(`SELECT erros FROM login_tentativas WHERE chave=$1 AND inicio > NOW() - INTERVAL '15 minutes'`, [chave]);
  return r.rows.length > 0 && r.rows[0].erros >= MAX_ERROS;
}
async function errou(chave) {
  await pool.query(
    `INSERT INTO login_tentativas (chave, inicio, erros) VALUES ($1, NOW(), 1)
     ON CONFLICT (chave) DO UPDATE SET erros = CASE WHEN login_tentativas.inicio > NOW() - INTERVAL '15 minutes' THEN login_tentativas.erros + 1 ELSE 1 END,
       inicio = CASE WHEN login_tentativas.inicio > NOW() - INTERVAL '15 minutes' THEN login_tentativas.inicio ELSE NOW() END`, [chave]);
}
const limparErros = (chave) => pool.query(`DELETE FROM login_tentativas WHERE chave=$1`, [chave]).catch(() => {});
setInterval(() => { pool.query(`DELETE FROM login_tentativas WHERE inicio < NOW() - INTERVAL '1 hour'`).catch(() => {}); }, 30 * 60 * 1000).unref();

/* Cria a clínica + o primeiro usuário admin. Usado uma única vez, na primeira configuração. */
router.post('/setup', async (req, res) => {
  const { slug, nomeClinica, nomeAdmin, email, senha } = req.body;
  if (!slug || !nomeClinica || !nomeAdmin || !email || !senha) {
    return res.status(400).json({ erro: 'Preencha slug, nome da clínica, nome do admin, e-mail e senha.' });
  }
  { const e = validarSenha(senha); if (e) return res.status(400).json({ erro: e }); }
  // no ar (produção), depois que a primeira clínica existe, ninguém de fora cria outra
  if (process.env.NODE_ENV === 'production' && process.env.LIBERAR_CADASTRO !== 'sim') {
    const n = await pool.query('SELECT COUNT(*)::int AS n FROM clinicas');
    if (n.rows[0].n > 0) return res.status(403).json({ erro: 'O cadastro de novas clínicas está fechado neste servidor. Entre com sua conta.' });
  }
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const clinica = await client.query(
      `INSERT INTO clinicas (slug, nome_fantasia) VALUES ($1,$2) RETURNING *`,
      [slug.toLowerCase().trim(), nomeClinica]
    );
    const senhaHash = await bcrypt.hash(senha, 10);
    const usuario = await client.query(
      `INSERT INTO usuarios (clinica_id, nome, email, senha_hash, papel)
       VALUES ($1,$2,$3,$4,'admin') RETURNING *`,
      [clinica.rows[0].id, nomeAdmin, email.toLowerCase().trim(), senhaHash]
    );
    await client.query(
      `INSERT INTO tipos_atendimento (clinica_id, nome, duracao_min, buffer_min, cor) VALUES
       ($1,'Exame de vista',30,10,'#1B5C5A'),
       ($1,'Retirada de receita',15,5,'#2D8C84'),
       ($1,'Ajuste de armação',15,5,'#E3A23D')`,
      [clinica.rows[0].id]
    );
    await client.query('COMMIT');
    const token = gerarToken(usuario.rows[0]);
    res.status(201).json({ token, clinica: clinica.rows[0] });
  } catch (e) {
    await client.query('ROLLBACK');
    if (e.code === '23505') return res.status(409).json({ erro: 'Esse slug ou e-mail já está em uso.' });
    console.error(e);
    res.status(500).json({ erro: 'Erro ao criar a clínica.' });
  } finally {
    client.release();
  }
});

router.post('/login', async (req, res) => {
  const { email, senha } = req.body;
  if (!email || !senha) return res.status(400).json({ erro: 'Informe e-mail e senha.' });
  if (typeof email !== 'string' || typeof senha !== 'string' || email.length > 254 || senha.length > 200) return res.status(400).json({ erro: 'E-mail ou senha em formato inválido.' });
  const chave = chaveTent(req, email);
  if (await bloqueado(chave)) return res.status(429).json({ erro: 'Muitas tentativas erradas. Espere 15 minutos e tente de novo.' });
  try {
    const r = await pool.query(
      `SELECT u.*, c.nome_fantasia, c.slug FROM usuarios u
       JOIN clinicas c ON c.id = u.clinica_id
       WHERE u.email=$1 AND u.ativo=TRUE`,
      [email.toLowerCase().trim()]
    );
    if (!r.rows.length) { await errou(chave); return res.status(401).json({ erro: 'E-mail ou senha incorretos.' }); }
    const usuario = r.rows[0];
    const ok = await bcrypt.compare(senha, usuario.senha_hash);
    if (!ok) { await errou(chave); return res.status(401).json({ erro: 'E-mail ou senha incorretos.' }); }
    await limparErros(chave);
    // agendador sem cidade não entra: sem cidade ele veria agendamentos de todas as cidades
    if (usuario.papel === 'atendente' && !(await cidadesDe(usuario.id, usuario.unidade_id)).length) {
      return res.status(403).json({ erro: 'Seu acesso de agendador ainda não tem uma cidade. Peça ao administrador para escolher a sua cidade em Master, Equipe, botão Cidades.' });
    }
    // código de 6 números do celular, se a pessoa ativou
    if (usuario.totp_ativo) {
      const pendente = jwt.sign({ fin: 'totp', uid: usuario.id }, SEGREDO, { expiresIn: '5m' });
      return res.json({ etapa: 'totp', pendente });
    }
    registrarDispositivo(req, usuario);
    const token = gerarToken(usuario);
    res.json({ token, usuario: { id: usuario.id, email: usuario.email, nome: usuario.nome, papel: usuario.papel, clinica: usuario.nome_fantasia, slug: usuario.slug, unidadeId: usuario.unidade_id || null, unidadeIds: await cidadesDe(usuario.id, usuario.unidade_id), permissoes: usuario.permissoes || [] } });
  } catch (e) {
    console.error(e);
    res.status(500).json({ erro: 'Erro ao entrar.' });
  }
});

/* Meu perfil: cada pessoa vê seus dados e troca a própria senha. */
/* encerra a sessão em todos os aparelhos (celular perdido, senha vazada) */
router.post('/sair-todos', exigirLogin, async (req, res) => {
  await pool.query(`UPDATE usuarios SET sessao_versao = sessao_versao + 1 WHERE id=$1`, [req.usuario.usuarioId]);
  require('../middleware/auth').limparCacheUsuario(req.usuario.usuarioId);
  res.json({ ok: true });
});

/* Localização de quem entrou: o celular manda só se a pessoa permitiu. Guarda a última posição e marca a entrada mais recente. */
router.post('/localizacao', exigirLogin, async (req, res) => {
  const lat = Number(req.body.lat), lng = Number(req.body.lng);
  if (!isFinite(lat) || !isFinite(lng) || Math.abs(lat) > 90 || Math.abs(lng) > 180) return res.status(400).json({ erro: 'Localização inválida.' });
  const prec = Math.max(0, Math.min(100000, Math.round(Number(req.body.precisao) || 0)));
  const id = req.usuario.usuarioId;
  await pool.query(`UPDATE usuarios SET loc_lat=$2, loc_lng=$3, loc_precisao=$4, loc_em=NOW() WHERE id=$1`, [id, lat, lng, prec]);
  await pool.query(`UPDATE entradas_log SET lat=$2, lng=$3 WHERE id = (SELECT id FROM entradas_log WHERE usuario_id=$1 AND lat IS NULL AND criado_em >= NOW() - INTERVAL '15 minutes' ORDER BY criado_em DESC LIMIT 1)`, [id, lat, lng]);
  res.json({ ok: true });
});

router.get('/eu', exigirLogin, async (req, res) => {
  const r = await pool.query(
    `SELECT u.nome, u.email, u.papel, u.registro_conselho, un.nome AS cidade FROM usuarios u LEFT JOIN unidades un ON un.id = u.unidade_id WHERE u.id=$1`,
    [req.usuario.usuarioId]);
  if (!r.rows.length) return res.status(404).json({ erro: 'Usuário não encontrado.' });
  res.json(r.rows[0]);
});

router.patch('/eu', exigirLogin, async (req, res) => {
  const { nome, senha_atual, nova_senha } = req.body;
  const r = await pool.query('SELECT * FROM usuarios WHERE id=$1', [req.usuario.usuarioId]);
  const u = r.rows[0];
  if (!u) return res.status(404).json({ erro: 'Usuário não encontrado.' });
  if (nome !== undefined && !String(nome).trim()) return res.status(400).json({ erro: 'O nome não pode ficar vazio.' });
  let hash = u.senha_hash;
  if (nova_senha) {
    { const e = validarSenha(nova_senha); if (e) return res.status(400).json({ erro: e }); }
    if (!senha_atual || !(await bcrypt.compare(senha_atual, u.senha_hash))) return res.status(400).json({ erro: 'A senha atual está errada.' });
    hash = await bcrypt.hash(nova_senha, 10);
  }
  await pool.query('UPDATE usuarios SET nome=$1, senha_hash=$2 WHERE id=$3', [nome !== undefined ? String(nome).trim() : u.nome, hash, u.id]);
  res.json({ ok: true, nome: nome !== undefined ? String(nome).trim() : u.nome });
});

/* ===================== ENTRADA (resposta com token) ===================== */
async function cidadesDe(usuarioId, principal) {
  const r = await pool.query(`SELECT unidade_id FROM usuarios_unidades WHERE usuario_id=$1`, [usuarioId]);
  const ids = new Set(r.rows.map((x) => x.unidade_id));
  if (principal) ids.add(principal);
  return [...ids];
}
async function respostaDeEntrada(usuarioId, req) {
  const r = await pool.query(`SELECT u.*, c.nome_fantasia, c.slug FROM usuarios u JOIN clinicas c ON c.id=u.clinica_id WHERE u.id=$1 AND u.ativo=TRUE`, [usuarioId]);
  const u = r.rows[0];
  if (!u) return null;
  if (req) registrarDispositivo(req, u);
  return { token: gerarToken(u), usuario: { id: u.id, email: u.email, nome: u.nome, papel: u.papel, clinica: u.nome_fantasia, slug: u.slug, unidadeId: u.unidade_id || null, unidadeIds: await cidadesDe(u.id, u.unidade_id), permissoes: u.permissoes || [] } };
}


router.respostaDeEntrada = respostaDeEntrada;
module.exports = router;
