const fs = require('fs');
const path = require('path');
const pool = require('./pool');

/* Banco novo e vazio (caso de quem coloca o sistema online): cria as tabelas sozinho. */
async function criarTabelasSeFaltar() {
  const r = await pool.query(`SELECT to_regclass('public.clinicas') AS t`);
  if (r.rows[0].t) return;
  const candidatos = [path.join(__dirname, 'schema-agendamento.sql'), path.join(__dirname, '..', '..', 'schema-agendamento.sql')];
  const arq = candidatos.find((c) => fs.existsSync(c));
  if (!arq) throw new Error('Arquivo schema-agendamento.sql não encontrado para criar o banco.');
  console.log('Banco vazio: criando as tabelas...');
  await pool.query(fs.readFileSync(arq, 'utf8'));
  console.log('Tabelas criadas.');
}

/* Ajustes pequenos de banco que rodam sempre que o servidor liga.
   Servem pra quem já tem o banco criado de uma versão anterior: cada comando
   só age se a coluna ainda não existir, então é seguro rodar várias vezes. */
async function migrar() {
  await criarTabelasSeFaltar();
  await pool.query(`ALTER TABLE pacientes ADD COLUMN IF NOT EXISTS data_nascimento DATE`);
  await pool.query(`ALTER TABLE pacientes ADD COLUMN IF NOT EXISTS dados_extras JSONB DEFAULT '{}'::jsonb`);
  // OCO (vendas do gestor): base sincronizada por clínica e as últimas cópias, para voltar atrás se algo der errado
  await pool.query(`CREATE TABLE IF NOT EXISTS gestor_vendas_dados (
    clinica_id UUID PRIMARY KEY REFERENCES clinicas(id) ON DELETE CASCADE,
    versao INTEGER NOT NULL,
    dados TEXT NOT NULL,
    atualizado_em TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    atualizado_por TEXT
  )`);
  await pool.query(`CREATE TABLE IF NOT EXISTS gestor_vendas_copias (
    clinica_id UUID NOT NULL REFERENCES clinicas(id) ON DELETE CASCADE,
    versao INTEGER NOT NULL,
    dados TEXT NOT NULL,
    criado_em TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (clinica_id, versao)
  )`);
  // agenda do evento: dia + faixa de horário em que o agendador pode marcar pacientes
  await pool.query(`CREATE TABLE IF NOT EXISTS agendas (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    clinica_id UUID NOT NULL REFERENCES clinicas(id) ON DELETE CASCADE,
    unidade_id UUID NOT NULL REFERENCES unidades(id) ON DELETE CASCADE,
    data DATE NOT NULL,
    hora_inicio TIME NOT NULL,
    hora_fim TIME NOT NULL,
    tipo_atendimento_id UUID NOT NULL REFERENCES tipos_atendimento(id),
    local VARCHAR(255),
    ativa BOOLEAN DEFAULT TRUE,
    criado_em TIMESTAMP DEFAULT NOW()
  )`);
  await pool.query(`CREATE INDEX IF NOT EXISTS idx_agendas_unidade_data ON agendas(unidade_id, data) WHERE ativa`);
  await pool.query(`ALTER TABLE agendas ADD COLUMN IF NOT EXISTS buffer_min INTEGER`);
  await pool.query(`ALTER TABLE agendas ADD COLUMN IF NOT EXISTS almoco_inicio TIME`);
  await pool.query(`ALTER TABLE agendas ADD COLUMN IF NOT EXISTS almoco_fim TIME`);

  // o que cada agendador pode abrir (lista de chaves) e como imprimir os documentos
  await pool.query(`ALTER TABLE usuarios ADD COLUMN IF NOT EXISTS permissoes JSONB DEFAULT '[]'::jsonb`);
  await pool.query(`ALTER TABLE clinicas ADD COLUMN IF NOT EXISTS config_impressao JSONB DEFAULT '{}'::jsonb`);

  // cadastros de apoio
  await pool.query(`CREATE TABLE IF NOT EXISTS oticas_parceiras (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    clinica_id UUID NOT NULL REFERENCES clinicas(id) ON DELETE CASCADE,
    nome VARCHAR(150) NOT NULL, ativa BOOLEAN DEFAULT TRUE, criado_em TIMESTAMP DEFAULT NOW())`);
  await pool.query(`CREATE TABLE IF NOT EXISTS convenios (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    clinica_id UUID NOT NULL REFERENCES clinicas(id) ON DELETE CASCADE,
    nome VARCHAR(150) NOT NULL, ativo BOOLEAN DEFAULT TRUE, criado_em TIMESTAMP DEFAULT NOW())`);

  // de onde veio o agendamento e qual ótica parceira indicou
  await pool.query(`ALTER TABLE agendamentos ADD COLUMN IF NOT EXISTS origem VARCHAR(20) DEFAULT 'equipe'`);
  await pool.query(`ALTER TABLE agendamentos ADD COLUMN IF NOT EXISTS otica_parceira_id UUID REFERENCES oticas_parceiras(id) ON DELETE SET NULL`);

  // preço padrão de cada tipo de atendimento (já vem preenchido na cobrança)
  await pool.query(`ALTER TABLE tipos_atendimento ADD COLUMN IF NOT EXISTS preco_padrao NUMERIC(10,2)`);

  // financeiro
  await pool.query(`CREATE TABLE IF NOT EXISTS pagamentos (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    clinica_id UUID NOT NULL REFERENCES clinicas(id) ON DELETE CASCADE,
    agendamento_id UUID NOT NULL UNIQUE REFERENCES agendamentos(id) ON DELETE CASCADE,
    valor NUMERIC(10,2) NOT NULL CHECK (valor >= 0),
    forma VARCHAR(20),
    convenio_id UUID REFERENCES convenios(id) ON DELETE SET NULL,
    status VARCHAR(10) NOT NULL DEFAULT 'pendente' CHECK (status IN ('pendente','pago')),
    pago_em DATE,
    criado_em TIMESTAMP DEFAULT NOW())`);
  await pool.query(`CREATE TABLE IF NOT EXISTS contas_pagar (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    clinica_id UUID NOT NULL REFERENCES clinicas(id) ON DELETE CASCADE,
    descricao VARCHAR(200) NOT NULL,
    valor NUMERIC(10,2) NOT NULL CHECK (valor >= 0),
    vencimento DATE NOT NULL,
    pago BOOLEAN DEFAULT FALSE,
    pago_em DATE,
    criado_em TIMESTAMP DEFAULT NOW())`);

  // v4.4 Pix para receita e atestado (QR estático, dinheiro cai direto na chave da clínica)
  await pool.query(`ALTER TABLE clinicas ADD COLUMN IF NOT EXISTS pix_chave VARCHAR(100)`);
  await pool.query(`ALTER TABLE clinicas ADD COLUMN IF NOT EXISTS pix_tipo VARCHAR(12)`);
  await pool.query(`ALTER TABLE clinicas ADD COLUMN IF NOT EXISTS pix_nome VARCHAR(25)`);
  await pool.query(`ALTER TABLE clinicas ADD COLUMN IF NOT EXISTS pix_cidade VARCHAR(15)`);
  await pool.query(`ALTER TABLE clinicas ADD COLUMN IF NOT EXISTS pix_valor_receita NUMERIC(10,2)`);
  await pool.query(`ALTER TABLE clinicas ADD COLUMN IF NOT EXISTS pix_valor_atestado NUMERIC(10,2)`);
  await pool.query(`UPDATE clinicas SET pix_chave='+5564992161203', pix_tipo='telefone' WHERE pix_chave IS NULL`);
  await pool.query(`CREATE TABLE IF NOT EXISTS cobrancas_documento (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    clinica_id UUID NOT NULL REFERENCES clinicas(id) ON DELETE CASCADE,
    unidade_id UUID,
    paciente_id UUID NOT NULL REFERENCES pacientes(id) ON DELETE CASCADE,
    tipo VARCHAR(12) NOT NULL CHECK (tipo IN ('receita','atestado','declaracao')),
    valor NUMERIC(10,2) NOT NULL CHECK (valor > 0),
    status VARCHAR(10) NOT NULL DEFAULT 'pendente' CHECK (status IN ('pendente','pago')),
    criado_em TIMESTAMP DEFAULT NOW(),
    criado_por_nome VARCHAR(150),
    pago_em TIMESTAMP,
    pago_por_nome VARCHAR(150))`);
  await pool.query(`CREATE INDEX IF NOT EXISTS ix_cobr_doc_pac ON cobrancas_documento(clinica_id, paciente_id, criado_em DESC)`);

  // v4.5 comissão do agendador por óculos vendido e retorno depois de alguns dias
  await pool.query(`ALTER TABLE clinicas ADD COLUMN IF NOT EXISTS comissao_opcao_a NUMERIC(10,2) DEFAULT 25`);
  await pool.query(`ALTER TABLE clinicas ADD COLUMN IF NOT EXISTS comissao_opcao_b NUMERIC(10,2) DEFAULT 50`);
  await pool.query(`ALTER TABLE clinicas ADD COLUMN IF NOT EXISTS pos_oculos_dias INTEGER DEFAULT 20`);
  await pool.query(`CREATE TABLE IF NOT EXISTS vendas_oculos (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    clinica_id UUID NOT NULL REFERENCES clinicas(id) ON DELETE CASCADE,
    unidade_id UUID,
    paciente_id UUID NOT NULL REFERENCES pacientes(id) ON DELETE CASCADE,
    agendamento_id UUID UNIQUE REFERENCES agendamentos(id) ON DELETE SET NULL,
    agendador_id UUID,
    agendador_nome VARCHAR(150),
    valor_venda NUMERIC(10,2),
    comissao NUMERIC(10,2) NOT NULL DEFAULT 0 CHECK (comissao >= 0),
    comissao_paga BOOLEAN NOT NULL DEFAULT FALSE,
    comissao_paga_em DATE,
    vendido_em DATE NOT NULL DEFAULT CURRENT_DATE,
    entregue_em DATE,
    observacoes TEXT,
    pos_enviado BOOLEAN NOT NULL DEFAULT FALSE,
    pos_enviado_em TIMESTAMP,
    pos_resposta TEXT,
    pos_resposta_em TIMESTAMP,
    pos_situacao VARCHAR(10) CHECK (pos_situacao IN ('ok','problema')),
    pos_obs TEXT,
    criado_por_nome VARCHAR(150),
    criado_em TIMESTAMP DEFAULT NOW())`);
  await pool.query(`CREATE INDEX IF NOT EXISTS ix_vendas_clinica ON vendas_oculos(clinica_id, vendido_em DESC)`);
  await pool.query(`CREATE INDEX IF NOT EXISTS ix_vendas_agendador ON vendas_oculos(clinica_id, agendador_id)`);

  // v4.6 resultado da venda (completa, só lente, só armação, não comprou)
  await pool.query(`ALTER TABLE vendas_oculos ADD COLUMN IF NOT EXISTS resultado VARCHAR(12) NOT NULL DEFAULT 'completa'`);
  await pool.query(`ALTER TABLE vendas_oculos ADD COLUMN IF NOT EXISTS comissao_cheia NUMERIC(10,2)`);
  await pool.query(`UPDATE vendas_oculos SET comissao_cheia = comissao WHERE comissao_cheia IS NULL`);
  await pool.query(`ALTER TABLE vendas_oculos ADD COLUMN IF NOT EXISTS garantia_ate DATE`);
  await pool.query(`ALTER TABLE vendas_oculos DROP CONSTRAINT IF EXISTS vendas_oculos_resultado_check`);
  await pool.query(`ALTER TABLE vendas_oculos ADD CONSTRAINT vendas_oculos_resultado_check CHECK (resultado IN ('completa','lente','armacao','nao_comprou'))`);
  // v4.6 gestor de vendas: novo tipo de usuário
  await pool.query(`ALTER TABLE usuarios DROP CONSTRAINT IF EXISTS usuarios_papel_check`);
  await pool.query(`ALTER TABLE usuarios ADD CONSTRAINT usuarios_papel_check CHECK (papel IN ('admin','atendente','profissional','gestor'))`);
  await pool.query(`ALTER TABLE pacientes ADD COLUMN IF NOT EXISTS aceita_promocao BOOLEAN NOT NULL DEFAULT TRUE`);
  await pool.query(`CREATE TABLE IF NOT EXISTS posvenda_ocorrencias (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    clinica_id UUID NOT NULL REFERENCES clinicas(id) ON DELETE CASCADE,
    paciente_id UUID NOT NULL REFERENCES pacientes(id) ON DELETE CASCADE,
    venda_id UUID REFERENCES vendas_oculos(id) ON DELETE SET NULL,
    tipo VARCHAR(12) NOT NULL CHECK (tipo IN ('ajuste','garantia','troca','reclamacao','outro')),
    descricao TEXT NOT NULL,
    status VARCHAR(12) NOT NULL DEFAULT 'aberta' CHECK (status IN ('aberta','andamento','resolvida')),
    prazo DATE,
    visita_em TIMESTAMP,
    resolucao TEXT,
    resolvida_em TIMESTAMP,
    criado_por_nome VARCHAR(150),
    criado_em TIMESTAMP DEFAULT NOW(),
    atualizado_em TIMESTAMP DEFAULT NOW())`);
  await pool.query(`CREATE INDEX IF NOT EXISTS ix_posv_ocor ON posvenda_ocorrencias(clinica_id, status, prazo)`);
  await pool.query(`CREATE TABLE IF NOT EXISTS posvenda_envios (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    clinica_id UUID NOT NULL REFERENCES clinicas(id) ON DELETE CASCADE,
    paciente_id UUID NOT NULL REFERENCES pacientes(id) ON DELETE CASCADE,
    campanha VARCHAR(60) NOT NULL,
    enviado_por_nome VARCHAR(150),
    enviado_em TIMESTAMP DEFAULT NOW())`);
  await pool.query(`CREATE UNIQUE INDEX IF NOT EXISTS ux_posv_envio ON posvenda_envios(clinica_id, paciente_id, campanha)`);

  // pós-exame: contato com o paciente para saber se ficou satisfeito com o exame de vista
  await pool.query(`CREATE TABLE IF NOT EXISTS posexame_contatos (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    clinica_id UUID NOT NULL REFERENCES clinicas(id) ON DELETE CASCADE,
    agendamento_id UUID NOT NULL UNIQUE REFERENCES agendamentos(id) ON DELETE CASCADE,
    paciente_id UUID NOT NULL REFERENCES pacientes(id) ON DELETE CASCADE,
    enviado_em TIMESTAMP,
    enviado_por_nome VARCHAR(150),
    resultado VARCHAR(14) CHECK (resultado IN ('satisfeito','regular','insatisfeito','sem_resposta')),
    observacao TEXT,
    acompanhar BOOLEAN NOT NULL DEFAULT FALSE,
    resolvido_em TIMESTAMP,
    resolucao TEXT,
    criado_em TIMESTAMP DEFAULT NOW(),
    atualizado_em TIMESTAMP DEFAULT NOW())`);
  await pool.query(`CREATE INDEX IF NOT EXISTS ix_posexame ON posexame_contatos(clinica_id, acompanhar, resolvido_em)`);

  // registro de quem abriu ou alterou dado de saúde (LGPD)
  await pool.query(`CREATE TABLE IF NOT EXISTS acessos_log (
    id BIGSERIAL PRIMARY KEY,
    clinica_id UUID NOT NULL REFERENCES clinicas(id) ON DELETE CASCADE,
    usuario_id UUID, usuario_nome VARCHAR(150),
    acao VARCHAR(10), area VARCHAR(30), caminho VARCHAR(200), ip VARCHAR(60),
    criado_em TIMESTAMP DEFAULT NOW())`);
  await pool.query(`CREATE INDEX IF NOT EXISTS idx_acessos_log ON acessos_log(clinica_id, criado_em DESC)`);

  // WhatsApp automático e número da clínica
  await pool.query(`ALTER TABLE clinicas ADD COLUMN IF NOT EXISTS whatsapp_numero VARCHAR(20)`);
  await pool.query(`ALTER TABLE clinicas ADD COLUMN IF NOT EXISTS whatsapp_auto BOOLEAN DEFAULT FALSE`);
  await pool.query(`ALTER TABLE agendamentos ADD COLUMN IF NOT EXISTS whatsapp_ultimo_erro VARCHAR(200)`);
  // v4.0: segurança, lista de espera, licença
  await pool.query(`ALTER TABLE usuarios ADD COLUMN IF NOT EXISTS totp_segredo TEXT`);
  await pool.query(`ALTER TABLE usuarios ADD COLUMN IF NOT EXISTS totp_ativo BOOLEAN NOT NULL DEFAULT FALSE`);
  await pool.query(`ALTER TABLE usuarios ADD COLUMN IF NOT EXISTS totp_ultimo_passo BIGINT NOT NULL DEFAULT 0`);
  await pool.query(`CREATE TABLE IF NOT EXISTS redefinicoes_senha (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    usuario_id UUID NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE,
    token_hash TEXT NOT NULL UNIQUE,
    expira_em TIMESTAMPTZ NOT NULL,
    usado_em TIMESTAMPTZ,
    criado_em TIMESTAMPTZ DEFAULT NOW())`);
  await pool.query(`CREATE TABLE IF NOT EXISTS dispositivos_login (
    usuario_id UUID NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE,
    hash TEXT NOT NULL,
    agente TEXT,
    primeiro_em TIMESTAMPTZ DEFAULT NOW(),
    visto_em TIMESTAMPTZ DEFAULT NOW(),
    PRIMARY KEY (usuario_id, hash))`);
  await pool.query(`ALTER TABLE clinicas ADD COLUMN IF NOT EXISTS licenca TEXT`);
  await pool.query(`CREATE TABLE IF NOT EXISTS lista_espera (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    clinica_id UUID NOT NULL REFERENCES clinicas(id) ON DELETE CASCADE,
    unidade_id UUID REFERENCES unidades(id) ON DELETE CASCADE,
    nome VARCHAR(150) NOT NULL,
    telefone VARCHAR(30),
    observacao VARCHAR(300),
    resolvido_em TIMESTAMP,
    criado_em TIMESTAMP DEFAULT NOW())`);
  // v4.1: CPF embaralhado + impressão para barrar CPF repetido
  await pool.query(`ALTER TABLE pacientes ALTER COLUMN cpf TYPE TEXT`);
  await pool.query(`ALTER TABLE pacientes ADD COLUMN IF NOT EXISTS cpf_idx TEXT`);
  await pool.query(`ALTER TABLE pacientes DROP CONSTRAINT IF EXISTS unique_cpf_por_clinica`);
  await pool.query(`CREATE UNIQUE INDEX IF NOT EXISTS ux_pacientes_cpf_idx ON pacientes(clinica_id, cpf_idx) WHERE cpf_idx IS NOT NULL`);
  // v4.1: Guardião do sistema
  await pool.query(`CREATE TABLE IF NOT EXISTS assistente_obrigacoes (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    clinica_id UUID NOT NULL REFERENCES clinicas(id) ON DELETE CASCADE,
    codigo TEXT, titulo TEXT NOT NULL, detalhe TEXT,
    vence_em DATE NOT NULL, repetir_dias INTEGER,
    feito_em TIMESTAMPTZ, lembrado_em DATE,
    ativo BOOLEAN NOT NULL DEFAULT TRUE,
    criado_em TIMESTAMPTZ DEFAULT NOW())`);
  await pool.query(`CREATE UNIQUE INDEX IF NOT EXISTS ux_assistente_obr_codigo ON assistente_obrigacoes(clinica_id, codigo) WHERE codigo IS NOT NULL`);
  await pool.query(`CREATE TABLE IF NOT EXISTS assistente_verificacoes (
    id BIGSERIAL PRIMARY KEY,
    clinica_id UUID NOT NULL REFERENCES clinicas(id) ON DELETE CASCADE,
    erros INTEGER NOT NULL DEFAULT 0, avisos INTEGER NOT NULL DEFAULT 0,
    resumo JSONB, criado_em TIMESTAMPTZ DEFAULT NOW())`);
  await pool.query(`CREATE INDEX IF NOT EXISTS idx_assist_verif ON assistente_verificacoes(clinica_id, criado_em DESC)`);
  await pool.query(`CREATE TABLE IF NOT EXISTS sistema_batimento (id INTEGER PRIMARY KEY, visto_em TIMESTAMPTZ NOT NULL DEFAULT NOW())`);
  await pool.query(`CREATE TABLE IF NOT EXISTS sistema_reinicios (id BIGSERIAL PRIMARY KEY, parado_min INTEGER NOT NULL DEFAULT 0, criado_em TIMESTAMPTZ DEFAULT NOW())`);
  // v4.2/v4.3: agendador offline (cada pedido do celular tem um número, para o envio repetido não duplicar)
  await pool.query(`CREATE TABLE IF NOT EXISTS agendamentos_offline (
    clinica_id UUID NOT NULL REFERENCES clinicas(id) ON DELETE CASCADE,
    cliente_id UUID NOT NULL,
    usuario_id UUID,
    resultado JSONB NOT NULL,
    criado_em TIMESTAMPTZ DEFAULT NOW(),
    PRIMARY KEY (clinica_id, cliente_id))`);
  // diagnóstico (CID) passa a caber embaralhado
  await pool.query(`DO $$ BEGIN
    IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='receitas' AND column_name='cid_codigo' AND data_type='character varying') THEN
      ALTER TABLE receitas ALTER COLUMN cid_codigo TYPE TEXT;
      ALTER TABLE receitas ALTER COLUMN cid_descricao TYPE TEXT;
    END IF; END $$`);
  await pool.query(`ALTER TABLE agendamentos ADD COLUMN IF NOT EXISTS chegou_em TIMESTAMP`);
  await pool.query(`ALTER TABLE agendamentos ADD COLUMN IF NOT EXISTS inicio_atendimento_em TIMESTAMP`);
  await pool.query(`CREATE TABLE IF NOT EXISTS feriados_locais (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    clinica_id UUID NOT NULL REFERENCES clinicas(id) ON DELETE CASCADE,
    unidade_id UUID REFERENCES unidades(id) ON DELETE CASCADE,
    data DATE NOT NULL,
    nome VARCHAR(100) NOT NULL,
    criado_em TIMESTAMP DEFAULT NOW())`);
  await pool.query(`CREATE UNIQUE INDEX IF NOT EXISTS ux_feriados_locais ON feriados_locais (clinica_id, COALESCE(unidade_id, '00000000-0000-0000-0000-000000000000'::uuid), data)`);
  await pool.query(`ALTER TABLE usuarios ADD COLUMN IF NOT EXISTS sessao_versao INTEGER NOT NULL DEFAULT 0`);
  await pool.query(`CREATE TABLE IF NOT EXISTS login_tentativas (chave TEXT PRIMARY KEY, inicio TIMESTAMPTZ NOT NULL DEFAULT NOW(), erros INTEGER NOT NULL DEFAULT 0)`);
  await pool.query(`ALTER TABLE prontuarios ADD COLUMN IF NOT EXISTS refracao JSONB`);
  await pool.query(`ALTER TABLE prontuarios ADD COLUMN IF NOT EXISTS exame JSONB`);
  await pool.query(`ALTER TABLE prontuarios ADD COLUMN IF NOT EXISTS fechado_em TIMESTAMP`);
  await pool.query(`CREATE TABLE IF NOT EXISTS prontuario_versoes (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    prontuario_id UUID NOT NULL REFERENCES prontuarios(id) ON DELETE CASCADE,
    usuario_id UUID, usuario_nome VARCHAR(150), motivo TEXT, snapshot JSONB,
    criado_em TIMESTAMP DEFAULT NOW())`);
  // duração própria da agenda (vazio = usa a duração do tipo de atendimento)
  await pool.query(`ALTER TABLE agendas ADD COLUMN IF NOT EXISTS duracao_min INTEGER`);
  // v4.7: digital e rosto (passkeys) foram retirados do sistema
  await pool.query(`DROP TABLE IF EXISTS passkeys`);
  // v4.7: preço de armações e garantias da vitrine (o administrador ajusta quando quiser)
  await pool.query(`ALTER TABLE clinicas ADD COLUMN IF NOT EXISTS vitrine_preco_armacao NUMERIC(10,2) DEFAULT 89.90`);
  await pool.query(`ALTER TABLE clinicas ADD COLUMN IF NOT EXISTS vitrine_garantia_lente_dias INTEGER DEFAULT 90`);
  await pool.query(`ALTER TABLE clinicas ADD COLUMN IF NOT EXISTS vitrine_garantia_armacao TEXT DEFAULT 'Garantia de 1 ano na armação, sujeita à análise.'`);
  // v4.7: nota fiscal SIMULADA (sem valor fiscal, só para treinar o fluxo)
  await pool.query(`CREATE TABLE IF NOT EXISTS notas_simuladas (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    clinica_id UUID NOT NULL REFERENCES clinicas(id) ON DELETE CASCADE,
    numero INTEGER NOT NULL,
    cliente_nome VARCHAR(150) NOT NULL,
    cliente_cpf VARCHAR(20),
    descricao VARCHAR(200) NOT NULL,
    valor NUMERIC(10,2) NOT NULL,
    forma VARCHAR(20),
    criado_por VARCHAR(150),
    criado_em TIMESTAMP DEFAULT NOW(),
    UNIQUE (clinica_id, numero))`);
  // v4.6.3 um usuário pode ter mais de uma cidade
  await pool.query(`CREATE TABLE IF NOT EXISTS usuarios_unidades (
    usuario_id UUID NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE,
    unidade_id UUID NOT NULL REFERENCES unidades(id) ON DELETE CASCADE,
    PRIMARY KEY (usuario_id, unidade_id))`);
  await pool.query(`INSERT INTO usuarios_unidades (usuario_id, unidade_id) SELECT id, unidade_id FROM usuarios WHERE unidade_id IS NOT NULL ON CONFLICT DO NOTHING`);
  // v4.10 formação superior do profissional (curso e instituição), impressa na receita
  await pool.query(`ALTER TABLE usuarios ADD COLUMN IF NOT EXISTS formacao VARCHAR(200)`);
}

module.exports = migrar;
