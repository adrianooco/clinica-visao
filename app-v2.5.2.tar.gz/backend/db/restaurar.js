/* Restaura um backup (.json baixado no painel) num banco novo e vazio.
   Uso:  DATABASE_URL=... node db/restaurar.js backup-2026-10-10.json
   Se o banco estiver vazio, as tabelas são criadas sozinhas.
   Linhas que já existem são mantidas, nada é apagado. */
const fs = require('fs');
const pool = require('./pool');
const migrar = require('./migrar');

const ORDEM = ['clinicas', 'unidades', 'usuarios', 'tipos_atendimento', 'pacientes', 'agendas', 'agendamentos', 'receitas', 'prontuarios', 'prontuario_versoes', 'testes_visao', 'pagamentos', 'contas_pagar', 'convenios', 'oticas_parceiras', 'acessos_log'];

async function main() {
  const arq = process.argv[2];
  if (!arq) { console.error('Informe o arquivo de backup.'); process.exit(1); }
  const b = JSON.parse(fs.readFileSync(arq, 'utf8'));
  if (!b.tabelas) { console.error('Arquivo antigo (formato 1): não tem todas as tabelas. Use um backup novo.'); process.exit(1); }
  const nomes = [...ORDEM.filter((n) => b.tabelas[n]), ...Object.keys(b.tabelas).filter((n) => !ORDEM.includes(n))];
  await migrar(); // cria as tabelas se o banco estiver vazio
  const c = await pool.connect();
  try {
    await c.query('BEGIN');
    for (const n of nomes) {
      const linhas = b.tabelas[n] || [];
      if (!linhas.length || !/^[a-z_]+$/.test(n)) { console.log(n + ': 0'); continue; }
      // colunas calculadas pelo banco (ex.: periodo_ocupado) não entram na cópia
      const cols = (await c.query(`SELECT column_name FROM information_schema.columns WHERE table_schema='public' AND table_name=$1 AND is_generated='NEVER' ORDER BY ordinal_position`, [n])).rows.map((x) => '"' + x.column_name + '"').join(', ');
      const r = await c.query(`INSERT INTO ${n} (${cols}) SELECT ${cols} FROM jsonb_populate_recordset(NULL::${n}, $1::jsonb) ON CONFLICT DO NOTHING`, [JSON.stringify(linhas)]);
      console.log(`${n}: ${r.rowCount} de ${linhas.length}`);
    }
    await c.query('COMMIT');
    console.log('Restauração concluída.');
  } catch (e) {
    await c.query('ROLLBACK');
    console.error('Falhou, nada foi gravado:', e.message);
    process.exitCode = 1;
  } finally { c.release(); await pool.end(); }
}
main();
