/* Aparelho perdido? Tira as chaves de digital/rosto de um usuário para ele entrar de novo só com a senha.
   Uso:  DATABASE_URL=... node db/remover-passkeys.js email@do.usuario */
const pool = require('./pool');
(async () => {
  const email = (process.argv[2] || '').toLowerCase().trim();
  if (!email) { console.error('Informe o e-mail.'); process.exit(1); }
  const r = await pool.query(`DELETE FROM passkeys WHERE usuario_id IN (SELECT id FROM usuarios WHERE email=$1)`, [email]);
  console.log(`Chaves removidas: ${r.rowCount}`);
  await pool.end();
})();
