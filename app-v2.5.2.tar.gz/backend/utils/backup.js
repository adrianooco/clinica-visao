const pool = require('../db/pool');

/* Cópia completa dos dados da clínica: todas as tabelas, incluindo
   senhas (já embaralhadas), prontuários, histórico de correções e registro de acessos.
   Serve para restaurar o sistema inteiro num banco novo. */
async function gerarBackupCompleto(clinicaId) {
  const t = await pool.query(`SELECT table_name FROM information_schema.tables WHERE table_schema='public' AND table_type='BASE TABLE' ORDER BY table_name`);
  const comClinica = await pool.query(`SELECT table_name FROM information_schema.columns WHERE table_schema='public' AND column_name='clinica_id'`);
  const temClinica = new Set(comClinica.rows.map((r) => r.table_name));
  const copia = { formato: 'clinica-visao-backup-2', gerado_em: new Date().toISOString(), clinica_id: clinicaId, tabelas: {} };
  for (const { table_name: nome } of t.rows) {
    if (!/^[a-z_]+$/.test(nome)) continue;
    let sql, params = [];
    if (nome === 'clinicas') { sql = `SELECT to_jsonb(x) AS j FROM clinicas x WHERE id=$1`; params = [clinicaId]; }
    else if (temClinica.has(nome)) { sql = `SELECT to_jsonb(x) AS j FROM ${nome} x WHERE clinica_id=$1`; params = [clinicaId]; }
    else if (nome === 'prontuario_versoes') { sql = `SELECT to_jsonb(x) AS j FROM prontuario_versoes x WHERE prontuario_id IN (SELECT id FROM prontuarios WHERE clinica_id=$1)`; params = [clinicaId]; }
    else continue;
    copia.tabelas[nome] = (await pool.query(sql, params)).rows.map((r) => r.j);
  }
  return copia;
}

module.exports = { gerarBackupCompleto };
