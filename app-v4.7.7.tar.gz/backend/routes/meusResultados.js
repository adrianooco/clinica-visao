const express = require('express');
const pool = require('../db/pool');
const { exigirLogin } = require('../middleware/auth');

/* O agendador vê só a cor do resultado de quem ele agendou. Nunca valor, comissão ou resultado de exame. */
const router = express.Router();
router.use(exigirLogin);

router.get('/', async (req, res) => {
  if (req.usuario.papel !== 'atendente') return res.status(403).json({ erro: 'Esta tela é do agendador.' });
  const r = await pool.query(
    `SELECT a.id, a.data_hora, a.status, p.nome_completo AS paciente_nome, un.nome AS unidade_nome, v.resultado
     FROM agendamentos a
     JOIN pacientes p ON p.id = a.paciente_id
     LEFT JOIN unidades un ON un.id = a.unidade_id
     LEFT JOIN vendas_oculos v ON v.agendamento_id = a.id
     WHERE a.clinica_id=$1 AND a.usuario_id=$2 AND a.data_hora::date >= CURRENT_DATE - 90
       AND a.data_hora < (NOW() AT TIME ZONE 'America/Sao_Paulo')
     ORDER BY a.data_hora DESC LIMIT 300`, [req.usuario.clinicaId, req.usuario.usuarioId]);
  const itens = r.rows.map((x) => {
    let cor = 'cinza', texto = 'Aguardando';
    if (x.resultado === 'completa') { cor = 'verde'; texto = 'Venda'; }
    else if (x.resultado === 'lente' || x.resultado === 'armacao') { cor = 'meio'; texto = '1/2 venda'; }
    else if (x.resultado === 'nao_comprou') { cor = 'vermelho'; texto = 'Não comprou'; }
    else if (x.status === 'faltou') texto = 'Não compareceu';
    else if (x.status === 'cancelado') texto = 'Cancelado';
    return { id: x.id, data_hora: x.data_hora, paciente_nome: x.paciente_nome, unidade_nome: x.unidade_nome, cor, texto };
  });
  const conta = (c) => itens.filter((i) => i.cor === c).length;
  res.setHeader('Cache-Control', 'no-store');
  res.json({ verde: conta('verde'), meio: conta('meio'), vermelho: conta('vermelho'), aguardando: conta('cinza'), itens });
});

module.exports = router;
