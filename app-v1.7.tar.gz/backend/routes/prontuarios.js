const express = require('express');
const pool = require('../db/pool');
const { exigirLogin, exigirPermissao } = require('../middleware/auth');

const router = express.Router();
router.use(exigirLogin);
router.use(exigirPermissao('prontuario')); // atendente só com liberação do administradorixo

/* confirma que o paciente existe, é da clínica, e, se o usuário for restrito a
   uma cidade, que o paciente é dessa mesma cidade */
async function pacienteAcessivel(req, pacienteId) {
  const params = [pacienteId, req.usuario.clinicaId];
  let filtro = '';
  if (req.usuario.unidadeId) { params.push(req.usuario.unidadeId); filtro = ' AND unidade_id=$3'; }
  const r = await pool.query(`SELECT id FROM pacientes WHERE id=$1 AND clinica_id=$2 AND deletado_em IS NULL${filtro}`, params);
  return r.rows.length > 0;
}

router.get('/', async (req, res) => {
  const { paciente_id } = req.query;
  if (paciente_id && !(await pacienteAcessivel(req, paciente_id))) {
    return res.status(404).json({ erro: 'Paciente não encontrado.' });
  }
  const params = [req.usuario.clinicaId, paciente_id || null];
  let filtroUnidade = '';
  if (req.usuario.unidadeId) { params.push(req.usuario.unidadeId); filtroUnidade = ` AND p.unidade_id=$3`; }
  const r = await pool.query(
    `SELECT pr.*, u.nome AS profissional_nome FROM prontuarios pr
     JOIN pacientes p ON p.id = pr.paciente_id
     JOIN usuarios u ON u.id = pr.profissional_id
     WHERE pr.clinica_id=$1 AND ($2::uuid IS NULL OR pr.paciente_id=$2)${filtroUnidade}
     ORDER BY pr.data_exame DESC, pr.criado_em DESC`,
    params
  );
  res.json(r.rows);
});

router.post('/', async (req, res) => {
  const { paciente_id, queixa_principal, sintomas, observacoes_clinicas, conduta, receita_id, data_exame, gabarito_acuidade, refracao } = req.body;
  if (!paciente_id) return res.status(400).json({ erro: 'Informe o paciente.' });
  if (!(await pacienteAcessivel(req, paciente_id))) {
    return res.status(404).json({ erro: 'Paciente não encontrado.' });
  }
  const r = await pool.query(
    `INSERT INTO prontuarios (clinica_id, paciente_id, profissional_id, data_exame, queixa_principal, sintomas, observacoes_clinicas, conduta, receita_id, gabarito_acuidade, refracao)
     VALUES ($1,$2,$3,COALESCE($4,CURRENT_DATE),$5,$6,$7,$8,$9,$10,$11) RETURNING *`,
    [req.usuario.clinicaId, paciente_id, req.usuario.usuarioId, data_exame || null,
     queixa_principal || null, sintomas ? JSON.stringify(sintomas) : null, observacoes_clinicas || null, conduta || null, receita_id || null,
     gabarito_acuidade ? JSON.stringify(gabarito_acuidade) : null,
     refracao ? JSON.stringify(refracao) : null]
  );
  res.status(201).json(r.rows[0]);
});

router.put('/:id', async (req, res) => {
  const { queixa_principal, sintomas, observacoes_clinicas, conduta, receita_id, gabarito_acuidade, refracao } = req.body;
  const r = await pool.query(
    `UPDATE prontuarios SET queixa_principal=$1, sintomas=$2, observacoes_clinicas=$3, conduta=$4, receita_id=$5, gabarito_acuidade=$6, refracao=$7
     WHERE id=$8 AND clinica_id=$9 RETURNING *`,
    [queixa_principal || null, sintomas ? JSON.stringify(sintomas) : null, observacoes_clinicas || null, conduta || null, receita_id || null,
     gabarito_acuidade ? JSON.stringify(gabarito_acuidade) : null, refracao ? JSON.stringify(refracao) : null, req.params.id, req.usuario.clinicaId]
  );
  if (!r.rows.length) return res.status(404).json({ erro: 'Prontuário não encontrado.' });
  res.json(r.rows[0]);
});

module.exports = router;
