/* Backup diário por e-mail (até a 4.9.38 era semanal), trancado com senha. Liga sozinho quando o servidor tem:
   SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS, EMAIL_DE, BACKUP_EMAIL_PARA e BACKUP_SENHA (8+ caracteres). */
const pool = require('../db/pool');
const email = require('./email');
const { gerarBackupCompleto, protegerBackup } = require('./backup');

const LIMITE_ANEXO = 20 * 1024 * 1024;
const ativo = () => email.ativo() && !!process.env.BACKUP_EMAIL_PARA && String(process.env.BACKUP_SENHA || '').length >= 8;

async function rodarUmaVez(forcar = false) {
  if (!ativo()) return { feito: false, motivo: 'desligado' };
  const clinicas = (await pool.query(`SELECT id, nome_fantasia FROM clinicas WHERE ativa=TRUE`)).rows;
  let enviados = 0;
  for (const c of clinicas) {
    const u = (await pool.query(`SELECT EXTRACT(EPOCH FROM (LOCALTIMESTAMP - MAX(criado_em))) / 3600 AS horas FROM acessos_log WHERE clinica_id=$1 AND area='backup'`, [c.id])).rows[0];
    if (!forcar && u.horas !== null && Number(u.horas) < 20) continue; // um por dia: espera 20 horas desde o último
    let cop;
    try { cop = protegerBackup(await gerarBackupCompleto(c.id), process.env.BACKUP_SENHA); }
    catch (e) { await avisarFalha(c, 'não consegui montar o arquivo (' + e.message + ')'); continue; }
    const texto = JSON.stringify(cop);
    const data = new Date().toISOString().slice(0, 10);
    let r;
    if (Buffer.byteLength(texto) > LIMITE_ANEXO) {
      r = await email.enviar({ para: process.env.BACKUP_EMAIL_PARA, assunto: `Backup de ${c.nome_fantasia} grande demais para e-mail`, texto: 'O backup passou de 20 MB e não coube no e-mail. Entre no sistema, abra Master, aba Segurança, e baixe o backup à mão.' });
    } else {
      r = await email.enviar({ para: process.env.BACKUP_EMAIL_PARA, assunto: `Backup diário de ${c.nome_fantasia} (${data})`, texto: 'Segue o backup trancado com a senha que você definiu no servidor (BACKUP_SENHA). Guarde este e-mail. Sem a senha o arquivo não abre.', anexos: [{ filename: `backup-${data}.json`, content: texto }] });
    }
    if (r.ok && Buffer.byteLength(texto) <= LIMITE_ANEXO) {
      await pool.query(`INSERT INTO acessos_log (clinica_id, usuario_nome, acao, area, caminho) VALUES ($1,'Sistema','AUTO','backup','/backup-automatico')`, [c.id]).catch(() => {});
      enviados++;
    } else {
      await avisarFalha(c, Buffer.byteLength(texto) > LIMITE_ANEXO ? 'o arquivo passou de 20 MB e não coube no e-mail' : 'o e-mail não saiu (' + ((r && (r.erro || r.motivo)) || 'sem resposta do Brevo') + ')');
    }
  }
  return { feito: true, enviados };
}
/* v4.9.39: se o backup do dia não sair, avisa por e-mail (no máximo 1 aviso por dia) e deixa registrado para o Guardião */
async function avisarFalha(c, motivo) {
  console.error(`Backup automático de ${c.nome_fantasia} falhou: ${motivo}`);
  try {
    const j = (await pool.query(`SELECT 1 FROM acessos_log WHERE clinica_id=$1 AND area='backup_falha' AND criado_em > LOCALTIMESTAMP - INTERVAL '20 hours' LIMIT 1`, [c.id])).rows.length;
    await pool.query(`INSERT INTO acessos_log (clinica_id, usuario_nome, acao, area, caminho) VALUES ($1,'Sistema','FALHA','backup_falha',$2)`, [c.id, String(motivo).slice(0, 190)]);
    if (j) return;
    const para = process.env.ALERTA_EMAIL_PARA || process.env.BACKUP_EMAIL_PARA;
    if (para) await email.enviar({ para, assunto: `Alerta: o backup de hoje de ${c.nome_fantasia} não saiu`,
      texto: `O backup automático de hoje falhou: ${motivo}.\n\nO sistema tenta de novo daqui a 6 horas. Enquanto isso, entre no sistema, abra Master, aba Segurança, e baixe o backup à mão.` });
  } catch (e) { console.error('Aviso de falha do backup:', e.message); }
}
let ligado = false;
function iniciar() {
  if (!ativo() || ligado) return;
  ligado = true;
  setTimeout(() => rodarUmaVez().catch((e) => console.error('Backup automático falhou:', e.message)), 120000).unref();
  setInterval(() => rodarUmaVez().catch((e) => console.error('Backup automático falhou:', e.message)), 6 * 3600000).unref();
  console.log('Backup diário por e-mail ligado.');
}
module.exports = { iniciar, rodarUmaVez, ativo };
