const pool = require('../db/pool');

/* ===== v4.9.36 fase 2: auditoria de telas =====
   Grava em auditoria_telas cada vez que alguém (o Master também) vê, cria, edita ou apaga dados de
   fichas, prontuários, receitas, agenda, configurações, financeiro e OCO.
   Leituras repetidas da mesma coisa pela mesma pessoa em 10 minutos contam uma vez só,
   para o registro não encher com a tela se atualizando sozinha.
   O registro vem sempre do servidor: o usuário, o papel, o IP e o aparelho não podem ser forjados pela tela. */

const TELAS = {
  '/pacientes': 'ficha', '/prontuarios': 'prontuario', '/receitas': 'receita',
  '/agendamentos': 'agenda', '/agendas': 'agenda', '/lista-espera': 'agenda', '/envios': 'agenda',
  '/clinica': 'configuracao', '/unidades': 'configuracao', '/tipos-atendimento': 'configuracao', '/feriados-locais': 'configuracao',
  '/financeiro': 'financeiro', '/gestor-vendas-api': 'oco', '/posvenda': 'oco', '/posexame': 'oco',
  '/testes-visao': 'prontuario', '/auditoria': 'auditoria', '/vigia': 'configuracao',
};
/* telas abertas na interface, avisadas pela própria tela (POST /auditoria/tela) */
const TELAS_INTERFACE = new Set(['inicio', 'agenda', 'calendario', 'fila', 'espera', 'confirmacao', 'envios', 'pacientes', 'ficha', 'prontuario',
  'anamnese', 'receita', 'retornos', 'aniversariantes', 'teste', 'assistente', 'relatorio', 'painel', 'financeiro', 'posexame', 'vendasgestor',
  'master', 'perfil', 'servicos', 'legal', 'auditoria']);
const ACAO = { GET: 'ver', POST: 'criar', PUT: 'editar', PATCH: 'editar', DELETE: 'apagar' };
const UUID = /[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/i;
const ehUuid = (v) => typeof v === 'string' && /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(v);

const vistos = new Map(); // chave -> quando (ms)
const JANELA_LEITURA = 10 * 60000;
setInterval(() => { const a = Date.now(); for (const [k, t] of vistos) if (a - t > JANELA_LEITURA) vistos.delete(k); }, 5 * 60000).unref();

function registroDoCaminho(req) {
  const resto = String(req.originalUrl || '').split('?')[0].slice(String(req.baseUrl || '').length);
  const u = UUID.exec(resto); if (u) return u[0];
  const n = /\/(\d{1,12})(\/|$)/.exec(resto); return n ? n[1] : null;
}
function pacienteDoPedido(req, tela, registro) {
  if (tela === 'ficha' && ehUuid(registro)) return registro;
  const q = req.query && req.query.paciente_id, b = req.body && req.body.paciente_id;
  if (ehUuid(q)) return q;
  if (ehUuid(b)) return b;
  return null;
}

function gravar(d) {
  return pool.query(
    `INSERT INTO auditoria_telas (clinica_id, usuario_id, usuario_nome, papel, tela, acao, registro_id, paciente_id, ip, aparelho, caminho, metodo)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12)`,
    [d.clinicaId, d.usuarioId, d.nome, d.papel, d.tela, d.acao, d.registro, d.paciente, d.ip, d.aparelho, d.caminho, d.metodo]
  ).catch((e) => console.error('Auditoria:', e.message));
}
const dadosBase = (req) => ({
  clinicaId: req.usuario.clinicaId, usuarioId: req.usuario.usuarioId || req.usuario.id || null, nome: req.usuario.nome || null,
  papel: req.usuario.papel || null, ip: String(req.ip || '').slice(0, 60), aparelho: String(req.get('user-agent') || '').slice(0, 200),
});
function repetido(chave) {
  const t = vistos.get(chave);
  if (t && Date.now() - t < JANELA_LEITURA) return true;
  vistos.set(chave, Date.now()); return false;
}

/* chamado pelo exigirLogin depois de saber quem é o usuário */
function auditarPedido(req, res) {
  const base = String(req.baseUrl || '').replace(/^\/api(?=\/)/, '');
  const tela = TELAS[base];
  if (!tela || !req.usuario) return;
  if (base === '/auditoria' && req.method === 'POST' && /\/tela\/?$/.test(req.path)) return; // o aviso de tela grava sozinho
  const acao = ACAO[req.method] || 'ver';
  const registro = registroDoCaminho(req);
  const paciente = pacienteDoPedido(req, tela, registro);
  res.on('finish', () => {
    if (res.statusCode >= 400) return;
    const quem = dadosBase(req);
    if (acao === 'ver' && repetido([quem.usuarioId, tela, registro, paciente].join('|'))) return; // leitura sem ficha nem registro conta 1 vez por tela a cada 10 min
    gravar({ ...quem, tela, acao, registro: registro ? String(registro).slice(0, 60) : null, paciente,
      caminho: String(req.originalUrl || '').split('?')[0].slice(0, 200), metodo: req.method });
  });
}

/* a tela avisa que foi aberta (inclusive a ficha de um paciente, que abre a partir da lista já carregada) */
async function registrarTela(req, res) {
  const tela = String((req.body || {}).tela || '').slice(0, 40);
  if (!TELAS_INTERFACE.has(tela)) return res.status(400).json({ erro: 'Tela desconhecida.' });
  let paciente = ehUuid((req.body || {}).paciente_id) ? req.body.paciente_id : null;
  if (paciente) {
    const ok = await pool.query(`SELECT 1 FROM pacientes WHERE id=$1 AND clinica_id=$2`, [paciente, req.usuario.clinicaId]);
    if (!ok.rows.length) paciente = null;
  }
  const base = dadosBase(req);
  if (!repetido([base.usuarioId, 'tela', tela, paciente].join('|'))) {
    await gravar({ ...base, tela, acao: 'ver', registro: paciente, paciente, caminho: '/tela/' + tela, metodo: 'TELA' });
  }
  res.json({ ok: true });
}

module.exports = { auditarPedido, registrarTela, TELAS, TELAS_INTERFACE };
