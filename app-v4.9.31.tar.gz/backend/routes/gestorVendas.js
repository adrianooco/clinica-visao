const express = require('express');
const pool = require('../db/pool');
const cripto = require('../utils/cripto');
const { exigirLogin } = require('../middleware/auth');

/* Sincronização do OCO (sistema de vendas do gestor). O app guarda tudo no aparelho e funciona sem internet.
   Quando a internet volta, ele junta o que tem com o que está aqui. Cada clínica tem uma única base.
   O servidor só guarda e controla a versão; quem junta os registros é o aparelho. */
const router = express.Router();
router.use(exigirLogin);
router.use((req, res, next) => {
  if (req.usuario.papel !== 'gestor' && req.usuario.papel !== 'admin') return res.status(403).json({ erro: 'Esta área é do gestor de vendas.' });
  next();
});

const COLECOES = ['clientes', 'vendas', 'ordens', 'contas', 'estoque', 'caixaMovimentos', 'fornecedores', 'compras', 'feedbacks', 'precos', 'lentesProntas'];
const MAX_REGISTROS = 200000;
const COPIAS_GUARDADAS = 15;

function validar(dados, tomb) {
  if (!dados || typeof dados !== 'object' || Array.isArray(dados)) return 'Dados inválidos.';
  let total = 0;
  for (const c of COLECOES) {
    const lista = dados[c];
    if (lista === undefined) continue;
    if (!Array.isArray(lista)) return 'Coleção inválida: ' + c;
    total += lista.length;
    for (const r of lista) if (!r || typeof r !== 'object' || Array.isArray(r) || typeof r.id !== 'number') return 'Registro sem número em ' + c;
  }
  if (total > MAX_REGISTROS) return 'Registros demais.';
  if (dados.loja !== undefined && (typeof dados.loja !== 'object' || dados.loja === null || Array.isArray(dados.loja))) return 'Dados da loja inválidos.';
  if (tomb !== undefined && (typeof tomb !== 'object' || tomb === null || Array.isArray(tomb))) return 'Exclusões inválidas.';
  return null;
}

router.get('/dados', async (req, res) => {
  const r = await pool.query(`SELECT versao, dados, atualizado_em, atualizado_por FROM gestor_vendas_dados WHERE clinica_id=$1`, [req.usuario.clinicaId]);
  if (!r.rows.length) return res.json({ versao: 0, dados: null, tomb: {}, clinica_id: req.usuario.clinicaId });
  const linha = r.rows[0];
  let corpo;
  try { corpo = JSON.parse(cripto.decifrar(linha.dados)); } catch (e) { console.error(e); return res.status(500).json({ erro: 'Não consegui abrir os dados guardados.' }); }
  res.json({ clinica_id: req.usuario.clinicaId, versao: linha.versao, dados: corpo.dados || null, tomb: corpo.tomb || {}, atualizado_em: linha.atualizado_em, atualizado_por: linha.atualizado_por });
});

router.put('/dados', async (req, res) => {
  const { base_versao, dados, tomb } = req.body || {};
  if (!Number.isInteger(base_versao) || base_versao < 0) return res.status(400).json({ erro: 'Versão inválida.' });
  const erro = validar(dados, tomb);
  if (erro) return res.status(400).json({ erro });
  const texto = cripto.cifrar(JSON.stringify({ dados, tomb: tomb || {} }));
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const atual = await client.query(`SELECT versao FROM gestor_vendas_dados WHERE clinica_id=$1 FOR UPDATE`, [req.usuario.clinicaId]);
    const versaoAtual = atual.rows.length ? atual.rows[0].versao : 0;
    if (versaoAtual !== base_versao) { await client.query('ROLLBACK'); return res.status(409).json({ erro: 'Outro aparelho enviou dados antes. Vou juntar e tentar de novo.', versao: versaoAtual }); }
    const nova = versaoAtual + 1;
    if (!atual.rows.length) {
      await client.query(`INSERT INTO gestor_vendas_dados (clinica_id, versao, dados, atualizado_em, atualizado_por) VALUES ($1,$2,$3,NOW(),$4)`, [req.usuario.clinicaId, nova, texto, req.usuario.usuarioId]);
    } else {
      await client.query(`UPDATE gestor_vendas_dados SET versao=$2, dados=$3, atualizado_em=NOW(), atualizado_por=$4 WHERE clinica_id=$1`, [req.usuario.clinicaId, nova, texto, req.usuario.usuarioId]);
    }
    await client.query(`INSERT INTO gestor_vendas_copias (clinica_id, versao, dados, criado_em) VALUES ($1,$2,$3,NOW())`, [req.usuario.clinicaId, nova, texto]);
    await client.query(`DELETE FROM gestor_vendas_copias WHERE clinica_id=$1 AND versao <= $2`, [req.usuario.clinicaId, nova - COPIAS_GUARDADAS]);
    await client.query('COMMIT');
    res.json({ versao: nova });
  } catch (e) {
    await client.query('ROLLBACK').catch(() => {});
    console.error(e);
    res.status(500).json({ erro: 'Não consegui guardar os dados.' });
  } finally { client.release(); }
});

/* ===== Atendente IA do WhatsApp da ótica (v4.9.24) =====
   A IA responde os clientes sozinha. Só o Master (papel admin) liga, desliga e muda as instruções.
   A equipe vê as conversas, responde e assume quando precisar. */
const ia = require('../utils/iaAtendente');
const wpp = require('../utils/whatsapp');
const soMaster = (req, res, next) => (req.usuario.papel === 'admin' ? next() : res.status(403).json({ erro: 'Só o Master muda o atendente.' }));
const telOk = (t) => /^\d{10,20}$/.test(String(t || ''));
const HORAS_EQUIPE = 12;

router.get('/atendente/config', async (req, res) => {
  const cfg = await ia.lerConfig(req.usuario.clinicaId);
  res.json({
    ativo: !!cfg.ativo, numero_otica: cfg.numero_otica || '', nome_atendente: cfg.nome_atendente || '', horario: cfg.horario || '', instrucoes: cfg.instrucoes || '',
    atualizado_em: cfg.atualizado_em || null, atualizado_por: cfg.atualizado_por || null,
    gemini: ia.configurada(), meta: wpp.configurado(), master: req.usuario.papel === 'admin',
    webhook: (process.env.URL_PUBLICA || '').replace(/\/$/, '') + '/whatsapp/webhook',
  });
});

router.put('/atendente/config', soMaster, async (req, res) => {
  const b = req.body || {};
  const numero = String(b.numero_otica || '').replace(/\D/g, '');
  if (numero && (numero.length < 10 || numero.length > 13)) return res.status(400).json({ erro: 'Número da ótica inválido. Use DDD + número.' });
  if (b.ativo && !numero) return res.status(400).json({ erro: 'Para ligar a IA, informe o número de WhatsApp da ótica.' });
  if (numero) {
    const igual = await pool.query(`SELECT 1 FROM clinicas WHERE id=$1 AND RIGHT(REGEXP_REPLACE(COALESCE(whatsapp_numero,''),'\\D','','g'),10)=$2`, [req.usuario.clinicaId, numero.slice(-10)]);
    if (igual.rows.length) return res.status(400).json({ erro: 'Esse número é o da Clínica. A ótica precisa de um número separado.' });
  }
  await pool.query(
    `INSERT INTO atendente_config (clinica_id, ativo, numero_otica, nome_atendente, horario, instrucoes, atualizado_em, atualizado_por)
     VALUES ($1,$2,$3,$4,$5,$6,NOW(),$7)
     ON CONFLICT (clinica_id) DO UPDATE SET ativo=$2, numero_otica=$3, nome_atendente=$4, horario=$5, instrucoes=$6, atualizado_em=NOW(), atualizado_por=$7`,
    [req.usuario.clinicaId, !!b.ativo, numero || null, String(b.nome_atendente || '').slice(0, 40) || null,
      String(b.horario || '').slice(0, 300) || null, String(b.instrucoes || '').slice(0, 4000) || null, req.usuario.nome || null]);
  res.json({ ok: true });
});

/* simulador: testa a resposta da IA sem mandar nada para o WhatsApp (funciona antes da chave da Meta) */
const testes = new Map();
router.post('/atendente/testar', async (req, res) => {
  const hist = Array.isArray(req.body?.historico) ? req.body.historico : [];
  const limpo = hist.slice(-16).map((m) => ({ autor: m.autor === 'cliente' ? 'cliente' : 'ia', texto: String(m.texto || '').slice(0, 1500) })).filter((m) => m.texto);
  if (!limpo.length || limpo[limpo.length - 1].autor !== 'cliente') return res.status(400).json({ erro: 'Escreva uma mensagem de cliente para testar.' });
  const agora = Date.now(); const lista = (testes.get(req.usuario.usuarioId) || []).filter((t) => agora - t < 3600000);
  if (lista.length >= 60) return res.status(429).json({ erro: 'Muitos testes nesta hora. Tente mais tarde.' });
  lista.push(agora); testes.set(req.usuario.usuarioId, lista);
  try { res.json(await ia.responderCliente(req.usuario.clinicaId, limpo)); }
  catch (e) { console.error('Teste do atendente:', e.message); res.status(502).json({ erro: 'A IA não respondeu: ' + e.message }); }
});

router.get('/atendente/conversas', async (req, res) => {
  const r = await pool.query(
    `SELECT c.telefone, c.nome, c.precisa_equipe, c.nao_lidas, c.ultima_em, (c.equipe_ate IS NOT NULL AND c.equipe_ate > NOW()) AS com_equipe,
       (SELECT texto FROM wa_mensagens m WHERE m.clinica_id=c.clinica_id AND m.telefone=c.telefone ORDER BY criado_em DESC LIMIT 1) AS ultima
     FROM wa_conversas c WHERE c.clinica_id=$1 ORDER BY c.precisa_equipe DESC, c.ultima_em DESC LIMIT 200`, [req.usuario.clinicaId]);
  res.json(r.rows);
});

router.get('/atendente/conversas/:tel', async (req, res) => {
  if (!telOk(req.params.tel)) return res.status(400).json({ erro: 'Telefone inválido.' });
  const r = await pool.query(
    `SELECT autor, texto, enviado_por, criado_em FROM (SELECT * FROM wa_mensagens WHERE clinica_id=$1 AND telefone=$2 ORDER BY criado_em DESC LIMIT 200) t ORDER BY criado_em`,
    [req.usuario.clinicaId, req.params.tel]);
  await pool.query(`UPDATE wa_conversas SET nao_lidas=0 WHERE clinica_id=$1 AND telefone=$2`, [req.usuario.clinicaId, req.params.tel]);
  res.json(r.rows);
});

/* a equipe responde: a IA fica quieta nessa conversa por 12 horas */
router.post('/atendente/conversas/:tel/responder', async (req, res) => {
  if (!telOk(req.params.tel)) return res.status(400).json({ erro: 'Telefone inválido.' });
  const texto = String(req.body?.texto || '').trim().slice(0, 3500);
  if (!texto) return res.status(400).json({ erro: 'Escreva a resposta.' });
  if (!wpp.configurado()) return res.status(400).json({ erro: 'O WhatsApp automático ainda não está ligado (falta a chave da Meta).' });
  const conv = await pool.query(`SELECT phone_id, ultima_em FROM wa_conversas WHERE clinica_id=$1 AND telefone=$2`, [req.usuario.clinicaId, req.params.tel]);
  if (!conv.rows.length) return res.status(404).json({ erro: 'Conversa não encontrada.' });
  const ultCliente = await pool.query(`SELECT MAX(criado_em) t FROM wa_mensagens WHERE clinica_id=$1 AND telefone=$2 AND autor='cliente'`, [req.usuario.clinicaId, req.params.tel]);
  if (!ultCliente.rows[0].t || Date.now() - new Date(ultCliente.rows[0].t).getTime() > 24 * 3600000) {
    return res.status(400).json({ erro: 'Passaram mais de 24 horas da última mensagem do cliente. A Meta só deixa responder livre dentro de 24 horas. Chame pelo botão WhatsApp normal.' });
  }
  try { await wpp.responder(req.params.tel, texto, conv.rows[0].phone_id); }
  catch (e) { return res.status(502).json({ erro: 'O WhatsApp não aceitou: ' + e.message }); }
  await pool.query(`INSERT INTO wa_mensagens (clinica_id, telefone, autor, texto, enviado_por) VALUES ($1,$2,'equipe',$3,$4)`, [req.usuario.clinicaId, req.params.tel, texto, req.usuario.nome || null]);
  await pool.query(`UPDATE wa_conversas SET equipe_ate=NOW() + ($3 || ' hours')::interval, precisa_equipe=FALSE, ultima_em=NOW() WHERE clinica_id=$1 AND telefone=$2`, [req.usuario.clinicaId, req.params.tel, String(HORAS_EQUIPE)]);
  res.json({ ok: true });
});

router.post('/atendente/conversas/:tel/assumir', async (req, res) => {
  if (!telOk(req.params.tel)) return res.status(400).json({ erro: 'Telefone inválido.' });
  const devolver = !!req.body?.devolver;
  await pool.query(
    devolver ? `UPDATE wa_conversas SET equipe_ate=NULL, precisa_equipe=FALSE WHERE clinica_id=$1 AND telefone=$2`
      : `UPDATE wa_conversas SET equipe_ate=NOW() + INTERVAL '${HORAS_EQUIPE} hours' WHERE clinica_id=$1 AND telefone=$2`,
    [req.usuario.clinicaId, req.params.tel]);
  res.json({ ok: true });
});

module.exports = router;
