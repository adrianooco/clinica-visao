/* Service worker simples: deixa o app instalável e guarda só a tela de entrada para abrir mais rápido.
   Nada de dados de pacientes passa por aqui: chamadas à API nunca são guardadas. */
const CACHE = 'clinica-visao-casca-v3';
const CASCA = ['/modulo-agendamento.html', '/app.js', '/app.css', '/optotipo.js', '/qrcode.js', '/icone-192.png', '/manifest.json'];
self.addEventListener('install', (e) => { e.waitUntil(caches.open(CACHE).then((c) => c.addAll(CASCA)).catch(() => {})); self.skipWaiting(); });
self.addEventListener('activate', (e) => { e.waitUntil(caches.keys().then((ks) => Promise.all(ks.filter((k) => k !== CACHE).map((k) => caches.delete(k)))).then(() => self.clients.claim())); });
self.addEventListener('fetch', (e) => {
  const r = e.request, u = new URL(r.url);
  if (r.method !== 'GET' || u.origin !== location.origin || !CASCA.includes(u.pathname)) return;
  // sempre tenta a versão nova primeiro; sem internet, usa a guardada
  e.respondWith(fetch(r).then((resp) => { const copia = resp.clone(); caches.open(CACHE).then((c) => c.put(r, copia)); return resp; }).catch(() => caches.match(r)));
});
