/* Guardião do sistema: confere a saúde do programa, os backups e as obrigações do Master.
   Cada item volta com um nível (ok, aviso, erro, info) e, quando existe, uma ação:
   - corrigir: o servidor resolve com um clique (pede confirmação quando mexe em algo importante)
   - ir: leva o Master até a tela certa
   - passos: lista curta do que fazer fora do sistema (ex.: Render, GitHub)
   Não envia nenhum dado de paciente. Os e-mails de alerta só dizem os títulos dos problemas. */
const crypto = require('crypto');
const pool = require('../db/pool');
const cripto = require('./cripto');
const email = require('./email');
const licenca = require('./licenca');

const NIVEL = { erro: 3, aviso: 2, info: 1, ok: 0 };
const iniciouEm = Date.now();
let ultimoPingExterno = 0;

/* quem chama /health de fora (monitor de queda) deixa marca aqui */
function registrarPing(userAgent) {
  const ua = String(userAgent || '');
  if (/uptime|pingdom|betterstack|better stack|cron-job|statuscake|freshping|hetrix|site24x7|updown|monitor/i.test(ua)) ultimoPingExterno = Date.now();
}
const monitorAtivo = () => Date.now() - ultimoPingExterno < 20 * 60 * 1000;

const OBRIGACOES_PADRAO = [
  { codigo: 'plano_banco', titulo: 'Contratar o plano pago do banco de dados', dias: null, data: '2026-11-08', repetir: null,
    detalhe: 'O banco gratuito da Render expira em 08/11/2026 e não tem backup automático. Na Render: abra o banco, toque em Upgrade e escolha um plano pago.' },
  { codigo: 'plano_servidor', titulo: 'Contratar o plano pago do servidor', dias: null, data: '2026-11-01', repetir: null,
    detalhe: 'O servidor gratuito dorme depois de 15 minutos parado e o primeiro paciente espera cerca de 50 segundos. Na Render: abra o serviço, toque em Settings, depois Instance Type, e escolha um plano pago.' },
  { codigo: 'repo_privado', titulo: 'Deixar o repositório do GitHub privado', dias: 10, repetir: null,
    detalhe: 'No GitHub: abra o repositório, toque em Settings, role até Danger Zone e toque em Change visibility. Escolha Private.' },
  { codigo: 'trocar_tokens', titulo: 'Trocar os tokens do GitHub e a senha do banco', dias: 11, repetir: 180,
    detalhe: 'Depois de deixar o repositório privado, crie tokens novos no GitHub e troque a senha do banco na Render. Apague os antigos.' },
  { codigo: 'copia_chave', titulo: 'Guardar a chave de criptografia em dois lugares', dias: 3, repetir: null,
    detalhe: 'Copie o valor de CHAVE_CRIPTOGRAFIA (Render, Environment) e guarde em dois lugares seguros, fora da Render. Se a chave se perder, os dados protegidos não abrem mais. A impressão da chave aparece no Guardião para você conferir a cópia.' },
  { codigo: 'monitor_externo', titulo: 'Ligar o aviso de queda gratuito (UptimeRobot)', dias: 5, repetir: null, auto: 'monitor',
    detalhe: 'Crie uma conta grátis em uptimerobot.com, adicione um monitor do tipo HTTP(s) com o endereço do sistema terminando em /health e intervalo de 5 minutos. Ele avisa quando o sistema cair e mantém o servidor acordado.' },
  { codigo: 'trocar_chave_brevo', titulo: 'Trocar a chave do Brevo', dias: 3, repetir: null,
    detalhe: 'A chave atual passou por conversa e foto. No Brevo: clique no seu nome, SMTP e API, aba Chaves de API, gere uma chave nova. Na Render, em Environment, troque o valor de BREVO_API_KEY pela chave nova e salve. Depois, no Brevo, apague a chave antiga. Em Master, use o botão de e-mail de teste para conferir.' },
  { codigo: 'google_2fa', titulo: 'Ligar a verificação em duas etapas do Google', dias: 3, repetir: null,
    detalhe: 'O e-mail do backup recebe cópias dos dados da clínica. Em myaccount.google.com, abra Segurança, depois Verificação em duas etapas, e siga os passos com o seu celular.' },
  { codigo: 'email_config', titulo: 'Ligar o e-mail do sistema', dias: 7, repetir: null, auto: 'email',
    detalhe: 'Crie uma conta grátis no Brevo, pegue os dados SMTP e coloque na Render, em Environment: SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS e EMAIL_DE.' },
  { codigo: 'backup_manual', titulo: 'Baixar um backup e guardar fora do sistema', dias: 7, repetir: 30,
    detalhe: 'Master, aba Segurança, botão Baixar backup. Guarde o arquivo e a senha em lugares diferentes.' },
  { codigo: 'teste_restauracao', titulo: 'Testar a restauração de um backup', dias: 30, repetir: 90,
    detalhe: 'Backup que nunca foi restaurado não é garantia. Rode o restaurar.js com um backup num banco de teste. O arquivo LEIA-ME do pacote explica o passo a passo.' },
  { codigo: 'revisar_usuarios', titulo: 'Revisar quem tem acesso ao sistema', dias: 30, repetir: 90,
    detalhe: 'Master, aba Equipe. Desative quem saiu da clínica e confira quem tem papel de administrador.' },
  { codigo: 'dominio', titulo: 'Colocar o domínio próprio', dias: 30, repetir: null,
    detalhe: 'Registre um domínio (por exemplo clinicadevisao.com.br) e aponte para a Render, em Settings, Custom Domains.' },
  { codigo: 'whatsapp_meta', titulo: 'Pedir a chave da Meta para o WhatsApp automático', dias: 30, repetir: null, auto: 'whatsapp',
    detalhe: 'Crie a conta no Meta for Developers, ative o WhatsApp Business e coloque WA_TOKEN e WA_PHONE_ID na Render, em Environment.' },
  { codigo: 'piloto', titulo: 'Fazer o piloto com 20 pacientes', dias: 21, repetir: null,
    detalhe: 'Use o sistema de verdade com 20 pacientes e anote onde a equipe trava. O modo treino do Guardião ajuda a preparar a equipe antes.' },
  { codigo: 'lgpd', titulo: 'Revisão de LGPD com advogado', dias: 45, repetir: null,
    detalhe: 'Leve o aviso de privacidade e o termo de aceite do sistema para um advogado revisar.' },
  { codigo: 'inpi', titulo: 'Registrar a marca no INPI', dias: 60, repetir: null,
    detalhe: 'O registro da marca Clínica de Visão no INPI protege o nome contra cópia.' },
  { codigo: 'trocar_senha_master', titulo: 'Trocar a senha do Master', dias: 180, repetir: 180,
    detalhe: 'Meu perfil, trocar senha. Use uma senha longa que você não usa em outro lugar.' },
];

async function garantirObrigacoes(clinicaId) {
  for (const o of OBRIGACOES_PADRAO) {
    const venc = o.data ? o.data : null;
    await pool.query(
      `INSERT INTO assistente_obrigacoes (clinica_id, codigo, titulo, detalhe, vence_em, repetir_dias)
       VALUES ($1,$2,$3,$4, COALESCE($5::date, CURRENT_DATE + $6::int), $7)
       ON CONFLICT (clinica_id, codigo) WHERE codigo IS NOT NULL DO NOTHING`,
      [clinicaId, o.codigo, o.titulo, o.detalhe, venc, o.dias || 0, o.repetir]);
  }
}

const item = (id, grupo, nivel, titulo, detalhe, acao) => ({ id, grupo, nivel, titulo, detalhe, acao: acao || null });
const ir = (rotulo, destino) => ({ tipo: 'ir', rotulo, ...destino });
const corrigir = (rotulo, id, confirmar) => ({ tipo: 'corrigir', rotulo, id, confirmar: confirmar || null });
const passos = (rotulo, lista) => ({ tipo: 'passos', rotulo, passos: lista });

async function contarAbertos() {
  if (!cripto.ativa()) return 0;
  const q = async (sql) => Number((await pool.query(sql)).rows[0].n);
  const ab = (c) => `(${c} IS NOT NULL AND ${c} <> '' AND ${c} NOT LIKE 'enc1:%')`;
  return (await q(`SELECT COUNT(*)::int AS n FROM prontuarios WHERE ${ab('queixa_principal')} OR ${ab('observacoes_clinicas')} OR ${ab('conduta')}`))
    + (await q(`SELECT COUNT(*)::int AS n FROM receitas WHERE ${ab('atestado_texto')} OR ${ab('declaracao_texto')} OR ${ab('cid_codigo')} OR ${ab('cid_descricao')}`))
    + (await q(`SELECT COUNT(*)::int AS n FROM pacientes WHERE ${ab('cpf')} OR ${ab('foto_receita_url')} OR ${ab('foto_armacao_url')}`));
}

const COLUNAS_ESPERADAS = [['pacientes', 'cpf_idx'], ['usuarios', 'sessao_versao'], ['usuarios', 'totp_ativo'], ['agendamentos', 'chegou_em'], ['clinicas', 'licenca'], ['assistente_obrigacoes', 'vence_em'], ['assistente_verificacoes', 'resumo'], ['vigia_ocorrencias', 'status'], ['vigia_pedidos', 'status']];

async function verificar(clinicaId) {
  const itens = [];
  const add = (...a) => itens.push(item(...a));
  const um = async (sql, p = [clinicaId]) => (await pool.query(sql, p)).rows[0];
  const prod = process.env.NODE_ENV === 'production';

  /* ---------- SISTEMA ---------- */
  const t0 = Date.now();
  try { await pool.query('SELECT 1'); } catch (e) { add('banco', 'Sistema', 'erro', 'O banco de dados não responde', 'Sem o banco nada funciona. Confira o banco na Render.'); }
  const ms = Date.now() - t0;
  if (!itens.length) add('banco', 'Sistema', ms > 1500 ? 'aviso' : 'ok', 'Banco de dados respondendo', `Resposta em ${ms} ms.${ms > 1500 ? ' Está lento.' : ''}`);

  const cols = (await pool.query(`SELECT table_name, column_name FROM information_schema.columns WHERE table_schema='public'`)).rows;
  const tem = new Set(cols.map((c) => c.table_name + '.' + c.column_name));
  const faltam = COLUNAS_ESPERADAS.filter(([t, c]) => !tem.has(t + '.' + c));
  add('estrutura', 'Sistema', faltam.length ? 'erro' : 'ok', faltam.length ? 'O banco está desatualizado' : 'Estrutura do banco em dia',
    faltam.length ? `Faltam ${faltam.length} ajuste(s): ${faltam.map((f) => f.join('.')).join(', ')}.` : 'Todas as tabelas e colunas esperadas existem.',
    faltam.length ? corrigir('Atualizar o banco agora', 'aplicar_migracoes') : null);

  const tam = Number((await um(`SELECT pg_database_size(current_database()) AS n`, [])).n);
  const limiteMb = parseInt(process.env.DB_LIMITE_MB, 10) || 1024;
  const pct = Math.round((tam / 1048576 / limiteMb) * 100);
  add('tamanho', 'Sistema', pct >= 90 ? 'erro' : pct >= 70 ? 'aviso' : 'ok', 'Espaço do banco',
    `Usando ${(tam / 1048576).toFixed(1)} MB de ${limiteMb} MB (${pct}%).${pct >= 70 ? ' Quando encher, o sistema para de gravar. Suba o plano do banco na Render.' : ''}`,
    pct >= 70 ? passos('Ver como aumentar', ['Abra a Render e entre no banco de dados.', 'Toque em Upgrade ou Settings.', 'Escolha um plano com mais espaço.']) : null);

  const rss = process.memoryUsage().rss / 1048576;
  add('memoria', 'Sistema', rss > 400 ? 'aviso' : 'ok', 'Memória do servidor', `Usando ${Math.round(rss)} MB. O plano gratuito aguenta cerca de 512 MB.`);

  const rr = await um(`SELECT COUNT(*)::int AS n, COALESCE(MAX(parado_min),0)::int AS m FROM sistema_reinicios WHERE criado_em > NOW() - INTERVAL '24 hours'`, []);
  const rein = rr.n, reinMax = rr.m;
  add('reinicios', 'Sistema', rein > 6 ? 'aviso' : 'info', 'Reinícios nas últimas 24 horas',
    rein ? `O servidor reiniciou ${rein} vez(es). Maior tempo parado: ${reinMax} minutos. No plano gratuito ele dorme quando ninguém usa.` : 'Nenhum reinício.',
    rein && !monitorAtivo() ? passos('Evitar que o servidor durma', ['Crie uma conta grátis em uptimerobot.com.', 'Adicione um monitor HTTP(s) com o endereço do sistema terminando em /health.', 'Escolha intervalo de 5 minutos.']) : null);

  add('monitor', 'Sistema', monitorAtivo() ? 'ok' : 'aviso', monitorAtivo() ? 'Aviso de queda ligado' : 'Ninguém vigia o sistema de fora',
    monitorAtivo() ? 'Um monitor externo chamou /health nos últimos 20 minutos.' : 'Se o sistema cair de madrugada você só descobre de manhã. Um monitor grátis avisa na hora e mantém o servidor acordado.',
    monitorAtivo() ? null : passos('Ligar o monitor grátis', ['Entre em uptimerobot.com e crie uma conta grátis.', 'Toque em Add New Monitor.', 'Tipo HTTP(s). Endereço: o do sistema terminando em /health.', 'Intervalo de 5 minutos. Coloque seu e-mail para receber o aviso.']));

  add('producao', 'Sistema', prod ? 'ok' : 'aviso', prod ? 'Servidor em modo de produção' : 'Servidor fora do modo de produção', prod ? 'NODE_ENV=production.' : 'Em produção, NODE_ENV precisa ser production.');

  /* ---------- SEGURANÇA ---------- */
  const cripOn = cripto.ativa();
  const digital = cripOn ? crypto.createHash('sha256').update('imp:' + String(process.env.CHAVE_CRIPTOGRAFIA)).digest('hex').slice(0, 8).toUpperCase() : null;
  add('cripto', 'Segurança', cripOn ? 'ok' : 'erro', cripOn ? 'Dados criptografados' : 'Dados sem criptografia',
    cripOn ? `Impressão da chave: ${digital}. Compare com a da sua cópia guardada. Se for igual, a cópia serve.` : 'Falta a variável CHAVE_CRIPTOGRAFIA na Render.');

  const abertos = await contarAbertos().catch(() => 0);
  if (cripOn) add('abertos', 'Segurança', abertos ? 'erro' : 'ok', abertos ? 'Existem dados abertos no banco' : 'Nenhum dado aberto no banco',
    abertos ? `${abertos} registro(s) ainda estão sem criptografia.` : 'Prontuários, receitas, CPF e fotos estão todos trancados.',
    abertos ? corrigir('Criptografar agora', 'proteger_dados') : null);

  if (process.env.CHAVE_CRIPTOGRAFIA_ANTIGA) add('chave_antiga', 'Segurança', 'aviso', 'A chave antiga ainda está no servidor',
    'Depois da troca de chave, apague CHAVE_CRIPTOGRAFIA_ANTIGA da Render. Uma chave velha esquecida é uma brecha.',
    passos('Como apagar', ['Abra a Render, serviço clinica-visao, Environment.', 'Apague a variável CHAVE_CRIPTOGRAFIA_ANTIGA.', 'Salve. O servidor reinicia sozinho.']));

  const jwt = String(process.env.JWT_SECRET || '');
  add('jwt', 'Segurança', jwt.length >= 32 ? 'ok' : jwt.length ? 'aviso' : 'erro', jwt.length >= 32 ? 'Segredo de login forte' : 'Segredo de login fraco', jwt.length >= 32 ? 'JWT_SECRET tem tamanho bom.' : 'JWT_SECRET precisa ter pelo menos 32 caracteres aleatórios.');

  const adm = await um(`SELECT COUNT(*)::int AS total,
      COUNT(*) FILTER (WHERE NOT totp_ativo)::int AS sem
      FROM usuarios u WHERE clinica_id=$1 AND ativo=TRUE AND papel='admin'`);
  add('admin2f', 'Segurança', adm.sem ? 'aviso' : 'ok', adm.sem ? 'Administrador só com senha' : 'Administradores com segunda proteção',
    adm.sem ? `${adm.sem} administrador(es) entram só com senha. Ative o código do celular em Meu perfil.` : 'Todos usam o código do celular.',
    adm.sem ? ir('Abrir Meu perfil', { view: 'perfil' }) : null);

  const falhas = await um(`SELECT COALESCE(SUM(erros),0)::int AS n, COUNT(*)::int AS chaves FROM login_tentativas WHERE inicio > NOW() - INTERVAL '24 hours'`, []);
  add('falhas', 'Segurança', falhas.n >= 40 ? 'erro' : falhas.n >= 15 ? 'aviso' : 'ok', 'Tentativas de login erradas',
    `${falhas.n} erro(s) de senha nas últimas 24 horas${falhas.chaves ? ` em ${falhas.chaves} conta(s)/aparelho(s)` : ''}.${falhas.n >= 15 ? ' Pode ser alguém tentando adivinhar uma senha. O bloqueio automático já está ativo.' : ''}`);

  const novos = await um(`SELECT COUNT(*)::int AS n FROM dispositivos_login d JOIN usuarios u ON u.id=d.usuario_id WHERE u.clinica_id=$1 AND d.primeiro_em > NOW() - INTERVAL '7 days'`);
  add('aparelhos', 'Segurança', 'info', 'Aparelhos novos na última semana', `${novos.n} aparelho(s) entraram pela primeira vez.`);

  const parados = await um(`SELECT COUNT(*)::int AS n FROM usuarios u WHERE clinica_id=$1 AND ativo=TRUE AND papel<>'admin' AND criado_em < NOW() - INTERVAL '60 days'
      AND NOT EXISTS (SELECT 1 FROM dispositivos_login d WHERE d.usuario_id=u.id AND d.visto_em > NOW() - INTERVAL '60 days')`);
  if (parados.n) add('parados', 'Segurança', 'aviso', 'Usuários sem entrar há 60 dias', `${parados.n} usuário(s) ativo(s) não entram há mais de 60 dias. Conta esquecida é porta aberta.`,
    corrigir('Desativar esses usuários', 'desativar_inativos', 'Desativar os usuários parados? Eles não conseguem mais entrar. Você pode reativar na aba Equipe.'));

  const lic = await (async () => {
    if (!process.env.LICENCA_SEGREDO) return null;
    const c = (await pool.query(`SELECT slug, licenca FROM clinicas WHERE id=$1`, [clinicaId])).rows[0];
    const r = licenca.conferir(c.licenca, c.slug);
    return { controle: true, valida: r.valida, ate: r.ate || null, dias: r.dias ?? null };
  })().catch(() => null);
  if (lic && lic.controle) add('licenca', 'Segurança', !lic.valida ? 'erro' : (lic.dias !== undefined && lic.dias !== null && lic.dias <= 30 ? 'aviso' : 'ok'), 'Licença da clínica',
    lic.valida ? (lic.ate ? `Válida até ${String(lic.ate).slice(0, 10)} (${lic.dias} dias).` : 'Válida.') : 'Sem licença válida.', !lic.valida || (lic.dias <= 30) ? ir('Abrir a licença', { view: 'master', aba: 'Segurança' }) : null);

  const repo = process.env.GITHUB_REPO;
  if (repo && /^[\w.-]+\/[\w.-]+$/.test(repo)) {
    let publico = null;
    try {
      const r = await fetch('https://api.github.com/repos/' + repo, { headers: { 'User-Agent': 'clinica-visao-guardiao' }, signal: AbortSignal.timeout(6000) });
      publico = r.status === 200 ? true : r.status === 404 ? false : null;
    } catch (e) { /* sem resposta: não conclui nada */ }
    if (publico === true) add('repo', 'Segurança', 'erro', 'O código está público no GitHub', 'Qualquer pessoa pode baixar o sistema inteiro. Deixe o repositório privado.', passos('Como deixar privado', ['Abra o repositório no GitHub.', 'Toque em Settings.', 'Role até Danger Zone e toque em Change visibility.', 'Escolha Private e confirme.']));
    else if (publico === false) add('repo', 'Segurança', 'ok', 'Repositório privado', 'O código não aparece para quem não tem acesso.');
    if (publico !== null) await pool.query(`UPDATE assistente_obrigacoes SET feito_em=NOW() WHERE clinica_id=$1 AND codigo='repo_privado' AND $2::boolean AND feito_em IS NULL`, [clinicaId, publico === false]);
  }

  /* ---------- VIGIA DA EQUIPE ---------- */
  const vg = await um(`SELECT
      (SELECT COUNT(*)::int FROM vigia_ocorrencias WHERE clinica_id=$1 AND status='aberta' AND gravidade='alta') AS graves,
      (SELECT COUNT(*)::int FROM vigia_ocorrencias WHERE clinica_id=$1 AND status='aberta') AS abertas,
      (SELECT COUNT(*)::int FROM vigia_pedidos WHERE clinica_id=$1 AND status='pendente') AS pedidos`).catch(() => null);
  if (vg) {
    const nivel = vg.graves ? 'erro' : (vg.abertas || vg.pedidos) ? 'aviso' : 'ok';
    add('vigia', 'Segurança', nivel, nivel === 'ok' ? 'Vigia da equipe sem alertas' : `Vigia da equipe: ${vg.abertas} alerta(s)${vg.pedidos ? ` e ${vg.pedidos} pedido(s) esperando o seu sim` : ''}`,
      nivel === 'ok' ? 'Nada fora do normal no que a equipe fez.' : `${vg.graves ? vg.graves + ' alerta(s) grave(s). ' : ''}Nada foi bloqueado sozinho. Abra o quadro Vigia da equipe para ver as provas, pedir a opinião da IA ou abrir uma sindicância.`,
      nivel === 'ok' ? null : ir('Abrir o Vigia', { view: 'master', aba: 'Equipe' }));
  }

  /* ---------- BACKUP ---------- */
  const bk = await um(`SELECT MAX(criado_em) AS ultimo, FLOOR(EXTRACT(EPOCH FROM (LOCALTIMESTAMP - MAX(criado_em))) / 86400) AS dias FROM acessos_log WHERE clinica_id=$1 AND area='backup'`);
  const dias = bk.ultimo ? Math.max(0, Number(bk.dias)) : null;
  const autoOn = email.ativo() && !!process.env.BACKUP_EMAIL_PARA && String(process.env.BACKUP_SENHA || '').length >= 8;
  /* v4.9.39: com o backup diário ligado, 2 dias sem backup já é problema */
  const limAviso = autoOn ? 1 : 7, limErro = autoOn ? 2 : 14;
  const falha = await um(`SELECT caminho, criado_em FROM acessos_log WHERE clinica_id=$1 AND area='backup_falha' ORDER BY criado_em DESC LIMIT 1`);
  if (falha && (!bk.ultimo || new Date(falha.criado_em) > new Date(bk.ultimo))) add('backup_falha', 'Backup', 'erro', 'O último backup automático falhou',
    `Motivo: ${falha.caminho}. O sistema tenta de novo a cada 6 horas.`, corrigir('Tentar enviar o backup agora', 'backup_email_agora'));
  add('backup_ultimo', 'Backup', dias === null ? 'erro' : dias > limErro ? 'erro' : dias > limAviso ? 'aviso' : 'ok',
    dias === null ? 'Nenhum backup foi feito' : dias === 0 ? 'Backup feito hoje' : `Último backup há ${dias} dia(s)`,
    dias === null || dias > limAviso ? 'Sem backup recente, uma falha do banco apaga tudo. O banco gratuito não faz cópia sozinho.' : 'Em dia.',
    dias === null || dias > limAviso ? (autoOn ? corrigir('Enviar backup por e-mail agora', 'backup_email_agora') : ir('Baixar backup agora', { view: 'master', aba: 'Segurança', clicar: 'mBackup' })) : null);
  add('backup_auto', 'Backup', autoOn ? 'ok' : 'aviso', autoOn ? 'Backup diário por e-mail ligado' : 'Backup diário por e-mail desligado',
    autoOn ? `Enviado para ${String(process.env.BACKUP_EMAIL_PARA).replace(/(^.).*(@.*$)/, '$1***$2')}, trancado com senha.` : 'Sem ele você depende de lembrar de baixar o backup à mão.',
    autoOn ? corrigir('Testar enviando um backup agora', 'backup_email_agora') : ir('Ligar e-mail e backup', { view: 'master', aba: 'Segurança', clicar: 'mEmailBackup' }));
  const mail = email.ativo();
  add('email', 'Backup', mail ? 'ok' : 'aviso', mail ? 'E-mail do sistema ligado' : 'E-mail do sistema desligado', mail ? 'Recuperação de senha, aviso de aparelho novo e alertas do Guardião funcionam.' : 'Sem e-mail não há recuperação de senha, aviso de aparelho novo, backup diário nem alerta do Guardião.',
    mail ? corrigir('Enviar e-mail de teste', 'email_teste') : ir('Ligar e-mail e backup', { view: 'master', aba: 'Segurança', clicar: 'mEmailBackup' }));
  /* v4.9.39: espaço do banco. O plano grátis da Render tem 1 GB. Depois do plano pago, coloque o tamanho em BANCO_LIMITE_MB. */
  try {
    const tam = Number((await pool.query(`SELECT pg_database_size(current_database()) AS b`)).rows[0].b);
    const limite = (Number(process.env.BANCO_LIMITE_MB) || 1024) * 1048576, pct = Math.round((tam / limite) * 100);
    const mb = (x) => (x / 1048576).toLocaleString('pt-BR', { maximumFractionDigits: 0 });
    add('banco_espaco', 'Backup', pct >= 80 ? 'erro' : pct >= 60 ? 'aviso' : 'ok', `Banco de dados usando ${pct}% do espaço`,
      `${mb(tam)} MB de ${mb(limite)} MB. ${pct >= 80 ? 'Perto do limite: quando enche, o sistema para de gravar. Contrate mais espaço na Render, no banco, em Storage, e coloque o novo tamanho em BANCO_LIMITE_MB.' : pct >= 60 ? 'Ainda cabe, mas vale planejar mais espaço.' : 'Espaço de sobra.'}`);
  } catch (e) { /* sem permissão para medir: não mostra */ }
  if (process.env.BACKUP_SENHA && String(process.env.BACKUP_SENHA).length < 8) add('backup_senha', 'Backup', 'erro', 'Senha do backup curta demais', 'BACKUP_SENHA precisa de 8 caracteres ou mais, senão o backup diário não sai.');

  /* ---------- OPERAÇÃO ---------- */
  const ag = await um(`SELECT COUNT(*)::int AS n FROM agendas WHERE clinica_id=$1 AND ativa AND data BETWEEN CURRENT_DATE AND CURRENT_DATE + 14`);
  add('agendas', 'Operação', ag.n ? 'ok' : 'aviso', ag.n ? 'Há horários abertos nas próximas 2 semanas' : 'Nenhum horário aberto nas próximas 2 semanas',
    ag.n ? `${ag.n} dia(s) de agenda aberta.` : 'Ninguém consegue marcar exame. Abra dias e horários na aba Agenda.', ag.n ? null : ir('Abrir a agenda', { view: 'master', aba: 'Agenda' }));
  const velhos = await um(`SELECT COUNT(*)::int AS n FROM agendamentos WHERE clinica_id=$1 AND status IN ('agendado','confirmado') AND data_hora < NOW() - INTERVAL '1 day'`);
  add('sem_desfecho', 'Operação', velhos.n ? 'aviso' : 'ok', velhos.n ? 'Agendamentos antigos sem desfecho' : 'Todos os agendamentos passados têm desfecho',
    velhos.n ? `${velhos.n} agendamento(s) passaram e continuam como agendado ou confirmado. Marque realizado ou faltou, senão os números do relatório ficam errados.` : 'Nada pendente.', velhos.n ? ir('Ver o resumo do dia', { view: 'relatorio' }) : null);
  const esp = await um(`SELECT COUNT(*)::int AS n FROM lista_espera WHERE clinica_id=$1 AND resolvido_em IS NULL AND criado_em < NOW() - INTERVAL '7 days'`);
  if (esp.n) add('espera', 'Operação', 'aviso', 'Lista de espera parada', `${esp.n} pessoa(s) esperam há mais de 7 dias.`, ir('Abrir a lista de espera', { view: 'espera' }));
  const wa = !!(process.env.WA_TOKEN && process.env.WA_PHONE_ID);
  add('whatsapp', 'Operação', wa ? 'ok' : 'info', wa ? 'WhatsApp automático ligado' : 'WhatsApp automático desligado', wa ? 'Lembretes saem sozinhos.' : 'Faltam WA_TOKEN e WA_PHONE_ID. Enquanto isso a equipe manda os lembretes pelo botão do WhatsApp.');
  const lgpd = await um(`SELECT COUNT(*)::int AS n FROM pacientes WHERE clinica_id=$1 AND deletado_em IS NULL AND termo_lgpd_aceito_em IS NULL`);
  if (lgpd.n) add('lgpd', 'Operação', 'info', 'Pacientes sem aceite do aviso de privacidade', `${lgpd.n} paciente(s) cadastrados pela equipe não têm o aceite registrado. O cadastro pelo link do paciente já registra.`);

  /* ---------- OBRIGAÇÕES ---------- */
  await garantirObrigacoes(clinicaId);
  const autos = { monitor: monitorAtivo(), email: mail, whatsapp: wa };
  for (const o of OBRIGACOES_PADRAO) if (o.auto && autos[o.auto]) await pool.query(`UPDATE assistente_obrigacoes SET feito_em=NOW() WHERE clinica_id=$1 AND codigo=$2 AND feito_em IS NULL`, [clinicaId, o.codigo]);
  if (dias !== null && dias < 7) await pool.query(`UPDATE assistente_obrigacoes SET feito_em=NOW() WHERE clinica_id=$1 AND codigo='backup_manual' AND feito_em IS NULL AND vence_em <= CURRENT_DATE + 7`, [clinicaId]);
  const obr = (await pool.query(`SELECT id, codigo, titulo, detalhe, vence_em::text AS vence_em, repetir_dias, (vence_em - CURRENT_DATE) AS faltam FROM assistente_obrigacoes WHERE clinica_id=$1 AND ativo AND feito_em IS NULL ORDER BY vence_em`, [clinicaId])).rows;
  for (const o of obr) {
    const f = Number(o.faltam);
    const nivel = f < 0 ? 'erro' : f <= 14 ? 'aviso' : 'info';
    const quando = f < 0 ? `venceu há ${-f} dia(s)` : f === 0 ? 'vence hoje' : `vence em ${f} dia(s)`;
    add('obr:' + o.id, 'Obrigações', nivel, o.titulo, `${o.vence_em.split('-').reverse().join('/')}, ${quando}. ${o.detalhe || ''}`, { tipo: 'obrigacao', id: o.id, repete: o.repetir_dias });
  }

  itens.sort((a, b) => NIVEL[b.nivel] - NIVEL[a.nivel]);
  const resumo = { erros: itens.filter((i) => i.nivel === 'erro').length, avisos: itens.filter((i) => i.nivel === 'aviso').length, ok: itens.filter((i) => i.nivel === 'ok').length };
  return { gerado_em: new Date().toISOString(), resumo, itens };
}

/* ---------- CORREÇÕES ---------- */
async function corrigirItem(clinicaId, usuario, id) {
  if (id === 'proteger_dados') {
    const r = await require('./protegerExistentes')({ reescrever: false });
    return { ok: true, mensagem: `Pronto. Protegidos: ${r.prontuarios} prontuário/receita(s), ${r.fotos} foto(s), ${r.cpfs} CPF(s).` };
  }
  if (id === 'aplicar_migracoes') { await require('../db/migrar')(); return { ok: true, mensagem: 'Banco atualizado.' }; }
  if (id === 'backup_email_agora') {
    const b = require('./backupAuto');
    if (!b.ativo()) return { ok: false, mensagem: 'O backup por e-mail ainda não está ligado.' };
    const r = await b.rodarUmaVez(true);
    return r.enviados ? { ok: true, mensagem: 'Backup enviado para o seu e-mail.' } : { ok: false, mensagem: 'Não consegui enviar. Confira os dados do e-mail na Render.' };
  }
  if (id === 'email_teste') {
    const para = process.env.ALERTA_EMAIL_PARA || process.env.BACKUP_EMAIL_PARA || usuario.email;
    if (!para) return { ok: false, mensagem: 'Sem e-mail de destino. Coloque BACKUP_EMAIL_PARA na Render.' };
    const r = await email.enviar({ para, assunto: 'Teste do Guardião da Clínica de Visão', texto: 'Se você recebeu este e-mail, o envio do sistema está funcionando.' });
    return r.ok ? { ok: true, mensagem: 'E-mail de teste enviado.' } : { ok: false, mensagem: 'O e-mail não saiu. Confira os dados SMTP na Render.' };
  }
  if (id === 'desativar_inativos') {
    const r = await pool.query(`UPDATE usuarios u SET ativo=FALSE, sessao_versao=COALESCE(sessao_versao,0)+1 WHERE clinica_id=$1 AND ativo=TRUE AND papel<>'admin' AND criado_em < NOW() - INTERVAL '60 days'
      AND NOT EXISTS (SELECT 1 FROM dispositivos_login d WHERE d.usuario_id=u.id AND d.visto_em > NOW() - INTERVAL '60 days')`, [clinicaId]);
    require('../middleware/auth').limparCacheUsuario();
    return { ok: true, mensagem: `${r.rowCount} usuário(s) desativado(s).` };
  }
  if (id === 'treino_criar') return treinoCriar(clinicaId);
  if (id === 'treino_remover') return treinoRemover(clinicaId);
  return { ok: false, mensagem: 'Correção desconhecida.' };
}

/* ---------- MODO TREINO: pacientes de mentira para a equipe aprender sem medo ---------- */
const NOMES_TREINO = ['Maria Exemplo', 'João Teste', 'Ana Treino', 'Carlos Prática', 'Lúcia Modelo'];
function cpfFalso(n) {
  const d = [(n * 7 + 1) % 10, (n * 3 + 2) % 10, (n * 5 + 3) % 10, (n * 9 + 4) % 10, (n + 5) % 10, (n * 2 + 6) % 10, (n * 4 + 7) % 10, (n * 6 + 8) % 10, (n * 8 + 9) % 10];
  if (d.every((x) => x === d[0])) d[0] = (d[0] + 1) % 10;
  const dv = (arr) => { let s = 0; for (let i = 0; i < arr.length; i++) s += arr[i] * (arr.length + 1 - i); const r = (s * 10) % 11; return r === 10 ? 0 : r; };
  const a = dv(d), b = dv([...d, a]);
  return [...d, a, b].join('');
}
async function treinoCriar(clinicaId) {
  const ja = await pool.query(`SELECT COUNT(*)::int AS n FROM pacientes WHERE clinica_id=$1 AND nome_completo LIKE '[TREINO]%' AND deletado_em IS NULL`, [clinicaId]);
  if (ja.rows[0].n) return { ok: false, mensagem: 'Os pacientes de treino já existem.' };
  const un = (await pool.query(`SELECT id FROM unidades WHERE clinica_id=$1 ORDER BY criado_em LIMIT 1`, [clinicaId])).rows[0];
  let n = 0;
  for (let i = 0; i < NOMES_TREINO.length; i++) {
    const cpf = cpfFalso(i + 1);
    try {
      await pool.query(`INSERT INTO pacientes (clinica_id, unidade_id, nome_completo, cpf, cpf_idx, telefone, agendado_por, data_nascimento) VALUES ($1,$2,$3,$4,$5,$6,'Treino',$7)`,
        [clinicaId, un ? un.id : null, '[TREINO] ' + NOMES_TREINO[i], cripto.cifrar(cpf), cripto.indiceCpf(cpf), '(00) 90000-000' + i, `19${60 + i * 7}-0${i + 1}-1${i}`]);
      n++;
    } catch (e) { /* CPF de treino repetido: ignora */ }
  }
  return { ok: true, mensagem: `${n} pacientes de treino criados. Eles têm [TREINO] no nome. Treine à vontade e depois toque em Remover treino.` };
}
/* apaga o paciente e tudo que depende dele (agendamentos, receitas, prontuários, pagamentos...) */
async function apagarCascata(c, tabela, ids, visto = new Set()) {
  if (!ids.length || visto.has(tabela)) return;
  visto.add(tabela);
  const fks = (await c.query(`SELECT c.conrelid::regclass::text AS filho, a.attname AS coluna FROM pg_constraint c JOIN pg_attribute a ON a.attrelid=c.conrelid AND a.attnum=c.conkey[1]
    WHERE c.contype='f' AND c.confrelid=$1::regclass AND array_length(c.conkey,1)=1`, [tabela])).rows;
  for (const f of fks) {
    if (!/^[a-z_]+$/.test(f.filho) || !/^[a-z_]+$/.test(f.coluna)) continue;
    const temId = (await c.query(`SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name=$1 AND column_name='id'`, [f.filho])).rows.length;
    if (temId) {
      const filhos = (await c.query(`SELECT id FROM ${f.filho} WHERE ${f.coluna} = ANY($1::uuid[])`, [ids])).rows.map((r) => r.id);
      await apagarCascata(c, f.filho, filhos, visto);
    } else await c.query(`DELETE FROM ${f.filho} WHERE ${f.coluna} = ANY($1::uuid[])`, [ids]);
  }
  await c.query(`DELETE FROM ${tabela} WHERE id = ANY($1::uuid[])`, [ids]);
}
async function treinoRemover(clinicaId) {
  const c = await pool.connect();
  try {
    await c.query('BEGIN');
    const ids = (await c.query(`SELECT id FROM pacientes WHERE clinica_id=$1 AND nome_completo LIKE '[TREINO]%'`, [clinicaId])).rows.map((r) => r.id);
    await apagarCascata(c, 'pacientes', ids);
    await c.query('COMMIT');
    return { ok: true, mensagem: ids.length ? `${ids.length} pacientes de treino removidos, com tudo que foi feito neles.` : 'Não havia pacientes de treino.' };
  } catch (e) { await c.query('ROLLBACK'); console.error('Treino:', e.message); return { ok: false, mensagem: 'Não consegui remover o treino.' }; }
  finally { c.release(); }
}

/* ---------- ROTINA ---------- */
async function batimento() {
  await pool.query(`INSERT INTO sistema_batimento (id, visto_em) VALUES (1, NOW()) ON CONFLICT (id) DO UPDATE SET visto_em=NOW()`);
}
async function registrarInicio() {
  const r = (await pool.query(`SELECT EXTRACT(EPOCH FROM (NOW() - visto_em))/60 AS min FROM sistema_batimento WHERE id=1`)).rows[0];
  const min = r ? Math.round(Number(r.min)) : 0;
  await pool.query(`INSERT INTO sistema_reinicios (parado_min) VALUES ($1)`, [min]);
  await batimento();
}

async function limpeza() {
  await pool.query(`DELETE FROM redefinicoes_senha WHERE expira_em < NOW() - INTERVAL '2 days'`).catch(() => {});
  await pool.query(`DELETE FROM login_tentativas WHERE inicio < NOW() - INTERVAL '2 days'`).catch(() => {});
  await pool.query(`DELETE FROM agendamentos_offline WHERE criado_em < NOW() - INTERVAL '90 days'`).catch(() => {});
  await pool.query(`DELETE FROM sistema_reinicios WHERE criado_em < NOW() - INTERVAL '30 days'`).catch(() => {});
  await pool.query(`DELETE FROM assistente_verificacoes WHERE criado_em < NOW() - INTERVAL '60 days'`).catch(() => {});
}

async function rodarRotina() {
  await limpeza();
  const clinicas = (await pool.query(`SELECT id, nome_fantasia FROM clinicas WHERE ativa=TRUE`)).rows;
  for (const c of clinicas) {
    const v = await verificar(c.id);
    const graves = v.itens.filter((i) => i.nivel === 'erro').map((i) => i.id);
    const ant = (await pool.query(`SELECT resumo FROM assistente_verificacoes WHERE clinica_id=$1 ORDER BY criado_em DESC LIMIT 1`, [c.id])).rows[0];
    const antigos = new Set((ant && ant.resumo && ant.resumo.graves) || []);
    const novos = v.itens.filter((i) => i.nivel === 'erro' && !antigos.has(i.id));
    await pool.query(`INSERT INTO assistente_verificacoes (clinica_id, erros, avisos, resumo) VALUES ($1,$2,$3,$4)`, [c.id, v.resumo.erros, v.resumo.avisos, JSON.stringify({ graves })]);
    const para = process.env.ALERTA_EMAIL_PARA || process.env.BACKUP_EMAIL_PARA;
    if (!para || !email.ativo()) continue;
    /* alerta de problema novo */
    if (novos.length) await email.enviar({ para, assunto: `Guardião: ${novos.length} problema(s) novo(s) em ${c.nome_fantasia}`,
      texto: 'O Guardião achou problemas novos:\n\n' + novos.map((i) => `- ${i.titulo}: ${i.detalhe}`).join('\n') + '\n\nEntre no sistema, Master, aba Guardião, para corrigir.' });
    /* lembrete diário de obrigações vencidas ou perto de vencer (no máximo 1 e-mail por dia) */
    const dev = (await pool.query(`SELECT id, titulo, vence_em::text AS vence_em FROM assistente_obrigacoes WHERE clinica_id=$1 AND ativo AND feito_em IS NULL AND vence_em <= CURRENT_DATE + 3
      AND (lembrado_em IS NULL OR lembrado_em < CURRENT_DATE) ORDER BY vence_em`, [c.id])).rows;
    if (dev.length) {
      const r = await email.enviar({ para, assunto: `Guardião: ${dev.length} obrigação(ões) para hoje ou vencida(s)`,
        texto: 'Lembrete das suas obrigações:\n\n' + dev.map((o) => `- ${o.titulo} (${o.vence_em.split('-').reverse().join('/')})`).join('\n') + '\n\nEntre no sistema, Master, aba Guardião.' });
      if (r.ok) await pool.query(`UPDATE assistente_obrigacoes SET lembrado_em=CURRENT_DATE WHERE id = ANY($1::uuid[])`, [dev.map((o) => o.id)]);
    }
  }
}

function iniciar() {
  registrarInicio().catch((e) => console.error('Guardião (início):', e.message));
  setInterval(() => batimento().catch(() => {}), 60 * 1000).unref();
  setTimeout(() => rodarRotina().catch((e) => console.error('Guardião:', e.message)), 3 * 60 * 1000).unref();
  setInterval(() => rodarRotina().catch((e) => console.error('Guardião:', e.message)), 6 * 3600000).unref();
  console.log('Guardião do sistema ligado.');
}

module.exports = { verificar, corrigirItem, iniciar, rodarRotina, registrarPing, monitorAtivo, garantirObrigacoes, iniciouEm };
