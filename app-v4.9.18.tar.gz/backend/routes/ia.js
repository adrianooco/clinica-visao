/* Assistente de textos com IA gratuita (Google Gemini) ou, se não houver, a chave da Anthropic.
   Serve só para texto geral (sem dados de paciente). A leitura de fotos continua em /leitura. */
const express = require('express');
const { exigirLogin } = require('../middleware/auth');

const router = express.Router();
router.use(exigirLogin);

const GEMINI_MODELO = process.env.GEMINI_MODEL || 'gemini-3.5-flash-lite';
const ANTHROPIC_MODELO = process.env.ANTHROPIC_MODEL || 'claude-haiku-4-5-20251001';

function provedor() {
  if (process.env.GEMINI_API_KEY) return 'gemini';
  if (process.env.ANTHROPIC_API_KEY) return 'anthropic';
  return null;
}

/* limite simples por usuário: 40 pedidos por hora, para ficar dentro da cota gratuita */
const usos = new Map();
function dentroDoLimite(id) {
  const agora = Date.now();
  const lista = (usos.get(id) || []).filter((t) => agora - t < 3600000);
  if (lista.length >= 40) { usos.set(id, lista); return false; }
  lista.push(agora); usos.set(id, lista); return true;
}

/* tira o que parece dado pessoal antes de enviar para fora */
function protegerTexto(t) {
  return String(t || '')
    .replace(/\b\d{3}\.?\d{3}\.?\d{3}-?\d{2}\b/g, '[CPF removido]')
    .replace(/[\w.+-]+@[\w-]+\.[\w.-]+/g, '[e-mail removido]')
    .replace(/(\+?55\s?)?\(?\d{2}\)?\s?9?\d{4}[-\s]?\d{4}\b/g, '[telefone removido]');
}

const SISTEMA = 'Você ajuda uma ótica e clínica de exame de vista no Brasil. Responda em português do Brasil, com frases curtas e simples, voz ativa, sem markdown, sem asteriscos, sem hashtags e sem travessões. Não invente dados clínicos. Não dê diagnóstico. Se o pedido for sobre saúde, diga que o profissional responsável decide.';

router.get('/status', (req, res) => {
  const p = provedor();
  res.json({ ligada: !!p, provedor: p, gratuita: p === 'gemini' });
});

router.post('/texto', async (req, res) => {
  const p = provedor();
  if (!p) return res.status(503).json({ erro: 'A IA não está ligada. Falta colocar a chave GEMINI_API_KEY no Render.', semIA: true });
  let pedido = String((req.body || {}).pedido || '').trim().slice(0, 1500);
  if (pedido.length < 4) return res.status(400).json({ erro: 'Escreva o que você quer.' });
  if (!dentroDoLimite(req.usuario.usuarioId)) return res.status(429).json({ erro: 'Muitos pedidos seguidos. Tente de novo mais tarde.' });
  pedido = protegerTexto(pedido);
  try {
    const ctl = new AbortController();
    const timer = setTimeout(() => ctl.abort(), 30000);
    let r, texto = '';
    if (p === 'gemini') {
      r = await fetch((process.env.GEMINI_API_BASE || 'https://generativelanguage.googleapis.com').replace(/\/$/, '') + '/v1beta/models/' + encodeURIComponent(GEMINI_MODELO) + ':generateContent', {
        method: 'POST', signal: ctl.signal,
        headers: { 'content-type': 'application/json', 'x-goog-api-key': process.env.GEMINI_API_KEY },
        body: JSON.stringify({
          systemInstruction: { parts: [{ text: SISTEMA }] },
          contents: [{ role: 'user', parts: [{ text: pedido }] }],
          generationConfig: { maxOutputTokens: 700, temperature: 0.5 },
        }),
      });
      clearTimeout(timer);
      if (!r.ok) { console.error('IA (Gemini) falhou:', r.status); return res.status(r.status === 429 ? 429 : 502).json({ erro: r.status === 429 ? 'O limite gratuito do dia acabou. Tente mais tarde.' : 'Não consegui responder agora. Tente de novo.' }); }
      const d = await r.json();
      texto = ((((d.candidates || [])[0] || {}).content || {}).parts || []).map((x) => x.text || '').join('');
    } else {
      r = await fetch((process.env.ANTHROPIC_API_BASE || 'https://api.anthropic.com').replace(/\/$/, '') + '/v1/messages', {
        method: 'POST', signal: ctl.signal,
        headers: { 'content-type': 'application/json', 'x-api-key': process.env.ANTHROPIC_API_KEY, 'anthropic-version': '2023-06-01' },
        body: JSON.stringify({ model: ANTHROPIC_MODELO, max_tokens: 700, system: SISTEMA, messages: [{ role: 'user', content: pedido }] }),
      });
      clearTimeout(timer);
      if (!r.ok) { console.error('IA (Anthropic) falhou:', r.status); return res.status(502).json({ erro: 'Não consegui responder agora. Tente de novo.' }); }
      const d = await r.json();
      texto = (d.content || []).map((c) => c.text || '').join('');
    }
    texto = texto.replace(/[*#]/g, '').replace(/\s+—\s+/g, ', ').replace(/—/g, ', ').trim();
    if (!texto) return res.status(502).json({ erro: 'A IA não devolveu texto. Tente de novo.' });
    res.json({ ok: true, texto, provedor: p });
  } catch (e) {
    console.error('IA erro:', e.message);
    res.status(502).json({ erro: 'Não consegui responder agora. Tente de novo.' });
  }
});

module.exports = router;
