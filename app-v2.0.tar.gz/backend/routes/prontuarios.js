const express = require('express');
const pool = require('../db/pool');
const { exigirLogin, exigirPermissao } = require('../middleware/auth');

const router = express.Router();
router.use(exigirLogin);
router.use(exigirPermissao('prontuario')); // atendente só com liberação do administradorixo

/* confirma que o paciente existe, é da clínica, e, se o usuário for restrito a
   uma cidade, que o paciente é dessa mesma cidade */
async function pacienteAcessivel(req, pacienteId) {
  const params = [pacienteId, req.usuario.clinicaId];
  let filtro = '';
  if (req.usuario.unidadeId) { params.push(req.usuario.unidadeId); filtro = ' AND unidade_id=$3'; }
  const r = await pool.query(`SELECT id FROM pacientes WHERE id=$1 AND clinica_id=$2 AND deletado_em IS NULL${filtro}`, params);
  return r.rows.length > 0;
}

router.get('/', async (req, res) => {
  const { paciente_id } = req.query;
  if (paciente_id && !(await pacienteAcessivel(req, paciente_id))) {
    return res.status(404).json({ erro: 'Paciente não encontrado.' });
  }
  const params = [req.usuario.clinicaId, paciente_id || null];
  let filtroUnidade = '';
  if (req.usuario.unidadeId) { params.push(req.usuario.unidadeId); filtroUnidade = ` AND p.unidade_id=$3`; }
  const r = await pool.query(
    `SELECT pr.*, u.nome AS profissional_nome FROM prontuarios pr
     JOIN pacientes p ON p.id = pr.paciente_id
     JOIN usuarios u ON u.id = pr.profissional_id
     WHERE pr.clinica_id=$1 AND ($2::uuid IS NULL OR pr.paciente_id=$2)${filtroUnidade}
     ORDER BY pr.data_exame DESC, pr.criado_em DESC`,
    params
  );
  res.json(r.rows);
});

const json = (v) => (v ? JSON.stringify(v) : null);

router.post('/', async (req, res) => {
  const { paciente_id, queixa_principal, sintomas, observacoes_clinicas, conduta, receita_id, data_exame, gabarito_acuidade, refracao, exame, fechar } = req.body;
  if (!paciente_id) return res.status(400).json({ erro: 'Informe o paciente.' });
  if (req.usuario.papel === 'atendente') return res.status(403).json({ erro: 'Só o profissional registra o exame.' });
  if (!(await pacienteAcessivel(req, paciente_id))) {
    return res.status(404).json({ erro: 'Paciente não encontrado.' });
  }
  const r = await pool.query(
    `INSERT INTO prontuarios (clinica_id, paciente_id, profissional_id, data_exame, queixa_principal, sintomas, observacoes_clinicas, conduta, receita_id, gabarito_acuidade, refracao, exame, fechado_em)
     VALUES ($1,$2,$3,COALESCE($4,CURRENT_DATE),$5,$6,$7,$8,$9,$10,$11,$12, CASE WHEN $13 THEN NOW() END) RETURNING *`,
    [req.usuario.clinicaId, paciente_id, req.usuario.usuarioId, data_exame || null,
     queixa_principal || null, json(sintomas), observacoes_clinicas || null, conduta || null, receita_id || null,
     json(gabarito_acuidade), json(refracao), json(exame), fechar === true]
  );
  res.status(201).json(r.rows[0]);
});

/* corrigir um registro: guarda a versão anterior. Registro fechado exige o motivo da correção. */
router.put('/:id', async (req, res) => {
  if (req.usuario.papel === 'atendente') return res.status(403).json({ erro: 'Só o profissional corrige o prontuário.' });
  const { queixa_principal, sintomas, observacoes_clinicas, conduta, receita_id, gabarito_acuidade, refracao, exame, motivo, fechar } = req.body;
  const atual = await pool.query(`SELECT * FROM prontuarios WHERE id=$1 AND clinica_id=$2`, [req.params.id, req.usuario.clinicaId]);
  if (!atual.rows.length) return res.status(404).json({ erro: 'Prontuário não encontrado.' });
  const antes = atual.rows[0];
  if (!(await pacienteAcessivel(req, antes.paciente_id))) return res.status(404).json({ erro: 'Prontuário não encontrado.' });
  if (antes.fechado_em && !String(motivo || '').trim()) return res.status(400).json({ erro: 'Informe o motivo da correção.' });
  await pool.query(
    `INSERT INTO prontuario_versoes (prontuario_id, usuario_id, usuario_nome, motivo, snapshot) VALUES ($1,$2,$3,$4,$5)`,
    [antes.id, req.usuario.usuarioId, req.usuario.nome || null, String(motivo || '').trim() || null, JSON.stringify(antes)]
  );
  const r = await pool.query(
    `UPDATE prontuarios SET queixa_principal=$1, sintomas=$2, observacoes_clinicas=$3, conduta=$4, receita_id=$5, gabarito_acuidade=$6, refracao=$7, exame=$8,
       fechado_em = CASE WHEN $9 THEN COALESCE(fechado_em, NOW()) ELSE fechado_em END
     WHERE id=$10 AND clinica_id=$11 RETURNING *`,
    [queixa_principal || null, json(sintomas), observacoes_clinicas || null, conduta || null, receita_id || null,
     json(gabarito_acuidade), json(refracao), json(exame), fechar === true, req.params.id, req.usuario.clinicaId]
  );
  res.json(r.rows[0]);
});

router.get('/:id/versoes', async (req, res) => {
  const dono = await pool.query(`SELECT paciente_id FROM prontuarios WHERE id=$1 AND clinica_id=$2`, [req.params.id, req.usuario.clinicaId]);
  if (!dono.rows.length || !(await pacienteAcessivel(req, dono.rows[0].paciente_id))) return res.status(404).json({ erro: 'Prontuário não encontrado.' });
  const r = await pool.query(`SELECT id, usuario_nome, motivo, criado_em FROM prontuario_versoes WHERE prontuario_id=$1 ORDER BY criado_em DESC`, [req.params.id]);
  res.json(r.rows);
});

module.exports = router;
