const express = require('express');
const pool = require('../db/pool');
const { exigirLogin, exigirPermissao } = require('../middleware/auth');

const router = express.Router();
router.use(exigirLogin);
router.use(exigirPermissao('receita')); // agendador só acessa se o administrador liberar

/* confirma que o paciente existe, é da clínica, e, se o usuário for restrito a
   uma cidade, que o paciente é dessa mesma cidade */
async function pacienteAcessivel(req, pacienteId) {
  const params = [pacienteId, req.usuario.clinicaId];
  let filtro = '';
  if (req.usuario.unidadeId) { params.push(req.usuario.unidadeId); filtro = ' AND unidade_id=$3'; }
  const r = await pool.query(`SELECT id FROM pacientes WHERE id=$1 AND clinica_id=$2 AND deletado_em IS NULL${filtro}`, params);
  return r.rows.length > 0;
}

router.get('/', async (req, res) => {
  const { paciente_id } = req.query;
  if (paciente_id && !(await pacienteAcessivel(req, paciente_id))) {
    return res.status(404).json({ erro: 'Paciente não encontrado.' });
  }
  // sem paciente_id: lista só as receitas de pacientes que o usuário pode ver (join com o filtro de cidade)
  const params = [req.usuario.clinicaId, paciente_id || null];
  let filtroUnidade = '';
  if (req.usuario.unidadeId) { params.push(req.usuario.unidadeId); filtroUnidade = ` AND p.unidade_id=$3`; }
  const r = await pool.query(
    `SELECT r.*, prof.nome AS profissional_nome, prof.registro_conselho AS profissional_registro,
            prof.carimbo_texto AS profissional_carimbo, prof.assinatura_url AS profissional_assinatura
     FROM receitas r
     JOIN pacientes p ON p.id = r.paciente_id
     LEFT JOIN usuarios prof ON prof.id = r.profissional_id
     WHERE r.clinica_id=$1 AND ($2::uuid IS NULL OR r.paciente_id=$2)${filtroUnidade}
     ORDER BY r.criado_em DESC`,
    params
  );
  res.json(r.rows);
});

router.post('/', async (req, res) => {
  let { paciente_id, idade_paciente, profissional_id, longe, perto, adicao, tipo_lente, tratamentos, cid_codigo, cid_descricao, atestado_texto, declaracao_texto } = req.body;
  if (!paciente_id) return res.status(400).json({ erro: 'Informe o paciente.' });
  if (!(await pacienteAcessivel(req, paciente_id))) {
    return res.status(404).json({ erro: 'Paciente não encontrado.' });
  }
  // se veio profissional_id, confirma que é mesmo um profissional desta clínica
  let profissionalValido = null, ehMedico = false;
  if (profissional_id) {
    const p = await pool.query(`SELECT id, registro_conselho FROM usuarios WHERE id=$1 AND clinica_id=$2 AND papel='profissional'`, [profissional_id, req.usuario.clinicaId]);
    if (p.rows.length) { profissionalValido = profissional_id; ehMedico = /^\s*CRM/i.test(p.rows[0].registro_conselho || ''); }
  }
  // CID é diagnóstico: só entra quando quem assina é médico (CRM)
  if (!ehMedico) { cid_codigo = null; cid_descricao = null; }
  const r = await pool.query(
    `INSERT INTO receitas (clinica_id, paciente_id, usuario_id, profissional_id, idade_paciente, longe, perto, adicao, tipo_lente, tratamentos, cid_codigo, cid_descricao, atestado_texto, declaracao_texto)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14) RETURNING *`,
    [req.usuario.clinicaId, paciente_id, req.usuario.usuarioId, profissionalValido, idade_paciente || null, longe || null, perto || null, adicao || null, tipo_lente || null, tratamentos || null, cid_codigo || null, cid_descricao || null, atestado_texto || null, declaracao_texto || null]
  );
  res.status(201).json(r.rows[0]);
});

module.exports = router;
