const express = require('express');
const { exigirLogin } = require('../middleware/auth');

const router = express.Router();
router.use(exigirLogin);

const MODELO = process.env.ANTHROPIC_MODEL || 'claude-haiku-4-5-20251001';
const BASE = (process.env.ANTHROPIC_API_BASE || 'https://api.anthropic.com').replace(/\/$/, '');

/* limite simples por usuário: 120 leituras por hora */
const usos = new Map();
function dentroDoLimite(id) {
  const agora = Date.now();
  const lista = (usos.get(id) || []).filter((t) => agora - t < 3600000);
  if (lista.length >= 120) { usos.set(id, lista); return false; }
  lista.push(agora); usos.set(id, lista); return true;
}

const PROMPTS = {
  documento: 'A imagem é a foto de um documento brasileiro (RG, CNH ou CPF). Leia só o que está escrito e legível. Responda apenas com um JSON neste formato, sem texto antes ou depois: {"nome_completo": string ou null, "cpf": string só com 11 números ou null, "data_nascimento": "AAAA-MM-DD" ou null}. Se não conseguir ler um campo, use null. Nunca invente.',
  receita: 'A imagem é a foto de uma receita de óculos ou de um papel com o grau do paciente. Leia só o que está escrito e legível. Responda apenas com um JSON neste formato, sem texto antes ou depois: {"od": {"esf": string ou null, "cil": string ou null, "eixo": string ou null, "dnp": string ou null}, "oe": {"esf": string ou null, "cil": string ou null, "eixo": string ou null, "dnp": string ou null}, "adicao": string ou null, "dp": string ou null}. Use o formato com sinal e duas casas, como "-1.25", "+0.50", e eixo só em número, como "90". OD é o olho direito e OE é o olho esquerdo. Se não conseguir ler um campo, use null. Nunca invente.',
  oculos: 'A imagem é a foto de um papel, etiqueta ou aparelho que mostra o grau de óculos (receita, lensômetro ou autorrefrator). Leia só o que está escrito e legível. Responda apenas com um JSON neste formato, sem texto antes ou depois: {"od": {"esf": string ou null, "cil": string ou null, "eixo": string ou null, "dnp": string ou null}, "oe": {"esf": string ou null, "cil": string ou null, "eixo": string ou null, "dnp": string ou null}, "adicao": string ou null, "dp": string ou null}. Use o formato com sinal e duas casas, como "-1.25", "+0.50", e eixo só em número, como "90". OD é o olho direito e OE é o olho esquerdo. Se não conseguir ler um campo, use null. Nunca invente.',
};

function cpfOk(c) {
  c = String(c || '').replace(/\D/g, '');
  if (c.length !== 11 || /^(\d)\1+$/.test(c)) return false;
  for (let t = 9; t < 11; t++) {
    let s = 0;
    for (let i = 0; i < t; i++) s += Number(c[i]) * (t + 1 - i);
    if (((s * 10) % 11) % 10 !== Number(c[t])) return false;
  }
  return true;
}
const txt = (v, max = 120) => (v == null ? null : String(v).replace(/[<>]/g, '').trim().slice(0, max) || null);
function grau(v) {
  if (v == null) return null;
  const n = parseFloat(String(v).replace(',', '.'));
  if (isNaN(n) || Math.abs(n) > 30) return null;
  return (n > 0 ? '+' : '') + n.toFixed(2);
}
function eixo(v) {
  const n = parseInt(String(v == null ? '' : v).replace(/\D/g, ''), 10);
  return isNaN(n) || n < 0 || n > 180 ? null : String(n);
}
function medida(v) {
  const n = parseFloat(String(v == null ? '' : v).replace(',', '.'));
  return isNaN(n) || n <= 0 || n > 90 ? null : String(n);
}
function limparOlho(o) {
  o = o || {};
  return { esf: grau(o.esf), cil: grau(o.cil), eixo: eixo(o.eixo), dnp: medida(o.dnp) };
}

function limparResposta(tipo, j) {
  if (tipo === 'documento') {
    const cpf = String(j.cpf || '').replace(/\D/g, '');
    const nasc = /^\d{4}-\d{2}-\d{2}$/.test(String(j.data_nascimento || '')) ? j.data_nascimento : null;
    return { nome_completo: txt(j.nome_completo), cpf: cpfOk(cpf) ? cpf : null, cpf_ilegivel: !!cpf && !cpfOk(cpf), data_nascimento: nasc };
  }
  const adicao = grau(j.adicao);
  return { od: limparOlho(j.od), oe: limparOlho(j.oe), adicao: adicao && parseFloat(adicao) > 0 ? adicao : null, dp: medida(j.dp) };
}

router.post('/', async (req, res) => {
  const { tipo, imagem } = req.body || {};
  if (!PROMPTS[tipo]) return res.status(400).json({ erro: 'Tipo de leitura inválido.' });
  const m = /^data:(image\/(?:jpeg|png|webp));base64,([A-Za-z0-9+/=]+)$/.exec(String(imagem || ''));
  if (!m) return res.status(400).json({ erro: 'Envie uma foto válida.' });
  if (!process.env.ANTHROPIC_API_KEY) {
    return res.status(503).json({ erro: 'A leitura por IA não está ligada.', semIA: true });
  }
  if (!dentroDoLimite(req.usuario.usuarioId)) return res.status(429).json({ erro: 'Muitas leituras seguidas. Tente de novo mais tarde.' });
  try {
    const ctl = new AbortController();
    const timer = setTimeout(() => ctl.abort(), 45000);
    const r = await fetch(BASE + '/v1/messages', {
      method: 'POST',
      signal: ctl.signal,
      headers: { 'content-type': 'application/json', 'x-api-key': process.env.ANTHROPIC_API_KEY, 'anthropic-version': '2023-06-01' },
      body: JSON.stringify({
        model: MODELO,
        max_tokens: 600,
        messages: [{ role: 'user', content: [
          { type: 'image', source: { type: 'base64', media_type: m[1], data: m[2] } },
          { type: 'text', text: PROMPTS[tipo] },
        ] }],
      }),
    });
    clearTimeout(timer);
    if (!r.ok) {
      console.error('Leitura por IA falhou:', r.status);
      return res.status(502).json({ erro: 'Não consegui ler a foto agora. Digite os dados ou tente de novo.' });
    }
    const d = await r.json();
    const texto = (d.content || []).map((c) => c.text || '').join('');
    const bruto = /\{[\s\S]*\}/.exec(texto);
    if (!bruto) return res.status(422).json({ erro: 'Não consegui ler essa foto. Tente com mais luz e a imagem reta.' });
    let j;
    try { j = JSON.parse(bruto[0]); } catch (e) { return res.status(422).json({ erro: 'Não consegui ler essa foto. Tente com mais luz e a imagem reta.' }); }
    res.json({ ok: true, tipo, dados: limparResposta(tipo, j) });
  } catch (e) {
    console.error('Leitura por IA erro:', e.message);
    res.status(502).json({ erro: 'Não consegui ler a foto agora. Digite os dados ou tente de novo.' });
  }
});

module.exports = router;
