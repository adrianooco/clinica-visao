require('dotenv').config();
const express = require('express');
require('express-async-errors'); // erro dentro de rota assíncrona vira resposta 500, em vez de deixar o pedido travado
const cors = require('cors');
const path = require('path');

// no ar, sem segredo próprio qualquer pessoa conseguiria forjar um login: não deixa ligar
if (process.env.NODE_ENV === 'production' && !process.env.JWT_SECRET) {
  console.error('ERRO: defina a variável JWT_SECRET antes de ligar o sistema no ar.');
  process.exit(1);
}

const app = express();
app.set('trust proxy', 1); // atrás do Render/Railway, pra enxergar o IP real de quem acessa
app.disable('x-powered-by');
app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'same-origin');
  res.setHeader('X-Frame-Options', 'SAMEORIGIN');
  res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
  if (process.env.NODE_ENV === 'production') res.setHeader('Strict-Transport-Security', 'max-age=31536000');
  res.setHeader('Content-Security-Policy', "default-src 'self'; script-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net; worker-src 'self' blob:; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com data:; img-src 'self' data: blob: https:; connect-src 'self' https://viacep.com.br https://cdn.jsdelivr.net https://tessdata.projectnaptha.com; object-src 'none'; base-uri 'self'; form-action 'self'; frame-ancestors 'self'");
  next();
});
/* CORS: no ar, só o próprio endereço do sistema (e os que você listar em CORS_ORIGENS, separados por vírgula) */
const origensLiberadas = (process.env.CORS_ORIGENS || '').split(',').map((x) => x.trim()).filter(Boolean);
app.use(cors({
  origin: (origem, cb) => {
    if (!origem || process.env.NODE_ENV !== 'production') return cb(null, true);
    cb(null, origensLiberadas.includes(origem) || origem === process.env.URL_PUBLICA);
  },
}));
app.use(express.json({ limit: '8mb', verify: (req, res, buf) => { req.rawBody = buf; } })); // fotos em base64 podem ser grandes; rawBody confere a assinatura do WhatsApp

/* Defesa contra código escondido em texto (XSS): tira os sinais < e > de todo texto que chega.
   Vale para o cadastro público e para a equipe. */
function limparTexto(v) {
  if (typeof v === 'string') return v.replace(/[<>]/g, '');
  if (Array.isArray(v)) return v.map(limparTexto);
  if (v && typeof v === 'object') { const o = {}; for (const k of Object.keys(v)) o[k] = limparTexto(v[k]); return o; }
  return v;
}
app.use((req, res, next) => { if (req.body && typeof req.body === 'object') req.body = limparTexto(req.body); next(); });

/* Freio no cadastro público: no máximo 30 envios por hora por aparelho (evita lixo e abuso). */
const enviosPublicos = new Map();
app.use('/public', (req, res, next) => {
  if (req.method !== 'POST') return next();
  const agora = Date.now(), t = enviosPublicos.get(req.ip);
  if (!t || agora - t.inicio > 3600000) enviosPublicos.set(req.ip, { inicio: agora, n: 1 });
  else if (++t.n > 30) return res.status(429).json({ erro: 'Muitos envios seguidos. Tente de novo mais tarde.' });
  next();
});
setInterval(() => { const a = Date.now(); for (const [k, t] of enviosPublicos) if (a - t.inicio > 3600000) enviosPublicos.delete(k); }, 600000).unref();

/* Versão do sistema: vem dos arquivos VERSION e versoes.json do pacote */
const fs = require('fs');
function lerVersao() {
  const raiz = path.join(__dirname, '..');
  let versao = '?', historico = [];
  try { versao = fs.readFileSync(path.join(raiz, 'VERSION'), 'utf8').trim(); } catch (e) {}
  try { historico = JSON.parse(fs.readFileSync(path.join(raiz, 'versoes.json'), 'utf8')); } catch (e) {}
  return { versao, historico };
}
const VERSAO_ATUAL = lerVersao();
app.get('/health', (req, res) => res.json({ ok: true, versao: VERSAO_ATUAL.versao }));
app.get('/versao', (req, res) => { res.setHeader('Cache-Control', 'no-cache'); res.json(VERSAO_ATUAL); });

/* Páginas do sistema: o próprio servidor entrega, então quem abre o endereço já cai na tela de login.
   Só estes arquivos são públicos (nunca a pasta inteira, pra não expor o .env). */
const RAIZ = path.join(__dirname, '..');
const PAGINAS = ['modulo-agendamento.html', 'cadastro-paciente.html', 'teste-visao.html', 'optotipo.js', 'qrcode.js', 'clinica.ico'];
app.get('/', (req, res) => res.redirect('/modulo-agendamento.html'));
PAGINAS.forEach((f) => app.get('/' + f, (req, res, next) => {
  res.setHeader('Cache-Control', 'no-cache');
  res.sendFile(path.join(RAIZ, f), (err) => err && next());
}));

app.use('/whatsapp', require('./routes/whatsappWebhook'));
app.use('/auth', require('./routes/auth'));
app.use('/public', require('./routes/public'));
app.use('/integracao/:slug', require('./routes/integracao'));
app.use('/pacientes', require('./routes/pacientes'));
app.use('/agendamentos', require('./routes/agendamentos'));
app.use('/agendas', require('./routes/agendas'));
app.use('/envios', require('./routes/envios'));
app.use('/cadastros', require('./routes/cadastros'));
app.use('/financeiro', require('./routes/financeiro'));
app.use('/tipos-atendimento', require('./routes/tiposAtendimento'));
app.use('/unidades', require('./routes/unidades'));
app.use('/receitas', require('./routes/receitas'));
app.use('/prontuarios', require('./routes/prontuarios'));
app.use('/leitura', require('./routes/leitura'));
app.use('/testes-visao', require('./routes/testesVisao'));
app.use('/clinica', require('./routes/clinica'));
app.use('/relatorios', require('./routes/relatorios'));
app.use('/optotipo', require('./routes/optotipo'));

app.use((req, res) => res.status(404).json({ erro: 'Rota não encontrada.' }));
app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ erro: 'Erro interno do servidor.' });
});

// um erro numa rota não pode derrubar o sistema inteiro
process.on('unhandledRejection', (e) => console.error('Erro não tratado:', e));

const PORTA = process.env.PORT || 3000;
require('./db/migrar')()
  .catch((e) => console.error('Aviso: não consegui ajustar o banco automaticamente.', e.message))
  .finally(() => app.listen(PORTA, () => { console.log(`API da agenda, versão ${VERSAO_ATUAL.versao}, rodando na porta ${PORTA}`); require('./utils/lembretes').iniciar(); }));
