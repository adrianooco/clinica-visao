const express = require('express');
const pool = require('../db/pool');
const { exigirLogin, exigirAdmin } = require('../middleware/auth');

const router = express.Router();
router.use(exigirLogin);
router.use(exigirAdmin); // comissão é dinheiro da clínica: só administrador
router.use((req, res, next) => {
  if (req.usuario.unidadeId) return res.status(403).json({ erro: 'As comissões só abrem para o administrador geral.' });
  next();
});

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const DATA = /^\d{4}-\d{2}-\d{2}$/;
const dinheiro = (v) => { if (v === '' || v == null) return null; const n = Number(String(v).replace(/\./g, '').replace(',', '.')); return isFinite(n) ? Math.round(n * 100) / 100 : NaN; };
const hoje = () => new Date(Date.now() - 3 * 3600000).toISOString().slice(0, 10);
const dataOk = (d) => DATA.test(String(d || '')) && !isNaN(new Date(d + 'T12:00:00Z'));

function periodo(req) {
  const h = hoje();
  return [DATA.test(req.query.de || '') ? req.query.de : h.slice(0, 8) + '01', DATA.test(req.query.ate || '') ? req.query.ate : h];
}

router.get('/config', async (req, res) => {
  const r = await pool.query(`SELECT comissao_opcao_a, comissao_opcao_b, pos_oculos_dias FROM clinicas WHERE id=$1`, [req.usuario.clinicaId]);
  const c = r.rows[0] || {};
  res.json({ opcao_a: Number(c.comissao_opcao_a ?? 25), opcao_b: Number(c.comissao_opcao_b ?? 50), pos_dias: Number(c.pos_oculos_dias ?? 20) });
});

router.put('/config', async (req, res) => {
  const a = dinheiro(req.body.opcao_a), b = dinheiro(req.body.opcao_b), d = parseInt(req.body.pos_dias, 10);
  if (!(a >= 0 && a <= 1000) || !(b >= 0 && b <= 1000)) return res.status(400).json({ erro: 'Comissão inválida. Use valores entre 0 e 1.000.' });
  if (!(d >= 1 && d <= 120)) return res.status(400).json({ erro: 'Os dias do retorno ficam entre 1 e 120.' });
  await pool.query(`UPDATE clinicas SET comissao_opcao_a=$1, comissao_opcao_b=$2, pos_oculos_dias=$3 WHERE id=$4`, [a, b, d, req.usuario.clinicaId]);
  res.json({ ok: true });
});

/* exames feitos que vieram de um agendador e ainda não têm venda marcada */
router.get('/candidatos', async (req, res) => {
  const [de, ate] = periodo(req);
  const r = await pool.query(
    `SELECT a.id AS agendamento_id, a.data_hora, a.status, p.nome_completo AS paciente_nome, un.nome AS unidade_nome,
            u.id AS agendador_id, u.nome AS agendador_nome
     FROM agendamentos a
     JOIN pacientes p ON p.id = a.paciente_id
     JOIN usuarios u ON u.id = a.usuario_id AND u.papel = 'atendente'
     LEFT JOIN unidades un ON un.id = a.unidade_id
     LEFT JOIN vendas_oculos v ON v.agendamento_id = a.id
     WHERE a.clinica_id=$1 AND v.id IS NULL AND a.status NOT IN ('cancelado','faltou')
       AND a.data_hora::date BETWEEN $2 AND $3 AND a.data_hora < (NOW() AT TIME ZONE 'America/Sao_Paulo') + INTERVAL '1 day'
     ORDER BY a.data_hora DESC LIMIT 400`, [req.usuario.clinicaId, de, ate]);
  res.json({ de, ate, itens: r.rows });
});

/* marca que o paciente comprou óculos */
router.post('/', async (req, res) => {
  const { agendamento_id, observacoes } = req.body || {};
  const comissao = dinheiro(req.body.comissao), valor = dinheiro(req.body.valor_venda);
  if (!UUID.test(String(agendamento_id || ''))) return res.status(400).json({ erro: 'Escolha o atendimento.' });
  if (!(comissao >= 0 && comissao <= 1000)) return res.status(400).json({ erro: 'Informe a comissão. Use valores entre 0 e 1.000.' });
  if (valor !== null && !(valor >= 0 && valor <= 200000)) return res.status(400).json({ erro: 'Valor da venda inválido.' });
  const vendido = req.body.vendido_em ? req.body.vendido_em : hoje();
  const entregue = req.body.entregue_em || null;
  if (!dataOk(vendido) || (entregue && !dataOk(entregue))) return res.status(400).json({ erro: 'Data inválida.' });
  const ag = await pool.query(
    `SELECT a.id, a.paciente_id, a.unidade_id, a.usuario_id, u.nome AS agendador_nome, u.papel
     FROM agendamentos a LEFT JOIN usuarios u ON u.id = a.usuario_id WHERE a.id=$1 AND a.clinica_id=$2`, [agendamento_id, req.usuario.clinicaId]);
  if (!ag.rows.length) return res.status(404).json({ erro: 'Atendimento não encontrado.' });
  const a = ag.rows[0];
  if (a.papel !== 'atendente') return res.status(400).json({ erro: 'Esse atendimento não foi marcado por um agendador.' });
  try {
    const r = await pool.query(
      `INSERT INTO vendas_oculos (clinica_id, unidade_id, paciente_id, agendamento_id, agendador_id, agendador_nome, valor_venda, comissao, vendido_em, entregue_em, observacoes, criado_por_nome)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12) RETURNING id`,
      [req.usuario.clinicaId, a.unidade_id, a.paciente_id, a.id, a.usuario_id, a.agendador_nome, valor, comissao, vendido, entregue, String(observacoes || '').slice(0, 500) || null, req.usuario.nome || null]);
    res.status(201).json({ id: r.rows[0].id });
  } catch (e) {
    if (e.code === '23505') return res.status(409).json({ erro: 'Essa venda já foi marcada.' });
    throw e;
  }
});

const COLUNAS = `v.id, v.valor_venda::float AS valor_venda, v.comissao::float AS comissao, v.comissao_paga, v.comissao_paga_em, v.vendido_em, v.entregue_em, v.observacoes,
  v.agendador_id, v.agendador_nome, v.pos_enviado, v.pos_enviado_em, v.pos_resposta, v.pos_resposta_em, v.pos_situacao, v.pos_obs,
  p.nome_completo AS paciente_nome, p.telefone, un.nome AS unidade_nome`;

router.get('/', async (req, res) => {
  const [de, ate] = periodo(req);
  const params = [req.usuario.clinicaId, de, ate];
  let filtro = '';
  if (req.query.agendador_id && UUID.test(req.query.agendador_id)) { params.push(req.query.agendador_id); filtro += ` AND v.agendador_id=$${params.length}`; }
  if (req.query.pago === 'sim') filtro += ' AND v.comissao_paga'; else if (req.query.pago === 'nao') filtro += ' AND NOT v.comissao_paga';
  const r = await pool.query(
    `SELECT ${COLUNAS} FROM vendas_oculos v JOIN pacientes p ON p.id = v.paciente_id LEFT JOIN unidades un ON un.id = v.unidade_id
     WHERE v.clinica_id=$1 AND v.vendido_em BETWEEN $2 AND $3${filtro} ORDER BY v.vendido_em DESC, v.criado_em DESC LIMIT 500`, params);
  res.json({ de, ate, itens: r.rows });
});

router.get('/resumo', async (req, res) => {
  const [de, ate] = periodo(req);
  const r = await pool.query(
    `SELECT COALESCE(v.agendador_nome,'sem nome') AS nome, v.agendador_id, COUNT(*)::int AS vendas,
            COALESCE(SUM(v.valor_venda),0)::float AS vendido, COALESCE(SUM(v.comissao),0)::float AS comissao,
            COALESCE(SUM(v.comissao) FILTER (WHERE v.comissao_paga),0)::float AS paga,
            COALESCE(SUM(v.comissao) FILTER (WHERE NOT v.comissao_paga),0)::float AS a_pagar
     FROM vendas_oculos v WHERE v.clinica_id=$1 AND v.vendido_em BETWEEN $2 AND $3 GROUP BY 1,2 ORDER BY 6 DESC`, [req.usuario.clinicaId, de, ate]);
  const t = r.rows.reduce((o, x) => ({ vendas: o.vendas + x.vendas, vendido: o.vendido + x.vendido, comissao: o.comissao + x.comissao, paga: o.paga + x.paga, a_pagar: o.a_pagar + x.a_pagar }), { vendas: 0, vendido: 0, comissao: 0, paga: 0, a_pagar: 0 });
  res.json({ de, ate, por_agendador: r.rows, total: t });
});

async function vendaDaClinica(req, res) {
  if (!UUID.test(req.params.id)) { res.status(400).json({ erro: 'Venda inválida.' }); return null; }
  const r = await pool.query(`SELECT id, comissao_paga FROM vendas_oculos WHERE id=$1 AND clinica_id=$2`, [req.params.id, req.usuario.clinicaId]);
  if (!r.rows.length) { res.status(404).json({ erro: 'Venda não encontrada.' }); return null; }
  return r.rows[0];
}

/* muda comissão, valor e datas (só enquanto a comissão não foi paga) */
router.put('/:id', async (req, res) => {
  const v = await vendaDaClinica(req, res); if (!v) return;
  if (v.comissao_paga) return res.status(409).json({ erro: 'Comissão já paga. Desfaça o pagamento antes de mudar.' });
  const comissao = dinheiro(req.body.comissao), valor = dinheiro(req.body.valor_venda);
  if (!(comissao >= 0 && comissao <= 1000)) return res.status(400).json({ erro: 'Comissão inválida.' });
  if (valor !== null && !(valor >= 0 && valor <= 200000)) return res.status(400).json({ erro: 'Valor da venda inválido.' });
  const vendido = req.body.vendido_em || hoje(), entregue = req.body.entregue_em || null;
  if (!dataOk(vendido) || (entregue && !dataOk(entregue))) return res.status(400).json({ erro: 'Data inválida.' });
  await pool.query(`UPDATE vendas_oculos SET comissao=$1, valor_venda=$2, vendido_em=$3, entregue_em=$4, observacoes=$5 WHERE id=$6`,
    [comissao, valor, vendido, entregue, String(req.body.observacoes || '').slice(0, 500) || null, v.id]);
  res.json({ ok: true });
});

router.patch('/:id/pagar', async (req, res) => {
  const v = await vendaDaClinica(req, res); if (!v) return;
  const pagar = req.body.pago !== false;
  await pool.query(`UPDATE vendas_oculos SET comissao_paga=$1::boolean, comissao_paga_em=CASE WHEN $1::boolean THEN CURRENT_DATE END WHERE id=$2`, [pagar, v.id]);
  res.json({ ok: true });
});

/* paga todas as comissões em aberto de um agendador no período */
router.post('/pagar-agendador', async (req, res) => {
  const { agendador_id } = req.body || {};
  if (!UUID.test(String(agendador_id || ''))) return res.status(400).json({ erro: 'Escolha o agendador.' });
  const [de, ate] = [DATA.test(req.body.de || '') ? req.body.de : '2000-01-01', DATA.test(req.body.ate || '') ? req.body.ate : '2999-12-31'];
  const r = await pool.query(`UPDATE vendas_oculos SET comissao_paga=TRUE, comissao_paga_em=CURRENT_DATE WHERE clinica_id=$1 AND agendador_id=$2 AND NOT comissao_paga AND vendido_em BETWEEN $3 AND $4 RETURNING comissao`,
    [req.usuario.clinicaId, agendador_id, de, ate]);
  res.json({ ok: true, quantidade: r.rows.length, total: r.rows.reduce((t, x) => t + Number(x.comissao), 0) });
});

/* como o óculos está: resposta do contato depois dos dias combinados */
router.patch('/:id/retorno', async (req, res) => {
  const v = await vendaDaClinica(req, res); if (!v) return;
  const sit = req.body.situacao === 'ok' || req.body.situacao === 'problema' ? req.body.situacao : null;
  await pool.query(`UPDATE vendas_oculos SET pos_situacao=$1, pos_obs=$2 WHERE id=$3`, [sit, String(req.body.obs || '').slice(0, 500) || null, v.id]);
  res.json({ ok: true });
});

router.delete('/:id', async (req, res) => {
  const v = await vendaDaClinica(req, res); if (!v) return;
  if (v.comissao_paga) return res.status(409).json({ erro: 'Comissão já paga. Desfaça o pagamento antes de apagar.' });
  await pool.query(`DELETE FROM vendas_oculos WHERE id=$1`, [v.id]);
  res.json({ ok: true });
});

module.exports = router;
