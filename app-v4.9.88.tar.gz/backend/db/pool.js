const { Pool, types } = require('pg');

// colunas DATE chegam como texto 'AAAA-MM-DD' (sem virar Date e sem erro de fuso horário)
types.setTypeParser(1082, (v) => v);
// TIMESTAMP sem fuso também chega como texto 'AAAA-MM-DDTHH:MM:SS', pra o horário marcado aparecer igual em qualquer computador
types.setTypeParser(1114, (v) => v.replace(' ', 'T'));

// Em produção, defina DATABASE_URL (ex: fornecida pelo Railway/Render/Supabase).
// Em desenvolvimento local, cai nas variáveis PG* abaixo.
const pool = new Pool(
  process.env.DATABASE_URL
    ? { connectionString: process.env.DATABASE_URL, ssl: process.env.PGSSL === 'false' ? false : { rejectUnauthorized: false } }
    : {
        host: process.env.PGHOST || 'localhost',
        port: process.env.PGPORT || 5432,
        user: process.env.PGUSER || 'postgres',
        password: process.env.PGPASSWORD || 'postgres',
        database: process.env.PGDATABASE || 'agenda_teste',
      }
);

/* Se o banco derrubar uma conexão parada (reinício ou manutenção da Render), o sistema não pode cair junto.
   O pool descarta a conexão quebrada e abre outra no próximo pedido. */
pool.on('error', (e) => console.error('Banco: conexão parada caiu e foi descartada:', e.message));
module.exports = pool;
