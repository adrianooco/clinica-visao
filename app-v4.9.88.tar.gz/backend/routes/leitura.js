const express = require('express');
const { exigirLogin } = require('../middleware/auth');

const router = express.Router();
router.use(exigirLogin);

const MODELO = process.env.ANTHROPIC_MODEL || 'claude-haiku-4-5-20251001';
const BASE = (process.env.ANTHROPIC_API_BASE || 'https://api.anthropic.com').replace(/\/$/, '');

/* limite simples por usuário: 120 leituras por hora */
const usos = new Map();
function dentroDoLimite(id) {
  const agora = Date.now();
  const lista = (usos.get(id) || []).filter((t) => agora - t < 3600000);
  if (lista.length >= 120) { usos.set(id, lista); return false; }
  lista.push(agora); usos.set(id, lista); return true;
}

const PROMPTS = {
  /* v4.9.75: ficha de cadastro em papel (escrita à mão ou impressa) */
  ficha: 'A imagem é a foto de uma ficha de cadastro de paciente, escrita à mão ou impressa (ficha de ótica ou de clínica de exame de vista). Leia só o que está escrito e legível; se não der para ler um campo, use null. Nunca invente. Se a ficha tiver SETOR, é o bairro. CEL é o celular. NAS é a data de nascimento. Letra de mão: leia com cuidado cada número do CPF e do celular. Responda apenas com um JSON neste formato, sem texto antes ou depois: {"nome_completo": string ou null, "cpf": string só com números ou null, "data_nascimento": "AAAA-MM-DD" ou null, "telefone": string só com números, com DDD, ou null, "cep": string só com números ou null, "endereco": string com rua e número ou null, "bairro": string ou null, "cidade": string ou null, "responsavel": nome do responsável, string ou null, "pai": nome do pai ou null, "mae": nome da mãe ou null, "rg": string ou null, "estado_civil": string ou null, "od": {"esf": string ou null, "cil": string ou null, "eixo": string ou null, "dnp": string ou null} ou null, "oe": {"esf": string ou null, "cil": string ou null, "eixo": string ou null, "dnp": string ou null} ou null, "adicao": string ou null}',
  documento: 'A imagem é a foto de um documento brasileiro (RG, CNH ou CPF). Leia só o que está escrito e legível. Responda apenas com um JSON neste formato, sem texto antes ou depois: {"nome_completo": string ou null, "cpf": string só com 11 números ou null, "data_nascimento": "AAAA-MM-DD" ou null, "mae": nome da mãe escrito na filiação ou null, "pai": nome do pai escrito na filiação ou null}. Se não conseguir ler um campo, use null. Nunca invente.',
  receita: 'A imagem é a foto de uma receita de óculos ou de um papel com o grau do paciente. Leia só o que está escrito e legível. Responda apenas com um JSON neste formato, sem texto antes ou depois: {"od": {"esf": string ou null, "cil": string ou null, "eixo": string ou null, "dnp": string ou null}, "oe": {"esf": string ou null, "cil": string ou null, "eixo": string ou null, "dnp": string ou null}, "adicao": string ou null, "dp": string ou null}. Use o formato com sinal e duas casas, como "-1.25", "+0.50", e eixo só em número, como "90". OD é o olho direito e OE é o olho esquerdo. Se não conseguir ler um campo, use null. Nunca invente.',
  oculos: 'A imagem é a foto de um papel, etiqueta ou aparelho que mostra o grau de óculos (receita, lensômetro ou autorrefrator). Leia só o que está escrito e legível. Responda apenas com um JSON neste formato, sem texto antes ou depois: {"od": {"esf": string ou null, "cil": string ou null, "eixo": string ou null, "dnp": string ou null}, "oe": {"esf": string ou null, "cil": string ou null, "eixo": string ou null, "dnp": string ou null}, "adicao": string ou null, "dp": string ou null}. Use o formato com sinal e duas casas, como "-1.25", "+0.50", e eixo só em número, como "90". OD é o olho direito e OE é o olho esquerdo. Se não conseguir ler um campo, use null. Nunca invente.',
};

function cpfOk(c) {
  c = String(c || '').replace(/\D/g, '');
  if (c.length !== 11 || /^(\d)\1+$/.test(c)) return false;
  for (let t = 9; t < 11; t++) {
    let s = 0;
    for (let i = 0; i < t; i++) s += Number(c[i]) * (t + 1 - i);
    if (((s * 10) % 11) % 10 !== Number(c[t])) return false;
  }
  return true;
}
const txt = (v, max = 120) => (v == null ? null : String(v).replace(/[<>]/g, '').trim().slice(0, max) || null);
function grau(v) {
  if (v == null) return null;
  const n = parseFloat(String(v).replace(',', '.'));
  if (isNaN(n) || Math.abs(n) > 30) return null;
  return (n > 0 ? '+' : '') + n.toFixed(2);
}
function eixo(v) {
  const n = parseInt(String(v == null ? '' : v).replace(/\D/g, ''), 10);
  return isNaN(n) || n < 0 || n > 180 ? null : String(n);
}
function medida(v) {
  const n = parseFloat(String(v == null ? '' : v).replace(',', '.'));
  return isNaN(n) || n <= 0 || n > 90 ? null : String(n);
}
function limparOlho(o) {
  o = o || {};
  return { esf: grau(o.esf), cil: grau(o.cil), eixo: eixo(o.eixo), dnp: medida(o.dnp) };
}

function limparResposta(tipo, j) {
  if (tipo === 'ficha') {
    const doc = limparResposta('documento', j);
    let tel = String(j.telefone || '').replace(/\D/g, ''); if (tel.startsWith('55') && tel.length >= 12) tel = tel.slice(2);
    const cep = String(j.cep || '').replace(/\D/g, '');
    const od = limparOlho(j.od), oe = limparOlho(j.oe), ad = grau(j.adicao);
    const temGrau = [od.esf, od.cil, oe.esf, oe.cil].some(Boolean);
    return { ...doc, telefone: [10, 11].includes(tel.length) ? tel : null, cep: cep.length === 8 ? cep : null,
      endereco: txt(j.endereco), bairro: txt(j.bairro, 80), cidade: txt(j.cidade, 80), responsavel: (txt(j.mae, 120) && txt(j.pai, 120)) ? `${txt(j.mae, 120)} (mãe) e ${txt(j.pai, 120)} (pai)` : (txt(j.mae, 120) || txt(j.pai, 120) || txt(j.responsavel, 120) || doc.responsavel),
      rg: txt(j.rg, 30), estado_civil: txt(j.estado_civil, 40),
      receita: temGrau ? { od, oe, adicao: ad && parseFloat(ad) > 0 ? ad : null, dp: null } : null };
  }
  if (tipo === 'documento') {
    const cpf = String(j.cpf || '').replace(/\D/g, '');
    const nasc = /^\d{4}-\d{2}-\d{2}$/.test(String(j.data_nascimento || '')) ? j.data_nascimento : null;
    return { nome_completo: txt(j.nome_completo), cpf: cpfOk(cpf) ? cpf : null, cpf_ilegivel: !!cpf && !cpfOk(cpf), data_nascimento: nasc, responsavel: txt(j.mae, 120) || txt(j.pai, 120) || null }; /* v4.9.77: filiação */
  }
  const adicao = grau(j.adicao);
  return { od: limparOlho(j.od), oe: limparOlho(j.oe), adicao: adicao && parseFloat(adicao) > 0 ? adicao : null, dp: medida(j.dp) };
}

router.post('/', async (req, res) => {
  const { tipo, imagem } = req.body || {};
  if (!PROMPTS[tipo]) return res.status(400).json({ erro: 'Tipo de leitura inválido.' });
  const m = /^data:(image\/(?:jpeg|png|webp));base64,([A-Za-z0-9+/=]+)$/.exec(String(imagem || ''));
  if (!m) return res.status(400).json({ erro: 'Envie uma foto válida.' });
  const ia = require('./ia');
  if (!ia.provedorFoto()) {
    return res.status(503).json({ erro: 'A leitura por IA não está ligada.', semIA: true });
  }
  if (!dentroDoLimite(req.usuario.usuarioId)) return res.status(429).json({ erro: 'Muitas leituras seguidas. Tente de novo mais tarde.' });
  try {
    let texto;
    try { texto = await ia.chamarIAImagem(null, PROMPTS[tipo], m[1], m[2], false, 600); }
    catch (e) {
      console.error('Leitura por IA falhou:', e.status || e.message);
      return res.status(502).json({ erro: 'Não consegui ler a foto agora. Digite os dados ou tente de novo.' });
    }
    const bruto = /\{[\s\S]*\}/.exec(texto);
    if (!bruto) return res.status(422).json({ erro: 'Não consegui ler essa foto. Tente com mais luz e a imagem reta.' });
    let j;
    try { j = JSON.parse(bruto[0]); } catch (e) { return res.status(422).json({ erro: 'Não consegui ler essa foto. Tente com mais luz e a imagem reta.' }); }
    res.json({ ok: true, tipo, dados: limparResposta(tipo, j) });
  } catch (e) {
    console.error('Leitura por IA erro:', e.message);
    res.status(502).json({ erro: 'Não consegui ler a foto agora. Digite os dados ou tente de novo.' });
  }
});

/* v4.9.80: texto que sai do lensômetro pelo cabo (ou colado). Só números de grau, sem dado do cliente.
   Primeiro o próprio sistema tenta ler; se não conseguir, a IA paga lê o texto. */
router.post('/texto', async (req, res) => {
  const bruto = String((req.body || {}).texto || '').replace(/[^\x20-\x7E\n\r\tºª°±−]/g, ' ').slice(0, 3000);
  if (bruto.trim().length < 6) return res.status(400).json({ erro: 'Texto do lensômetro vazio.' });
  const ia = require('./ia');
  if (!ia.provedorFoto()) return res.status(503).json({ erro: 'A leitura por IA não está ligada.', semIA: true });
  if (!dentroDoLimite(req.usuario.usuarioId)) return res.status(429).json({ erro: 'Muitas leituras seguidas. Tente de novo mais tarde.' });
  try {
    const pedido = PROMPTS.oculos.replace('A imagem é a foto de um papel, etiqueta ou aparelho que mostra', 'O texto abaixo saiu de um lensômetro automático e mostra') + '\n\nTEXTO DO APARELHO:\n' + bruto;
    const texto = await ia.chamarIAImagem(null, pedido, [], null, false, 600);
    const m = /\{[\s\S]*\}/.exec(texto || '');
    if (!m) return res.status(422).json({ erro: 'Não consegui ler esse texto.' });
    res.json({ ok: true, tipo: 'oculos', dados: limparResposta('oculos', JSON.parse(m[0])) });
  } catch (e) {
    console.error('Leitura de texto do lensômetro falhou:', e.status || e.message);
    res.status(502).json({ erro: 'Não consegui ler agora. Digite o grau ou tente de novo.' });
  }
});

module.exports = router;
