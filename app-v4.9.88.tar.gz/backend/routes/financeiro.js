const express = require('express');
const pool = require('../db/pool');
const { exigirLogin, exigirAdmin } = require('../middleware/auth');

const router = express.Router();
router.use(exigirLogin);
router.use(exigirAdmin); // dinheiro da clínica: só administrador
router.use((req, res, next) => {
  // administrador preso a uma cidade não vê o dinheiro da clínica inteira
  if (req.usuario.unidadeId) return res.status(403).json({ erro: 'O financeiro só abre para o administrador geral.' });
  next();
});

const FORMAS = ['dinheiro', 'pix', 'debito', 'credito', 'convenio'];

function periodo(req) {
  const hoje = new Date();
  const ini = new Date(hoje.getFullYear(), hoje.getMonth(), 1);
  const fim = new Date(hoje.getFullYear(), hoje.getMonth() + 1, 0);
  const f = (d) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  return [req.query.de || f(ini), req.query.ate || f(fim)];
}

/* Recebíveis do período: atendimentos sem cobrança, a receber e recebidos */
router.get('/recebiveis', async (req, res) => {
  const [de, ate] = periodo(req);
  const base = `SELECT a.id AS agendamento_id, a.data_hora, a.status AS situacao, p.nome_completo AS paciente_nome, t.nome AS tipo_nome, t.preco_padrao,
      un.nome AS unidade_nome, o.nome AS otica_nome,
      pg.id AS pagamento_id, pg.valor, pg.forma, pg.status, pg.pago_em, cv.nome AS convenio_nome
    FROM agendamentos a
    JOIN pacientes p ON p.id = a.paciente_id
    LEFT JOIN tipos_atendimento t ON t.id = a.tipo_atendimento_id
    LEFT JOIN unidades un ON un.id = a.unidade_id
    LEFT JOIN oticas_parceiras o ON o.id = a.otica_parceira_id
    LEFT JOIN pagamentos pg ON pg.agendamento_id = a.id
    LEFT JOIN convenios cv ON cv.id = pg.convenio_id
    WHERE a.clinica_id=$1 AND a.status <> 'cancelado' AND a.data_hora::date BETWEEN $2 AND $3`;
  const r = await pool.query(`${base} ORDER BY a.data_hora DESC`, [req.usuario.clinicaId, de, ate]);
  res.json({
    de, ate,
    sem_cobranca: r.rows.filter((x) => !x.pagamento_id),
    a_receber: r.rows.filter((x) => x.pagamento_id && x.status === 'pendente'),
    recebidos: r.rows.filter((x) => x.pagamento_id && x.status === 'pago'),
  });
});

/* cria ou atualiza a cobrança de um atendimento */
router.post('/pagamentos', async (req, res) => {
  const { agendamento_id, valor, forma, convenio_id, pago } = req.body;
  const v = Number(String(valor).replace(',', '.'));
  if (!agendamento_id || isNaN(v) || v < 0) return res.status(400).json({ erro: 'Informe o atendimento e um valor válido.' });
  if (forma && !FORMAS.includes(forma)) return res.status(400).json({ erro: 'Forma de pagamento inválida.' });
  const ag = await pool.query(`SELECT id FROM agendamentos WHERE id=$1 AND clinica_id=$2`, [agendamento_id, req.usuario.clinicaId]);
  if (!ag.rows.length) return res.status(404).json({ erro: 'Atendimento não encontrado.' });
  let conv = null;
  if (convenio_id) { const c = await pool.query(`SELECT id FROM convenios WHERE id=$1 AND clinica_id=$2`, [convenio_id, req.usuario.clinicaId]); conv = c.rows[0]?.id || null; }
  const r = await pool.query(
    `INSERT INTO pagamentos (clinica_id, agendamento_id, valor, forma, convenio_id, status, pago_em)
     VALUES ($1,$2,$3,$4,$5,$6::varchar, CASE WHEN $6::varchar='pago' THEN (NOW() AT TIME ZONE 'America/Sao_Paulo')::date END)
     ON CONFLICT (agendamento_id) DO UPDATE SET valor=EXCLUDED.valor, forma=EXCLUDED.forma, convenio_id=EXCLUDED.convenio_id,
       status=EXCLUDED.status, pago_em=CASE WHEN EXCLUDED.status='pago' THEN COALESCE(pagamentos.pago_em, (NOW() AT TIME ZONE 'America/Sao_Paulo')::date) END
     RETURNING *`,
    [req.usuario.clinicaId, agendamento_id, v, forma || null, conv, pago ? 'pago' : 'pendente']
  );
  res.status(201).json(r.rows[0]);
});

router.patch('/pagamentos/:id/pagar', async (req, res) => {
  const desfazer = req.body.pago === false;
  const forma = req.body.forma && FORMAS.includes(req.body.forma) ? req.body.forma : null;
  const r = await pool.query(
    `UPDATE pagamentos SET status=$1::varchar, pago_em=CASE WHEN $1::varchar='pago' THEN (NOW() AT TIME ZONE 'America/Sao_Paulo')::date END, forma=COALESCE($2, forma)
     WHERE id=$3 AND clinica_id=$4 RETURNING id`,
    [desfazer ? 'pendente' : 'pago', forma, req.params.id, req.usuario.clinicaId]
  );
  if (!r.rows.length) return res.status(404).json({ erro: 'Cobrança não encontrada.' });
  res.json({ ok: true });
});

router.delete('/pagamentos/:id', async (req, res) => {
  const r = await pool.query(`DELETE FROM pagamentos WHERE id=$1 AND clinica_id=$2 RETURNING id`, [req.params.id, req.usuario.clinicaId]);
  if (!r.rows.length) return res.status(404).json({ erro: 'Cobrança não encontrada.' });
  res.json({ ok: true });
});

/* contas a pagar */
router.get('/contas', async (req, res) => {
  const r = await pool.query(`SELECT id, descricao, valor, vencimento, pago, pago_em FROM contas_pagar WHERE clinica_id=$1 ORDER BY pago, vencimento`, [req.usuario.clinicaId]);
  res.json(r.rows);
});
router.post('/contas', async (req, res) => {
  const { descricao, valor, vencimento } = req.body;
  const v = Number(String(valor).replace(',', '.'));
  if (!descricao || isNaN(v) || v < 0 || !vencimento) return res.status(400).json({ erro: 'Informe descrição, valor e vencimento.' });
  const r = await pool.query(`INSERT INTO contas_pagar (clinica_id, descricao, valor, vencimento) VALUES ($1,$2,$3,$4) RETURNING *`, [req.usuario.clinicaId, descricao, v, vencimento]);
  res.status(201).json(r.rows[0]);
});
router.patch('/contas/:id/pagar', async (req, res) => {
  const desfazer = req.body.pago === false;
  const r = await pool.query(`UPDATE contas_pagar SET pago=$1::boolean, pago_em=CASE WHEN $1::boolean THEN (NOW() AT TIME ZONE 'America/Sao_Paulo')::date END WHERE id=$2 AND clinica_id=$3 RETURNING id`, [!desfazer, req.params.id, req.usuario.clinicaId]);
  if (!r.rows.length) return res.status(404).json({ erro: 'Conta não encontrada.' });
  res.json({ ok: true });
});
router.delete('/contas/:id', async (req, res) => {
  const r = await pool.query(`DELETE FROM contas_pagar WHERE id=$1 AND clinica_id=$2 RETURNING id`, [req.params.id, req.usuario.clinicaId]);
  if (!r.rows.length) return res.status(404).json({ erro: 'Conta não encontrada.' });
  res.json({ ok: true });
});

/* receitas, atestados e declarações pagos por Pix */
router.get('/documentos', async (req, res) => {
  const [de, ate] = periodo(req);
  const r = await pool.query(
    `SELECT d.id, d.tipo, d.valor::float AS valor, d.status, d.criado_em, d.pago_em, d.pago_por_nome, d.criado_por_nome, p.nome_completo AS paciente_nome, un.nome AS unidade_nome
     FROM cobrancas_documento d JOIN pacientes p ON p.id = d.paciente_id LEFT JOIN unidades un ON un.id = d.unidade_id
     WHERE d.clinica_id=$1 AND d.criado_em::date BETWEEN $2 AND $3 ORDER BY d.criado_em DESC LIMIT 300`, [req.usuario.clinicaId, de, ate]);
  res.json({ de, ate, itens: r.rows });
});

/* resumo do período */
router.get('/resumo', async (req, res) => {
  const [de, ate] = periodo(req);
  const id = req.usuario.clinicaId;
  const q = (sql, p) => pool.query(sql, p).then((r) => r.rows);
  const filtroAg = `FROM pagamentos pg JOIN agendamentos a ON a.id = pg.agendamento_id WHERE pg.clinica_id=$1 AND a.data_hora::date BETWEEN $2 AND $3`;
  const [tot] = await q(
    `SELECT COALESCE(SUM(pg.valor) FILTER (WHERE pg.status='pendente'),0)::float AS a_receber,
            COUNT(*) FILTER (WHERE pg.status='pendente')::int AS n_a_receber,
            COALESCE(SUM(pg.valor) FILTER (WHERE pg.status='pago'),0)::float AS recebido,
            COUNT(*) FILTER (WHERE pg.status='pago')::int AS n_recebido ${filtroAg}`, [id, de, ate]);
  const porForma = await q(`SELECT COALESCE(pg.forma,'sem informar') AS nome, SUM(pg.valor)::float AS total, COUNT(*)::int AS qtd ${filtroAg} AND pg.status='pago' GROUP BY 1 ORDER BY 2 DESC`, [id, de, ate]);
  const porOtica = await q(`SELECT COALESCE(o.nome,'sem ótica') AS nome, SUM(pg.valor)::float AS total, COUNT(*)::int AS qtd ${filtroAg.replace('WHERE','LEFT JOIN oticas_parceiras o ON o.id = a.otica_parceira_id WHERE')} AND pg.status='pago' GROUP BY 1 ORDER BY 2 DESC`, [id, de, ate]);
  const porConv = await q(`SELECT COALESCE(c.nome,'particular') AS nome, SUM(pg.valor)::float AS total, COUNT(*)::int AS qtd ${filtroAg.replace('WHERE','LEFT JOIN convenios c ON c.id = pg.convenio_id WHERE')} AND pg.status='pago' GROUP BY 1 ORDER BY 2 DESC`, [id, de, ate]);
  const [contas] = await q(
    `SELECT COALESCE(SUM(valor) FILTER (WHERE NOT pago),0)::float AS a_pagar, COALESCE(SUM(valor) FILTER (WHERE pago),0)::float AS pago
     FROM contas_pagar WHERE clinica_id=$1 AND vencimento BETWEEN $2 AND $3`, [id, de, ate]);
  const [docs] = await q(
    `SELECT COALESCE(SUM(valor) FILTER (WHERE status='pago' AND pago_em::date BETWEEN $2 AND $3),0)::float AS recebido,
            COUNT(*) FILTER (WHERE status='pago' AND pago_em::date BETWEEN $2 AND $3)::int AS n_recebido,
            COALESCE(SUM(valor) FILTER (WHERE status='pendente' AND criado_em::date BETWEEN $2 AND $3),0)::float AS a_receber,
            COUNT(*) FILTER (WHERE status='pendente' AND criado_em::date BETWEEN $2 AND $3)::int AS n_a_receber
     FROM cobrancas_documento WHERE clinica_id=$1`, [id, de, ate]);
  if (docs.n_recebido) { const pf = porForma.find((x) => x.nome === 'pix'); if (pf) { pf.total += docs.recebido; pf.qtd += docs.n_recebido; } else porForma.push({ nome: 'pix', total: docs.recebido, qtd: docs.n_recebido }); porForma.sort((a, b) => b.total - a.total); }
  tot.recebido += docs.recebido;
  const documentos = { recebido: docs.recebido, n_recebido: docs.n_recebido, pendente: docs.a_receber, n_pendente: docs.n_a_receber };
  res.json({ de, ate, ...tot, documentos, por_forma: porForma, por_otica: porOtica, por_convenio: porConv, contas_a_pagar: contas.a_pagar, contas_pagas: contas.pago, saldo: tot.recebido - contas.pago });
});

/* ===== v4.9.33 fase 5: financeiro único da clínica e da OCO =====
   Lê as tabelas da clínica ao vivo e a cópia da OCO (caixa_movimentos, contas_receber, ordens_servico). */
const ETAPAS_OS = ['Pedido feito', 'Enviada ao laboratório', 'Recebida do laboratório', 'Em montagem', 'Pronto para retirada', 'Entregue'];
const NOME_DOC = { receita: 'Receita', atestado: 'Atestado', declaracao: 'Declaração' };

/* fluxo de caixa: tudo o que entrou e saiu no período, das duas pontas */
router.get('/fluxo', async (req, res) => {
  const [de, ate] = periodo(req);
  const id = req.usuario.clinicaId;
  const r = await pool.query(
    `SELECT * FROM (
       SELECT pg.pago_em AS data, 'entrada' AS tipo, 'exame' AS origem, 'Exame · ' || p.nome_completo AS descricao, pg.forma, pg.valor::float AS valor
         FROM pagamentos pg JOIN agendamentos a ON a.id = pg.agendamento_id JOIN pacientes p ON p.id = a.paciente_id
        WHERE pg.clinica_id=$1 AND pg.status='pago' AND pg.pago_em BETWEEN $2 AND $3
       UNION ALL
       SELECT d.pago_em::date, 'entrada', 'documento', d.tipo || ' · ' || p.nome_completo, 'pix', d.valor::float
         FROM cobrancas_documento d JOIN pacientes p ON p.id = d.paciente_id
        WHERE d.clinica_id=$1 AND d.status='pago' AND d.pago_em::date BETWEEN $2 AND $3
       UNION ALL
       SELECT c.pago_em, 'saida', 'conta', c.descricao, NULL, c.valor::float
         FROM contas_pagar c WHERE c.clinica_id=$1 AND c.pago AND c.pago_em BETWEEN $2 AND $3
       UNION ALL
       SELECT m.data, m.tipo, m.origem, m.descricao, m.forma, m.valor::float
         FROM caixa_movimentos m WHERE m.clinica_id=$1 AND m.removido_em IS NULL AND m.data BETWEEN $2 AND $3
     ) t ORDER BY data DESC, tipo LIMIT 2000`, [id, de, ate]);
  const itens = r.rows.map((x) => (x.origem === 'documento' ? Object.assign(x, { descricao: x.descricao.replace(/^(\w+)/, (m) => NOME_DOC[m] || m) }) : x));
  const soma = (f) => Math.round(itens.filter(f).reduce((t, x) => t + x.valor, 0) * 100) / 100;
  const entradas = soma((x) => x.tipo === 'entrada'), saidas = soma((x) => x.tipo === 'saida');
  const porOrigem = {};
  for (const x of itens) { const k = x.origem; porOrigem[k] = porOrigem[k] || { entradas: 0, saidas: 0, qtd: 0 }; porOrigem[k][x.tipo === 'entrada' ? 'entradas' : 'saidas'] += x.valor; porOrigem[k].qtd++; }
  const porDia = {};
  for (const x of itens) { const k = String(x.data instanceof Date ? x.data.toISOString() : x.data).slice(0, 10); porDia[k] = porDia[k] || { entradas: 0, saidas: 0 }; porDia[k][x.tipo === 'entrada' ? 'entradas' : 'saidas'] += x.valor; }
  const esp = await pool.query(`SELECT copiado_em, erro FROM oco_espelho WHERE clinica_id=$1`, [id]);
  res.json({ de, ate, entradas, saidas, saldo: Math.round((entradas - saidas) * 100) / 100, por_origem: porOrigem, por_dia: porDia, itens, oco: esp.rows[0] || null });
});

/* quadro das OS de óculos por etapa; atrasada = passou do prazo e ainda não ficou pronta */
router.get('/os', async (req, res) => {
  const r = await pool.query(
    `SELECT o.id, o.origem_id, o.numero, o.cliente_nome, o.cliente_tel, o.etapa, o.aberta_em, o.prazo, o.entregue_em, o.valor::float AS valor,
            (o.prazo IS NOT NULL AND o.prazo < (NOW() AT TIME ZONE 'America/Sao_Paulo')::date AND o.etapa NOT IN ('Pronto para retirada','Entregue')) AS atrasada,
            ((NOW() AT TIME ZONE 'America/Sao_Paulo')::date - o.aberta_em) AS dias_aberta
       FROM ordens_servico o
      WHERE o.clinica_id=$1 AND o.removido_em IS NULL AND (o.etapa <> 'Entregue' OR COALESCE(o.entregue_em, o.aberta_em) >= (NOW() AT TIME ZONE 'America/Sao_Paulo')::date - 30)
      ORDER BY atrasada DESC, o.prazo NULLS LAST, o.aberta_em`, [req.usuario.clinicaId]);
  const colunas = ETAPAS_OS.map((e) => ({ etapa: e, itens: r.rows.filter((x) => x.etapa === e) }));
  const outras = r.rows.filter((x) => !ETAPAS_OS.includes(x.etapa));
  if (outras.length) colunas[0].itens.push(...outras);
  res.json({ colunas, abertas: r.rows.filter((x) => x.etapa !== 'Entregue').length, atrasadas: r.rows.filter((x) => x.atrasada).length });
});

/* contas a receber por cliente: parcelas da OCO e exames cobrados e não pagos */
router.get('/receber-clientes', async (req, res) => {
  const id = req.usuario.clinicaId;
  const oco = await pool.query(
    `SELECT COALESCE(cliente_origem_id::text, cliente_nome) AS chave, cliente_nome AS nome, cliente_tel AS telefone, origem_id, parcela, parcelas, vencimento, valor::float AS valor,
            GREATEST((NOW() AT TIME ZONE 'America/Sao_Paulo')::date - vencimento, 0) AS dias_atraso
       FROM contas_receber WHERE clinica_id=$1 AND removido_em IS NULL AND pago_em IS NULL ORDER BY vencimento`, [id]);
  const exames = await pool.query(
    `SELECT p.id::text AS chave, p.nome_completo AS nome, p.telefone, pg.id AS pagamento_id, a.data_hora::date AS vencimento, pg.valor::float AS valor,
            GREATEST((NOW() AT TIME ZONE 'America/Sao_Paulo')::date - a.data_hora::date, 0) AS dias_atraso
       FROM pagamentos pg JOIN agendamentos a ON a.id = pg.agendamento_id JOIN pacientes p ON p.id = a.paciente_id
      WHERE pg.clinica_id=$1 AND pg.status='pendente' AND a.status <> 'cancelado' ORDER BY a.data_hora`, [id]);
  const mapa = new Map();
  const juntar = (x, origem) => {
    const k = origem + ':' + x.chave;
    const c = mapa.get(k) || { origem, nome: x.nome || 'Cliente sem nome', telefone: x.telefone || null, total: 0, vencido: 0, maior_atraso: 0, itens: [] };
    c.total += x.valor; if (x.dias_atraso > 0) c.vencido += x.valor; c.maior_atraso = Math.max(c.maior_atraso, x.dias_atraso);
    c.itens.push({ vencimento: x.vencimento, valor: x.valor, dias_atraso: x.dias_atraso, parcela: x.parcela ? `${x.parcela}/${x.parcelas}` : null });
    mapa.set(k, c);
  };
  oco.rows.forEach((x) => juntar(x, 'oco')); exames.rows.forEach((x) => juntar(x, 'exame'));
  const lista = [...mapa.values()].map((c) => Object.assign(c, { total: Math.round(c.total * 100) / 100, vencido: Math.round(c.vencido * 100) / 100 }))
    .sort((a, b) => b.maior_atraso - a.maior_atraso || b.total - a.total);
  /* Pix Copia e Cola com o valor vencido (ou o total, se nada venceu), na chave Pix da clínica */
  const cfg = await pool.query(`SELECT c.pix_chave, c.pix_nome, c.pix_cidade, c.nome_fantasia, (SELECT cidade FROM unidades WHERE clinica_id=c.id AND cidade IS NOT NULL ORDER BY criado_em LIMIT 1) AS cidade_unidade FROM clinicas c WHERE c.id=$1`, [id]);
  const k = cfg.rows[0] || {};
  if (k.pix_chave) {
    const pix = require('../utils/pix');
    for (const c of lista) { const v = c.vencido || c.total; if (v > 0) c.pix = pix.gerarPayload({ chave: k.pix_chave, nome: k.pix_nome || k.nome_fantasia, cidade: k.pix_cidade || k.cidade_unidade, valor: v }); }
  }
  const tot = (f) => Math.round(lista.reduce((t, c) => t + f(c), 0) * 100) / 100;
  res.json({ clientes: lista, total: tot((c) => c.total), vencido: tot((c) => c.vencido), pix_configurado: !!k.pix_chave });
});

/* painel Master: os números dos dois sistemas numa tela */
router.get('/painel-master', async (req, res) => {
  const id = req.usuario.clinicaId;
  const um = async (sql) => (await pool.query(sql, [id])).rows[0];
  const cidades = (await pool.query(
    `SELECT COALESCE(NULLIF(u.cidade,''), u.nome, 'Sem cidade') AS cidade, COUNT(*)::int AS total,
            COUNT(*) FILTER (WHERE a.status='confirmado')::int AS confirmados, COUNT(*) FILTER (WHERE a.status='realizado')::int AS atendidos
       FROM agendamentos a LEFT JOIN unidades u ON u.id = a.unidade_id
      WHERE a.clinica_id=$1 AND a.status <> 'cancelado' AND a.data_hora::date = (NOW() AT TIME ZONE 'America/Sao_Paulo')::date GROUP BY 1 ORDER BY 2 DESC`, [id])).rows;
  const vendas = await um(`SELECT COUNT(*) FILTER (WHERE data = (NOW() AT TIME ZONE 'America/Sao_Paulo')::date)::int AS hoje_qtd, COALESCE(SUM(total) FILTER (WHERE data = (NOW() AT TIME ZONE 'America/Sao_Paulo')::date),0)::float AS hoje,
      COUNT(*) FILTER (WHERE date_trunc('month', data) = date_trunc('month', (NOW() AT TIME ZONE 'America/Sao_Paulo')::date))::int AS mes_qtd,
      COALESCE(SUM(total) FILTER (WHERE date_trunc('month', data) = date_trunc('month', (NOW() AT TIME ZONE 'America/Sao_Paulo')::date)),0)::float AS mes
      FROM vendas_oco WHERE clinica_id=$1 AND removido_em IS NULL`);
  const os = await um(`SELECT COUNT(*) FILTER (WHERE etapa <> 'Entregue')::int AS abertas,
      COUNT(*) FILTER (WHERE etapa = 'Pronto para retirada')::int AS prontas,
      COUNT(*) FILTER (WHERE prazo < (NOW() AT TIME ZONE 'America/Sao_Paulo')::date AND etapa NOT IN ('Pronto para retirada','Entregue'))::int AS atrasadas
      FROM ordens_servico WHERE clinica_id=$1 AND removido_em IS NULL`);
  const caixa = await um(`SELECT
      COALESCE((SELECT SUM(valor) FROM pagamentos WHERE clinica_id=$1 AND status='pago' AND pago_em = (NOW() AT TIME ZONE 'America/Sao_Paulo')::date),0)
    + COALESCE((SELECT SUM(valor) FROM cobrancas_documento WHERE clinica_id=$1 AND status='pago' AND pago_em::date = (NOW() AT TIME ZONE 'America/Sao_Paulo')::date),0)
    + COALESCE((SELECT SUM(valor) FROM caixa_movimentos WHERE clinica_id=$1 AND removido_em IS NULL AND tipo='entrada' AND data = (NOW() AT TIME ZONE 'America/Sao_Paulo')::date),0) AS entradas_hoje,
      COALESCE((SELECT SUM(valor) FROM contas_pagar WHERE clinica_id=$1 AND pago AND pago_em = (NOW() AT TIME ZONE 'America/Sao_Paulo')::date),0)
    + COALESCE((SELECT SUM(valor) FROM caixa_movimentos WHERE clinica_id=$1 AND removido_em IS NULL AND tipo='saida' AND data = (NOW() AT TIME ZONE 'America/Sao_Paulo')::date),0) AS saidas_hoje`);
  const receber = await um(`SELECT COALESCE(SUM(valor),0)::float AS total, COALESCE(SUM(valor) FILTER (WHERE vencimento < (NOW() AT TIME ZONE 'America/Sao_Paulo')::date),0)::float AS vencido,
      COUNT(DISTINCT COALESCE(cliente_origem_id::text, cliente_nome)) FILTER (WHERE vencimento < (NOW() AT TIME ZONE 'America/Sao_Paulo')::date)::int AS clientes_atraso
      FROM contas_receber WHERE clinica_id=$1 AND removido_em IS NULL AND pago_em IS NULL`);
  const pagar = await um(`SELECT COUNT(*) FILTER (WHERE vencimento BETWEEN (NOW() AT TIME ZONE 'America/Sao_Paulo')::date AND (NOW() AT TIME ZONE 'America/Sao_Paulo')::date + 3)::int AS vencendo,
      COUNT(*) FILTER (WHERE vencimento < (NOW() AT TIME ZONE 'America/Sao_Paulo')::date)::int AS vencidas FROM contas_pagar WHERE clinica_id=$1 AND NOT pago`);
  const vigia = await um(`SELECT COUNT(*) FILTER (WHERE status='aberta')::int AS abertas, COUNT(*) FILTER (WHERE status='sindicancia')::int AS sindicancias,
      (SELECT COUNT(*) FROM vigia_pedidos WHERE clinica_id=$1 AND status='pendente')::int AS pedidos FROM vigia_ocorrencias WHERE clinica_id=$1`);
  const esp = await pool.query(`SELECT copiado_em, erro FROM oco_espelho WHERE clinica_id=$1`, [id]);
  const n = (x) => Math.round(Number(x || 0) * 100) / 100;
  res.json({ cidades, vendas, os, caixa: { entradas: n(caixa.entradas_hoje), saidas: n(caixa.saidas_hoje), saldo: n(caixa.entradas_hoje - caixa.saidas_hoje) },
    receber, pagar, vigia, oco: esp.rows[0] || null });
});

/* copia o bloco da OCO de novo e confere os totais (botão do Master) */
router.post('/oco/copiar', async (req, res) => {
  const r = await require('../utils/ocoEspelho').espelharDoBanco(req.usuario.clinicaId);
  res.status(r.ok ? 200 : 500).json(r.ok ? r : { erro: 'A cópia não bateu: ' + r.erro });
});

/* ---- nota fiscal SIMULADA: não vai à prefeitura, não tem valor fiscal ---- */
router.get('/notas-simuladas', async (req, res) => {
  const r = await pool.query(`SELECT id, numero, cliente_nome, cliente_cpf, descricao, valor, forma, criado_por, criado_em FROM notas_simuladas WHERE clinica_id=$1 ORDER BY numero DESC LIMIT 100`, [req.usuario.clinicaId]);
  res.json(r.rows);
});
router.post('/notas-simuladas', async (req, res) => {
  const nome = String(req.body.cliente_nome || '').trim().slice(0, 150);
  const descricao = String(req.body.descricao || '').trim().slice(0, 200);
  const valor = Number(String(req.body.valor).replace(',', '.'));
  const cpf = String(req.body.cliente_cpf || '').replace(/\D/g, '').slice(0, 11) || null;
  const forma = FORMAS.includes(req.body.forma) ? req.body.forma : null;
  if (!nome) return res.status(400).json({ erro: 'Informe o nome do cliente.' });
  if (!descricao) return res.status(400).json({ erro: 'Informe o que foi cobrado.' });
  if (!(valor > 0) || valor > 1000000) return res.status(400).json({ erro: 'Informe um valor maior que zero.' });
  const c = await pool.connect();
  try {
    await c.query('BEGIN');
    await c.query('SELECT pg_advisory_xact_lock(hashtext($1))', ['nf-' + req.usuario.clinicaId]);
    const n = await c.query('SELECT COALESCE(MAX(numero),0)+1 AS n FROM notas_simuladas WHERE clinica_id=$1', [req.usuario.clinicaId]);
    const r = await c.query(
      `INSERT INTO notas_simuladas (clinica_id, numero, cliente_nome, cliente_cpf, descricao, valor, forma, criado_por)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING id, numero, cliente_nome, cliente_cpf, descricao, valor, forma, criado_por, criado_em`,
      [req.usuario.clinicaId, n.rows[0].n, nome, cpf, descricao, valor.toFixed(2), forma, req.usuario.nome || null]);
    await c.query('COMMIT');
    res.status(201).json(r.rows[0]);
  } catch (e) { await c.query('ROLLBACK').catch(() => {}); throw e; } finally { c.release(); }
});

module.exports = router;
