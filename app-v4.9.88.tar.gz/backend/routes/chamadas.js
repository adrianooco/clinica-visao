/* ===== v4.9.50: ligação de voz e de vídeo entre o Master e cada pessoa da equipe =====
   - Só as mesmas duplas da conversa privada: um Master com um agendador ou profissional.
   - O som e a imagem vão direto de um aparelho para o outro (WebRTC), protegidos. Nada passa gravado pelo servidor.
   - O servidor só combina a ligação: quem liga, quem atende, e os dados técnicos de conexão. Esses dados ficam
     só na memória e somem quando a ligação acaba.
   - Ligação não atendida em 40 segundos vira "Ligação perdida" na conversa, e a pessoa recebe aviso no celular.
   - Para conectar em qualquer rede (dados móveis), dá para usar um servidor de passagem (TURN) com
     TURN_URLS, TURN_USUARIO e TURN_SENHA na Render. Sem eles, usa só o STUN público. */
const express = require('express');
const crypto = require('crypto');
const pool = require('../db/pool');
const cripto = require('../utils/cripto');
const { exigirLogin } = require('../middleware/auth');
const avisoPush = require('../utils/avisoPush');

const router = express.Router();
router.use(exigirLogin);

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const EQUIPE = ['atendente', 'profissional'];
const TEMPO_CHAMANDO_MS = 40000;
const MAX_SINAIS = 300, MAX_SINAL_BYTES = 20000;
const eu = (req) => req.usuario.usuarioId || req.usuario.id;
const souMaster = (req) => req.usuario.papel === 'admin';
const souEquipe = (req) => EQUIPE.includes(req.usuario.papel);

router.use((req, res, next) => {
  if (!souMaster(req) && !souEquipe(req)) return res.status(403).json({ erro: 'A ligação é entre o Master e a equipe da clínica.' });
  next();
});

/* ligações em andamento, só na memória */
const chamadas = new Map();
const pedidos = new Map();

function iceServers() {
  const l = [{ urls: ['stun:stun.l.google.com:19302', 'stun:stun1.l.google.com:19302'] }];
  const urls = String(process.env.TURN_URLS || '').split(',').map((x) => x.trim()).filter((x) => /^turns?:/.test(x));
  if (urls.length && process.env.TURN_USUARIO && process.env.TURN_SENHA) l.push({ urls, username: process.env.TURN_USUARIO, credential: process.env.TURN_SENHA });
  return l;
}
const temPassagem = () => iceServers().length > 1;

async function par(req, outroId) {
  if (!UUID.test(String(outroId || ''))) return { erro: 'Pessoa inválida.', status: 400 };
  const o = (await pool.query(`SELECT id, nome, papel, ativo FROM usuarios WHERE id=$1 AND clinica_id=$2`, [outroId, req.usuario.clinicaId])).rows[0];
  if (!o || o.id === eu(req)) return { erro: 'Pessoa não encontrada.', status: 404 };
  if (!o.ativo) return { erro: 'Essa pessoa está com o acesso bloqueado.', status: 400 };
  if (souMaster(req) && EQUIPE.includes(o.papel)) return { masterId: eu(req), membroId: o.id, outro: o };
  if (souEquipe(req) && o.papel === 'admin') return { masterId: o.id, membroId: eu(req), outro: o };
  return { erro: 'Essa ligação não é permitida.', status: 403 };
}

/* escreve na conversa da dupla (aparece para os dois, como mensagem de quem ligou) */
async function registrarNaConversa(c, texto) {
  try {
    const conv = (await pool.query(
      `INSERT INTO conversas_equipe (clinica_id, master_id, membro_id) VALUES ($1,$2,$3)
       ON CONFLICT (master_id, membro_id) DO UPDATE SET ultima_em = NOW() RETURNING id`, [c.clinicaId, c.masterId, c.membroId])).rows[0];
    await pool.query(`INSERT INTO conversas_mensagens (clinica_id, conversa_id, autor_id, texto) VALUES ($1,$2,$3,$4)`, [c.clinicaId, conv.id, c.de.id, cripto.cifrar(texto)]);
  } catch (e) { console.error('Registro da ligação na conversa falhou:', e.message); }
}
const nomeTipo = (t) => (t === 'video' ? 'vídeo' : 'voz');
function duracaoTexto(s) { const m = Math.floor(s / 60), r = s % 60; return m ? `${m} min${r ? ' ' + r + ' s' : ''}` : `${r} s`; }

function finalizar(c, estado) {
  if (['encerrada', 'recusada', 'perdida', 'cancelada'].includes(c.estado)) return;
  c.estado = estado; c.fim = Date.now();
  if (estado === 'encerrada' && c.atendidaEm) registrarNaConversa(c, `📞 Ligação de ${nomeTipo(c.tipo)}, ${duracaoTexto(Math.round((c.fim - c.atendidaEm) / 1000))}.`);
  else if (estado === 'perdida' || (estado === 'encerrada' && !c.atendidaEm) || estado === 'cancelada') {
    registrarNaConversa(c, `📞 Ligação de ${nomeTipo(c.tipo)} perdida.`);
    avisoPush.enviarParaUsuario(c.para.id, { titulo: 'Ligação perdida', corpo: `Ligação perdida de ${c.de.nome}. Toque para abrir a conversa.`, url: '/modulo-agendamento.html#conversa=' + c.de.id, tag: 'cham-' + c.id });
  } else if (estado === 'recusada') registrarNaConversa(c, `📞 Ligação de ${nomeTipo(c.tipo)} recusada.`);
  setTimeout(() => chamadas.delete(c.id), 120000).unref();
}
setInterval(() => {
  const a = Date.now();
  for (const c of chamadas.values()) {
    if (c.estado === 'chamando' && a - c.inicio > TEMPO_CHAMANDO_MS) finalizar(c, 'perdida');
    // ligação atendida em que os dois pararam de responder por 60 s
    else if (c.estado === 'atendida' && a - Math.max(c.visto[c.de.id] || 0, c.visto[c.para.id] || 0) > 60000) finalizar(c, 'encerrada');
  }
  for (const [k, t] of pedidos) if (a - t.inicio > 60000) pedidos.delete(k);
}, 5000).unref();

function minha(req, res) {
  const c = chamadas.get(String(req.params.id || ''));
  if (!c || c.clinicaId !== req.usuario.clinicaId || (c.de.id !== eu(req) && c.para.id !== eu(req))) { res.status(404).json({ erro: 'Ligação não encontrada ou já terminou.' }); return null; }
  c.visto[eu(req)] = Date.now();
  return c;
}
const resumo = (c, meuId) => ({ id: c.id, tipo: c.tipo, estado: c.estado, sou: c.de.id === meuId ? 'quem_liga' : 'quem_recebe', outro: c.de.id === meuId ? c.para : c.de, inicio: c.inicio, atendida_em: c.atendidaEm || null, ice: iceServers(), passagem: temPassagem() });

router.get('/config', (req, res) => res.json({ ice: iceServers(), passagem: temPassagem() }));

router.post('/', async (req, res) => {
  const b = req.body || {};
  const tipo = b.tipo === 'video' ? 'video' : 'voz';
  const p = await par(req, b.para);
  if (p.erro) return res.status(p.status).json({ erro: p.erro });
  const t = pedidos.get(eu(req)), agora = Date.now();
  if (!t || agora - t.inicio > 60000) pedidos.set(eu(req), { inicio: agora, n: 1 });
  else if (++t.n > 8) return res.status(429).json({ erro: 'Muitas ligações seguidas. Espere um minuto.' });
  for (const c of chamadas.values()) {
    const envolve = (id) => c.de.id === id || c.para.id === id;
    if (['chamando', 'atendida'].includes(c.estado) && (envolve(eu(req)) || envolve(p.outro.id))) {
      if (envolve(eu(req)) && c.estado === 'chamando' && c.de.id === eu(req)) finalizar(c, 'cancelada');
      else return res.status(409).json({ erro: envolve(p.outro.id) && !envolve(eu(req)) ? `${p.outro.nome} está em outra ligação agora. Tente daqui a pouco ou mande mensagem.` : c.estado === 'chamando' && c.para.id === eu(req) ? `${c.de.nome} está te ligando agora. Atenda ou recuse primeiro.` : 'Você já está numa ligação.' });
    }
  }
  const c = {
    id: crypto.randomUUID(), clinicaId: req.usuario.clinicaId, masterId: p.masterId, membroId: p.membroId, tipo, estado: 'chamando',
    de: { id: eu(req), nome: req.usuario.nome || 'Clínica' }, para: { id: p.outro.id, nome: p.outro.nome },
    inicio: Date.now(), sinais: [], seq: 0, visto: { [eu(req)]: Date.now() },
  };
  chamadas.set(c.id, c);
  avisoPush.enviarParaUsuario(c.para.id, { titulo: tipo === 'video' ? 'Chamada de vídeo' : 'Ligação', corpo: `${c.de.nome} está te ligando${tipo === 'video' ? ' por vídeo' : ''}. Toque para atender.`, url: '/modulo-agendamento.html#chamada=' + c.id, tag: 'cham-' + c.id });
  res.status(201).json(resumo(c, eu(req)));
});

/* ligação tocando para mim (o app olha isso a cada poucos segundos com a tela aberta) */
router.get('/pendente', (req, res) => {
  res.setHeader('Cache-Control', 'no-store');
  for (const c of chamadas.values()) if (c.clinicaId === req.usuario.clinicaId && c.para.id === eu(req) && c.estado === 'chamando') return res.json({ chamada: resumo(c, eu(req)) });
  res.json({ chamada: null });
});

router.get('/:id', (req, res) => { const c = minha(req, res); if (c) res.json(resumo(c, eu(req))); });

router.post('/:id/atender', (req, res) => {
  const c = minha(req, res); if (!c) return;
  if (c.para.id !== eu(req)) return res.status(403).json({ erro: 'Só quem recebe a ligação pode atender.' });
  if (c.estado !== 'chamando') return res.status(409).json({ erro: c.estado === 'perdida' ? 'A ligação já tinha parado de tocar.' : 'Essa ligação já terminou.' });
  if ((req.body || {}).so_voz) c.tipo = 'voz';
  c.estado = 'atendida'; c.atendidaEm = Date.now();
  res.json(resumo(c, eu(req)));
});
router.post('/:id/recusar', (req, res) => {
  const c = minha(req, res); if (!c) return;
  if (c.para.id === eu(req) && c.estado === 'chamando') finalizar(c, 'recusada');
  res.json(resumo(c, eu(req)));
});
router.post('/:id/encerrar', (req, res) => {
  const c = minha(req, res); if (!c) return;
  if (c.estado === 'chamando') finalizar(c, c.de.id === eu(req) ? 'cancelada' : 'recusada');
  else if (c.estado === 'atendida') finalizar(c, 'encerrada');
  res.json(resumo(c, eu(req)));
});

/* dados técnicos da conexão entre os dois aparelhos (oferta, resposta e caminhos de rede) */
router.post('/:id/sinal', (req, res) => {
  const c = minha(req, res); if (!c) return;
  const b = req.body || {};
  if (!['oferta', 'resposta', 'ice', 'midia'].includes(b.tipo)) return res.status(400).json({ erro: 'Sinal inválido.' });
  const dados = JSON.stringify(b.dados || null);
  if (dados.length > MAX_SINAL_BYTES) return res.status(413).json({ erro: 'Sinal grande demais.' });
  if (c.sinais.length >= MAX_SINAIS || ['encerrada', 'recusada', 'perdida', 'cancelada'].includes(c.estado)) return res.status(409).json({ erro: 'Ligação já terminou.' });
  c.sinais.push({ n: ++c.seq, de: eu(req), tipo: b.tipo, dados: b.dados || null });
  res.json({ ok: true });
});
router.get('/:id/sinais', (req, res) => {
  const c = minha(req, res); if (!c) return;
  const depois = Number(req.query.depois) || 0;
  res.setHeader('Cache-Control', 'no-store');
  res.json({ ...resumo(c, eu(req)), sinais: c.sinais.filter((s) => s.n > depois && s.de !== eu(req)).map(({ n, tipo, dados }) => ({ n, tipo, dados })) });
});

module.exports = router;
