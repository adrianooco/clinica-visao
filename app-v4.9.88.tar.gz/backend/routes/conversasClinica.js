/* v4.9.80: tela Conversas. O Master vê todas; o agendador vê as dos pacientes das cidades dele e as de números novos. */
const express = require('express');
const pool = require('../db/pool');
const { exigirLogin } = require('../middleware/auth');
const wpp = require('../utils/whatsapp');
const cc = require('../utils/conversaClinica');

const router = express.Router();
router.use(exigirLogin);
router.use((req, res, next) => (['admin', 'atendente'].includes(req.usuario.papel) ? next() : res.status(403).json({ erro: 'Só o Master e os agendadores abrem as conversas.' })));
const TEL = /^\d{10,15}$/;
function filtro(req, params) {
  if (req.usuario.papel === 'admin' || !req.usuario.unidadeId) return '';
  params.push(req.usuario.unidadeIds || [req.usuario.unidadeId]);
  return ` AND (c.unidade_id IS NULL OR c.unidade_id = ANY($${params.length}::uuid[]))`;
}
async function conversaPermitida(req, tel) {
  const params = [req.usuario.clinicaId, tel];
  const r = await pool.query(`SELECT c.* FROM wa_cli_conversas c WHERE c.clinica_id=$1 AND c.telefone=$2${filtro(req, params)}`, params);
  return r.rows[0] || null;
}

router.get('/config', async (req, res) => {
  const r = (await pool.query(`SELECT COALESCE(conversa_ia_ligada,FALSE) AS ligada, COALESCE(conversa_ia_instrucoes,'') AS instrucoes, whatsapp_numero, COALESCE(whatsapp_auto,FALSE) AS auto FROM clinicas WHERE id=$1`, [req.usuario.clinicaId])).rows[0] || {};
  const ia = require('./ia');
  res.json({ ...r, whatsapp_ligado: wpp.configurado(), ia_paga: !!ia.provedorFoto() });
});
router.put('/config', async (req, res) => {
  if (req.usuario.papel !== 'admin') return res.status(403).json({ erro: 'Só o Master muda o atendimento automático.' });
  const b = req.body || {};
  await pool.query(`UPDATE clinicas SET conversa_ia_ligada=$2, conversa_ia_instrucoes=$3 WHERE id=$1`, [req.usuario.clinicaId, b.ligada === true, String(b.instrucoes || '').slice(0, 3000)]);
  res.json({ ok: true });
});
router.get('/', async (req, res) => {
  const params = [req.usuario.clinicaId];
  const r = await pool.query(
    `SELECT c.telefone, COALESCE(p.nome_completo, c.nome) AS nome, (p.id IS NOT NULL) AS e_paciente, c.precisa_equipe, c.nao_lidas, c.ultima_em, c.atendido_por,
            (c.equipe_ate IS NOT NULL AND c.equipe_ate > NOW()) AS equipe, (c.ultima_cliente_em > NOW() - INTERVAL '24 hours') AS janela,
            (SELECT texto FROM wa_cli_mensagens m WHERE m.clinica_id=c.clinica_id AND m.telefone=c.telefone ORDER BY criado_em DESC LIMIT 1) AS ultima
     FROM wa_cli_conversas c LEFT JOIN pacientes p ON p.id=c.paciente_id
     WHERE c.clinica_id=$1${filtro(req, params)} ORDER BY c.precisa_equipe DESC, c.ultima_em DESC LIMIT 200`, params);
  res.json(r.rows.map((x) => ({ ...x, ultima: String(cc.dec(x.ultima) || '').slice(0, 90) })));
});
router.get('/:tel', async (req, res) => {
  if (!TEL.test(req.params.tel)) return res.status(400).json({ erro: 'Número inválido.' });
  const c = await conversaPermitida(req, req.params.tel); if (!c) return res.status(404).json({ erro: 'Conversa não encontrada.' });
  const r = await pool.query(`SELECT autor, texto, enviado_por, criado_em FROM (SELECT * FROM wa_cli_mensagens WHERE clinica_id=$1 AND telefone=$2 ORDER BY criado_em DESC LIMIT 200) t ORDER BY criado_em`, [req.usuario.clinicaId, req.params.tel]);
  await pool.query(`UPDATE wa_cli_conversas SET nao_lidas=0 WHERE clinica_id=$1 AND telefone=$2`, [req.usuario.clinicaId, req.params.tel]);
  res.json({ telefone: c.telefone, equipe: !!(c.equipe_ate && new Date(c.equipe_ate) > new Date()), janela: !!(c.ultima_cliente_em && new Date(c.ultima_cliente_em) > new Date(Date.now() - 24 * 3600e3)),
    atendido_por: c.atendido_por, mensagens: r.rows.map((m) => ({ ...m, texto: cc.dec(m.texto) })) });
});
router.post('/:tel/responder', async (req, res) => {
  if (!TEL.test(req.params.tel)) return res.status(400).json({ erro: 'Número inválido.' });
  const texto = String((req.body || {}).texto || '').trim().slice(0, 3000);
  if (!texto) return res.status(400).json({ erro: 'Escreva a mensagem.' });
  const c = await conversaPermitida(req, req.params.tel); if (!c) return res.status(404).json({ erro: 'Conversa não encontrada.' });
  if (!c.ultima_cliente_em || new Date(c.ultima_cliente_em) < new Date(Date.now() - 24 * 3600e3)) return res.status(409).json({ erro: 'Já passaram 24 horas da última mensagem do paciente. O WhatsApp oficial só deixa responder até 24 horas. Use o botão WhatsApp do celular.' });
  if (!wpp.configurado()) return res.status(503).json({ erro: 'O WhatsApp oficial ainda não está ligado no servidor.' });
  try { await wpp.responder(req.params.tel, texto); }
  catch (e) { console.error('Resposta da equipe falhou:', e.message); return res.status(502).json({ erro: 'O WhatsApp não aceitou a mensagem agora. Tente de novo.' }); }
  const nome = req.usuario.nome || 'Equipe';
  await cc.guardar({ id: req.usuario.clinicaId }, req.params.tel, 'equipe', texto, null, null, nome);
  await pool.query(`UPDATE wa_cli_conversas SET equipe_ate=NOW() + INTERVAL '${cc.HORAS_EQUIPE} hours', precisa_equipe=FALSE, atendido_por=$3, ultima_em=NOW() WHERE clinica_id=$1 AND telefone=$2`, [req.usuario.clinicaId, req.params.tel, nome.slice(0, 150)]);
  res.json({ ok: true });
});
router.post('/:tel/devolver', async (req, res) => {
  if (!TEL.test(req.params.tel)) return res.status(400).json({ erro: 'Número inválido.' });
  const c = await conversaPermitida(req, req.params.tel); if (!c) return res.status(404).json({ erro: 'Conversa não encontrada.' });
  await pool.query(`UPDATE wa_cli_conversas SET equipe_ate=NULL, precisa_equipe=FALSE WHERE clinica_id=$1 AND telefone=$2`, [req.usuario.clinicaId, req.params.tel]);
  res.json({ ok: true });
});
router.get('/resumo/selo', async (req, res) => {
  const params = [req.usuario.clinicaId];
  const r = await pool.query(`SELECT COUNT(*) FILTER (WHERE c.precisa_equipe)::int AS precisam, COALESCE(SUM(c.nao_lidas),0)::int AS nao_lidas FROM wa_cli_conversas c WHERE c.clinica_id=$1${filtro(req, params)}`, params);
  res.json(r.rows[0]);
});
module.exports = router;
