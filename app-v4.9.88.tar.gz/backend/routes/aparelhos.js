const express = require('express');
const pool = require('../db/pool');
const { exigirLogin, exigirAdmin, limparCacheUsuario } = require('../middleware/auth');

/* ===== v4.9.44: aparelhos da equipe e aparelhos de confiança do Master =====
   O Master libera, recusa ou remove aparelhos. Nada é apagado: o aparelho removido fica com status "removido". */
const router = express.Router();
router.use(exigirLogin, exigirAdmin);
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const eu = (req) => req.usuario.usuarioId || req.usuario.id;

router.get('/', async (req, res) => {
  const r = await pool.query(
    `SELECT a.id, a.status, a.nome, a.ip, a.criado_em, a.expira_em, a.decidido_em, a.decidido_por, a.ultimo_uso, u.id AS usuario_id, u.nome AS usuario_nome, u.papel
     FROM aparelhos a JOIN usuarios u ON u.id = a.usuario_id
     WHERE a.clinica_id=$1 AND a.status <> 'removido' AND (u.papel IN ('atendente','profissional') OR (a.usuario_id=$2 AND a.status='confiavel' AND a.expira_em > NOW()))
     ORDER BY (a.status='pendente') DESC, u.nome, a.criado_em DESC`, [req.usuario.clinicaId, eu(req)]);
  const c = await pool.query(`SELECT liberar_aparelhos FROM clinicas WHERE id=$1`, [req.usuario.clinicaId]);
  res.setHeader('Cache-Control', 'no-store');
  res.json({ ligado: c.rows[0].liberar_aparelhos !== false, aparelhos: r.rows });
});
router.get('/pendentes', async (req, res) => {
  const r = await pool.query(`SELECT COUNT(*)::int AS n FROM aparelhos WHERE clinica_id=$1 AND status='pendente'`, [req.usuario.clinicaId]);
  res.json({ total: r.rows[0].n });
});
router.post('/:id/:acao', async (req, res) => {
  if (!UUID.test(req.params.id)) return res.status(400).json({ erro: 'Aparelho inválido.' });
  const novo = { liberar: 'liberado', recusar: 'recusado', remover: 'removido' }[req.params.acao];
  if (!novo) return res.status(404).json({ erro: 'Ação desconhecida.' });
  const a = (await pool.query(`SELECT a.*, u.papel FROM aparelhos a JOIN usuarios u ON u.id=a.usuario_id WHERE a.id=$1 AND a.clinica_id=$2`, [req.params.id, req.usuario.clinicaId])).rows[0];
  if (!a) return res.status(404).json({ erro: 'Aparelho não encontrado.' });
  const daEquipe = ['atendente', 'profissional'].includes(a.papel), meu = a.usuario_id === eu(req) && a.status === 'confiavel';
  if (!daEquipe && !(meu && novo === 'removido')) return res.status(403).json({ erro: 'Esse aparelho não pode ser mudado por aqui.' });
  await pool.query(`UPDATE aparelhos SET status=$1, decidido_em=NOW(), decidido_por=$2 WHERE id=$3`, [novo, req.usuario.nome || 'Master', a.id]);
  /* aparelho removido ou recusado: a sessão aberta nele cai na hora */
  if (novo !== 'liberado' && daEquipe) { await pool.query(`UPDATE usuarios SET sessao_versao = sessao_versao + 1 WHERE id=$1`, [a.usuario_id]); limparCacheUsuario(a.usuario_id); }
  await pool.query(`INSERT INTO acessos_log (clinica_id, usuario_id, usuario_nome, acao, area, caminho, ip) VALUES ($1,$2,$3,$4,'aparelhos',$5,$6)`,
    [req.usuario.clinicaId, eu(req), req.usuario.nome || null, novo.slice(0, 10).toUpperCase(), String(a.nome || '').slice(0, 200), req.ip]).catch(() => {});
  res.json({ ok: true, status: novo });
});
router.put('/config', async (req, res) => {
  const ligado = req.body && req.body.ligado === true;
  await pool.query(`UPDATE clinicas SET liberar_aparelhos=$1 WHERE id=$2`, [ligado, req.usuario.clinicaId]);
  res.json({ ok: true, ligado });
});
module.exports = router;
