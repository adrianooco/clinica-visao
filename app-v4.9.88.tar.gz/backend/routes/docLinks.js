/* v4.9.87: link seguro para o paciente abrir a receita, o laudo ou o atestado no celular.
   - O link tem um código longo e aleatório (192 bits). No banco fica só o "resumo" (hash) do código,
     então quem visse o banco não conseguiria montar o link.
   - O documento fica cifrado no banco e o link vence em 30 dias.
   - A página do link não roda nenhum código que não seja o botão de salvar em PDF. */
const express = require('express');
const crypto = require('crypto');
const pool = require('../db/pool');
const { exigirLogin, exigirPermissao } = require('../middleware/auth');
const cripto = require('../utils/cripto');

const TIPOS = { receita: 'Receita de óculos', laudo: 'Laudo optométrico', atestado: 'Atestado', declaracao: 'Declaração de comparecimento' };
const DIAS = 30;
const hash = (t) => crypto.createHash('sha256').update(String(t)).digest('hex');
const escHtml = (v) => String(v == null ? '' : v).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

/* ---------- parte da equipe (com login) ---------- */
const privado = express.Router();
privado.use(exigirLogin);
privado.use(exigirPermissao('receita'));

privado.post('/', async (req, res) => {
  const { paciente_id, tipo } = req.body || {};
  /* o documento vem em base64: a proteção geral do servidor tira os sinais < e > de todo texto que chega */
  let html = req.body && req.body.html_b64 ? Buffer.from(String(req.body.html_b64), 'base64').toString('utf8') : (req.body && req.body.html);
  if (!TIPOS[tipo]) return res.status(400).json({ erro: 'Tipo de documento inválido.' });
  if (typeof html !== 'string' || html.length < 50) return res.status(400).json({ erro: 'Documento vazio.' });
  if (html.length > 4 * 1024 * 1024) return res.status(413).json({ erro: 'Documento grande demais para enviar por link.' });
  if (!paciente_id) return res.status(400).json({ erro: 'Informe o paciente.' });
  const params = [paciente_id, req.usuario.clinicaId];
  let filtro = '';
  if (req.usuario.unidadeId) { params.push(req.usuario.unidadeIds); filtro = ' AND unidade_id=ANY($3)'; }
  const p = await pool.query(`SELECT id FROM pacientes WHERE id=$1 AND clinica_id=$2 AND deletado_em IS NULL${filtro}`, params);
  if (!p.rows.length) return res.status(404).json({ erro: 'Paciente não encontrado.' });
  const token = crypto.randomBytes(24).toString('base64url');
  const r = await pool.query(
    `INSERT INTO doc_links (token_hash, clinica_id, paciente_id, tipo, html, criado_por, expira_em)
     VALUES ($1,$2,$3,$4,$5,$6, NOW() + ($7 || ' days')::interval) RETURNING expira_em`,
    [hash(token), req.usuario.clinicaId, paciente_id, tipo, cripto.cifrar(html), req.usuario.usuarioId || null, String(DIAS)]);
  res.status(201).json({ token, caminho: '/d/' + token, expira_em: r.rows[0].expira_em, dias: DIAS });
});

/* ---------- parte do paciente (sem login, só com o link) ---------- */
const publico = express.Router();
const acessos = new Map();
setInterval(() => { const a = Date.now(); for (const [k, t] of acessos) if (a - t.inicio > 60000) acessos.delete(k); }, 120000).unref();

function paginaAviso(res, status, titulo, texto) {
  res.status(status);
  res.setHeader('Content-Security-Policy', "default-src 'none'; style-src 'unsafe-inline'; base-uri 'none'; form-action 'none'; frame-ancestors 'none'");
  res.setHeader('X-Robots-Tag', 'noindex, nofollow');
  res.setHeader('Cache-Control', 'no-store');
  res.type('html').send(`<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex"><title>${escHtml(titulo)}</title>
<style>body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Arial,sans-serif;background:#F2F2F7;color:#1c1c1e;margin:0;padding:24px 16px;display:flex;justify-content:center}
.c{background:#fff;border-radius:16px;padding:24px;max-width:420px;width:100%;box-shadow:0 2px 12px rgba(0,0,0,.06)}h1{font-size:22px;margin:0 0 8px}p{font-size:17px;line-height:1.45;color:#3c3c43;margin:0}</style></head>
<body><div class="c"><h1>${escHtml(titulo)}</h1><p>${escHtml(texto)}</p></div></body></html>`);
}

publico.get('/:token', async (req, res) => {
  const agora = Date.now(), t = acessos.get(req.ip);
  if (!t || agora - t.inicio > 60000) acessos.set(req.ip, { inicio: agora, n: 1 });
  else if (++t.n > 40) return paginaAviso(res, 429, 'Muitos acessos seguidos', 'Espere um minuto e abra o link de novo.');
  const token = String(req.params.token || '');
  if (!/^[A-Za-z0-9_-]{20,64}$/.test(token)) return paginaAviso(res, 404, 'Link não encontrado', 'Confira se o link chegou inteiro. Se precisar, peça um novo à clínica.');
  const r = await pool.query(`SELECT id, tipo, html, expira_em, revogado_em FROM doc_links WHERE token_hash=$1`, [hash(token)]);
  if (!r.rows.length) return paginaAviso(res, 404, 'Link não encontrado', 'Confira se o link chegou inteiro. Se precisar, peça um novo à clínica.');
  const d = r.rows[0];
  if (d.revogado_em || new Date(d.expira_em).getTime() < agora) return paginaAviso(res, 410, 'Este link venceu', `Por segurança, o link vale ${DIAS} dias. Peça à clínica para mandar de novo.`);
  pool.query(`UPDATE doc_links SET acessos = acessos + 1, ultimo_acesso = NOW() WHERE id=$1`, [d.id]).catch(() => {});
  let html = cripto.decifrar(d.html) || '';
  const nonce = crypto.randomBytes(16).toString('base64');
  const barra = `<div class="dl-barra" style="position:sticky;top:0;z-index:9;display:flex;gap:12px;align-items:center;justify-content:space-between;flex-wrap:wrap;background:#fff;border-bottom:1px solid #e5e5ea;padding:10px 16px;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Arial,sans-serif;">
<span style="font-size:15px;color:#3c3c43;">${escHtml(TIPOS[d.tipo] || 'Documento')}</span>
<button type="button" id="dlPdf" style="min-height:44px;padding:0 20px;border:0;border-radius:999px;background:#1B5C5A;color:#fff;font-size:17px;font-weight:600;cursor:pointer;">Salvar em PDF ou imprimir</button></div>
<style>@media print{.dl-barra{display:none !important}} @media screen{html{background:#F2F2F7} body{background:#fff !important;max-width:840px;margin:0 auto !important;padding:0 16px 32px !important;box-sizing:border-box} .dl-barra{margin:0 -16px 12px !important}}</style>
<script nonce="${nonce}">document.getElementById('dlPdf').addEventListener('click',function(){window.print();});</script>`;
  if (/<body[^>]*>/i.test(html)) html = html.replace(/<body([^>]*)>/i, (m) => m + barra);
  else html = barra + html;
  if (!/name="viewport"/i.test(html)) html = html.replace(/<head([^>]*)>/i, (m) => m + '<meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex">');
  res.setHeader('Content-Security-Policy', `default-src 'none'; img-src 'self' data: https:; style-src 'unsafe-inline' https://fonts.googleapis.com; font-src https://fonts.gstatic.com data:; script-src 'nonce-${nonce}'; base-uri 'none'; form-action 'none'; frame-ancestors 'none'`);
  res.setHeader('X-Robots-Tag', 'noindex, nofollow');
  res.setHeader('Cache-Control', 'no-store');
  res.setHeader('Referrer-Policy', 'no-referrer');
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.type('html').send(html);
});

module.exports = { privado, publico, TIPOS };
