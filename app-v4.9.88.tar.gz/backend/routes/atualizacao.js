/* Botão "Atualizar sistema" do Master (v4.9.26).
   Mostra a versão que está no ar e a mais nova que está no GitHub, e manda o Render instalar.
   Variáveis no Render (uma das duas):
     RENDER_DEPLOY_HOOK  endereço do Deploy Hook (Render > serviço > Settings > Deploy Hook)
     RENDER_API_KEY      chave da API do Render (o RENDER_SERVICE_ID o próprio Render já coloca)
   GITHUB_REPO (padrão adrianooco/clinica-visao) e GITHUB_TOKEN (só se o repositório for privado). */
const express = require('express');
const fs = require('fs');
const path = require('path');
const { exigirLogin, exigirAdmin } = require('../middleware/auth');

const router = express.Router();
router.use(exigirLogin, exigirAdmin);

const REPO = /^[\w.-]+\/[\w.-]+$/.test(process.env.GITHUB_REPO || '') ? process.env.GITHUB_REPO : 'adrianooco/clinica-visao';
const noAr = () => { try { return fs.readFileSync(path.join(__dirname, '..', '..', 'VERSION'), 'utf8').trim(); } catch (e) { return '?'; } };
const comparar = (a, b) => { const x = String(a).split('.').map(Number), y = String(b).split('.').map(Number); for (let i = 0; i < Math.max(x.length, y.length); i++) { const d = (x[i] || 0) - (y[i] || 0); if (d) return d; } return 0; };

let cacheGithub = { em: 0, versao: null };
async function versaoNoGithub() {
  if (Date.now() - cacheGithub.em < 60000) return cacheGithub.versao;
  const headers = { 'User-Agent': 'clinica-visao-atualizacao', Accept: 'application/vnd.github+json' };
  if (process.env.GITHUB_TOKEN) headers.Authorization = 'Bearer ' + process.env.GITHUB_TOKEN;
  const r = await fetch(`https://api.github.com/repos/${REPO}/contents`, { headers, signal: AbortSignal.timeout(8000) });
  if (!r.ok) throw new Error('GitHub respondeu ' + r.status);
  const lista = await r.json();
  const versoes = (Array.isArray(lista) ? lista : []).map((f) => (String(f.name).match(/^app-v(\d+(?:\.\d+)*)\.tar\.gz$/) || [])[1]).filter(Boolean);
  const maior = versoes.sort(comparar).pop() || null;
  cacheGithub = { em: Date.now(), versao: maior };
  return maior;
}

function podeInstalar() { return !!(process.env.RENDER_DEPLOY_HOOK || (process.env.RENDER_API_KEY && process.env.RENDER_SERVICE_ID)); }

router.get('/', async (req, res) => {
  let github = null, erroGithub = null;
  try { github = await versaoNoGithub(); } catch (e) { erroGithub = 'Não consegui ver o GitHub agora.'; }
  const atual = noAr();
  res.json({ no_ar: atual, github, tem_nova: !!(github && atual !== '?' && comparar(github, atual) > 0), pode_instalar: podeInstalar(), erro_github: erroGithub });
});

let ultimoPedido = 0;
router.post('/', async (req, res) => {
  if (!podeInstalar()) return res.status(400).json({ erro: 'Falta ligar o botão: coloque RENDER_DEPLOY_HOOK no Render, em Environment.' });
  if (Date.now() - ultimoPedido < 3 * 60000) return res.status(429).json({ erro: 'A atualização já foi pedida. Espere uns minutos.' });
  try {
    let r;
    if (process.env.RENDER_DEPLOY_HOOK) {
      const url = new URL(process.env.RENDER_DEPLOY_HOOK);
      if (url.protocol !== 'https:' || !/(^|\.)render\.com$/.test(url.hostname)) return res.status(400).json({ erro: 'RENDER_DEPLOY_HOOK não parece um endereço do Render.' });
      r = await fetch(url, { method: 'POST', signal: AbortSignal.timeout(15000) });
    } else {
      r = await fetch(`https://api.render.com/v1/services/${encodeURIComponent(process.env.RENDER_SERVICE_ID)}/deploys`, {
        method: 'POST', headers: { Authorization: 'Bearer ' + process.env.RENDER_API_KEY, 'Content-Type': 'application/json', Accept: 'application/json' },
        body: JSON.stringify({ clearCache: 'do_not_clear' }), signal: AbortSignal.timeout(15000) });
    }
    if (!r.ok) return res.status(502).json({ erro: 'O Render não aceitou o pedido (' + r.status + ').' });
    ultimoPedido = Date.now();
    console.log(`Atualização pedida por ${req.usuario.nome || req.usuario.usuarioId}. No ar: ${noAr()}.`);
    res.json({ ok: true, no_ar: noAr() });
  } catch (e) {
    res.status(502).json({ erro: 'Não consegui falar com o Render: ' + e.message });
  }
});

module.exports = router;
