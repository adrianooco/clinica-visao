const express = require('express');
const pool = require('../db/pool');
const { exigirLogin } = require('../middleware/auth');
const { registrarTela, TELAS, TELAS_INTERFACE } = require('../middleware/auditoria');

/* ===== v4.9.36 fase 2: tela de auditoria =====
   GET  /auditoria            lista com filtros e páginas (só Master geral)
   GET  /auditoria/exportar   as mesmas linhas filtradas, em colunas, para baixar como planilha
   GET  /auditoria/opcoes     pessoas e telas para os filtros
   POST /auditoria/tela       a tela avisa que foi aberta (qualquer pessoa logada)
   GET  /auditoria/alertas    alertas do Vigia gerados a partir da auditoria
   POST /auditoria/alertas/:id/decidir   o Master bloqueia ou ignora
   Também responde em /api/auditoria. */
const router = express.Router();
router.use(exigirLogin);
router.post('/tela', registrarTela);

/* daqui para baixo, só o Master geral (admin sem cidade de trabalho escolhida) */
router.use((req, res, next) => {
  if (req.usuario.papel !== 'admin' || req.usuario.unidadeId) return res.status(403).json({ erro: 'A auditoria é só do Master.' });
  next();
});

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const DIA = /^\d{4}-\d{2}-\d{2}$/;
const ACOES = ['ver', 'criar', 'editar', 'apagar'];
const TODAS_TELAS = [...new Set([...Object.values(TELAS), ...TELAS_INTERFACE])].sort();

/* monta o WHERE só com parâmetros ($n): nenhum valor vindo da tela entra no texto da consulta */
function filtros(req) {
  const q = req.query || {};
  const w = ['a.clinica_id = $1'], p = [req.usuario.clinicaId];
  const add = (sql, v) => { p.push(v); w.push(sql.replace('?', '$' + p.length)); };
  if (UUID.test(q.usuario_id || '')) add('a.usuario_id = ?', q.usuario_id);
  if (TODAS_TELAS.includes(q.tela)) add('a.tela = ?', q.tela);
  if (ACOES.includes(q.acao)) add('a.acao = ?', q.acao);
  if (UUID.test(q.paciente_id || '')) add('a.paciente_id = ?', q.paciente_id);
  if (DIA.test(q.de || '')) add(`(a.quando AT TIME ZONE 'America/Sao_Paulo')::date >= ?::date`, q.de);
  if (DIA.test(q.ate || '')) add(`(a.quando AT TIME ZONE 'America/Sao_Paulo')::date <= ?::date`, q.ate);
  if (q.paciente && String(q.paciente).trim().length >= 3) add('p.nome_completo ILIKE ?', '%' + String(q.paciente).trim().replace(/[%_]/g, '').slice(0, 80) + '%');
  return { where: w.join(' AND '), params: p };
}
const SELECT = `SELECT a.id, a.quando, (a.quando AT TIME ZONE 'America/Sao_Paulo') AS quando_local, a.usuario_id, COALESCE(a.usuario_nome, u.nome) AS usuario_nome, a.papel,
    a.tela, a.acao, a.registro_id, a.paciente_id, p.nome_completo AS paciente_nome, a.ip, a.aparelho, a.caminho
  FROM auditoria_telas a LEFT JOIN usuarios u ON u.id = a.usuario_id LEFT JOIN pacientes p ON p.id = a.paciente_id`;

router.get('/', async (req, res) => {
  const f = filtros(req);
  const porPagina = Math.min(200, Math.max(10, parseInt(req.query.por_pagina, 10) || 50));
  const pagina = Math.max(1, parseInt(req.query.pagina, 10) || 1);
  const total = await pool.query(`SELECT COUNT(*)::int AS n FROM auditoria_telas a LEFT JOIN pacientes p ON p.id = a.paciente_id WHERE ${f.where}`, f.params);
  const r = await pool.query(`${SELECT} WHERE ${f.where} ORDER BY a.quando DESC LIMIT ${porPagina} OFFSET ${(pagina - 1) * porPagina}`, f.params);
  res.setHeader('Cache-Control', 'no-store');
  res.json({ pagina, por_pagina: porPagina, total: total.rows[0].n, paginas: Math.max(1, Math.ceil(total.rows[0].n / porPagina)), itens: r.rows });
});

/* exportação: até 20 mil linhas, já em colunas, na ordem de uma planilha */
router.get('/exportar', async (req, res) => {
  const f = filtros(req);
  const r = await pool.query(`${SELECT} WHERE ${f.where} ORDER BY a.quando DESC LIMIT 20000`, f.params);
  const colunas = ['Data e hora', 'Pessoa', 'Papel', 'Tela', 'Ação', 'Paciente', 'Registro', 'IP', 'Aparelho', 'Caminho'];
  const linhas = r.rows.map((x) => [String(x.quando_local).replace('T', ' ').slice(0, 19), x.usuario_nome || '', x.papel || '', x.tela, x.acao,
    x.paciente_nome || '', x.registro_id || '', x.ip || '', x.aparelho || '', x.caminho || '']);
  await pool.query(`INSERT INTO auditoria_telas (clinica_id, usuario_id, usuario_nome, papel, tela, acao, ip, aparelho, caminho, metodo) VALUES ($1,$2,$3,$4,'auditoria','ver',$5,$6,'/auditoria/exportar','GET')`,
    [req.usuario.clinicaId, req.usuario.usuarioId || null, req.usuario.nome || null, req.usuario.papel, String(req.ip || '').slice(0, 60), String(req.get('user-agent') || '').slice(0, 200)]).catch(() => {});
  res.setHeader('Cache-Control', 'no-store');
  res.json({ gerado_em: new Date().toISOString(), filtros: req.query, colunas, linhas, total: linhas.length, cortado: linhas.length === 20000 });
});

router.get('/opcoes', async (req, res) => {
  const u = await pool.query(`SELECT id, nome, papel, ativo FROM usuarios WHERE clinica_id=$1 ORDER BY ativo DESC, nome`, [req.usuario.clinicaId]);
  res.json({ usuarios: u.rows, telas: TODAS_TELAS, acoes: ACOES });
});

/* alertas que o Vigia tirou da auditoria (ia_memoria, tipo seguranca) */
router.get('/alertas', async (req, res) => {
  const st = req.query.status === 'decididos' ? `status IN ('aceita','recusada')` : `status = 'nova'`;
  const r = await pool.query(`SELECT id, resumo, dados_agregados, status, decidido_por, decidido_em, criado_em FROM ia_memoria
    WHERE clinica_id=$1 AND tipo='seguranca' AND ${st} ORDER BY criado_em DESC LIMIT 100`, [req.usuario.clinicaId]);
  res.json(r.rows);
});
router.post('/alertas/:id/decidir', async (req, res) => {
  if (!/^\d{1,18}$/.test(req.params.id)) return res.status(400).json({ erro: 'Alerta inválido.' });
  const decisao = (req.body || {}).decisao;
  if (!['bloquear', 'ignorar'].includes(decisao)) return res.status(400).json({ erro: 'Escolha bloquear ou ignorar.' });
  const a = (await pool.query(`SELECT id, resumo, dados_agregados FROM ia_memoria WHERE id=$1 AND clinica_id=$2 AND tipo='seguranca' AND status='nova'`, [req.params.id, req.usuario.clinicaId])).rows[0];
  if (!a) return res.status(404).json({ erro: 'Alerta não encontrado ou já decidido.' });
  let mensagem = 'Alerta ignorado. Nada foi feito com a conta.';
  if (decisao === 'bloquear') {
    const alvo = a.dados_agregados || {};
    if (!UUID.test(alvo.usuario_id || '')) return res.status(400).json({ erro: 'Esse alerta não tem uma pessoa ligada.' });
    if (alvo.usuario_id === (req.usuario.usuarioId || req.usuario.id)) return res.status(400).json({ erro: 'Você não pode bloquear a sua própria conta por aqui.' });
    const vigia = require('../utils/vigia');
    const pedidoId = await vigia.criarPedido(req.usuario.clinicaId, { tipo: 'bloquear_usuario', alvo_usuario_id: alvo.usuario_id, alvo_nome: alvo.usuario_nome || null, motivo: a.resumo, origem: 'master' });
    let pid = pedidoId;
    if (!pid) pid = (await pool.query(`SELECT id FROM vigia_pedidos WHERE clinica_id=$1 AND tipo='bloquear_usuario' AND alvo_usuario_id=$2 AND status='pendente'`, [req.usuario.clinicaId, alvo.usuario_id])).rows[0]?.id;
    const r = pid ? await vigia.executarPedido(req.usuario.clinicaId, req.usuario, pid) : { ok: false, mensagem: 'Não consegui criar o bloqueio.' };
    if (!r.ok) return res.status(400).json({ erro: r.mensagem || 'Não consegui bloquear.' });
    mensagem = r.mensagem || 'Conta bloqueada.';
  }
  await pool.query(`UPDATE ia_memoria SET status=$1, decidido_por=$2, decidido_em=NOW() WHERE id=$3`, [decisao === 'bloquear' ? 'aceita' : 'recusada', req.usuario.nome || 'Master', a.id]);
  res.json({ ok: true, mensagem });
});

module.exports = router;
