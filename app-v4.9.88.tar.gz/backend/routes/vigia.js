/* Vigia da equipe: só o Master (admin geral) vê e decide. */
const express = require('express');
const pool = require('../db/pool');
const { exigirLogin, exigirAdmin } = require('../middleware/auth');
const vigia = require('../utils/vigia');

const router = express.Router();
router.use(exigirLogin, exigirAdmin);

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const idOk = (req, res) => { if (UUID.test(req.params.id)) return true; res.status(400).json({ erro: 'Identificador inválido.' }); return false; };
async function anotar(req, oque) {
  await pool.query(`INSERT INTO acessos_log (clinica_id, usuario_id, usuario_nome, acao, area, caminho, ip) VALUES ($1,$2,$3,'VIGIA','vigia',$4,$5)`,
    [req.usuario.clinicaId, req.usuario.usuarioId, req.usuario.nome || null, String(oque).slice(0, 200), req.ip]).catch(() => {});
}

/* resumo para o quadro e para o selo do menu */
router.get('/', async (req, res) => {
  const st = req.query.status === 'fechadas' ? `status IN ('arquivada','procedente')` : `status IN ('aberta','sindicancia')`;
  const [oc, pe, cont] = await Promise.all([
    pool.query(`SELECT id, tipo, gravidade, usuario_id, usuario_nome, usuario_papel, titulo, detalhe, status, ia_parecer, ia_recomendacao, parecer_master, decidido_por, decidido_em, criado_em
      FROM vigia_ocorrencias WHERE clinica_id=$1 AND ${st}
      ORDER BY (status='sindicancia') DESC, CASE gravidade WHEN 'alta' THEN 0 WHEN 'media' THEN 1 ELSE 2 END, criado_em DESC LIMIT 100`, [req.usuario.clinicaId]),
    pool.query(`SELECT id, ocorrencia_id, tipo, alvo_usuario_id, alvo_nome, motivo, origem, criado_em FROM vigia_pedidos WHERE clinica_id=$1 AND status='pendente' ORDER BY criado_em DESC`, [req.usuario.clinicaId]),
    pool.query(`SELECT COUNT(*) FILTER (WHERE status='aberta')::int AS abertas, COUNT(*) FILTER (WHERE status='aberta' AND gravidade='alta')::int AS graves,
      COUNT(*) FILTER (WHERE status='sindicancia')::int AS sindicancias, MAX(criado_em) AS ultima FROM vigia_ocorrencias WHERE clinica_id=$1`, [req.usuario.clinicaId]),
  ]);
  res.json({ ocorrencias: oc.rows, pedidos: pe.rows.map((p) => Object.assign(p, { rotulo: vigia.PEDIDOS[p.tipo] || p.tipo })), resumo: cont.rows[0], ia: !!require('./ia').provedor() });
});

/* conferir agora, sem esperar a próxima hora */
router.post('/rodar', async (req, res) => {
  const novas = await vigia.rodar(req.usuario.clinicaId);
  await anotar(req, '/vigia/rodar');
  res.json({ ok: true, novas: novas.length });
});

/* opinião da IA sobre uma ocorrência */
router.post('/ocorrencias/:id/analisar', async (req, res) => {
  if (!idOk(req, res)) return;
  try {
    const r = await vigia.analisarComIA(req.usuario.clinicaId, req.params.id);
    res.status(r.ok ? 200 : 400).json(r.ok ? r : { erro: r.mensagem });
  } catch (e) {
    console.error('Vigia IA:', e.message);
    res.status(e.status === 429 ? 429 : 502).json({ erro: e.status === 429 ? 'O limite gratuito da IA acabou por hoje. Tente mais tarde.' : 'A IA não respondeu agora. Tente de novo.' });
  }
});

/* abrir sindicância */
router.post('/ocorrencias/:id/sindicancia', async (req, res) => {
  if (!idOk(req, res)) return;
  const r = await pool.query(`UPDATE vigia_ocorrencias SET status='sindicancia' WHERE id=$1 AND clinica_id=$2 AND status IN ('aberta','sindicancia') RETURNING id`, [req.params.id, req.usuario.clinicaId]);
  if (!r.rows.length) return res.status(404).json({ erro: 'Ocorrência não encontrada ou já concluída.' });
  await anotar(req, '/vigia/sindicancia/' + req.params.id);
  res.json({ ok: true });
});

/* salvar o parecer sem concluir */
router.put('/ocorrencias/:id/parecer', async (req, res) => {
  if (!idOk(req, res)) return;
  const texto = String((req.body || {}).parecer || '').slice(0, 4000);
  const r = await pool.query(`UPDATE vigia_ocorrencias SET parecer_master=$1 WHERE id=$2 AND clinica_id=$3 RETURNING id`, [texto, req.params.id, req.usuario.clinicaId]);
  if (!r.rows.length) return res.status(404).json({ erro: 'Ocorrência não encontrada.' });
  res.json({ ok: true });
});

/* concluir: arquivada (não houve nada errado) ou procedente (a suspeita se confirmou) */
router.post('/ocorrencias/:id/concluir', async (req, res) => {
  if (!idOk(req, res)) return;
  const status = (req.body || {}).status === 'procedente' ? 'procedente' : 'arquivada';
  const parecer = (req.body || {}).parecer;
  const r = await pool.query(`UPDATE vigia_ocorrencias SET status=$1, parecer_master=COALESCE($2, parecer_master), decidido_por=$3, decidido_em=NOW()
    WHERE id=$4 AND clinica_id=$5 RETURNING id`, [status, parecer === undefined ? null : String(parecer).slice(0, 4000), req.usuario.nome || 'Master', req.params.id, req.usuario.clinicaId]);
  if (!r.rows.length) return res.status(404).json({ erro: 'Ocorrência não encontrada.' });
  /* arquivou: os pedidos ligados a ela deixam de fazer sentido */
  if (status === 'arquivada') await pool.query(`UPDATE vigia_pedidos SET status='recusado', resultado='Ocorrência arquivada', decidido_por=$1, decidido_em=NOW() WHERE ocorrencia_id=$2 AND status='pendente'`, [req.usuario.nome || 'Master', req.params.id]);
  await anotar(req, `/vigia/concluir/${req.params.id}/${status}`);
  res.json({ ok: true, status });
});

/* pedir uma medida na mão, a partir da ocorrência (ainda precisa do sim) */
router.post('/ocorrencias/:id/pedido', async (req, res) => {
  if (!idOk(req, res)) return;
  const tipo = String((req.body || {}).tipo || '');
  if (!vigia.PEDIDOS[tipo]) return res.status(400).json({ erro: 'Medida desconhecida.' });
  const oc = (await pool.query(`SELECT id, usuario_id, usuario_nome, titulo FROM vigia_ocorrencias WHERE id=$1 AND clinica_id=$2`, [req.params.id, req.usuario.clinicaId])).rows[0];
  if (!oc || !oc.usuario_id) return res.status(404).json({ erro: 'Essa ocorrência não tem uma pessoa ligada.' });
  const id = await vigia.criarPedido(req.usuario.clinicaId, { ocorrencia_id: oc.id, tipo, alvo_usuario_id: oc.usuario_id, alvo_nome: oc.usuario_nome, motivo: oc.titulo, origem: 'master' });
  res.json({ ok: true, id, jaExistia: !id });
});

/* autorizar ou recusar um pedido */
router.post('/pedidos/:id/autorizar', async (req, res) => {
  if (!idOk(req, res)) return;
  const r = await vigia.executarPedido(req.usuario.clinicaId, req.usuario, req.params.id);
  await anotar(req, '/vigia/autorizar/' + req.params.id);
  res.status(r.ok ? 200 : 400).json(r.ok ? r : { erro: r.mensagem });
});
router.post('/pedidos/:id/recusar', async (req, res) => {
  if (!idOk(req, res)) return;
  const r = await pool.query(`UPDATE vigia_pedidos SET status='recusado', decidido_por=$1, decidido_em=NOW() WHERE id=$2 AND clinica_id=$3 AND status='pendente' RETURNING id`, [req.usuario.nome || 'Master', req.params.id, req.usuario.clinicaId]);
  if (!r.rows.length) return res.status(404).json({ erro: 'Pedido não encontrado ou já decidido.' });
  await anotar(req, '/vigia/recusar/' + req.params.id);
  res.json({ ok: true, mensagem: 'Pedido recusado. Nada foi feito.' });
});

/* dossiê da sindicância: a ocorrência, a linha do tempo da pessoa e o histórico de alertas e medidas */
const TEXTO_ACAO = {
  paciente: { GET: 'Abriu a ficha de um paciente', POST: 'Cadastrou um paciente', PUT: 'Editou um paciente', PATCH: 'Editou um paciente', DELETE: 'Excluiu um paciente' },
  agendamento: { POST: 'Marcou um exame', PUT: 'Mudou um agendamento', PATCH: 'Mudou um agendamento', DELETE: 'Excluiu um agendamento' },
  agenda: { POST: 'Abriu uma agenda', PUT: 'Editou uma agenda', PATCH: 'Editou uma agenda', DELETE: 'Apagou uma agenda' },
  prontuario: { GET: 'Abriu um prontuário', POST: 'Criou um prontuário', PUT: 'Editou um prontuário', DELETE: 'Excluiu um prontuário' },
  receita: { GET: 'Abriu uma receita', POST: 'Emitiu receita ou atestado', PUT: 'Editou uma receita', DELETE: 'Excluiu uma receita' },
  cidade: { POST: 'Cadastrou uma cidade', PUT: 'Editou uma cidade', DELETE: 'Desativou uma cidade' },
  financeiro: { GET: 'Abriu o financeiro', POST: 'Lançou no financeiro', PUT: 'Editou no financeiro', DELETE: 'Excluiu no financeiro' },
  backup: { POST: 'Baixou a cópia completa dos dados' },
};
const textoDe = (l) => (TEXTO_ACAO[l.area] && TEXTO_ACAO[l.area][l.acao]) || `${l.acao} em ${l.area}`;

router.get('/ocorrencias/:id/dossie', async (req, res) => {
  if (!idOk(req, res)) return;
  const oc = (await pool.query(`SELECT * FROM vigia_ocorrencias WHERE id=$1 AND clinica_id=$2`, [req.params.id, req.usuario.clinicaId])).rows[0];
  if (!oc) return res.status(404).json({ erro: 'Ocorrência não encontrada.' });
  let eventos = [], historico = [], pedidos = [], pessoa = null;
  if (oc.usuario_id) {
    const ini = oc.janela_inicio || oc.criado_em, fim = oc.janela_fim || oc.criado_em;
    const p = [oc.usuario_id, req.usuario.clinicaId, ini, fim];
    const [u, ac, en, ag, hi, pe] = await Promise.all([
      pool.query(`SELECT nome, email, papel, ativo, criado_em, ultimo_acesso FROM usuarios WHERE id=$1 AND clinica_id=$2`, [oc.usuario_id, req.usuario.clinicaId]),
      pool.query(`SELECT acao, area, criado_em, ip FROM acessos_log WHERE usuario_id=$1 AND clinica_id=$2 AND criado_em BETWEEN $3::timestamp - INTERVAL '12 hours' AND $4::timestamp + INTERVAL '12 hours' ORDER BY criado_em DESC LIMIT 300`, p),
      pool.query(`SELECT criado_em, lat, lng, ip FROM entradas_log WHERE usuario_id=$1 AND clinica_id=$2 AND criado_em BETWEEN $3::timestamp - INTERVAL '12 hours' AND $4::timestamp + INTERVAL '12 hours' ORDER BY criado_em DESC LIMIT 100`, p),
      pool.query(`SELECT criado_em FROM agendamentos WHERE usuario_id=$1 AND clinica_id=$2 AND criado_em BETWEEN $3::timestamp - INTERVAL '12 hours' AND $4::timestamp + INTERVAL '12 hours' ORDER BY criado_em DESC LIMIT 200`, p),
      pool.query(`SELECT id, titulo, gravidade, status, criado_em FROM vigia_ocorrencias WHERE usuario_id=$1 AND clinica_id=$2 AND id<>$3 ORDER BY criado_em DESC LIMIT 30`, [oc.usuario_id, req.usuario.clinicaId, oc.id]),
      pool.query(`SELECT tipo, status, origem, resultado, decidido_por, decidido_em, criado_em FROM vigia_pedidos WHERE alvo_usuario_id=$1 AND clinica_id=$2 ORDER BY criado_em DESC LIMIT 30`, [oc.usuario_id, req.usuario.clinicaId]),
    ]);
    pessoa = u.rows[0] || null;
    eventos = [
      ...ac.rows.map((x) => ({ quando: x.criado_em, texto: textoDe(x), ip: x.ip })),
      ...en.rows.map((x) => ({ quando: x.criado_em, texto: 'Entrou no sistema', lat: x.lat, lng: x.lng, ip: x.ip })),
      ...ag.rows.filter((x) => !ac.rows.some((a) => a.area === 'agendamento' && a.acao === 'POST' && Math.abs(new Date(a.criado_em) - new Date(x.criado_em)) < 3000)).map((x) => ({ quando: x.criado_em, texto: 'Marcou um exame' })),
    ].sort((a, b) => new Date(b.quando) - new Date(a.quando)).slice(0, 300);
    historico = hi.rows;
    pedidos = pe.rows.map((x) => Object.assign(x, { rotulo: vigia.PEDIDOS[x.tipo] || x.tipo }));
  }
  await anotar(req, '/vigia/dossie/' + oc.id);
  res.json({ ocorrencia: oc, pessoa, eventos, historico, pedidos });
});

module.exports = router;
