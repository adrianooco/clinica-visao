const express = require('express');
const pool = require('../db/pool');
const { exigirLogin, exigirAdmin } = require('../middleware/auth');
const { regraDaClinica } = require('../utils/senha');

/* v4.9.71: regra da senha e do encaixe. Todos leem; só o Master muda. */
const router = express.Router();
router.use(exigirLogin);
router.get('/', async (req, res) => { res.setHeader('Cache-Control', 'no-store'); res.json(await regraDaClinica(req.usuario.clinicaId)); });
router.put('/', exigirAdmin, async (req, res) => {
  const n = (x, min, max) => { const v = parseInt(x, 10); return Number.isFinite(v) && v >= min && v <= max ? v : null; };
  const antecedencia = n(req.body.antecedencia, 0, 60), tolerancia = n(req.body.tolerancia, 0, 60);
  if (antecedencia === null || tolerancia === null) return res.status(400).json({ erro: 'Use minutos de 0 a 60.' });
  await pool.query(`UPDATE clinicas SET senha_ligada=$1, senha_antecedencia_min=$2, senha_tolerancia_min=$3 WHERE id=$4`, [req.body.ligada !== false, antecedencia, tolerancia, req.usuario.clinicaId]);
  res.json(await regraDaClinica(req.usuario.clinicaId));
});
module.exports = router;
