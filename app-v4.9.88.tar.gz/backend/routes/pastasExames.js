const express = require('express');
const pool = require('../db/pool');
const cripto = require('../utils/cripto');
const { exigirLogin } = require('../middleware/auth');

/* v4.9.73: pastas de exames por cidade.
   Depois do atendimento, cada exame (prontuário ou receita) fica numa pasta da cidade onde o paciente foi atendido.
   A cidade é a do agendamento daquele dia; sem agendamento, a cidade do cadastro do paciente.
   Só o Master (admin) e o profissional abrem. O profissional restrito a cidades vê só as cidades dele. */
const router = express.Router();
router.use(exigirLogin);
router.use((req, res, next) => {
  if (req.usuario.papel === 'gestor' && req.method === 'GET' && req.path === '/sem-compra') return next(); /* v4.9.74: o gestor da ótica vê só nome, telefone, dia e cidade */
  if (!['admin', 'profissional'].includes(req.usuario.papel)) return res.status(403).json({ erro: 'As pastas de exames são do Master e do profissional.' });
  next();
});
const oco = require('../utils/ocoCompras'); // v4.9.74
const MES = /^\d{4}-\d{2}$/;
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

/* um registro por paciente e dia, vindo do prontuário ou da receita, com a cidade do atendimento */
function sqlExames(extra) {
  return `WITH dias AS (
      SELECT paciente_id, data_exame AS dia FROM prontuarios WHERE clinica_id=$1
      UNION
      SELECT paciente_id, data_emissao AS dia FROM receitas WHERE clinica_id=$1
    ), ex AS (
      SELECT d.paciente_id, d.dia,
        COALESCE((SELECT a.unidade_id FROM agendamentos a WHERE a.clinica_id=$1 AND a.paciente_id=d.paciente_id AND a.data_hora::date=d.dia AND a.status<>'cancelado' ORDER BY a.data_hora LIMIT 1), p.unidade_id) AS unidade_id,
        (SELECT to_char(a.data_hora,'HH24:MI') FROM agendamentos a WHERE a.clinica_id=$1 AND a.paciente_id=d.paciente_id AND a.data_hora::date=d.dia AND a.status<>'cancelado' ORDER BY a.data_hora LIMIT 1) AS hora
      FROM dias d JOIN pacientes p ON p.id=d.paciente_id AND p.clinica_id=$1 AND p.deletado_em IS NULL
    ) ${extra}`;
}
function filtroCidades(req, params) {
  if (req.usuario.papel === 'admin' || !Array.isArray(req.usuario.unidadeIds) || !req.usuario.unidadeIds.length) return '';
  params.push(req.usuario.unidadeIds);
  return ` AND ex.unidade_id = ANY($${params.length})`;
}

router.get('/', async (req, res) => {
  const params = [req.usuario.clinicaId];
  const f = filtroCidades(req, params);
  const r = await pool.query(sqlExames(`SELECT ex.unidade_id, COUNT(*)::int AS exames, MAX(ex.dia) AS ultimo, MIN(ex.dia) AS primeiro
      FROM ex WHERE TRUE${f} GROUP BY ex.unidade_id`), params);
  const un = await pool.query(`SELECT id, nome, cidade FROM unidades WHERE clinica_id=$1`, [req.usuario.clinicaId]);
  const nome = new Map(un.rows.map((u) => [String(u.id), u.cidade && u.cidade !== u.nome ? `${u.nome} (${u.cidade})` : u.nome]));
  res.setHeader('Cache-Control', 'no-store');
  res.json(r.rows.map((x) => ({ unidade_id: x.unidade_id, cidade: x.unidade_id ? (nome.get(String(x.unidade_id)) || 'Cidade') : 'Sem cidade definida', exames: x.exames, ultimo: x.ultimo, primeiro: x.primeiro }))
    .sort((a, b) => String(b.ultimo).localeCompare(String(a.ultimo))));
});

/* exames de uma cidade num mês: ?unidade=<id ou sem>&mes=AAAA-MM */
router.get('/exames', async (req, res) => {
  const mes = MES.test(String(req.query.mes || '')) ? req.query.mes : null;
  const u = String(req.query.unidade || '');
  if (!mes || !(u === 'sem' || UUID.test(u))) return res.status(400).json({ erro: 'Escolha a cidade e o mês.' });
  const params = [req.usuario.clinicaId, mes + '-01'];
  let fu = '';
  if (u === 'sem') fu = ' AND ex.unidade_id IS NULL'; else { params.push(u); fu = ` AND ex.unidade_id = $${params.length}`; }
  const f = filtroCidades(req, params);
  const r = await pool.query(sqlExames(`SELECT ex.paciente_id, ex.dia, ex.hora, p.nome_completo, p.telefone, p.data_nascimento, p.cpf
      FROM ex JOIN pacientes p ON p.id=ex.paciente_id
      WHERE ex.dia >= $2::date AND ex.dia < ($2::date + INTERVAL '1 month')${fu}${f}
      ORDER BY ex.dia DESC, ex.hora NULLS LAST, p.nome_completo`), params);
  const ids = [...new Set(r.rows.map((x) => x.paciente_id))];
  const pr = ids.length ? await pool.query(`SELECT pr.*, u.nome AS profissional_nome FROM prontuarios pr LEFT JOIN usuarios u ON u.id=pr.profissional_id
      WHERE pr.clinica_id=$1 AND pr.paciente_id = ANY($2) AND pr.data_exame >= $3::date AND pr.data_exame < ($3::date + INTERVAL '1 month') ORDER BY pr.criado_em DESC`, [req.usuario.clinicaId, ids, mes + '-01']) : { rows: [] };
  const rc = ids.length ? await pool.query(`SELECT r.*, u.nome AS profissional_nome FROM receitas r LEFT JOIN usuarios u ON u.id=r.profissional_id
      WHERE r.clinica_id=$1 AND r.paciente_id = ANY($2) AND r.data_emissao >= $3::date AND r.data_emissao < ($3::date + INTERVAL '1 month') ORDER BY r.criado_em DESC`, [req.usuario.clinicaId, ids, mes + '-01']) : { rows: [] };
  const dia = (d) => (d instanceof Date ? d.toISOString() : String(d)).slice(0, 10);
  /* v4.9.74: exame anterior de cada paciente, para ver se o grau mudou */
  const antP = ids.length ? await pool.query(`SELECT paciente_id, data_exame AS dia, refracao FROM prontuarios WHERE clinica_id=$1 AND paciente_id = ANY($2) AND data_exame < ($3::date + INTERVAL '1 month') ORDER BY data_exame DESC`, [req.usuario.clinicaId, ids, mes + '-01']) : { rows: [] };
  const antR = ids.length ? await pool.query(`SELECT paciente_id, data_emissao AS dia, longe FROM receitas WHERE clinica_id=$1 AND paciente_id = ANY($2) AND data_emissao < ($3::date + INTERVAL '1 month') AND COALESCE(tipo_receita,'oculos')='oculos' ORDER BY data_emissao DESC`, [req.usuario.clinicaId, ids, mes + '-01']) : { rows: [] };
  const grauDe = (refr, longe) => {
    const n = (v) => { const x = parseFloat(String(v == null ? '' : v).replace(',', '.')); return isNaN(x) ? null : x; };
    try { if (longe) { const l = cripto.decifrarJson ? cripto.decifrarJson(longe) : longe; if (l && (l.od || l.oe)) return { od: { esf: n(l.od && l.od.esf), cil: n(l.od && l.od.cil) }, oe: { esf: n(l.oe && l.oe.esf), cil: n(l.oe && l.oe.cil) } }; } } catch (e) {}
    try { if (refr) { const f = (cripto.decifrarJson ? cripto.decifrarJson(refr) : refr) || {}; const fi = f.final || {}; if (Object.values(fi).some((v) => v)) return { od: { esf: n(fi.odEsf), cil: n(fi.odCil) }, oe: { esf: n(fi.oeEsf), cil: n(fi.oeCil) } }; } } catch (e) {}
    return null;
  };
  const grauNoDia = (pid, d, antes) => {
    const cand = [];
    for (const y of antP.rows) if (y.paciente_id === pid && (antes ? dia(y.dia) < d : dia(y.dia) === d)) { const g = grauDe(y.refracao, null); if (g) cand.push({ d: dia(y.dia), g }); }
    for (const y of antR.rows) if (y.paciente_id === pid && (antes ? dia(y.dia) < d : dia(y.dia) === d)) { const g = grauDe(null, y.longe); if (g) cand.push({ d: dia(y.dia), g }); }
    cand.sort((a, b) => b.d.localeCompare(a.d));
    return cand[0] || null;
  };
  const mudanca = (a, b) => { let m = 0; for (const o of ['od', 'oe']) for (const k of ['esf', 'cil']) { const x = a.g[o][k], y = b.g[o][k]; if (x != null || y != null) m = Math.max(m, Math.abs((x || 0) - (y || 0))); } return Math.round(m * 100) / 100; };
  let base = null; try { base = await oco.carregar(req.usuario.clinicaId); } catch (e) { base = null; }
  const lista = r.rows.map((x) => {
    const d = dia(x.dia);
    const p = pr.rows.find((y) => y.paciente_id === x.paciente_id && dia(y.data_exame) === d);
    const rec = rc.rows.find((y) => y.paciente_id === x.paciente_id && dia(y.data_emissao) === d && (y.tipo_receita || 'oculos') === 'oculos') || rc.rows.find((y) => y.paciente_id === x.paciente_id && dia(y.data_emissao) === d);
    let pa = null, ra = null;
    try { pa = p ? cripto.abrirProntuario(p) : null; } catch (e) { pa = null; }
    try { ra = rec ? cripto.abrirReceita(rec) : null; } catch (e) { ra = null; }
    const ex = (pa && pa.exame) || {};
    return {
      paciente_id: x.paciente_id, dia: d, hora: x.hora, nome: x.nome_completo, telefone: x.telefone, nascimento: x.data_nascimento ? dia(x.data_nascimento) : null,
      profissional: (pa && pa.profissional_nome) || (ra && ra.profissional_nome) || '',
      queixa: pa ? pa.queixa_principal : null, conduta: pa ? pa.conduta : null,
      av: ex.av || null, encaminhado: !!(ex.encaminhamento && ex.encaminhamento.sim), retorno_meses: ex.retorno_meses || null,
      refracao: pa && pa.refracao ? pa.refracao.final || null : null, fechado: !!(pa && pa.fechado_em),
      receita: ra ? { longe: ra.longe || null, perto: ra.perto || null, adicao: ra.adicao || null, tipo_lente: ra.tipo_lente || null, tipo: ra.tipo_receita || 'oculos' } : null,
      ...(() => { /* v4.9.74: grau do exame anterior e compra na ótica */
        const atual = grauNoDia(x.paciente_id, d, false), ant = grauNoDia(x.paciente_id, d, true);
        const c = base ? oco.compraDepois(base, x, d) : { cliente: false, comprou: false };
        return { anterior: ant ? { dia: ant.d, mudou: atual ? mudanca(atual, ant) : null } : null, compra: { cliente: c.cliente, comprou: c.comprou, data: c.data || null } };
      })(),
    };
  });
  /* v4.9.74: faltas do mês nesta cidade */
  const pf = [req.usuario.clinicaId, mes + '-01'];
  let ff = ''; if (u === 'sem') ff = ' AND unidade_id IS NULL'; else { pf.push(u); ff = ` AND unidade_id=$${pf.length}`; }
  const faltas = (await pool.query(`SELECT COUNT(*)::int AS n FROM agendamentos WHERE clinica_id=$1 AND status='faltou' AND data_hora >= $2::date AND data_hora < ($2::date + INTERVAL '1 month')${ff}`, pf)).rows[0].n;
  res.setHeader('Cache-Control', 'no-store');
  res.json({ mes, exames: lista, faltas, loja: base ? base.loja : '' });
});

/* v4.9.74: retorno vencendo nesta cidade. O último exame do paciente foi nesta cidade, o prazo de retorno
   (o do exame, ou 12 meses) acaba em até 30 dias ou já passou, e ele não tem exame marcado. */
router.get('/retornos', async (req, res) => {
  const u = String(req.query.unidade || '');
  if (!(u === 'sem' || UUID.test(u))) return res.status(400).json({ erro: 'Escolha a cidade.' });
  const params = [req.usuario.clinicaId];
  const f = filtroCidades(req, params);
  const r = await pool.query(sqlExames(`, ult AS (SELECT DISTINCT ON (ex.paciente_id) ex.paciente_id, ex.dia, ex.unidade_id FROM ex WHERE TRUE${f} ORDER BY ex.paciente_id, ex.dia DESC)
      SELECT ult.paciente_id, ult.dia, p.nome_completo, p.telefone,
        (SELECT pr.exame FROM prontuarios pr WHERE pr.clinica_id=$1 AND pr.paciente_id=ult.paciente_id AND pr.data_exame=ult.dia ORDER BY pr.criado_em DESC LIMIT 1) AS exame
      FROM ult JOIN pacientes p ON p.id=ult.paciente_id
      WHERE ${u === 'sem' ? 'ult.unidade_id IS NULL' : `ult.unidade_id = '${u}'`}
        AND NOT EXISTS (SELECT 1 FROM agendamentos a WHERE a.clinica_id=$1 AND a.paciente_id=ult.paciente_id AND a.status IN ('agendado','confirmado') AND a.data_hora >= NOW() - INTERVAL '3 hours')
        AND ult.dia <= (CURRENT_DATE - INTERVAL '5 months')
      ORDER BY ult.dia`), params);
  const hoje = new Date(Date.now() - 3 * 3600e3).toISOString().slice(0, 10);
  const soma = (d, meses) => { const x = new Date(d + 'T12:00:00Z'); x.setUTCMonth(x.getUTCMonth() + meses); return x.toISOString().slice(0, 10); };
  const lim = soma(hoje, 0), em30 = (() => { const x = new Date(hoje + 'T12:00:00Z'); x.setUTCDate(x.getUTCDate() + 30); return x.toISOString().slice(0, 10); })();
  const dia = (d) => (d instanceof Date ? d.toISOString() : String(d)).slice(0, 10);
  const lista = [];
  for (const x of r.rows) {
    let meses = 12; try { const e = x.exame ? cripto.decifrarJson(x.exame) : null; const m = parseInt(e && e.retorno_meses, 10); if (m > 0 && m <= 36) meses = m; } catch (e) {}
    const vence = soma(dia(x.dia), meses);
    if (vence <= em30) lista.push({ paciente_id: x.paciente_id, nome: x.nome_completo, telefone: x.telefone, ultimo: dia(x.dia), vence, vencido: vence < lim, meses });
  }
  let proxima = null;
  if (u !== 'sem') { const a = await pool.query(`SELECT MIN(data) AS d FROM agendas WHERE clinica_id=$1 AND unidade_id=$2 AND COALESCE(ativa,TRUE) AND data >= CURRENT_DATE`, [req.usuario.clinicaId, u]); proxima = a.rows[0].d ? dia(a.rows[0].d) : null; }
  res.setHeader('Cache-Control', 'no-store');
  res.json({ proxima_visita: proxima, retornos: lista });
});

/* v4.9.74: procurar o paciente em todas as pastas */
router.get('/busca', async (req, res) => {
  const q = String(req.query.q || '').trim().slice(0, 60);
  if (q.length < 2) return res.json({ resultados: [] });
  const params = [req.usuario.clinicaId, '%' + q.toLowerCase() + '%'];
  const f = filtroCidades(req, params);
  const r = await pool.query(sqlExames(`SELECT ex.paciente_id, ex.dia, ex.unidade_id, p.nome_completo FROM ex JOIN pacientes p ON p.id=ex.paciente_id
      WHERE lower(p.nome_completo) LIKE $2${f} ORDER BY ex.dia DESC LIMIT 40`), params);
  const dia = (d) => (d instanceof Date ? d.toISOString() : String(d)).slice(0, 10);
  res.json({ resultados: r.rows.map((x) => ({ paciente_id: x.paciente_id, nome: x.nome_completo, dia: dia(x.dia), unidade_id: x.unidade_id })) });
});

/* v4.9.74: fica anotado quem imprimiu ou baixou uma pasta (dados de saúde saindo do sistema) */
router.post('/registro', async (req, res) => {
  const acao = req.body && req.body.acao === 'baixou' ? 'baixou' : 'imprimiu';
  const ref = String((req.body && req.body.unidade) || '').slice(0, 36) + ' ' + String((req.body && req.body.mes) || '').slice(0, 7);
  await pool.query(`INSERT INTO auditoria_telas (clinica_id, usuario_id, usuario_nome, papel, tela, acao, registro_id, ip, aparelho, caminho, metodo) VALUES ($1,$2,$3,$4,'pastas',$5,$6,$7,$8,'/pastas-exames/registro','POST')`,
    [req.usuario.clinicaId, req.usuario.usuarioId || null, req.usuario.nome || null, req.usuario.papel, acao, ref.trim().slice(0, 60), String(req.ip || '').slice(0, 60), String(req.get('user-agent') || '').slice(0, 200)]);
  res.json({ ok: true });
});

/* v4.9.74: para o gestor da ótica, quem fez exame nos últimos 60 dias e ainda não comprou. Sem dado de saúde. */
router.get('/sem-compra', async (req, res) => {
  const params = [req.usuario.clinicaId];
  const r = await pool.query(sqlExames(`SELECT DISTINCT ON (ex.paciente_id) ex.paciente_id, ex.dia, ex.unidade_id, p.nome_completo, p.telefone, p.cpf
      FROM ex JOIN pacientes p ON p.id=ex.paciente_id WHERE ex.dia >= CURRENT_DATE - INTERVAL '60 days' ORDER BY ex.paciente_id, ex.dia DESC`), params);
  const base = await oco.carregar(req.usuario.clinicaId);
  const un = await pool.query(`SELECT id, nome, cidade FROM unidades WHERE clinica_id=$1`, [req.usuario.clinicaId]);
  const nomeUn = new Map(un.rows.map((x) => [String(x.id), x.cidade || x.nome]));
  const dia = (d) => (d instanceof Date ? d.toISOString() : String(d)).slice(0, 10);
  const lista = r.rows.map((x) => ({ x, c: oco.compraDepois(base, x, dia(x.dia)) })).filter((y) => !y.c.comprou)
    .map(({ x, c }) => ({ paciente_id: x.paciente_id, nome: x.nome_completo, telefone: x.telefone, dia: dia(x.dia), cidade: x.unidade_id ? (nomeUn.get(String(x.unidade_id)) || '') : '', cliente_da_otica: c.cliente }))
    .sort((a, b) => b.dia.localeCompare(a.dia));
  res.setHeader('Cache-Control', 'no-store');
  res.json({ loja: base.loja || '', lista });
});

module.exports = router;
