const express = require('express');
const pool = require('../db/pool');
const { exigirLogin, exigirPermissao, exigirAdmin } = require('../middleware/auth');
const pix = require('../utils/pix');
const cripto = require('../utils/cripto');

const router = express.Router();
router.use(exigirLogin);
router.use(exigirPermissao('receita')); // agendador só acessa se o administrador liberar

/* confirma que o paciente existe, é da clínica, e, se o usuário for restrito a
   uma cidade, que o paciente é dessa mesma cidade */
async function pacienteAcessivel(req, pacienteId) {
  const params = [pacienteId, req.usuario.clinicaId];
  let filtro = '';
  if (req.usuario.unidadeId) { params.push(req.usuario.unidadeIds); filtro = ' AND unidade_id=ANY($3)'; }
  const r = await pool.query(`SELECT id FROM pacientes WHERE id=$1 AND clinica_id=$2 AND deletado_em IS NULL${filtro}`, params);
  return r.rows.length > 0;
}

router.get('/', async (req, res) => {
  const { paciente_id } = req.query;
  if (paciente_id && !(await pacienteAcessivel(req, paciente_id))) {
    return res.status(404).json({ erro: 'Paciente não encontrado.' });
  }
  // sem paciente_id: lista só as receitas de pacientes que o usuário pode ver (join com o filtro de cidade)
  const params = [req.usuario.clinicaId, paciente_id || null];
  let filtroUnidade = '';
  if (req.usuario.unidadeId) { params.push(req.usuario.unidadeIds); filtroUnidade = ` AND p.unidade_id=ANY($3)`; }
  const r = await pool.query(
    `SELECT r.*, prof.nome AS profissional_nome, prof.registro_conselho AS profissional_registro,
            prof.carimbo_texto AS profissional_carimbo, prof.assinatura_url AS profissional_assinatura
     FROM receitas r
     JOIN pacientes p ON p.id = r.paciente_id
     LEFT JOIN usuarios prof ON prof.id = r.profissional_id
     WHERE r.clinica_id=$1 AND ($2::uuid IS NULL OR r.paciente_id=$2)${filtroUnidade}
     ORDER BY r.criado_em DESC`,
    params
  );
  res.json(r.rows.map(cripto.abrirReceita));
});

/* código curto para conferir o documento pelo QR Code (sem letras que se confundem) */
const ALFABETO_CODIGO = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
function novoCodigo() { const b = require('crypto').randomBytes(10); let c = ''; for (let i = 0; i < 10; i++) c += ALFABETO_CODIGO[b[i] % ALFABETO_CODIGO.length]; return c; }

router.post('/', async (req, res) => {
  let { paciente_id, idade_paciente, profissional_id, longe, perto, adicao, tipo_lente, tratamentos, cid_codigo, cid_descricao, atestado_texto, declaracao_texto } = req.body;
  if (!paciente_id) return res.status(400).json({ erro: 'Informe o paciente.' });
  if (!(await pacienteAcessivel(req, paciente_id))) {
    return res.status(404).json({ erro: 'Paciente não encontrado.' });
  }
  // se veio profissional_id, confirma que é mesmo um profissional desta clínica
  let profissionalValido = null, ehMedico = false;
  if (profissional_id) {
    const p = await pool.query(`SELECT id, registro_conselho FROM usuarios WHERE id=$1 AND clinica_id=$2 AND papel='profissional'`, [profissional_id, req.usuario.clinicaId]);
    if (p.rows.length) { profissionalValido = profissional_id; ehMedico = /^\s*CRM/i.test(p.rows[0].registro_conselho || ''); }
  }
  // CID de doença é diagnóstico: só entra quando quem assina é médico (CRM).
  // Quem não é médico só pode usar CID de motivo do atendimento (grupo Z); a descrição vem daqui, não do cliente.
  const CID_MOTIVO = { 'Z01.0': 'Exame dos olhos e da visão', 'Z13.5': 'Rastreamento especial de transtornos dos olhos e dos ouvidos', 'Z46.0': 'Colocação e ajustamento de óculos e lentes de contato', 'Z97.3': 'Presença de óculos e lentes de contato' };
  if (!ehMedico) {
    if (profissionalValido && cid_codigo && CID_MOTIVO[cid_codigo]) cid_descricao = CID_MOTIVO[cid_codigo];
    else { cid_codigo = null; cid_descricao = null; }
  }
  // clínica que escolheu atender só com médico: receita e atestado só saem com assinatura de médico (CRM)
  const pol = (await pool.query(`SELECT politica_profissionais FROM clinicas WHERE id=$1`, [req.usuario.clinicaId])).rows[0];
  if (pol && pol.politica_profissionais === 'so_medico' && !ehMedico) {
    return res.status(403).json({ erro: 'Esta clínica emite receita e atestado só com médico (CRM). Escolha um profissional médico.' });
  }
  const codigo = novoCodigo();
  const r = await pool.query(
    `INSERT INTO receitas (clinica_id, paciente_id, usuario_id, profissional_id, idade_paciente, longe, perto, adicao, tipo_lente, tratamentos, cid_codigo, cid_descricao, atestado_texto, declaracao_texto, codigo_verificacao)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15) RETURNING *`,
    [req.usuario.clinicaId, paciente_id, req.usuario.usuarioId, profissionalValido, idade_paciente || null, longe ? cripto.cifrarJson(longe) : null, perto ? cripto.cifrarJson(perto) : null, adicao || null, tipo_lente || null, tratamentos || null, cid_codigo ? cripto.cifrar(cid_codigo) : null, cid_descricao ? cripto.cifrar(cid_descricao) : null, atestado_texto ? cripto.cifrar(atestado_texto) : null, declaracao_texto ? cripto.cifrar(declaracao_texto) : null, codigo]
  );
  res.status(201).json(cripto.abrirReceita(r.rows[0]));
});


/* v4.9.87: laudo optométrico gravado junto da receita (sai no QR Code de conferência) */
router.put('/:id/laudo', async (req, res) => {
  const texto = String((req.body && req.body.laudo_texto) || '').slice(0, 6000);
  const finalidade = String((req.body && req.body.laudo_finalidade) || '').slice(0, 60);
  const r = await pool.query(`SELECT paciente_id FROM receitas WHERE id=$1 AND clinica_id=$2`, [req.params.id, req.usuario.clinicaId]).catch(() => ({ rows: [] }));
  if (!r.rows.length || !(await pacienteAcessivel(req, r.rows[0].paciente_id))) return res.status(404).json({ erro: 'Receita não encontrada.' });
  await pool.query(`UPDATE receitas SET laudo_texto=$1, laudo_finalidade=$2 WHERE id=$3`, [texto ? cripto.cifrar(texto) : null, finalidade || null, req.params.id]);
  res.json({ ok: true });
});

/* ---------- Pix para receita, atestado e declaração ---------- */
const TIPOS_DOC = ['receita', 'atestado', 'declaracao'];
const dinheiro = (v) => { const n = Number(String(v).replace(',', '.')); return isFinite(n) ? Math.round(n * 100) / 100 : NaN; };

async function configPix(clinicaId) {
  const r = await pool.query(
    `SELECT c.pix_chave, c.pix_tipo, c.pix_nome, c.pix_cidade, c.pix_valor_receita, c.pix_valor_atestado, c.nome_fantasia,
            (SELECT cidade FROM unidades WHERE clinica_id=c.id AND cidade IS NOT NULL ORDER BY criado_em LIMIT 1) AS cidade_unidade
     FROM clinicas c WHERE c.id=$1`, [clinicaId]);
  return r.rows[0] || {};
}
const dadosPayload = (c) => ({ chave: c.pix_chave, nome: c.pix_nome || c.nome_fantasia, cidade: c.pix_cidade || c.cidade_unidade });

router.get('/pix/config', async (req, res) => {
  const c = await configPix(req.usuario.clinicaId);
  res.json({
    configurado: !!c.pix_chave, chave: c.pix_chave || '', tipo: c.pix_tipo || 'telefone',
    nome: c.pix_nome || '', cidade: c.pix_cidade || '', valor_receita: c.pix_valor_receita == null ? null : Number(c.pix_valor_receita),
    valor_atestado: c.pix_valor_atestado == null ? null : Number(c.pix_valor_atestado),
    pode_editar: req.usuario.papel === 'admin' && !req.usuario.unidadeId,
  });
});

router.put('/pix/config', exigirAdmin, async (req, res) => {
  if (req.usuario.unidadeId) return res.status(403).json({ erro: 'Só o administrador geral muda a chave Pix.' });
  const { tipo, chave, nome, cidade, valor_receita, valor_atestado } = req.body || {};
  if (!pix.TIPOS.includes(tipo)) return res.status(400).json({ erro: 'Escolha o tipo da chave Pix.' });
  const ch = pix.normalizarChave(tipo, chave);
  if (!ch) return res.status(400).json({ erro: 'A chave Pix não confere com o tipo escolhido.' });
  const vr = valor_receita === '' || valor_receita == null ? null : dinheiro(valor_receita);
  const va = valor_atestado === '' || valor_atestado == null ? null : dinheiro(valor_atestado);
  if ((vr !== null && !(vr > 0 && vr <= 5000)) || (va !== null && !(va > 0 && va <= 5000))) return res.status(400).json({ erro: 'Valor padrão inválido. Use entre 0,01 e 5.000,00.' });
  await pool.query(
    `UPDATE clinicas SET pix_chave=$1, pix_tipo=$2, pix_nome=$3, pix_cidade=$4, pix_valor_receita=$5, pix_valor_atestado=$6 WHERE id=$7`,
    [ch, tipo, String(nome || '').slice(0, 25) || null, String(cidade || '').slice(0, 15) || null, vr, va, req.usuario.clinicaId]);
  res.json({ ok: true });
});

router.post('/pix/cobrancas', async (req, res) => {
  const { paciente_id, tipo } = req.body || {};
  const valor = dinheiro(req.body && req.body.valor);
  if (!TIPOS_DOC.includes(tipo)) return res.status(400).json({ erro: 'Escolha receita, atestado ou declaração.' });
  if (!(valor > 0 && valor <= 5000)) return res.status(400).json({ erro: 'Informe um valor entre 0,01 e 5.000,00.' });
  if (!paciente_id || !(await pacienteAcessivel(req, paciente_id))) return res.status(404).json({ erro: 'Paciente não encontrado.' });
  const c = await configPix(req.usuario.clinicaId);
  if (!c.pix_chave) return res.status(400).json({ erro: 'A chave Pix ainda não foi configurada. Peça ao administrador.' });
  const pac = await pool.query(`SELECT unidade_id FROM pacientes WHERE id=$1`, [paciente_id]);
  const r = await pool.query(
    `INSERT INTO cobrancas_documento (clinica_id, unidade_id, paciente_id, tipo, valor, criado_por_nome) VALUES ($1,$2,$3,$4,$5,$6) RETURNING id, tipo, valor, status, criado_em`,
    [req.usuario.clinicaId, pac.rows[0] && pac.rows[0].unidade_id, paciente_id, tipo, valor, req.usuario.nome || null]);
  const row = r.rows[0];
  res.status(201).json({ ...row, valor: Number(row.valor), payload: pix.gerarPayload({ ...dadosPayload(c), valor }) });
});

router.get('/pix/cobrancas', async (req, res) => {
  const { paciente_id } = req.query;
  if (!paciente_id || !(await pacienteAcessivel(req, paciente_id))) return res.status(404).json({ erro: 'Paciente não encontrado.' });
  const c = await configPix(req.usuario.clinicaId);
  const r = await pool.query(
    `SELECT id, tipo, valor, status, criado_em, pago_em, pago_por_nome FROM cobrancas_documento WHERE clinica_id=$1 AND paciente_id=$2 ORDER BY criado_em DESC LIMIT 10`,
    [req.usuario.clinicaId, paciente_id]);
  res.json(r.rows.map((x) => ({ ...x, valor: Number(x.valor), payload: x.status === 'pendente' && c.pix_chave ? pix.gerarPayload({ ...dadosPayload(c), valor: Number(x.valor) }) : null })));
});

async function cobrancaAcessivel(req) {
  const r = await pool.query(`SELECT id, paciente_id, status FROM cobrancas_documento WHERE id=$1 AND clinica_id=$2`, [req.params.id, req.usuario.clinicaId]);
  const c = r.rows[0];
  if (!c || !(await pacienteAcessivel(req, c.paciente_id))) return null;
  return c;
}

router.post('/pix/cobrancas/:id/pagar', async (req, res) => {
  if (!/^[0-9a-f-]{36}$/i.test(req.params.id)) return res.status(400).json({ erro: 'Cobrança inválida.' });
  const c = await cobrancaAcessivel(req);
  if (!c) return res.status(404).json({ erro: 'Cobrança não encontrada.' });
  await pool.query(`UPDATE cobrancas_documento SET status='pago', pago_em=COALESCE(pago_em, NOW()), pago_por_nome=COALESCE(pago_por_nome, $2) WHERE id=$1`, [c.id, req.usuario.nome || null]);
  await pool.query(`INSERT INTO acessos_log (clinica_id, usuario_id, usuario_nome, acao, area, caminho, ip) VALUES ($1,$2,$3,$4,$5,$6,$7)`,
    [req.usuario.clinicaId, req.usuario.usuarioId, req.usuario.nome || null, 'confirmou pagamento Pix', 'financeiro', '/receitas/pix/cobrancas/' + c.id, req.ip || null]).catch(() => {});
  res.json({ ok: true });
});

router.delete('/pix/cobrancas/:id', async (req, res) => {
  if (!/^[0-9a-f-]{36}$/i.test(req.params.id)) return res.status(400).json({ erro: 'Cobrança inválida.' });
  const c = await cobrancaAcessivel(req);
  if (!c) return res.status(404).json({ erro: 'Cobrança não encontrada.' });
  if (c.status === 'pago') return res.status(409).json({ erro: 'Cobrança já paga não pode ser apagada.' });
  await pool.query(`DELETE FROM cobrancas_documento WHERE id=$1`, [c.id]);
  res.json({ ok: true });
});

module.exports = router;
