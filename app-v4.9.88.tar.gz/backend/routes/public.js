const express = require('express');
const pool = require('../db/pool');

const { estadoDe, estadosResolvidos, limparExtras, CAMPOS } = require('../utils/ficha');
const cripto = require('../utils/cripto');
const { conferirContato } = require('../utils/validar');
const fotoGrava = (v) => (v ? cripto.cifrar(v) : null);
const router = express.Router();

async function buscarClinicaPorSlug(slug) {
  const r = await pool.query(`SELECT * FROM clinicas WHERE slug=$1 AND ativa=TRUE`, [slug]);
  return r.rows[0] || null;
}

/* resolve a cidade pelo slug (?u=) se vier na URL; sem isso, segue sem cidade (modo clínica única) */
async function buscarUnidade(clinicaId, unidadeSlug) {
  if (!unidadeSlug) return null;
  const r = await pool.query(`SELECT * FROM unidades WHERE clinica_id=$1 AND slug=$2 AND ativa=TRUE`, [clinicaId, unidadeSlug]);
  return r.rows[0] || null;
}

/* Conferir um documento (receita, atestado, declaração) pelo QR Code impresso.
   Mostra só o que prova que o documento existe: clínica, profissional, data e o primeiro nome do paciente.
   Nada de grau, CID ou texto do atestado. */
const consultasVerificacao = new Map();
router.get('/verificar/:codigo', async (req, res) => {
  const agora = Date.now(), t = consultasVerificacao.get(req.ip);
  if (!t || agora - t.inicio > 60000) consultasVerificacao.set(req.ip, { inicio: agora, n: 1 });
  else if (++t.n > 30) return res.status(429).json({ erro: 'Muitas consultas seguidas. Tente de novo em um minuto.' });
  const codigo = String(req.params.codigo || '').toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 16);
  if (codigo.length < 8) return res.status(404).json({ valido: false });
  const r = await pool.query(
    `SELECT r.data_emissao, r.criado_em, (r.atestado_texto IS NOT NULL) AS tem_atestado, (r.declaracao_texto IS NOT NULL) AS tem_declaracao, (r.laudo_texto IS NOT NULL) AS tem_laudo,
            (r.longe IS NOT NULL OR r.perto IS NOT NULL) AS tem_receita,
            c.nome_fantasia, p.nome_completo, u.nome AS prof_nome, u.registro_conselho, u.formacao, u.formacao_tipo, u.formacao_portaria
     FROM receitas r JOIN clinicas c ON c.id = r.clinica_id JOIN pacientes p ON p.id = r.paciente_id
     LEFT JOIN usuarios u ON u.id = r.profissional_id
     WHERE r.codigo_verificacao = $1`, [codigo]);
  if (!r.rows.length) return res.status(404).json({ valido: false });
  const x = r.rows[0];
  const nomes = String(x.nome_completo || '').trim().split(/\s+/);
  const paciente = nomes.length > 1 ? `${nomes[0]} ${nomes[nomes.length - 1][0]}.` : nomes[0];
  const documentos = []; if (x.tem_receita) documentos.push('Receita de óculos'); if (x.tem_atestado) documentos.push('Atestado'); if (x.tem_declaracao) documentos.push('Declaração de comparecimento'); if (x.tem_laudo) documentos.push('Laudo optométrico');
  res.json({
    valido: true, codigo, clinica: x.nome_fantasia, emitido_em: x.data_emissao, registrado_em: x.criado_em, paciente, documentos,
    profissional: x.prof_nome ? { nome: x.prof_nome, registro: x.registro_conselho, formacao: x.formacao, formacao_tipo: x.formacao_tipo, formacao_portaria: x.formacao_portaria } : null,
  });
});
setInterval(() => { const a = Date.now(); for (const [k, t] of consultasVerificacao) if (a - t.inicio > 60000) consultasVerificacao.delete(k); }, 120000).unref();

/* dados públicos pra montar a tela: nome, campos obrigatórios, local do exame,
   e, se a URL trouxer ?u=slug-da-cidade, os dados dessa cidade específica */
router.get('/:slug/config', async (req, res) => {
  const clinica = await buscarClinicaPorSlug(req.params.slug);
  if (!clinica) return res.status(404).json({ erro: 'Clínica não encontrada.' });
  const unidade = await buscarUnidade(clinica.id, req.query.u);
  if (req.query.u && !unidade) return res.status(404).json({ erro: 'Cidade não encontrado ou encerrado.' });
  res.json({
    nomeClinica: unidade ? `${clinica.nome_fantasia} · ${unidade.nome}` : clinica.nome_fantasia,
    localExame: unidade ? (unidade.local || clinica.local_exame_padrao) : clinica.local_exame_padrao,
    camposObrigatorios: clinica.campos_obrigatorios,
    ficha: estadosResolvidos(clinica.campos_obrigatorios),
    linkSite: clinica.link_site,
    agendamentoOnline: clinica.agendamento_online !== false,
    unidade: unidade ? { nome: unidade.nome, cidade: unidade.cidade, dataInicio: unidade.data_inicio, dataFim: unidade.data_fim } : null,
  });
});

/* ===== v4.9.42: o paciente escolhe o horário no final do teste =====
   Mostra só horários livres das agendas abertas pelo Master, a partir de 2 horas depois de agora e até 30 dias.
   Nenhum dado de paciente sai daqui: só cidade, dia, hora e local. */
const offline = require('./agendadorOffline');
const consultasHorarios = new Map();
setInterval(() => { const a = Date.now(); for (const [k, t] of consultasHorarios) if (a - t.inicio > 60000) consultasHorarios.delete(k); }, 120000).unref();
async function horariosPublicos(clinica, unidadeId) {
  const hoje = offline.agoraBrasilia().slice(0, 10);
  const lista = await offline.horariosLivres({ clinicaId: clinica.id, unidadeId: null, unidadeIds: [] }, hoje, offline.somaDias(hoje, 30), unidadeId || null);
  const limite = new Date(Date.now() + 2 * 3600000 - 3 * 3600000).toISOString().slice(0, 16); // agora em Brasília + 2 horas
  return lista.filter((x) => (!unidadeId || x.unidade_id === unidadeId) && String(x.data_hora).slice(0, 16) >= limite)
    .slice(0, 600).map((x) => ({ unidade_id: x.unidade_id, unidade_nome: x.unidade_nome, data: x.data, hora: x.hora, data_hora: x.data_hora, local: x.local || null }));
}
router.get('/:slug/horarios', async (req, res) => {
  const agora = Date.now(), t = consultasHorarios.get(req.ip);
  if (!t || agora - t.inicio > 60000) consultasHorarios.set(req.ip, { inicio: agora, n: 1 });
  else if (++t.n > 20) return res.status(429).json({ erro: 'Muitas consultas seguidas. Tente de novo em um minuto.' });
  const clinica = await buscarClinicaPorSlug(req.params.slug);
  if (!clinica) return res.status(404).json({ erro: 'Clínica não encontrada.' });
  if (clinica.agendamento_online === false) return res.json({ ligado: false, horarios: [] });
  const unidade = await buscarUnidade(clinica.id, req.query.u);
  if (req.query.u && !unidade) return res.status(404).json({ erro: 'Cidade não encontrada ou encerrada.' });
  res.setHeader('Cache-Control', 'no-store');
  res.json({ ligado: true, horarios: await horariosPublicos(clinica, unidade ? unidade.id : null) });
});

const marcacoesPorIp = new Map();
setInterval(() => { const a = Date.now(); for (const [k, t] of marcacoesPorIp) if (a - t.inicio > 86400000) marcacoesPorIp.delete(k); }, 3600000).unref();
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const soDigitos = (t) => String(t || '').replace(/\D/g, '');
const dataBR = (dh) => { const d = String(dh); return `${d.slice(8, 10)}/${d.slice(5, 7)} às ${d.slice(11, 16)}`; };

/* autocadastro do paciente (cadastro-paciente.html) */
router.post('/:slug/pacientes', async (req, res) => {
  const clinica = await buscarClinicaPorSlug(req.params.slug);
  if (!clinica) return res.status(404).json({ erro: 'Clínica não encontrada.' });
  const unidade = await buscarUnidade(clinica.id, req.query.u);
  if (req.query.u && !unidade) return res.status(404).json({ erro: 'Cidade não encontrado ou encerrado.' });
  const { nome_completo, cpf, telefone, cep, endereco, bairro, cidade, foto_receita_url, foto_armacao_url, data_nascimento } = req.body;
  if (!nome_completo) return res.status(400).json({ erro: 'Informe o nome.' });
  const msgContato = conferirContato({ cpf, telefone }); if (msgContato) return res.status(400).json({ erro: msgContato });
  if (cripto.fotoGrande(foto_receita_url) || cripto.fotoGrande(foto_armacao_url)) return res.status(413).json({ erro: 'Foto muito grande. Tire outra com menos qualidade.' });
  if (req.body.aceite_lgpd !== true) return res.status(400).json({ erro: 'É preciso aceitar o aviso de privacidade.' });
  const extras = limparExtras(req.body.dados_extras);
  const valores = { telefone, cpf, cep, endereco, bairro, data_nascimento, foto_receita: foto_receita_url || extras.receita_digitada || (extras.receita_status === 'nao_tem' ? 'nao_tem' : ''), foto_armacao: foto_armacao_url, ...extras };
  for (const [chave, rotulo] of CAMPOS) {
    if (estadoDe(clinica.campos_obrigatorios, chave) === 'obrigatorio' && !valores[chave]) {
      return res.status(400).json({ erro: `${rotulo} é obrigatório.` });
    }
  }
  /* v4.9.42: horário escolhido no final do teste (opcional) */
  const h = req.body.horario && typeof req.body.horario === 'object' ? req.body.horario : null;
  let slot = null, unidadeMarcada = null, dh = null;
  if (h) {
    if (clinica.agendamento_online === false) return res.status(400).json({ erro: 'A marcação pelo site está desligada. A clínica vai te chamar para marcar.' });
    dh = String(h.data_hora || '').slice(0, 16);
    if (!/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$/.test(dh) || !UUID.test(String(h.unidade_id || ''))) return res.status(400).json({ erro: 'Horário inválido. Escolha de novo.' });
    if (unidade && unidade.id !== h.unidade_id) return res.status(400).json({ erro: 'Esse horário é de outra cidade. Escolha de novo.' });
    const un = await pool.query(`SELECT id, nome FROM unidades WHERE id=$1 AND clinica_id=$2 AND ativa=TRUE`, [h.unidade_id, clinica.id]);
    if (!un.rows.length) return res.status(400).json({ erro: 'Cidade inválida. Escolha de novo.' });
    unidadeMarcada = un.rows[0];
    if (soDigitos(telefone).length < 10) return res.status(400).json({ erro: 'Para marcar o horário, informe o telefone com DDD. A clínica confirma por ele.' });
    const livres = await horariosPublicos(clinica, unidadeMarcada.id);
    if (!livres.some((x) => String(x.data_hora).slice(0, 16) === dh)) return res.status(409).json({ erro: 'Esse horário não está mais livre. Escolha outro.', ocupado: true });
    slot = await offline.horarioDoEvento(clinica.id, unidadeMarcada.id, dh);
    if (!slot) return res.status(409).json({ erro: 'Esse horário não está mais livre. Escolha outro.', ocupado: true });
    const ja = await pool.query(`SELECT a.data_hora FROM agendamentos a JOIN pacientes p ON p.id = a.paciente_id
      WHERE a.clinica_id=$1 AND a.status IN ('agendado','confirmado') AND a.data_hora >= NOW() - INTERVAL '3 hours'
        AND regexp_replace(COALESCE(p.telefone,''),'\\D','','g') = $2 LIMIT 1`, [clinica.id, soDigitos(telefone)]);
    if (ja.rows.length) return res.status(409).json({ erro: `Este telefone já tem exame marcado para ${dataBR(ja.rows[0].data_hora)}. Para mudar o horário, fale com a clínica.` });
    const t = marcacoesPorIp.get(req.ip), agoraMs = Date.now();
    if (t && agoraMs - t.inicio < 86400000 && t.n >= 3) return res.status(429).json({ erro: 'Muitas marcações feitas deste aparelho hoje. Fale com a clínica para marcar.' });
  }
  const c = await pool.connect();
  try {
    await c.query('BEGIN');
    let pacienteId = null;
    try {
      await c.query('SAVEPOINT novo_paciente');
      const r = await c.query(
        `INSERT INTO pacientes (clinica_id, unidade_id, nome_completo, cpf, telefone, cep, endereco, bairro, cidade, agendado_por, foto_receita_url, foto_armacao_url, data_nascimento, dados_extras, termo_lgpd_aceito_em, termo_lgpd_versao, cpf_idx)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,'Autocadastro',$10,$11,$12,$13,NOW(),'2026-10-v1',$14) RETURNING id`,
        [clinica.id, unidade ? unidade.id : (unidadeMarcada ? unidadeMarcada.id : null), nome_completo, cpf ? cripto.cifrar(cpf) : null, telefone || null, cep || null, endereco || null, bairro || null, cidade || null, fotoGrava(foto_receita_url), fotoGrava(foto_armacao_url), data_nascimento || null, JSON.stringify(extras), cripto.indiceCpf(cpf)]
      );
      pacienteId = r.rows[0].id;
    } catch (e) {
      if (e.code !== '23505') throw e;
      await c.query('ROLLBACK TO SAVEPOINT novo_paciente');
      /* já tem cadastro com esse CPF: só marca o horário se o telefone também for o mesmo do cadastro */
      const ex = h ? (await c.query(`SELECT id, telefone FROM pacientes WHERE clinica_id=$1 AND cpf_idx=$2 AND deletado_em IS NULL`, [clinica.id, cripto.indiceCpf(cpf)])).rows[0] : null;
      if (!ex || soDigitos(ex.telefone) !== soDigitos(telefone)) {
        await c.query('ROLLBACK');
        return res.status(409).json({ erro: h ? 'Já existe um cadastro com esse CPF e outro telefone. Para marcar, fale com a clínica.' : 'Já existe um cadastro com esse CPF nesta clínica.' });
      }
      pacienteId = ex.id;
    }
    let agendamento = null;
    if (h) {
      const a = await c.query(
        `INSERT INTO agendamentos (clinica_id, unidade_id, paciente_id, tipo_atendimento_id, usuario_id, data_hora, duracao_min, buffer_min, local, agendado_por, status, origem)
         VALUES ($1,$2,$3,$4,NULL,$5,$6,$7,$8,'Site (teste de visão)','agendado','site') RETURNING id, data_hora`,
        [clinica.id, unidadeMarcada.id, pacienteId, slot.tipo_atendimento_id, dh + ':00', slot.duracao_min, slot.buffer_min, slot.local || null]);
      agendamento = { id: a.rows[0].id, data_hora: dh + ':00', local: slot.local || unidade?.local || clinica.local_exame_padrao || null, cidade: unidadeMarcada.nome };
    }
    await c.query('COMMIT');
    if (agendamento) {
      const t = marcacoesPorIp.get(req.ip), agoraMs = Date.now();
      if (!t || agoraMs - t.inicio > 86400000) marcacoesPorIp.set(req.ip, { inicio: agoraMs, n: 1 }); else t.n++;
      const email = require('../utils/email'), para = process.env.ALERTA_EMAIL_PARA || process.env.BACKUP_EMAIL_PARA;
      if (email.ativo() && para) email.enviar({ para, assunto: `Exame marcado pelo site: ${dataBR(agendamento.data_hora)} em ${agendamento.cidade}`,
        texto: `${String(nome_completo).split(/\s+/)[0]} marcou um exame pelo teste de visão do site para ${dataBR(agendamento.data_hora)} em ${agendamento.cidade}.\n\nO horário já está na agenda como Agendado. Confirme com o paciente pelo WhatsApp na tela Confirmar.` }).catch(() => {});
    }
    res.status(201).json({ ok: true, id: pacienteId, agendamento });
  } catch (e) {
    await c.query('ROLLBACK').catch(() => {});
    if (e.code === '23P01') return res.status(409).json({ erro: 'Outra pessoa acabou de marcar esse horário. Escolha outro.', ocupado: true });
    if (e.code === '23505') return res.status(409).json({ erro: 'Já existe um cadastro com esse CPF nesta clínica.' });
    console.error(e); res.status(500).json({ erro: 'Erro ao salvar cadastro.' });
  } finally { c.release(); }
});

/* resultado do teste de visão (teste-visao.html) */
router.post('/:slug/testes-visao', async (req, res) => {
  const clinica = await buscarClinicaPorSlug(req.params.slug);
  if (!clinica) return res.status(404).json({ erro: 'Clínica não encontrada.' });
  const unidade = await buscarUnidade(clinica.id, req.query.u);
  if (req.query.u && !unidade) return res.status(404).json({ erro: 'Cidade não encontrado ou encerrado.' });
  const { nome_informado, distancia_cm, menor_linha, equivalente_snellen } = req.body;
  const amsler = ['normal', 'alterado'].includes(req.body.amsler) ? req.body.amsler : null;
  const leque = ['iguais', 'diferentes'].includes(req.body.leque) ? req.body.leque : null;
  const r = await pool.query(
    `INSERT INTO testes_visao (clinica_id, unidade_id, nome_informado, distancia_cm, menor_linha, equivalente_snellen, amsler, leque)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING id`,
    [clinica.id, unidade ? unidade.id : null, nome_informado || null, distancia_cm || null, menor_linha || null, equivalente_snellen || null, amsler, leque]
  );
  res.status(201).json({ ok: true, id: r.rows[0].id });
});

module.exports = router;
