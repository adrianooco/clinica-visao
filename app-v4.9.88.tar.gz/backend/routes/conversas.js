const express = require('express');
const pool = require('../db/pool');
const cripto = require('../utils/cripto');
const { exigirLogin } = require('../middleware/auth');
const avisoPush = require('../utils/avisoPush');

/* ===== v4.9.43: conversa privada entre cada Master e cada pessoa da equipe =====
   - Cada conversa tem só duas pessoas: um Master (admin) e um agendador ou profissional.
   - Ninguém mais lê. Os outros agendadores não veem, e outro Master também não.
   - Exceção: o dono (o primeiro Master da clínica) pode abrir a conversa de outro Master
     só por sindicância, escrevendo o motivo. A abertura fica na auditoria.
   - O texto fica trancado no banco com a chave do sistema (CHAVE_CRIPTOGRAFIA). A IA não lê.
   - Mensagem não se apaga. Quem escreveu pode corrigir em até 5 minutos. */
const router = express.Router();
router.use(exigirLogin);

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const EQUIPE = ['atendente', 'profissional'];
const PRAZO_CORRIGIR_MS = 5 * 60000;
const eu = (req) => req.usuario.usuarioId || req.usuario.id;
const souMaster = (req) => req.usuario.papel === 'admin';
const souEquipe = (req) => EQUIPE.includes(req.usuario.papel);

router.use((req, res, next) => {
  if (!souMaster(req) && !souEquipe(req)) return res.status(403).json({ erro: 'As conversas são entre o Master e a equipe da clínica.' });
  next();
});

const envios = new Map();
/* v4.9.49: quem está com a conversa aberta na tela não recebe aviso no celular (a tela atualiza a cada 10 segundos) */
const vendo = new Map();
setInterval(() => { const a = Date.now(); for (const [k, t] of vendo) if (a - t > 60000) vendo.delete(k); }, 120000).unref();
setInterval(() => { const a = Date.now(); for (const [k, t] of envios) if (a - t.inicio > 60000) envios.delete(k); }, 120000).unref();

/* confere se as duas pessoas podem conversar e devolve quem é o Master e quem é da equipe */
async function par(req, outroId) {
  if (!UUID.test(String(outroId || ''))) return { erro: 'Pessoa inválida.', status: 400 };
  const o = (await pool.query(`SELECT id, nome, papel, ativo FROM usuarios WHERE id=$1 AND clinica_id=$2`, [outroId, req.usuario.clinicaId])).rows[0];
  if (!o || o.id === eu(req)) return { erro: 'Pessoa não encontrada.', status: 404 };
  if (souMaster(req) && EQUIPE.includes(o.papel)) return { masterId: eu(req), membroId: o.id, outro: o };
  if (souEquipe(req) && o.papel === 'admin') return { masterId: o.id, membroId: eu(req), outro: o };
  return { erro: 'Essa conversa não é permitida.', status: 403 };
}
const abrir = (t) => { try { return cripto.decifrar(t); } catch (e) { return '(mensagem trancada com outra chave)'; } };
const formatar = (m, meuId) => ({
  id: Number(m.id), autor_id: m.autor_id, meu: m.autor_id === meuId, texto: abrir(m.texto), criado_em: m.criado_em, editado_em: m.editado_em, lida_em: m.lida_em,
  pode_corrigir: m.autor_id === meuId && Date.now() - new Date(m.criado_em).getTime() < PRAZO_CORRIGIR_MS,
});
async function auditar(req, registro, caminho) {
  await pool.query(`INSERT INTO auditoria_telas (clinica_id, usuario_id, usuario_nome, papel, tela, acao, registro_id, ip, aparelho, caminho, metodo)
    VALUES ($1,$2,$3,$4,'conversa','ver',$5,$6,$7,$8,$9)`,
  [req.usuario.clinicaId, eu(req), req.usuario.nome || null, req.usuario.papel, String(registro).slice(0, 60), String(req.ip || '').slice(0, 60), String(req.get('user-agent') || '').slice(0, 200), caminho, req.method]).catch(() => {});
}

/* com quem eu posso conversar, com o número de mensagens não lidas */
router.get('/contatos', async (req, res) => {
  const meu = eu(req);
  const r = souMaster(req)
    ? await pool.query(
      `SELECT u.id, u.nome, u.papel, u.ativo, c.id AS conversa_id, c.ultima_em,
         (SELECT COUNT(*)::int FROM conversas_mensagens m WHERE m.conversa_id = c.id AND m.autor_id = u.id AND m.lida_em IS NULL) AS nao_lidas
       FROM usuarios u LEFT JOIN conversas_equipe c ON c.membro_id = u.id AND c.master_id = $2
       WHERE u.clinica_id = $1 AND u.papel = ANY($3) AND (u.ativo OR c.id IS NOT NULL)
       ORDER BY (c.ultima_em IS NULL), c.ultima_em DESC, u.nome`, [req.usuario.clinicaId, meu, EQUIPE])
    : await pool.query(
      `SELECT u.id, u.nome, u.papel, u.ativo, c.id AS conversa_id, c.ultima_em,
         (SELECT COUNT(*)::int FROM conversas_mensagens m WHERE m.conversa_id = c.id AND m.autor_id = u.id AND m.lida_em IS NULL) AS nao_lidas
       FROM usuarios u LEFT JOIN conversas_equipe c ON c.master_id = u.id AND c.membro_id = $2
       WHERE u.clinica_id = $1 AND u.papel = 'admin' AND (u.ativo OR c.id IS NOT NULL)
       ORDER BY (c.ultima_em IS NULL), c.ultima_em DESC, u.nome`, [req.usuario.clinicaId, meu]);
  res.setHeader('Cache-Control', 'no-store');
  res.json(r.rows.map((x) => ({ id: x.id, nome: x.nome, papel: x.papel, ativo: x.ativo, ultima_em: x.ultima_em, nao_lidas: x.nao_lidas || 0 })));
});

/* total de não lidas, para o aviso no menu */
router.get('/nao-lidas', async (req, res) => {
  const r = await pool.query(
    `SELECT COUNT(*)::int AS n FROM conversas_mensagens m JOIN conversas_equipe c ON c.id = m.conversa_id
     WHERE c.clinica_id = $1 AND (c.master_id = $2 OR c.membro_id = $2) AND m.autor_id <> $2 AND m.lida_em IS NULL`, [req.usuario.clinicaId, eu(req)]);
  res.setHeader('Cache-Control', 'no-store');
  res.json({ total: r.rows[0].n });
});

/* mensagens da conversa com uma pessoa (as novas depois de ?depois=id). Abrir marca como lidas. */
router.get('/com/:uid', async (req, res) => {
  const p = await par(req, req.params.uid);
  if (p.erro) return res.status(p.status).json({ erro: p.erro });
  const c = (await pool.query(`SELECT id FROM conversas_equipe WHERE master_id=$1 AND membro_id=$2 AND clinica_id=$3`, [p.masterId, p.membroId, req.usuario.clinicaId])).rows[0];
  const depois = /^\d{1,18}$/.test(String(req.query.depois || '')) ? req.query.depois : null;
  if (!depois) await auditar(req, p.outro.id, '/conversas/com');
  vendo.set(eu(req) + '|' + p.outro.id, Date.now());
  res.setHeader('Cache-Control', 'no-store');
  if (!c) return res.json({ outro: { id: p.outro.id, nome: p.outro.nome, papel: p.outro.papel, ativo: p.outro.ativo }, mensagens: [] });
  const r = depois
    ? await pool.query(`SELECT * FROM conversas_mensagens WHERE conversa_id=$1 AND (id > $2 OR editado_em > NOW() - INTERVAL '6 minutes') ORDER BY id`, [c.id, depois])
    : await pool.query(`SELECT * FROM (SELECT * FROM conversas_mensagens WHERE conversa_id=$1 ORDER BY id DESC LIMIT 300) x ORDER BY id`, [c.id]);
  await pool.query(`UPDATE conversas_mensagens SET lida_em = NOW() WHERE conversa_id=$1 AND autor_id=$2 AND lida_em IS NULL`, [c.id, p.outro.id]);
  /* o "lida" das minhas mensagens, para mostrar o visto */
  const vistas = (await pool.query(`SELECT MAX(id) AS id FROM conversas_mensagens WHERE conversa_id=$1 AND autor_id=$2 AND lida_em IS NOT NULL`, [c.id, eu(req)])).rows[0].id;
  res.json({ outro: { id: p.outro.id, nome: p.outro.nome, papel: p.outro.papel, ativo: p.outro.ativo }, mensagens: r.rows.map((m) => formatar(m, eu(req))), vista_ate: vistas ? Number(vistas) : 0 });
});

router.post('/com/:uid', async (req, res) => {
  const p = await par(req, req.params.uid);
  if (p.erro) return res.status(p.status).json({ erro: p.erro });
  if (!p.outro.ativo) return res.status(400).json({ erro: 'Essa pessoa está com o acesso bloqueado. A conversa fica só para leitura.' });
  const texto = String((req.body || {}).texto || '').trim();
  if (!texto) return res.status(400).json({ erro: 'Escreva a mensagem.' });
  if (texto.length > 2000) return res.status(400).json({ erro: 'Mensagem grande demais. Divida em partes de até 2000 letras.' });
  const t = envios.get(eu(req)), agora = Date.now();
  if (!t || agora - t.inicio > 60000) envios.set(eu(req), { inicio: agora, n: 1 });
  else if (++t.n > 30) return res.status(429).json({ erro: 'Muitas mensagens seguidas. Espere um minuto.' });
  const c = (await pool.query(
    `INSERT INTO conversas_equipe (clinica_id, master_id, membro_id) VALUES ($1,$2,$3)
     ON CONFLICT (master_id, membro_id) DO UPDATE SET ultima_em = NOW() RETURNING id`, [req.usuario.clinicaId, p.masterId, p.membroId])).rows[0];
  const m = (await pool.query(`INSERT INTO conversas_mensagens (clinica_id, conversa_id, autor_id, texto) VALUES ($1,$2,$3,$4) RETURNING *`,
    [req.usuario.clinicaId, c.id, eu(req), cripto.cifrar(texto)])).rows[0];
  res.status(201).json(formatar(m, eu(req)));
  const dest = p.outro.id, aberta = vendo.get(dest + '|' + eu(req));
  if (!aberta || Date.now() - aberta > 25000) {
    avisoPush.enviarParaUsuario(dest, { titulo: 'Nova mensagem', corpo: `Nova mensagem de ${req.usuario.nome || 'alguém da clínica'}. Toque para abrir.`, url: '/modulo-agendamento.html#conversa=' + eu(req), tag: 'conv-' + eu(req) });
  }
});

/* corrigir a própria mensagem em até 5 minutos */
router.put('/mensagens/:id', async (req, res) => {
  if (!/^\d{1,18}$/.test(req.params.id)) return res.status(400).json({ erro: 'Mensagem inválida.' });
  const texto = String((req.body || {}).texto || '').trim();
  if (!texto || texto.length > 2000) return res.status(400).json({ erro: 'Escreva a mensagem (até 2000 letras).' });
  const m = (await pool.query(`SELECT * FROM conversas_mensagens WHERE id=$1 AND clinica_id=$2`, [req.params.id, req.usuario.clinicaId])).rows[0];
  if (!m || m.autor_id !== eu(req)) return res.status(404).json({ erro: 'Mensagem não encontrada.' });
  if (Date.now() - new Date(m.criado_em).getTime() > PRAZO_CORRIGIR_MS) return res.status(400).json({ erro: 'Passou o prazo de 5 minutos para corrigir. Mande uma mensagem nova.' });
  const r = (await pool.query(`UPDATE conversas_mensagens SET texto=$1, editado_em=NOW() WHERE id=$2 RETURNING *`, [cripto.cifrar(texto), m.id])).rows[0];
  res.json(formatar(r, eu(req)));
});

/* ---------- sindicância: só o dono abre a conversa de outro Master, com motivo ---------- */
async function souDono(req) {
  if (!souMaster(req)) return false;
  const r = await pool.query(`SELECT id FROM usuarios WHERE clinica_id=$1 AND papel='admin' ORDER BY criado_em, id LIMIT 1`, [req.usuario.clinicaId]);
  return r.rows.length && r.rows[0].id === eu(req);
}
router.get('/sindicancia', async (req, res) => {
  if (!(await souDono(req))) return res.status(403).json({ erro: 'Só o dono da clínica abre conversa de outro Master.' });
  const r = await pool.query(
    `SELECT c.id, c.ultima_em, um.nome AS master_nome, ue.nome AS membro_nome, (SELECT COUNT(*)::int FROM conversas_mensagens m WHERE m.conversa_id=c.id) AS qtd
     FROM conversas_equipe c JOIN usuarios um ON um.id = c.master_id JOIN usuarios ue ON ue.id = c.membro_id
     WHERE c.clinica_id=$1 AND c.master_id <> $2 ORDER BY c.ultima_em DESC`, [req.usuario.clinicaId, eu(req)]);
  res.json(r.rows);
});
router.post('/sindicancia/:conversaId', async (req, res) => {
  if (!(await souDono(req))) return res.status(403).json({ erro: 'Só o dono da clínica abre conversa de outro Master.' });
  if (!UUID.test(req.params.conversaId)) return res.status(400).json({ erro: 'Conversa inválida.' });
  const motivo = String((req.body || {}).motivo || '').trim();
  if (motivo.length < 10) return res.status(400).json({ erro: 'Escreva o motivo da sindicância (pelo menos 10 letras). Ele fica registrado na auditoria.' });
  const c = (await pool.query(`SELECT c.*, um.nome AS master_nome, ue.nome AS membro_nome FROM conversas_equipe c JOIN usuarios um ON um.id=c.master_id JOIN usuarios ue ON ue.id=c.membro_id
    WHERE c.id=$1 AND c.clinica_id=$2 AND c.master_id <> $3`, [req.params.conversaId, req.usuario.clinicaId, eu(req)])).rows[0];
  if (!c) return res.status(404).json({ erro: 'Conversa não encontrada.' });
  await auditar(req, c.id, '/conversas/sindicancia');
  await pool.query(`INSERT INTO acessos_log (clinica_id, usuario_id, usuario_nome, acao, area, caminho, ip) VALUES ($1,$2,$3,'SINDIC','conversa',$4,$5)`,
    [req.usuario.clinicaId, eu(req), req.usuario.nome || null, `Conversa ${c.master_nome} e ${c.membro_nome}. Motivo: ${motivo}`.slice(0, 200), req.ip]).catch(() => {});
  const r = await pool.query(`SELECT * FROM conversas_mensagens WHERE conversa_id=$1 ORDER BY id`, [c.id]);
  res.json({ master: c.master_nome, membro: c.membro_nome, master_id: c.master_id,
    mensagens: r.rows.map((m) => ({ ...formatar(m, null), autor: m.autor_id === c.master_id ? c.master_nome : c.membro_nome, pode_corrigir: false })) });
});

module.exports = router;
