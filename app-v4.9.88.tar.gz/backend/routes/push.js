/* ===== v4.9.49: ligar e desligar o aviso de mensagem nova neste aparelho ===== */
const express = require('express');
const pool = require('../db/pool');
const { exigirLogin } = require('../middleware/auth');
const aviso = require('../utils/avisoPush');
const { nomeAparelho } = require('../utils/aparelhos');

const router = express.Router();
router.use(exigirLogin);
const eu = (req) => req.usuario.usuarioId || req.usuario.id;
const MAX_POR_PESSOA = 10;
const endpointValido = (e) => typeof e === 'string' && e.length <= 1000 && /^https:\/\/[a-z0-9.-]+(:\d+)?\//i.test(e);
const chaveValida = (k) => typeof k === 'string' && /^[A-Za-z0-9_-]{10,200}=*$/.test(k);

router.get('/chave', async (req, res) => { res.json({ publica: await aviso.chavePublica() }); });

router.post('/inscrever', async (req, res) => {
  const b = req.body || {}, k = b.keys || {};
  if (!endpointValido(b.endpoint) || !chaveValida(k.p256dh) || !chaveValida(k.auth)) return res.status(400).json({ erro: 'Aparelho não aceitou o aviso. Tente de novo.' });
  await pool.query(
    `INSERT INTO push_inscricoes (clinica_id, usuario_id, endpoint, p256dh, auth, aparelho) VALUES ($1,$2,$3,$4,$5,$6)
     ON CONFLICT (endpoint) DO UPDATE SET clinica_id=EXCLUDED.clinica_id, usuario_id=EXCLUDED.usuario_id, p256dh=EXCLUDED.p256dh, auth=EXCLUDED.auth, aparelho=EXCLUDED.aparelho, criado_em=NOW(), falhas=0`,
    [req.usuario.clinicaId, eu(req), b.endpoint, k.p256dh, k.auth, nomeAparelho(req.get('user-agent'))]);
  await pool.query(`DELETE FROM push_inscricoes WHERE usuario_id=$1 AND id NOT IN (SELECT id FROM push_inscricoes WHERE usuario_id=$1 ORDER BY criado_em DESC LIMIT ${MAX_POR_PESSOA})`, [eu(req)]);
  res.json({ ok: true });
});

router.post('/sair', async (req, res) => {
  const e = (req.body || {}).endpoint;
  if (endpointValido(e)) await pool.query(`DELETE FROM push_inscricoes WHERE endpoint=$1 AND usuario_id=$2`, [e, eu(req)]);
  res.json({ ok: true });
});

module.exports = router;
