/* v4.9.36: varredura anti injeção de SQL. Rode com: node backend/scripts/varrer-sql.js
   Procura consultas (query/pool.query/client.query) cujo texto tenha ${...} com dado que veio da tela
   (req.body, req.query, req.params) ou variável sem passar por número. Sai com erro se achar. */
const fs = require('fs'), path = require('path');
const raiz = path.join(__dirname, '..');
const pastas = ['routes', 'utils', 'middleware', 'db'];
const PERIGO = /\$\{[^}]*\breq\.(body|query|params|headers)\b[^}]*\}/;
let achados = 0, consultas = 0;
for (const p of pastas) {
  for (const arq of fs.readdirSync(path.join(raiz, p)).filter((f) => f.endsWith('.js'))) {
    const txt = fs.readFileSync(path.join(raiz, p, arq), 'utf8');
    const re = /\.query\(\s*`([\s\S]*?)`/g; let m;
    while ((m = re.exec(txt))) {
      consultas++;
      if (PERIGO.test(m[1])) {
        achados++;
        const linha = txt.slice(0, m.index).split('\n').length;
        console.log(`PERIGO ${p}/${arq}:${linha}  ${m[1].match(PERIGO)[0]}`);
      }
    }
  }
}
console.log(`${consultas} consultas conferidas, ${achados} com dado da tela dentro do texto.`);
process.exit(achados ? 1 : 0);
