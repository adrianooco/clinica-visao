const pool = require('../db/pool');
const crypto = require('crypto');

/* v4.9.35: ações que a IA prepara e o Master confirma.
   A IA só sugere o tipo e os dados. Aqui o servidor confere tudo, troca nomes por cadastros reais
   e monta os passos. Quem executa é a tela, chamando as mesmas rotas de sempre com o login de quem confirmou,
   então todas as permissões continuam valendo. Nada aqui apaga dado. */

const sem = (t) => String(t || '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().trim();
const DIA = /^\d{4}-\d{2}-\d{2}$/, HORA = /^\d{2}:\d{2}$/;
const fmtDia = (d) => d.split('-').reverse().join('/');
const TIPOS = {
  cadastrar_cidade: ['admin'], abrir_agenda: ['admin'], criar_agendador: ['admin'],
  marcar_exame: ['admin', 'profissional'], remarcar_exame: ['admin', 'profissional'], cancelar_exame: ['admin', 'profissional'],
  lista_espera: ['admin', 'profissional'], cobrar_cliente: ['admin'],
};

/* e-mail e telefone nunca vão para a IA; o servidor tira da mensagem original de quem pediu */
function contatosDaConversa(bruto) {
  const textos = (bruto || []).filter((m) => m && m.papel !== 'ia').slice(-4).map((m) => String(m.texto || '')).reverse();
  let email = null, telefone = null;
  for (const t of textos) {
    if (!email) { const e = /[\w.+-]+@[\w-]+\.[\w.-]+/.exec(t); if (e) email = e[0].toLowerCase(); }
    if (!telefone) { const f = /(\+?55\s?)?\(?\d{2}\)?\s?9?\d{4}[-\s]?\d{4}\b/.exec(t); if (f) telefone = f[0].replace(/\D/g, '').replace(/^55(?=\d{10,11}$)/, ''); }
  }
  return { email, telefone };
}

async function acharCidade(clinicaId, nome) {
  const r = await pool.query(`SELECT id, nome, cidade FROM unidades WHERE clinica_id=$1 AND ativa=TRUE`, [clinicaId]);
  const n = sem(nome);
  if (!n) return { erro: 'Diga o nome da cidade.' };
  const exatas = r.rows.filter((u) => sem(u.cidade) === n || sem(u.nome) === n);
  const achou = exatas.length ? exatas : r.rows.filter((u) => sem(u.cidade).includes(n) || sem(u.nome).includes(n));
  if (!achou.length) return { erro: `Não achei a cidade ${nome} no cadastro.` };
  if (achou.length > 1) return { erro: `Achei mais de uma cidade parecida com ${nome}: ${achou.map((u) => u.cidade || u.nome).join(', ')}. Diga qual.` };
  return { id: achou[0].id, nome: achou[0].cidade || achou[0].nome };
}

async function acharPaciente(clinicaId, nome) {
  const n = String(nome || '').trim();
  if (n.length < 3) return { erro: 'Diga o nome do paciente.' };
  const r = await pool.query(`SELECT id, nome_completo, telefone FROM pacientes WHERE clinica_id=$1 AND deletado_em IS NULL AND nome_completo ILIKE $2 ORDER BY nome_completo LIMIT 6`,
    [clinicaId, '%' + n.replace(/[%_]/g, '') + '%']);
  if (!r.rows.length) return { nenhum: true };
  if (r.rows.length > 1) {
    const igual = r.rows.filter((p) => sem(p.nome_completo) === sem(n));
    if (igual.length === 1) return { id: igual[0].id, nome: igual[0].nome_completo, telefone: igual[0].telefone };
    return { erro: `Achei ${r.rows.length} pacientes com esse nome: ${r.rows.map((p) => p.nome_completo).join(', ')}. Diga o nome completo.` };
  }
  return { id: r.rows[0].id, nome: r.rows[0].nome_completo, telefone: r.rows[0].telefone };
}

async function tipoPadrao(clinicaId) {
  const r = await pool.query(`SELECT id, nome FROM tipos_atendimento WHERE clinica_id=$1 AND COALESCE(ativo,TRUE) ORDER BY criado_em NULLS LAST LIMIT 1`, [clinicaId]).catch(() => pool.query(`SELECT id, nome FROM tipos_atendimento WHERE clinica_id=$1 LIMIT 1`, [clinicaId]));
  return r.rows[0] || null;
}

async function proximoExame(clinicaId, pacienteId, dia) {
  const p = [clinicaId, pacienteId]; let f = '';
  if (dia && DIA.test(dia)) { p.push(dia); f = ' AND a.data_hora::date = $3'; }
  const r = await pool.query(`SELECT a.id, a.data_hora, a.tipo_atendimento_id, a.local, a.agendado_por, a.status, a.observacoes, a.unidade_id
    FROM agendamentos a WHERE a.clinica_id=$1 AND a.paciente_id=$2 AND a.status IN ('agendado','confirmado')
      AND a.data_hora >= (NOW() AT TIME ZONE 'America/Sao_Paulo') - INTERVAL '1 day'${f} ORDER BY a.data_hora LIMIT 2`, p);
  return r.rows;
}

function senhaProvisoria() {
  const a = 'abcdefghjkmnpqrstuvwxyzABCDEFGHJKMNPQRSTUVWXYZ', d = '23456789';
  let s = ''; for (let i = 0; i < 8; i++) s += a[crypto.randomInt(a.length)];
  return s + d[crypto.randomInt(d.length)] + d[crypto.randomInt(d.length)];
}

async function preparar(tipo, dadosIA, req, bruto) {
  const papel = req.usuario.papel, clinica = req.usuario.clinicaId;
  if (!TIPOS[tipo]) return { erro: 'Essa ação não existe.' };
  if (!TIPOS[tipo].includes(papel)) return { erro: 'Essa ação é só do Master.' };
  const d = dadosIA && typeof dadosIA === 'object' ? dadosIA : {};
  const contato = contatosDaConversa(bruto);

  if (tipo === 'cadastrar_cidade') {
    const cidade = String(d.cidade || '').trim().slice(0, 80);
    if (cidade.length < 2) return { erro: 'Diga o nome da cidade.' };
    const ja = await acharCidade(clinica, cidade);
    if (ja.id) return { erro: `A cidade ${ja.nome} já está cadastrada.` };
    const passos = [{ metodo: 'POST', caminho: '/unidades', corpo: { nome: cidade, cidade, local: String(d.local || '').slice(0, 150) || undefined } }];
    let rot = `Cadastrar a cidade ${cidade}${d.local ? ', local ' + String(d.local).slice(0, 60) : ''}`;
    if (DIA.test(d.data || '') && HORA.test(d.hora_inicio || '') && HORA.test(d.hora_fim || '')) {
      const t = await tipoPadrao(clinica); if (!t) return { erro: 'Cadastre antes um tipo de atendimento.' };
      passos.push({ metodo: 'POST', caminho: '/agendas', corpo: { unidade_id: '$anterior.id', data: d.data, data_fim: DIA.test(d.data_fim || '') ? d.data_fim : undefined, hora_inicio: d.hora_inicio, hora_fim: d.hora_fim, tipo_atendimento_id: t.id } });
      rot += ` e abrir horários ${DIA.test(d.data_fim || '') ? `de ${fmtDia(d.data)} a ${fmtDia(d.data_fim)}` : `em ${fmtDia(d.data)}`}, das ${d.hora_inicio} às ${d.hora_fim}`;
    }
    return { rotulo: rot, passos, pronto: 'Pronto, cidade cadastrada.' };
  }

  if (tipo === 'abrir_agenda') {
    const c = await acharCidade(clinica, d.cidade); if (c.erro) return c;
    if (!DIA.test(d.data || '') || !HORA.test(d.hora_inicio || '') || !HORA.test(d.hora_fim || '')) return { erro: 'Diga o dia e o horário de início e fim.' };
    const t = await tipoPadrao(clinica); if (!t) return { erro: 'Cadastre antes um tipo de atendimento.' };
    const fim = DIA.test(d.data_fim || '') ? d.data_fim : null;
    return { rotulo: `Abrir horários em ${c.nome} ${fim ? `de ${fmtDia(d.data)} a ${fmtDia(fim)}` : `em ${fmtDia(d.data)}`}, das ${d.hora_inicio} às ${d.hora_fim}`,
      passos: [{ metodo: 'POST', caminho: '/agendas', corpo: { unidade_id: c.id, data: d.data, data_fim: fim || undefined, hora_inicio: d.hora_inicio, hora_fim: d.hora_fim, tipo_atendimento_id: t.id } }],
      pronto: 'Pronto, horários abertos.' };
  }

  if (tipo === 'criar_agendador') {
    const nome = String(d.nome || '').trim().slice(0, 120);
    if (nome.length < 3) return { erro: 'Diga o nome do agendador.' };
    if (!contato.email) return { erro: 'Escreva o e-mail do agendador na mensagem. Ele não vai para a IA, o sistema lê direto.' };
    const c = await acharCidade(clinica, d.cidade); if (c.erro) return c;
    const ja = await pool.query(`SELECT 1 FROM usuarios WHERE LOWER(email)=$1`, [contato.email]);
    if (ja.rows.length) return { erro: 'Já existe um usuário com esse e-mail.' };
    const senha = senhaProvisoria();
    return { rotulo: `Criar o agendador ${nome} (${contato.email.replace(/(^.).*(@.*$)/, '$1***$2')}) na cidade ${c.nome}, com senha provisória`,
      passos: [{ metodo: 'POST', caminho: '/clinica/usuarios', corpo: { nome, email: contato.email, senha, papel: 'atendente', unidade_id: c.id } }],
      pronto: `Pronto, agendador criado. Senha provisória: ${senha}. Mande para ${nome.split(' ')[0]} e peça para trocar no primeiro acesso.`, privado: true };
  }

  if (tipo === 'marcar_exame') {
    const c = await acharCidade(clinica, d.cidade); if (c.erro) return c;
    if (!DIA.test(d.data || '') || !HORA.test(d.hora || '')) return { erro: 'Diga o dia e a hora do exame.' };
    const p = await acharPaciente(clinica, d.paciente); if (p.erro) return p;
    const livre = await pool.query(`SELECT 1 FROM agendamentos WHERE clinica_id=$1 AND unidade_id=$2 AND data_hora=$3::timestamp AND status <> 'cancelado'`, [clinica, c.id, `${d.data} ${d.hora}`]);
    if (livre.rows.length) return { erro: `O horário das ${d.hora} de ${fmtDia(d.data)} em ${c.nome} já está ocupado.` };
    const aberto = await pool.query(`SELECT tipo_atendimento_id FROM agendas WHERE clinica_id=$1 AND unidade_id=$2 AND ativa AND data=$3 AND hora_inicio <= $4::time AND hora_fim > $4::time LIMIT 1`, [clinica, c.id, d.data, d.hora]);
    if (!aberto.rows.length) return { erro: `Não há horário aberto em ${c.nome} no dia ${fmtDia(d.data)} às ${d.hora}. Abra a agenda primeiro.` };
    const corpoAg = { paciente_id: p.id || '$anterior.id', unidade_id: c.id, data_hora: `${d.data}T${d.hora}`, tipo_atendimento_id: aberto.rows[0].tipo_atendimento_id, agendado_por: 'IA (confirmado pelo ' + (req.usuario.nome || 'Master') + ')' };
    if (p.nenhum) {
      if (!contato.telefone) return { erro: `Não achei ${d.paciente} no cadastro. Para cadastrar, escreva também o telefone dele na mensagem.` };
      const nomeNovo = String(d.paciente).trim().slice(0, 150);
      return { rotulo: `Cadastrar ${nomeNovo} e marcar o exame em ${c.nome}, ${fmtDia(d.data)} às ${d.hora}`,
        passos: [{ metodo: 'POST', caminho: '/pacientes', corpo: { nome_completo: nomeNovo, telefone: contato.telefone, agendado_por: 'IA' } }, { metodo: 'POST', caminho: '/agendamentos', corpo: corpoAg }],
        pronto: 'Pronto, paciente cadastrado e exame marcado.' };
    }
    return { rotulo: `Marcar o exame de ${p.nome} em ${c.nome}, ${fmtDia(d.data)} às ${d.hora}`, passos: [{ metodo: 'POST', caminho: '/agendamentos', corpo: corpoAg }], pronto: 'Pronto, exame marcado.' };
  }

  if (tipo === 'remarcar_exame' || tipo === 'cancelar_exame') {
    const p = await acharPaciente(clinica, d.paciente); if (p.erro) return p;
    if (p.nenhum) return { erro: `Não achei ${d.paciente} no cadastro.` };
    const ex = await proximoExame(clinica, p.id, d.data_atual);
    if (!ex.length) return { erro: `${p.nome} não tem exame marcado${d.data_atual ? ' nesse dia' : ''}.` };
    if (ex.length > 1 && !d.data_atual) return { erro: `${p.nome} tem mais de um exame marcado. Diga de qual dia.` };
    const a = ex[0], quando = `${fmtDia(String(a.data_hora).slice(0, 10))} às ${String(a.data_hora).slice(11, 16)}`;
    if (tipo === 'cancelar_exame') return { rotulo: `Cancelar o exame de ${p.nome} de ${quando}`, passos: [{ metodo: 'PATCH', caminho: `/agendamentos/${a.id}/status`, corpo: { status: 'cancelado' } }], pronto: 'Pronto, exame cancelado. O horário ficou livre.' };
    if (!DIA.test(d.nova_data || '') || !HORA.test(d.nova_hora || '')) return { erro: 'Diga o novo dia e a nova hora.' };
    const livre = await pool.query(`SELECT 1 FROM agendamentos WHERE clinica_id=$1 AND unidade_id IS NOT DISTINCT FROM $2 AND data_hora=$3::timestamp AND status <> 'cancelado' AND id <> $4`, [clinica, a.unidade_id, `${d.nova_data} ${d.nova_hora}`, a.id]);
    if (livre.rows.length) return { erro: `O horário das ${d.nova_hora} de ${fmtDia(d.nova_data)} já está ocupado.` };
    return { rotulo: `Remarcar o exame de ${p.nome} de ${quando} para ${fmtDia(d.nova_data)} às ${d.nova_hora}`,
      passos: [{ metodo: 'PUT', caminho: `/agendamentos/${a.id}`, corpo: { paciente_id: p.id, tipo_atendimento_id: a.tipo_atendimento_id, data_hora: `${d.nova_data}T${d.nova_hora}`, local: a.local, agendado_por: a.agendado_por, status: 'agendado', observacoes: a.observacoes } }],
      pronto: 'Pronto, exame remarcado.' };
  }

  if (tipo === 'lista_espera') {
    const nome = String(d.nome || d.paciente || '').trim().slice(0, 150);
    if (nome.length < 3) return { erro: 'Diga o nome de quem vai para a lista de espera.' };
    let c = null; if (d.cidade) { c = await acharCidade(clinica, d.cidade); if (c.erro) return c; }
    return { rotulo: `Pôr ${nome} na lista de espera${c ? ' de ' + c.nome : ''}${contato.telefone ? ' com o telefone informado' : ''}`,
      passos: [{ metodo: 'POST', caminho: '/lista-espera', corpo: { nome, telefone: contato.telefone || undefined, unidade_id: c ? c.id : undefined, observacao: String(d.observacao || '').slice(0, 200) || undefined } }],
      pronto: 'Pronto, está na lista de espera.' };
  }

  if (tipo === 'cobrar_cliente') {
    const n = String(d.cliente || d.nome || '').trim();
    if (n.length < 3) return { erro: 'Diga o nome do cliente.' };
    const r = await pool.query(`SELECT cliente_nome, cliente_tel, SUM(valor)::float AS total, SUM(valor) FILTER (WHERE vencimento < (NOW() AT TIME ZONE 'America/Sao_Paulo')::date)::float AS vencido
      FROM contas_receber WHERE clinica_id=$1 AND removido_em IS NULL AND pago_em IS NULL AND cliente_nome ILIKE $2 GROUP BY 1,2 LIMIT 3`, [clinica, '%' + n.replace(/[%_]/g, '') + '%']);
    if (!r.rows.length) return { erro: `${n} não tem conta em aberto na OCO.` };
    if (r.rows.length > 1) return { erro: `Achei mais de um cliente: ${r.rows.map((x) => x.cliente_nome).join(', ')}. Diga o nome completo.` };
    const x = r.rows[0];
    if (!x.cliente_tel) return { erro: `${x.cliente_nome} não tem telefone no cadastro da OCO.` };
    const v = x.vencido || x.total;
    return { rotulo: `Abrir o WhatsApp para cobrar ${x.cliente_nome}: R$ ${v.toFixed(2).replace('.', ',')}${x.vencido ? ' vencido' : ''}`,
      passos: [{ metodo: 'WHATSAPP', telefone: x.cliente_tel, valor: v, nome: x.cliente_nome, vencido: !!x.vencido }], pronto: 'Abri a mensagem de cobrança no WhatsApp. Confira e envie.' };
  }
  return { erro: 'Ação não reconhecida.' };
}

module.exports = { TIPOS, preparar };
