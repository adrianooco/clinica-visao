/* ===== v4.9.53: lembretes de cobrança do crediário próprio da ótica (OCO) =====
   Mesma regra da tela Financeiro da OCO:
     3 dias antes do vencimento, 1 e 3 dias depois, no último dia da tolerância (padrão 5) e,
     depois, a cada 48 horas até pagar.
   Todo dia, a partir das 8h (horário de Brasília), uma vez por clínica:
     1) o Master recebe aviso no celular com quantos lembretes há para hoje;
     2) se LEMBRETES_COBRANCA_WHATSAPP=sim e o WhatsApp oficial estiver ligado (WA_TOKEN, WA_PHONE_ID, WA_TEMPLATE),
        o servidor manda cada lembrete sozinho e registra em regua_mensagens (não repete no mesmo dia).
   Os dados do histórico do sistema antigo não entram aqui: são só registro interno. */
const pool = require('../db/pool');
const cripto = require('./cripto');
const avisoPush = require('./avisoPush');
const whatsapp = require('./whatsapp');

const FUSO = 'America/Sao_Paulo';
const diaBrasilia = (d = new Date()) => new Intl.DateTimeFormat('en-CA', { timeZone: FUSO, year: 'numeric', month: '2-digit', day: '2-digit' }).format(d);
const horaBrasilia = (d = new Date()) => Number(new Intl.DateTimeFormat('en-GB', { timeZone: FUSO, hour: '2-digit', hour12: false }).format(d));
const diasEntre = (de, ate) => Math.round((new Date(ate + 'T12:00:00Z') - new Date(de + 'T12:00:00Z')) / 86400000);
const fmtData = (iso) => { const [a, m, d] = String(iso).split('-'); return `${d}/${m}/${a}`; };
const fmtMoeda = (v) => 'R$ ' + Number(v || 0).toFixed(2).replace('.', ',').replace(/\B(?=(\d{3})+(?!\d),)/g, '.');

function tolerancia(loja) { const t = parseInt(loja && loja.toleranciaDias, 10); return isNaN(t) ? 5 : Math.max(0, Math.min(30, t)); }
function etapa(x, dia, tol) {
  if (!x || x.status !== 'pendente' || !/^\d{4}-\d{2}-\d{2}$/.test(String(x.vencimento || ''))) return null;
  if (x.cheque && !x.cheque.devolvido) return null; // v4.9.54: cheque só entra na cobrança se o banco devolver
  const depois = diasEntre(x.vencimento, dia);
  if (depois === -3) return 'antes3';
  if (depois >= 1 && depois < tol) return depois === 1 ? 'dep1' : depois === 3 ? 'dep3' : null;
  if (depois === tol && tol >= 1) return 'dep5';
  if (depois > tol && (depois - tol) % 2 === 0) return 'juros';
  return null;
}
function valorAtual(x, loja, dia) {
  const atraso = diasEntre(x.vencimento, dia);
  if (atraso <= tolerancia(loja)) return Number(x.valor) || 0;
  const v = Number(x.valor) || 0;
  return v + v * ((Number(loja.multaAtraso) || 0) / 100) + v * ((Number(loja.jurosAoMes) || 0) / 100 / 30) * atraso;
}
function chaveParaLer(loja) {
  const k = String(loja.chavePix || '').trim();
  if ((loja.tipoChavePix || 'celular') === 'celular') { const d = k.replace(/\D/g, '').replace(/^55(?=\d{10,11}$)/, ''); return d.length === 11 ? `(${d.slice(0, 2)}) ${d.slice(2, 7)}-${d.slice(7)}` : k; }
  return k;
}
const NOME_TIPO = { celular: 'celular', cpf: 'CPF/CNPJ', email: 'e-mail', aleatoria: 'chave aleatória' };
function mensagem(x, et, cliente, loja, dia) {
  const nome = String(cliente.nome || '').split(' ')[0] || 'tudo bem';
  const nomeLoja = loja.nome || 'a ótica';
  const pix = loja.chavePix ? ` Pague pelo Pix: chave ${NOME_TIPO[loja.tipoChavePix || 'celular']} ${chaveParaLer(loja)}.` : '';
  const parc = `a parcela ${x.parcelaNum}/${x.parcelaTotal}`, Parc = 'A' + parc.slice(1);
  const ate = (() => { const d = new Date(x.vencimento + 'T12:00:00Z'); d.setUTCDate(d.getUTCDate() + tolerancia(loja)); return d.toISOString().slice(0, 10); })();
  if (et === 'antes3') return `Olá, ${nome}! Aqui é da ${nomeLoja}. Passando para lembrar que ${parc} do seu carnê vence em ${fmtData(x.vencimento)}, no valor de ${fmtMoeda(x.valor)}.${pix} Se já pagou, desconsidere. Obrigado!`;
  if (et === 'dep1' || et === 'dep3') return `Olá, ${nome}! Aqui é da ${nomeLoja}. ${Parc} do seu carnê venceu em ${fmtData(x.vencimento)} e ainda consta em aberto, no valor de ${fmtMoeda(x.valor)}. Pagando até ${fmtData(ate)}, não tem juros.${pix} Se já pagou, nos avise para darmos baixa. Obrigado!`;
  if (et === 'dep5') return `Olá, ${nome}! Aqui é da ${nomeLoja}. Hoje é o último dia para pagar ${parc} do seu carnê, vencida em ${fmtData(x.vencimento)}, sem juros: ${fmtMoeda(x.valor)}. A partir de amanhã entram multa e juros.${pix} Se já pagou, nos avise. Obrigado!`;
  return `Olá, ${nome}! Aqui é da ${nomeLoja}. ${Parc} do seu carnê, vencida em ${fmtData(x.vencimento)}, está em aberto há ${diasEntre(x.vencimento, dia)} dias. Valor atualizado com multa de ${loja.multaAtraso || 0}% e juros de ${loja.jurosAoMes || 0}% ao mês: ${fmtMoeda(valorAtual(x, loja, dia))}.${pix} Se já pagou, nos avise para darmos baixa. Podemos combinar?`;
}
function lembretesDoDia(dados, dia) {
  const loja = dados.loja || {}, tol = tolerancia(loja);
  const clientes = new Map((dados.clientes || []).map((c) => [c.id, c]));
  return (dados.contas || []).map((x) => ({ x, et: etapa(x, dia, tol) })).filter((i) => i.et)
    .map((i) => ({ ...i, cliente: clientes.get(i.x.clienteId) || {}, feito: Array.isArray(i.x.lembretes) && i.x.lembretes.includes(dia) }));
}
const autoLigado = () => process.env.LEMBRETES_COBRANCA_WHATSAPP === 'sim' && whatsapp.configurado();

async function rodar(agora = new Date()) {
  const hora = horaBrasilia(agora);
  if (hora < 8 || hora >= 20) return;
  const dia = diaBrasilia(agora);
  const l = (await pool.query(`SELECT clinica_id, dados FROM gestor_vendas_dados`)).rows;
  for (const linha of l) {
    try {
      const pego = await pool.query(`INSERT INTO avisos_diarios (clinica_id, tipo, dia) VALUES ($1,'cobranca',$2) ON CONFLICT DO NOTHING RETURNING clinica_id`, [linha.clinica_id, dia]);
      if (!pego.rows.length) continue;
      const corpo = JSON.parse(cripto.decifrar(linha.dados));
      const lista = lembretesDoDia(corpo.dados || {}, dia).filter((i) => !i.feito);
      if (!lista.length) continue;
      let enviados = 0;
      if (autoLigado()) {
        for (const i of lista) {
          const tel = whatsapp.normalizar(i.cliente.telefone);
          if (!tel) continue;
          const r = await pool.query(`INSERT INTO regua_mensagens (clinica_id, gatilho, referencia_id, telefone, agendada_para) VALUES ($1,$2,$3,$4,NOW())
            ON CONFLICT (clinica_id, gatilho, referencia_id) DO NOTHING RETURNING id`, [linha.clinica_id, 'cob' + dia, String(i.x.id), tel]);
          if (!r.rows.length) continue;
          try {
            await whatsapp.enviarIniciada(tel, mensagem(i.x, i.et, i.cliente, corpo.dados.loja || {}, dia));
            await pool.query(`UPDATE regua_mensagens SET status='enviada', enviada_em=NOW() WHERE id=$1`, [r.rows[0].id]);
            enviados++;
          } catch (e) { await pool.query(`UPDATE regua_mensagens SET status='erro', erro=$2 WHERE id=$1`, [r.rows[0].id, String(e.message).slice(0, 300)]); }
        }
      }
      const faltam = lista.length - enviados;
      const admins = (await pool.query(`SELECT id FROM usuarios WHERE clinica_id=$1 AND papel='admin' AND ativo`, [linha.clinica_id])).rows;
      const corpoAviso = enviados
        ? `O WhatsApp automático mandou ${enviados} lembrete(s) de cobrança hoje.${faltam ? ` Faltam ${faltam} para mandar em Financeiro, na OCO.` : ''}`
        : `Hoje tem ${lista.length} lembrete(s) de cobrança do crediário. Abra a OCO, em Financeiro.`;
      for (const a of admins) avisoPush.enviarParaUsuario(a.id, { titulo: 'Cobrança de hoje', corpo: corpoAviso, url: '/modulo-agendamento.html', tag: 'cobranca-' + dia });
    } catch (e) { console.error('Lembretes de cobrança falharam numa clínica:', e.message); }
  }
}
let timer = null;
function iniciar() {
  if (timer) return;
  const passo = () => rodar().catch((e) => console.error('Lembretes de cobrança:', e.message));
  setTimeout(passo, 60000).unref();
  timer = setInterval(passo, 10 * 60000); timer.unref();
}
async function enviadosHoje(clinicaId) {
  const r = await pool.query(`SELECT referencia_id FROM regua_mensagens WHERE clinica_id=$1 AND gatilho=$2 AND status='enviada'`, [clinicaId, 'cob' + diaBrasilia()]);
  return r.rows.map((x) => Number(x.referencia_id)).filter(Number.isFinite);
}
module.exports = { iniciar, rodar, etapa, mensagem, lembretesDoDia, enviadosHoje, autoLigado, diaBrasilia };
