const pool = require('../db/pool');
const cripto = require('./cripto');

/* v4.9.74: cruza o paciente da clínica com o cliente da ótica (OCO) e diz se ele comprou depois do exame.
   Mesma regra dos ganhos do agendador: CPF; senão, telefone com o mesmo primeiro nome; senão, o nome completo. */
const so = (x) => String(x == null ? '' : x).replace(/\D/g, '');
const semAcento = (t) => String(t || '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().trim();
async function carregar(clinicaId) {
  const r = await pool.query(`SELECT dados FROM gestor_vendas_dados WHERE clinica_id=$1`, [clinicaId]);
  let d = {};
  if (r.rows.length) { try { d = JSON.parse(cripto.decifrar(r.rows[0].dados)).dados || {}; } catch (e) { d = {}; } }
  const clientes = d.clientes || [], vendas = d.vendas || [];
  const porCpf = new Map(), porTel = new Map(), porNome = new Map(), vendasPor = new Map();
  for (const c of clientes) {
    const cpf = so(c.cpf), tel = so(c.telefone).slice(-8), nome = semAcento(c.nome);
    if (cpf.length === 11) porCpf.set(cpf, c.id);
    if (tel.length === 8) (porTel.get(tel) || porTel.set(tel, []).get(tel)).push(c);
    if (nome) (porNome.get(nome) || porNome.set(nome, []).get(nome)).push(c.id);
  }
  for (const v of vendas) (vendasPor.get(v.clienteId) || vendasPor.set(v.clienteId, []).get(v.clienteId)).push(v);
  return { porCpf, porTel, porNome, vendasPor, loja: (d.loja && d.loja.nome) || '' };
}
/* p = { cpf (cifrado ou não), telefone, nome_completo } ; dia = AAAA-MM-DD do exame */
function compraDepois(base, p, dia) {
  let cpf = ''; try { cpf = so(cripto.decifrar(p.cpf)); } catch (e) { cpf = so(p.cpf); }
  const tel = so(p.telefone).slice(-8), nome = semAcento(p.nome_completo), primeiro = nome.split(' ')[0];
  let id = cpf.length === 11 ? base.porCpf.get(cpf) : undefined;
  if (id === undefined && tel.length === 8) { const l = (base.porTel.get(tel) || []).filter((c) => semAcento(c.nome).split(' ')[0] === primeiro); if (l.length === 1) id = l[0].id; }
  if (id === undefined) { const l = base.porNome.get(nome) || []; if (l.length === 1) id = l[0]; }
  if (id === undefined) return { cliente: false, comprou: false };
  const vs = (base.vendasPor.get(id) || []).filter((v) => String(v.data || '').slice(0, 10) >= dia).sort((a, b) => String(a.data).localeCompare(String(b.data)));
  return { cliente: true, comprou: vs.length > 0, data: vs.length ? String(vs[0].data).slice(0, 10) : null, total: vs.length ? Number(vs[0].total || 0) : 0 };
}
module.exports = { carregar, compraDepois };
