const pool = require('../db/pool');
const cripto = require('./cripto');

/* Espelho da OCO (fase 1 do plano, v4.9.33).
   A OCO guarda tudo num bloco criptografado (gestor_vendas_dados) e o aparelho continua sendo a fonte.
   Aqui o servidor copia vendas, OS, parcelas e despesas do caixa para tabelas próprias, para o financeiro
   único e o painel Master lerem sem abrir o bloco. O bloco nunca é alterado.
   Registro que sumiu do bloco não é apagado da cópia: ganha removido_em. */

const dataOk = (x) => (/^\d{4}-\d{2}-\d{2}$/.test(String(x || '').slice(0, 10)) ? String(x).slice(0, 10) : null);
const num = (x) => { const n = Number(x); return Number.isFinite(n) ? Math.round(n * 100) / 100 : 0; };
const txt = (x, n) => (x == null || x === '' ? null : String(x).slice(0, n));
const ids = (l) => l.map((x) => x.id).filter((x) => Number.isInteger(x));
const etapaOS = (s) => (s === 'Em produção' ? 'Pedido feito' : (s || 'Pedido feito'));
const SAIDAS_CAIXA = ['despesa'];

async function marcarRemovidos(c, tabela, clinica, origemCol, vivos) {
  const filtroOrigem = origemCol ? ` AND origem='oco'` : '';
  await c.query(`UPDATE ${tabela} SET removido_em=NOW() WHERE clinica_id=$1${filtroOrigem} AND removido_em IS NULL AND NOT (origem_id = ANY($2::bigint[]))`, [clinica, vivos]);
}

async function espelhar(clinicaId, dados, versao) {
  const d = dados || {};
  const clientes = new Map((d.clientes || []).map((x) => [x.id, x]));
  const cli = (id) => clientes.get(id) || {};
  const vendas = d.vendas || [], ordens = d.ordens || [], contas = d.contas || [], caixa = d.caixaMovimentos || [];
  const c = await pool.connect();
  try {
    await c.query('BEGIN');
    /* uma cópia por vez para a mesma clínica: a segunda espera a primeira terminar */
    await c.query('SELECT pg_advisory_xact_lock(hashtext($1))', ['oco-espelho-' + clinicaId]);
    for (const v of vendas) {
      await c.query(`INSERT INTO vendas_oco (clinica_id, origem_id, cliente_nome, data, total, forma, parcelas, vendedor)
        VALUES ($1,$2,$3,$4,$5,$6,$7,$8)
        ON CONFLICT (clinica_id, origem_id) DO UPDATE SET cliente_nome=$3, data=$4, total=$5, forma=$6, parcelas=$7, vendedor=$8, removido_em=NULL`,
      [clinicaId, v.id, txt(cli(v.clienteId).nome, 150), dataOk(v.data), num(v.total), txt(v.formaPagamento, 40), parseInt(v.parcelas, 10) || 1, txt(v.vendedor, 150)]);
    }
    await c.query(`UPDATE vendas_oco SET removido_em=NOW() WHERE clinica_id=$1 AND removido_em IS NULL AND NOT (origem_id = ANY($2::bigint[]))`, [clinicaId, ids(vendas)]);

    const totalVenda = new Map(vendas.map((v) => [v.id, num(v.total)]));
    for (const o of ordens) {
      const k = cli(o.clienteId);
      const hist = Array.isArray(o.historico) ? o.historico : [];
      const entregue = etapaOS(o.status) === 'Entregue' ? (dataOk(o.dataEntrega) || dataOk((hist.filter((h) => h.status === 'Entregue').pop() || {}).data)) : null;
      const r = await c.query(`INSERT INTO ordens_servico (clinica_id, origem, origem_id, numero, cliente_nome, cliente_tel, venda_origem_id, etapa, aberta_em, prazo, entregue_em, valor, atualizado_em)
        VALUES ($1,'oco',$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,NOW())
        ON CONFLICT (clinica_id, origem, origem_id) DO UPDATE SET numero=$3, cliente_nome=$4, cliente_tel=$5, venda_origem_id=$6, etapa=$7, aberta_em=$8, prazo=$9, entregue_em=$10, valor=$11, atualizado_em=NOW(), removido_em=NULL
        RETURNING id`,
      [clinicaId, o.id, txt(o.numero || String(o.id).padStart(2, '0'), 20), txt(k.nome, 150), txt(k.telefone, 20), Number.isInteger(o.vendaId) ? o.vendaId : null,
        txt(etapaOS(o.status), 40), dataOk(o.data), dataOk(o.previsaoEntrega), entregue, totalVenda.get(o.vendaId) ?? null]);
      let antes = null;
      for (const h of hist) {
        const para = txt(etapaOS(h.status), 40), quando = dataOk(h.data);
        if (!para || !quando) continue;
        await c.query(`INSERT INTO os_eventos (clinica_id, os_id, etapa_de, etapa_para, usuario, quando) VALUES ($1,$2,$3,$4,$5,$6) ON CONFLICT (os_id, etapa_para, quando) DO NOTHING`,
          [clinicaId, r.rows[0].id, antes, para, txt(h.usuario, 150), quando]);
        antes = para;
      }
    }
    await marcarRemovidos(c, 'ordens_servico', clinicaId, true, ids(ordens));

    for (const x of contas) {
      const k = cli(x.clienteId);
      const venda = vendas.find((v) => v.id === x.vendaId);
      const pago = x.status === 'pago' ? (dataOk(x.dataPagamento) || dataOk(x.vencimento)) : null;
      await c.query(`INSERT INTO contas_receber (clinica_id, origem, origem_id, cliente_origem_id, cliente_nome, cliente_tel, venda_origem_id, parcela, parcelas, vencimento, valor, pago_em, forma)
        VALUES ($1,'oco',$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12)
        ON CONFLICT (clinica_id, origem, origem_id) DO UPDATE SET cliente_origem_id=$3, cliente_nome=$4, cliente_tel=$5, venda_origem_id=$6, parcela=$7, parcelas=$8, vencimento=$9, valor=$10, pago_em=$11, forma=$12, removido_em=NULL`,
      [clinicaId, x.id, Number.isInteger(x.clienteId) ? x.clienteId : null, txt(k.nome, 150), txt(k.telefone, 20), Number.isInteger(x.vendaId) ? x.vendaId : null,
        parseInt(x.parcelaNum, 10) || 1, parseInt(x.parcelaTotal, 10) || 1, dataOk(x.vencimento), num(x.valor), pago, txt(venda && venda.formaPagamento, 40)]);
    }
    await marcarRemovidos(c, 'contas_receber', clinicaId, true, ids(contas));

    /* caixa: entrada = parcela paga (toda venda da OCO vira parcela, à vista inclusive); saída = despesa lançada no caixa */
    const vivos = [];
    for (const x of contas) {
      if (x.status !== 'pago') continue;
      const venda = vendas.find((v) => v.id === x.vendaId);
      const oid = 'parcela-' + x.id; vivos.push(oid);
      await c.query(`INSERT INTO caixa_movimentos (clinica_id, origem, origem_id, data, tipo, descricao, forma, valor)
        VALUES ($1,'oco_venda',$2,$3,'entrada',$4,$5,$6)
        ON CONFLICT (clinica_id, origem, origem_id) DO UPDATE SET data=$3, descricao=$4, forma=$5, valor=$6, removido_em=NULL`,
      [clinicaId, oid, dataOk(x.dataPagamento) || dataOk(x.vencimento) || new Date().toISOString().slice(0, 10),
        txt(`Venda OCO · ${cli(x.clienteId).nome || 'cliente'}${(x.parcelaTotal || 1) > 1 ? ` · parcela ${x.parcelaNum}/${x.parcelaTotal}` : ''}`, 200), txt(venda && venda.formaPagamento, 40), num(x.valor)]);
    }
    for (const m of caixa) {
      if (!SAIDAS_CAIXA.includes(m.tipo) || !dataOk(m.data)) continue;
      const oid = 'caixa-' + m.id; vivos.push(oid);
      await c.query(`INSERT INTO caixa_movimentos (clinica_id, origem, origem_id, data, tipo, descricao, valor)
        VALUES ($1,'oco_despesa',$2,$3,'saida',$4,$5)
        ON CONFLICT (clinica_id, origem, origem_id) DO UPDATE SET data=$3, descricao=$4, valor=$5, removido_em=NULL`,
      [clinicaId, oid, dataOk(m.data), txt(m.descricao || 'Despesa do caixa da OCO', 200), num(m.valor)]);
    }
    await c.query(`UPDATE caixa_movimentos SET removido_em=NOW() WHERE clinica_id=$1 AND origem IN ('oco_venda','oco_despesa') AND removido_em IS NULL AND NOT (origem_id = ANY($2::text[]))`, [clinicaId, vivos]);

    /* conferência: os totais da cópia têm de bater com o bloco */
    const somaBloco = {
      vendas: vendas.length, total_vendas: num(vendas.reduce((t, v) => t + num(v.total), 0)),
      ordens: ordens.length, parcelas: contas.length, total_parcelas: num(contas.reduce((t, x) => t + num(x.valor), 0)),
    };
    const cv = await c.query(`SELECT COUNT(*)::int n, COALESCE(SUM(total),0)::float t FROM vendas_oco WHERE clinica_id=$1 AND removido_em IS NULL`, [clinicaId]);
    const co = await c.query(`SELECT COUNT(*)::int n FROM ordens_servico WHERE clinica_id=$1 AND origem='oco' AND removido_em IS NULL`, [clinicaId]);
    const cc = await c.query(`SELECT COUNT(*)::int n, COALESCE(SUM(valor),0)::float t FROM contas_receber WHERE clinica_id=$1 AND origem='oco' AND removido_em IS NULL`, [clinicaId]);
    const somaCopia = { vendas: cv.rows[0].n, total_vendas: num(cv.rows[0].t), ordens: co.rows[0].n, parcelas: cc.rows[0].n, total_parcelas: num(cc.rows[0].t) };
    const bate = Object.keys(somaBloco).every((k) => Math.abs(somaBloco[k] - somaCopia[k]) < 0.01);
    if (!bate) throw new Error('Totais não bateram: bloco ' + JSON.stringify(somaBloco) + ' cópia ' + JSON.stringify(somaCopia));
    await c.query(`INSERT INTO oco_espelho (clinica_id, versao, copiado_em, conferencia, erro) VALUES ($1,$2,NOW(),$3,NULL)
      ON CONFLICT (clinica_id) DO UPDATE SET versao=$2, copiado_em=NOW(), conferencia=$3, erro=NULL`, [clinicaId, versao || null, JSON.stringify({ bloco: somaBloco, copia: somaCopia, bate })]);
    await c.query('COMMIT');
    return { ok: true, bloco: somaBloco, copia: somaCopia };
  } catch (e) {
    await c.query('ROLLBACK').catch(() => {});
    await pool.query(`INSERT INTO oco_espelho (clinica_id, versao, erro) VALUES ($1,$2,$3) ON CONFLICT (clinica_id) DO UPDATE SET erro=$3`, [clinicaId, versao || null, String(e.message).slice(0, 500)]).catch(() => {});
    console.error('Espelho da OCO:', e.message);
    return { ok: false, erro: e.message };
  } finally { c.release(); }
}

/* lê o bloco guardado e copia; usado ao ligar o servidor e pelo botão "Copiar de novo" */
async function espelharDoBanco(clinicaId) {
  const r = await pool.query(`SELECT versao, dados FROM gestor_vendas_dados WHERE clinica_id=$1`, [clinicaId]);
  if (!r.rows.length) return { ok: true, vazio: true };
  const corpo = JSON.parse(cripto.decifrar(r.rows[0].dados));
  return espelhar(clinicaId, corpo.dados, r.rows[0].versao);
}

/* ao ligar: copia as clínicas cuja cópia está atrasada em relação ao bloco */
async function iniciar() {
  try {
    const r = await pool.query(`SELECT g.clinica_id FROM gestor_vendas_dados g LEFT JOIN oco_espelho e ON e.clinica_id = g.clinica_id
      WHERE e.versao IS DISTINCT FROM g.versao OR e.erro IS NOT NULL`);
    for (const x of r.rows) await espelharDoBanco(x.clinica_id);
  } catch (e) { console.error('Espelho da OCO ao ligar:', e.message); }
}

module.exports = { espelhar, espelharDoBanco, iniciar };
