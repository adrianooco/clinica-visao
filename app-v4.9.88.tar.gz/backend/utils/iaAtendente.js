/* Atendente de IA do WhatsApp da ótica (OCO).
   Usa o Google Gemini (variável GEMINI_API_KEY no servidor). A IA só conversa:
   não marca, não vende, não muda nada no sistema. Quando o cliente precisa de uma pessoa,
   ela avisa e a conversa vai para a equipe na tela "Atendente IA" do OCO. */
const pool = require('../db/pool');
const cripto = require('./cripto');

const MODELOS = [process.env.GEMINI_MODEL, 'gemini-flash-latest', 'gemini-3.5-flash-lite', 'gemini-2.5-flash'].filter(Boolean);
const BASE = (process.env.GEMINI_API_BASE || 'https://generativelanguage.googleapis.com').replace(/\/$/, '');

function configurada() { return !!process.env.GEMINI_API_KEY; }

const reais = (n) => 'R$ ' + Number(n || 0).toFixed(2).replace('.', ',');
const limpa = (t, max = 200) => String(t == null ? '' : t).replace(/[\r\n\t]+/g, ' ').trim().slice(0, max);

/* lê do OCO o que a IA precisa saber: dados da loja, tabela de lentes e armações do estoque */
async function dadosDaLoja(clinicaId) {
  const r = await pool.query(`SELECT dados FROM gestor_vendas_dados WHERE clinica_id=$1`, [clinicaId]);
  if (!r.rows.length) return {};
  try { return JSON.parse(cripto.decifrar(r.rows[0].dados)).dados || {}; } catch (e) { return {}; }
}

function montarInstrucoes(cfg, d) {
  const loja = d.loja || {};
  const linhas = [];
  linhas.push(`Você é ${cfg.nome_atendente || 'a atendente virtual'} da ótica ${limpa(loja.nome, 80) || 'Ótica'} no WhatsApp.`);
  linhas.push('Responda em português do Brasil, com frases curtas e simples, como uma atendente educada de loja. No máximo 4 frases por resposta. Sem asteriscos, sem listas longas, sem emojis em excesso (no máximo 1).');
  linhas.push('Regras:');
  linhas.push('1. Use só as informações abaixo. Se o cliente perguntar algo que não está aqui (preço que não aparece, prazo, estoque de um modelo, desconto), diga que vai chamar alguém da equipe e marque chamar_equipe como true.');
  linhas.push('2. Nunca invente preço, prazo, promoção, desconto ou disponibilidade.');
  linhas.push('3. Você não marca horário, não fecha venda, não confirma pagamento e não altera nada. Para marcar exame, fechar compra, reclamação, troca, garantia ou pagamento, diga que vai passar para a equipe e marque chamar_equipe como true.');
  linhas.push('4. Não dê diagnóstico nem orientação médica. Se o cliente falar de dor, olho vermelho, perda de visão súbita ou machucado, oriente procurar atendimento médico logo e marque chamar_equipe como true.');
  linhas.push('5. Não fale de outras empresas nem de outros sistemas. Não diga que é uma IA, a não ser que perguntem. Se perguntarem, diga a verdade: é um atendimento automático e uma pessoa da equipe pode assumir.');
  linhas.push('6. Se o cliente pedir para falar com uma pessoa, marque chamar_equipe como true.');
  linhas.push('Responda SOMENTE com um JSON assim: {"resposta": "texto para o cliente", "chamar_equipe": true ou false}');
  linhas.push('');
  linhas.push('INFORMAÇÕES DA ÓTICA:');
  if (loja.endereco) linhas.push('Endereço: ' + limpa(loja.endereco, 200));
  if (loja.telefone) linhas.push('Telefone: ' + limpa(loja.telefone, 40));
  if (cfg.horario) linhas.push('Horário de atendimento: ' + limpa(cfg.horario, 300));
  if (loja.garantiaDias) linhas.push(`Garantia: ${Number(loja.garantiaDias)} dias de adaptação da lente.`);
  if (loja.marcasLentes) linhas.push('Marcas de lentes que trabalhamos: ' + limpa(loja.marcasLentes, 200));
  if (loja.chavePix) linhas.push('Aceitamos Pix.');

  const armacoes = (d.estoque || []).filter((p) => /arma/i.test(p.categoria || p.nome || '') && Number(String(p.preco).replace(',', '.')) > 0 && Number(p.quantidade || 0) > 0);
  if (armacoes.length) {
    const precos = armacoes.map((p) => Number(String(p.preco).replace(',', '.')));
    linhas.push(`Armações em estoque: ${armacoes.length} modelos, de ${reais(Math.min(...precos))} até ${reais(Math.max(...precos))}.`);
  }
  const lentes = (d.precos || []).filter((p) => p && p.nome && Number(p.preco) > 0).slice(0, 60);
  if (lentes.length) {
    linhas.push('Tabela de lentes (preço por par):');
    lentes.forEach((p) => linhas.push(`- ${limpa(p.nome, 60)}${p.tipo ? ' | ' + limpa(p.tipo, 30) : ''}${p.indice ? ' | índice ' + limpa(p.indice, 10) : ''}${p.marca ? ' | ' + limpa(p.marca, 30) : ''}: ${reais(p.preco)}`));
  }
  if (cfg.instrucoes) { linhas.push(''); linhas.push('O QUE O DONO DA ÓTICA PEDIU PARA VOCÊ SABER E SEGUIR:'); linhas.push(String(cfg.instrucoes).slice(0, 4000)); }
  const agora = new Date().toLocaleString('pt-BR', { timeZone: 'America/Sao_Paulo', weekday: 'long', hour: '2-digit', minute: '2-digit' });
  linhas.push('');
  linhas.push('Agora é ' + agora + ' (horário de Brasília).');
  return linhas.join('\n');
}

async function chamarGemini(instrucoes, historico) {
  const contents = historico.map((m) => ({ role: m.autor === 'cliente' ? 'user' : 'model', parts: [{ text: m.texto }] }));
  // o Gemini pede que a conversa comece pelo cliente
  while (contents.length && contents[0].role !== 'user') contents.shift();
  if (!contents.length) throw new Error('Conversa vazia.');
  let ultimoErro;
  for (const modelo of MODELOS) {
    try {
      const r = await fetch(`${BASE}/v1beta/models/${encodeURIComponent(modelo)}:generateContent`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-goog-api-key': process.env.GEMINI_API_KEY },
        body: JSON.stringify({
          systemInstruction: { parts: [{ text: instrucoes }] },
          contents,
          generationConfig: { temperature: 0.3, maxOutputTokens: 2048, responseMimeType: 'application/json' },
        }),
        signal: AbortSignal.timeout(25000),
      });
      const j = await r.json().catch(() => ({}));
      if (!r.ok) { ultimoErro = new Error(j.error?.message || `Gemini respondeu ${r.status}`); if (r.status === 404 || r.status === 400) continue; throw ultimoErro; }
      const texto = (j.candidates?.[0]?.content?.parts || []).map((p) => p.text || '').join('').trim();
      return interpretar(texto);
    } catch (e) { ultimoErro = e; if (e.name === 'TimeoutError') break; }
  }
  throw ultimoErro || new Error('Gemini indisponível.');
}

function interpretar(texto) {
  let obj = null;
  try { obj = JSON.parse(texto); } catch (e) {
    const m = texto.match(/\{[\s\S]*\}/);
    if (m) { try { obj = JSON.parse(m[0]); } catch (e2) { /* segue */ } }
  }
  const resposta = limpa(obj?.resposta || (obj ? '' : texto), 1200).replace(/\*/g, '');
  if (!resposta) throw new Error('Resposta vazia da IA.');
  return { resposta, chamarEquipe: obj?.chamar_equipe === true };
}

async function lerConfig(clinicaId) {
  const r = await pool.query(`SELECT * FROM atendente_config WHERE clinica_id=$1`, [clinicaId]);
  return r.rows[0] || { clinica_id: clinicaId, ativo: false };
}

/* historico: [{autor:'cliente'|'ia'|'equipe', texto}] em ordem. Devolve {resposta, chamarEquipe}. */
async function responderCliente(clinicaId, historico, cfgTeste) {
  if (!configurada()) throw new Error('Falta a chave GEMINI_API_KEY no servidor.');
  const cfg = cfgTeste || await lerConfig(clinicaId);
  const d = await dadosDaLoja(clinicaId);
  return chamarGemini(montarInstrucoes(cfg, d), historico.slice(-16));
}

module.exports = { configurada, lerConfig, responderCliente };
