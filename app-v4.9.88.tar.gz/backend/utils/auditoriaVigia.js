const pool = require('../db/pool');

/* ===== v4.9.36 fase 2: o Vigia lê a auditoria de hora em hora =====
   Regra 1: a mesma pessoa abriu mais de 50 fichas de pacientes diferentes em 1 hora.
   Regra 2: a pessoa usou o sistema entre 23h e 5h (horário de Brasília).
   Cada achado vira um alerta em ia_memoria (tipo 'seguranca', status 'nova').
   O Master decide na aba Segurança: bloquear a conta ou ignorar. Nada é bloqueado sozinho.
   O mesmo alerta (pessoa + regra) não se repete em 24 horas. */
const LIMITE_FICHAS = 50;

async function jaAvisado(clinicaId, usuarioId, regra) {
  const r = await pool.query(`SELECT 1 FROM ia_memoria WHERE clinica_id=$1 AND tipo='seguranca' AND criado_em > NOW() - INTERVAL '24 hours'
    AND dados_agregados->>'usuario_id' = $2 AND dados_agregados->>'regra' = $3 LIMIT 1`, [clinicaId, usuarioId, regra]);
  return r.rows.length > 0;
}

async function criarAlerta(clinicaId, d, resumo) {
  if (await jaAvisado(clinicaId, d.usuario_id, d.regra)) return false;
  await pool.query(`INSERT INTO ia_memoria (clinica_id, tipo, resumo, dados_agregados, status) VALUES ($1,'seguranca',$2,$3,'nova')`, [clinicaId, resumo, JSON.stringify(d)]);
  const email = require('./email'), para = process.env.ALERTA_EMAIL_PARA || process.env.BACKUP_EMAIL_PARA;
  if (email.ativo() && para) {
    email.enviar({ para, assunto: 'Alerta do Vigia: ' + resumo.slice(0, 80), texto: resumo + '\n\nAbra o sistema em Master, aba Segurança, Alertas da auditoria, para bloquear a conta ou ignorar o alerta. Nada foi bloqueado sozinho.' }).catch(() => {});
  }
  return true;
}

async function analisar() {
  let novos = 0;
  /* regra 1: muitas fichas diferentes na última hora */
  const fichas = await pool.query(`SELECT a.clinica_id, a.usuario_id, MAX(a.usuario_nome) AS usuario_nome, MAX(a.papel) AS papel, COUNT(DISTINCT a.paciente_id)::int AS fichas
    FROM auditoria_telas a WHERE a.quando > NOW() - INTERVAL '1 hour' AND a.paciente_id IS NOT NULL AND a.usuario_id IS NOT NULL
    GROUP BY a.clinica_id, a.usuario_id HAVING COUNT(DISTINCT a.paciente_id) > $1`, [LIMITE_FICHAS]);
  for (const x of fichas.rows) {
    const ok = await criarAlerta(x.clinica_id, { regra: 'muitas_fichas', usuario_id: x.usuario_id, usuario_nome: x.usuario_nome, papel: x.papel, contagem: x.fichas, janela: '1 hora' },
      `${x.usuario_nome || 'Uma pessoa'} abriu ${x.fichas} fichas de pacientes diferentes em menos de 1 hora (o limite de atenção é ${LIMITE_FICHAS}).`);
    if (ok) novos++;
  }
  /* regra 2: uso entre 23h e 5h, olhando as últimas 2 horas para não perder nada entre uma rodada e outra */
  const noite = await pool.query(`SELECT a.clinica_id, a.usuario_id, MAX(a.usuario_nome) AS usuario_nome, MAX(a.papel) AS papel, COUNT(*)::int AS acessos,
      MIN(a.quando AT TIME ZONE 'America/Sao_Paulo') AS primeiro, MAX(a.quando AT TIME ZONE 'America/Sao_Paulo') AS ultimo
    FROM auditoria_telas a WHERE a.quando > NOW() - INTERVAL '2 hours' AND a.usuario_id IS NOT NULL
      AND (EXTRACT(HOUR FROM a.quando AT TIME ZONE 'America/Sao_Paulo') >= 23 OR EXTRACT(HOUR FROM a.quando AT TIME ZONE 'America/Sao_Paulo') < 5)
    GROUP BY a.clinica_id, a.usuario_id`);
  for (const x of noite.rows) {
    const h = (t) => String(t).replace(' ', 'T').slice(11, 16);
    const ok = await criarAlerta(x.clinica_id, { regra: 'madrugada', usuario_id: x.usuario_id, usuario_nome: x.usuario_nome, papel: x.papel, contagem: x.acessos, de: h(x.primeiro), ate: h(x.ultimo) },
      `${x.usuario_nome || 'Uma pessoa'} usou o sistema de madrugada, entre ${h(x.primeiro)} e ${h(x.ultimo)}, com ${x.acessos} registro(s) de acesso.`);
    if (ok) novos++;
  }
  if (novos) console.log(`Vigia da auditoria: ${novos} alerta(s) novo(s) para o Master.`);
  return novos;
}

function iniciar() {
  const rodar = () => analisar().catch((e) => console.error('Vigia da auditoria:', e.message));
  setTimeout(rodar, 3 * 60000).unref();
  setInterval(rodar, 60 * 60000).unref();
}
module.exports = { analisar, iniciar, LIMITE_FICHAS };
