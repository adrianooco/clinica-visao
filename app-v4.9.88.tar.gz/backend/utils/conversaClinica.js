/* ===== v4.9.80: Conversas do WhatsApp da clínica =====
   Tudo o que o paciente escreve para o número da clínica fica guardado aqui (texto embaralhado no banco),
   junto com as respostas automáticas, da IA e da equipe. O Master e os agendadores veem e respondem na tela Conversas.
   Quando alguém da equipe responde, o sistema e a IA ficam quietos nessa conversa por 12 horas. */
const pool = require('../db/pool');
const cripto = require('./cripto');
const wpp = require('./whatsapp');

const HORAS_EQUIPE = 12;
const IA_POR_HORA = 20;
const cif = (t) => { try { return cripto.cifrar(String(t)); } catch (e) { return String(t); } };
const dec = (t) => { try { return cripto.decifrar(t); } catch (e) { return '[mensagem protegida]'; } };
const fimDe = (tel) => String(tel || '').replace(/\D/g, '').slice(-10);

async function pacienteDoTelefone(clinicaId, tel) {
  const r = await pool.query(
    `SELECT id, nome_completo, unidade_id FROM pacientes WHERE clinica_id=$1 AND deletado_em IS NULL AND RIGHT(REGEXP_REPLACE(COALESCE(telefone,''),'\\D','','g'),10)=$2 ORDER BY criado_em DESC LIMIT 1`,
    [clinicaId, fimDe(tel)]);
  return r.rows[0] || null;
}

/* guarda uma mensagem. Para a do paciente, devolve false se a Meta mandou a mesma de novo */
async function guardar(cl, tel, autor, texto, waId, nome, enviadoPor) {
  const t = String(texto == null ? '' : texto).slice(0, 4000); if (!t) return true;
  const ins = await pool.query(
    `INSERT INTO wa_cli_mensagens (clinica_id, telefone, autor, texto, wa_id, enviado_por) VALUES ($1,$2,$3,$4,$5,$6)
     ON CONFLICT (wa_id) WHERE wa_id IS NOT NULL DO NOTHING RETURNING id`,
    [cl.id, tel, autor, cif(t), waId ? String(waId).slice(0, 120) : null, enviadoPor || null]);
  if (!ins.rows.length) return false;
  if (autor === 'cliente') {
    const p = await pacienteDoTelefone(cl.id, tel);
    await pool.query(
      `INSERT INTO wa_cli_conversas (clinica_id, telefone, nome, paciente_id, unidade_id, nao_lidas, ultima_em, ultima_cliente_em) VALUES ($1,$2,$3,$4,$5,1,NOW(),NOW())
       ON CONFLICT (clinica_id, telefone) DO UPDATE SET nome=COALESCE(EXCLUDED.nome, wa_cli_conversas.nome), paciente_id=COALESCE(EXCLUDED.paciente_id, wa_cli_conversas.paciente_id),
         unidade_id=COALESCE(EXCLUDED.unidade_id, wa_cli_conversas.unidade_id), nao_lidas=wa_cli_conversas.nao_lidas+1, ultima_em=NOW(), ultima_cliente_em=NOW()`,
      [cl.id, tel, nome ? String(nome).slice(0, 120) : null, p ? p.id : null, p ? p.unidade_id : null]);
  } else {
    await pool.query(`UPDATE wa_cli_conversas SET ultima_em=NOW() WHERE clinica_id=$1 AND telefone=$2`, [cl.id, tel]);
  }
  return true;
}
async function responder(cl, tel, texto, autor) {
  await wpp.responder(tel, texto);
  try { await guardar(cl, tel, autor || 'sistema', texto); } catch (e) { console.error('Conversa: não guardou a resposta:', e.message); }
}
async function equipeAtendendo(cl, tel) {
  const r = await pool.query(`SELECT equipe_ate FROM wa_cli_conversas WHERE clinica_id=$1 AND telefone=$2`, [cl.id, tel]);
  return !!(r.rows[0] && r.rows[0].equipe_ate && new Date(r.rows[0].equipe_ate) > new Date());
}
async function marcarPrecisa(cl, tel, sim) {
  await pool.query(`UPDATE wa_cli_conversas SET precisa_equipe=$3 WHERE clinica_id=$1 AND telefone=$2`, [cl.id, tel, !!sim]);
}
/* foto, áudio e outros: guarda o aviso e chama a equipe */
async function naoTexto(numeroClinica, m, contatos) {
  const c = await pool.query(`SELECT id, nome_fantasia FROM clinicas WHERE ativa=TRUE AND RIGHT(REGEXP_REPLACE(COALESCE(whatsapp_numero,''),'\\D','','g'),10)=$1 LIMIT 1`, [String(numeroClinica).slice(-10)]);
  if (!c.rows.length) return;
  const tel = String(m.from || '').replace(/\D/g, ''); if (!tel) return;
  const nomes = { audio: 'áudio', image: 'foto', video: 'vídeo', document: 'documento', sticker: 'figurinha', location: 'localização' };
  const texto = m.type === 'button' ? String(m.button?.text || '') : m.type === 'interactive' ? String(m.interactive?.button_reply?.title || m.interactive?.list_reply?.title || '') : `[${nomes[m.type] || m.type}]`;
  const nome = (contatos || []).find((x) => x.wa_id === m.from)?.profile?.name;
  if (await guardar(c.rows[0], tel, 'cliente', texto, m.id, nome)) await marcarPrecisa(c.rows[0], tel, true);
}

/* ---- IA da clínica: só a IA paga (o paciente pode falar de saúde). Só informa; quem marca é a equipe ou o 1, 2, 3 ---- */
const fmtDia = (d) => { const [a, m, dd] = String(d).slice(0, 10).split('-'); return `${dd}/${m}`; };
async function contexto(cl, tel) {
  const c = (await pool.query(`SELECT nome_fantasia, local_exame_padrao, whatsapp_numero, conversa_ia_instrucoes FROM clinicas WHERE id=$1`, [cl.id])).rows[0] || {};
  const ag = await pool.query(
    `SELECT a.data, MIN(a.hora_inicio) AS ini, MAX(a.hora_fim) AS fim, MAX(a.local) AS local, COALESCE(u.cidade, u.nome) AS cidade
     FROM agendas a JOIN unidades u ON u.id=a.unidade_id
     WHERE a.clinica_id=$1 AND a.ativa=TRUE AND a.data BETWEEN (NOW() AT TIME ZONE 'America/Sao_Paulo')::date AND (NOW() AT TIME ZONE 'America/Sao_Paulo')::date + 45
     GROUP BY a.data, COALESCE(u.cidade, u.nome) ORDER BY a.data LIMIT 30`, [cl.id]);
  const p = await pacienteDoTelefone(cl.id, tel);
  let meu = null;
  if (p) {
    const r = await pool.query(
      `SELECT a.data_hora, a.status, a.local, COALESCE(u.cidade, u.nome) AS cidade FROM agendamentos a LEFT JOIN unidades u ON u.id=a.unidade_id
       WHERE a.clinica_id=$1 AND a.paciente_id=$2 AND a.status IN ('agendado','confirmado') AND a.data_hora > (NOW() AT TIME ZONE 'America/Sao_Paulo') ORDER BY a.data_hora LIMIT 1`, [cl.id, p.id]);
    meu = r.rows[0] || null;
  }
  const L = [];
  L.push(`Você responde o WhatsApp da ${c.nome_fantasia || 'clínica'} de exame de vista (optometria).`);
  L.push('Responda em português do Brasil, com frases curtas e simples, no máximo 4 frases. Sem asteriscos, sem listas longas, no máximo 1 emoji.');
  L.push('Regras: 1) Use só as informações abaixo. Nunca invente preço, data, horário ou endereço. 2) Você não marca, não desmarca e não muda nada. Para marcar exame, pagar, reclamar ou qualquer coisa fora daqui, diga que vai passar para a equipe e marque chamar_equipe como true. 3) Se o paciente já tem exame marcado, lembre que ele pode responder 1 para confirmar, 2 para cancelar ou 3 para remarcar. 4) Não dê diagnóstico nem orientação de remédio. Dor forte, olho vermelho, perda súbita de visão ou machucado: oriente procurar atendimento médico logo e marque chamar_equipe como true. 5) Se pedir para falar com uma pessoa, marque chamar_equipe como true. 6) Se perguntarem, diga que é um atendimento automático e que a equipe pode assumir.');
  L.push('Responda SOMENTE com um JSON assim: {"resposta": "texto", "chamar_equipe": true ou false}');
  L.push('');
  L.push('INFORMAÇÕES:');
  if (c.local_exame_padrao) L.push('Local do exame: ' + String(c.local_exame_padrao).slice(0, 200));
  if (ag.rows.length) { L.push('Próximos dias de exame por cidade:'); ag.rows.forEach((x) => L.push(`- ${x.cidade}: ${fmtDia(x.data)}, das ${String(x.ini).slice(0, 5)} às ${String(x.fim).slice(0, 5)}${x.local ? ', em ' + String(x.local).slice(0, 80) : ''}`)); }
  else L.push('Não há dias de exame abertos nos próximos 45 dias.');
  if (meu) L.push(`Este paciente (${String(p.nome_completo || '').split(' ')[0]}) tem exame marcado: ${fmtDia(String(meu.data_hora).replace(' ', 'T'))} às ${String(meu.data_hora).replace(' ', 'T').slice(11, 16)}, em ${meu.cidade || ''}${meu.local ? ', ' + meu.local : ''}. Situação: ${meu.status}.`);
  else if (p) L.push(`Este paciente (${String(p.nome_completo || '').split(' ')[0]}) não tem exame marcado agora.`);
  else L.push('Este número não está cadastrado como paciente.');
  if (c.conversa_ia_instrucoes) { L.push(''); L.push('O QUE O DONO PEDIU PARA VOCÊ SABER E SEGUIR:'); L.push(String(c.conversa_ia_instrucoes).slice(0, 3000)); }
  L.push('');
  L.push('Agora é ' + new Date().toLocaleString('pt-BR', { timeZone: 'America/Sao_Paulo', weekday: 'long', day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' }) + '.');
  return L.join('\n');
}
async function iaResponder(cl, tel) {
  const ia = require('../routes/ia');
  const cfg = (await pool.query(`SELECT COALESCE(conversa_ia_ligada,FALSE) AS ligada FROM clinicas WHERE id=$1`, [cl.id])).rows[0];
  if (!cfg || !cfg.ligada || !ia.provedorFoto()) return false;
  const usos = await pool.query(`SELECT COUNT(*)::int n FROM wa_cli_mensagens WHERE clinica_id=$1 AND telefone=$2 AND autor='ia' AND criado_em > NOW() - INTERVAL '1 hour'`, [cl.id, tel]);
  if (usos.rows[0].n >= IA_POR_HORA) return false;
  const hist = (await pool.query(`SELECT autor, texto FROM (SELECT autor, texto, criado_em FROM wa_cli_mensagens WHERE clinica_id=$1 AND telefone=$2 ORDER BY criado_em DESC LIMIT 14) t ORDER BY criado_em`, [cl.id, tel])).rows;
  const conversa = hist.map((h) => (h.autor === 'cliente' ? 'Paciente: ' : 'Clínica: ') + dec(h.texto)).join('\n');
  let resposta, chamar = false;
  try {
    const bruto = await ia.chamarIAImagem(await contexto(cl, tel), 'CONVERSA ATÉ AGORA:\n' + conversa + '\n\nEscreva a próxima resposta da clínica.', [], null, true, 500);
    const m = /\{[\s\S]*\}/.exec(bruto || ''); const j = m ? JSON.parse(m[0]) : null;
    resposta = String((j && j.resposta) || '').replace(/\*/g, '').trim().slice(0, 1200); chamar = !!(j && j.chamar_equipe === true);
  } catch (e) { console.error('IA da conversa falhou:', e.status || e.message); return false; }
  if (!resposta) return false;
  await responder(cl, tel, resposta, 'ia');
  if (chamar) await marcarPrecisa(cl, tel, true);
  return true;
}
module.exports = { guardar, responder, equipeAtendendo, marcarPrecisa, naoTexto, iaResponder, contexto, dec, HORAS_EQUIPE, fimDe };
