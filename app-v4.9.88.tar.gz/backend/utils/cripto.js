/* Criptografia dos dados sensíveis (AES-256-GCM).
   A chave vem da variável CHAVE_CRIPTOGRAFIA (fica só no servidor, nunca no banco).
   Sem a chave, o sistema funciona igual, mas grava sem embaralhar.
   Valores embaralhados começam com "enc1:". Valores antigos (sem prefixo) continuam legíveis. */
const crypto = require('crypto');

const PREFIXO = 'enc1:';
let chave = null, antiga = null;
const derivar = (b) => (b ? crypto.createHash('sha256').update(String(b)).digest() : false);
function pegarChave() {
  if (chave !== null) return chave || null;
  chave = derivar(process.env.CHAVE_CRIPTOGRAFIA);
  return chave || null;
}
/* durante a troca de chave, a antiga (CHAVE_CRIPTOGRAFIA_ANTIGA) ainda abre o que não foi regravado */
function pegarAntiga() {
  if (antiga !== null) return antiga || null;
  antiga = derivar(process.env.CHAVE_CRIPTOGRAFIA_ANTIGA);
  return antiga || null;
}
const ativa = () => !!pegarChave();
const jaCifrado = (v) => typeof v === 'string' && v.startsWith(PREFIXO);

function cifrar(texto) {
  if (texto === null || texto === undefined || texto === '') return texto;
  const k = pegarChave();
  if (!k || jaCifrado(texto)) return texto;
  const iv = crypto.randomBytes(12);
  const c = crypto.createCipheriv('aes-256-gcm', k, iv);
  const dados = Buffer.concat([c.update(String(texto), 'utf8'), c.final()]);
  return PREFIXO + Buffer.concat([iv, c.getAuthTag(), dados]).toString('base64');
}
function decifrar(valor) {
  if (!jaCifrado(valor)) return valor;
  const k = pegarChave();
  if (!k) throw new Error('Dados embaralhados, mas falta a variável CHAVE_CRIPTOGRAFIA.');
  const b = Buffer.from(valor.slice(PREFIXO.length), 'base64');
  const tentar = (chv) => {
    const d = crypto.createDecipheriv('aes-256-gcm', chv, b.subarray(0, 12));
    d.setAuthTag(b.subarray(12, 28));
    return Buffer.concat([d.update(b.subarray(28)), d.final()]).toString('utf8');
  };
  try { return tentar(k); }
  catch (e) {
    const velha = pegarAntiga();
    if (!velha) throw e;
    return tentar(velha);
  }
}
/* JSON: vira um texto embaralhado guardado como string dentro do jsonb */
function cifrarJson(obj) {
  if (obj === null || obj === undefined) return null;
  const k = pegarChave();
  return JSON.stringify(k ? cifrar(JSON.stringify(obj)) : obj);
}
function decifrarJson(v) {
  if (typeof v === 'string' && jaCifrado(v)) return JSON.parse(decifrar(v));
  return v;
}

const CAMPOS_TEXTO = ['queixa_principal', 'observacoes_clinicas', 'conduta'];
const CAMPOS_JSON = ['sintomas', 'gabarito_acuidade', 'refracao', 'exame'];
function abrirProntuario(l) {
  if (!l) return l;
  const o = { ...l };
  for (const c of CAMPOS_TEXTO) if (c in o) o[c] = decifrar(o[c]);
  for (const c of CAMPOS_JSON) if (c in o) o[c] = decifrarJson(o[c]);
  return o;
}
const REC_TEXTO = ['atestado_texto', 'declaracao_texto', 'cid_codigo', 'cid_descricao'];
const REC_JSON = ['longe', 'perto'];
REC_TEXTO.push('laudo_texto'); /* v4.9.87 */
function abrirReceita(l) {
  if (!l) return l;
  const o = { ...l };
  for (const c of REC_TEXTO) if (c in o) o[c] = decifrar(o[c]);
  for (const c of REC_JSON) if (c in o) o[c] = decifrarJson(o[c]);
  return o;
}
function abrirPaciente(l) {
  if (!l) return l;
  const o = { ...l };
  for (const c of ['foto_receita_url', 'foto_armacao_url', 'cpf']) if (c in o) o[c] = decifrar(o[c]);
  delete o.cpf_idx;
  return o;
}
/* CPF embaralhado não dá para procurar nem comparar. Por isso o banco guarda também uma "impressão" do CPF
   (HMAC com a chave do servidor): serve só para barrar CPF repetido e achar o paciente, e não permite voltar ao número. */
function indiceCpf(cpf) {
  const d = String(cpf === null || cpf === undefined ? '' : cpf).replace(/\D/g, '');
  if (!d) return null;
  return crypto.createHmac('sha256', pegarChave() || Buffer.from('sem-chave')).update('cpf:' + d).digest('hex');
}
/* paciente para a tela: abre só o CPF (as fotos continuam fechadas) e tira o índice interno */
function abrirCpf(l) {
  if (!l) return l;
  const o = { ...l };
  if ('cpf' in o) { try { o.cpf = decifrar(o.cpf); } catch (e) { o.cpf = null; } }
  delete o.cpf_idx;
  return o;
}

/* foto grande demais (texto base64): o celular já reduz antes de enviar, isto é a trava do servidor */
const fotoGrande = (v) => typeof v === 'string' && v.length > 1500000;

/* texto aberto qualquer, para uso interno (ex.: segredo do código do celular) */
module.exports = { indiceCpf, abrirCpf, fotoGrande, abrirReceita, REC_TEXTO, REC_JSON, ativa, cifrar, decifrar, cifrarJson, decifrarJson, jaCifrado, abrirProntuario, abrirPaciente, CAMPOS_TEXTO, CAMPOS_JSON };
