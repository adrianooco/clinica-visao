/* ===== v4.9.44: aparelho de confiança e liberação de aparelho =====
   Cada navegador guarda um número próprio e aleatório (agend_aparelho_id). O servidor guarda só o "hash" dele.
   1) Master: entra com a senha e, em aparelho novo, com um código de 6 números enviado por e-mail.
      Depois do código, aquele aparelho fica de confiança por 30 dias e não pede código de novo.
      Emergência: na Render, SEGUNDO_FATOR_MASTER=nao desliga o código.
   2) Agendador e profissional: o primeiro aparelho de cada pessoa é liberado sozinho (o Master recebe aviso).
      Aparelho novo depois disso espera o Master liberar na aba Equipe. A clínica pode desligar isso. */
const crypto = require('crypto');
const pool = require('../db/pool');
const email = require('./email');

const DIAS_CONFIANCA = 30;
const ID_VALIDO = /^[A-Za-z0-9_-]{20,100}$/;
const hashDe = (id) => crypto.createHash('sha256').update('aparelho|' + id).digest('hex');
const segundoFatorLigado = () => process.env.SEGUNDO_FATOR_MASTER !== 'nao';

function nomeAparelho(ua) {
  ua = String(ua || '');
  const so = /Android/i.test(ua) ? 'Android' : /iPhone|iPad/i.test(ua) ? 'iPhone' : /Windows/i.test(ua) ? 'Windows' : /Mac OS/i.test(ua) ? 'Mac' : /Linux/i.test(ua) ? 'Linux' : 'aparelho';
  const nav = /Edg\//.test(ua) ? 'Edge' : /SamsungBrowser/i.test(ua) ? 'Samsung Internet' : /Chrome\//.test(ua) ? 'Chrome' : /Firefox\//.test(ua) ? 'Firefox' : /Safari\//.test(ua) ? 'Safari' : 'navegador';
  const modelo = (/Android[^;)]*;\s*([^;)]+?)\s*(Build|\))/i.exec(ua) || [])[1];
  return `${so}${modelo && !/^(K|wv)$/i.test(modelo.trim()) ? ' ' + modelo.trim() : ''}, ${nav}`.slice(0, 120);
}
const mascara = (e) => (e ? String(e).replace(/^(.)[^@]*(@.*)$/, '$1***$2') : '');

/* ---------- Master: aparelho de confiança ---------- */
async function confiavel(usuarioId, aparelhoId) {
  if (!ID_VALIDO.test(String(aparelhoId || ''))) return false;
  const r = await pool.query(`UPDATE aparelhos SET ultimo_uso=NOW() WHERE usuario_id=$1 AND aparelho_hash=$2 AND status='confiavel' AND expira_em > NOW() RETURNING id`, [usuarioId, hashDe(aparelhoId)]);
  return r.rows.length > 0;
}
async function marcarConfiavel(usuario, aparelhoId, req) {
  if (!ID_VALIDO.test(String(aparelhoId || ''))) return;
  await pool.query(
    `INSERT INTO aparelhos (clinica_id, usuario_id, aparelho_hash, status, nome, ip, expira_em, decidido_em, ultimo_uso)
     VALUES ($1,$2,$3,'confiavel',$4,$5,NOW() + INTERVAL '${DIAS_CONFIANCA} days',NOW(),NOW())
     ON CONFLICT (usuario_id, aparelho_hash) DO UPDATE SET status='confiavel', expira_em=NOW() + INTERVAL '${DIAS_CONFIANCA} days', decidido_em=NOW(), ultimo_uso=NOW(), nome=EXCLUDED.nome, ip=EXCLUDED.ip`,
    [usuario.clinica_id, usuario.id, hashDe(aparelhoId), nomeAparelho(req.get('user-agent')), String(req.ip || '').slice(0, 60)]);
}

/* código de 6 números por e-mail: vale 10 minutos, 5 tentativas, no máximo 1 envio por minuto */
async function enviarCodigo(usuario, req) {
  const ult = (await pool.query(`SELECT enviado_em FROM codigos_login WHERE usuario_id=$1`, [usuario.id])).rows[0];
  if (ult && Date.now() - new Date(ult.enviado_em).getTime() < 55000) return { ok: true, repetido: true };
  const codigo = String(crypto.randomInt(0, 1000000)).padStart(6, '0');
  await pool.query(
    `INSERT INTO codigos_login (usuario_id, hash, expira_em, tentativas, enviado_em) VALUES ($1,$2,NOW() + INTERVAL '10 minutes',0,NOW())
     ON CONFLICT (usuario_id) DO UPDATE SET hash=EXCLUDED.hash, expira_em=EXCLUDED.expira_em, tentativas=0, enviado_em=NOW()`,
    [usuario.id, crypto.createHash('sha256').update(usuario.id + '|' + codigo).digest('hex')]);
  const destinos = [...new Set([usuario.email, process.env.ALERTA_EMAIL_PARA].filter((x) => x && /@/.test(x)).map((x) => x.toLowerCase()))];
  const r = await email.enviar({ para: destinos.join(','), assunto: `Código de entrada: ${codigo}`,
    texto: `Seu código para entrar na Clínica de Visão é: ${codigo}\n\nEle vale por 10 minutos. Aparelho: ${nomeAparelho(req.get('user-agent'))}. Endereço de rede: ${req.ip}.\n\nSe não foi você tentando entrar, não passe este código para ninguém e troque sua senha.` });
  if (!r.ok) return { ok: false };
  return { ok: true, destino: destinos.map(mascara).join(' e ') };
}
async function conferirCodigo(usuarioId, codigo) {
  const c = (await pool.query(`SELECT hash, expira_em, tentativas FROM codigos_login WHERE usuario_id=$1`, [usuarioId])).rows[0];
  if (!c || new Date(c.expira_em) < new Date()) return { ok: false, erro: 'O código venceu. Toque em Mandar outro código.' };
  if (c.tentativas >= 5) return { ok: false, erro: 'Muitos códigos errados. Toque em Mandar outro código.' };
  const certo = crypto.createHash('sha256').update(usuarioId + '|' + String(codigo || '').replace(/\D/g, '')).digest('hex');
  if (!crypto.timingSafeEqual(Buffer.from(certo), Buffer.from(c.hash))) {
    await pool.query(`UPDATE codigos_login SET tentativas = tentativas + 1 WHERE usuario_id=$1`, [usuarioId]);
    return { ok: false, erro: 'Código errado. Confira os 6 números no e-mail.' };
  }
  await pool.query(`DELETE FROM codigos_login WHERE usuario_id=$1`, [usuarioId]);
  return { ok: true };
}

/* ---------- Equipe: liberação de aparelho pelo Master ---------- */
async function liberacaoLigada(clinicaId) {
  const r = await pool.query(`SELECT liberar_aparelhos FROM clinicas WHERE id=$1`, [clinicaId]);
  return !r.rows.length || r.rows[0].liberar_aparelhos !== false;
}
async function avisarMaster(usuario, req, texto, assunto) {
  const para = process.env.ALERTA_EMAIL_PARA || process.env.BACKUP_EMAIL_PARA;
  if (email.ativo() && para) email.enviar({ para, assunto, texto: texto + `\n\nAparelho: ${nomeAparelho(req.get('user-agent'))}. Endereço de rede: ${req.ip}.\n\nAbra o sistema em Área Master, aba Equipe, quadro Aparelhos da equipe.` }).catch(() => {});
}
/* devolve 'liberado', 'pendente' ou 'recusado' */
async function situacaoEquipe(usuario, aparelhoId, req) {
  if (!ID_VALIDO.test(String(aparelhoId || ''))) return 'sem_id';
  const h = hashDe(aparelhoId);
  const ex = (await pool.query(`SELECT id, status FROM aparelhos WHERE usuario_id=$1 AND aparelho_hash=$2`, [usuario.id, h])).rows[0];
  if (ex && ex.status === 'liberado') { pool.query(`UPDATE aparelhos SET ultimo_uso=NOW(), ip=$2 WHERE id=$1`, [ex.id, String(req.ip || '').slice(0, 60)]).catch(() => {}); return 'liberado'; }
  if (ex) return ex.status === 'recusado' ? 'recusado' : 'pendente';
  const tem = (await pool.query(`SELECT 1 FROM aparelhos WHERE usuario_id=$1 AND status IN ('liberado','pendente','recusado') LIMIT 1`, [usuario.id])).rows.length;
  const primeiro = !tem;
  await pool.query(
    `INSERT INTO aparelhos (clinica_id, usuario_id, aparelho_hash, status, nome, ip, decidido_em, decidido_por, ultimo_uso)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) ON CONFLICT (usuario_id, aparelho_hash) DO NOTHING`,
    [usuario.clinica_id, usuario.id, h, primeiro ? 'liberado' : 'pendente', nomeAparelho(req.get('user-agent')), String(req.ip || '').slice(0, 60),
      primeiro ? new Date() : null, primeiro ? 'Sistema (primeiro aparelho)' : null, primeiro ? new Date() : null]);
  if (primeiro) {
    avisarMaster(usuario, req, `${usuario.nome} entrou pela primeira vez num aparelho e ele foi liberado sozinho, por ser o primeiro. Se não foi essa pessoa, remova o aparelho e troque a senha dela.`, `Aparelho liberado: ${usuario.nome}`);
    return 'liberado';
  }
  avisarMaster(usuario, req, `${usuario.nome} tentou entrar por um aparelho novo. Ele só entra depois que você liberar.`, `Liberar aparelho novo de ${usuario.nome}?`);
  return 'pendente';
}

module.exports = { confiavel, marcarConfiavel, enviarCodigo, conferirCodigo, situacaoEquipe, liberacaoLigada, segundoFatorLigado, nomeAparelho, mascara, ID_VALIDO, DIAS_CONFIANCA };
