/* ===== v4.9.49: aviso no celular (Web Push) quando chega mensagem nova na conversa =====
   - As chaves do aviso (VAPID) são criadas sozinhas na primeira vez e ficam no banco, trancadas com a chave do sistema.
   - O aviso leva só "Nova mensagem de Fulano". O texto da mensagem nunca vai no aviso.
   - Aparelho que deixou de existir (o navegador responde 404 ou 410) sai da lista sozinho. */
const webpush = require('web-push');
const pool = require('../db/pool');
const cripto = require('./cripto');

let chavesProntas = null;
async function chaves() {
  if (chavesProntas) return chavesProntas;
  let r = (await pool.query(`SELECT valor FROM config_servidor WHERE chave='vapid'`)).rows[0];
  if (!r) {
    const k = webpush.generateVAPIDKeys();
    await pool.query(`INSERT INTO config_servidor (chave, valor, atualizado_em, atualizado_por) VALUES ('vapid',$1,NOW(),'Sistema (avisos)') ON CONFLICT (chave) DO NOTHING`, [cripto.cifrar(JSON.stringify(k))]);
    r = (await pool.query(`SELECT valor FROM config_servidor WHERE chave='vapid'`)).rows[0];
  }
  const k = JSON.parse(cripto.decifrar(r.valor));
  const contato = process.env.ALERTA_EMAIL_PARA && /@/.test(process.env.ALERTA_EMAIL_PARA) ? process.env.ALERTA_EMAIL_PARA.split(',')[0].trim() : 'avisos@clinica-visao.onrender.com';
  webpush.setVapidDetails('mailto:' + contato, k.publicKey, k.privateKey);
  chavesProntas = k;
  return k;
}
async function chavePublica() { return (await chaves()).publicKey; }

async function enviarParaUsuario(usuarioId, aviso) {
  try {
    await chaves();
    const l = (await pool.query(`SELECT id, endpoint, p256dh, auth FROM push_inscricoes WHERE usuario_id=$1`, [usuarioId])).rows;
    await Promise.all(l.map(async (s) => {
      try {
        await webpush.sendNotification({ endpoint: s.endpoint, keys: { p256dh: s.p256dh, auth: s.auth } }, JSON.stringify(aviso), { TTL: 6 * 3600, urgency: 'high', topic: String(aviso.tag || '').replace(/[^A-Za-z0-9_-]/g, '').slice(0, 32) || undefined });
        pool.query(`UPDATE push_inscricoes SET ultimo_envio=NOW(), falhas=0 WHERE id=$1`, [s.id]).catch(() => {});
      } catch (e) {
        if (e.statusCode === 404 || e.statusCode === 410) await pool.query(`DELETE FROM push_inscricoes WHERE id=$1`, [s.id]).catch(() => {});
        else pool.query(`UPDATE push_inscricoes SET falhas=falhas+1 WHERE id=$1`, [s.id]).catch(() => {});
      }
    }));
    return l.length;
  } catch (e) { console.error('Aviso no celular falhou:', e.message); return 0; }
}
module.exports = { chavePublica, enviarParaUsuario };
