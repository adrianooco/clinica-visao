const pool = require('../db/pool');
const cripto = require('./cripto');

/* v4.9.34: configurações de e-mail e backup que o Master liga pela tela, sem entrar no Render.
   Ficam no banco, criptografadas com a chave do sistema. O que estiver no Render sempre vale mais:
   na partida, só preenche o que o Render não tem. */
const CHAVES = ['BREVO_API_KEY', 'EMAIL_DE', 'EMAIL_NOME', 'BACKUP_EMAIL_PARA', 'BACKUP_SENHA', 'ALERTA_EMAIL_PARA'];
const SEGREDOS = ['BREVO_API_KEY', 'BACKUP_SENHA'];
const doRender = new Set(CHAVES.filter((k) => process.env[k]));
const doSistema = new Set();

async function carregar() {
  const r = await pool.query(`SELECT chave, valor FROM config_servidor WHERE chave = ANY($1)`, [CHAVES]);
  for (const x of r.rows) {
    if (doRender.has(x.chave)) continue;
    try { process.env[x.chave] = cripto.decifrar(x.valor); doSistema.add(x.chave); } catch (e) { console.error('Configuração ilegível:', x.chave); }
  }
  if (doSistema.size) console.log('Configurações de e-mail e backup lidas do sistema: ' + [...doSistema].filter((k) => !SEGREDOS.includes(k)).join(', ') + (SEGREDOS.some((k) => doSistema.has(k)) ? ' e as senhas' : '') + '.');
}

/* grava só o que veio preenchido; o que está no Render não é trocado por aqui */
async function salvar(campos, quem) {
  const ignorados = [];
  for (const [k, v] of Object.entries(campos)) {
    if (!CHAVES.includes(k) || v == null || v === '') continue;
    if (doRender.has(k)) { ignorados.push(k); continue; }
    await pool.query(`INSERT INTO config_servidor (chave, valor, atualizado_em, atualizado_por) VALUES ($1,$2,NOW(),$3)
      ON CONFLICT (chave) DO UPDATE SET valor=$2, atualizado_em=NOW(), atualizado_por=$3`, [k, cripto.cifrar(String(v)), quem || null]);
    process.env[k] = String(v); doSistema.add(k);
  }
  return { ignorados };
}

function estado() {
  const o = {};
  for (const k of CHAVES) o[k] = doRender.has(k) ? 'render' : doSistema.has(k) ? 'sistema' : null;
  return o;
}
module.exports = { CHAVES, carregar, salvar, estado };
