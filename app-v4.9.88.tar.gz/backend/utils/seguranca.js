const pool = require('../db/pool');

/* ===== v4.9.36 fase 2: blindagem de entradas e trava por IP =====

   1) LIMPEZA DE ENTRADAS (anti-XSS), num lugar só.
   Todo texto que chega perde os sinais < e > e os caracteres de controle invisíveis.
   O banco já é protegido contra injeção de SQL porque todas as consultas usam parâmetros ($1, $2...);
   a varredura em scripts/varrer-sql.js confere isso antes de cada versão.
   Na tela, todo texto passa por esc() antes de aparecer. As duas camadas juntas fecham o XSS.
   Senhas, chaves e códigos NÃO passam pela limpeza: o símbolo que a pessoa escolheu fica intacto. */
const CAMPOS_SEGREDO = new Set(['senha', 'senha_atual', 'nova_senha', 'senha_nova', 'senha2', 'password', 'confirmar_senha',
  'backup_senha', 'backup_senha2', 'chave_brevo', 'codigo', 'token']);
const CONTROLE = /[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g;

function limparTexto(v, chave) {
  if (typeof v === 'string') return chave && CAMPOS_SEGREDO.has(chave) ? v : v.replace(/[<>]/g, '').replace(CONTROLE, '');
  if (Array.isArray(v)) return v.map((x) => limparTexto(x, chave));
  if (v && typeof v === 'object') { const o = {}; for (const k of Object.keys(v)) o[k] = limparTexto(v[k], k); return o; }
  return v;
}
function limparEntrada(req, res, next) {
  if (req.body && typeof req.body === 'object') req.body = limparTexto(req.body);
  next();
}

/* Até a 4.9.35 a senha também perdia < e >. Quem criou senha com esses sinais tem guardada a versão sem eles.
   Na conferência, se a senha digitada tiver < ou >, tenta também a versão antiga. */
async function senhaConfere(bcrypt, digitada, hash) {
  if (!hash || typeof digitada !== 'string') return false;
  if (await bcrypt.compare(digitada, hash)) return true;
  return /[<>]/.test(digitada) ? bcrypt.compare(digitada.replace(/[<>]/g, ''), hash) : false;
}

/* 2) TRAVA POR IP. Mais de 30 falhas na mesma hora (senha errada, código errado, acesso negado no login
   ou abuso do cadastro público) bloqueiam aquele IP por 15 minutos em todo o sistema.
   Fica gravado no banco, então reiniciar o servidor não zera a contagem. */
const LIMITE = 30, JANELA_MS = 3600000, BLOQUEIO_MIN = 15;
const memoria = new Map(); // ip -> bloqueado_ate (ms), para não ir ao banco a cada pedido
const LIVRES = /^\/(health|ping|versao)(\/|$)/;

async function travaIp(req, res, next) {
  if (LIVRES.test(req.path)) return next();
  const ip = String(req.ip || '');
  let ate = memoria.get(ip);
  if (ate === undefined) {
    try {
      const r = await pool.query(`SELECT bloqueado_ate FROM seguranca_ip WHERE ip=$1 AND bloqueado_ate > NOW()`, [ip]);
      ate = r.rows.length ? new Date(r.rows[0].bloqueado_ate).getTime() : 0;
    } catch (e) { ate = 0; }
    memoria.set(ip, ate);
  }
  if (ate > Date.now()) {
    const min = Math.ceil((ate - Date.now()) / 60000);
    res.setHeader('Retry-After', String(min * 60));
    return res.status(429).json({ erro: `Muitas tentativas erradas deste aparelho ou rede. Espere ${min} minuto(s) e tente de novo.` });
  }
  next();
}

async function registrarFalha(ip, motivo) {
  ip = String(ip || ''); if (!ip) return;
  try {
    const r = await pool.query(
      `INSERT INTO seguranca_ip (ip, falhas, janela_inicio, ultimo_motivo) VALUES ($1, 1, NOW(), $2)
       ON CONFLICT (ip) DO UPDATE SET
         falhas = CASE WHEN seguranca_ip.janela_inicio > NOW() - INTERVAL '1 hour' THEN seguranca_ip.falhas + 1 ELSE 1 END,
         janela_inicio = CASE WHEN seguranca_ip.janela_inicio > NOW() - INTERVAL '1 hour' THEN seguranca_ip.janela_inicio ELSE NOW() END,
         ultimo_motivo = $2
       RETURNING falhas`, [ip, String(motivo || '').slice(0, 120)]);
    if (r.rows[0].falhas > LIMITE) {
      await pool.query(`UPDATE seguranca_ip SET bloqueado_ate = NOW() + INTERVAL '${BLOQUEIO_MIN} minutes', falhas = 0, janela_inicio = NOW() WHERE ip=$1`, [ip]);
      memoria.set(ip, Date.now() + BLOQUEIO_MIN * 60000);
      console.warn(`Trava de IP: ${ip} bloqueado por ${BLOQUEIO_MIN} minutos (${motivo}).`);
    }
  } catch (e) { console.error('Trava de IP:', e.message); }
}

/* conta como falha o que só acontece com senha errada ou força bruta: erros de login, de código e abuso público */
const CAMINHOS_LOGIN = /^\/(auth|auth2|public)(\/|$)/;
function contarFalhas(req, res, next) {
  if (!CAMINHOS_LOGIN.test(req.path) || req.method === 'GET') return next();
  res.on('finish', () => {
    const s = res.statusCode;
    if (s === 401 || s === 403 || s === 429 || (s === 400 && /\/(login|codigo|totp|verificar|recuperar|redefinir)/.test(req.path))) registrarFalha(req.ip, `${req.method} ${req.path} ${s}`);
  });
  next();
}

setInterval(() => {
  const a = Date.now(); for (const [k, v] of memoria) if (v < a) memoria.delete(k);
  pool.query(`DELETE FROM seguranca_ip WHERE (bloqueado_ate IS NULL OR bloqueado_ate < NOW()) AND janela_inicio < NOW() - INTERVAL '1 day'`).catch(() => {});
}, 10 * 60000).unref();

module.exports = { limparTexto, limparEntrada, senhaConfere, travaIp, contarFalhas, registrarFalha, CAMPOS_SEGREDO, LIMITE, BLOQUEIO_MIN };
