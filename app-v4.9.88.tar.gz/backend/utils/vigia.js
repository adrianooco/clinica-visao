/* Vigia da equipe: confere o que cada pessoa faz no sistema e avisa o Master quando algo foge do normal.
   Ele não pune ninguém sozinho. Quando acha um problema:
   1. grava uma ocorrência (com as provas: horários e quantidades, sem dados de paciente);
   2. se for o caso, cria um PEDIDO (encerrar as sessões ou bloquear a conta) que só roda quando o Master autoriza;
   3. a IA dá a opinião dela, usando só números e horários (nada de nome de paciente, CPF ou telefone);
   4. o Master pode abrir uma sindicância, ver a linha do tempo da pessoa, escrever o parecer e decidir.
   Tudo o que o Master decide fica registrado. */
const pool = require('../db/pool');
const email = require('./email');

const TZ = 'America/Sao_Paulo';
const LOCAL = (c) => `((${c}) AT TIME ZONE current_setting('TimeZone')) AT TIME ZONE '${TZ}'`;

/* limites: ajustados para uma clínica pequena, com 5 a 10 agendadores por cidade */
const LIMITES = {
  noite_inicio: 22, noite_fim: 6,   // das 22h às 6h
  noite_min: 3,                     // 3 ou mais alterações de madrugada
  fichas_aviso: 60, fichas_alta: 150, // fichas de paciente diferentes abertas em 24 horas
  exclusoes_aviso: 3, exclusoes_alta: 10,
  marcacoes_hora: 30,               // exames marcados numa mesma hora
  distancia_km: 150, distancia_horas: 3,
  falhas_conta: 10,
};

const TIPOS = {
  fora_horario: 'Mexeu no sistema de madrugada',
  muitas_fichas: 'Abriu muitas fichas de pacientes',
  exclusoes: 'Excluiu muitos registros',
  marcacao_massa: 'Marcou muitos exames em pouco tempo',
  dois_lugares: 'Entrou de dois lugares distantes',
  backup_baixado: 'Cópia completa dos dados baixada',
  admin_novo: 'Nova conta com poder de Master',
  falhas_login: 'Muitas senhas erradas numa conta',
};

const PEDIDOS = {
  encerrar_sessoes: 'Encerrar as sessões abertas',
  bloquear_usuario: 'Bloquear a conta',
  exigir_codigo: 'Desligar o acesso até trocar a senha',
};

function km(a, b) {
  const r = (x) => (x * Math.PI) / 180;
  const dLat = r(b.lat - a.lat), dLng = r(b.lng - a.lng);
  const h = Math.sin(dLat / 2) ** 2 + Math.cos(r(a.lat)) * Math.cos(r(b.lat)) * Math.sin(dLng / 2) ** 2;
  return 6371 * 2 * Math.asin(Math.sqrt(h));
}
const hora = (d) => new Date(String(d).slice(0, 19) + 'Z').toLocaleString('pt-BR', { timeZone: TZ, day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' });
const diaLocal = () => new Date().toLocaleDateString('sv-SE', { timeZone: TZ });

/* grava a ocorrência uma vez só (a chave evita repetir o mesmo aviso) e devolve se é nova */
async function registrar(clinicaId, o) {
  const r = await pool.query(
    `INSERT INTO vigia_ocorrencias (clinica_id, chave, tipo, gravidade, usuario_id, usuario_nome, usuario_papel, titulo, detalhe, evidencias, janela_inicio, janela_fim)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12) ON CONFLICT (clinica_id, chave) DO NOTHING RETURNING id`,
    [clinicaId, o.chave.slice(0, 160), o.tipo, o.gravidade, o.usuario_id || null, o.usuario_nome || null, o.usuario_papel || null,
      o.titulo, o.detalhe, JSON.stringify(o.evidencias || {}), o.inicio || null, o.fim || null]);
  if (!r.rows.length) return null;
  const id = r.rows[0].id;
  if (o.pedido && o.usuario_id) await criarPedido(clinicaId, { ocorrencia_id: id, tipo: o.pedido, alvo_usuario_id: o.usuario_id, alvo_nome: o.usuario_nome, motivo: o.titulo, origem: 'vigia' });
  return Object.assign({ id }, o);
}

async function criarPedido(clinicaId, p) {
  if (!PEDIDOS[p.tipo]) return null;
  const r = await pool.query(
    `INSERT INTO vigia_pedidos (clinica_id, ocorrencia_id, tipo, alvo_usuario_id, alvo_nome, motivo, origem)
     VALUES ($1,$2,$3,$4,$5,$6,$7) ON CONFLICT (clinica_id, tipo, alvo_usuario_id) WHERE status='pendente' DO NOTHING RETURNING id`,
    [clinicaId, p.ocorrencia_id || null, p.tipo, p.alvo_usuario_id, p.alvo_nome || null, String(p.motivo || '').slice(0, 300), p.origem || 'vigia']);
  return r.rows[0] ? r.rows[0].id : null;
}

/* ---------- AS REGRAS ---------- */
async function rodar(clinicaId) {
  const novas = [];
  const add = async (o) => { const n = await registrar(clinicaId, o); if (n) novas.push(n); };
  const dia = diaLocal();
  const q = async (sql, p = [clinicaId]) => (await pool.query(sql, p)).rows;

  /* 1. alterações de madrugada */
  for (const r of await q(`SELECT l.usuario_id, MAX(l.usuario_nome) AS nome, MAX(u.papel) AS papel, COUNT(*)::int AS n,
        MIN(l.criado_em) AS ini, MAX(l.criado_em) AS fim,
        json_agg(json_build_object('quando', l.criado_em, 'acao', l.acao, 'area', l.area) ORDER BY l.criado_em) AS lista
      FROM acessos_log l JOIN usuarios u ON u.id=l.usuario_id
      WHERE l.clinica_id=$1 AND u.papel<>'admin' AND l.acao NOT IN ('GET') AND l.criado_em > NOW() - INTERVAL '24 hours'
        AND (EXTRACT(HOUR FROM ${LOCAL('l.criado_em')}) >= ${LIMITES.noite_inicio} OR EXTRACT(HOUR FROM ${LOCAL('l.criado_em')}) < ${LIMITES.noite_fim})
      GROUP BY l.usuario_id HAVING COUNT(*) >= ${LIMITES.noite_min}`)) {
    await add({ chave: `fora_horario:${r.usuario_id}:${dia}`, tipo: 'fora_horario', gravidade: r.n >= 15 ? 'alta' : 'media',
      usuario_id: r.usuario_id, usuario_nome: r.nome, usuario_papel: r.papel, inicio: r.ini, fim: r.fim,
      titulo: `${r.nome} mexeu no sistema de madrugada`,
      detalhe: `${r.n} alteração(ões) entre ${LIMITES.noite_inicio}h e ${LIMITES.noite_fim}h. A primeira às ${hora(r.ini)} e a última às ${hora(r.fim)}.`,
      evidencias: { quantidade: r.n, acoes: r.lista.slice(0, 40).map((x) => ({ quando: x.quando, acao: x.acao, area: x.area })) },
      pedido: r.n >= 15 ? 'encerrar_sessoes' : null });
  }

  /* 2. muitas fichas de pacientes diferentes abertas (risco de copiarem a lista de pacientes) */
  for (const r of await q(`SELECT l.usuario_id, MAX(l.usuario_nome) AS nome, MAX(u.papel) AS papel,
        COUNT(DISTINCT substring(l.caminho from '/pacientes/([0-9a-f-]{36})'))::int AS n, MIN(l.criado_em) AS ini, MAX(l.criado_em) AS fim
      FROM acessos_log l JOIN usuarios u ON u.id=l.usuario_id
      WHERE l.clinica_id=$1 AND u.papel<>'admin' AND l.area='paciente' AND l.acao='GET' AND l.caminho ~ '/pacientes/[0-9a-f-]{36}'
        AND l.criado_em > NOW() - INTERVAL '24 hours'
      GROUP BY l.usuario_id HAVING COUNT(DISTINCT substring(l.caminho from '/pacientes/([0-9a-f-]{36})')) >= ${LIMITES.fichas_aviso}`)) {
    const alta = r.n >= LIMITES.fichas_alta;
    await add({ chave: `muitas_fichas:${r.usuario_id}:${dia}`, tipo: 'muitas_fichas', gravidade: alta ? 'alta' : 'media',
      usuario_id: r.usuario_id, usuario_nome: r.nome, usuario_papel: r.papel, inicio: r.ini, fim: r.fim,
      titulo: `${r.nome} abriu ${r.n} fichas de pacientes em 24 horas`,
      detalhe: `Foram ${r.n} pacientes diferentes, das ${hora(r.ini)} às ${hora(r.fim)}. Num dia normal de exame, um agendador abre bem menos. Pode ser alguém copiando a lista de pacientes.`,
      evidencias: { fichas_diferentes: r.n }, pedido: alta ? 'bloquear_usuario' : null });
  }

  /* 3. exclusões */
  for (const r of await q(`SELECT l.usuario_id, MAX(l.usuario_nome) AS nome, MAX(u.papel) AS papel, COUNT(*)::int AS n,
        MIN(l.criado_em) AS ini, MAX(l.criado_em) AS fim,
        json_agg(json_build_object('quando', l.criado_em, 'area', l.area) ORDER BY l.criado_em) AS lista
      FROM acessos_log l JOIN usuarios u ON u.id=l.usuario_id
      WHERE l.clinica_id=$1 AND u.papel<>'admin' AND l.acao='DELETE' AND l.criado_em > NOW() - INTERVAL '24 hours'
      GROUP BY l.usuario_id HAVING COUNT(*) >= ${LIMITES.exclusoes_aviso}`)) {
    const alta = r.n >= LIMITES.exclusoes_alta;
    const nomes = { paciente: ['paciente', 'pacientes'], agendamento: ['agendamento', 'agendamentos'], agenda: ['dia de agenda', 'dias de agenda'], receita: ['receita', 'receitas'], prontuario: ['prontuário', 'prontuários'], cidade: ['cidade', 'cidades'] };
    const cont = {}; for (const x of r.lista) cont[x.area] = (cont[x.area] || 0) + 1;
    const partes = Object.entries(cont).map(([a, n]) => `${n} ${nomes[a] ? nomes[a][n > 1 ? 1 : 0] : a}`).join(', ');
    await add({ chave: `exclusoes:${r.usuario_id}:${dia}`, tipo: 'exclusoes', gravidade: alta ? 'alta' : 'media',
      usuario_id: r.usuario_id, usuario_nome: r.nome, usuario_papel: r.papel, inicio: r.ini, fim: r.fim,
      titulo: `${r.nome} excluiu ${r.n} registros em 24 horas`,
      detalhe: `Excluiu: ${partes}. Das ${hora(r.ini)} às ${hora(r.fim)}.`,
      evidencias: { quantidade: r.n, por_tipo: cont, acoes: r.lista.slice(0, 40) }, pedido: alta ? 'bloquear_usuario' : null });
  }

  /* 4. muitas marcações na mesma hora (marcação de mentira para ganhar comissão, por exemplo) */
  for (const r of await q(`SELECT a.usuario_id, MAX(u.nome) AS nome, MAX(u.papel) AS papel, date_trunc('hour', a.criado_em) AS h, COUNT(*)::int AS n
      FROM agendamentos a JOIN usuarios u ON u.id=a.usuario_id
      WHERE a.clinica_id=$1 AND u.papel<>'admin' AND a.criado_em > NOW() - INTERVAL '24 hours'
      GROUP BY a.usuario_id, date_trunc('hour', a.criado_em) HAVING COUNT(*) >= ${LIMITES.marcacoes_hora}`)) {
    await add({ chave: `marcacao_massa:${r.usuario_id}:${String(r.h).slice(0, 13)}`, tipo: 'marcacao_massa', gravidade: 'media',
      usuario_id: r.usuario_id, usuario_nome: r.nome, usuario_papel: r.papel, inicio: r.h, fim: r.h,
      titulo: `${r.nome} marcou ${r.n} exames numa hora só`,
      detalhe: `Foram ${r.n} marcações a partir das ${hora(r.h)}. Confira se os pacientes existem e se os telefones atendem.`,
      evidencias: { quantidade: r.n } });
  }

  /* 5. a mesma conta entrou de dois lugares longe um do outro em poucas horas (senha emprestada) */
  const ents = await q(`SELECT e.usuario_id, e.usuario_nome, u.papel, e.lat, e.lng, e.criado_em FROM entradas_log e JOIN usuarios u ON u.id=e.usuario_id
      WHERE e.clinica_id=$1 AND e.lat IS NOT NULL AND e.lng IS NOT NULL AND e.criado_em > NOW() - INTERVAL '24 hours' ORDER BY e.usuario_id, e.criado_em`);
  const porUsuario = new Map();
  for (const e of ents) { if (!porUsuario.has(e.usuario_id)) porUsuario.set(e.usuario_id, []); porUsuario.get(e.usuario_id).push(e); }
  for (const [uid, lista] of porUsuario) {
    let achou = null;
    for (let i = 1; i < lista.length && !achou; i++) for (let j = i - 1; j >= 0; j--) {
      const horas = (new Date(lista[i].criado_em) - new Date(lista[j].criado_em)) / 3600000;
      if (horas > LIMITES.distancia_horas) break;
      const d = km(lista[i], lista[j]);
      if (d >= LIMITES.distancia_km) { achou = { a: lista[j], b: lista[i], d: Math.round(d), horas }; break; }
    }
    if (achou) await add({ chave: `dois_lugares:${uid}:${dia}`, tipo: 'dois_lugares', gravidade: 'alta',
      usuario_id: uid, usuario_nome: achou.a.usuario_nome, usuario_papel: achou.a.papel, inicio: achou.a.criado_em, fim: achou.b.criado_em,
      titulo: `A conta de ${achou.a.usuario_nome} entrou de dois lugares a ${achou.d} km de distância`,
      detalhe: `Entrada às ${hora(achou.a.criado_em)} e outra às ${hora(achou.b.criado_em)}, ${achou.d} km longe. Ninguém viaja tão rápido: a senha pode estar com outra pessoa.`,
      evidencias: { km: achou.d, entradas: [{ quando: achou.a.criado_em, lat: achou.a.lat, lng: achou.a.lng }, { quando: achou.b.criado_em, lat: achou.b.lat, lng: achou.b.lng }] },
      pedido: 'encerrar_sessoes' });
  }

  /* 6. cópia completa dos dados baixada por uma pessoa (só admin consegue, mas o Master precisa saber) */
  for (const r of await q(`SELECT l.id, l.usuario_id, l.usuario_nome, l.criado_em FROM acessos_log l
      WHERE l.clinica_id=$1 AND l.area='backup' AND l.usuario_id IS NOT NULL AND l.criado_em > NOW() - INTERVAL '24 hours'`)) {
    await add({ chave: `backup_baixado:${r.id}`, tipo: 'backup_baixado', gravidade: 'baixa',
      usuario_id: r.usuario_id, usuario_nome: r.usuario_nome, usuario_papel: 'admin', inicio: r.criado_em, fim: r.criado_em,
      titulo: `${r.usuario_nome || 'Alguém'} baixou a cópia completa dos dados`,
      detalhe: `Às ${hora(r.criado_em)}. Se foi você, arquive. Se não foi, abra uma sindicância e troque a senha dessa conta.`,
      evidencias: {} });
  }

  /* 7. conta nova com poder de Master (a primeira conta da clínica não conta: é a do próprio dono) */
  for (const r of await q(`SELECT u.id, u.nome, u.criado_em FROM usuarios u WHERE u.clinica_id=$1 AND u.papel='admin' AND u.criado_em > NOW() - INTERVAL '24 hours'
      AND EXISTS (SELECT 1 FROM usuarios o WHERE o.clinica_id=u.clinica_id AND o.papel='admin' AND o.id<>u.id AND o.criado_em < u.criado_em)`)) {
    await add({ chave: `admin_novo:${r.id}`, tipo: 'admin_novo', gravidade: 'alta',
      usuario_id: r.id, usuario_nome: r.nome, usuario_papel: 'admin', inicio: r.criado_em, fim: r.criado_em,
      titulo: `Foi criada uma conta de Master: ${r.nome}`,
      detalhe: `Criada às ${hora(r.criado_em)}. Master vê e apaga tudo. Se foi você, arquive. Se não foi, autorize o bloqueio.`,
      evidencias: {}, pedido: 'bloquear_usuario' });
  }

  /* 8. muitas senhas erradas numa conta conhecida */
  const contas = await q(`SELECT id, nome, papel, lower(email) AS email FROM usuarios WHERE clinica_id=$1 AND ativo=TRUE`);
  if (contas.length) {
    const tent = (await pool.query(`SELECT chave, erros, inicio FROM login_tentativas WHERE inicio > NOW() - INTERVAL '24 hours' AND erros >= $1`, [LIMITES.falhas_conta])).rows;
    for (const t of tent) {
      const c = contas.find((x) => x.email && String(t.chave).toLowerCase().includes(x.email));
      if (!c) continue;
      await add({ chave: `falhas_login:${c.id}:${dia}`, tipo: 'falhas_login', gravidade: c.papel === 'admin' ? 'alta' : 'media',
        usuario_id: c.id, usuario_nome: c.nome, usuario_papel: c.papel, inicio: t.inicio, fim: t.inicio,
        titulo: `${t.erros} senhas erradas na conta de ${c.nome}`,
        detalhe: 'Pode ser a própria pessoa que esqueceu a senha ou alguém tentando adivinhar. O bloqueio automático por tentativas já está ligado.',
        evidencias: { erros: t.erros } });
    }
  }

  return novas;
}

/* ---------- O QUE O MASTER AUTORIZA ---------- */
async function executarPedido(clinicaId, master, pedidoId) {
  const p = (await pool.query(`SELECT * FROM vigia_pedidos WHERE id=$1 AND clinica_id=$2`, [pedidoId, clinicaId])).rows[0];
  if (!p) return { ok: false, mensagem: 'Pedido não encontrado.' };
  if (p.status !== 'pendente') return { ok: false, mensagem: 'Esse pedido já foi decidido.' };
  if (p.alvo_usuario_id && p.alvo_usuario_id === master.usuarioId) return { ok: false, mensagem: 'Você não pode bloquear a sua própria conta por aqui.' };
  const alvo = (await pool.query(`SELECT id, nome, papel, ativo FROM usuarios WHERE id=$1 AND clinica_id=$2`, [p.alvo_usuario_id, clinicaId])).rows[0];
  let mensagem;
  if (!alvo) mensagem = 'A conta não existe mais.';
  else if (p.tipo === 'encerrar_sessoes') {
    await pool.query(`UPDATE usuarios SET sessao_versao=COALESCE(sessao_versao,0)+1 WHERE id=$1`, [alvo.id]);
    mensagem = `As sessões de ${alvo.nome} foram encerradas. Ela precisa entrar de novo com a senha.`;
  } else if (p.tipo === 'bloquear_usuario' || p.tipo === 'exigir_codigo') {
    await pool.query(`UPDATE usuarios SET ativo=FALSE, sessao_versao=COALESCE(sessao_versao,0)+1 WHERE id=$1`, [alvo.id]);
    mensagem = `A conta de ${alvo.nome} foi bloqueada. Para liberar de novo: aba Equipe, Usuários da clínica, botão Reativar.`;
  } else return { ok: false, mensagem: 'Tipo de pedido desconhecido.' };
  try { require('../middleware/auth').limparCacheUsuario(); } catch (e) { /* sem cache */ }
  await pool.query(`UPDATE vigia_pedidos SET status='executado', resultado=$1, decidido_por=$2, decidido_em=NOW() WHERE id=$3`, [mensagem, master.nome || 'Master', p.id]);
  return { ok: true, mensagem };
}

/* ---------- OPINIÃO DA IA (só números e horários) ---------- */
async function contextoParaIA(clinicaId, oc) {
  const hist = oc.usuario_id ? (await pool.query(`SELECT tipo, status, criado_em FROM vigia_ocorrencias WHERE clinica_id=$1 AND usuario_id=$2 AND id<>$3 AND criado_em > NOW() - INTERVAL '90 days' ORDER BY criado_em DESC LIMIT 10`, [clinicaId, oc.usuario_id, oc.id])).rows : [];
  const base = oc.usuario_id ? (await pool.query(`SELECT COUNT(*) FILTER (WHERE acao<>'GET')::float / 30 AS alter_dia,
      COUNT(*) FILTER (WHERE area='paciente' AND acao='GET')::float / 30 AS fichas_dia
      FROM acessos_log WHERE clinica_id=$1 AND usuario_id=$2 AND criado_em > NOW() - INTERVAL '30 days'`, [clinicaId, oc.usuario_id])).rows[0] : {};
  const papel = { atendente: 'agendador', profissional: 'profissional de exame', gestor: 'gestor de vendas', admin: 'administrador' }[oc.usuario_papel] || 'usuário';
  const ev = oc.evidencias || {};
  const resumoEv = {};
  for (const k of ['quantidade', 'fichas_diferentes', 'km', 'erros', 'por_tipo']) if (ev[k] !== undefined) resumoEv[k] = ev[k];
  if (Array.isArray(ev.acoes)) resumoEv.horarios = ev.acoes.slice(0, 20).map((a) => `${hora(a.quando)} ${a.acao || 'DELETE'} ${a.area}`);
  return `Tipo do alerta: ${TIPOS[oc.tipo] || oc.tipo}. Gravidade calculada: ${oc.gravidade}.
Quem: um ${papel} (nome omitido).
O que o vigia viu: ${String(oc.detalhe || '').replace(oc.usuario_nome || '§§', 'a pessoa')}
Provas (sem dados de paciente): ${JSON.stringify(resumoEv)}
Média dessa pessoa nos últimos 30 dias: ${Number(base.alter_dia || 0).toFixed(1)} alterações por dia e ${Number(base.fichas_dia || 0).toFixed(1)} fichas abertas por dia.
Alertas anteriores dessa pessoa em 90 dias: ${hist.length ? hist.map((h) => `${TIPOS[h.tipo] || h.tipo} (${h.status})`).join('; ') : 'nenhum'}.`;
}

async function analisarComIA(clinicaId, ocorrenciaId) {
  const ia = require('../routes/ia');
  if (!ia.provedor()) return { ok: false, mensagem: 'A IA não está ligada. Falta a chave GEMINI_API_KEY no Render.' };
  const oc = (await pool.query(`SELECT * FROM vigia_ocorrencias WHERE id=$1 AND clinica_id=$2`, [ocorrenciaId, clinicaId])).rows[0];
  if (!oc) return { ok: false, mensagem: 'Ocorrência não encontrada.' };
  const sistema = `Você é o Vigia de uma clínica de exame de vista no Brasil. Ajuda o dono (Master) a decidir o que fazer com um alerta sobre um funcionário.
Seja justo: um alerta não prova culpa. Considere explicações normais (dia de exame cheio, erro de digitação, trabalho em outra cidade) antes de suspeitar.
Responda em português do Brasil, frases curtas, voz ativa, sem markdown, sem asteriscos e sem travessões.
Responda SÓ com JSON: {"parecer": string de 2 a 4 frases, "recomendacao": uma de "arquivar", "conversar", "sindicancia", "encerrar_sessoes", "bloquear_usuario", "motivo": string de 1 frase}.
Use "bloquear_usuario" só quando houver risco claro para os dados dos pacientes ou para o caixa.`;
  const texto = await ia.chamarIA(sistema, [{ papel: 'eu', texto: await contextoParaIA(clinicaId, oc) }], true);
  let j = {};
  try { const m = /\{[\s\S]*\}/.exec(texto); j = JSON.parse(m ? m[0] : texto); } catch (e) { j = { parecer: texto }; }
  const limpar = (t) => String(t || '').replace(/[*#]/g, '').replace(/\s+—\s+/g, ', ').replace(/—/g, ', ').trim();
  const recs = ['arquivar', 'conversar', 'sindicancia', 'encerrar_sessoes', 'bloquear_usuario'];
  const rec = recs.includes(j.recomendacao) ? j.recomendacao : null;
  const parecer = limpar(j.parecer) + (j.motivo ? ' ' + limpar(j.motivo) : '');
  await pool.query(`UPDATE vigia_ocorrencias SET ia_parecer=$1, ia_recomendacao=$2 WHERE id=$3`, [parecer.slice(0, 1500), rec, oc.id]);
  let pedido = null;
  if (rec && PEDIDOS[rec] && oc.usuario_id && oc.status === 'aberta') pedido = await criarPedido(clinicaId, { ocorrencia_id: oc.id, tipo: rec, alvo_usuario_id: oc.usuario_id, alvo_nome: oc.usuario_nome, motivo: 'Sugestão da IA: ' + oc.titulo, origem: 'ia' });
  return { ok: true, parecer, recomendacao: rec, pedido };
}

/* ---------- ROTINA ---------- */
async function rodarTodas() {
  const clinicas = (await pool.query(`SELECT id, nome_fantasia FROM clinicas WHERE ativa=TRUE`)).rows;
  for (const c of clinicas) {
    const novas = await rodar(c.id).catch((e) => { console.error('Vigia:', e.message); return []; });
    if (!novas.length) continue;
    /* a IA dá a opinião das ocorrências graves logo de cara (no máximo 3 por rodada, para caber no plano gratuito) */
    for (const n of novas.filter((x) => x.gravidade === 'alta').slice(0, 3)) await analisarComIA(c.id, n.id).catch(() => {});
    const para = process.env.ALERTA_EMAIL_PARA || process.env.BACKUP_EMAIL_PARA;
    const serias = novas.filter((x) => x.gravidade !== 'baixa');
    if (para && email.ativo() && serias.length) {
      await email.enviar({ para, assunto: `Vigia: ${serias.length} alerta(s) da equipe em ${c.nome_fantasia}`,
        texto: 'O Vigia achou isto:\n\n' + serias.map((x) => `- ${x.titulo}. ${x.detalhe}`).join('\n') + '\n\nEntre no sistema, Master, aba Equipe, quadro Vigia da equipe. Nada foi bloqueado: os pedidos esperam a sua autorização.' }).catch(() => {});
    }
  }
}

function iniciar() {
  setTimeout(() => rodarTodas().catch((e) => console.error('Vigia:', e.message)), 5 * 60 * 1000).unref();
  setInterval(() => rodarTodas().catch((e) => console.error('Vigia:', e.message)), 60 * 60 * 1000).unref();
  console.log('Vigia da equipe ligado.');
}

module.exports = { rodar, rodarTodas, iniciar, executarPedido, criarPedido, analisarComIA, TIPOS, PEDIDOS, LIMITES, hora };
