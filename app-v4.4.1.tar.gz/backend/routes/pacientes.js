const express = require('express');
const pool = require('../db/pool');
const { exigirLogin, exigirPermissao, exigirAdmin } = require('../middleware/auth');

const { limparExtras } = require('../utils/ficha');
const cripto = require('../utils/cripto');
const { conferirContato } = require('../utils/validar');

/* a lista e as respostas não carregam as fotos (pesadas): só dizem se existem. A foto vem sob demanda em /:id/fotos */
function leve(l) {
  if (!l) return l;
  const { foto_receita_url, foto_armacao_url, ...resto } = cripto.abrirCpf(l);
  if (foto_receita_url === undefined && foto_armacao_url === undefined) return resto; // a lista já traz só os avisos tem_foto_*
  return { ...resto, tem_foto_receita: !!foto_receita_url, tem_foto_armacao: !!foto_armacao_url };
}
const fotoGrava = (v) => (v ? cripto.cifrar(v) : null);
const router = express.Router();
router.use(exigirLogin);

/* Um usuário restrito a uma cidade só vê/edita pacientes daquela cidade.
   Sem restrição (admin itinerante), vê a clínica toda. */
function filtroUnidade(req, params, proximoIndice) {
  if (!req.usuario.unidadeId) return { sql: '', params };
  params.push(req.usuario.unidadeId);
  return { sql: ` AND unidade_id=$${proximoIndice}`, params };
}

/* agendador (atendente) só enxerga o mínimo pra marcar horário: nome e telefone.
   CPF, endereço e fotos ficam só com profissional e admin. */
const ehAgendador = (req) => req.usuario.papel === 'atendente' && !(req.usuario.permissoes || []).includes('pacientes');

/* a lista não puxa as fotos do banco (são pesadas): só pergunta se existem */
let colunasLista = null;
async function colunasSemFotos() {
  if (colunasLista) return colunasLista;
  const r = await pool.query(`SELECT column_name FROM information_schema.columns WHERE table_schema='public' AND table_name='pacientes' ORDER BY ordinal_position`);
  const cols = r.rows.map((x) => x.column_name).filter((c) => c !== 'foto_receita_url' && c !== 'foto_armacao_url');
  colunasLista = cols.map((c) => `"${c}"`).join(', ')
    + `, (foto_receita_url IS NOT NULL AND foto_receita_url <> '') AS tem_foto_receita, (foto_armacao_url IS NOT NULL AND foto_armacao_url <> '') AS tem_foto_armacao`;
  return colunasLista;
}
router.get('/', async (req, res) => {
  const params = [req.usuario.clinicaId];
  const f = filtroUnidade(req, params, 2);
  const colunas = ehAgendador(req) ? 'id, unidade_id, nome_completo, telefone' : await colunasSemFotos();
  const r = await pool.query(
    `SELECT ${colunas} FROM pacientes WHERE clinica_id=$1 AND deletado_em IS NULL${f.sql} ORDER BY nome_completo`,
    f.params
  );
  res.json(ehAgendador(req) ? r.rows : r.rows.map(leve));
});

/* foto sob demanda: só quem pode ver a ficha completa */
router.get('/:id/fotos', async (req, res) => {
  if (ehAgendador(req)) return res.status(403).json({ erro: 'Seu acesso não permite abrir essa parte do sistema.' });
  const params = [req.params.id, req.usuario.clinicaId];
  const f = filtroUnidade(req, params, 3);
  const r = await pool.query(`SELECT foto_receita_url, foto_armacao_url FROM pacientes WHERE id=$1 AND clinica_id=$2 AND deletado_em IS NULL${f.sql}`, f.params);
  if (!r.rows.length) return res.status(404).json({ erro: 'Paciente não encontrado.' });
  res.setHeader('Cache-Control', 'no-store');
  res.json(cripto.abrirPaciente(r.rows[0]));
});

router.post('/', async (req, res) => {
  let { nome_completo, cpf, telefone, cep, endereco, bairro, cidade, agendado_por, foto_receita_url, foto_armacao_url, data_nascimento } = req.body;
  let extras = limparExtras(req.body.dados_extras);
  /* o agendador só grava: documento (CPF e nascimento) e receita lida por foto. Não grava endereço nem outros dados, e nunca lê a ficha de volta. */
  if (ehAgendador(req)) {
    cep = endereco = bairro = cidade = foto_armacao_url = null;
    extras = { receita_status: extras.receita_status, receita_digitada: extras.receita_digitada };
    Object.keys(extras).forEach((k) => extras[k] === undefined && delete extras[k]);
  }
  if (!nome_completo) return res.status(400).json({ erro: 'Informe o nome.' });
  const msgContato = conferirContato({ cpf, telefone }); if (msgContato) return res.status(400).json({ erro: msgContato });
  if (cripto.fotoGrande(foto_receita_url) || cripto.fotoGrande(foto_armacao_url)) return res.status(413).json({ erro: 'Foto muito grande. Tire outra com menos qualidade.' });
  // quem está restrito a uma cidade sempre cadastra nessa cidade; admin pode escolher (ou deixar em branco = compartilhado)
  const unidade_id = req.usuario.unidadeId || req.body.unidade_id || null;
  try {
    const r = await pool.query(
      `INSERT INTO pacientes (clinica_id, unidade_id, nome_completo, cpf, telefone, cep, endereco, bairro, cidade, agendado_por, foto_receita_url, foto_armacao_url, data_nascimento, dados_extras, termo_lgpd_aceito_em, termo_lgpd_versao, cpf_idx)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14, CASE WHEN $15 THEN NOW() END, CASE WHEN $15 THEN '2026-10-v1' END, $16) RETURNING *`,
      [req.usuario.clinicaId, unidade_id, nome_completo, cpf ? cripto.cifrar(cpf) : null, telefone || null, cep || null, endereco || null, bairro || null, cidade || null, agendado_por || null, fotoGrava(foto_receita_url), fotoGrava(foto_armacao_url), data_nascimento || null, JSON.stringify(extras), req.body.aceite_lgpd === true, cripto.indiceCpf(cpf)]
    );
    const novo = r.rows[0];
    res.status(201).json(ehAgendador(req) ? { id: novo.id, unidade_id: novo.unidade_id, nome_completo: novo.nome_completo, telefone: novo.telefone } : leve(novo));
  } catch (e) {
    if (e.code === '23505') return res.status(409).json({ erro: 'Já existe um paciente com esse CPF nesta clínica.' });
    console.error(e); res.status(500).json({ erro: 'Erro ao salvar paciente.' });
  }
});

router.put('/:id', exigirPermissao('pacientes'), async (req, res) => {
  const { nome_completo, cpf, telefone, cep, endereco, bairro, cidade, agendado_por, foto_receita_url, foto_armacao_url, data_nascimento } = req.body;
  if (!nome_completo) return res.status(400).json({ erro: 'Informe o nome.' });
  const msgContato = conferirContato({ cpf, telefone }); if (msgContato) return res.status(400).json({ erro: msgContato });
  if (cripto.fotoGrande(foto_receita_url) || cripto.fotoGrande(foto_armacao_url)) return res.status(413).json({ erro: 'Foto muito grande. Tire outra com menos qualidade.' });
  const params = [nome_completo, cpf ? cripto.cifrar(cpf) : null, telefone || null, cep || null, endereco || null, bairro || null, cidade || null,
     agendado_por || null, fotoGrava(foto_receita_url), fotoGrava(foto_armacao_url), data_nascimento || null, req.params.id, req.usuario.clinicaId,
     req.body.dados_extras === undefined ? null : JSON.stringify(limparExtras(req.body.dados_extras)), cripto.indiceCpf(cpf)];
  const f = filtroUnidade(req, params, params.length + 1);
  try {
    const r = await pool.query(
      `UPDATE pacientes SET nome_completo=$1, cpf=$2, telefone=$3, cep=$4, endereco=$5, bairro=$6, cidade=$7,
        agendado_por=$8, foto_receita_url=COALESCE($9,foto_receita_url), foto_armacao_url=COALESCE($10,foto_armacao_url), data_nascimento=$11, dados_extras=COALESCE($14::jsonb,dados_extras), cpf_idx=$15
       WHERE id=$12 AND clinica_id=$13 AND deletado_em IS NULL${f.sql} RETURNING *`,
      f.params
    );
    if (!r.rows.length) return res.status(404).json({ erro: 'Paciente não encontrado.' });
    res.json(leve(r.rows[0]));
  } catch (e) {
    if (e.code === '23505') return res.status(409).json({ erro: 'Já existe um paciente com esse CPF nesta clínica.' });
    console.error(e); res.status(500).json({ erro: 'Erro ao atualizar paciente.' });
  }
});

/* soft delete: nunca apaga fisicamente o prontuário */
router.delete('/:id', exigirAdmin, async (req, res) => {
  const params = [req.params.id, req.usuario.clinicaId];
  const f = filtroUnidade(req, params, params.length + 1);
  const r = await pool.query(
    `UPDATE pacientes SET deletado_em = NOW() WHERE id=$1 AND clinica_id=$2${f.sql} RETURNING id`,
    f.params
  );
  if (!r.rows.length) return res.status(404).json({ erro: 'Paciente não encontrado.' });
  res.json({ ok: true });
});

module.exports = router;
