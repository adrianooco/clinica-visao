const express = require('express');
const pool = require('../db/pool');
const { exigirLogin, exigirAdmin } = require('../middleware/auth');

const router = express.Router();
router.use(exigirLogin);

/* Feriados e folgas da cidade (aniversário da cidade, ponto facultativo, evento local).
   unidade_id vazio vale para todas as cidades da clínica. */
router.get('/', async (req, res) => {
  const params = [req.usuario.clinicaId];
  let f = '';
  if (req.usuario.unidadeId) { params.push(req.usuario.unidadeId); f = ' AND (f.unidade_id IS NULL OR f.unidade_id=$2)'; }
  const r = await pool.query(
    `SELECT f.id, to_char(f.data,'YYYY-MM-DD') AS data, f.nome, f.unidade_id, u.nome AS cidade
     FROM feriados_locais f LEFT JOIN unidades u ON u.id = f.unidade_id
     WHERE f.clinica_id=$1${f} ORDER BY f.data`, params);
  res.json(r.rows);
});

router.post('/', exigirAdmin, async (req, res) => {
  const { data, nome, unidade_id } = req.body;
  if (!/^\d{4}-\d{2}-\d{2}$/.test(String(data || ''))) return res.status(400).json({ erro: 'Informe a data.' });
  const n = String(nome || '').trim().slice(0, 100);
  if (!n) return res.status(400).json({ erro: 'Informe o nome do feriado.' });
  if (unidade_id) {
    const u = await pool.query(`SELECT 1 FROM unidades WHERE id=$1 AND clinica_id=$2`, [unidade_id, req.usuario.clinicaId]);
    if (!u.rows.length) return res.status(400).json({ erro: 'Cidade inválida.' });
  }
  try {
    const r = await pool.query(`INSERT INTO feriados_locais (clinica_id, unidade_id, data, nome) VALUES ($1,$2,$3,$4) RETURNING id`, [req.usuario.clinicaId, unidade_id || null, data, n]);
    res.status(201).json({ id: r.rows[0].id });
  } catch (e) {
    if (e.code === '23505') return res.status(409).json({ erro: 'Essa data já está cadastrada para essa cidade.' });
    if (e.code === '22008' || e.code === '22007') return res.status(400).json({ erro: 'Data inválida.' });
    throw e;
  }
});

router.delete('/:id', exigirAdmin, async (req, res) => {
  const r = await pool.query(`DELETE FROM feriados_locais WHERE id=$1 AND clinica_id=$2 RETURNING id`, [req.params.id, req.usuario.clinicaId]);
  if (!r.rows.length) return res.status(404).json({ erro: 'Feriado não encontrado.' });
  res.json({ ok: true });
});

module.exports = router;
