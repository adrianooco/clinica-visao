/* v4.9.102: sincronização em partes da OCO.
   O bloco da OCO ({ dados, tomb }) ganha:
   - rv: { colecao: { id: versão } } — em que versão do servidor cada registro mudou por último;
   - rvDesde: a partir de qual versão o rv está completo; rvLoja: versão da última mudança nos dados da loja.
   Assim o aparelho pede "o que mudou desde a versão N" e recebe só isso. */
const COLECOES = ['clientes', 'vendas', 'ordens', 'contas', 'estoque', 'caixaMovimentos', 'fornecedores', 'compras', 'feedbacks', 'precos', 'lentesProntas', 'orcamentos', 'devolucoes', 'historico'];
const NOME_COL = /^[A-Za-z][A-Za-z0-9]{0,39}$/;
/* coleções = as conhecidas + qualquer lista de registros que o aparelho já guarda (ex.: uma coleção nova de versão futura) */
const colecoesDe = (...objs) => { const s = new Set(COLECOES); for (const o of objs) for (const [k, v] of Object.entries(o || {})) if (k !== 'loja' && NOME_COL.test(k) && Array.isArray(v)) s.add(k); return [...s]; };
const LIMITE_TOMB_DIAS = 120;
const u = (r) => Number((r && r._u) || 0);

/* depois de um envio completo: compara com o bloco anterior e marca a versão de quem mudou */
function comVersoes(anterior, novo, versao) {
  const rvAnt = (anterior && anterior.rv) || {}, dAnt = (anterior && anterior.dados) || {};
  const rv = {};
  for (const col of colecoesDe(novo.dados)) {
    const antes = new Map((dAnt[col] || []).map((r) => [r.id, r])), m = {};
    for (const r of (novo.dados[col] || [])) {
      const a = antes.get(r.id);
      m[r.id] = a && u(a) === u(r) && JSON.stringify(a) === JSON.stringify(r) ? ((rvAnt[col] || {})[r.id] || versao) : versao;
    }
    rv[col] = m;
  }
  const lojaIgual = anterior && JSON.stringify((anterior.dados || {}).loja || null) === JSON.stringify(novo.dados.loja || null);
  return { ...novo, rv, rvDesde: anterior && anterior.rvDesde ? anterior.rvDesde : versao, rvLoja: lojaIgual && anterior.rvLoja ? anterior.rvLoja : versao };
}

/* o que mudou desde a versão v (ou tudo, se o servidor não sabe responder a partir dali) */
function desde(corpo, v) {
  const d = corpo.dados || {};
  if (!corpo.rv || !corpo.rvDesde || v < corpo.rvDesde) return { parcial: false, dados: d, tomb: corpo.tomb || {} };
  const saida = {};
  for (const col of colecoesDe(d)) {
    const rv = corpo.rv[col] || {};
    const l = (d[col] || []).filter((r) => (rv[r.id] || corpo.rvDesde) > v);
    if (l.length) saida[col] = l;
  }
  if (d.loja && (corpo.rvLoja || 0) > v) saida.loja = d.loja;
  return { parcial: true, dados: saida, tomb: corpo.tomb || {} };
}

function validarParte(mudados, tomb, loja) {
  if (mudados !== undefined && (typeof mudados !== 'object' || mudados === null || Array.isArray(mudados))) return 'Dados inválidos.';
  let total = 0;
  for (const [col, l] of Object.entries(mudados || {})) {
    if (!NOME_COL.test(col) || col === 'loja') return 'Coleção inválida: ' + col;
    if (!Array.isArray(l)) return 'Coleção inválida: ' + col;
    total += l.length;
    for (const r of l) if (!r || typeof r !== 'object' || Array.isArray(r) || typeof r.id !== 'number') return 'Registro sem número em ' + col;
  }
  if (total > 200000) return 'Registros demais.';
  if (tomb !== undefined && (typeof tomb !== 'object' || tomb === null || Array.isArray(tomb))) return 'Exclusões inválidas.';
  for (const [col, m] of Object.entries(tomb || {})) { if (!NOME_COL.test(col) || typeof m !== 'object' || m === null || Array.isArray(m)) return 'Exclusões inválidas.'; }
  if (loja !== undefined && loja !== null && (typeof loja !== 'object' || Array.isArray(loja))) return 'Dados da loja inválidos.';
  return null;
}

/* junta o que o aparelho mandou no bloco do servidor (mesma regra do aparelho) */
function aplicar(corpo, parte, versao) {
  corpo.dados = corpo.dados || {}; corpo.tomb = corpo.tomb || {};
  if (!corpo.rv || !corpo.rvDesde) { const base = comVersoes(null, corpo, versao); corpo.rv = base.rv; corpo.rvDesde = versao; corpo.rvLoja = versao; }
  const limite = Date.now() - LIMITE_TOMB_DIAS * 86400000;
  let mudou = false, aplicados = 0;
  for (const col of colecoesDe(corpo.dados, parte.mudados, Object.fromEntries(Object.keys(parte.tomb || {}).map((k) => [k, []])))) {
    const vindos = (parte.mudados || {})[col] || [], tombVindo = (parte.tomb || {})[col] || {};
    if (!vindos.length && !Object.keys(tombVindo).length) continue;
    const lista = corpo.dados[col] || (corpo.dados[col] = []);
    const pos = new Map(lista.map((r, i) => [r.id, i]));
    const tomb = corpo.tomb[col] || (corpo.tomb[col] = {}), rv = corpo.rv[col] || (corpo.rv[col] = {});
    for (const [k, t] of Object.entries(tombVindo)) { const n = Number(t); if (Number.isFinite(n) && n > (tomb[k] || 0)) { tomb[k] = n; mudou = true; } }
    for (const r of vindos) {
      const t = tomb[r.id];
      if (t && t >= u(r)) continue;                       /* foi excluído depois desta mudança */
      if (t) { delete tomb[r.id]; mudou = true; }
      const i = pos.get(r.id);
      if (i === undefined) { pos.set(r.id, lista.length); lista.push(r); rv[r.id] = versao; mudou = true; aplicados++; }
      else if (u(r) > u(lista[i])) { lista[i] = r; rv[r.id] = versao; mudou = true; aplicados++; }
    }
    /* exclusões: tira da lista quem foi excluído depois da última mudança */
    const antes = lista.length;
    corpo.dados[col] = lista.filter((r) => { const t = tomb[r.id]; if (t && t >= u(r)) { delete rv[r.id]; return false; } return true; });
    if (corpo.dados[col].length !== antes) mudou = true;
    for (const k of Object.keys(tomb)) if (tomb[k] < limite) delete tomb[k];
  }
  if (parte.loja && typeof parte.loja === 'object') {
    const atual = corpo.dados.loja || {};
    if (u(parte.loja) > u(atual)) { corpo.dados.loja = Object.assign({}, atual, parte.loja); corpo.rvLoja = versao; mudou = true; }
  }
  return { mudou, aplicados };
}

/* o espelho para o financeiro do Master percorre a base toda: roda no máximo uma vez a cada 2 minutos por clínica */
const pendentes = new Map();
function espelharDepois(clinicaId, dados, versao) {
  const p = pendentes.get(clinicaId);
  if (p) { p.dados = dados; p.versao = versao; return; }
  const item = { dados, versao };
  pendentes.set(clinicaId, item);
  const rodar = () => { pendentes.delete(clinicaId); require('./ocoEspelho').espelhar(clinicaId, item.dados, item.versao).catch((e) => console.error('espelho', e.message)); };
  if (!espelharDepois.ultimo) espelharDepois.ultimo = new Map();
  const desdeUlt = Date.now() - (espelharDepois.ultimo.get(clinicaId) || 0);
  const espera = desdeUlt > 120000 ? 0 : 120000 - desdeUlt;
  setTimeout(() => { espelharDepois.ultimo.set(clinicaId, Date.now()); rodar(); }, espera).unref();
}

module.exports = { COLECOES, comVersoes, desde, validarParte, aplicar, espelharDepois };
