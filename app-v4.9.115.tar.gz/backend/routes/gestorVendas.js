const express = require('express');
const pool = require('../db/pool');
const cripto = require('../utils/cripto');
const { exigirLogin } = require('../middleware/auth');

/* Sincronização do OCO (sistema de vendas do gestor). O app guarda tudo no aparelho e funciona sem internet.
   Quando a internet volta, ele junta o que tem com o que está aqui. Cada clínica tem uma única base.
   O servidor só guarda e controla a versão; quem junta os registros é o aparelho. */
const router = express.Router();
router.use(exigirLogin);
router.use((req, res, next) => {
  if (req.usuario.papel !== 'gestor' && req.usuario.papel !== 'admin') return res.status(403).json({ erro: 'Esta área é do gestor de vendas.' });
  next();
});
/* v4.9.68: perfil Consulta. O gestor marcado como só consulta vê tudo e não muda nada. */
const ehConsulta = (req) => req.usuario.papel === 'gestor' && (req.usuario.permissoes || []).includes('oco_consulta');
router.use((req, res, next) => {
  if (req.method !== 'GET' && ehConsulta(req)) return res.status(403).json({ erro: 'Seu perfil é Consulta: você vê tudo, mas não muda nada.', consulta: true });
  next();
});

const COLECOES = ['clientes', 'vendas', 'ordens', 'contas', 'estoque', 'caixaMovimentos', 'fornecedores', 'compras', 'feedbacks', 'precos', 'lentesProntas'];
const MAX_REGISTROS = 200000;
const COPIAS_GUARDADAS = 15;

function validar(dados, tomb) {
  if (!dados || typeof dados !== 'object' || Array.isArray(dados)) return 'Dados inválidos.';
  let total = 0;
  for (const c of COLECOES) {
    const lista = dados[c];
    if (lista === undefined) continue;
    if (!Array.isArray(lista)) return 'Coleção inválida: ' + c;
    total += lista.length;
    for (const r of lista) if (!r || typeof r !== 'object' || Array.isArray(r) || typeof r.id !== 'number') return 'Registro sem número em ' + c;
  }
  if (total > MAX_REGISTROS) return 'Registros demais.';
  if (dados.loja !== undefined && (typeof dados.loja !== 'object' || dados.loja === null || Array.isArray(dados.loja))) return 'Dados da loja inválidos.';
  if (tomb !== undefined && (typeof tomb !== 'object' || tomb === null || Array.isArray(tomb))) return 'Exclusões inválidas.';
  return null;
}

router.get('/dados', async (req, res) => {
  const r = await pool.query(`SELECT versao, dados, atualizado_em, atualizado_por FROM gestor_vendas_dados WHERE clinica_id=$1`, [req.usuario.clinicaId]);
  if (!r.rows.length) return res.json({ versao: 0, dados: null, tomb: {}, clinica_id: req.usuario.clinicaId, consulta: ehConsulta(req) });
  const linha = r.rows[0];
  let corpo;
  try { corpo = JSON.parse(cripto.decifrar(linha.dados)); } catch (e) { console.error(e); return res.status(500).json({ erro: 'Não consegui abrir os dados guardados.' }); }
  res.json({ clinica_id: req.usuario.clinicaId, versao: linha.versao, dados: corpo.dados || null, tomb: corpo.tomb || {}, atualizado_em: linha.atualizado_em, atualizado_por: linha.atualizado_por, consulta: ehConsulta(req) });
});

router.put('/dados', async (req, res) => {
  const { base_versao, dados, tomb } = req.body || {};
  if (!Number.isInteger(base_versao) || base_versao < 0) return res.status(400).json({ erro: 'Versão inválida.' });
  const erro = validar(dados, tomb);
  if (erro) return res.status(400).json({ erro });
  let texto = cripto.cifrar(JSON.stringify({ dados, tomb: tomb || {} }));
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const atual = await client.query(`SELECT versao, dados FROM gestor_vendas_dados WHERE clinica_id=$1 FOR UPDATE`, [req.usuario.clinicaId]);
    const versaoAtual = atual.rows.length ? atual.rows[0].versao : 0;
    if (versaoAtual !== base_versao) { await client.query('ROLLBACK'); return res.status(409).json({ erro: 'Outro aparelho enviou dados antes. Vou juntar e tentar de novo.', versao: versaoAtual }); }
    const nova = versaoAtual + 1;
    /* v4.9.102: guarda a versão de cada registro, para os aparelhos baixarem só o que mudou */
    try { const ant = atual.rows.length ? JSON.parse(cripto.decifrar(atual.rows[0].dados)) : null; texto = cripto.cifrar(JSON.stringify(delta.comVersoes(ant, { dados, tomb: tomb || {} }, nova))); } catch (e) { console.error('rv', e.message); }
    if (!atual.rows.length) {
      await client.query(`INSERT INTO gestor_vendas_dados (clinica_id, versao, dados, atualizado_em, atualizado_por) VALUES ($1,$2,$3,NOW(),$4)`, [req.usuario.clinicaId, nova, texto, req.usuario.usuarioId]);
    } else {
      await client.query(`UPDATE gestor_vendas_dados SET versao=$2, dados=$3, atualizado_em=NOW(), atualizado_por=$4 WHERE clinica_id=$1`, [req.usuario.clinicaId, nova, texto, req.usuario.usuarioId]);
    }
    await client.query(`INSERT INTO gestor_vendas_copias (clinica_id, versao, dados, criado_em) VALUES ($1,$2,$3,NOW())`, [req.usuario.clinicaId, nova, texto]);
    await client.query(`DELETE FROM gestor_vendas_copias WHERE clinica_id=$1 AND versao <= $2`, [req.usuario.clinicaId, nova - COPIAS_GUARDADAS]);
    await client.query('COMMIT');
    res.json({ versao: nova });
    /* fase 1: copia para as tabelas do financeiro único, depois de responder, sem atrasar o aparelho */
    delta.espelharDepois(req.usuario.clinicaId, dados, nova);
  } catch (e) {
    await client.query('ROLLBACK').catch(() => {});
    console.error(e);
    res.status(500).json({ erro: 'Não consegui guardar os dados.' });
  } finally { client.release(); }
});

/* ===== v4.9.102: sincronização em partes =====
   O aparelho baixa só os registros que mudaram desde a última vez e manda só o que ele mudou.
   O servidor junta registro por registro, com a mesma regra do aparelho: vale o que foi mexido por último (_u),
   e exclusão vale se for mais nova que a última mudança. O bloco completo continua guardado como antes. */
const delta = require('../utils/ocoDelta');
router.get('/dados/desde', async (req, res) => {
  const v = parseInt(req.query.v, 10);
  const r = await pool.query(`SELECT versao, dados, atualizado_em FROM gestor_vendas_dados WHERE clinica_id=$1`, [req.usuario.clinicaId]);
  res.setHeader('Cache-Control', 'no-store');
  if (!r.rows.length) return res.json({ versao: 0, parcial: false, dados: null, tomb: {}, clinica_id: req.usuario.clinicaId, consulta: ehConsulta(req) });
  let corpo; try { corpo = JSON.parse(cripto.decifrar(r.rows[0].dados)); } catch (e) { return res.status(500).json({ erro: 'Não consegui abrir os dados guardados.' }); }
  const parte = delta.desde(corpo, Number.isInteger(v) ? v : -1);
  res.json({ clinica_id: req.usuario.clinicaId, versao: r.rows[0].versao, atualizado_em: r.rows[0].atualizado_em, consulta: ehConsulta(req), ...parte });
});
router.patch('/dados', async (req, res) => {
  const b = req.body || {};
  if (!Number.isInteger(b.base_versao) || b.base_versao < 0) return res.status(400).json({ erro: 'Versão inválida.' });
  const erro = delta.validarParte(b.mudados, b.tomb, b.loja);
  if (erro) return res.status(400).json({ erro });
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const atual = await client.query(`SELECT versao, dados FROM gestor_vendas_dados WHERE clinica_id=$1 FOR UPDATE`, [req.usuario.clinicaId]);
    if (!atual.rows.length) { await client.query('ROLLBACK'); return res.status(409).json({ erro: 'A base ainda não existe. Vou mandar tudo.', versao: 0, completo: true }); }
    const versaoAtual = atual.rows[0].versao, nova = versaoAtual + 1;
    const corpo = JSON.parse(cripto.decifrar(atual.rows[0].dados));
    const res1 = delta.aplicar(corpo, { mudados: b.mudados || {}, tomb: b.tomb || {}, loja: b.loja || null }, nova);
    if (!res1.mudou) { await client.query('ROLLBACK'); return res.json({ versao: versaoAtual, outros: versaoAtual !== b.base_versao, nada: true }); }
    const texto = cripto.cifrar(JSON.stringify(corpo));
    await client.query(`UPDATE gestor_vendas_dados SET versao=$2, dados=$3, atualizado_em=NOW(), atualizado_por=$4 WHERE clinica_id=$1`, [req.usuario.clinicaId, nova, texto, req.usuario.usuarioId]);
    /* cópia de segurança: no máximo uma a cada 10 minutos (antes era uma por envio) */
    const ult = await client.query(`SELECT MAX(criado_em) AS m FROM gestor_vendas_copias WHERE clinica_id=$1`, [req.usuario.clinicaId]);
    if (!ult.rows[0].m || Date.now() - new Date(ult.rows[0].m).getTime() > 10 * 60000) {
      await client.query(`INSERT INTO gestor_vendas_copias (clinica_id, versao, dados, criado_em) VALUES ($1,$2,$3,NOW())`, [req.usuario.clinicaId, nova, texto]);
      await client.query(`DELETE FROM gestor_vendas_copias WHERE clinica_id=$1 AND versao < (SELECT MIN(versao) FROM (SELECT versao FROM gestor_vendas_copias WHERE clinica_id=$1 ORDER BY versao DESC LIMIT $2) t)`, [req.usuario.clinicaId, COPIAS_GUARDADAS]);
    }
    await client.query('COMMIT');
    res.json({ versao: nova, outros: versaoAtual !== b.base_versao, aplicados: res1.aplicados });
    delta.espelharDepois(req.usuario.clinicaId, corpo.dados, nova);
  } catch (e) {
    await client.query('ROLLBACK').catch(() => {});
    console.error(e);
    res.status(500).json({ erro: 'Não consegui guardar os dados.' });
  } finally { client.release(); }
});

/* ===== Atendente IA do WhatsApp da ótica (v4.9.24) =====
   A IA responde os clientes sozinha. Só o Master (papel admin) liga, desliga e muda as instruções.
   A equipe vê as conversas, responde e assume quando precisar. */
const ia = require('../utils/iaAtendente');
const wpp = require('../utils/whatsapp');
const soMaster = (req, res, next) => (req.usuario.papel === 'admin' ? next() : res.status(403).json({ erro: 'Só o Master muda o atendente.' }));
const telOk = (t) => /^\d{10,20}$/.test(String(t || ''));
const HORAS_EQUIPE = 12;

router.get('/atendente/config', async (req, res) => {
  const cfg = await ia.lerConfig(req.usuario.clinicaId);
  res.json({
    ativo: !!cfg.ativo, numero_otica: cfg.numero_otica || '', nome_atendente: cfg.nome_atendente || '', horario: cfg.horario || '', instrucoes: cfg.instrucoes || '',
    atualizado_em: cfg.atualizado_em || null, atualizado_por: cfg.atualizado_por || null,
    gemini: ia.configurada(), meta: wpp.configurado(), master: req.usuario.papel === 'admin',
    webhook: (process.env.URL_PUBLICA || '').replace(/\/$/, '') + '/whatsapp/webhook',
  });
});

router.put('/atendente/config', soMaster, async (req, res) => {
  const b = req.body || {};
  const numero = String(b.numero_otica || '').replace(/\D/g, '');
  if (numero && (numero.length < 10 || numero.length > 13)) return res.status(400).json({ erro: 'Número da ótica inválido. Use DDD + número.' });
  if (b.ativo && !numero) return res.status(400).json({ erro: 'Para ligar a IA, informe o número de WhatsApp da ótica.' });
  if (numero) {
    const igual = await pool.query(`SELECT 1 FROM clinicas WHERE id=$1 AND RIGHT(REGEXP_REPLACE(COALESCE(whatsapp_numero,''),'\\D','','g'),10)=$2`, [req.usuario.clinicaId, numero.slice(-10)]);
    if (igual.rows.length) return res.status(400).json({ erro: 'Esse número é o da Clínica. A ótica precisa de um número separado.' });
  }
  await pool.query(
    `INSERT INTO atendente_config (clinica_id, ativo, numero_otica, nome_atendente, horario, instrucoes, atualizado_em, atualizado_por)
     VALUES ($1,$2,$3,$4,$5,$6,NOW(),$7)
     ON CONFLICT (clinica_id) DO UPDATE SET ativo=$2, numero_otica=$3, nome_atendente=$4, horario=$5, instrucoes=$6, atualizado_em=NOW(), atualizado_por=$7`,
    [req.usuario.clinicaId, !!b.ativo, numero || null, String(b.nome_atendente || '').slice(0, 40) || null,
      String(b.horario || '').slice(0, 300) || null, String(b.instrucoes || '').slice(0, 4000) || null, req.usuario.nome || null]);
  res.json({ ok: true });
});

/* simulador: testa a resposta da IA sem mandar nada para o WhatsApp (funciona antes da chave da Meta) */
const testes = new Map();
router.post('/atendente/testar', async (req, res) => {
  const hist = Array.isArray(req.body?.historico) ? req.body.historico : [];
  const limpo = hist.slice(-16).map((m) => ({ autor: m.autor === 'cliente' ? 'cliente' : 'ia', texto: String(m.texto || '').slice(0, 1500) })).filter((m) => m.texto);
  if (!limpo.length || limpo[limpo.length - 1].autor !== 'cliente') return res.status(400).json({ erro: 'Escreva uma mensagem de cliente para testar.' });
  const agora = Date.now(); const lista = (testes.get(req.usuario.usuarioId) || []).filter((t) => agora - t < 3600000);
  if (lista.length >= 60) return res.status(429).json({ erro: 'Muitos testes nesta hora. Tente mais tarde.' });
  lista.push(agora); testes.set(req.usuario.usuarioId, lista);
  try { res.json(await ia.responderCliente(req.usuario.clinicaId, limpo)); }
  catch (e) { console.error('Teste do atendente:', e.message); res.status(502).json({ erro: 'A IA não respondeu: ' + e.message }); }
});

router.get('/atendente/conversas', async (req, res) => {
  const r = await pool.query(
    `SELECT c.telefone, c.nome, c.precisa_equipe, c.nao_lidas, c.ultima_em, (c.equipe_ate IS NOT NULL AND c.equipe_ate > NOW()) AS com_equipe,
       (SELECT texto FROM wa_mensagens m WHERE m.clinica_id=c.clinica_id AND m.telefone=c.telefone ORDER BY criado_em DESC LIMIT 1) AS ultima
     FROM wa_conversas c WHERE c.clinica_id=$1 ORDER BY c.precisa_equipe DESC, c.ultima_em DESC LIMIT 200`, [req.usuario.clinicaId]);
  res.json(r.rows);
});

router.get('/atendente/conversas/:tel', async (req, res) => {
  if (!telOk(req.params.tel)) return res.status(400).json({ erro: 'Telefone inválido.' });
  const r = await pool.query(
    `SELECT autor, texto, enviado_por, criado_em FROM (SELECT * FROM wa_mensagens WHERE clinica_id=$1 AND telefone=$2 ORDER BY criado_em DESC LIMIT 200) t ORDER BY criado_em`,
    [req.usuario.clinicaId, req.params.tel]);
  await pool.query(`UPDATE wa_conversas SET nao_lidas=0 WHERE clinica_id=$1 AND telefone=$2`, [req.usuario.clinicaId, req.params.tel]);
  res.json(r.rows);
});

/* a equipe responde: a IA fica quieta nessa conversa por 12 horas */
router.post('/atendente/conversas/:tel/responder', async (req, res) => {
  if (!telOk(req.params.tel)) return res.status(400).json({ erro: 'Telefone inválido.' });
  const texto = String(req.body?.texto || '').trim().slice(0, 3500);
  if (!texto) return res.status(400).json({ erro: 'Escreva a resposta.' });
  if (!wpp.configurado()) return res.status(400).json({ erro: 'O WhatsApp automático ainda não está ligado (falta a chave da Meta).' });
  const conv = await pool.query(`SELECT phone_id, ultima_em FROM wa_conversas WHERE clinica_id=$1 AND telefone=$2`, [req.usuario.clinicaId, req.params.tel]);
  if (!conv.rows.length) return res.status(404).json({ erro: 'Conversa não encontrada.' });
  const ultCliente = await pool.query(`SELECT MAX(criado_em) t FROM wa_mensagens WHERE clinica_id=$1 AND telefone=$2 AND autor='cliente'`, [req.usuario.clinicaId, req.params.tel]);
  if (!ultCliente.rows[0].t || Date.now() - new Date(ultCliente.rows[0].t).getTime() > 24 * 3600000) {
    return res.status(400).json({ erro: 'Passaram mais de 24 horas da última mensagem do cliente. A Meta só deixa responder livre dentro de 24 horas. Chame pelo botão WhatsApp normal.' });
  }
  try { await wpp.responder(req.params.tel, texto, conv.rows[0].phone_id); }
  catch (e) { return res.status(502).json({ erro: 'O WhatsApp não aceitou: ' + e.message }); }
  await pool.query(`INSERT INTO wa_mensagens (clinica_id, telefone, autor, texto, enviado_por) VALUES ($1,$2,'equipe',$3,$4)`, [req.usuario.clinicaId, req.params.tel, texto, req.usuario.nome || null]);
  await pool.query(`UPDATE wa_conversas SET equipe_ate=NOW() + ($3 || ' hours')::interval, precisa_equipe=FALSE, ultima_em=NOW() WHERE clinica_id=$1 AND telefone=$2`, [req.usuario.clinicaId, req.params.tel, String(HORAS_EQUIPE)]);
  res.json({ ok: true });
});

router.post('/atendente/conversas/:tel/assumir', async (req, res) => {
  if (!telOk(req.params.tel)) return res.status(400).json({ erro: 'Telefone inválido.' });
  const devolver = !!req.body?.devolver;
  await pool.query(
    devolver ? `UPDATE wa_conversas SET equipe_ate=NULL, precisa_equipe=FALSE WHERE clinica_id=$1 AND telefone=$2`
      : `UPDATE wa_conversas SET equipe_ate=NOW() + INTERVAL '${HORAS_EQUIPE} hours' WHERE clinica_id=$1 AND telefone=$2`,
    [req.usuario.clinicaId, req.params.tel]);
  res.json({ ok: true });
});

/* ===== v4.9.47: histórico do sistema antigo (HJ Systems) =====
   Só leitura. Fica numa tabela separada e não entra em vendas, caixa, cobrança, comissão nem relatórios.
   As parcelas em aberto de lá são registro interno: sem juros, sem multa e sem cobrança.
   O arquivo chega trancado com senha (scrypt + AES-256-GCM, conteúdo compactado). No banco, cada cliente fica trancado com a chave do sistema. */
const zlib = require('zlib');
const cryptoNode = require('crypto');
const crip = require('../utils/cripto');
const normNome = (t) => String(t || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^a-z0-9 ]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 200);
const tel8 = (t) => { const d = String(t || '').replace(/\D/g, ''); return d.length >= 8 ? d.slice(-8) : null; };
function abrirArquivoLegado(env, senha) {
  if (!env || env.formato !== 'legado-protegido-1') throw new Error('Este não é o arquivo do histórico do sistema antigo.');
  const chave = cryptoNode.scryptSync(String(senha || ''), Buffer.from(env.salt, 'base64'), 32, { N: 16384, r: 8, p: 1 });
  const d = cryptoNode.createDecipheriv('aes-256-gcm', chave, Buffer.from(env.iv, 'base64'));
  d.setAuthTag(Buffer.from(env.tag, 'base64'));
  let bruto;
  try { bruto = Buffer.concat([d.update(Buffer.from(env.dados, 'base64')), d.final()]); } catch (e) { throw new Error('Senha errada ou arquivo danificado.'); }
  return JSON.parse(zlib.gunzipSync(bruto).toString('utf8'));
}
router.post('/legado/importar', async (req, res) => {
  if (req.usuario.papel !== 'admin') return res.status(403).json({ erro: 'Só o Master importa o histórico.' });
  let pac;
  try { pac = abrirArquivoLegado((req.body || {}).arquivo, (req.body || {}).senha); } catch (e) { return res.status(400).json({ erro: e.message }); }
  if (!pac || pac.formato !== 'legado-hj-1' || !Array.isArray(pac.clientes)) return res.status(400).json({ erro: 'Arquivo em formato desconhecido.' });
  const c = await pool.connect(); let n = 0;
  try {
    await c.query('BEGIN');
    for (const x of pac.clientes) {
      if (!x || !x.chave || !x.nome) continue;
      const aberto = (x.parcelas || []).reduce((t, p) => t + (Number(p.em_aberto) || 0), 0);
      await c.query(
        `INSERT INTO legado_clientes (clinica_id, chave, nome, nome_norm, cpf_idx, tel8, em_aberto, dados, origem)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)
         ON CONFLICT (clinica_id, chave) DO UPDATE SET nome=EXCLUDED.nome, nome_norm=EXCLUDED.nome_norm, cpf_idx=EXCLUDED.cpf_idx, tel8=EXCLUDED.tel8, em_aberto=EXCLUDED.em_aberto, dados=EXCLUDED.dados, origem=EXCLUDED.origem, importado_em=NOW()`,
        [req.usuario.clinicaId, String(x.chave).slice(0, 40), String(x.nome).slice(0, 200), normNome(x.nome), x.cpf ? crip.indiceCpf(x.cpf) : null, tel8(x.telefone),
          Math.round(aberto * 100) / 100, crip.cifrar(JSON.stringify(x)), String(pac.origem || '').slice(0, 120)]);
      n++;
    }
    await c.query('COMMIT');
  } catch (e) { await c.query('ROLLBACK').catch(() => {}); throw e; } finally { c.release(); }
  await pool.query(`INSERT INTO acessos_log (clinica_id, usuario_id, usuario_nome, acao, area, caminho, ip) VALUES ($1,$2,$3,'IMPORT','legado',$4,$5)`,
    [req.usuario.clinicaId, req.usuario.usuarioId || null, req.usuario.nome || null, `Histórico do sistema antigo: ${n} clientes`, req.ip]).catch(() => {});
  res.json({ ok: true, clientes: n });
});
/* v4.9.53: parcelas que o WhatsApp automático já lembrou hoje (a tela Financeiro marca como feitas) */
router.get('/lembretes-hoje', async (req, res) => {
  const cl = require('../utils/cobrancaLembretes');
  res.setHeader('Cache-Control', 'no-store');
  res.json({ automatico: cl.autoLigado(), enviados: await cl.enviadosHoje(req.usuario.clinicaId) });
});
router.get('/legado/resumo', async (req, res) => {
  const r = await pool.query(`SELECT COUNT(*)::int AS clientes, COALESCE(SUM(em_aberto),0)::float AS em_aberto, COUNT(*) FILTER (WHERE em_aberto > 0)::int AS com_aberto, MAX(importado_em) AS importado_em, MAX(origem) AS origem
    FROM legado_clientes WHERE clinica_id=$1`, [req.usuario.clinicaId]);
  res.json(r.rows[0]);
});
router.get('/legado/cliente', async (req, res) => {
  const cpf = String(req.query.cpf || '').replace(/\D/g, ''), nome = normNome(req.query.nome), t = tel8(req.query.tel);
  let r = { rows: [] };
  if (cpf.length === 11) r = await pool.query(`SELECT dados FROM legado_clientes WHERE clinica_id=$1 AND cpf_idx=$2`, [req.usuario.clinicaId, crip.indiceCpf(cpf)]);
  if (!r.rows.length && nome && t) r = await pool.query(`SELECT dados FROM legado_clientes WHERE clinica_id=$1 AND nome_norm=$2 AND tel8=$3`, [req.usuario.clinicaId, nome, t]);
  if (!r.rows.length && nome) { const x = await pool.query(`SELECT dados FROM legado_clientes WHERE clinica_id=$1 AND nome_norm=$2`, [req.usuario.clinicaId, nome]); if (x.rows.length === 1) r = x; }
  res.setHeader('Cache-Control', 'no-store');
  if (!r.rows.length) return res.json({ achou: false });
  const lista = r.rows.map((x) => JSON.parse(crip.decifrar(x.dados)));
  /* o mesmo CPF pode ter vindo em mais de um cadastro antigo: junta tudo */
  const h = lista.reduce((a, b) => ({ ...a, vendas: [...a.vendas, ...(b.vendas || [])], os: [...a.os, ...(b.os || [])], receitas: [...a.receitas, ...(b.receitas || [])], parcelas: [...a.parcelas, ...(b.parcelas || [])] }), { ...lista[0], vendas: [], os: [], receitas: [], parcelas: [] });
  res.json({ achou: true, historico: h });
});

/* v4.9.61: anexos da ficha do cliente (foto da receita de papel, documentos e foto do cliente).
   A imagem chega já reduzida pelo aparelho e fica cifrada no banco. Só gestor e admin da clínica acessam. */
const TIPOS_ANEXO = new Set(['receita', 'documento', 'perfil', 'outro', 'assinatura']); // v4.9.67: assinatura do cliente na venda
router.get('/anexos', async (req, res) => {
  const cli = parseInt(req.query.cliente, 10);
  if (!Number.isFinite(cli)) return res.status(400).json({ erro: 'Cliente inválido.' });
  const r = await pool.query(`SELECT id, tipo, descricao, tamanho, criado_em FROM oco_anexos WHERE clinica_id=$1 AND cliente_id=$2 ORDER BY criado_em DESC`, [req.usuario.clinicaId, cli]);
  res.setHeader('Cache-Control', 'no-store');
  res.json({ anexos: r.rows });
});
router.get('/anexos/:id', async (req, res) => {
  if (!/^\d{1,15}$/.test(req.params.id)) return res.status(404).json({ erro: 'Anexo não encontrado.' });
  const r = await pool.query(`SELECT imagem FROM oco_anexos WHERE clinica_id=$1 AND id=$2`, [req.usuario.clinicaId, req.params.id]);
  if (!r.rows.length) return res.status(404).json({ erro: 'Anexo não encontrado.' });
  res.setHeader('Cache-Control', 'no-store');
  try { res.json({ imagem: cripto.decifrar(r.rows[0].imagem) }); } catch (e) { res.status(500).json({ erro: 'Não consegui abrir o anexo.' }); }
});
router.post('/anexos', async (req, res) => {
  const { cliente, tipo, descricao, imagem } = req.body || {};
  const cli = parseInt(cliente, 10);
  if (!Number.isFinite(cli)) return res.status(400).json({ erro: 'Cliente inválido.' });
  if (!TIPOS_ANEXO.has(tipo)) return res.status(400).json({ erro: 'Tipo de anexo inválido.' });
  if (typeof imagem !== 'string' || !/^data:image\/(jpeg|png|webp);base64,[A-Za-z0-9+/=]+$/.test(imagem)) return res.status(400).json({ erro: 'Mande uma imagem JPG, PNG ou WEBP.' });
  if (imagem.length > 2_000_000) return res.status(413).json({ erro: 'Imagem grande demais.' });
  const n = await pool.query(`SELECT COUNT(*)::int AS n FROM oco_anexos WHERE clinica_id=$1 AND cliente_id=$2`, [req.usuario.clinicaId, cli]);
  if (n.rows[0].n >= 40) return res.status(409).json({ erro: 'Este cliente já tem 40 anexos. Apague algum antes.' });
  if (tipo === 'perfil') await pool.query(`DELETE FROM oco_anexos WHERE clinica_id=$1 AND cliente_id=$2 AND tipo='perfil'`, [req.usuario.clinicaId, cli]);
  const r = await pool.query(`INSERT INTO oco_anexos (clinica_id, cliente_id, tipo, descricao, imagem, tamanho, criado_por) VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING id, tipo, descricao, tamanho, criado_em`,
    [req.usuario.clinicaId, cli, tipo, String(descricao || '').slice(0, 200) || null, cripto.cifrar(imagem), Math.round(imagem.length * 3 / 4), req.usuario.usuarioId]);
  res.json(r.rows[0]);
});
router.delete('/anexos/:id', async (req, res) => {
  if (!/^\d{1,15}$/.test(req.params.id)) return res.status(404).json({ erro: 'Anexo não encontrado.' });
  const r = await pool.query(`DELETE FROM oco_anexos WHERE clinica_id=$1 AND id=$2 RETURNING cliente_id, tipo`, [req.usuario.clinicaId, req.params.id]);
  if (!r.rows.length) return res.status(404).json({ erro: 'Anexo não encontrado.' });
  await pool.query(`INSERT INTO acessos_log (clinica_id, usuario_id, usuario_nome, acao, area, caminho, ip) VALUES ($1,$2,$3,'DELETE','anexo',$4,$5)`,
    [req.usuario.clinicaId, req.usuario.usuarioId, req.usuario.nome || '', '/anexos/' + req.params.id + ' cliente ' + r.rows[0].cliente_id, req.ip]).catch(() => {});
  res.json({ ok: true });
});

module.exports = router;
