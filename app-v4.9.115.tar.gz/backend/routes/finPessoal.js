/* v4.9.100: Minha planilha (controle financeiro pessoal do dono, no Master).
   - Só o Master abre, e ainda pede uma senha separada (não é a senha de entrar no sistema).
     A senha fica guardada como resumo (bcrypt). Depois de acertar, o acesso vale 20 minutos.
   - Cada dia de exame numa cidade é um atendimento: pacientes atendidos, o que cada um comprou na ótica (OCO),
     preço e custo de cada item, como pagou, gastos do dia (combustível, almoço, diária, local, equipe, divulgação...)
     e doações. Vendas da loja que não vieram de um dia de exame aparecem à parte.
   - Mês: recebido por forma (dinheiro, Pix, cartão, cheque, depósito...), a receber, gastos e o resumo do lucro. */
const express = require('express');
const crypto = require('crypto');
const bcrypt = require('bcryptjs');
const pool = require('../db/pool');
const cripto = require('../utils/cripto');
const { exigirLogin, exigirAdmin, SEGREDO } = require('../middleware/auth');
const { cidade } = require('../utils/rotulo');

const router = express.Router();
router.use(exigirLogin, exigirAdmin);

const MES = /^\d{4}-\d{2}$/, DIA = /^\d{4}-\d{2}-\d{2}$/;
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const JANELA = 60, VALIDADE_MIN = 20;
const TIPOS = ['gasto', 'doacao', 'recebimento'];
const CATEGORIAS = ['Combustível', 'Almoço', 'Diária', 'Hospedagem', 'Pedágio', 'Local', 'Profissional', 'Ajudante', 'Comissão do agendador', 'Produtos', 'Divulgação', 'Taxa da maquininha', 'Internet e telefone', 'Outros'];
const FORMAS = ['Dinheiro', 'Pix', 'Cartão', 'Cheque', 'Depósito', 'Carnê', 'Na ótica', 'Outro'];
const so = (x) => String(x == null ? '' : x).replace(/\D/g, '');
const semAcento = (t) => String(t || '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().trim();
const dia = (d) => (d instanceof Date ? d.toISOString().slice(0, 10) : String(d || '').slice(0, 10));
const somaDias = (iso, n) => { const d = new Date(iso + 'T12:00:00Z'); d.setUTCDate(d.getUTCDate() + n); return d.toISOString().slice(0, 10); };
const r2 = (v) => Math.round((Number(v) || 0) * 100) / 100;
const num = (v) => { const n = Number(String(v == null ? '' : v).replace(',', '.')); return Number.isFinite(n) ? n : null; };
const fimDoMes = (mes) => somaDias(dia(new Date(Date.UTC(+mes.slice(0, 4), +mes.slice(5, 7), 1))), -1);
const hojeBR = () => new Date(Date.now() - 3 * 3600000).toISOString().slice(0, 10);

/* ---------- senha separada e acesso de 20 minutos ---------- */
const tentativas = new Map();
function assinar(obj) { const c = Buffer.from(JSON.stringify(obj)).toString('base64url'); return c + '.' + crypto.createHmac('sha256', SEGREDO + ':fin').update(c).digest('base64url'); }
function conferirToken(req) {
  const t = String(req.headers['x-fin-token'] || ''); const [c, s] = t.split('.');
  if (!c || !s) return false;
  const esperado = crypto.createHmac('sha256', SEGREDO + ':fin').update(c).digest('base64url');
  if (s.length !== esperado.length || !crypto.timingSafeEqual(Buffer.from(s), Buffer.from(esperado))) return false;
  let o; try { o = JSON.parse(Buffer.from(c, 'base64url').toString()); } catch (e) { return false; }
  return o.u === String(req.usuario.usuarioId) && o.c === String(req.usuario.clinicaId) && o.exp > Date.now();
}
function exigirToken(req, res, next) { if (!conferirToken(req)) return res.status(401).json({ erro: 'A planilha fechou. Digite a senha da planilha de novo.', fechada: true }); next(); }

router.get('/estado', async (req, res) => {
  const r = await pool.query(`SELECT 1 FROM fin_acesso WHERE clinica_id=$1`, [req.usuario.clinicaId]);
  res.json({ tem_senha: !!r.rows.length });
});
router.post('/senha', async (req, res) => {
  const b = req.body || {}, nova = String(b.nova || '');
  if (nova.length < 6) return res.status(400).json({ erro: 'A senha da planilha precisa ter pelo menos 6 caracteres.' });
  const r = await pool.query(`SELECT senha_hash FROM fin_acesso WHERE clinica_id=$1`, [req.usuario.clinicaId]);
  if (r.rows.length) {
    /* trocar: precisa da senha atual da planilha, ou da senha de entrar no sistema (se esqueceu) */
    let ok = false;
    if (b.atual) ok = await bcrypt.compare(String(b.atual), r.rows[0].senha_hash);
    if (!ok && b.senha_login) { const u = await pool.query(`SELECT senha_hash FROM usuarios WHERE id=$1`, [req.usuario.usuarioId]); ok = !!(u.rows[0] && await bcrypt.compare(String(b.senha_login), u.rows[0].senha_hash)); }
    if (!ok) return res.status(401).json({ erro: 'Senha atual errada.' });
  } else {
    const u = await pool.query(`SELECT senha_hash FROM usuarios WHERE id=$1`, [req.usuario.usuarioId]);
    if (u.rows[0] && await bcrypt.compare(nova, u.rows[0].senha_hash)) return res.status(400).json({ erro: 'Use uma senha diferente da senha de entrar no sistema.' });
  }
  const h = await bcrypt.hash(nova, 10);
  await pool.query(`INSERT INTO fin_acesso (clinica_id, senha_hash, atualizado_em) VALUES ($1,$2,NOW()) ON CONFLICT (clinica_id) DO UPDATE SET senha_hash=EXCLUDED.senha_hash, atualizado_em=NOW()`, [req.usuario.clinicaId, h]);
  res.json({ ok: true });
});
router.post('/entrar', async (req, res) => {
  const k = String(req.usuario.usuarioId), t = tentativas.get(k) || { n: 0, ate: 0 };
  if (t.ate > Date.now()) return res.status(429).json({ erro: 'Muitas tentativas erradas. Espere 15 minutos.' });
  const r = await pool.query(`SELECT senha_hash FROM fin_acesso WHERE clinica_id=$1`, [req.usuario.clinicaId]);
  if (!r.rows.length) return res.status(400).json({ erro: 'Crie a senha da planilha primeiro.' });
  if (!(await bcrypt.compare(String((req.body || {}).senha || ''), r.rows[0].senha_hash))) {
    t.n++; if (t.n >= 5) { t.ate = Date.now() + 15 * 60000; t.n = 0; } tentativas.set(k, t);
    return res.status(401).json({ erro: 'Senha da planilha errada.' });
  }
  tentativas.delete(k);
  const exp = Date.now() + VALIDADE_MIN * 60000;
  res.json({ token: assinar({ u: k, c: String(req.usuario.clinicaId), exp }), expira_em: exp });
});

/* ---------- dados da ótica ---------- */
async function oco(clinicaId) {
  const r = await pool.query(`SELECT dados FROM gestor_vendas_dados WHERE clinica_id=$1`, [clinicaId]);
  let d = {}; if (r.rows.length) { try { d = JSON.parse(cripto.decifrar(r.rows[0].dados)).dados || {}; } catch (e) { d = {}; } }
  return { clientes: d.clientes || [], vendas: d.vendas || [], contas: d.contas || [], estoque: d.estoque || [], precos: d.precos || [] };
}
function formaNormal(f) {
  const s = semAcento(f);
  if (!s) return 'Na ótica';
  if (/dinheiro|especie/.test(s)) return 'Dinheiro';
  if (/pix/.test(s)) return 'Pix';
  if (/credito|debito|cartao/.test(s)) return 'Cartão';
  if (/cheque/.test(s)) return 'Cheque';
  if (/deposito|transfer|ted|doc/.test(s)) return 'Depósito';
  if (/carne|boleto/.test(s)) return 'Carnê';
  if (/otica|loja/.test(s)) return 'Na ótica';
  return 'Outro';
}
function custoDoItem(it, base, override) {
  if (override != null) return { custo: override, fonte: 'digitado' };
  if (it.estoqueId != null) { const p = base.estoque.find((x) => x.id === it.estoqueId); const c = p ? num(p.custo) : null; if (c != null) return { custo: c * (it.qtd || 1), fonte: 'estoque' }; }
  if (it.lente) {
    const l = it.lente, alvo = semAcento(it.descricao);
    const p = (l.precoId != null ? base.precos.find((x) => x.id === l.precoId) : null) || base.precos.find((x) => x.nome && alvo.includes(semAcento(x.nome)) && num(x.custo) != null);
    const c = p ? num(p.custo) : null; if (c != null) return { custo: c * (it.qtd || 1), fonte: 'tabela' };
  }
  return { custo: null, fonte: null };
}

/* ---------- o mês inteiro ---------- */
router.get('/mes', exigirToken, async (req, res) => {
  const mes = MES.test(String(req.query.mes || '')) ? req.query.mes : hojeBR().slice(0, 7);
  const c = req.usuario.clinicaId, ini = mes + '-01', fim = fimDoMes(mes), hoje = hojeBR();
  const base = await oco(c);
  const ov = await pool.query(`SELECT venda_id, item, custo FROM fin_custos WHERE clinica_id=$1`, [c]);
  const custoOv = new Map(ov.rows.map((x) => [x.venda_id + '#' + x.item, Number(x.custo)]));
  const lan = await pool.query(`SELECT id, atend_chave, data, tipo, categoria, descricao, valor, forma FROM fin_lancamentos WHERE clinica_id=$1 AND mes=$2 ORDER BY data, criado_em`, [c, mes]);
  const lancs = lan.rows.map((x) => ({ id: x.id, atend: x.atend_chave || null, data: dia(x.data), tipo: x.tipo, categoria: x.categoria, descricao: x.descricao ? cripto.decifrar(x.descricao) : '', valor: Number(x.valor), forma: x.forma }));

  /* vendas da ótica com preço, custo e pagamento */
  const vendaInfo = (v) => {
    const itens = (v.itens || []).map((it, i) => { const k = custoDoItem(it, base, custoOv.has(v.id + '#' + i) ? custoOv.get(v.id + '#' + i) : null); return { i, descricao: it.descricao, qtd: it.qtd || 1, preco: r2((it.valor || 0) * (it.qtd || 1)), custo: k.custo == null ? null : r2(k.custo), custo_fonte: k.fonte }; });
    const contas = base.contas.filter((x) => x.vendaId === v.id);
    const recebido = r2(contas.reduce((s, x) => s + (x.pagamentos && x.pagamentos.length ? x.pagamentos.reduce((a, p) => a + (Number(p.valor) || 0), 0) : (x.status === 'pago' ? Number(x.valor) || 0 : 0)), 0));
    const aberto = r2(contas.filter((x) => x.status === 'pendente').reduce((s, x) => s + (Number(x.valor) || 0), 0));
    return { venda_id: v.id, data: dia(v.data), total: r2(v.total), forma: formaNormal(v.formaPagamento), forma_texto: v.formaPagamento || '', parcelas: v.parcelas || 1, itens, recebido, a_receber: aberto, custo: r2(itens.reduce((s, x) => s + (x.custo || 0), 0)), sem_custo: itens.filter((x) => x.custo == null).length };
  };

  /* atendimentos: cada dia de exame numa cidade (com agenda aberta ou com paciente marcado nesse dia) */
  const ag = await pool.query(
    `SELECT a.data, a.unidade_id, ${cidade('u')} AS cidade FROM agendas a JOIN unidades u ON u.id=a.unidade_id
      WHERE a.clinica_id=$1 AND a.data BETWEEN $2 AND $3`, [c, ini, fim]);
  const pac = await pool.query(
    `SELECT g.id, g.unidade_id, g.data_hora::date AS dia, g.status, g.venda_resultado, p.nome_completo, p.cpf, p.telefone, ${cidade('u')} AS cidade
       FROM agendamentos g JOIN pacientes p ON p.id=g.paciente_id LEFT JOIN unidades u ON u.id=g.unidade_id
      WHERE g.clinica_id=$1 AND g.data_hora::date BETWEEN $2 AND $3 AND g.status<>'cancelado' ORDER BY g.data_hora`, [c, ini, fim]);
  const porCpf = new Map(), porTel = new Map(), porNome = new Map(), vendasPor = new Map();
  for (const cl of base.clientes) {
    const cpf = so(cl.cpf), tel = so(cl.telefone).slice(-8), nome = semAcento(cl.nome);
    if (cpf.length === 11) porCpf.set(cpf, cl.id);
    if (tel.length === 8) (porTel.get(tel) || porTel.set(tel, []).get(tel)).push(cl);
    if (nome) (porNome.get(nome) || porNome.set(nome, []).get(nome)).push(cl.id);
  }
  for (const v of base.vendas) (vendasPor.get(v.clienteId) || vendasPor.set(v.clienteId, []).get(v.clienteId)).push(v);
  const usadas = new Set();
  const chave = (d, u) => dia(d) + '|' + (u || '');
  const porAgenda = new Map();
  for (const a of ag.rows) { const k = chave(a.data, a.unidade_id); if (!porAgenda.has(k)) porAgenda.set(k, { chave: k, data: dia(a.data), cidade: a.cidade, pacientes: [] }); }
  for (const p of pac.rows) { const k = chave(p.dia, p.unidade_id); if (!porAgenda.has(k)) porAgenda.set(k, { chave: k, data: dia(p.dia), cidade: p.cidade || 'Sem cidade', pacientes: [] }); }
  const atend = [...porAgenda.values()].sort((x, y) => x.data.localeCompare(y.data) || String(x.cidade).localeCompare(String(y.cidade)));
  for (const p of pac.rows) {
    const A = porAgenda.get(chave(p.dia, p.unidade_id)); if (!A) continue;
    let cpf = ''; try { cpf = so(cripto.decifrar(p.cpf)); } catch (e) { cpf = so(p.cpf); }
    const tel = so(p.telefone).slice(-8), nome = semAcento(p.nome_completo), primeiro = nome.split(' ')[0];
    let id = cpf.length === 11 ? porCpf.get(cpf) : undefined;
    if (id === undefined && tel.length === 8) { const l = (porTel.get(tel) || []).filter((x) => semAcento(x.nome).split(' ')[0] === primeiro); if (l.length === 1) id = l[0].id; }
    if (id === undefined) { const l = porNome.get(nome) || []; if (l.length === 1) id = l[0]; }
    const d0 = dia(p.dia), d1 = somaDias(d0, JANELA);
    const vs = id === undefined ? [] : (vendasPor.get(id) || []).filter((v) => !usadas.has(v.id) && dia(v.data) >= d0 && dia(v.data) <= d1).sort((x, y) => dia(x.data).localeCompare(dia(y.data)));
    const v = vs[0]; if (v) usadas.add(v.id);
    A.pacientes.push({ nome: p.nome_completo, status: p.status, marcado: p.venda_resultado || null, venda: v ? vendaInfo(v) : null });
  }
  /* vendas do mês que não vieram de um dia de exame */
  const loja = base.vendas.filter((v) => !usadas.has(v.id) && dia(v.data) >= ini && dia(v.data) <= fim).sort((x, y) => dia(x.data).localeCompare(dia(y.data)))
    .map((v) => { const cl = base.clientes.find((x) => x.id === v.clienteId); return { cliente: cl ? cl.nome : 'Cliente', ...vendaInfo(v) }; });

  /* totais de cada atendimento */
  for (const A of atend) {
    const vend = A.pacientes.filter((p) => p.venda), meus = lancs.filter((l) => l.atend === A.chave);
    A.atendidos = A.pacientes.filter((p) => p.status === 'realizado' || p.marcado).length;
    A.compraram = vend.length;
    A.vendido = r2(vend.reduce((s, p) => s + p.venda.total, 0));
    A.custo_produtos = r2(vend.reduce((s, p) => s + (p.venda.custo || 0), 0));
    A.sem_custo = vend.reduce((s, p) => s + p.venda.sem_custo, 0);
    A.gastos = r2(meus.filter((l) => l.tipo === 'gasto').reduce((s, l) => s + l.valor, 0));
    A.doacoes = r2(meus.filter((l) => l.tipo === 'doacao').reduce((s, l) => s + l.valor, 0));
    A.recebido_extra = r2(meus.filter((l) => l.tipo === 'recebimento').reduce((s, l) => s + l.valor, 0));
    A.recebido = r2(vend.reduce((s, p) => s + p.venda.recebido, 0) + A.recebido_extra);
    A.a_receber = r2(vend.reduce((s, p) => s + p.venda.a_receber, 0));
    A.lucro = r2(A.vendido + A.recebido_extra - A.custo_produtos - A.gastos - A.doacoes);
    A.lancamentos = meus;
  }

  /* recebido no mês, por forma (o dinheiro que entrou de verdade) */
  const formas = Object.fromEntries(FORMAS.map((f) => [f, 0]));
  for (const x of base.contas) {
    const v = base.vendas.find((y) => y.id === x.vendaId);
    if (x.pagamentos && x.pagamentos.length) { for (const p of x.pagamentos) if (dia(p.data) >= ini && dia(p.data) <= fim) formas[formaNormal(p.forma)] += Number(p.valor) || 0; }
    else if (x.status === 'pago' && dia(x.dataPagamento) >= ini && dia(x.dataPagamento) <= fim) formas[formaNormal(x.formaRecebimento || (v && v.formaPagamento))] += Number(x.valor) || 0;
  }
  lancs.filter((l) => l.tipo === 'recebimento').forEach((l) => { formas[FORMAS.includes(l.forma) ? l.forma : 'Outro'] += l.valor; });
  Object.keys(formas).forEach((k) => { formas[k] = r2(formas[k]); });
  const recebidoMes = r2(Object.values(formas).reduce((s, v) => s + v, 0));

  /* a receber */
  const pend = base.contas.filter((x) => x.status === 'pendente');
  const aReceber = {
    vence_no_mes: r2(pend.filter((x) => dia(x.vencimento) >= ini && dia(x.vencimento) <= fim).reduce((s, x) => s + (Number(x.valor) || 0), 0)),
    atrasado: r2(pend.filter((x) => dia(x.vencimento) < hoje).reduce((s, x) => s + (Number(x.valor) || 0), 0)),
    total: r2(pend.reduce((s, x) => s + (Number(x.valor) || 0), 0)),
    proximos: [0, 1, 2].map((k) => { const d = new Date(Date.UTC(+mes.slice(0, 4), +mes.slice(5, 7) - 1 + k, 1)); const m = d.toISOString().slice(0, 7); return { mes: m, valor: r2(pend.filter((x) => dia(x.vencimento).slice(0, 7) === m).reduce((s, x) => s + (Number(x.valor) || 0), 0)) }; }),
  };

  /* gastos do mês por categoria (de todos os atendimentos e os gerais) */
  const porCat = {}; lancs.filter((l) => l.tipo === 'gasto').forEach((l) => { porCat[l.categoria || 'Outros'] = r2((porCat[l.categoria || 'Outros'] || 0) + l.valor); });
  const vendasMes = [...atend.flatMap((A) => A.pacientes.filter((p) => p.venda && p.venda.data >= ini && p.venda.data <= fim).map((p) => p.venda)), ...loja];
  const vendido = r2(vendasMes.reduce((s, v) => s + v.total, 0));
  const custo = r2(vendasMes.reduce((s, v) => s + (v.custo || 0), 0));
  const gastos = r2(Object.values(porCat).reduce((s, v) => s + v, 0));
  const doacoes = r2(lancs.filter((l) => l.tipo === 'doacao').reduce((s, l) => s + l.valor, 0));
  const extra = r2(lancs.filter((l) => l.tipo === 'recebimento').reduce((s, l) => s + l.valor, 0));
  res.setHeader('Cache-Control', 'no-store');
  res.json({
    mes, categorias: CATEGORIAS, formas: FORMAS,
    resumo: {
      vendido, recebido_extra: extra, custo_produtos: custo, gastos, doacoes,
      sem_custo: vendasMes.reduce((s, v) => s + v.sem_custo, 0),
      lucro: r2(vendido + extra - custo - gastos - doacoes),
      recebido: recebidoMes,
      lucro_em_caixa: r2(recebidoMes - custo - gastos - doacoes),
      lucro_possivel: r2(vendido + extra + aReceber.total - custo - gastos - doacoes),
    },
    formas_recebidas: formas, a_receber: aReceber, gastos_por_categoria: porCat,
    atendimentos: atend, vendas_loja: loja,
    gerais: lancs.filter((l) => !l.atend),
  });
});

/* ---------- lançamentos: gastos, doações e recebimentos que não estão na ótica ---------- */
router.post('/lancamentos', exigirToken, async (req, res) => {
  const b = req.body || {};
  const tipo = TIPOS.includes(b.tipo) ? b.tipo : null, valor = num(b.valor), data = DIA.test(String(b.data || '')) ? b.data : null;
  if (!tipo || valor == null || valor <= 0 || valor > 1000000 || !data) return res.status(400).json({ erro: 'Confira o tipo, a data e o valor.' });
  const categoria = tipo === 'gasto' ? (CATEGORIAS.includes(b.categoria) ? b.categoria : 'Outros') : (tipo === 'doacao' ? 'Doação' : null);
  const forma = tipo === 'recebimento' ? (FORMAS.includes(b.forma) ? b.forma : 'Outro') : null;
  const atend = b.atend ? String(b.atend) : null;
  if (atend && !/^\d{4}-\d{2}-\d{2}\|[0-9a-f-]{0,36}$/i.test(atend)) return res.status(400).json({ erro: 'Atendimento inválido.' });
  const desc = String(b.descricao || '').trim().slice(0, 300);
  const r = await pool.query(
    `INSERT INTO fin_lancamentos (clinica_id, mes, atend_chave, data, tipo, categoria, descricao, valor, forma, criado_por) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) RETURNING id`,
    [req.usuario.clinicaId, data.slice(0, 7), atend, data, tipo, categoria, desc ? cripto.cifrar(desc) : null, r2(valor), forma, String(req.usuario.nome || '').slice(0, 150)]);
  res.status(201).json({ id: r.rows[0].id });
});
router.delete('/lancamentos/:id', exigirToken, async (req, res) => {
  if (!UUID.test(req.params.id)) return res.status(400).json({ erro: 'Lançamento inválido.' });
  await pool.query(`DELETE FROM fin_lancamentos WHERE id=$1 AND clinica_id=$2`, [req.params.id, req.usuario.clinicaId]);
  res.json({ ok: true });
});
/* custo de um item vendido que a ótica não tinha cadastrado */
router.put('/custo', exigirToken, async (req, res) => {
  const b = req.body || {}, item = parseInt(b.item, 10), vendaId = String(b.venda_id == null ? '' : b.venda_id).slice(0, 40);
  if (!vendaId || !(item >= 0)) return res.status(400).json({ erro: 'Item inválido.' });
  const custo = b.custo === null || b.custo === '' ? null : num(b.custo);
  if (custo === null) await pool.query(`DELETE FROM fin_custos WHERE clinica_id=$1 AND venda_id=$2 AND item=$3`, [req.usuario.clinicaId, vendaId, item]);
  else {
    if (custo < 0 || custo > 1000000) return res.status(400).json({ erro: 'Custo inválido.' });
    await pool.query(`INSERT INTO fin_custos (clinica_id, venda_id, item, custo) VALUES ($1,$2,$3,$4) ON CONFLICT (clinica_id, venda_id, item) DO UPDATE SET custo=EXCLUDED.custo`, [req.usuario.clinicaId, vendaId, item, r2(custo)]);
  }
  res.json({ ok: true });
});

module.exports = router;
