/* ========================= APARÊNCIA (letra, contraste, tema) ========================= */
function lerAparencia(){ try{ return JSON.parse(localStorage.getItem('agend_ap')||'{}'); }catch(e){ return {}; } }
function aplicarAparencia(){
  const a = lerAparencia(), r = document.documentElement;
  if(a.fonte) r.setAttribute('data-fonte', a.fonte); else r.removeAttribute('data-fonte');
  if(a.contraste) r.setAttribute('data-contraste', a.contraste); else r.removeAttribute('data-contraste');
  let tema = a.tema;
  if(!tema && window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches && a.auto) tema = 'escuro';
  if(tema) r.setAttribute('data-tema', tema); else r.removeAttribute('data-tema');
}
function mudarAparencia(chave, valor){
  const a = lerAparencia(); if(valor) a[chave] = valor; else delete a[chave];
  try{ localStorage.setItem('agend_ap', JSON.stringify(a)); }catch(e){}
  aplicarAparencia();
}
/* botões A− e A+ sempre à mão: 4 tamanhos de letra para o sistema todo */
const NIVEIS_FONTE = ['', 'grande', 'enorme', 'gigante'];
function fonteCtlHtml(){
  const i = NIVEIS_FONTE.indexOf(lerAparencia().fonte||'');
  return `<span class="fonte-ctl" role="group" aria-label="Tamanho da letra"><button type="button" data-fonte-mais="-1" aria-label="Diminuir a letra" ${i<=0?'disabled':''}>A−</button><button type="button" data-fonte-mais="1" aria-label="Aumentar a letra" ${i>=NIVEIS_FONTE.length-1?'disabled':''}>A+</button></span>`;
}
document.addEventListener('click', (e)=>{
  const b = e.target.closest && e.target.closest('button[data-fonte-mais]'); if(!b || b.disabled) return;
  const i = Math.max(0, NIVEIS_FONTE.indexOf(lerAparencia().fonte||'')) + Number(b.dataset.fonteMais);
  const n = Math.min(NIVEIS_FONTE.length-1, Math.max(0, i));
  mudarAparencia('fonte', NIVEIS_FONTE[n]);
  document.querySelectorAll('.fonte-ctl').forEach(c=>{ c.querySelector('[data-fonte-mais="-1"]').disabled = n<=0; c.querySelector('[data-fonte-mais="1"]').disabled = n>=NIVEIS_FONTE.length-1; });
});
function aparenciaHtml(){
  const a = lerAparencia();
  const grupo = (chave, rotulo, ops)=>`<label>${rotulo}</label><div class="ap-linha">${ops.map(([v,t])=>`<button type="button" data-ap="${chave}" data-v="${v}" class="${(a[chave]||'')===v?'on':''}">${t}</button>`).join('')}</div>`;
  return `${grupo('fonte','Tamanho da letra',[['','Normal'],['grande','Grande'],['enorme','Muito grande'],['gigante','Gigante']])}
    ${grupo('contraste','Contraste',[['','Normal'],['alto','Alto']])}
    ${grupo('tema','Tema',[['','Claro'],['escuro','Escuro']])}`;
}
function ligarAparencia(raiz){
  raiz.querySelectorAll('button[data-ap]').forEach(b=> b.onclick = ()=>{
    mudarAparencia(b.dataset.ap, b.dataset.v);
    raiz.querySelectorAll(`button[data-ap="${b.dataset.ap}"]`).forEach(x=> x.classList.toggle('on', x===b));
  });
}
/* Instalar no celular: Android e computador abrem o aviso do próprio navegador; no iPhone o jeito é pelo botão Compartilhar */
let eventoInstalar = null;
const jaInstalado = ()=> (window.matchMedia && matchMedia('(display-mode: standalone)').matches) || window.navigator.standalone === true;
const ehIphone = ()=> /iphone|ipad|ipod/i.test(navigator.userAgent) || (navigator.platform==='MacIntel' && navigator.maxTouchPoints>1);
function atualizarBotoesInstalar(){
  const mostrar = !jaInstalado();
  document.querySelectorAll('.btn-instalar').forEach(b=> b.style.display = mostrar ? '' : 'none');
  const l = document.getElementById('lkInstalar'); if(l) l.style.display = mostrar ? '' : 'none';
}
async function instalarApp(){
  if(eventoInstalar){
    eventoInstalar.prompt();
    try{ await eventoInstalar.userChoice; }catch(e){}
    eventoInstalar = null; atualizarBotoesInstalar(); return;
  }
  const passos = ehIphone()
    ? ['Abra este endereço no Safari.', 'Toque no botão Compartilhar, o quadrado com a seta para cima.', 'Role e toque em Adicionar à Tela de Início.', 'Toque em Adicionar. O ícone aparece na tela do celular.']
    : ['Abra este endereço no Chrome.', 'Toque nos três pontinhos no canto de cima.', 'Toque em Instalar app ou Adicionar à tela inicial.', 'Confirme. O ícone aparece na tela do celular.'];
  openModal(`<h2>Instalar o app</h2><ol style="padding-left:20px;line-height:1.55;">${passos.map(p=>`<li style="margin:6px 0;">${p}</li>`).join('')}</ol><div class="btn-row"><button class="btn btn-primary" onclick="closeModal()">Entendi</button></div>`);
}
window.addEventListener('beforeinstallprompt', (e)=>{ e.preventDefault(); eventoInstalar = e; atualizarBotoesInstalar(); });
window.addEventListener('appinstalled', ()=>{ eventoInstalar = null; atualizarBotoesInstalar(); toast('App instalado.'); });
aplicarAparencia();
(function(){
  const li = document.getElementById('lkInstalar'); if(li){ li.onclick = (e)=>{ e.preventDefault(); instalarApp(); }; }
  setTimeout(atualizarBotoesInstalar, 0);
})();
(function(){
  const f=document.getElementById('lkFonte'), c=document.getElementById('lkContraste'), t=document.getElementById('lkTema');
  if(f) f.onclick = (e)=>{ e.preventDefault(); const a=lerAparencia(); mudarAparencia('fonte', !a.fonte ? 'grande' : a.fonte==='grande' ? 'enorme' : a.fonte==='enorme' ? 'gigante' : ''); };
  if(c) c.onclick = (e)=>{ e.preventDefault(); mudarAparencia('contraste', lerAparencia().contraste ? '' : 'alto'); };
  if(t) t.onclick = (e)=>{ e.preventDefault(); mudarAparencia('tema', lerAparencia().tema ? '' : 'escuro'); };
})();
/* tela de abertura única: fica até o sistema saber se há sessão salva, para não piscar a tela de entrada */
function tirarSplash(){ const s = document.getElementById('splash'); if(!s || s.dataset.saindo) return; s.dataset.saindo = '1'; s.classList.add('some'); setTimeout(()=>s.remove(), 400); }
window.addEventListener('load', ()=>{ setTimeout(tirarSplash, (typeof authToken!=='undefined' && authToken) ? 8000 : 500); });
function atualizarOffline(){ document.body.classList.toggle('offline', !navigator.onLine); }
window.addEventListener('online', atualizarOffline); window.addEventListener('offline', atualizarOffline);
window.addEventListener('load', atualizarOffline);

/* ========================= CONEXÃO COM A API ========================= */
const qs = new URLSearchParams(location.search);
const SERVIDOR_PROPRIO = /^https?:$/.test(location.protocol); // a página veio do próprio servidor (no ar ou em localhost)
let API_BASE = qs.get('api') || (SERVIDOR_PROPRIO ? location.origin : '') || localStorage.getItem('agend_api_base') || '';
let authToken = localStorage.getItem('agend_token') || '';
let usuarioAtual = JSON.parse(localStorage.getItem('agend_usuario') || 'null');

async function api(path, { method = 'GET', body, semAuth = false } = {}) {
  const headers = { 'Content-Type': 'application/json' };
  if (!semAuth && authToken) headers['Authorization'] = 'Bearer ' + authToken;
  if (!semAuth && usuarioAtual?.papel === 'admin') { try{ const ct = localStorage.getItem('agend_cidade_trabalho'); if(ct) headers['X-Cidade-Trabalho'] = ct; }catch(e){} }
  let res;
  try {
    res = await fetch(API_BASE + path, { method, headers, body: body ? JSON.stringify(body) : undefined });
  } catch (e) {
    throw new Error('Não consegui falar com o servidor. Confira o endereço da API e sua internet.');
  }
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.erro || 'Erro na requisição (' + res.status + ').');
  return data;
}

function uid(){ return Date.now().toString(36)+Math.random().toString(36).slice(2,7); }
function minParaHora(min){ const h=Math.floor(min/60)%24, m=min%60; return String(h).padStart(2,'0')+':'+String(m).padStart(2,'0'); }
function horaParaMin(hora){ const [h,m]=hora.split(':').map(Number); return h*60+m; }
function tipoById(id){ return tiposAtendimento.find(t=>t.id===id) || tiposAtendimento[0]; }
function soData(iso){ return iso ? iso.slice(0,10) : ''; }
function soHora(iso){ return iso ? iso.slice(11,16) : ''; }
function fmtData(iso){ if(!iso) return ''; const [y,m,d]=iso.slice(0,10).split('-'); return `${d}/${m}/${y}`; }

function toast(msg){
  const t = document.getElementById('toast');
  t.textContent = msg; t.classList.add('show');
  setTimeout(()=>t.classList.remove('show'), 2600);
}
function erroApi(e){ toast(e.message || 'Algo deu errado.'); console.error(e); }

/* ========================= ESTADO EM MEMÓRIA (carregado da API) ========================= */
let pacientes = [];
/* data de hoje no horário do aparelho (toISOString usa UTC e vira o dia 3 horas antes no Brasil) */
function dataISO(d){ return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`; }
function hojeISO(){ return dataISO(new Date()); }
let agendamentos = [];
let janelaAgDe = '', janelaAgAte = '';
async function carregarJanelaAgendamentos(){
  const hoje = new Date();
  const de = new Date(hoje); de.setDate(de.getDate()-60);
  const ate = new Date(hoje); ate.setDate(ate.getDate()+90);
  janelaAgDe = dataISO(de); janelaAgAte = dataISO(ate);
  agendamentos = await api(`/agendamentos?de=${janelaAgDe}&ate=${janelaAgAte}`);
}
/* ao navegar para um mês fora da janela carregada, busca esse mês */
async function garantirMesCarregado(ano, mes){
  const ini = dataISO(new Date(ano, mes, 1)), fim = dataISO(new Date(ano, mes+1, 0));
  if(janelaAgDe && ini >= janelaAgDe && fim <= janelaAgAte) return;
  try{
    const novos = await api(`/agendamentos?de=${ini}&ate=${fim}`);
    const ids = new Set(novos.map(a=>a.id));
    agendamentos = [...agendamentos.filter(a=>!ids.has(a.id)), ...novos];
  }catch(e){}
}
/* vira o dia sozinho: se o app ficou aberto e passou da meia-noite, o calendário volta para o mês de hoje */
let diaVisto = hojeISO();
/* ícone de calendário do menu: mostra o mês e o dia de hoje, sempre certos */
const MES_CURTO = ['JAN','FEV','MAR','ABR','MAI','JUN','JUL','AGO','SET','OUT','NOV','DEZ'];
function atualizarIconeData(){
  const b = document.getElementById('brandData'); if(!b) return;
  const n = new Date();
  b.querySelector('.bd-mes').textContent = MES_CURTO[n.getMonth()];
  b.querySelector('.bd-dia').textContent = n.getDate();
  b.title = 'Hoje: '+fmtData(hojeISO())+'. Toque para abrir o Calendário';
}
atualizarIconeData(); setInterval(atualizarIconeData, 30000);
document.addEventListener('DOMContentLoaded', atualizarIconeData);
document.getElementById('brandData')?.addEventListener('click', ()=>{ if(authToken){ switchView('calendario'); fecharMenuMobile(); } });
function conferirVirouODia(){
  if(!authToken || hojeISO()===diaVisto) return;
  diaVisto = hojeISO(); calRef = new Date(); calRef.setDate(1);
  carregarJanelaAgendamentos().then(()=>{
    const ativo = [...pillnav.children].find(b=>b.classList.contains('active'));
    const aberto = document.getElementById('modalOverlay')?.classList.contains('show');
    if(ativo && !aberto) renderView(ativo.dataset.view);
  }).catch(()=>{});
}
setInterval(conferirVirouODia, 30000);
document.addEventListener('visibilitychange', ()=>{ if(!document.hidden){ conferirVirouODia(); atualizarIconeData(); } });
let tiposAtendimento = [];
let receitas = [];
let testesVisaoRecentes = [];
let clinicaAtual = null;

let unidades = []; // cidades/eventos: admin vê todas, atendente restrito vê só a própria
let oticas = [];
let convenios = [];
let profissionais = []; // quem tem papel 'profissional', pra escolher na receita quem assina

let feriadosLocais = [];
async function carregarTudo(){
  if(usuarioAtual?.papel === 'gestor'){ // o gestor só abre o pós-exame e o OCO: carrega o mínimo
    const [cli, unid] = await Promise.all([api('/clinica'), api('/unidades')]);
    clinicaAtual = cli; unidades = normUnidades(unid); pacientes = []; agendamentos = []; profissionais = []; testesVisaoRecentes = []; feriadosLocais = []; oticas = []; convenios = [];
    return;
  }
  const [pac, tipos, cli, unid, prof] = await Promise.all([
    api('/pacientes'),
    api('/tipos-atendimento'),
    api('/clinica'),
    api('/unidades'),
    api('/clinica/profissionais'),
  ]);
  pacientes = pac;
  tiposAtendimento = tipos.length ? tipos : tiposAtendimento;
  clinicaAtual = cli;
  unidades = normUnidades(unid);
  profissionais = prof;
  // agendamentos: carrega uma janela de +-60 dias a partir de hoje, suficiente pro calendário
  await carregarJanelaAgendamentos();
  testesVisaoRecentes = [];
  if(usuarioAtual?.papel !== 'atendente' || (usuarioAtual.permissoes||[]).includes('assistente')){
    try{ testesVisaoRecentes = await api('/testes-visao'); }catch(e){ testesVisaoRecentes = []; }
  }
  try{ feriadosLocais = await api('/feriados-locais'); }catch(e){ feriadosLocais = []; }
  try{ oticas = await api('/cadastros/oticas'); }catch(e){ oticas = []; }
  try{ convenios = await api('/cadastros/convenios'); }catch(e){ convenios = []; }
}
/* O agendador vê a cidade do exame: "Santa Cruz · Exame de vista". Sem cidade preenchida, vale o nome. */
function rotuloUnidade(u){ const c=(u.cidade||'').trim(), n=(u.nomeBruto||u.nome||'').trim(); if(!c) return n; return n.toLowerCase().includes(c.toLowerCase()) ? n : c+' · '+n; }
function normUnidades(l){ return (l||[]).map(u=>({ ...u, nomeBruto: u.nomeBruto||u.nome, nome: rotuloUnidade(u) })); }
function minhaUnidade(){ return usuarioAtual?.unidadeId ? unidades.find(u=>u.id===usuarioAtual.unidadeId) : null; }
function cidadeTrabalho(){
  if(usuarioAtual?.papel !== 'admin') return '';
  try{ const c = localStorage.getItem('agend_cidade_trabalho') || ''; return unidades.some(u=>u.id===c) ? c : ''; }catch(e){ return ''; }
}
function cidadesVisiveis(){ const ids = minhasCidadesIds(); return ids.length ? unidades.filter(u=>ids.includes(u.id)) : unidades; }
function textoLocalTopo(){
  const ct = cidadeTrabalho(); const nome = ct ? (unidades.find(u=>u.id===ct)||{}).nome : '';
  return (clinicaAtual?.local_exame_padrao || 'Agendando exame de vista') + (nome ? ' · Cidade: ' + nome : '');
}
function minhasCidadesIds(){ const ct = cidadeTrabalho(); if(ct) return [ct]; return usuarioAtual?.unidadeIds?.length ? usuarioAtual.unidadeIds : (usuarioAtual?.unidadeId ? [usuarioAtual.unidadeId] : []); }
function minhasCidadesTexto(){ const n = minhasCidadesIds().map(id=>unidades.find(u=>u.id===id)?.nome).filter(Boolean); return n.length ? n.join(', ') : ''; }
function cidadesCheckboxes(selecionadas, nameAttr){
  return unidades.map(u=>`<label style="display:flex;gap:10px;align-items:center;margin:8px 0;font-weight:500;"><input type="checkbox" style="width:auto;" ${nameAttr}="${u.id}" ${selecionadas.includes(u.id)?'checked':''}> ${esc(u.nome)}</label>`).join('');
}

/* ========================= LOGIN / CRIAÇÃO DE CONTA ========================= */
const lockScreen = document.getElementById('lockScreen');
const mainApp = document.getElementById('mainApp');
const lockMsg = document.getElementById('lockMsg');
const lockBtn = document.getElementById('lockBtn');
const lockApi = document.getElementById('lockApi');
const lockEmail = document.getElementById('lockEmail');
const lockPass = document.getElementById('lockPass');
const lockToggle = document.getElementById('lockToggle');
const lockTitulo = document.getElementById('lockTitulo');
const lockSub = document.getElementById('lockSub');

lockApi.value = API_BASE;
if(SERVIDOR_PROPRIO && !qs.get('api')) document.getElementById('lockApiBox').style.display = 'none';

let modoCriarConta = false;

const ENTRADAS = {
  atendente:{ titulo:'Entrada do agendador', sub:'Para quem marca os horários dos pacientes.' },
  profissional:{ titulo:'Entrada do profissional', sub:'Para quem faz o exame de vista.' },
  gestor:{ titulo:'Entrada do OCO', sub:'Para quem cuida das vendas, das ordens de serviço, do estoque e do caixa da ótica.' },
  admin:{ titulo:'Entrada do administrador', sub:'Acesso a todas as partes do sistema.' },
};
let entradaEscolhida = 'atendente';
try{ const q = qs.get('entrada'); entradaEscolhida = ENTRADAS[q] ? q : (ENTRADAS[localStorage.getItem('agend_entrada')] ? localStorage.getItem('agend_entrada') : 'atendente'); }catch(e){}
function aplicarEntrada(){
  const l = document.getElementById('lockScreen');
  l.classList.remove('entrada-atendente','entrada-profissional','entrada-admin','entrada-gestor'); l.classList.add('entrada-'+entradaEscolhida);
  document.querySelectorAll('#lockEntradas button').forEach(b=> b.classList.toggle('ativa', b.dataset.e===entradaEscolhida));
  const nomeMarca = document.getElementById('lockMarcaNome'); if(nomeMarca) nomeMarca.textContent = entradaEscolhida==='gestor' ? 'OCO' : 'Clínica de Visão';
  const rod = document.querySelector('.lock-rodape'); if(rod) rod.textContent = entradaEscolhida==='gestor' ? '© 2026 OCO · Todos os direitos reservados' : '© 2026 Clínica de Visão · Todos os direitos reservados';
  if(!modoCriarConta){ lockTitulo.textContent = ENTRADAS[entradaEscolhida].titulo; lockSub.textContent = ENTRADAS[entradaEscolhida].sub+' Entre com o e-mail e a senha.'; }
}
document.getElementById('lockEntradas').addEventListener('click', e=>{
  const b = e.target.closest('button[data-e]'); if(!b) return;
  entradaEscolhida = b.dataset.e; try{ localStorage.setItem('agend_entrada', entradaEscolhida); }catch(err){}
  aplicarEntrada();
});

function renderLockExtra(){
  document.getElementById('lockEntradas').style.display = modoCriarConta ? 'none' : 'flex';
  if(modoCriarConta){
    lockTitulo.textContent = 'Criar minha clínica';
    lockSub.textContent = 'Isso cria a conta da sua clínica e o primeiro usuário administrador.';
    lockBtn.textContent = 'Criar conta';
    lockToggle.textContent = 'Já tenho conta, quero entrar';
    document.getElementById('lockSetupExtra').innerHTML = `
      <label class="req">Nome da clínica</label>
      <input type="text" id="lockNomeClinica" placeholder="Clínica de Visão">
      <label class="req">Identificador único (sem espaços, usado nos links públicos)</label>
      <input type="text" id="lockSlug" placeholder="clinica-de-visao">
      <label class="req">Seu nome</label>
      <input type="text" id="lockNomeAdmin" placeholder="Seu nome completo">`;
  } else {
    aplicarEntrada();
    lockBtn.textContent = 'Entrar';
    lockToggle.textContent = 'Ainda não tenho uma conta, quero criar minha clínica';
    document.getElementById('lockSetupExtra').innerHTML = '';
  }
}
renderLockExtra();
lockToggle.addEventListener('click', (e)=>{ e.preventDefault(); modoCriarConta=!modoCriarConta; lockMsg.textContent=''; renderLockExtra(); });

lockBtn.addEventListener('click', async ()=>{
  lockMsg.textContent = '';
  API_BASE = lockApi.value.trim().replace(/\/$/,'');
  if(!API_BASE){ lockMsg.textContent = 'Informe o endereço do servidor (API).'; return; }
  localStorage.setItem('agend_api_base', API_BASE);
  const email = lockEmail.value.trim();
  const senha = lockPass.value;
  if(!email || !senha){ lockMsg.textContent = 'Preencha e-mail e senha.'; return; }

  lockBtn.disabled = true; lockBtn.textContent = 'Aguarde...';
  try{
    let resp;
    if(modoCriarConta){
      const nomeClinica = document.getElementById('lockNomeClinica').value.trim();
      const slug = document.getElementById('lockSlug').value.trim().toLowerCase().replace(/[^a-z0-9-]/g,'-');
      const nomeAdmin = document.getElementById('lockNomeAdmin').value.trim();
      if(!nomeClinica || !slug || !nomeAdmin){ lockMsg.textContent = 'Preencha todos os campos.'; lockBtn.disabled=false; renderLockExtra(); return; }
      resp = await api('/auth/setup', { method:'POST', semAuth:true, body:{ slug, nomeClinica, nomeAdmin, email, senha } });
      usuarioAtual = { nome: nomeAdmin, papel:'admin', clinica: nomeClinica, slug };
    } else {
      resp = await api('/auth/login', { method:'POST', semAuth:true, body:{ email, senha } });
      if(resp.etapa === 'totp'){
        lockMsg.textContent = 'Senha certa. Agora digite o código do aplicativo no celular.';
        const cod = await pedirCodigoCelular();
        resp = await api('/auth/totp/entrar', { method:'POST', semAuth:true, body:{ pendente:resp.pendente, codigo:cod } });
      }
      usuarioAtual = resp.usuario;
    }
    authToken = resp.token;
    localStorage.setItem('agend_token', authToken);
    localStorage.setItem('agend_usuario', JSON.stringify(usuarioAtual));
    const escolhida = entradaEscolhida;
    if(ENTRADAS[usuarioAtual.papel]){ entradaEscolhida = usuarioAtual.papel; try{ localStorage.setItem('agend_entrada', entradaEscolhida); }catch(err){} }
    await entrarNoApp();
    // a conta é que decide o acesso, não o botão escolhido na entrada
    if(usuarioAtual.papel==='admin' && escolhida!=='admin') toast('Esta é a conta do administrador, por isso abre o sistema inteiro. Para ver só o agendador, entre com a conta de um agendador.');
  }catch(e){
    lockMsg.textContent = e.message;
  }finally{
    lockBtn.disabled = false; renderLockExtra();
  }
});

/* ---------- código de 6 números do celular e recuperar senha ---------- */
function pedirCodigoCelular(){
  return new Promise((resolve, reject)=>{
    openModal(`<h2>Código do celular</h2><p class="sub">Abra o aplicativo de códigos (Google Authenticator, Microsoft Authenticator ou parecido) e digite os 6 números.</p>
      <input type="text" id="tpCod" inputmode="numeric" maxlength="7" autocomplete="one-time-code" style="font-size:24px;text-align:center;letter-spacing:6px;">
      <div class="btn-row"><button class="btn btn-primary" id="tpOk">Entrar</button><button class="btn btn-outline" id="tpNo">Cancelar</button></div>`);
    const cx = document.getElementById('tpCod'); setTimeout(()=>cx.focus(), 100);
    let feito = false;
    const ok = ()=>{ const v = cx.value.replace(/\D/g,''); if(v.length!==6){ cx.style.borderColor='#C1462F'; return; } feito = true; closeModal(); resolve(v); };
    document.getElementById('tpOk').onclick = ok;
    cx.onkeydown = (e)=>{ if(e.key==='Enter') ok(); };
    document.getElementById('tpNo').onclick = ()=>{ feito = true; closeModal(); reject(new Error('Entrada cancelada.')); };
  });
}
(function(){
  const l = document.getElementById('lockEsqueci'); if(!l) return;
  l.onclick = (e)=>{
    e.preventDefault();
    openModal(`<h2>Esqueci minha senha</h2><p class="sub">Digite o e-mail do seu acesso. Enviamos um link para escolher uma senha nova. O link vale 30 minutos.</p>
      <input type="email" id="esqEmail" value="${esc(document.getElementById('lockEmail')?.value||'')}" placeholder="seu@email.com">
      <p id="esqMsg" class="sub"></p>
      <div class="btn-row"><button class="btn btn-primary" id="esqEnviar">Enviar link</button><button class="btn btn-outline" onclick="closeModal()">Fechar</button></div>`);
    document.getElementById('esqEnviar').onclick = async ()=>{
      const m = document.getElementById('esqMsg');
      try{ const r = await api('/auth/esqueci', { method:'POST', semAuth:true, body:{ email: document.getElementById('esqEmail').value } }); m.style.color=''; m.textContent = r.mensagem; }
      catch(err){ m.style.color='#C1462F'; m.textContent = err.message; }
    };
  };
})();
function abrirRedefinicao(token){
  openModal(`<h2>Senha nova</h2><p class="sub">Escolha uma senha com pelo menos 10 caracteres, com letras e números.</p>
    <label>Senha nova</label><input type="password" id="rdSenha" autocomplete="new-password">
    <label>Repita a senha</label><input type="password" id="rdSenha2" autocomplete="new-password">
    <p id="rdMsg" class="sub"></p>
    <div class="btn-row"><button class="btn btn-primary" id="rdOk">Salvar senha</button></div>`);
  document.getElementById('rdOk').onclick = async ()=>{
    const a = document.getElementById('rdSenha').value, b = document.getElementById('rdSenha2').value, m = document.getElementById('rdMsg');
    if(a!==b){ m.style.color='#C1462F'; m.textContent='As duas senhas não são iguais.'; return; }
    try{ await api('/auth/redefinir', { method:'POST', semAuth:true, body:{ token, senha:a } }); history.replaceState(null,'',location.pathname+location.search); closeModal(); toast('Senha trocada. Agora entre com a senha nova.'); }
    catch(err){ m.style.color='#C1462F'; m.textContent = err.message; }
  };
}
window.addEventListener('load', ()=>{ const m = /#reset=([a-f0-9]{20,})/.exec(location.hash); if(m) setTimeout(()=>abrirRedefinicao(m[1]), 700); });

/* Manda a localização de quem entrou. Só envia se o celular já deixa (ou se a pessoa aceitar o pedido do navegador). Sem permissão, não faz nada. */
async function enviarLocalizacao(){
  try{
    if(!navigator.geolocation || !usuarioAtual || usuarioAtual.papel==='admin') return;
    if(navigator.permissions && navigator.permissions.query){
      const p = await navigator.permissions.query({ name:'geolocation' });
      if(p.state==='denied') return;
    }
    navigator.geolocation.getCurrentPosition(
      pos=>{ api('/auth/localizacao', { method:'POST', body:{ lat:pos.coords.latitude, lng:pos.coords.longitude, precisao:pos.coords.accuracy } }).catch(()=>{}); },
      ()=>{}, { enableHighAccuracy:false, timeout:10000, maximumAge:300000 });
  }catch(e){}
}
function linkMapa(lat, lng){ return lat==null||lng==null ? '' : `https://www.google.com/maps?q=${encodeURIComponent(lat+','+lng)}`; }
async function entrarNoApp(){
  try{
    await carregarTudo();
  }catch(e){
    lockMsg.textContent = e.message;
    return;
  }
  lockScreen.style.display = 'none';
  mainApp.style.display = 'flex';
  enviarLocalizacao();
  if(usuarioAtual?.papel === 'admin'){
    api('/clinica/backup-status').then(st=>{
      if(st.dias===null || st.dias>=7) toast(st.dias===null ? 'Você ainda não fez backup dos dados. Vá em Master e baixe um.' : 'Faz '+st.dias+' dias sem backup. Vá em Master e baixe um novo.');
    }).catch(()=>{});
  }
  document.getElementById('hdrNome').textContent = clinicaAtual?.nome_fantasia || 'Agenda de Exame de Vista';
  document.getElementById('hdrLocal').textContent = textoLocalTopo();
  // Prontuário é clínico: só quem tem papel profissional ou admin vê essa aba.
  // Quem só agenda (atendente) nunca enxerga o botão, nem consegue abrir a tela.
  const podeVerProntuario = usuarioAtual?.papel === 'profissional' || usuarioAtual?.papel === 'admin' || (usuarioAtual?.permissoes||[]).includes('prontuario');
  document.getElementById('navProntuario').style.display = podeVerProntuario ? '' : 'none';
  document.getElementById('navAnamnese').style.display = podeVerProntuario ? '' : 'none';
  // Agendador (atendente) só usa Calendário e Confirmação. O resto fica escondido.
  const agendador = usuarioAtual?.papel === 'atendente';
  document.querySelectorAll('#pillnav button').forEach(b=>{
    if(agendador && !agendadorPodeAbrir(b.dataset.view)) b.style.display = 'none';
  });
  document.getElementById('navFinanceiro').style.display = usuarioAtual?.papel === 'admin' ? '' : 'none';
  { const nc = document.getElementById('navCidades'); if(nc){ nc.style.display = podeCadastrarCidade() ? '' : 'none'; nc.onclick = ()=>{ fecharMenuMobile(); abrirCadastroCidade(document.getElementById('main')); }; } }
  /* cada tipo de usuário tem seu visual e seu menu */
  const papelUI = usuarioAtual?.papel || 'admin';
  document.body.classList.remove('modo-admin','modo-profissional','modo-atendente','modo-gestor'); document.body.classList.add('modo-'+papelUI);
  if(papelUI==='profissional'){
    document.querySelectorAll('#pillnav button').forEach(b=>{ if(!VIEWS_PROFISSIONAL.includes(b.dataset.view)) b.style.display = 'none'; });
  }
  if(papelUI==='gestor'){
    document.querySelectorAll('#pillnav button').forEach(b=>{ if(!VIEWS_GESTOR.includes(b.dataset.view)) b.style.display = 'none'; });
  }
  document.getElementById('navPosexame').style.display = (papelUI==='gestor' || papelUI==='admin') ? '' : 'none';
  document.getElementById('navVendasGestor').style.display = (papelUI==='gestor' || papelUI==='admin') ? '' : 'none';
  montarTopoPrancheta();
  { const ft = document.getElementById('fonteTopo'); if(ft) ft.innerHTML = fonteCtlHtml(); const fb = document.getElementById('bmFonte'); if(fb) fb.innerHTML = fonteCtlHtml(); }
  try{ if(localStorage.getItem('agend_menu')==='fechado') { mainApp.classList.add('colapsado'); document.getElementById('btnMenu').textContent = '›'; } }catch(e){}
  const btnTopo = document.getElementById('btnMasterAccess');
  btnTopo.textContent = usuarioAtual?.papel === 'admin' ? 'Área Master' : 'Sair';
  { const bs = document.getElementById('btnSairTopo'); if(bs){ bs.style.display = usuarioAtual?.papel === 'admin' ? '' : 'none'; bs.onclick = sair; } }
  gdSeloEm = 0; setTimeout(()=>guardiaoSelo(true), 400);
  if(usuarioAtual?.papel !== 'admin') document.querySelector('#pillnav button[data-view=master]').style.display = 'none';
  atualizarSecoesMenu();
  { const bn = document.getElementById('bmNome'); if(bn) bn.textContent = clinicaAtual?.nome_fantasia || 'Clínica de Visão'; }
  let primeira = false;
  try{ const k='agend_bv_'+(usuarioAtual?.email||''); if(!localStorage.getItem(k)){ primeira=true; localStorage.setItem(k,'1'); } }catch(e){}
  switchView(papelUI==='gestor' ? 'servicos' : (primeira ? 'inicio' : (agendador ? 'agenda' : (papelUI==='profissional' ? 'prontuario' : 'painel'))));
  baseLegalPrimeira();
}
/* versão do sistema: aparece no login, no menu, na tela Início e no Master */
let versaoSistema = null;
async function carregarVersao(){
  try{
    const r = await fetch((API_BASE||'')+'/versao', { cache:'no-store' });
    if(!r.ok) return;
    versaoSistema = await r.json();
    if(!versaoCarregada) versaoCarregada = versaoSistema.versao;
    document.querySelectorAll('.verApp').forEach(el=>{ el.textContent = 'Versão '+versaoSistema.versao; });
  }catch(e){}
}
carregarVersao();

/* Aviso de versão nova: quem deixa o app aberto vê um aviso e atualiza com um toque */
let versaoCarregada = null, avisoVersaoAdiadoAte = 0;
async function conferirNovaVersao(){
  if(!versaoCarregada || Date.now() < avisoVersaoAdiadoAte) return;
  try{
    const r = await fetch((API_BASE||'')+'/versao', { cache:'no-store' });
    if(!r.ok) return;
    const v = await r.json();
    if(v.versao && v.versao !== versaoCarregada) mostrarAvisoNovaVersao(v.versao);
  }catch(e){}
}
function mostrarAvisoNovaVersao(nova){
  if(document.getElementById('avisoVersao')) return;
  const d = document.createElement('div'); d.id = 'avisoVersao'; d.setAttribute('role','status');
  d.innerHTML = `<span>Nova versão ${esc(nova)} pronta. Termine o que está fazendo e toque em Atualizar.</span><button type="button" id="avisoVersaoOk">Atualizar</button><button type="button" id="avisoVersaoNao" aria-label="Agora não">×</button>`;
  document.body.appendChild(d);
  document.getElementById('avisoVersaoOk').onclick = async ()=>{ try{ if(window.caches){ const ks = await caches.keys(); await Promise.all(ks.map(k=>caches.delete(k))); } }catch(e){} location.reload(); };
  document.getElementById('avisoVersaoNao').onclick = ()=>{ d.remove(); avisoVersaoAdiadoAte = Date.now() + 30*60*1000; };
}
setInterval(conferirNovaVersao, 5*60*1000);
document.addEventListener('visibilitychange', ()=>{ if(!document.hidden) conferirNovaVersao(); });
window.addEventListener('online', conferirNovaVersao);

/* tenta entrar sozinho se já tiver token salvo */
(async function tentarAutoLogin(){
  if(authToken && API_BASE){
    try{ await entrarNoApp(); }
    catch(e){ /* token inválido/expirado: fica na tela de login */ }
    setTimeout(tirarSplash, 150);
  } else setTimeout(tirarSplash, 500);
})();

document.getElementById('btnMenu').addEventListener('click', ()=>{
  const fechado = mainApp.classList.toggle('colapsado');
  document.getElementById('btnMenu').textContent = fechado ? '›' : '‹';
  try{ localStorage.setItem('agend_menu', fechado ? 'fechado' : 'aberto'); }catch(e){}
});
const VIEWS_AGENDADOR = ['inicio','servicos','agenda','fila','espera','confirmacao','envios','relatorio','perfil'];
const VIEWS_GESTOR = ['servicos','posexame','vendasgestor','perfil'];
const VIEWS_PROFISSIONAL = ['inicio','servicos','anamnese','agenda','fila','espera','prontuario','receita','retornos','teste','pacientes','perfil'];
/* barra de cima do modo prancheta (só do agendador) */
function montarTopoPrancheta(){
  const el = document.getElementById('topoPrancheta'); if(!el) return;
  if(usuarioAtual?.papel!=='atendente'){ el.style.display='none'; el.innerHTML=''; return; }
  const un = minhaUnidade();
  el.style.display = 'flex';
  el.innerHTML = `<div class="tp-nome"><b>${esc(clinicaAtual?.nome_fantasia||'Agenda')}</b><small>${esc(usuarioAtual.nome||'')}${un?' · '+esc(un.nome):''}</small></div>
    <button type="button" data-view="inicio">Guia</button><button type="button" data-view="perfil">Perfil</button><button type="button" id="tpSair">Sair</button>${fonteCtlHtml()}`;
  el.querySelectorAll('button[data-view]').forEach(b=> b.onclick = ()=> switchView(b.dataset.view));
  document.getElementById('tpSair').onclick = sair;
}
/* telas extras que o administrador libera para cada agendador (tela de Acessos no Master) */
const ACESSOS_EXTRAS = [
  { chave:'calendario', nome:'Calendário', views:['calendario'] },
  { chave:'pacientes', nome:'Pacientes (ficha completa)', views:['pacientes'] },
  { chave:'assistente', nome:'Assistente e Teste na tela', views:['assistente','teste'] },
  { chave:'receita', nome:'Receita, atestado e declaração', views:['receita'] },
  { chave:'prontuario', nome:'Prontuário', views:['prontuario','anamnese'] },
  { chave:'retornos', nome:'Retornos e aniversariantes', views:['retornos'] },
];
function agendadorPodeAbrir(view){
  if(VIEWS_AGENDADOR.includes(view)) return true;
  const perm = usuarioAtual?.permissoes || [];
  return ACESSOS_EXTRAS.some(a=> perm.includes(a.chave) && a.views.includes(view));
}
document.getElementById('btnMasterAccess').addEventListener('click', ()=>{
  if(usuarioAtual?.papel !== 'admin'){ sair(); return; }
  switchView('master');
});

function sair(){
  authToken=''; usuarioAtual=null;
  localStorage.removeItem('agend_token'); localStorage.removeItem('agend_usuario');
  location.reload();
}

/* ========================= NAVEGAÇÃO ========================= */
const pillnav = document.getElementById('pillnav');
pillnav.addEventListener('click', (e)=>{
  const btn = e.target.closest('button[data-view]');
  if(!btn) return;
  switchView(btn.dataset.view);
});

/* ========================= v4.7: menu em grupos, Serviços, Anamnese ========================= */
function atualizarSecoesMenu(){
  const secs = [...document.querySelectorAll('#pillnav .nav-sec')];
  secs.forEach(sec=>{
    let el = sec.nextElementSibling, algum = false;
    while(el && !el.classList.contains('nav-sec')){ if(el.tagName==='BUTTON' && el.style.display!=='none') algum = true; el = el.nextElementSibling; }
    sec.style.display = algum ? '' : 'none';
  });
}
function fecharMenuMobile(){ document.getElementById('mainApp').classList.remove('menu-aberto'); }
document.getElementById('btnHamb').addEventListener('click', ()=> document.getElementById('mainApp').classList.toggle('menu-aberto'));
document.getElementById('menuVeu').addEventListener('click', fecharMenuMobile);
document.getElementById('pillnav').addEventListener('click', e=>{ if(e.target.closest('button[data-view]')) fecharMenuMobile(); });
const SERVICOS_TEXTO = {
  agenda:'Marcar paciente em um horário livre', calendario:'Ver o mês inteiro', fila:'Quem chegou e quem espera', espera:'Pacientes que querem vaga',
  confirmacao:'Confirmar o comparecimento', envios:'Mensagem pelo WhatsApp', relatorio:'Números do dia',
  pacientes:'Ficha completa do paciente', prontuario:'Fazer o exame de vista', anamnese:'Perguntas antes do exame', receita:'Receita, atestado e declaração',
  retornos:'Quem precisa voltar', teste:'Testes de visão na tela', assistente:'Ajuda com perguntas do sistema', painel:'Números e gráfico',
  financeiro:'Recebimentos e nota simulada', posexame:'O paciente ficou satisfeito com o exame?', vendasgestor:'Vendas, ordens de serviço, caixa e estoque do OCO', master:'Cidades, equipe e segurança', perfil:'Seus dados e senha'
};
function saudacao(){ const h = new Date().getHours(); return h<12 ? 'Bom dia' : (h<18 ? 'Boa tarde' : 'Boa noite'); }
function renderServicos(main){
  const botoes = [...document.querySelectorAll('#pillnav button[data-view]')].filter(b=> b.style.display!=='none' && !['inicio','servicos'].includes(b.dataset.view));
  const nome = (usuarioAtual?.nome||'').split(' ')[0];
  main.innerHTML = `<div class="card"><h2>${saudacao()}${nome?', '+esc(nome):''}!</h2><p class="sub">O que você quer fazer agora? Toque no serviço para abrir.</p>
    <div class="svc-grid">${botoes.map(b=>`<button type="button" class="svc-tile" data-v="${b.dataset.view}"><span class="ico">${b.querySelector('svg')?.outerHTML||''}</span>${esc(b.querySelector('.tx').textContent)}<small>${esc(SERVICOS_TEXTO[b.dataset.view]||'')}</small></button>`).join('')}</div></div>`;
  main.querySelectorAll('.svc-tile').forEach(t=> t.onclick = ()=> switchView(t.dataset.v));
}
function renderAnamnese(main){
  const lista = [...pacientes].sort((x,y)=> (x.nome_completo||'').localeCompare(y.nome_completo||''));
  const SIM = ['Diabetes','Pressão alta','Colesterol alto','Glaucoma na família','Catarata na família','Doença da tireoide','Gravidez ou amamentação'];
  const SINT = ['Visão embaçada de longe','Visão embaçada de perto','Dor de cabeça','Olho vermelho','Olho seco ou coceira','Luz incomoda','Vê pontos ou moscas','Visão dupla'];
  const chk = (nm,l)=>l.map((t,i)=>`<label style="display:flex;gap:8px;align-items:center;font-weight:400;margin:6px 0;"><input type="checkbox" class="${nm}" value="${esc(t)}" style="width:auto;"> ${esc(t)}</label>`).join('');
  main.innerHTML = `<div class="card"><h2>Anamnese</h2><p class="sub">Perguntas antes do exame de vista. Preencha e imprima ou salve em PDF. Esta tela não grava; o que importa vai para o prontuário.</p>
    <label>Paciente</label><select id="anPac"><option value="">Escolha o paciente</option>${lista.map(p=>`<option value="${p.id}">${esc(p.nome_completo)}</option>`).join('')}</select>
    <label>Motivo da consulta</label><textarea id="anQueixa" rows="2"></textarea>
    <div class="row2"><div><label>Usa óculos ou lentes</label><select id="anOculos"><option>Não</option><option>Óculos</option><option>Lentes de contato</option><option>Os dois</option></select></div>
    <div><label>Último exame de vista</label><input type="text" id="anUlt" placeholder="Ex.: há 2 anos"></div></div>
    <label>Horas por dia em telas</label><input type="text" id="anTelas" placeholder="Ex.: 8 horas">
    <h3 style="margin:14px 0 2px;font-size:15px;">Sintomas</h3>${chk('anSint',SINT)}
    <h3 style="margin:14px 0 2px;font-size:15px;">Saúde e família</h3>${chk('anSim',SIM)}
    <label>Remédios que usa</label><input type="text" id="anMed"><label>Alergias</label><input type="text" id="anAle"><label>Cirurgia nos olhos</label><input type="text" id="anCir">
    <label>Observações</label><textarea id="anObs" rows="2"></textarea>
    <div class="btn-row"><button class="btn btn-primary" id="anImp">Imprimir ou salvar em PDF</button></div></div>`;
  const pac = document.getElementById('anPac');
  pac.onchange = ()=>{
    const p = pacientes.find(x=>x.id===pac.value); if(!p) return; const ex = p.dados_extras||{};
    const set=(id,v)=>{ if(v!=null && v!=='') document.getElementById(id).value = v; };
    set('anQueixa',ex.queixa); set('anUlt',ex.ultimo_exame); set('anMed',ex.medicamentos); set('anAle',ex.alergias); set('anCir',ex.cirurgia_ocular); set('anObs',ex.observacoes);
    if(ex.usa_oculos){ const o = document.getElementById('anOculos'); [...o.options].forEach(op=>{ if(op.text.toLowerCase()===String(ex.usa_oculos).toLowerCase()) o.value = op.text; }); }
  };
  document.getElementById('anImp').onclick = ()=>{
    const p = pacientes.find(x=>x.id===pac.value);
    if(!p){ toast('Escolha o paciente.'); return; }
    const v = id=>document.getElementById(id).value.trim();
    const marc = c=>[...document.querySelectorAll('.'+c+':checked')].map(x=>x.value);
    const li = (r,t)=> t ? `<tr><th>${esc(r)}</th><td>${esc(t)}</td></tr>` : '';
    const w = window.open('','_blank'); if(!w){ toast('Libere as janelas do navegador para imprimir.'); return; }
    w.document.write(`<html><head><title>Anamnese de ${esc(p.nome_completo)}</title><style>body{font-family:Arial,sans-serif;margin:30px;color:#111}h1{font-size:20px;margin:0}h2{font-size:13px;color:#555;font-weight:400;margin:2px 0 14px}table{width:100%;border-collapse:collapse}th{text-align:left;width:34%;padding:7px;border-bottom:1px solid #ddd;font-size:13px;vertical-align:top}td{padding:7px;border-bottom:1px solid #ddd;font-size:14px}.ass{margin-top:60px;border-top:1px solid #111;width:300px;font-size:12px;padding-top:4px}</style></head><body>
      <h1>${esc(clinicaAtual?.nome_fantasia||'Clínica de Visão')}</h1><h2>Anamnese · ${new Date().toLocaleDateString('pt-BR')}</h2>
      <table>${li('Paciente',p.nome_completo)}${li('Nascimento',p.data_nascimento?new Date(p.data_nascimento+'T12:00:00').toLocaleDateString('pt-BR'):'')}${li('Telefone',p.telefone)}
      ${li('Motivo da consulta',v('anQueixa'))}${li('Usa óculos ou lentes',v('anOculos'))}${li('Último exame',v('anUlt'))}${li('Horas em telas',v('anTelas'))}
      ${li('Sintomas',marc('anSint').join(', '))}${li('Saúde e família',marc('anSim').join(', '))}${li('Remédios',v('anMed'))}${li('Alergias',v('anAle'))}${li('Cirurgia nos olhos',v('anCir'))}${li('Observações',v('anObs'))}</table>
      <div class="ass">Assinatura do paciente</div></body></html>`);
    w.document.close(); w.focus(); setTimeout(()=>w.print(),300);
  };
}

function switchView(view){
  if(usuarioAtual?.papel === 'atendente' && !agendadorPodeAbrir(view)) view = 'agenda';
  if(usuarioAtual?.papel === 'profissional' && !VIEWS_PROFISSIONAL.includes(view)) view = 'prontuario';
  if(usuarioAtual?.papel === 'gestor' && !VIEWS_GESTOR.includes(view)) view = 'posexame';
  if(view === 'posexame' && usuarioAtual?.papel !== 'admin' && usuarioAtual?.papel !== 'gestor') view = 'inicio';
  if(view === 'vendasgestor' && usuarioAtual?.papel !== 'admin' && usuarioAtual?.papel !== 'gestor') view = 'inicio';
  if((view === 'financeiro' || view === 'master') && usuarioAtual?.papel !== 'admin') view = usuarioAtual?.papel === 'atendente' ? 'agenda' : 'painel';
  if(view==='calendario'){ calRef = new Date(); calRef.setDate(1); }
  [...pillnav.children].forEach(b=> b.classList.toggle('active', b.dataset.view===view));
  guardiaoSelo();
  renderView(view);
  if(view==='inicio' || view==='painel') guardiaoAvisoInicio();
}
function renderView(view){
  pararVozExame();
  const main = document.getElementById('main');
  main.innerHTML = '';
  if(view==='inicio') renderInicio(main);
  else if(view==='servicos') renderServicos(main);
  else if(view==='anamnese') renderAnamnese(main);
  else if(view==='agenda') renderAgendaEvento(main);
  else if(view==='calendario') renderCalendario(main);
  else if(view==='pacientes') renderPacientes(main);
  else if(view==='assistente') renderAssistente(main);
  else if(view==='receita') renderReceita(main);
  else if(view==='prontuario') renderProntuario(main);
  else if(view==='fila') renderFila(main);
  else if(view==='espera') renderEspera(main);
  else if(view==='confirmacao') renderConfirmacao(main);
  else if(view==='envios') renderEnvios(main);
  else if(view==='relatorio') renderRelatorioDia(main);
  else if(view==='retornos') renderRetornos(main);
  else if(view==='painel') renderPainel(main);
  else if(view==='financeiro') renderFinanceiro(main);
  else if(view==='teste') renderTesteTela(main);
  else if(view==='perfil') renderPerfil(main);
  else if(view==='posexame') renderPosExame(main);
  else if(view==='vendasgestor') renderVendasGestor(main);
  else if(view==='master') renderMaster(main);
}
function openModal(html){
  document.getElementById('modalBody').innerHTML = html;
  document.getElementById('modalOverlay').classList.add('show');
}
function closeModal(){ document.getElementById('modalOverlay').classList.remove('show'); }
document.getElementById('modalOverlay').addEventListener('click',(e)=>{ if(e.target.id==='modalOverlay') closeModal(); });

function pacienteNome(id){ const p = pacientes.find(p=>p.id===id); return p? p.nome_completo : '(paciente removido)'; }

/* ---- validações compartilhadas: CPF, telefone, CEP ---- */
function cpfValido(cpfRaw){
  const cpf = cpfRaw.replace(/\D/g,'');
  if(cpf.length!==11) return false;
  if(/^(\d)\1{10}$/.test(cpf)) return false;
  let soma=0, resto;
  for(let i=1;i<=9;i++) soma += parseInt(cpf.substring(i-1,i)) * (11-i);
  resto = (soma*10) % 11; if(resto===10||resto===11) resto=0;
  if(resto !== parseInt(cpf.substring(9,10))) return false;
  soma=0;
  for(let i=1;i<=10;i++) soma += parseInt(cpf.substring(i-1,i)) * (12-i);
  resto = (soma*10) % 11; if(resto===10||resto===11) resto=0;
  if(resto !== parseInt(cpf.substring(10,11))) return false;
  return true;
}
function maskCpf(v){ v=v.replace(/\D/g,'').slice(0,11); return v.replace(/(\d{3})(\d)/,'$1.$2').replace(/(\d{3})(\d)/,'$1.$2').replace(/(\d{3})(\d{1,2})$/,'$1-$2'); }
function maskTelefone(v){
  v=v.replace(/\D/g,'').slice(0,11);
  if(v.length>10) v=v.replace(/(\d{2})(\d{5})(\d{0,4})/,'($1) $2-$3');
  else if(v.length>5) v=v.replace(/(\d{2})(\d{4})(\d{0,4})/,'($1) $2-$3');
  else if(v.length>2) v=v.replace(/(\d{2})(\d{0,5})/,'($1) $2');
  else if(v.length>0) v=v.replace(/(\d{0,2})/,'($1');
  return v.trim();
}
function maskCep(v){ v=v.replace(/\D/g,'').slice(0,8); if(v.length>5) v=v.replace(/(\d{5})(\d{0,3})/,'$1-$2'); return v; }

/* ========================= FERIADOS ========================= */
/* Feriados nacionais do ano, mais Carnaval e Corpus Christi (ponto facultativo). Feriado estadual e municipal não entram. */
function feriadosDoAno(ano){
  const f = {};
  const iso = (dt)=> `${dt.getFullYear()}-${String(dt.getMonth()+1).padStart(2,'0')}-${String(dt.getDate()).padStart(2,'0')}`;
  const fixo = (m,d,nome,tipo)=>{ f[`${ano}-${String(m).padStart(2,'0')}-${String(d).padStart(2,'0')}`] = {nome, tipo: tipo||'feriado'}; };
  fixo(1,1,'Confraternização Universal'); fixo(4,21,'Tiradentes'); fixo(5,1,'Dia do Trabalho');
  fixo(9,7,'Independência do Brasil'); fixo(10,12,'Nossa Senhora Aparecida'); fixo(11,2,'Finados');
  fixo(11,15,'Proclamação da República'); fixo(11,20,'Consciência Negra'); fixo(12,25,'Natal');
  // Páscoa (algoritmo de Meeus/Jones/Butcher)
  const a=ano%19, b=Math.floor(ano/100), c=ano%100, d=Math.floor(b/4), e=b%4, g=Math.floor((8*b+13)/25);
  const h=(19*a+b-d-g+15)%30, i=Math.floor(c/4), k=c%4, l=(32+2*e+2*i-h-k)%7, mm=Math.floor((a+11*h+22*l)/451);
  const mes=Math.floor((h+l-7*mm+114)/31), dia=((h+l-7*mm+114)%31)+1;
  const pascoa = new Date(ano, mes-1, dia);
  const somar = (n)=>{ const x = new Date(pascoa); x.setDate(x.getDate()+n); return iso(x); };
  f[somar(-48)] = {nome:'Carnaval (segunda)', tipo:'facultativo'};
  f[somar(-47)] = {nome:'Carnaval (terça)', tipo:'facultativo'};
  f[somar(-2)]  = {nome:'Sexta-feira Santa', tipo:'feriado'};
  f[iso(pascoa)] = {nome:'Páscoa', tipo:'feriado'};
  f[somar(60)]  = {nome:'Corpus Christi', tipo:'facultativo'};
  return f;
}
const _cacheFeriados = {};
function feriadoDe(isoData){
  const ano = parseInt(isoData.slice(0,4),10);
  if(!_cacheFeriados[ano]) _cacheFeriados[ano] = feriadosDoAno(ano);
  const nac = _cacheFeriados[ano][isoData];
  if(nac) return nac;
  const loc = feriadosLocais.filter(f=>f.data===isoData);
  if(loc.length) return { nome: loc.map(f=>f.nome+(f.cidade?' ('+f.cidade+')':'')).join(', '), tipo: 'feriado' };
  return null;
}

/* ========================= CALENDÁRIO ========================= */
let calRef = (()=>{ const d = new Date(); d.setDate(1); return d; })();
const DOW = ['D','S','T','Q','Q','S','S'];
const MESES = ['Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'];

function renderCalendario(main){
  const y = calRef.getFullYear(), m = calRef.getMonth();
  const first = new Date(y,m,1);
  const startDow = first.getDay();
  const daysInMonth = new Date(y,m+1,0).getDate();
  const daysInPrev = new Date(y,m,0).getDate();
  const todayStr = hojeISO();

  let cells = '';
  const listaFer = [];
  for(let i=0;i<startDow;i++){ const d=daysInPrev-startDow+1+i; cells += `<div class="cal-day muted"><span>${d}</span></div>`; }
  for(let d=1; d<=daysInMonth; d++){
    const iso = `${y}-${String(m+1).padStart(2,'0')}-${String(d).padStart(2,'0')}`;
    const dayAg = agendamentos.filter(a=>soData(a.data_hora)===iso);
    const statuses = [...new Set(dayAg.map(a=>a.status))];
    const dots = statuses.map(s=>`<span class="dot dot-${s}"></span>`).join('');
    const qtd = dayAg.filter(a=>a.status!=='cancelado').length;
    const fer = feriadoDe(iso);
    if(fer) listaFer.push(`<div><span class="${fer.tipo==='feriado'?'fer':'fac'}">${d}</span> ${esc(fer.nome)}${fer.tipo==='facultativo'?' (ponto facultativo)':''}</div>`);
    cells += `<div class="cal-day ${iso===todayStr?'today':''} ${fer?fer.tipo:''}" data-date="${iso}" ${fer?`title="${esc(fer.nome)}"`:''}><span>${d}</span><div class="dots">${dots}</div>${qtd?`<b class="qtd" title="${qtd} marcado(s)">${qtd}</b>`:''}</div>`;
  }
  const totalCells = startDow + daysInMonth;
  const trailing = (7 - (totalCells % 7)) % 7;
  for(let d=1; d<=trailing; d++) cells += `<div class="cal-day muted"><span>${d}</span></div>`;

  main.innerHTML = `
    <div class="card">
      <div class="cal-head">
        <div class="cal-nav"><button id="calPrev" aria-label="Mês anterior">‹</button></div>
        <div class="mlabel">${MESES[m]} ${y}</div>
        <div class="cal-nav"><button id="calNext" aria-label="Próximo mês">›</button></div>
      </div>
      <div class="cal-agora"><div class="ca-hora" id="calRelogio"></div><div class="ca-data" id="calDataExtenso"></div>
        <button type="button" class="btn btn-ghost btn-sm" id="calHoje">Ir para hoje</button></div>
      <div class="cal-grid">
        ${DOW.map(d=>`<div class="cal-dow">${d}</div>`).join('')}
        ${cells}
      </div>
      <div class="legend">
        <span><span class="dot dot-agendado"></span> Agendado</span>
        <span><span class="dot dot-confirmado"></span> Confirmado</span>
        <span><span class="dot dot-realizado"></span> Realizado</span>
        <span><span class="dot dot-cancelado"></span> Cancelado</span>
      </div>
      <div class="lista-feriados">${listaFer.length ? '<strong>Feriados do mês</strong>'+listaFer.join('') : '<span class="sub">Sem feriados neste mês.</span>'}<div class="sub" style="margin-top:4px;">Número vermelho: feriado. Número laranja: ponto facultativo. Feriado estadual e municipal não aparecem.</div></div>
    </div>
    <button class="btn btn-primary btn-block" id="btnNovoAg">+ Novo agendamento</button>
  `;
  const irPara = async (ano, mes)=>{ calRef = new Date(ano, mes, 1); await garantirMesCarregado(ano, mes); renderCalendario(main); };
  document.getElementById('calPrev').onclick = ()=> irPara(y, m-1);
  document.getElementById('calNext').onclick = ()=> irPara(y, m+1);
  document.getElementById('calHoje').onclick = ()=>{ const t = new Date(); irPara(t.getFullYear(), t.getMonth()); };
  const SEMANA_EXT = ['domingo','segunda-feira','terça-feira','quarta-feira','quinta-feira','sexta-feira','sábado'];
  const pintarRelogio = ()=>{
    const r = document.getElementById('calRelogio'), e = document.getElementById('calDataExtenso');
    if(!r){ clearInterval(window.__calRel); return; }
    const n = new Date();
    r.textContent = String(n.getHours()).padStart(2,'0')+':'+String(n.getMinutes()).padStart(2,'0');
    e.textContent = `${SEMANA_EXT[n.getDay()]}, ${n.getDate()} de ${MESES[n.getMonth()].toLowerCase()} de ${n.getFullYear()}`;
  };
  pintarRelogio(); clearInterval(window.__calRel); window.__calRel = setInterval(pintarRelogio, 15000);
  document.getElementById('btnNovoAg').onclick = ()=> openAgendamentoForm(todayStr);
  main.querySelectorAll('.cal-day[data-date]').forEach(el=> el.addEventListener('click', ()=> openDiaModal(el.dataset.date)));
}

function openDiaModal(iso){
  const dayAg = agendamentos.filter(a=>soData(a.data_hora)===iso).sort((a,b)=>a.data_hora.localeCompare(b.data_hora));
  const rows = dayAg.length ? dayAg.map(a=>{
    const tipo = tipoById(a.tipo_atendimento_id);
    const hora = soHora(a.data_hora);
    const horaFim = minParaHora(horaParaMin(hora) + (tipo?tipo.duracao_min:0));
    return `
    <div class="list-item">
      <div>
        <div class="name">${hora}–${horaFim} · ${pacienteNome(a.paciente_id)}</div>
        <div class="meta"><span class="pill-tag status-${a.status}">${a.status}</span> ${tipo?tipo.nome:''} · ${a.local||clinicaAtual?.local_exame_padrao||''}</div>
      </div>
      <div style="display:flex;gap:6px;"><button class="btn btn-ghost btn-sm" onclick="editAgendamento('${a.id}')">Editar</button></div>
    </div>`;}).join('') : `<div class="empty"><div class="ic">🗓️</div>Nenhum horário marcado neste dia.</div>`;
  openModal(`
    <h2>${fmtData(iso)}</h2>
    ${(()=>{ const fer = feriadoDe(iso); return fer ? `<p class="sub" style="color:${fer.tipo==='feriado'?'#c0392b':'#b9770e'};font-weight:600;margin:6px 0 0;">${fer.tipo==='feriado'?'Feriado':'Ponto facultativo'}: ${esc(fer.nome)}</p>` : ''; })()}
    <div style="margin:10px 0 16px;">${rows}</div>
    <button class="btn btn-primary btn-block" onclick="closeModal(); openAgendamentoForm('${iso}')">+ Marcar horário neste dia</button>
  `);
}

function openAgendamentoForm(dataIni, editId){
  const editing = editId ? agendamentos.find(a=>a.id===editId) : null;
  const opts = pacientes.map(p=>`<option value="${p.id}" ${editing&&editing.paciente_id===p.id?'selected':''}>${esc(p.nome_completo)}</option>`).join('');
  const tipoAtualId = editing? editing.tipo_atendimento_id : (tiposAtendimento[0] && tiposAtendimento[0].id);
  const tipoOpts = tiposAtendimento.map(t=>`<option value="${t.id}" ${tipoAtualId===t.id?'selected':''}>${esc(t.nome)} · ${t.duracao_min} min</option>`).join('');
  openModal(`
    <h2>${editing?'Editar agendamento':'Novo agendamento'}</h2>
    <label class="req">Paciente</label>
    <select id="fAgPac"><option value="">Selecione...</option>${opts}</select>
    <button type="button" class="link-discreto" id="fAgNovoPacBtn">+ Paciente novo (nome e telefone)</button>
    <div id="fAgNovoPac" style="display:none;margin-top:6px;">
      <label class="req">Nome completo</label>
      <input type="text" id="fAgNovoNome" placeholder="Nome do paciente">
      <label>Telefone (WhatsApp)</label>
      <input type="text" inputmode="tel" id="fAgNovoTel" placeholder="(64) 99999-9999">
    </div>
    <label class="req">Tipo de atendimento</label>
    <select id="fAgTipo">${tipoOpts}</select>
    <div class="row2">
      <div><label class="req">Data</label><input type="date" id="fAgData" value="${editing?soData(editing.data_hora):dataIni}"></div>
      <div><label class="req">Horário</label><input type="time" id="fAgHora" value="${editing?soHora(editing.data_hora):'09:00'}"></div>
    </div>
    <p class="sub" id="fAgPreview" style="margin-top:-6px;"></p>
    <label>Intervalo depois do exame</label>
    <select id="fAgBuf"><option value="">Padrão do tipo</option><option value="0">Sem intervalo</option><option value="5">5 minutos</option><option value="10">10 minutos</option><option value="15">15 minutos</option></select>
    <label>Local do exame</label>
    <input type="text" id="fAgLocal" value="${editing?(editing.local||''):(clinicaAtual?.local_exame_padrao||'')}" placeholder="Endereço / consultório">
    <label class="req">Agendado por</label>
    <input type="text" id="fAgPor" value="${editing?(editing.agendado_por||''):(usuarioAtual?usuarioAtual.nome:'')}" placeholder="Nome de quem marcou">
    <label>Status</label>
    <select id="fAgStatus">
      ${['agendado','confirmado','realizado','cancelado'].map(s=>`<option value="${s}" ${editing&&editing.status===s?'selected':''}>${s}</option>`).join('')}
    </select>
    ${editing?'':oticaSelectHtml('fAgOtica')}
    <label>Observações</label>
    <textarea id="fAgObs">${editing?(editing.observacoes||''):''}</textarea>
    <div class="btn-row">
      <button class="btn btn-primary" id="fAgSalvar">Salvar</button>
      ${editing && usuarioAtual?.papel==='admin' ?'<button class="btn btn-danger" id="fAgExcluir">Excluir</button>':''}
      <button class="btn btn-outline" onclick="closeModal()">Cancelar</button>
    </div>
    <p id="fAgErr" style="color:#C1462F;font-size:12.5px;margin-top:8px;"></p>
  `);

  function atualizarPreview(){
    const tipo = tipoById(document.getElementById('fAgTipo').value);
    const hora = document.getElementById('fAgHora').value;
    if(!hora || !tipo) return;
    const fimMin = horaParaMin(hora) + tipo.duracao_min;
    const bufSel = document.getElementById('fAgBuf').value;
    const buf = bufSel==='' ? tipo.buffer_min : parseInt(bufSel,10);
    document.getElementById('fAgPreview').textContent = buf>0
      ? `${hora} às ${minParaHora(fimMin)} (${tipo.duracao_min} min) · próximo horário liberado às ${minParaHora(fimMin + buf)}, com ${buf} min de intervalo`
      : `${hora} às ${minParaHora(fimMin)} (${tipo.duracao_min} min) · sem intervalo, o próximo horário pode começar às ${minParaHora(fimMin)}`;
  }
  let novoPacAberto = false;
  document.getElementById('fAgNovoPacBtn').onclick = ()=>{
    novoPacAberto = !novoPacAberto;
    document.getElementById('fAgNovoPac').style.display = novoPacAberto ? 'block' : 'none';
    document.getElementById('fAgPac').disabled = novoPacAberto;
    document.getElementById('fAgNovoPacBtn').textContent = novoPacAberto ? 'Escolher paciente já cadastrado' : '+ Paciente novo (nome e telefone)';
  };
  document.getElementById('fAgTipo').addEventListener('change', atualizarPreview);
  document.getElementById('fAgBuf').addEventListener('change', atualizarPreview);
  if(editing && editing.buffer_min!=null && editing.buffer_min!==(tipoById(editing.tipo_atendimento_id)||{}).buffer_min){ document.getElementById('fAgBuf').value = [0,5,10,15].includes(editing.buffer_min) ? String(editing.buffer_min) : ''; }
  document.getElementById('fAgHora').addEventListener('input', atualizarPreview);
  atualizarPreview();

  let pacCriadoAg = null; // evita paciente duplicado quando o salvamento do horário falha e o usuário tenta de novo
  document.getElementById('fAgSalvar').onclick = async (ev)=>{
    const btnSalvar = ev.currentTarget; if(btnSalvar.disabled) return;
    let paciente_id = document.getElementById('fAgPac').value;
    const data = document.getElementById('fAgData').value;
    const hora = document.getElementById('fAgHora').value;
    const tipo_atendimento_id = document.getElementById('fAgTipo').value;
    const status = document.getElementById('fAgStatus').value;
    const errEl = document.getElementById('fAgErr');
    errEl.textContent = '';
    const novoNome = document.getElementById('fAgNovoNome').value.trim();
    if(pacCriadoAg && !paciente_id) paciente_id = pacCriadoAg;
    if(novoPacAberto && novoNome && !pacCriadoAg){
      try{
        const novo = await api('/pacientes', { method:'POST', body:{ nome_completo: novoNome, telefone: document.getElementById('fAgNovoTel').value.trim(), agendado_por: document.getElementById('fAgPor').value } });
        pacientes.push(novo); paciente_id = novo.id; pacCriadoAg = novo.id;
      }catch(e){ errEl.textContent = e.message; return; }
    }
    if(!paciente_id || !data || !hora){ toast('Preencha paciente, data e horário.'); return; }

    const payload = {
      paciente_id, tipo_atendimento_id, data_hora: `${data}T${hora}:00`,
      local: document.getElementById('fAgLocal').value,
      agendado_por: document.getElementById('fAgPor').value,
      status, observacoes: document.getElementById('fAgObs').value,
      otica_parceira_id: (document.getElementById('fAgOtica')||{}).value || null,
      buffer_min: document.getElementById('fAgBuf').value
    };
    btnSalvar.disabled = true;
    try{
      if(editing){ await api(`/agendamentos/${editing.id}`, { method:'PUT', body:payload }); }
      else { await api('/agendamentos', { method:'POST', body:payload }); }
      agendamentos = await api(`/agendamentos?de=${data}&ate=${data}`).then(novos=>{
        // recarrega só o necessário: mantém o resto e substitui o dia alterado
        const outros = agendamentos.filter(a=>soData(a.data_hora)!==data);
        return [...outros, ...novos];
      });
      closeModal(); toast('Agendamento salvo.'); renderView('calendario');
    }catch(e){
      errEl.textContent = e.message; btnSalvar.disabled = false;
    }
  };
  if(editing){
    const bExcA = document.getElementById('fAgExcluir'); if(bExcA) bExcA.onclick = async ()=>{
      if(!confirm('Excluir este agendamento?')) return;
      try{
        await api(`/agendamentos/${editing.id}`, { method:'DELETE' });
        agendamentos = agendamentos.filter(a=>a.id!==editing.id);
        closeModal(); toast('Agendamento excluído.'); renderView('calendario');
      }catch(e){ erroApi(e); }
    };
  }
}
function editAgendamento(id){ closeModal(); openAgendamentoForm(null, id); }

/* ========================= PACIENTES ========================= */
function renderPacientes(main){
  const list = pacientes.length ? pacientes.map(p=>`
    <div class="list-item">
      <div>
        <div class="name">${esc(p.nome_completo)}</div>
        <div class="meta">${esc(p.telefone||'')} ${p.cidade? ' · '+esc(p.cidade) : ''}</div>
      </div>
      <div style="display:flex;gap:6px;"><button class="btn btn-ghost btn-sm" onclick="openPacienteForm('${p.id}')">Editar</button></div>
    </div>`).join('') : `<div class="empty"><div class="ic">👤</div>Nenhum paciente cadastrado ainda.</div>`;

  main.innerHTML = `
    <div class="card">
      <h2>Pacientes</h2>
      <p class="sub">${pacientes.length} cadastrado(s)</p>
      ${list}
    </div>
    <button class="btn btn-primary btn-block" id="btnNovoPac">+ Novo paciente</button>
    <button class="btn btn-outline btn-block" id="btnLinkPublico" style="margin-top:10px;">Copiar link do paciente (teste de visão + cadastro)</button>
    ${renderTestesRecentes()}
  `;
  document.getElementById('btnNovoPac').onclick = ()=> openPacienteForm();
  document.getElementById('btnLinkPublico').onclick = ()=>{
    const minha = minhaUnidade();
    const sufixo = minha ? `&u=${encodeURIComponent(minha.slug)}` : '';
    const url = baseSitePublico() + `cadastro-paciente.html?c=${clinicaAtual.slug}&api=${encodeURIComponent(API_BASE)}${sufixo}`;
    navigator.clipboard && navigator.clipboard.writeText(url).catch(()=>{});
    toast(minha ? `Link copiado (já com a cidade ${minha.cidade||minha.nome}).` : 'Link copiado.');
  };
}
function renderTestesRecentes(){
  if(!testesVisaoRecentes.length) return '';
  const rows = testesVisaoRecentes.slice(0,5).map(t=>`
    <div class="list-item">
      <div>
        <div class="name">${t.nome_informado || 'Teste sem nome'}</div>
        <div class="meta">${t.equivalente_snellen||''} (${t.menor_linha||''}) · ${new Date(t.criado_em).toLocaleDateString('pt-BR')}</div>
      </div>
    </div>`).join('');
  return `<div class="card" style="margin-top:14px;"><h2>Testes de visão recentes</h2><p class="sub">Feitos pelos próprios pacientes antes de agendar</p>${rows}</div>`;
}

/* ficha do paciente: cada campo pode ser oculto, opcional ou obrigatorio (escolha no Master) */
const FICHA_DEF = [
  ['telefone','Telefone / WhatsApp','tel','opcional'],
  ['cpf','CPF','cpf','obrigatorio'],
  ['data_nascimento','Data de nascimento','date','opcional'],
  ['email','E-mail','email','oculto'],
  ['sexo','Sexo','select','oculto',['Feminino','Masculino','Outro','Prefiro não informar']],
  ['profissao','Profissão','text','oculto'],
  ['cep','CEP','cep','obrigatorio'],
  ['endereco','Endereço (rua e número)','text','opcional'],
  ['bairro','Bairro','text','opcional'],
  ['usa_oculos','Já usa óculos ou lentes','select','oculto',['Não','Óculos','Lentes de contato','Óculos e lentes']],
  ['queixa','O que incomoda na visão','textarea','oculto'],
  ['ultimo_exame','Quando fez o último exame de vista','text','oculto'],
  ['doencas','Doenças (diabetes, pressão alta e outras)','text','oculto'],
  ['alergias','Alergias','text','oculto'],
  ['medicamentos','Remédios que usa','text','oculto'],
  ['cirurgia_ocular','Cirurgia nos olhos','text','oculto'],
  ['historico_familiar','Casos na família (glaucoma, catarata)','text','oculto'],
  ['indicacao','Como conheceu a clínica','text','oculto'],
  ['observacoes','Observações','textarea','oculto'],
  ['foto_receita','Foto da última receita','foto','opcional'],
  ['foto_armacao','Foto da armação desejada','foto','opcional'],
];
const FICHA_EXTRAS = ['email','sexo','profissao','usa_oculos','queixa','ultimo_exame','doencas','alergias','medicamentos','cirurgia_ocular','historico_familiar','indicacao','observacoes','receita_status','receita_digitada'];
function fichaEstado(k){
  const d = FICHA_DEF.find(x=>x[0]===k); const v = (clinicaAtual?.campos_obrigatorios||{})[k];
  if(v===true) return 'obrigatorio'; if(v===false) return 'opcional';
  return ['oculto','opcional','obrigatorio'].includes(v) ? v : d[3];
}
function camposObrig(){ const o={}; FICHA_DEF.forEach(d=>{ o[d[0]] = fichaEstado(d[0])==='obrigatorio'; }); return o; }
function campoExtraHtml(k, valor){
  const d = FICHA_DEF.find(x=>x[0]===k); const [,rot,tipo,,ops] = d;
  const id = 'fx_'+k; let inp;
  if(tipo==='select') inp = `<select id="${id}"><option value=""></option>${ops.map(o=>`<option ${o===valor?'selected':''}>${esc(o)}</option>`).join('')}</select>`;
  else if(tipo==='textarea') inp = `<textarea id="${id}" rows="2">${esc(valor||'')}</textarea>`;
  else inp = `<input type="${tipo==='email'?'email':'text'}" id="${id}" value="${esc(valor||'')}">`;
  return `<div data-campo="${k}" style="${fichaEstado(k)==='oculto'?'display:none':''}"><label class="${fichaEstado(k)==='obrigatorio'?'req':''}">${rot}</label>${inp}</div>`;
}
function imprimirFicha(p){
  const ex = p.dados_extras || {};
  const linhas = [['Nome',p.nome_completo],['Telefone',p.telefone],['CPF',p.cpf],['Nascimento',p.data_nascimento?new Date(p.data_nascimento+'T12:00:00').toLocaleDateString('pt-BR'):''],
    ['E-mail',ex.email],['Sexo',ex.sexo],['Profissão',ex.profissao],['CEP',p.cep],['Endereço',[p.endereco,p.bairro,p.cidade].filter(Boolean).join(', ')],
    ['Usa óculos ou lentes',ex.usa_oculos],['O que incomoda',ex.queixa],['Último exame de vista',ex.ultimo_exame],['Cirurgia nos olhos',ex.cirurgia_ocular],['Receita anterior',ex.receita_status==='digitar'?ex.receita_digitada:(ex.receita_status==='nao_tem'?'Não tem ou não lembra':(ex.receita_status==='foto'?'Foto anexada':''))],
    ['Doenças',ex.doencas],['Alergias',ex.alergias],['Remédios',ex.medicamentos],['Casos na família',ex.historico_familiar],['Como conheceu',ex.indicacao],['Observações',ex.observacoes]].filter(l=>l[1]);
  const w = window.open('','_blank'); if(!w){ toast('Libere as janelas do navegador para imprimir.'); return; }
  w.document.write(`<html><head><title>Ficha de ${esc(p.nome_completo)}</title><style>body{font-family:Arial,sans-serif;margin:30px;color:#111}h1{font-size:20px;margin:0 0 4px}h2{font-size:14px;color:#555;font-weight:400;margin:0 0 18px}table{border-collapse:collapse;width:100%}td{border-bottom:1px solid #ddd;padding:8px 6px;font-size:14px;vertical-align:top}td:first-child{width:34%;color:#555}</style></head><body>${clinicaAtual?.logo_url?`<img src="${clinicaAtual.logo_url}" style="max-height:60px;display:block;margin-bottom:8px;">`:''}<h1>Ficha do paciente</h1><h2>${esc(clinicaAtual?.nome_fantasia||'')} · ${new Date().toLocaleDateString('pt-BR')}</h2><table>${linhas.map(l=>`<tr><td>${esc(l[0])}</td><td>${esc(l[1])}</td></tr>`).join('')}</table></body></html>`);
  w.document.close(); w.focus(); setTimeout(()=>w.print(),300);
}

async function lerPorIA(tipo, dataUrl){
  return api('/leitura', { method:'POST', body:{ tipo, imagem:dataUrl } });
}
/* leitura no próprio celular (sem IA), usada quando a leitura por IA não está ligada */
function carregarTesseract(){
  if(window.Tesseract) return Promise.resolve(window.Tesseract);
  return new Promise((ok,err)=>{
    const sc = document.createElement('script'); sc.src = 'https://cdn.jsdelivr.net/npm/tesseract.js@5.1.1/dist/tesseract.min.js';
    sc.onload = ()=> ok(window.Tesseract); sc.onerror = ()=> err(new Error('Sem internet para carregar o leitor.')); document.head.appendChild(sc);
  });
}
async function lerDocumentoLocal(dataUrl){
  const T = await carregarTesseract();
  const r = await T.recognize(dataUrl, 'por');
  const texto = r.data.text || '';
  const achado = { nome_completo:null, cpf:null, data_nascimento:null };
  const cpfs = texto.match(/\d{3}[\.\s]?\d{3}[\.\s]?\d{3}[-\s]?\d{2}/g) || [];
  achado.cpf = cpfs.map(c=>c.replace(/\D/g,'')).find(c=>cpfValido(c)) || null;
  const dt = texto.match(/(\d{2})[\/\.\s-](\d{2})[\/\.\s-](\d{4})/g) || [];
  for(const d of dt){ const [dd,mm,aa] = d.split(/\D+/); if(+aa>1900 && +aa<=new Date().getFullYear() && +mm>=1 && +mm<=12 && +dd>=1 && +dd<=31){ achado.data_nascimento = `${aa}-${mm}-${dd}`; break; } }
  const linhas = texto.split(/\n/).map(l=>l.trim()).filter(Boolean);
  const iNome = linhas.findIndex(l=>/^nome\b/i.test(l));
  if(iNome>=0){ const cand = (linhas[iNome].replace(/^nome[:\s]*/i,'') || linhas[iNome+1] || '').replace(/[^A-Za-zÀ-ÿ\s]/g,'').trim(); if(cand.split(/\s+/).length>=2) achado.nome_completo = cand.toUpperCase(); }
  return achado;
}
const fmtGrau = o=> [o.esf, o.cil, o.eixo?('x'+o.eixo):''].filter(Boolean).join(' ');
function textoReceita(d){
  const partes = [];
  if(fmtGrau(d.od)) partes.push('OD: '+fmtGrau(d.od));
  if(fmtGrau(d.oe)) partes.push('OE: '+fmtGrau(d.oe));
  if(d.adicao) partes.push('Adição '+d.adicao);
  if(d.dp) partes.push('DP '+d.dp);
  return partes.join('  ');
}
async function lerDocumentoPorFoto(url){
  try{ return (await lerPorIA('documento', url)).dados; }
  catch(e){
    if(/não está ligada/i.test(e.message||'')) return lerDocumentoLocal(url);
    throw e;
  }
}

function openPacienteForm(editId){
  const editing = editId ? pacientes.find(p=>p.id===editId) : null;
  const req = camposObrig();
  const ex = (editing && editing.dados_extras) || {};
  const cx = (k, html)=> `<div data-campo="${k}" style="${fichaEstado(k)==='oculto'?'display:none':''}">${html}</div>`;
  openModal(`
    <h2>${editing?'Editar paciente':'Novo paciente'}</h2>
    <div class="foto-atalhos">
      <button type="button" class="btn btn-outline" id="btnFotoDoc">📷 Fotografar documento</button>
      <button type="button" class="btn btn-outline" id="btnFotoRec">📷 Fotografar receita ou óculos</button>
      <input type="file" id="inFotoDoc" accept="image/*" capture="environment" style="display:none">
      <input type="file" id="inFotoRec" accept="image/*" capture="environment" style="display:none">
    </div>
    <p class="sub" id="fotoMsg">Tire a foto do RG, CNH ou CPF e o sistema preenche nome, CPF e nascimento. Confira tudo antes de salvar.</p>
    <label class="req">Nome completo</label>
    <input type="text" id="fPNome" value="${editing?esc(editing.nome_completo):''}">
    ${cx('cpf',`<label class="${req.cpf?'req':''}">CPF</label>
    <input type="text" id="fPCpf" value="${editing?esc(editing.cpf||''):''}" placeholder="000.000.000-00" inputmode="numeric">
    <p class="fieldmsg" id="fPCpfMsg"></p>`)}
    ${cx('data_nascimento',`<label class="${req.data_nascimento?'req':''}">Data de nascimento <span style="font-weight:400;color:var(--ink-soft);">(usada em aniversários e na idade da receita)</span></label>
    <input type="date" id="fPNasc" value="${editing?(editing.data_nascimento||''):''}">`)}
    ${cx('telefone',`<label class="${req.telefone?'req':''}">Telefone / WhatsApp</label>
    <input type="tel" id="fPTel" value="${editing?esc(editing.telefone||''):''}" placeholder="(00) 00000-0000" inputmode="numeric">
    <p class="fieldmsg" id="fPTelMsg"></p>`)}
    ${['email','sexo','profissao'].map(k=>campoExtraHtml(k, ex[k])).join('')}
    ${cx('cep',`<div class="row2">
      <div><label class="${req.cep?'req':''}">CEP</label><input type="text" id="fPCep" value="${editing?(editing.cep||''):''}" placeholder="00000-000" inputmode="numeric"><p class="fieldmsg" id="fPCepMsg"></p></div>
      <div><label>Cidade</label><input type="text" id="fPCidade" value="${editing?esc(editing.cidade||''):''}" readonly></div>
    </div>`)}
    ${cx('endereco',`<label class="${req.endereco?'req':''}">Endereço</label>
    <input type="text" id="fPEndereco" value="${editing?esc(editing.endereco||''):''}">`)}
    ${cx('bairro',`<label class="${req.bairro?'req':''}">Bairro</label>
    <input type="text" id="fPBairro" value="${editing?esc(editing.bairro||''):''}">`)}
    ${['usa_oculos','queixa','ultimo_exame','cirurgia_ocular','doencas','alergias','medicamentos','historico_familiar','indicacao','observacoes'].map(k=>campoExtraHtml(k, ex[k])).join('')}
    <label>Agendado por</label>
    <input type="text" id="fPPor" value="${editing?esc(editing.agendado_por||''):''}">
    ${cx('foto_receita',`<label class="${req.foto_receita?'req':''}">Última receita</label>
    <select id="fx_receita_status"><option value=""></option>${[['foto','Tenho a foto'],['digitar','Vou digitar o grau'],['nao_tem','Não tem ou não lembra']].map(([v,t])=>`<option value="${v}" ${ex.receita_status===v?'selected':''}>${t}</option>`).join('')}</select>
    <div id="blocoReceitaDig" style="display:${ex.receita_status==='digitar'?'block':'none'};"><label>Grau digitado (OD e OE, longe e perto)</label><textarea id="fx_receita_digitada" rows="3" placeholder="OD: -1.00 -0.50 x90  OE: -1.25 -0.25 x80  Adição +1.50">${esc(ex.receita_digitada||'')}</textarea></div>
    <label>Foto da receita (se tiver)</label>
    <input type="file" id="fPFotoReceita" accept="image/*">
    ${editing&&editing.tem_foto_receita?`<p class="sub">Já existe uma foto salva. <a href="#" class="ver-foto" data-q="foto_receita_url">Ver foto</a></p>`:''}`)}
    ${cx('foto_armacao',`<label class="${req.foto_armacao?'req':''}">Foto do modelo de armação</label>
    <input type="file" id="fPFotoArmacao" accept="image/*">
    ${editing&&editing.tem_foto_armacao?`<p class="sub">Já existe uma foto salva. <a href="#" class="ver-foto" data-q="foto_armacao_url">Ver foto</a></p>`:''}`)}
    ${editing?'':`<label style="display:flex;gap:8px;align-items:flex-start;font-weight:400;margin-top:10px;"><input type="checkbox" id="fPLgpd" style="margin-top:4px;"> <span>O paciente leu o aviso de privacidade e concorda com o uso dos dados e com lembretes por WhatsApp.</span></label>`}
    <div class="btn-row">
      <button class="btn btn-primary" id="fPSalvar">Salvar</button>
      ${editing?'<button class="btn btn-outline" id="fPFicha">Imprimir ficha</button>':''}${editing && usuarioAtual?.papel==='admin' ?'<button class="btn btn-danger" id="fPExcluir">Excluir</button>':''}
      <button class="btn btn-outline" onclick="closeModal()">Cancelar</button>
    </div>
    <p id="fPErr" style="color:#C1462F;font-size:12.5px;margin-top:8px;"></p>
  `);

  const stRec = document.getElementById('fx_receita_status'); if(stRec) stRec.onchange = ()=>{ document.getElementById('blocoReceitaDig').style.display = stRec.value==='digitar' ? 'block' : 'none'; };
  const fPCpf = document.getElementById('fPCpf'), fPCpfMsg = document.getElementById('fPCpfMsg');
  fPCpf.addEventListener('input', ()=>{
    fPCpf.value = maskCpf(fPCpf.value);
    const digitos = fPCpf.value.replace(/\D/g,'');
    fPCpf.classList.remove('field-ok','field-bad');
    if(digitos.length < 11){ fPCpfMsg.textContent=''; fPCpfMsg.className='fieldmsg'; return; }
    if(cpfValido(fPCpf.value)){ fPCpfMsg.textContent='CPF válido'; fPCpfMsg.className='fieldmsg ok'; fPCpf.classList.add('field-ok'); }
    else{ fPCpfMsg.textContent='CPF inválido, confira os números'; fPCpfMsg.className='fieldmsg bad'; fPCpf.classList.add('field-bad'); }
  });
  const fPTel = document.getElementById('fPTel'), fPTelMsg = document.getElementById('fPTelMsg');
  fPTel.addEventListener('input', ()=>{
    fPTel.value = maskTelefone(fPTel.value);
    const digitos = fPTel.value.replace(/\D/g,'');
    fPTel.classList.remove('field-ok','field-bad');
    if(digitos.length === 0){ fPTelMsg.textContent=''; fPTelMsg.className='fieldmsg'; return; }
    if(digitos.length===10 || digitos.length===11){ fPTelMsg.textContent='Número válido'; fPTelMsg.className='fieldmsg ok'; fPTel.classList.add('field-ok'); }
    else{ fPTelMsg.textContent='Informe o DDD + número completo'; fPTelMsg.className='fieldmsg bad'; fPTel.classList.add('field-bad'); }
  });
  const fPCep = document.getElementById('fPCep'), fPCepMsg = document.getElementById('fPCepMsg');
  fPCep.addEventListener('input', ()=>{
    fPCep.value = maskCep(fPCep.value);
    fPCep.classList.remove('field-ok','field-bad');
    if(fPCep.value.replace(/\D/g,'').length < 8){ fPCepMsg.textContent=''; fPCepMsg.className='fieldmsg'; }
  });
  fPCep.addEventListener('blur', buscarCep);
  async function buscarCep(){
    const cep = fPCep.value.replace(/\D/g,'');
    if(cep.length!==8){ if(cep.length>0){ fPCepMsg.textContent='CEP incompleto'; fPCepMsg.className='fieldmsg bad'; fPCep.classList.add('field-bad'); } return; }
    fPCepMsg.textContent = 'Buscando endereço...'; fPCepMsg.className='fieldmsg';
    try{
      const r = await fetch(`https://viacep.com.br/ws/${cep}/json/`);
      const d = await r.json();
      if(!d.erro){
        document.getElementById('fPCidade').value = d.localidade + '/' + d.uf;
        document.getElementById('fPBairro').value = d.bairro || '';
        document.getElementById('fPEndereco').value = d.logradouro || document.getElementById('fPEndereco').value;
        fPCepMsg.textContent = 'Endereço encontrado'; fPCepMsg.className='fieldmsg ok'; fPCep.classList.add('field-ok');
      } else { fPCepMsg.textContent = 'CEP não encontrado, confira os números'; fPCepMsg.className='fieldmsg bad'; fPCep.classList.add('field-bad'); }
    }catch(e){ fPCepMsg.textContent = 'Sem internet para buscar o endereço agora.'; fPCepMsg.className='fieldmsg bad'; }
  }

  function readFile(input){
    return new Promise(res=>{
      const f = input.files[0];
      if(!f){ res(null); return; }
      // a foto é reduzida antes de enviar (mais leve para o celular e para o banco)
      reduzirImagem(f, 1280, 0.7).then(res).catch(()=>{ const r = new FileReader(); r.onload = ()=> res(r.result); r.readAsDataURL(f); });
    });
  }

  /* leitura por foto: documento e receita/óculos */
  const fotoMsg = document.getElementById('fotoMsg');
  const marcarLido = el=>{ if(el){ el.classList.add('campo-lido'); el.addEventListener('input', ()=>el.classList.remove('campo-lido'), {once:true}); } };
  function dispararInput(el){ el.dispatchEvent(new Event('input',{bubbles:true})); }
  function preencher(id, valor){
    const el = document.getElementById(id); if(!el || !valor) return false;
    el.value = valor; dispararInput(el); marcarLido(el); return true;
  }
  function ligarBotaoFoto(btnId, inputId, tratar){
    const btn = document.getElementById(btnId), inp = document.getElementById(inputId);
    btn.onclick = ()=> inp.click();
    inp.onchange = async ()=>{
      const f = inp.files[0]; if(!f) return;
      btn.disabled = true; const rot = btn.textContent; btn.textContent = 'Lendo a foto...';
      fotoMsg.textContent = 'Lendo a foto. Aguarde alguns segundos.'; fotoMsg.style.color = '';
      try{ const url = await reduzirImagem(f, 1280, 0.7); await tratar(url, f); }
      catch(e){ fotoMsg.textContent = e.message || 'Não consegui ler a foto.'; fotoMsg.style.color = '#C1462F'; }
      btn.disabled = false; btn.textContent = rot; inp.value = '';
    };
  }
  function aplicarDocumento(d){
    let n = 0;
    if(d.nome_completo && !document.getElementById('fPNome').value.trim() && preencher('fPNome', d.nome_completo)) n++;
    else if(d.nome_completo && document.getElementById('fPNome').value.trim()!==d.nome_completo){ if(confirm('O documento diz: '+d.nome_completo+'\nTrocar o nome que já está escrito?')){ preencher('fPNome', d.nome_completo); n++; } }
    if(d.cpf && preencher('fPCpf', d.cpf)) n++;
    if(d.data_nascimento && preencher('fPNasc', d.data_nascimento)) n++;
    if(d.cpf_ilegivel) { fotoMsg.textContent = 'O CPF da foto saiu com número errado. Tire de novo ou digite.'; fotoMsg.style.color = '#C1462F'; return; }
    fotoMsg.style.color = n ? '#2e9d5b' : '#C1462F';
    fotoMsg.textContent = n ? `Li ${n} campo(s). Eles estão em verde. Confira com o documento antes de salvar.` : 'Não achei dados legíveis. Tire a foto de novo, reta e com boa luz, ou digite.';
  }
  ligarBotaoFoto('btnFotoDoc','inFotoDoc', async (url)=>{ aplicarDocumento(await lerDocumentoPorFoto(url)); });
  ligarBotaoFoto('btnFotoRec','inFotoRec', async (url, arquivo)=>{
    // a foto sempre fica anexada na ficha (campo "Foto da receita")
    const alvo = document.getElementById('fPFotoReceita');
    if(alvo && window.DataTransfer){ try{ const bin = atob(url.split(',')[1]); const bytes = new Uint8Array(bin.length); for(let i=0;i<bin.length;i++) bytes[i]=bin.charCodeAt(i); const blob = new Blob([bytes],{type:'image/jpeg'}); const dt = new DataTransfer(); dt.items.add(new File([blob],'receita.jpg',{type:'image/jpeg'})); alvo.files = dt.files; }catch(e){} }
    let dados = null;
    try{ dados = (await lerPorIA('receita', url)).dados; }
    catch(e){
      if(e.semIA || /não está ligada/i.test(e.message||'')){
        fotoMsg.style.color = '#b26a00';
        fotoMsg.textContent = 'Foto anexada na ficha. A leitura automática do grau precisa da IA ligada. Digite o grau olhando a foto.';
      } else throw e;
    }
    const st = document.getElementById('fx_receita_status');
    if(dados){
      const t = textoReceita(dados);
      if(t && st){
        st.value = 'digitar'; st.dispatchEvent(new Event('change'));
        const cx = document.getElementById('fx_receita_digitada'); if(cx){ cx.value = t; marcarLido(cx); }
        fotoMsg.style.color = '#2e9d5b';
        fotoMsg.textContent = 'Li o grau e anexei a foto. O texto está em verde na parte da receita. Confira com a foto antes de salvar.';
      } else {
        if(st && !st.value){ st.value = 'foto'; st.dispatchEvent(new Event('change')); }
        fotoMsg.style.color = '#b26a00';
        fotoMsg.textContent = 'A foto ficou anexada, mas não consegui ler o grau. Digite olhando a foto ou tire outra, reta e com boa luz.';
      }
    } else if(st && !st.value){ st.value = 'foto'; st.dispatchEvent(new Event('change')); }
  });

  document.querySelectorAll('.ver-foto').forEach(a=> a.onclick = async (ev)=>{
    ev.preventDefault();
    try{
      const f = await api('/pacientes/'+editing.id+'/fotos');
      const src = f[a.dataset.q]; if(!src){ toast('Sem foto.'); return; }
      const ov = document.createElement('div');
      ov.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.85);z-index:200;display:flex;align-items:center;justify-content:center;padding:12px;';
      ov.innerHTML = '<img alt="Foto" style="max-width:100%;max-height:100%;border-radius:8px;">';
      ov.firstChild.src = src; ov.onclick = ()=> ov.remove(); document.body.appendChild(ov);
    }catch(e){ erroApi(e); }
  });
  document.getElementById('fPSalvar').onclick = async ()=>{
    const nome_completo = document.getElementById('fPNome').value.trim();
    const cpf = document.getElementById('fPCpf').value.trim();
    const tel = document.getElementById('fPTel').value.trim();
    const cep = document.getElementById('fPCep').value.trim();
    const errEl = document.getElementById('fPErr');
    if(!nome_completo){ errEl.textContent = 'Informe o nome.'; return; }
    if(cpf && !cpfValido(cpf)){ errEl.textContent = 'O CPF informado não é válido.'; return; }
    if(tel && ![10,11].includes(tel.replace(/\D/g,'').length)){ errEl.textContent = 'Telefone incompleto.'; return; }
    const dadosExtras = {}; FICHA_EXTRAS.forEach(k=>{ const el = document.getElementById('fx_'+k); if(el) dadosExtras[k] = el.value.trim(); });
    const valores = { telefone:tel, cpf, cep, endereco:document.getElementById('fPEndereco').value.trim(), bairro:document.getElementById('fPBairro').value.trim(), data_nascimento:document.getElementById('fPNasc').value,
      foto_receita: (document.getElementById('fPFotoReceita').files[0] || (editing&&editing.tem_foto_receita) || dadosExtras.receita_digitada || dadosExtras.receita_status==='nao_tem') ? 'x' : '',
      foto_armacao: (document.getElementById('fPFotoArmacao').files[0] || (editing&&editing.tem_foto_armacao)) ? 'x' : '', ...dadosExtras };
    for(const d of FICHA_DEF){ if(fichaEstado(d[0])==='obrigatorio' && !valores[d[0]]){ errEl.textContent = d[1]+' é obrigatório.'; return; } }

    const fotoReceita = await readFile(document.getElementById('fPFotoReceita'));
    const fotoArmacao = await readFile(document.getElementById('fPFotoArmacao'));
    const payload = {
      nome_completo, cpf: cpf||null, telefone: tel||null, cep: cep||null,
      cidade: document.getElementById('fPCidade').value,
      bairro: document.getElementById('fPBairro').value,
      endereco: document.getElementById('fPEndereco').value,
      agendado_por: document.getElementById('fPPor').value,
      data_nascimento: document.getElementById('fPNasc').value || null,
      foto_receita_url: fotoReceita, foto_armacao_url: fotoArmacao, dados_extras: dadosExtras,
      aceite_lgpd: !!(document.getElementById('fPLgpd') && document.getElementById('fPLgpd').checked),
    };
    try{
      if(editing){ const r = await api(`/pacientes/${editing.id}`, { method:'PUT', body:payload }); Object.assign(editing, r); }
      else { const r = await api('/pacientes', { method:'POST', body:payload }); pacientes.push(r); }
      closeModal(); toast('Paciente salvo.'); renderView('pacientes');
    }catch(e){ errEl.textContent = e.message; }
  };
  if(editing){
    document.getElementById('fPFicha').onclick = ()=> imprimirFicha(editing);
    const bExcP = document.getElementById('fPExcluir'); if(bExcP) bExcP.onclick = async ()=>{
      if(!confirm('Excluir este paciente? O histórico de exames é mantido, só o cadastro sai da lista.')) return;
      try{
        await api(`/pacientes/${editing.id}`, { method:'DELETE' });
        pacientes = pacientes.filter(p=>p.id!==editId);
        closeModal(); toast('Paciente excluído.'); renderView('pacientes');
      }catch(e){ erroApi(e); }
    };
  }
}

/* ========================= ASSISTENTE POR CONVERSA ========================= */
let chatState = { step:'nome', dados:{} };
const DIAS_SEMANA = {'domingo':0,'segunda':1,'segunda-feira':1,'terça':2,'terca':2,'terça-feira':2,'terca-feira':2,'quarta':3,'quarta-feira':3,'quinta':4,'quinta-feira':4,'sexta':5,'sexta-feira':5,'sábado':6,'sabado':6};

function renderAssistente(main){
  main.innerHTML = `${['admin','profissional'].includes(usuarioAtual?.papel) ? `<div class="card"><h2>Foto para a IA</h2>
      <p class="sub">Mande a foto da receita, do olho ou da pálpebra. A IA lê o grau, faz a triagem de olho e pálpebra e lê laudos de OCT, retinografia, campo visual e topografia. Ela compara com os valores de referência e lista hipóteses. Quem confirma o diagnóstico é o médico.</p>
      <button type="button" class="btn btn-primary btn-block" data-foto-ia="1">Mandar foto</button></div>` : ''}
    <div class="card">
      <h2>Assistente de agendamento</h2>
      <p class="sub">Converse normalmente. Ele entende dia, horário, e confirma o agendamento.</p>
      <div class="chat-box" id="chatBox"></div>
      <div class="chat-input-row">
        <input type="text" id="chatInput" placeholder="Digite aqui...">
        <button class="btn btn-primary" id="chatSend">Enviar</button>
      </div>
    </div>
  `;
  chatState = { step:'nome', dados:{} };
  const box = document.getElementById('chatBox');
  addBotMsg(box, 'Olá! Vamos marcar um exame de vista. Qual o nome completo do paciente?');
  document.getElementById('chatSend').onclick = sendChat;
  document.getElementById('chatInput').addEventListener('keydown', e=>{ if(e.key==='Enter') sendChat(); });
}
function addBotMsg(box, text){ box.insertAdjacentHTML('beforeend', `<div class="msg bot">${text}</div>`); box.scrollTop = box.scrollHeight; }
function addUserMsg(box, text){ box.insertAdjacentHTML('beforeend', `<div class="msg user">${text}</div>`); box.scrollTop = box.scrollHeight; }

function parseDataHora(texto){
  const t = texto.toLowerCase();
  let data = null;
  const hoje = new Date();
  if(t.includes('hoje')) data = new Date(hoje);
  else if(t.includes('amanhã') || t.includes('amanha')) { data = new Date(hoje); data.setDate(data.getDate()+1); }
  else {
    const dm = t.match(/(\d{1,2})\/(\d{1,2})(?:\/(\d{2,4}))?/);
    if(dm){ data = new Date(hoje.getFullYear(), parseInt(dm[2])-1, parseInt(dm[1])); }
    else {
      for(const k in DIAS_SEMANA){
        if(t.includes(k)){
          data = new Date(hoje);
          let target = DIAS_SEMANA[k];
          let diff = (target - data.getDay() + 7) % 7;
          if(diff===0) diff = 7;
          data.setDate(data.getDate()+diff);
          break;
        }
      }
    }
  }
  let hora = null;
  const hm = t.match(/(\d{1,2})[h:](\d{2})?/);
  if(hm){ hora = `${hm[1].padStart(2,'0')}:${(hm[2]||'00').padStart(2,'0')}`; }
  return { data: data? dataISO(data): null, hora };
}

function sendChat(){
  const input = document.getElementById('chatInput');
  const box = document.getElementById('chatBox');
  const val = input.value.trim();
  if(!val) return;
  addUserMsg(box, val);
  input.value = '';

  if(chatState.step==='nome'){
    chatState.dados.nome = val;
    const existente = pacientes.find(p=>p.nome_completo.toLowerCase()===val.toLowerCase());
    if(existente) chatState.dados.pacienteId = existente.id;
    chatState.step = 'telefone';
    addBotMsg(box, existente? `Encontrei ${existente.nome_completo} já cadastrado(a). Qual o telefone para confirmar?` : 'Certo. Qual o telefone de contato?');
  }
  else if(chatState.step==='telefone'){
    chatState.dados.telefone = val;
    chatState.step = 'quando';
    addBotMsg(box, 'Para quando você quer marcar? (ex: "amanhã às 14h" ou "sexta-feira 10h30")');
  }
  else if(chatState.step==='quando'){
    const {data, hora} = parseDataHora(val);
    if(!data || !hora){ addBotMsg(box, 'Não entendi bem a data/horário. Pode repetir, por exemplo: "quinta-feira às 15h"?'); return; }
    chatState.dados.data = data; chatState.dados.hora = hora;
    chatState.step = 'confirma';
    addBotMsg(box, `Confirmando: ${chatState.dados.nome}, dia ${fmtData(data)} às ${hora}. Posso agendar? (responda "sim" ou "não")`);
  }
  else if(chatState.step==='confirma'){
    if(/sim|pode|confirmo|ok/i.test(val)){
      confirmarAgendamentoChat(box);
    } else {
      addBotMsg(box, 'Sem problema, não vou agendar. Se quiser recomeçar, digite o nome do paciente.');
      chatState = {step:'nome', dados:{}};
    }
  }
  else {
    chatState = {step:'telefone', dados:{nome: val}};
    addBotMsg(box, 'Vamos marcar outro horário. Qual o telefone de contato?');
  }
}

async function confirmarAgendamentoChat(box){
  try{
    let pacienteId = chatState.dados.pacienteId;
    if(!pacienteId){
      const novo = await api('/pacientes', { method:'POST', body:{ nome_completo: chatState.dados.nome, telefone: chatState.dados.telefone, agendado_por:'Assistente' } });
      pacientes.push(novo); pacienteId = novo.id;
    }
    const tipoPadrao = tiposAtendimento[0];
    await api('/agendamentos', { method:'POST', body:{
      paciente_id: pacienteId, tipo_atendimento_id: tipoPadrao.id,
      data_hora: `${chatState.dados.data}T${chatState.dados.hora}:00`,
      agendado_por: 'Assistente'
    }});
    agendamentos = await api(`/agendamentos?de=${chatState.dados.data}&ate=${chatState.dados.data}`).then(novos=>{
      const outros = agendamentos.filter(a=>soData(a.data_hora)!==chatState.dados.data);
      return [...outros, ...novos];
    });
    addBotMsg(box, `Pronto! Agendamento criado para ${fmtData(chatState.dados.data)} às ${chatState.dados.hora}. ✅`);
  }catch(e){
    addBotMsg(box, `Não consegui agendar: ${e.message}`);
  }
  chatState = {step:'fim', dados:{}};
}

/* ========================= RECEITA E ATESTADO ========================= */
const CID_LIST = [
  {cid:'H00.0', desc:'Hordéolo (terçol) e outras inflamações profundas da pálpebra'}, {cid:'H00.1', desc:'Calázio'},
  {cid:'H01.0', desc:'Blefarite'}, {cid:'H02.4', desc:'Ptose palpebral'},
  {cid:'H04.1', desc:'Outros transtornos da glândula lacrimal (síndrome do olho seco)'}, {cid:'H04.2', desc:'Epífora (lacrimejamento)'},
  {cid:'H10', desc:'Conjuntivite'}, {cid:'H10.1', desc:'Conjuntivite atópica aguda'}, {cid:'H10.3', desc:'Conjuntivite aguda não especificada'},
  {cid:'H10.4', desc:'Conjuntivite crônica'}, {cid:'H10.5', desc:'Blefaroconjuntivite'}, {cid:'H10.9', desc:'Conjuntivite não especificada'},
  {cid:'H11.0', desc:'Pterígio'}, {cid:'H11.3', desc:'Hemorragia conjuntival'},
  {cid:'H16.0', desc:'Úlcera de córnea'}, {cid:'H16.9', desc:'Ceratite não especificada'}, {cid:'H17.9', desc:'Cicatriz e opacidade da córnea não especificada'},
  {cid:'H18.6', desc:'Ceratocone'}, {cid:'H20.9', desc:'Iridociclite não especificada'},
  {cid:'H25', desc:'Catarata senil'}, {cid:'H26.9', desc:'Catarata não especificada'}, {cid:'H27.0', desc:'Afacia'},
  {cid:'H33', desc:'Descolamentos e defeitos da retina'}, {cid:'H34', desc:'Oclusões vasculares da retina'},
  {cid:'H35.0', desc:'Retinopatias de fundo e alterações vasculares da retina'}, {cid:'H35.3', desc:'Degeneração macular'},
  {cid:'H36.0', desc:'Retinopatia diabética'},
  {cid:'H40', desc:'Glaucoma'}, {cid:'H40.0', desc:'Suspeita de glaucoma'}, {cid:'H40.1', desc:'Glaucoma primário de ângulo aberto'},
  {cid:'H43.3', desc:'Outras opacidades vítreas (moscas volantes)'}, {cid:'H46', desc:'Neurite óptica'}, {cid:'H47.2', desc:'Atrofia óptica'},
  {cid:'H49.9', desc:'Estrabismo paralítico não especificado'}, {cid:'H50.0', desc:'Estrabismo convergente concomitante'},
  {cid:'H50.1', desc:'Estrabismo divergente concomitante'}, {cid:'H50.9', desc:'Estrabismo não especificado'},
  {cid:'H51.1', desc:'Insuficiência de convergência e excesso de convergência'},
  {cid:'H52.0', desc:'Hipermetropia'}, {cid:'H52.1', desc:'Miopia'}, {cid:'H52.2', desc:'Astigmatismo'},
  {cid:'H52.3', desc:'Anisometropia e aniseiconia'}, {cid:'H52.4', desc:'Presbiopia'}, {cid:'H52.5', desc:'Transtornos da acomodação'},
  {cid:'H52.6', desc:'Outros transtornos da refração'}, {cid:'H52.7', desc:'Transtorno da refração não especificado'},
  {cid:'H53.0', desc:'Ambliopia por anopsia'}, {cid:'H53.1', desc:'Distúrbios visuais subjetivos'}, {cid:'H53.2', desc:'Diplopia (visão dupla)'},
  {cid:'H53.3', desc:'Outros transtornos da visão binocular'}, {cid:'H53.4', desc:'Defeitos do campo visual'},
  {cid:'H53.5', desc:'Deficiências da visão cromática (daltonismo)'}, {cid:'H53.6', desc:'Cegueira noturna'},
  {cid:'H53.8', desc:'Outros distúrbios visuais'}, {cid:'H53.9', desc:'Distúrbio visual não especificado'},
  {cid:'H54', desc:'Cegueira e visão subnormal'}, {cid:'H57.1', desc:'Dor ocular'},
  {cid:'T15.0', desc:'Corpo estranho na córnea'}, {cid:'T15.1', desc:'Corpo estranho no saco conjuntival'},
  {cid:'Z01.0', desc:'Exame dos olhos e da visão'},
  {cid:'Z13.5', desc:'Rastreamento especial de transtornos dos olhos e dos ouvidos'}, {cid:'Z46.0', desc:'Colocação e ajustamento de óculos e lentes de contato'},
  {cid:'Z97.3', desc:'Presença de óculos e lentes de contato'},
];
const CID_COMUNS = ['H52.1','H52.0','H52.2','H52.4','Z01.0'];
/* busca por código (com ou sem ponto) ou por parte do nome, sem acento */
const semAcento = t=> String(t||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
function buscarCid(q){
  const t = semAcento(q).trim(); if(!t) return [];
  const tc = t.replace('.','');
  return CID_LIST.filter(c=> (podeCidMedico() || CID_MOTIVO.includes(c.cid)) && (semAcento(c.cid).replace('.','').includes(tc) || semAcento(c.desc).includes(t)));
}
/* quem não é médico só usa CID de motivo do atendimento (grupo Z). CID de doença é diagnóstico e fica com o médico. */
const CID_MOTIVO = ['Z01.0','Z13.5','Z46.0','Z97.3'];
const cidPermitido = (cid)=> !!cid && (podeCidMedico() || CID_MOTIVO.includes(cid.cid));
const TIPOS_LENTE = ['Monofocal','Bifocal','Multifocal','Monofocal para perto (só leitura)','Ocupacional (perto e intermediária)'];
const ehSoPerto = t=> /para perto/i.test(t||'');
const ehOcupacional = t=> /^Ocupacional/i.test(t||'');
const LISTA_SINTOMAS = ['Visão embaçada','Dificuldade pra enxergar de longe','Dificuldade pra enxergar de perto','Dor de cabeça','Lacrimejamento','Coceira ou ardência','Sensibilidade à luz','Fadiga visual','Visão dupla','Olho seco'];
/* sintomas que pedem encaminhamento ao oftalmologista (aparecem em vermelho e geram alerta) */
const SINTOMAS_ALERTA = ['Flashes de luz','Moscas volantes novas','Perda súbita de visão','Dor no olho','Trauma recente no olho','Olho vermelho com dor','Visão dupla'];
LISTA_SINTOMAS.splice(LISTA_SINTOMAS.indexOf('Visão dupla'),1);
LISTA_SINTOMAS.push(...SINTOMAS_ALERTA);

/* Gabarito de acuidade visual: mesma estrutura de um exame em papel, serve tanto
   pra exame comum quanto admissional de empresa (campos de empresa ficam em branco
   quando não é o caso). Letras e faixas abaixo seguem o padrão de 8 linhas comum
   nesse tipo de teste (20/20 até 20/200). */
const LINHAS_ACUIDADE = [
  { faixa:'20/20',  od:'T I X L U', oe:'L V T I U' },
  { faixa:'20/25',  od:'O H F Z U', oe:'O H I N T' },
  { faixa:'20/30',  od:'D N O H S', oe:'O S D H N' },
  { faixa:'20/40',  od:'H L E N Z', oe:'Z H E L N' },
  { faixa:'20/50',  od:'R D L Z H', oe:'Z G L R H' },
  { faixa:'20/70',  od:'B F T P',   oe:'P F B T' },
  { faixa:'20/100', od:'L P E',     oe:'T O Z' },
  { faixa:'20/200', od:'F',         oe:'E' },
];
function gabaritoVazio(){
  return {
    idadePaciente:'', empresa:'', funcao:'', setor:'',
    usaOculos:'', frequenciaUso:'', tipoLenteAtual:'', tempoUsoAtual:'', ultimaConsultaEspecialista:'',
    jaFezExameEspecialista:'', possuiDoencaOcular:'', doencaOcularQual:'',
    senteDificuldadeVisual:'', dificuldadeQual:'',
    testeComCorrecao:'',
    linhasOD: Array(8).fill(null), linhasOE: Array(8).fill(null), // true=acertou, false=errou, null=não marcado
    resultadoOD:'', resultadoOE:'',
    avLongeSemOD:'', avLongeSemOE:'', avLongeSemAO:'',
    avLongeComOD:'', avLongeComOE:'', avLongeComAO:'',
    avPertoOD:'', avPertoOE:'', avPertoAO:'',
    testeCores:'', testeCoresAcertos:'',
    condutaGabarito:'', observacoesGabarito:''
  };
}
const TRATAMENTOS = ['Antirreflexo','Blue Control (filtro de luz azul)','Fotocromática (Transitions)','Anti-risco','Proteção UV','Antiembaçante','Hidro/Oleofóbica (repele água e gordura)','Polarizada'];

let receitaAtual = { pacienteId:'', idade:'', profissionalId:'', longe:{od:{esf:'',cil:'',eixo:''},oe:{esf:'',cil:'',eixo:''}}, perto:{od:{esf:'',cil:'',eixo:''},oe:{esf:'',cil:'',eixo:''}}, adicao:'', adicaoOe:'', tipoLente:TIPOS_LENTE[0], tratamentos:[], cid:null, atestadoTexto:'', declaracaoTexto:'',
  extras:{avOd:'',avOe:'',dnpOd:'',dnpOe:'',dp:''},
  mostrar:{av:true,dnp:true,idade:true}, distPerto:'', modoDist:'idade', alcanceOcup:'2', cidNoAtestado:false,
  adaptacaoSai:true, adaptacaoTexto:'', adaptacaoEditada:false, atestadoEditado:false, declaracaoEditado:false,
  pertoAuto:true, adicaoSugeridaAceita:false }; // pertoAuto: enquanto true, o Perto acompanha Longe+adição no multifocal; vira false assim que o atendente edita o Perto manualmente

/* Adição de referência por faixa etária (presbiopia). Ponto de partida, não regra:
   40-44: +1,00 · 45-49: +1,50 · 50-54: +2,00 · 55-59: +2,25 · 60-64: +2,50 · 65+: +2,75
   Base: tabela da Community Eye Health (35-45 +1,00; 45-50 +1,50; 50-55 +2,00; acima de 55 +2,50)
   e estudo com 869 pessoas (J Korean Ophthalmol Soc: 41-45 +1,00/+1,25; 46-50 +1,50/+1,75;
   51-55 +2,00; 56-60 +2,25/+2,50; 61-65 +2,50; 66-70 +2,75). O campo continua 100% digitável. */
function adicaoSugeridaPorIdade(idade){
  const n = parseInt(idade, 10);
  if(isNaN(n) || n < 40) return null;
  if(n <= 44) return '+1.00';
  if(n <= 49) return '+1.50';
  if(n <= 54) return '+2.00';
  if(n <= 59) return '+2.25';
  if(n <= 64) return '+2.50';
  return '+2.75';
}
/* Modo híbrido: olha primeiro como o paciente lê de perto com a correção de longe.
   J1 ou J2: enxerga bem, não precisa de adição agora. J3 ou J4: tabela menos 0,50.
   J5 ou pior, ou sem teste: tabela inteira. Modo "tabela" ignora a leitura. */
function adicaoHibrida(idade, j, modo){
  const n = parseInt(idade, 10);
  if(isNaN(n)) return { valor:null, texto:'Informe a idade para ver a sugestão.' };
  if(n < 40) return { valor:null, texto:'Abaixo de 40 anos a adição de perto não costuma ser necessária. Se o paciente reclama de perto, meça com o cartão de leitura a 40 cm.' };
  const tab = adicaoSugeridaPorIdade(n), tabN = parseFloat(tab);
  const fmt = v=> '+'+v.toFixed(2);
  if(modo==='tabela') return { valor:tab, texto:'Tabela de '+n+' anos: '+tab+'.' };
  if(!j) return { valor:tab, texto:'Leitura de perto não informada. Pela tabela de '+n+' anos: '+tab+'.' };
  if(j<=2) return { valor:null, texto:'Lê J'+j+' de perto com a correção de longe. Boa visão de perto, sem adição por enquanto. Pela tabela seria '+tab+'. Só dê adição se ele reclamar de cansaço ao ler.' };
  if(j<=4){ const v = Math.max(0.75, tabN-0.5); return { valor:fmt(v), texto:'Lê J'+j+': a dificuldade está começando. Sugestão: tabela de '+n+' anos ('+tab+') menos 0,50, ou seja '+fmt(v)+'.' }; }
  return { valor:tab, texto:'Lê J'+j+' ou pior. Use a tabela inteira de '+n+' anos: '+tab+'.' };
}
/* converte "J2", "j 3", "N8" em número da escala J */
function leituraPertoJ(txt){
  const t = String(txt||'').trim();
  let m = /J\s*(\d+)/i.exec(t); if(m) return Math.min(6, Math.max(1, +m[1]));
  m = /N\s*(\d+)/i.exec(t); if(m){ const n=+m[1]; return n<=5?1:n<=6?2:n<=8?3:n<=10?5:6; }
  return null;
}

/* ---- listas de opção pro combobox próprio (não usa <datalist> nativo) ----
   O <datalist> do navegador tem um problema sério no iOS: quando a lista passa de
   poucas opções, o painel de sugestão cobre o campo inteiro na tela. Por isso o menu
   de sugestão aqui é feito à mão, em HTML/CSS normal, e se comporta igual em
   qualquer celular. */
function opcoesEsf(){ const o=[]; for(let v=-20;v<=20;v+=0.25) o.push((v>0?'+':'')+v.toFixed(2)); return o; }
function opcoesCil(){ const o=['0.00']; for(let v=-0.25;v>=-10;v-=0.25) o.push(v.toFixed(2)); return o; }
function opcoesAdicao(){ const o=[]; for(let v=0.25;v<=4;v+=0.25) o.push('+'+v.toFixed(2)); return o; }
/* eixo: só os valores mais usados na prática aparecem como sugestão rápida (180 opções
   cobririam a tela toda); qualquer grau de 1 a 180 continua aceito digitando direto */
function opcoesEixo(){ return [180,90,45,135,30,60,120,150,10,20,70,100,160,170].map(v=>v+'°'); }

/* esférico aceita -20.00 a +20.00 */
function normalizarEsf(v){
  v = v.trim().replace(',', '.');
  if(v===''){ return ''; }
  const n = parseFloat(v);
  if(isNaN(n)) return v; // deixa como digitado, não trava o campo
  return (n>0?'+':'') + n.toFixed(2);
}
/* cilíndrico é sempre negativo por convenção clínica */
function normalizarCil(v){
  v = v.trim().replace(',', '.');
  if(v===''){ return ''; }
  const n = parseFloat(v);
  if(isNaN(n)) return v;
  const neg = n>0 ? -n : n;
  return neg===0 ? '0.00' : neg.toFixed(2);
}
/* eixo é cíclico entre 1 e 180: 0° e 180° são o mesmo meridiano, então por convenção
   nunca se escreve "0", sempre "180". Qualquer valor fora da faixa dá a volta
   (ex: 181 vira 1, 360 vira 180), em vez de simplesmente cortar no limite. */
function normalizarEixo(v){
  v = v.trim().replace('°','').replace(',', '.');
  if(v==='') return '';
  const n = parseInt(v,10);
  if(isNaN(n)) return v;
  const ciclico = ((n - 1) % 180 + 180) % 180 + 1;
  return ciclico + '°';
}

/* mostra embaixo do campo, por 2.5s, o que mudou quando o valor digitado é
   corrigido automaticamente (sinal do cilindro, eixo fora da faixa, etc.) */
function avisarCorrecao(campoId, valorDigitado, valorFinal){
  const msg = document.getElementById(campoId+'_msg');
  if(!msg) return;
  if(valorDigitado && valorDigitado!==valorFinal){
    msg.textContent = `Ajustado para ${valorFinal}`;
    msg.className = 'fieldmsg bad';
  } else if(valorFinal){
    msg.textContent = 'OK';
    msg.className = 'fieldmsg ok';
  } else {
    msg.textContent = ''; msg.className = 'fieldmsg';
  }
}

function olhoBlock(dist, olho, label){
  const d = receitaAtual[dist][olho];
  return `<div class="row3">
      <div><div class="combo-wrap"><label>${label} Esf.</label><input type="text" inputmode="decimal" id="r_${dist}_${olho}_esf" value="${d.esf}" placeholder="-1.00" autocomplete="off"></div><p class="fieldmsg" id="r_${dist}_${olho}_esf_msg"></p></div>
      <div><div class="combo-wrap"><label>${label} Cil.</label><input type="text" inputmode="decimal" id="r_${dist}_${olho}_cil" value="${d.cil}" placeholder="-0.75" autocomplete="off"></div><p class="fieldmsg" id="r_${dist}_${olho}_cil_msg"></p></div>
      <div><div class="combo-wrap"><label>${label} Eixo</label><input type="text" inputmode="numeric" id="r_${dist}_${olho}_eixo" value="${d.eixo}" placeholder="90°" autocomplete="off"></div><p class="fieldmsg" id="r_${dist}_${olho}_eixo_msg"></p></div>
    </div>`;
}

/* perto = longe + adição (sempre positiva), cilindro e eixo repetem os de longe.
   Só recalcula automático quando o tipo é Multifocal, a adição está preenchida,
   e o atendente ainda não editou o Perto manualmente (pertoAuto). */

/* ===== Distância de leitura (perto) =====
   Poder da lente para ver nítido a d cm = 100/d dioptrias. Dois modos:
   "exata": paciente sem acomodação, adição = 100/d.
   "idade": desconta metade da acomodação que ainda resta (Hofstetter, amplitude mínima = 15 - 0,25 x idade). */
const DISTANCIAS_PERTO = [25,35,45,50];
function arred025(n){ return Math.round(n*4)/4; }
function adicaoParaDistancia(cm){
  const demanda = 100/cm;
  const idade = parseInt(receitaAtual.idade,10);
  if(receitaAtual.modoDist==='idade' && idade>0){
    const amp = Math.max(0, 15 - 0.25*idade);
    return Math.max(0, arred025(demanda - amp/2));
  }
  return arred025(demanda);
}
function fmtAdicao(n){ return (n>0?'+':'')+n.toFixed(2); }
function distanciaDaAdicao(adicao){
  const n = parseFloat(String(adicao||'').replace('+','').replace(',','.'));
  return n>0 ? Math.round(100/n) : null;
}
function textoDistanciaInfo(){
  const r = receitaAtual, cm = distanciaDaAdicao(r.adicao);
  const partes = [];
  if(cm) partes.push(`Com a adição ${r.adicao} o foco exato fica a ${cm} cm.`);
  if(r.distPerto) partes.push(`Distância escolhida para a leitura: ${r.distPerto} cm.`);
  return partes.join(' ');
}
function atualizarInfoDistancia(){
  const el = document.getElementById('distInfo'); if(el) el.textContent = textoDistanciaInfo();
  document.querySelectorAll('#distChips [data-cm]').forEach(b=>{ b.classList.toggle('btn-primary', String(receitaAtual.distPerto)===b.dataset.cm); b.classList.toggle('btn-outline', String(receitaAtual.distPerto)!==b.dataset.cm); });
}
function distanciaBlocoHtml(){
  const r = receitaAtual;
  const idade = parseInt(r.idade,10);
  const chips = DISTANCIAS_PERTO.map(cm=>`<button type="button" class="btn btn-sm ${String(r.distPerto)===String(cm)?'btn-primary':'btn-outline'}" data-cm="${cm}" style="width:auto;margin:0 6px 6px 0;">${cm} cm → ${fmtAdicao(adicaoParaDistancia(cm))}</button>`).join('');
  const soPerto = ehSoPerto(r.tipoLente);
  return `<div class="sugestao-chip" style="display:block;margin-top:10px;">
    <b>Distância de leitura</b> <span style="font-weight:400;color:var(--ink-soft);">${soPerto?'(óculos só para perto)':'(toque para preencher a adição)'}</span>
    <div id="distChips" style="margin:8px 0 4px;">${chips}</div>
    <label style="margin-top:6px;">Como calcular</label>
    <select id="rModoDist"><option value="idade" ${r.modoDist==='idade'?'selected':''}>Descontar a acomodação da idade${idade>0?'':' (digite a idade)'}</option><option value="exata" ${r.modoDist==='exata'?'selected':''}>Foco exato na distância (sem acomodação)</option></select>
    <p class="sub" id="distInfo" style="margin:6px 0 0;">${esc(textoDistanciaInfo())}</p>
    <p class="sub" style="margin:4px 0 0;font-size:12px;">Poder = 100 ÷ distância em cm. Em 25 cm: 4,00 D. Em 35 cm: 2,86 D. Em 45 cm: 2,22 D. Em 50 cm: 2,00 D. O valor sai arredondado de 0,25 em 0,25. A decisão final é sua.</p>
  </div>`;
}
function ocupacionalBlocoHtml(){
  const r = receitaAtual;
  return `<div class="sugestao-chip" style="display:block;margin-top:10px;">
    <b>Lente ocupacional</b>
    <p class="sub" style="margin:4px 0 6px;">Serve para o trabalho: enxerga do perto até 1,5 m a 2 m. Não serve para dirigir nem para ver de longe.</p>
    <label>Alcance da lente</label>
    <select id="rAlcanceOcup"><option value="1,5" ${r.alcanceOcup==='1,5'?'selected':''}>Até 1,5 m</option><option value="2" ${r.alcanceOcup==='2'?'selected':''}>Até 2 m</option></select>
  </div>`;
}
function textoAdaptacaoPadrao(){
  const t = receitaAtual.tipoLente||'';
  const geral = 'Use os óculos novos o dia todo, desde que acordar, e evite voltar aos óculos antigos. ';
  const volte = 'Se a dor de cabeça ou a visão distorcida durar mais de 2 ou 3 dias, volte à ótica para conferir os óculos.';
  if(ehSoPerto(t)) return `Use estes óculos só para ler e para trabalhos de perto${receitaAtual.distPerto?', a cerca de '+receitaAtual.distPerto+' cm':''}. Não use para dirigir nem para andar. A adaptação costuma levar alguns dias. ${volte}`;
  if(ehOcupacional(t)) return `Lente para o trabalho, com foco do perto até ${receitaAtual.alcanceOcup} m. Não use para dirigir. A adaptação pode levar de alguns dias a algumas semanas. ${geral}Deixe a tela um pouco abaixo da linha dos olhos e vire a cabeça em vez de mexer só os olhos. Se não melhorar em 1 a 2 semanas, volte à ótica para conferir os óculos.`;
  if(/^Multifocal/i.test(t)) return `Lentes multifocais pedem mais tempo. A adaptação pode levar de alguns dias a algumas semanas, até cerca de 30 dias de uso. ${geral}Para ver de longe, olhe pela parte de cima da lente. Para ler, olhe pela parte de baixo. Vire a cabeça em vez de mexer só os olhos. Se não melhorar em 1 a 2 semanas, volte à ótica para conferir os óculos.`;
  if(/^Bifocal/i.test(t)) return `Para ler, olhe pela parte de baixo da lente. A adaptação costuma levar alguns dias e, para algumas pessoas, até 2 semanas. ${geral}${volte}`;
  return `A adaptação a óculos novos costuma levar alguns dias e, para algumas pessoas, até 2 semanas. ${geral}${volte}`;
}
function garantirTextosPadrao(){
  const r = receitaAtual;
  if(!r.adaptacaoEditada) r.adaptacaoTexto = textoAdaptacaoPadrao();
  const p = pacienteDaReceita(), nome = p ? p.nome_completo : 'o(a) paciente';
  const c = clinicaAtual || {}; const un = (typeof minhaUnidade==='function' && minhaUnidade()) || null;
  const onde = (c.nome_fantasia || 'esta clínica') + (un && un.nome ? ' ('+un.nome+')' : '');
  if(!r.atestadoEditado) r.atestadoTexto = `Atesto, para os devidos fins, que ${nome} esteve em atendimento de saúde ocular (exame de vista) em ${onde}, no dia ${dataExtenso()}.`;
  if(!r.declaracaoEditado) r.declaracaoTexto = `Declaro, para os devidos fins, que ${nome} compareceu a ${onde}, no dia ${dataExtenso()}, para realização de exame de vista.`;
}
function calcularPerto(){
  if(!receitaAtual.adicao || !receitaAtual.pertoAuto) return false;
  const adicaoOd = parseFloat(receitaAtual.adicao.replace('+',''));
  if(isNaN(adicaoOd)) return false;
  const adicaoOe = parseFloat(String(receitaAtual.adicaoOe||'').replace('+','')); // OE só tem adição própria quando é diferente da do OD
  ['od','oe'].forEach(olho=>{
    const adicao = (olho==='oe' && !isNaN(adicaoOe)) ? adicaoOe : adicaoOd;
    const esfLonge = parseFloat((receitaAtual.longe[olho].esf||'0').replace('+','')) || 0;
    const novoEsf = esfLonge + adicao;
    receitaAtual.perto[olho].esf = (novoEsf>0?'+':'') + novoEsf.toFixed(2);
    receitaAtual.perto[olho].cil = receitaAtual.longe[olho].cil;
    receitaAtual.perto[olho].eixo = receitaAtual.longe[olho].eixo;
  });
  return true;
}
function atualizarCamposPerto(){
  ['od','oe'].forEach(olho=>['esf','cil','eixo'].forEach(campo=>{
    const el = document.getElementById(`r_perto_${olho}_${campo}`);
    if(el) el.value = receitaAtual.perto[olho][campo];
  }));
}

/* combobox próprio: um <div> de sugestões posicionado embaixo do campo, sem depender
   do <datalist> nativo do navegador */
function montarCombo(inputId, opcoes){
  const input = document.getElementById(inputId);
  if(!input) return;
  const wrap = input.closest('.combo-wrap');
  const panel = document.createElement('div');
  panel.className = 'combo-panel';
  wrap.appendChild(panel);
  function render(){
    const filtro = input.value.trim().toLowerCase();
    const lista = filtro ? opcoes.filter(o=>o.toLowerCase().includes(filtro)) : opcoes;
    if(!lista.length){ panel.classList.remove('show'); return; }
    panel.innerHTML = lista.map(o=>`<div class="combo-opt">${o}</div>`).join('');
    panel.classList.add('show');
  }
  input.addEventListener('focus', render);
  input.addEventListener('input', render);
  input.addEventListener('blur', ()=> setTimeout(()=> panel.classList.remove('show'), 180));
  panel.addEventListener('mousedown', e=>{
    const opt = e.target.closest('.combo-opt');
    if(!opt) return;
    input.value = opt.textContent;
    panel.classList.remove('show');
    input.dispatchEvent(new Event('blur'));
  });
}


/* ========================= PIX PARA RECEITA E ATESTADO ========================= */
const NOME_DOC = { receita:'Receita', atestado:'Atestado', declaracao:'Declaração' };
function textoDocumento(tipo){
  if(tipo==='receita') return gerarTextoReceita();
  if(tipo==='atestado') return gerarTextoAtestado();
  const p = pacienteDaReceita();
  return `*DECLARAÇÃO DE COMPARECIMENTO*\n${clinicaAtual?.nome_fantasia||''}\n\nPaciente: ${p?p.nome_completo:''}\nData: ${fmtData(hojeISO())}\n\n${receitaAtual.declaracaoTexto}${textoCarimbo()}`;
}
function pixImagemQr(payload){
  try{ const qr = qrcode(0,'M'); qr.addData(payload); qr.make(); return qr.createImgTag(5,8); }catch(e){ return ''; }
}
async function pixMontar(){
  const box = document.getElementById('pixBox'); if(!box) return;
  const cab = `<h3 style="margin:10px 0 2px;font-size:16px;">Cobrar por Pix <span class="meta" style="font-weight:400;">opcional</span></h3>
    <p class="sub">Gera um QR Code. O paciente paga pelo app do banco e o dinheiro cai direto na sua chave Pix, sem taxa. Depois do pagamento você envia a receita ou o atestado por WhatsApp.</p>`;
  let cfg, lista = [];
  try{
    cfg = await api('/receitas/pix/config');
    if(receitaAtual.pacienteId) lista = await api('/receitas/pix/cobrancas?paciente_id='+encodeURIComponent(receitaAtual.pacienteId));
  }catch(e){ if(document.getElementById('pixBox')===box) box.innerHTML = cab + '<p class="sub">Não consegui abrir o Pix agora.</p>'; return; }
  if(document.getElementById('pixBox')!==box) return;
  const pac = pacienteDaReceita();
  const pend = lista.find(x=>x.status==='pendente');
  const pagos = lista.filter(x=>x.status==='pago').slice(0,3);
  const admin = cfg.pode_editar;
  let h = cab;
  if(!cfg.configurado){
    h += `<p class="sub">A chave Pix ainda não foi configurada.</p>`;
  } else if(!pac){
    h += `<p class="sub">Escolha o paciente acima para cobrar.</p>`;
  } else {
    const padrao = t => (t==='receita' ? cfg.valor_receita : cfg.valor_atestado);
    h += `<div class="row2"><div><label>Documento</label><select id="pxTipo">${Object.entries(NOME_DOC).map(([k,n])=>`<option value="${k}">${n}</option>`).join('')}</select></div>
      <div><label>Valor (R$)</label><input type="text" inputmode="decimal" id="pxValor" placeholder="35,00" value="${padrao('receita')!=null ? Number(padrao('receita')).toFixed(2).replace('.',',') : ''}"></div></div>
      <button class="btn btn-primary btn-block" id="pxGerar" style="margin-top:10px;">Gerar QR Code Pix</button>`;
  }
  if(pend){
    h += `<div class="card" style="margin-top:12px;text-align:center;background:#FBFAF7;">
      <b>${NOME_DOC[pend.tipo]} · ${fmtMoeda(pend.valor)}</b><div class="sub" style="margin:2px 0 8px;">Aguardando pagamento</div>
      <div id="pxQr" style="display:inline-block;background:#fff;padding:8px;border-radius:10px;">${pixImagemQr(pend.payload)}</div>
      <p class="sub" style="margin:8px 0 4px;">Pix copia e cola</p>
      <textarea id="pxCodigo" readonly rows="3" style="font-size:12px;">${esc(pend.payload)}</textarea>
      <div class="btn-row" style="margin-top:8px;justify-content:center;">
        <button class="btn btn-ghost" id="pxCopiar">Copiar código</button>
        <button class="btn btn-wpp" id="pxZapPix">Mandar o Pix por WhatsApp</button>
        <button class="btn btn-primary" id="pxPago">Já recebi o pagamento</button>
        <button class="btn btn-ghost" id="pxCancelar">Cancelar cobrança</button></div></div>`;
  }
  if(pagos.length){
    h += `<h4 style="margin:14px 0 4px;font-size:14px;">Pagos deste paciente</h4>` + pagos.map(x=>`<div class="list-item"><div><div class="name">${NOME_DOC[x.tipo]} · ${fmtMoeda(x.valor)}</div><div class="meta">Pago em ${fmtData(x.pago_em)}${x.pago_por_nome?' · confirmado por '+esc(x.pago_por_nome):''}</div></div><button class="btn btn-wpp" data-pxdoc="${x.tipo}">Enviar por WhatsApp</button></div>`).join('');
  }
  if(admin) h += `<button class="btn btn-ghost" id="pxConfig" style="margin-top:12px;">Mudar chave Pix e valores</button>`;
  box.innerHTML = h;
  const $ = id => document.getElementById(id);
  if($('pxTipo')) $('pxTipo').onchange = e=>{ const v = e.target.value==='receita' ? cfg.valor_receita : cfg.valor_atestado; $('pxValor').value = v!=null ? Number(v).toFixed(2).replace('.',',') : ''; };
  if($('pxGerar')) $('pxGerar').onclick = async ()=>{
    try{ await api('/receitas/pix/cobrancas', { method:'POST', body:{ paciente_id:receitaAtual.pacienteId, tipo:$('pxTipo').value, valor:$('pxValor').value } }); pixMontar(); }
    catch(e){ erroApi(e); }
  };
  if(pend){
    $('pxCopiar').onclick = async ()=>{ try{ await navigator.clipboard.writeText(pend.payload); toast('Código copiado.'); }catch(e){ $('pxCodigo').select(); toast('Segure o texto e copie.'); } };
    $('pxZapPix').onclick = ()=> abrirWhatsapp(pac.telefone, `Olá, ${String(pac.nome_completo).split(' ')[0]}! Segue o Pix de ${fmtMoeda(pend.valor)} pela ${NOME_DOC[pend.tipo].toLowerCase()}. Abra o app do seu banco, escolha Pix copia e cola e cole o código abaixo.\n\nDepois do pagamento enviamos o documento.\n\n${pend.payload}`);
    $('pxPago').onclick = async ()=>{
      if(!confirm('Confirme só se o dinheiro já apareceu na conta. Marcar como pago?')) return;
      try{ await api(`/receitas/pix/cobrancas/${pend.id}/pagar`, { method:'POST', body:{} }); toast('Pagamento registrado.'); pixMontar(); }catch(e){ erroApi(e); }
    };
    $('pxCancelar').onclick = async ()=>{ try{ await api(`/receitas/pix/cobrancas/${pend.id}`, { method:'DELETE' }); pixMontar(); }catch(e){ erroApi(e); } };
  }
  box.querySelectorAll('[data-pxdoc]').forEach(b=> b.onclick = ()=>{ const t = b.dataset.pxdoc; if((t==='atestado'&&!receitaAtual.atestadoTexto.trim())||(t==='declaracao'&&!receitaAtual.declaracaoTexto.trim())){ toast('Escreva o texto do documento acima.'); return; } enviarWhatsapp(textoDocumento(t)); });
  if($('pxConfig')) $('pxConfig').onclick = ()=> pixConfigurar(cfg);
}
function pixConfigurar(cfg){
  const v = x => x==null ? '' : Number(x).toFixed(2).replace('.',',');
  openModal(`<h2>Chave Pix da clínica</h2>
    <label>Tipo da chave</label><select id="pcTipo">${[['telefone','Telefone'],['cpf','CPF'],['cnpj','CNPJ'],['email','E-mail'],['aleatoria','Chave aleatória']].map(([k,n])=>`<option value="${k}" ${cfg.tipo===k?'selected':''}>${n}</option>`).join('')}</select>
    <label>Chave</label><input type="text" id="pcChave" value="${esc(cfg.tipo==='telefone'&&cfg.chave ? cfg.chave.replace(/^\+55/,'') : cfg.chave)}" placeholder="64992161203">
    <label>Nome que aparece para o pagador (até 25 letras)</label><input type="text" id="pcNome" maxlength="25" value="${esc(cfg.nome)}" placeholder="${esc(clinicaAtual?.nome_fantasia||'')}">
    <label>Cidade (até 15 letras)</label><input type="text" id="pcCidade" maxlength="15" value="${esc(cfg.cidade)}" placeholder="Rio Verde">
    <div class="row2"><div><label>Valor padrão da receita (R$)</label><input type="text" inputmode="decimal" id="pcVr" value="${v(cfg.valor_receita)}"></div>
    <div><label>Valor padrão do atestado (R$)</label><input type="text" inputmode="decimal" id="pcVa" value="${v(cfg.valor_atestado)}"></div></div>
    <div class="btn-row"><button class="btn btn-primary" id="pcSalvar">Salvar</button><button class="btn btn-ghost" onclick="closeModal()">Cancelar</button></div>`);
  document.getElementById('pcSalvar').onclick = async ()=>{
    const g = id => document.getElementById(id).value.trim();
    try{ await api('/receitas/pix/config', { method:'PUT', body:{ tipo:g('pcTipo'), chave:g('pcChave'), nome:g('pcNome'), cidade:g('pcCidade'), valor_receita:g('pcVr'), valor_atestado:g('pcVa') } }); closeModal(); toast('Chave Pix salva.'); pixMontar(); }
    catch(e){ erroApi(e); }
  };
}


/* ========================= VENDAS DO GESTOR (sistema de vendas, OS, estoque e caixa) =========================
   Abre /gestor-vendas/sistema.html dentro da aba (o mesmo sistema abre como app instalável em /gestor-vendas/). Os dados ficam separados por clínica. */
window.addEventListener('message', ev=>{ if(ev.origin === location.origin && ev.data && ev.data.gv === 'entrar'){ toast('Para sincronizar o OCO, saia e entre de novo no sistema.'); } });
function renderVendasGestor(main){
  const cid = usuarioAtual?.slug || clinicaAtual?.slug || clinicaAtual?.id || 'local';
  const nomeLoja = clinicaAtual?.nome_fantasia || usuarioAtual?.clinica || 'Sua ótica';
  const url = '/gestor-vendas/sistema.html?emb=1&c='+encodeURIComponent(cid)+'&n='+encodeURIComponent(nomeLoja)+'&u='+encodeURIComponent(usuarioAtual?.nome||'Gestor');
  main.innerHTML = '<iframe id="gvQuadro" title="Vendas do gestor" src="'+esc(url)+'" allow="camera" style="display:block;width:100%;height:calc(100vh - 120px);min-height:560px;border:0;border-radius:12px;background:#fff;"></iframe>';
}

/* ========================= PÓS-EXAME (gestor de vendas) =========================
   Depois do exame de vista, o gestor pergunta ao paciente se ficou satisfeito. Quem ficou regular ou
   insatisfeito vai para a lista de acompanhamento até o gestor resolver. */
let peAba = 'hoje', peDias = 7;
const NOME_PE = { satisfeito:'Satisfeito', regular:'Regular', insatisfeito:'Insatisfeito', sem_resposta:'Não respondeu' };
const COR_PE = { satisfeito:'#2E7D4F', regular:'#B26A00', insatisfeito:'#C1462F', sem_resposta:'#4B5755' };
const peNome = ()=> clinicaAtual?.nome_fantasia || 'nossa clínica';
const peH3 = t=>`<h3 style="margin:16px 0 4px;font-size:15px;">${t}</h3>`;
const peQuando = x=> `${fmtData(String(x).slice(0,10))} às ${String(x).slice(11,16)}`;
function peMensagem(x){
  return `Olá, ${primeiroNome(x.nome_completo)}! Aqui é da ${peNome()}. Você fez seu exame de vista conosco em ${fmtData(String(x.data_hora).slice(0,10))}. Queremos saber: você ficou satisfeito(a) com o atendimento e com o exame? Se puder, responda com uma nota de 1 a 5 ou nos conte como foi. Para não receber mais avisos, responda SAIR.`;
}
function renderPosExame(main){
  main.innerHTML = `<div class="card"><h2>Pós-exame</h2>
    <p class="sub">Pergunte ao paciente, depois do exame de vista, se ele ficou satisfeito.</p>
    <div class="btn-row" style="margin-bottom:10px;">${[['hoje','Para contatar'],['acompanhar','Acompanhar'],['resultados','Resultados']].map(([k,n])=>`<button class="btn ${peAba===k?'btn-primary':'btn-ghost'}" data-aba="${k}">${n}</button>`).join('')}</div>
    <div id="peCorpo"><p class="sub">Carregando...</p></div></div>`;
  main.querySelectorAll('button[data-aba]').forEach(b=> b.onclick = ()=>{ peAba = b.dataset.aba; renderPosExame(main); });
  const corpo = document.getElementById('peCorpo');
  const falha = e=>{ corpo.innerHTML = `<p class="fieldmsg bad">${esc(e.message)}</p>`; };
  const recarregar = ()=> renderPosExame(main);
  if(peAba==='hoje') peHoje(corpo, recarregar).catch(falha);
  else if(peAba==='acompanhar') peAcompanhar(corpo, recarregar).catch(falha);
  else peResultados(corpo).catch(falha);
}
function peLinha(x, botoes){
  const tel = x.telefone ? esc(x.telefone) : 'sem telefone';
  return `<div class="list-item" style="flex-wrap:wrap;"><div style="flex:1 1 220px;"><div class="name">${esc(x.nome_completo)}</div>
    <div class="meta">${esc(x.tipo||'Exame de vista')} · ${peQuando(x.data_hora)}${x.cidade?' · '+esc(x.cidade):''} · ${tel}</div>
    ${x.resultado ? `<div class="meta" style="color:${COR_PE[x.resultado]};font-weight:700;">${NOME_PE[x.resultado]}${x.observacao?': '+esc(x.observacao):''}</div>` : ''}
    ${x.aceita_contato===false ? '<div class="meta" style="color:#C1462F;">Pediu para não receber mensagens.</div>' : ''}</div>
    <div class="btn-row" style="gap:6px;">${botoes}</div></div>`;
}
async function peHoje(corpo, recarregar){
  const d = await api('/posexame/hoje?dias='+peDias);
  const grade = 'display:grid;grid-template-columns:repeat(auto-fit,minmax(130px,1fr));gap:10px;margin:6px 0;';
  let h = `<label>Exames dos últimos</label><select id="peDias" style="max-width:200px;">${[3,7,15,30].map(n=>`<option value="${n}" ${n===peDias?'selected':''}>${n} dias</option>`).join('')}</select>
    <div style="${grade}">${cartaoNumero('Para perguntar', String(d.a_contatar.length), 'ainda sem contato')}${cartaoNumero('Aguardando resposta', String(d.aguardando.length), 'já perguntados')}${cartaoNumero('Responderam', String(d.respondidos.length), 'neste período')}</div>`;
  h += peH3('Para perguntar se ficou satisfeito') + (d.a_contatar.length ? d.a_contatar.map((x,i)=> peLinha(x, x.telefone && x.aceita_contato!==false ? `<button class="btn btn-primary" data-zap="${i}">WhatsApp</button>` : '<span class="meta">Sem como contatar</span>')).join('') : '<p class="sub">Nenhum exame esperando contato.</p>');
  h += peH3('Perguntados, esperando resposta') + (d.aguardando.length ? d.aguardando.map((x,i)=> peLinha(x, `<button class="btn btn-ghost" data-resp="${i}">Registrar resposta</button><button class="btn btn-outline" data-zap2="${i}">Perguntar de novo</button>`)).join('') : '<p class="sub">Ninguém esperando resposta.</p>');
  h += peH3('Já responderam') + (d.respondidos.length ? d.respondidos.map(x=> peLinha(x, '')).join('') : '<p class="sub">Ainda sem respostas neste período.</p>');
  corpo.innerHTML = h;
  document.getElementById('peDias').onchange = e=>{ peDias = +e.target.value; recarregar(); };
  const perguntar = async x=>{ abrirWhatsapp(x.telefone, peMensagem(x)); try{ await api('/posexame/enviado', { method:'POST', body:{ agendamento_id:x.agendamento_id } }); recarregar(); }catch(e){ erroApi(e); } };
  corpo.querySelectorAll('[data-zap]').forEach(b=> b.onclick = ()=> perguntar(d.a_contatar[+b.dataset.zap]));
  corpo.querySelectorAll('[data-zap2]').forEach(b=> b.onclick = ()=> { const x = d.aguardando[+b.dataset.zap2]; if(!x.telefone){ toast('Sem telefone.'); return; } abrirWhatsapp(x.telefone, peMensagem(x)); });
  corpo.querySelectorAll('[data-resp]').forEach(b=> b.onclick = ()=> peRegistrar(d.aguardando[+b.dataset.resp], recarregar));
}
function peRegistrar(x, depois){
  openModal(`<h2>Como foi a resposta?</h2><p class="sub">${esc(x.nome_completo)} · exame de ${peQuando(x.data_hora)}</p>
    <label>Resposta do paciente</label>
    <select id="peRes">${['satisfeito','regular','insatisfeito','sem_resposta'].map(k=>`<option value="${k}">${NOME_PE[k]}</option>`).join('')}</select>
    <label>O que ele disse (opcional)</label><textarea id="peObs" rows="3" maxlength="1000" placeholder="Ex.: demorou para ser atendido; achou o exame rápido demais"></textarea>
    <div class="btn-row" style="margin-top:12px;"><button class="btn btn-primary" id="peSalvar">Salvar</button><button class="btn btn-ghost" id="peCancelar">Cancelar</button></div>`);
  document.getElementById('peCancelar').onclick = closeModal;
  document.getElementById('peSalvar').onclick = async ()=>{
    try{ await api('/posexame/resultado', { method:'POST', body:{ agendamento_id:x.agendamento_id, resultado:document.getElementById('peRes').value, observacao:document.getElementById('peObs').value } }); closeModal(); toast('Resposta registrada.'); depois(); }catch(e){ erroApi(e); }
  };
}
async function peAcompanhar(corpo, recarregar){
  const l = await api('/posexame/acompanhar');
  corpo.innerHTML = `<p class="sub">Pacientes que ficaram regular ou insatisfeitos. Fale com eles e marque como resolvido.</p>` +
    (l.length ? l.map((x,i)=> peLinha(x, `${x.telefone?`<button class="btn btn-outline" data-zap="${i}">WhatsApp</button>`:''}<button class="btn btn-primary" data-res="${i}">Resolver</button>`)).join('') : '<p class="sub">Ninguém em acompanhamento. Tudo resolvido.</p>');
  corpo.querySelectorAll('[data-zap]').forEach(b=> b.onclick = ()=>{ const x = l[+b.dataset.zap]; abrirWhatsapp(x.telefone, `Olá, ${primeiroNome(x.nome_completo)}! Aqui é da ${peNome()}. Soubemos que seu exame de vista não foi como você esperava e queremos ajudar. Podemos conversar?`); });
  corpo.querySelectorAll('[data-res]').forEach(b=> b.onclick = ()=>{
    const x = l[+b.dataset.res];
    openModal(`<h2>Resolver</h2><p class="sub">${esc(x.nome_completo)}</p><label>O que foi feito (opcional)</label><textarea id="peReso" rows="3" maxlength="1000" placeholder="Ex.: liguei, pedi desculpas e remarquei o exame"></textarea>
      <div class="btn-row" style="margin-top:12px;"><button class="btn btn-primary" id="peOk">Marcar como resolvido</button><button class="btn btn-ghost" id="peNao">Cancelar</button></div>`);
    document.getElementById('peNao').onclick = closeModal;
    document.getElementById('peOk').onclick = async ()=>{ try{ await api(`/posexame/${x.agendamento_id}/resolver`, { method:'PATCH', body:{ resolucao:document.getElementById('peReso').value } }); closeModal(); toast('Marcado como resolvido.'); recarregar(); }catch(e){ erroApi(e); } };
  });
}
async function peResultados(corpo){
  const d = await api('/posexame/resumo?dias=30');
  const resp = d.satisfeitos + d.regulares + d.insatisfeitos;
  const taxa = resp ? Math.round(d.satisfeitos/resp*100)+'%' : '—';
  const grade = 'display:grid;grid-template-columns:repeat(auto-fit,minmax(130px,1fr));gap:10px;margin:6px 0;';
  corpo.innerHTML = `<p class="sub">Últimos 30 dias.</p><div style="${grade}">
    ${cartaoNumero('Exames feitos', String(d.exames), '')}${cartaoNumero('Contatados', String(d.contatados), '')}${cartaoNumero('Satisfeitos', taxa, `${d.satisfeitos} de ${resp} que responderam`)}
    ${cartaoNumero('Regulares', String(d.regulares), '')}${cartaoNumero('Insatisfeitos', String(d.insatisfeitos), '')}${cartaoNumero('Em acompanhamento', String(d.em_acompanhamento), 'ainda sem resolver')}</div>`;
}


function podeCidMedico(){
  const prof = profissionalSelecionado();
  return !!prof && /^\s*CRM/i.test(prof.registro_conselho||'');
}
function podeCidAqui(){ return !!profissionalSelecionado(); } // médico usa qualquer CID, optometrista só o de motivo (Z)
function renderReceita(main){
  garantirTextosPadrao();
  const pacOpts = pacientes.map(p=>`<option value="${p.id}" ${receitaAtual.pacienteId===p.id?'selected':''}>${esc(p.nome_completo)}</option>`).join('');
  main.innerHTML = `
    <div class="card">
      <h2>Receita e atestado</h2>
      <p class="sub">Monte a receita óptica, gere atestado/declaração com CID e envie por WhatsApp ou imprima. Nos campos de grau, digite o valor ou toque pra ver sugestões.</p>
      <label class="req">Paciente</label>
      <select id="rPac"><option value="">Selecione...</option>${pacOpts}</select>
      <label>Profissional responsável <span style="font-weight:400;color:var(--ink-soft);">(carimbo e assinatura que saem na receita)</span></label>
      <select id="rProfissional"><option value="">Selecione...</option>${profissionais.map(p=>`<option value="${p.id}" ${receitaAtual.profissionalId===p.id?'selected':''}>${esc(p.nome)}</option>`).join('')}</select>
      ${!profissionais.length ? '<p class="fieldmsg bad">Nenhum profissional cadastrado ainda. Cadastre em Master &gt; Usuários.</p>' : ''}
      ${(()=>{ const pr = profissionalSelecionado(); return pr && !/^\s*CRM/i.test(pr.registro_conselho||'') && !pr.formacao ? '<p class="fieldmsg bad">Este profissional não tem a formação superior cadastrada. Sem ela a receita sai sem a prova do curso. Cadastre em Master &gt; Usuários &gt; Registro e formação.</p>' : ''; })()}
      <h3 style="margin-top:18px;font-size:15px;">Longe</h3>
      ${olhoBlock('longe','od','OD')}${olhoBlock('longe','oe','OE')}
      <h3 style="margin-top:18px;font-size:15px;">Perto
        ${receitaAtual.adicao ? (receitaAtual.pertoAuto
          ? '<span style="font-weight:400;color:var(--ink-soft);font-size:12px;">(calculado automático: longe + adição)</span>'
          : `<button type="button" class="link-discreto" id="btnRecalcularPerto" style="display:inline;width:auto;margin:0 0 0 6px;font-size:12px;">recalcular automático</button>`)
          : ''}
      </h3>
      ${olhoBlock('perto','od','OD')}${olhoBlock('perto','oe','OE')}
      <h3 style="margin-top:18px;font-size:15px;">Medidas complementares</h3>
      <div class="row2">
        <div><label>Acuidade OD</label><input type="text" id="rAvOd" value="${esc(receitaAtual.extras.avOd)}" placeholder="20/20"></div>
        <div><label>Acuidade OE</label><input type="text" id="rAvOe" value="${esc(receitaAtual.extras.avOe)}" placeholder="20/20"></div>
      </div>
      <div class="row3">
        <div><label>DNP OD (mm)</label><input type="text" inputmode="decimal" id="rDnpOd" value="${esc(receitaAtual.extras.dnpOd)}" placeholder="31"></div>
        <div><label>DNP OE (mm)</label><input type="text" inputmode="decimal" id="rDnpOe" value="${esc(receitaAtual.extras.dnpOe)}" placeholder="32"></div>
        <div><label>DP (mm)</label><input type="text" inputmode="decimal" id="rDp" value="${esc(receitaAtual.extras.dp)}" placeholder="63"></div>
      </div>
      <div class="sugestao-chip" style="display:block;margin:10px 0 0;">
        <b>Sai na receita impressa?</b> <span style="font-weight:400;color:var(--ink-soft);">Marcado: aparece na receita. Desmarcado: fica só no sistema.</span>
        <div class="check-grid" style="margin-top:6px;">
          <label class="check-item"><input type="checkbox" id="mostrarAv" ${receitaAtual.mostrar.av?'checked':''}> Acuidade</label>
          <label class="check-item"><input type="checkbox" id="mostrarDnp" ${receitaAtual.mostrar.dnp?'checked':''}> DP e DNP</label>
          <label class="check-item"><input type="checkbox" id="mostrarIdade" ${receitaAtual.mostrar.idade?'checked':''}> Idade</label>
        </div>
      </div>
      <label>Idade do paciente <span style="font-weight:400;color:var(--ink-soft);">(sugere a adição a partir dos 40 anos)</span></label>
      <input type="text" inputmode="numeric" id="rIdade" value="${receitaAtual.idade}" placeholder="Ex: 52" maxlength="3" style="max-width:120px;">
      <div id="sugestaoAdicaoBox"></div>
      <div class="combo-wrap"><label>Adição <span style="font-weight:400;color:var(--ink-soft);">(sempre positiva)</span></label>
      <input type="text" inputmode="decimal" id="rAdicao" value="${receitaAtual.adicao}" placeholder="+2.00" autocomplete="off"></div>
      <p class="fieldmsg" id="rAdicao_msg"></p>
      <label>Adição do OE <span style="font-weight:400;color:var(--ink-soft);">(só se for diferente da adição acima)</span></label>
      <input type="text" inputmode="decimal" id="rAdicaoOe" value="${esc(receitaAtual.adicaoOe||'')}" placeholder="Em branco = igual ao OD" autocomplete="off" style="max-width:220px;">
      <label>Tipo de lente</label><select id="rTipoLente">${TIPOS_LENTE.map(t=>`<option ${receitaAtual.tipoLente===t?'selected':''}>${t}</option>`).join('')}</select>
      ${distanciaBlocoHtml()}
      ${ehOcupacional(receitaAtual.tipoLente) ? ocupacionalBlocoHtml() : ''}
      <label>Tratamentos</label>
      <div class="check-grid">${TRATAMENTOS.map(t=>`<label class="check-item"><input type="checkbox" value="${t}" class="rTrat" ${receitaAtual.tratamentos.includes(t)?'checked':''}> ${t}</label>`).join('')}</div>
      <label class="check-item" style="margin-top:14px;"><input type="checkbox" id="rAdaptSai" ${receitaAtual.adaptacaoSai?'checked':''}> Colocar a orientação de adaptação na receita</label>
      <textarea id="rAdaptTexto" rows="4">${esc(receitaAtual.adaptacaoTexto)}</textarea>
      <p class="sub" style="margin:2px 0 0;font-size:12px;">Texto pronto pelo tipo de lente. Você pode editar. <button type="button" class="link-discreto" id="btnAdaptPadrao" style="display:inline;width:auto;font-size:12px;">voltar ao texto padrão</button></p>
      <button class="btn btn-ghost btn-block" style="margin-top:16px;" id="btnSalvarReceita">Salvar receita</button>
    </div>
    <div class="card">
      <h2>Atestado / Declaração</h2>
      <label>Buscar CID <span style="font-weight:400;color:var(--ink-soft);">(pelo número ou pelo nome)</span></label>
      <p class="sub" style="margin:0 0 6px;">${podeCidMedico() ? 'Médico: todos os CIDs da lista.' : 'Sem médico escolhido, só entram CIDs que dizem o motivo do atendimento (Z01.0 exame da visão, Z46.0 ajuste de óculos). CID de doença é diagnóstico e fica com o médico. Para ver todos, escolha um médico como profissional responsável.'}</p>
      <input type="text" id="cidSearch" placeholder="Ex.: H52.1 ou miopia" autocomplete="off">
      <div id="cidResults"></div>
      <div id="cidComuns" style="margin:6px 0;">${CID_COMUNS.map(c=>CID_LIST.find(x=>x.cid===c)).filter(c=>c && (podeCidMedico() || CID_MOTIVO.includes(c.cid))).map(c=>`<button type="button" class="btn btn-outline btn-sm" data-cid="${c.cid}" style="width:auto;margin:0 6px 6px 0;">${c.cid} ${esc(c.desc.split(' (')[0])}</button>`).join('')}</div>
      <div id="cidSelected">${receitaAtual.cid? cidChipHtml() : ''}</div>
      <div id="cidSaiBox">${receitaAtual.cid ? cidSaiHtml() : ''}</div>
      <label>Texto do atestado</label>
      <textarea id="rAtestado" rows="4">${esc(receitaAtual.atestadoTexto)}</textarea>
      <p class="sub" style="margin:2px 0 0;font-size:12px;">Texto já preenchido. Pode editar. <button type="button" class="link-discreto" id="btnAtestPadrao" style="display:inline;width:auto;font-size:12px;">voltar ao texto padrão</button></p>
      <label>Texto da declaração de comparecimento</label>
      <textarea id="rDeclaracao" rows="4">${esc(receitaAtual.declaracaoTexto)}</textarea>
      <p class="sub" style="margin:2px 0 0;font-size:12px;">Texto já preenchido. Pode editar. <button type="button" class="link-discreto" id="btnDeclPadrao" style="display:inline;width:auto;font-size:12px;">voltar ao texto padrão</button></p>
      <div class="btn-row">
        <button class="btn btn-amber" id="btnImprimirReceita">Imprimir receita</button>
        <button class="btn btn-amber" id="btnImprimirAtestado">Imprimir atestado</button>
        <button class="btn btn-amber" id="btnImprimirDeclaracao">Imprimir declaração</button>
        <button class="btn btn-wpp" id="btnWppReceita">Enviar receita (WhatsApp)</button>
        <button class="btn btn-wpp" id="btnWppAtestado">Enviar atestado (WhatsApp)</button>
      </div>
      <div id="pixBox" style="margin-top:18px;border-top:1px solid var(--line);padding-top:6px;"></div>
    </div>
  `;
  if(calcularPerto()) atualizarCamposPerto();
  pixMontar();

  document.getElementById('rPac').onchange = e=>{
    receitaAtual.pacienteId = e.target.value;
    const pac = pacientes.find(x=>x.id===e.target.value);
    const idade = pac ? idadeDe(pac.data_nascimento) : null;
    if(idade !== null){ receitaAtual.idade = String(idade); receitaAtual.adicaoSugeridaAceita = false; renderReceita(main); }
    else pixMontar();
  };
  [['rAvOd','avOd'],['rAvOe','avOe'],['rDnpOd','dnpOd'],['rDnpOe','dnpOe'],['rDp','dp']].forEach(([id,k])=>{
    document.getElementById(id).addEventListener('input', e=>{ receitaAtual.extras[k] = e.target.value.trim(); });
  });
  document.getElementById('rProfissional').onchange = e=>{ receitaAtual.profissionalId = e.target.value; if(receitaAtual.cid && !cidPermitido(receitaAtual.cid)) receitaAtual.cid = null; renderReceita(main); };

  function renderSugestaoAdicao(){
    const box = document.getElementById('sugestaoAdicaoBox');
    if(!box) return;
    const sugestao = adicaoSugeridaPorIdade(receitaAtual.idade);
    if(!sugestao || receitaAtual.adicaoSugeridaAceita){ box.innerHTML=''; return; }
    box.innerHTML = `<div class="sugestao-chip">
      Faixa de ${receitaAtual.idade} anos costuma usar ${sugestao} de adição
      <button type="button" id="btnAceitarSugestaoAdicao">Usar ${sugestao}</button>
      <button type="button" class="dispensar" id="btnDispensarSugestaoAdicao">Paciente tem acomodação melhor, ignorar</button>
    </div>`;
    document.getElementById('btnAceitarSugestaoAdicao').onclick = ()=>{
      document.getElementById('rAdicao').value = sugestao;
      receitaAtual.adicao = sugestao;
      receitaAtual.adicaoSugeridaAceita = true;
      if(calcularPerto()) atualizarCamposPerto();
      atualizarInfoDistancia();
      box.innerHTML = '';
    };
    document.getElementById('btnDispensarSugestaoAdicao').onclick = ()=>{
      receitaAtual.adicaoSugeridaAceita = true; // não insiste de novo pra essa idade já informada
      box.innerHTML = '';
    };
  }
  renderSugestaoAdicao();

  document.getElementById('rIdade').addEventListener('input', e=>{
    const digitos = e.target.value.replace(/\D/g,'').slice(0,3);
    e.target.value = digitos;
    receitaAtual.idade = digitos;
    receitaAtual.adicaoSugeridaAceita = false; // idade mudou, pode sugerir de novo
    renderSugestaoAdicao();
  });

  montarCombo('rAdicao', opcoesAdicao());
  document.getElementById('rAdicao').addEventListener('blur', e=>{
    const digitado = e.target.value.trim();
    let v = digitado.replace(',','.');
    if(v){ const n = parseFloat(v.replace('+','')); if(!isNaN(n)) v = '+'+Math.abs(n).toFixed(2); }
    e.target.value = v;
    avisarCorrecao('rAdicao', digitado, v);
    receitaAtual.adicao = v;
    if(receitaAtual.adicaoOe === v) receitaAtual.adicaoOe = '';
    if(calcularPerto()){ atualizarCamposPerto(); }
    atualizarInfoDistancia();
  });

  document.getElementById('rAdicaoOe').addEventListener('blur', e=>{
    let v = e.target.value.trim().replace(',','.');
    if(v){ const n = parseFloat(v.replace('+','')); v = isNaN(n) ? '' : '+'+Math.abs(n).toFixed(2); }
    e.target.value = v; receitaAtual.adicaoOe = (v && v!==receitaAtual.adicao) ? v : '';
    if(receitaAtual.adicao && receitaAtual.pertoAuto && calcularPerto()) atualizarCamposPerto();
  });
  document.getElementById('rTipoLente').onchange = e=>{
    receitaAtual.tipoLente = e.target.value;
    receitaAtual.pertoAuto = true; // ao trocar o tipo de lente, volta a calcular o perto sozinho
    receitaAtual.adaptacaoEditada = false;
    if(calcularPerto()) atualizarCamposPerto();
    renderReceita(main);
  };
  main.querySelectorAll('.rTrat').forEach(cb=> cb.onchange = ()=>{ receitaAtual.tratamentos = [...main.querySelectorAll('.rTrat:checked')].map(c=>c.value); });

  const btnRecalcular = document.getElementById('btnRecalcularPerto');
  if(btnRecalcular) btnRecalcular.onclick = ()=>{
    receitaAtual.pertoAuto = true;
    if(calcularPerto()) atualizarCamposPerto();
    renderReceita(main);
  };

  ['longe','perto'].forEach(dist=> ['od','oe'].forEach(olho=>{
    const elEsf = document.getElementById(`r_${dist}_${olho}_esf`);
    const elCil = document.getElementById(`r_${dist}_${olho}_cil`);
    const elEixo = document.getElementById(`r_${dist}_${olho}_eixo`);
    montarCombo(`r_${dist}_${olho}_esf`, opcoesEsf());
    montarCombo(`r_${dist}_${olho}_cil`, opcoesCil());
    montarCombo(`r_${dist}_${olho}_eixo`, opcoesEixo());

    if(elEsf) elEsf.addEventListener('blur', e=>{
      const digitado = e.target.value.trim();
      const v = normalizarEsf(digitado);
      e.target.value = v;
      avisarCorrecao(`r_${dist}_${olho}_esf`, digitado, v);
      receitaAtual[dist][olho].esf = v;
      if(dist==='longe' && calcularPerto()) atualizarCamposPerto();
      else if(dist==='perto' && receitaAtual.adicao && receitaAtual.pertoAuto){ receitaAtual.pertoAuto = false; renderReceita(main); }
    });
    if(elCil) elCil.addEventListener('blur', e=>{
      const digitado = e.target.value.trim();
      const v = normalizarCil(digitado);
      e.target.value = v;
      avisarCorrecao(`r_${dist}_${olho}_cil`, digitado, v);
      receitaAtual[dist][olho].cil = v;
      if(dist==='longe' && calcularPerto()) atualizarCamposPerto();
      else if(dist==='perto' && receitaAtual.adicao && receitaAtual.pertoAuto){ receitaAtual.pertoAuto = false; renderReceita(main); }
    });
    if(elEixo) elEixo.addEventListener('blur', e=>{
      const digitado = e.target.value.trim();
      const v = normalizarEixo(digitado);
      e.target.value = v;
      avisarCorrecao(`r_${dist}_${olho}_eixo`, digitado, v);
      receitaAtual[dist][olho].eixo = v;
      if(dist==='longe' && calcularPerto()) atualizarCamposPerto();
      else if(dist==='perto' && receitaAtual.adicao && receitaAtual.pertoAuto){ receitaAtual.pertoAuto = false; renderReceita(main); }
    });
  }));
  ligarCidSai();
  const cidBusca = document.getElementById('cidSearch');
  if(cidBusca) cidBusca.addEventListener('input', e=>{
    const res = document.getElementById('cidResults');
    const found = buscarCid(e.target.value).slice(0,8);
    if(!e.target.value.trim()){ res.innerHTML=''; return; }
    res.innerHTML = found.map(c=>`<div class="cid-result" onclick="selecionarCid('${c.cid}','${c.desc.replace(/'/g,"\\'")}')"><b>${c.cid}</b> — ${esc(c.desc)}</div>`).join('') || '<p class="sub">Nenhum CID encontrado.</p>';
  });
  document.getElementById('rAtestado').oninput = e=>{ receitaAtual.atestadoTexto = e.target.value; receitaAtual.atestadoEditado = true; };
  document.getElementById('rDeclaracao').oninput = e=>{ receitaAtual.declaracaoTexto = e.target.value; receitaAtual.declaracaoEditado = true; };
  document.getElementById('btnAtestPadrao').onclick = ()=>{ receitaAtual.atestadoEditado = false; renderReceita(main); };
  document.getElementById('btnDeclPadrao').onclick = ()=>{ receitaAtual.declaracaoEditado = false; renderReceita(main); };
  document.getElementById('rAdaptSai').onchange = e=> receitaAtual.adaptacaoSai = e.target.checked;
  document.getElementById('rAdaptTexto').oninput = e=>{ receitaAtual.adaptacaoTexto = e.target.value; receitaAtual.adaptacaoEditada = true; };
  document.getElementById('btnAdaptPadrao').onclick = ()=>{ receitaAtual.adaptacaoEditada = false; renderReceita(main); };
  [['mostrarAv','av'],['mostrarDnp','dnp'],['mostrarIdade','idade']].forEach(([id,k])=>{ document.getElementById(id).onchange = e=>{ receitaAtual.mostrar[k] = e.target.checked; }; });
  main.querySelectorAll('#distChips [data-cm]').forEach(b=> b.onclick = ()=>{
    receitaAtual.distPerto = b.dataset.cm;
    const v = adicaoParaDistancia(+b.dataset.cm);
    if(v>0){
      receitaAtual.adicao = fmtAdicao(v); receitaAtual.adicaoOe = ''; receitaAtual.pertoAuto = true; receitaAtual.adicaoSugeridaAceita = true;
      document.getElementById('rAdicao').value = receitaAtual.adicao; document.getElementById('rAdicaoOe').value = '';
      if(calcularPerto()) atualizarCamposPerto();
    } else toast('Nesta idade a acomodação cobre essa distância. Adição 0.');
    if(!receitaAtual.adaptacaoEditada){ receitaAtual.adaptacaoTexto = textoAdaptacaoPadrao(); const t = document.getElementById('rAdaptTexto'); if(t) t.value = receitaAtual.adaptacaoTexto; }
    atualizarInfoDistancia();
  });
  const mDist = document.getElementById('rModoDist'); if(mDist) mDist.onchange = e=>{ receitaAtual.modoDist = e.target.value; renderReceita(main); };
  const aOcup = document.getElementById('rAlcanceOcup'); if(aOcup) aOcup.onchange = e=>{ receitaAtual.alcanceOcup = e.target.value; renderReceita(main); };
  main.querySelectorAll('#cidComuns [data-cid]').forEach(b=> b.onclick = ()=>{ const c = CID_LIST.find(x=>x.cid===b.dataset.cid); if(c) selecionarCid(c.cid, c.desc); });
  document.getElementById('btnSalvarReceita').onclick = async ()=>{
    if(!receitaAtual.pacienteId){ toast('Selecione um paciente.'); return; }
    try{ await salvarReceitaAtual(); toast('Receita salva.'); }catch(e){ erroApi(e); }
  };
  const exigePaciente = ()=>{ if(!receitaAtual.pacienteId){ toast('Selecione o paciente primeiro.'); return false; } return true; };
  document.getElementById('btnImprimirReceita').onclick = async ()=>{ if(!exigePaciente()) return; await garantirCodigo(); imprimirDocumento(gerarHtmlReceita()); };
  document.getElementById('btnImprimirAtestado').onclick = async ()=>{
    if(!exigePaciente()) return;
    if(!receitaAtual.atestadoTexto.trim()){ toast('Escreva o texto do atestado.'); return; }
    await garantirCodigo(); imprimirDocumento(gerarHtmlAtestado());
  };
  document.getElementById('btnImprimirDeclaracao').onclick = async ()=>{
    if(!exigePaciente()) return;
    if(!receitaAtual.declaracaoTexto.trim()){ toast('Escreva o texto da declaração.'); return; }
    await garantirCodigo(); imprimirDocumento(gerarHtmlDeclaracao());
  };
  document.getElementById('btnWppReceita').onclick = async ()=>{ if(!exigePaciente()) return; await garantirCodigo(); enviarWhatsapp(gerarTextoReceita() + textoConferencia()); };
  document.getElementById('btnWppAtestado').onclick = async ()=>{ if(!exigePaciente()) return; await garantirCodigo(); enviarWhatsapp(gerarTextoAtestado() + textoConferencia()); };
}
function selecionarCid(cid, desc){ receitaAtual.cid={cid,desc}; document.getElementById('cidSelected').innerHTML=cidChipHtml(); document.getElementById('cidSaiBox').innerHTML=cidSaiHtml(); ligarCidSai(); document.getElementById('cidResults').innerHTML=''; document.getElementById('cidSearch').value=''; }
function removerCid(){ receitaAtual.cid=null; receitaAtual.cidNoAtestado=false; document.getElementById('cidSelected').innerHTML=''; document.getElementById('cidSaiBox').innerHTML=''; }
function cidSaiHtml(){
  const sai = !!receitaAtual.cidNoAtestado;
  return `<div class="sugestao-chip" style="display:block;margin:6px 0;"><b>O CID sai no atestado?</b>
    <div style="margin-top:6px;"><button type="button" class="btn btn-sm ${sai?'btn-primary':'btn-outline'}" data-cidsai="1" style="width:auto;margin-right:6px;">Sim, imprimir o CID</button><button type="button" class="btn btn-sm ${!sai?'btn-primary':'btn-outline'}" data-cidsai="0" style="width:auto;">Não, guardar só no sistema</button></div>
    <p class="sub" style="margin:6px 0 0;font-size:12px;">O CID é dado de saúde. Só coloque no atestado com a autorização do paciente.</p></div>`;
}
function ligarCidSai(){
  document.querySelectorAll('#cidSaiBox [data-cidsai]').forEach(b=> b.onclick = ()=>{ receitaAtual.cidNoAtestado = b.dataset.cidsai==='1'; document.getElementById('cidSaiBox').innerHTML = cidSaiHtml(); ligarCidSai(); });
}
function cidChipHtml(){ return `<div class="cid-chip">${receitaAtual.cid.cid} — ${receitaAtual.cid.desc} <button onclick="removerCid()">×</button></div>`; }
/* texto da formação do profissional, como sai impresso: curso, tipo e portaria do MEC */
function textoConferencia(){ return receitaAtual.codigo && receitaAtual.sigSalva === assinaturaReceita() ? `\n\nConferir este documento: ${urlConferencia()}` : ''; }
function formacaoTexto(prof){
  if(!prof || !prof.formacao || /^\s*CRM/i.test(prof.registro_conselho||'')) return '';
  const tipo = prof.formacao_tipo==='bacharelado' ? ' (Bacharelado)' : prof.formacao_tipo==='tecnologo' ? ' (Tecnológico)' : '';
  return prof.formacao + tipo + (prof.formacao_portaria ? ' · Reconhecimento do MEC: ' + prof.formacao_portaria : '');
}
/* QR Code de conferência: o documento só leva QR depois de salvo, e salva de novo se algo mudou */
function assinaturaReceita(){
  const r = receitaAtual;
  return JSON.stringify([r.pacienteId, r.profissionalId, r.idade, r.longe, r.perto, r.extras, r.mostrar, r.distPerto, r.alcanceOcup, r.adaptacaoSai, r.adaptacaoTexto, r.cidNoAtestado, r.adicao, r.adicaoOe, r.tipoLente, r.tratamentos, r.cid&&r.cid.cid, r.atestadoTexto, r.declaracaoTexto]);
}
async function salvarReceitaAtual(){
  const r = receitaAtual;
  const resp = await api('/receitas', { method:'POST', body:{
    paciente_id: r.pacienteId, profissional_id: r.profissionalId || null, idade_paciente: r.idade || null,
    longe: { ...r.longe, extras: { ...r.extras, mostrar: r.mostrar, distPerto: r.distPerto || undefined, alcanceOcup: ehOcupacional(r.tipoLente) ? r.alcanceOcup : undefined, cidNoAtestado: !!r.cidNoAtestado, adaptacaoSai: r.adaptacaoSai } }, perto: { ...r.perto, adicaoOe: r.adicaoOe || undefined }, adicao: r.adicao,
    tipo_lente: r.tipoLente, tratamentos: r.tratamentos,
    cid_codigo: r.cid?.cid||null, cid_descricao: r.cid?.desc||null,
    atestado_texto: r.atestadoTexto, declaracao_texto: r.declaracaoTexto
  }});
  r.codigo = resp && resp.codigo_verificacao || null; r.sigSalva = assinaturaReceita();
  return resp;
}
async function garantirCodigo(){
  if(receitaAtual.sigSalva === assinaturaReceita() && receitaAtual.codigo) return receitaAtual.codigo;
  try{ await salvarReceitaAtual(); }catch(e){ receitaAtual.codigo = null; toast('Não consegui salvar para gerar o QR Code. O documento sai sem ele.'); }
  return receitaAtual.codigo;
}
function urlConferencia(){ return (API_BASE||location.origin) + '/verificar.html?c=' + encodeURIComponent(receitaAtual.codigo||''); }
function qrVerificacaoHtml(){
  if(!receitaAtual.codigo || receitaAtual.sigSalva !== assinaturaReceita()) return '';
  let img = ''; try{ const qr = qrcode(0,'M'); qr.addData(urlConferencia()); qr.make(); img = qr.createImgTag(3,0); }catch(e){ return ''; }
  return `<div style="display:flex;align-items:center;gap:10px;margin-top:14px;font-size:10.5px;color:#444;"><div style="width:84px;height:84px;flex:none;">${img.replace('<img','<img style="width:84px;height:84px;"')}</div><div>Para conferir se este documento é verdadeiro, aponte a câmera do celular para o QR Code ou acesse<br><b>${esc(urlConferencia().replace(/^https?:\/\//,'').replace(/\?c=.*/,''))}</b> e digite o código <b>${esc(receitaAtual.codigo)}</b>.</div></div>`;
}
function profissionalSelecionado(){ return profissionais.find(p=>p.id===receitaAtual.profissionalId) || null; }
/* ===== Documentos impressos (receita, atestado, declaração) =====
   Cada documento abre num quadro invisível com página própria em A4, sem depender
   da tela do sistema. Assim a impressão sai igual em qualquer navegador. */
function esc(v){ return String(v==null?'':v).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'); }
function dataExtenso(d){ return (d||new Date()).toLocaleDateString('pt-BR',{day:'numeric',month:'long',year:'numeric'}); }
function idadeDe(iso){
  if(!iso) return null;
  const [y,m,d] = iso.slice(0,10).split('-').map(Number); const h = new Date();
  let n = h.getFullYear() - y;
  if(h.getMonth()+1 < m || (h.getMonth()+1 === m && h.getDate() < d)) n--;
  return n >= 0 && n < 130 ? n : null;
}
function pacienteDaReceita(){ return pacientes.find(p=>p.id===receitaAtual.pacienteId) || null; }

const FOLHAS = { A4:[210,297], A5:[148,210], Letter:[216,279] };
function configImpressao(){
  const c = clinicaAtual?.config_impressao || {};
  return { papel: FOLHAS[c.papel]?c.papel:'A4', orientacao: c.orientacao==='landscape'?'landscape':'portrait', cor: c.cor==='pb'?'pb':'colorido', margem_mm: c.margem_mm||14, rodape: c.rodape||'' };
}
function medidasFolha(){
  const c = configImpressao(); let [l,a] = FOLHAS[c.papel]; if(c.orientacao==='landscape') [l,a] = [a,l]; return { l, a };
}
function cssImpressao(){
  const c = configImpressao();
  let css = CSS_IMPRESSAO.replace('@page{size:A4;margin:14mm 16mm;}', `@page{size:${c.papel} ${c.orientacao};margin:${c.margem_mm}mm ${c.margem_mm+2}mm;}`);
  if(c.papel==='A5') css += 'body{zoom:.78;}';
  if(c.cor==='pb') css += `*{color:#000 !important;} table.grau th,table.lista th{background:#fff !important;} table.grau tr.sec td{background:#fff !important;border-top:2px solid #000;border-bottom:2px solid #000;} .cab{border-bottom-color:#000 !important;} h1{color:#000 !important;}`;
  return css;
}
const CSS_IMPRESSAO = `
  @page{size:A4;margin:14mm 16mm;}
  *{box-sizing:border-box;}
  body{font-family:Georgia,'Times New Roman',serif;color:#1b1b1b;font-size:12.5pt;line-height:1.45;margin:0;}
  .cab{display:flex;align-items:center;gap:16px;padding-bottom:10px;border-bottom:2.5px solid #0f4c4a;}
  .cab img{max-height:64px;max-width:150px;object-fit:contain;}
  .cab .dados{flex:1;}
  .cab .nome{font-size:17pt;font-weight:bold;color:#0f4c4a;letter-spacing:.3px;}
  .cab .linha{font-size:9.5pt;color:#444;font-family:Arial,sans-serif;}
  .filete{height:1px;background:#bbb;margin:3px 0 0;}
  h1{font-family:Arial,sans-serif;text-align:center;font-size:15pt;letter-spacing:4px;text-transform:uppercase;margin:20px 0 14px;color:#0f4c4a;}
  .paciente{border:1px solid #999;border-radius:4px;padding:8px 12px;font-family:Arial,sans-serif;font-size:10.5pt;display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap;}
  .paciente b{font-size:11.5pt;}
  table.grau{width:100%;border-collapse:collapse;margin-top:16px;font-family:Arial,sans-serif;font-size:11pt;}
  table.grau th,table.grau td{border:1px solid #777;padding:7px 8px;text-align:center;}
  table.grau th{background:#e8f0ef;font-weight:bold;}
  table.grau td.olho{text-align:left;font-weight:bold;width:34%;}
  table.grau tr.sec td{background:#0f4c4a;color:#fff;font-weight:bold;letter-spacing:2px;text-align:left;}
  .info{margin-top:14px;font-family:Arial,sans-serif;font-size:11pt;}
  .info div{padding:5px 0;border-bottom:1px dotted #aaa;}
  .info b{display:inline-block;min-width:130px;}
  .texto{font-size:13pt;text-align:justify;margin:6px 0 0;white-space:pre-wrap;line-height:1.7;}
  .cid{margin-top:14px;font-family:Arial,sans-serif;font-size:11pt;}
  .rodape{margin-top:46px;text-align:center;}
  .local-data{text-align:right;font-size:11.5pt;margin-bottom:34px;}
  .assin{display:inline-block;min-width:260px;text-align:center;}
  .assin img{max-height:62px;display:block;margin:0 auto 2px;}
  .assin .traco{border-top:1.5px solid #222;padding-top:5px;font-family:Arial,sans-serif;font-size:10.5pt;}
  .assin .traco b{font-size:11.5pt;}
  table.lista{width:100%;border-collapse:collapse;margin-top:14px;font-family:Arial,sans-serif;font-size:10.5pt;}
  table.lista th,table.lista td{border-bottom:1px solid #bbb;padding:6px 6px;text-align:left;}
  table.lista th{background:#e8f0ef;}
  .aviso{margin-top:22px;font-family:Arial,sans-serif;font-size:8.5pt;color:#666;text-align:center;border-top:1px solid #ccc;padding-top:6px;}
`;

function cabecalhoDocHtml(){
  const c = clinicaAtual || {};
  const logo = c.logo_url ? `<img src="${esc(c.logo_url)}" alt="">` : '';
  let un = minhaUnidade();
  try{ if(!un && typeof pacienteDaReceita==='function'){ const pp = pacienteDaReceita(); if(pp && pp.unidade_id) un = unidades.find(u=>u.id===pp.unidade_id) || null; } }catch(e){}
  const linhas = [un ? 'Atendimento em '+un.nome+(un.local?' · '+un.local:'') : c.endereco, c.telefone ? 'Telefone: '+c.telefone : '', c.cnpj ? 'CNPJ: '+c.cnpj : ''].filter(Boolean).map(l=>`<div class="linha">${esc(l)}</div>`).join('');
  return `<div class="cab">${logo}<div class="dados"><div class="nome">${esc(c.nome_fantasia||'')}</div>${linhas}</div></div>`;
}
function pacienteDocHtml(extra, semIdade){
  const p = pacienteDaReceita();
  const idade = (receitaAtual.idade && !semIdade) ? ` · ${esc(receitaAtual.idade)} anos` : '';
  return `<div class="paciente"><div>Paciente<br><b>${esc(p?p.nome_completo:'')}</b>${idade}</div><div style="text-align:right;">Data<br><b>${fmtData(hojeISO())}</b></div></div>${extra||''}`;
}
function assinaturaDocHtml(){
  const prof = profissionalSelecionado();
  if(!prof) return `<div class="assin"><div style="height:56px;"></div><div class="traco">Assinatura e carimbo do profissional</div></div>`;
  const img = prof.assinatura_url ? `<img src="${esc(prof.assinatura_url)}" alt="">` : '<div style="height:56px;"></div>';
  const carimbo = prof.carimbo_texto ? esc(prof.carimbo_texto).replace(/\n/g,'<br>') : `<b>${esc(prof.nome)}</b>`;
  return `<div class="assin">${img}<div class="traco">${carimbo}${prof.registro_conselho ? `<br>${esc(prof.registro_conselho)}`:''}${formacaoTexto(prof) ? `<br><span style="font-size:.85em;">${esc(formacaoTexto(prof))}</span>`:''}</div></div>`;
}
function localDataDocHtml(){
  const cidade = (minhaUnidade()?.nome) || '';
  return `<div class="local-data">${cidade ? esc(cidade)+', ' : ''}${dataExtenso()}</div>`;
}
function paginaDoc(titulo, corpo){
  return `<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><title>${esc(titulo)}</title><style>${cssImpressao()}</style></head><body>${cabecalhoDocHtml()}<h1>${esc(titulo)}</h1>${corpo}${configImpressao().rodape?`<div class="aviso">${esc(configImpressao().rodape)}</div>`:''}</body></html>`;
}
function celulaGrau(v, sufixo){ return v ? esc(v)+(sufixo||'') : '—'; }
function linhaGrau(rotulo, o){ return `<tr><td class="olho">${rotulo}</td><td>${celulaGrau(o.esf)}</td><td>${celulaGrau(o.cil)}</td><td>${celulaGrau(o.eixo,'°')}</td></tr>`; }

/* texto da adição: um valor só, ou OD e OE quando são diferentes */
function adicaoTexto(r){
  if(!r.adicao) return '—';
  return (r.adicaoOe && r.adicaoOe!==r.adicao) ? 'OD '+r.adicao+' · OE '+r.adicaoOe : r.adicao;
}
function blocoDistanciaTexto(r){
  if(ehSoPerto(r.tipoLente)) return 'Óculos só para perto (leitura e trabalho de perto)' + (r.distPerto ? ', distância de leitura ' + r.distPerto + ' cm' : '') + '. Não usar para dirigir.';
  if(ehOcupacional(r.tipoLente)) return 'Lente ocupacional: foco do perto até ' + r.alcanceOcup + ' m. Não usar para dirigir.';
  return '';
}
function gerarHtmlReceita(){
  const r = receitaAtual, m = r.mostrar || {av:true,dnp:true,idade:true};
  const soPerto = ehSoPerto(r.tipoLente);
  const tabela = `<table class="grau">
    <tr><th></th><th>Esférico</th><th>Cilíndrico</th><th>Eixo</th></tr>
    ${soPerto ? '' : `<tr class="sec"><td colspan="4">VISÃO DE LONGE</td></tr>
    ${linhaGrau('Olho direito (OD)', r.longe.od)}${linhaGrau('Olho esquerdo (OE)', r.longe.oe)}`}
    <tr class="sec"><td colspan="4">VISÃO DE PERTO${soPerto && r.distPerto ? ' · '+esc(r.distPerto)+' cm' : ''}</td></tr>
    ${linhaGrau('Olho direito (OD)', r.perto.od)}${linhaGrau('Olho esquerdo (OE)', r.perto.oe)}
  </table>`;
  const uso = blocoDistanciaTexto(r);
  const info = `<div class="info">
    ${(m.av && (r.extras.avOd||r.extras.avOe)) ? `<div><b>Acuidade visual:</b> OD ${esc(r.extras.avOd||'—')} · OE ${esc(r.extras.avOe||'—')}</div>` : ''}
    ${(m.dnp && (r.extras.dnpOd||r.extras.dnpOe||r.extras.dp)) ? `<div><b>Distância pupilar:</b> ${r.extras.dp ? 'DP '+esc(r.extras.dp)+' mm' : ''}${(r.extras.dnpOd||r.extras.dnpOe) ? ` · DNP OD ${esc(r.extras.dnpOd||'—')} · OE ${esc(r.extras.dnpOe||'—')} mm` : ''}</div>` : ''}
    <div><b>Adição:</b> ${esc(adicaoTexto(r))}</div>
    <div><b>Tipo de lente:</b> ${esc(r.tipoLente||'—')}</div>
    ${uso ? `<div><b>Uso:</b> ${esc(uso)}</div>` : ''}
    <div><b>Tratamentos:</b> ${esc(r.tratamentos.join(', ')||'—')}</div>
    ${(r.adaptacaoSai && r.adaptacaoTexto.trim()) ? `<div><b>Adaptação:</b> ${esc(r.adaptacaoTexto.trim())}</div>` : ''}
  </div>`;
  return paginaDoc('Receita de Óculos', `${pacienteDocHtml('', !m.idade)}${tabela}${info}<div class="rodape">${localDataDocHtml()}${assinaturaDocHtml()}</div>${qrVerificacaoHtml()}<div class="aviso">Este exame de refração não substitui a consulta com médico oftalmologista. Em caso de dor, perda de visão ou suspeita de doença nos olhos, procure um oftalmologista. Esta receita pertence ao paciente, que pode usá-la em qualquer ótica.</div>`);
}
function gerarHtmlAtestado(){
  const r = receitaAtual, p = pacienteDaReceita();
  const cid = (r.cid && r.cidNoAtestado) ? `<div class="cid"><b>CID-10:</b> ${esc(r.cid.cid)} — ${esc(r.cid.desc)}</div>` : '';
  return paginaDoc('Atestado', `${pacienteDocHtml()}<div style="margin-top:22px;"><p class="texto">${esc(r.atestadoTexto)}</p></div>${cid}<div class="rodape">${localDataDocHtml()}${assinaturaDocHtml()}</div>${qrVerificacaoHtml()}`);
}
function gerarHtmlDeclaracao(){
  return paginaDoc('Declaração de Comparecimento', `${pacienteDocHtml()}<div style="margin-top:22px;"><p class="texto">${esc(receitaAtual.declaracaoTexto)}</p></div><div class="rodape">${localDataDocHtml()}${assinaturaDocHtml()}</div>${qrVerificacaoHtml()}`);
}

/* mesma lógica das versões em texto, usadas no WhatsApp */
function textoCarimbo(){
  const prof = profissionalSelecionado();
  if(!prof) return '';
  return `\n\n${prof.carimbo_texto || prof.nome}${prof.registro_conselho? '\n'+prof.registro_conselho : ''}${formacaoTexto(prof) ? '\n'+formacaoTexto(prof) : ''}`;
}
function gerarTextoReceita(){
  const p = pacienteDaReceita(); const nome = p? p.nome_completo : '';
  const r = receitaAtual, m = r.mostrar || {av:true,dnp:true,idade:true};
  const f = o=>`Esf ${o.esf||'-'} | Cil ${o.cil||'-'} | Eixo ${o.eixo? o.eixo+'°':'-'}`;
  const soPerto = ehSoPerto(r.tipoLente), uso = blocoDistanciaTexto(r);
  const longe = soPerto ? '' : `*LONGE*\nOD: ${f(r.longe.od)}\nOE: ${f(r.longe.oe)}\n\n`;
  const idade = (m.idade && r.idade) ? ` (${r.idade} anos)` : '';
  const av = (m.av && (r.extras.avOd||r.extras.avOe)) ? 'Acuidade: OD '+(r.extras.avOd||'-')+' | OE '+(r.extras.avOe||'-')+'\n' : '';
  const dp = (m.dnp && (r.extras.dp||r.extras.dnpOd||r.extras.dnpOe)) ? 'DP: '+(r.extras.dp||'-')+' mm | DNP OD: '+(r.extras.dnpOd||'-')+' | OE: '+(r.extras.dnpOe||'-')+'\n' : '';
  const adapt = (r.adaptacaoSai && r.adaptacaoTexto.trim()) ? `\nAdaptação: ${r.adaptacaoTexto.trim()}` : '';
  return `*RECEITA DE ÓCULOS*\n${clinicaAtual?.nome_fantasia||''}\n\nPaciente: ${nome}${idade}\nData: ${fmtData(hojeISO())}\n\n${longe}*PERTO${soPerto && r.distPerto ? ' ('+r.distPerto+' cm)' : ''}*\nOD: ${f(r.perto.od)}\nOE: ${f(r.perto.oe)}\n\n${av}${dp}Adição: ${adicaoTexto(r)==='—'?'-':adicaoTexto(r)}\nTipo de lente: ${r.tipoLente}${uso ? '\nUso: '+uso : ''}\nTratamentos: ${r.tratamentos.join(', ')||'-'}${adapt}${textoCarimbo()}\n\n_Este exame de refração não substitui a consulta com médico oftalmologista. Em caso de dor, perda de visão ou suspeita de doença nos olhos, procure um oftalmologista. Esta receita pertence ao paciente, que pode usá-la em qualquer ótica._`;
}
function gerarTextoAtestado(){
  const p = pacienteDaReceita(); const nome = p? p.nome_completo : '';
  const cidTxt = (receitaAtual.cid && receitaAtual.cidNoAtestado)? `\nCID-10: ${receitaAtual.cid.cid} (${receitaAtual.cid.desc})` : '';
  return `*ATESTADO*\n${clinicaAtual?.nome_fantasia||''}\n\nPaciente: ${nome}\nData: ${fmtData(hojeISO())}\n\n${receitaAtual.atestadoTexto}${cidTxt}${textoCarimbo()}`;
}

/* Abre a impressão num quadro invisível, depois que as imagens (logo, assinatura) carregam. */
function imprimirDocumento(html){
  const f = document.createElement('iframe');
  f.setAttribute('aria-hidden','true');
  const fo = medidasFolha();
  f.style.cssText = `position:fixed;left:-9999px;top:0;width:${fo.l}mm;height:${fo.a}mm;border:0;`;
  document.body.appendChild(f);
  const d = f.contentWindow.document;
  d.open(); d.write(html); d.close();
  const imgs = [...d.images];
  const prontas = Promise.all(imgs.map(i=> i.complete ? null : new Promise(ok=>{ i.onload = i.onerror = ok; })));
  const limite = new Promise(ok=>setTimeout(ok, 2500));
  Promise.race([prontas, limite]).then(()=>{
    try{ f.contentWindow.focus(); f.contentWindow.print(); }
    catch(e){ toast('Não consegui abrir a impressão. Tente de novo.'); console.error(e); }
    setTimeout(()=>f.remove(), 60000);
  });
}
/* compatibilidade com o gabarito do prontuário, que ainda usa o nome antigo */
function imprimir(html){ imprimirDocumento(`<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><title>Documento</title><style>body{font-family:Arial,sans-serif;padding:14mm;}</style></head><body>${html}</body></html>`); }

function abrirWhatsapp(telefone, texto){
  let tel = (telefone||'').replace(/\D/g,'');
  if(tel.startsWith('55') && tel.length>=12) tel = tel.slice(2);
  if(tel.length < 10){ toast('Esse paciente está sem telefone com DDD. Edite o cadastro dele.'); return; }
  const url = `https://api.whatsapp.com/send?phone=55${tel}&text=${encodeURIComponent(texto)}`;
  const w = window.open(url, '_blank');
  if(!w) location.href = url; // navegador bloqueou a nova aba
}
function enviarWhatsapp(texto){ const p = pacienteDaReceita(); abrirWhatsapp(p ? p.telefone : '', texto); }


/* ========================= AGENDA DO EVENTO ========================= */
/* O administrador abre os dias e horários do evento (Master). O agendador só marca pacientes
   dentro desses horários e não enxerga mais nada do sistema. */
let agendaEstado = { unidadeId:'', dia:'' };
const STATUS_AGENDA = { agendado:'Agendado', confirmado:'Confirmado', realizado:'Atendido', faltou:'Não compareceu', cancelado:'Cancelado' };

/* v4.9.25 botão na Agenda para o Master cadastrar cidade sem precisar ir ao Master */
function podeCadastrarCidade(){ return usuarioAtual?.papel==='admin'; }
function abrirCadastroCidade(main){
  const lista = unidades.length ? unidades.map(u=>`<div class="list-item"><div><div class="name">${esc(u.nome)}</div>${u.local?`<div class="meta">${esc(u.local)}</div>`:''}</div></div>`).join('') : '<p class="sub">Nenhuma cidade cadastrada ainda.</p>';
  openModal(`<h2>Cadastro de cidades para exame de vista</h2>
    <p class="sub">Cidades já cadastradas:</p>
    <div style="max-height:180px;overflow:auto;margin-bottom:12px;">${lista}</div>
    <label>Nova cidade</label><input type="text" id="ccCidade" placeholder="Piracanjuba">
    <label>Local do exame <span style="font-weight:400;color:var(--ink-soft);">(opcional)</span></label><input type="text" id="ccLocal" placeholder="Endereço do exame">
    <div class="btn-row"><button class="btn btn-outline" type="button" onclick="closeModal()">Fechar</button><button class="btn btn-primary" type="button" id="ccSalvar">Cadastrar cidade</button></div>`);
  setTimeout(()=>{ const i = document.getElementById('ccCidade'); if(i) i.focus(); }, 50);
  document.getElementById('ccSalvar').onclick = async ()=>{
    const cidade = document.getElementById('ccCidade').value.trim();
    if(!cidade){ toast('Escreva o nome da cidade.'); return; }
    const igual = unidades.find(u=>String(u.cidade||u.nome||'').toLowerCase().includes(cidade.toLowerCase()));
    if(igual && !confirm(`Já existe "${igual.nome}". Cadastrar outra mesmo assim?`)) return;
    const bt = document.getElementById('ccSalvar'); bt.disabled = true;
    try{
      const nova = await api('/unidades', { method:'POST', body:{ nome:'Exame de vista', cidade, local: document.getElementById('ccLocal').value.trim() } });
      unidades.push(...normUnidades([nova]));
      if(usuarioAtual && Array.isArray(usuarioAtual.unidadeIds) && usuarioAtual.unidadeIds.length && !usuarioAtual.unidadeIds.includes(nova.id)){ usuarioAtual.unidadeIds.push(nova.id); try{ localStorage.setItem('agend_usuario', JSON.stringify(usuarioAtual)); }catch(e){} }
      closeModal();
      toast('Cidade cadastrada. Agora abra os dias do exame.');
      abaMasterAtual = 'Agenda'; switchView('master');
      setTimeout(()=>{ const s2 = document.getElementById('agmUn'); if(s2){ s2.value = nova.id; s2.scrollIntoView({behavior:'smooth',block:'center'}); } }, 300);
    }catch(e){ bt.disabled = false; erroApi(e); }
  };
}

async function renderAgendaEvento(main){
  const ehAdminOuProf = usuarioAtual?.papel !== 'atendente';
  const meusIds = minhasCidadesIds();
  const opcoesCidade = meusIds.length ? unidades.filter(u=>meusIds.includes(u.id)) : unidades;
  if(!agendaEstado.unidadeId || !opcoesCidade.some(u=>u.id===agendaEstado.unidadeId)) agendaEstado.unidadeId = opcoesCidade[0]?.id || '';
  const unidSel = opcoesCidade.length > 1
    ? `<label>Cidade do exame de vista</label><select id="agUn">${opcoesCidade.map(u=>`<option value="${u.id}" ${u.id===agendaEstado.unidadeId?'selected':''}>${esc(u.nome)}</option>`).join('')}</select>` : '';
  main.innerHTML = `<div class="card"><h2>Agenda de exame de vista</h2>
    <p class="sub" id="agTitulo"><strong>Cidade do exame de vista:</strong> ${esc((unidades.find(u=>u.id===agendaEstado.unidadeId)||{}).nome || 'não definida')}</p>${unidSel}
    ${podeCadastrarCidade() ? '<button class="btn btn-outline btn-block" id="agCadCidade" type="button" style="margin:10px 0 4px;">📍 Cadastro de cidades para exame de vista</button>' : ''}
    ${(usuarioAtual?.papel==='atendente' || usuarioAtual?.papel==='admin') ? '<a class="btn btn-ghost btn-block" href="/agendador/" style="text-align:center;text-decoration:none;margin:6px 0 4px;">📶 Marcar sem internet (agendador offline)</a><p class="sub" style="margin:0 0 6px;font-size:12px;">Abra uma vez com internet para baixar os horários. Depois funciona sem sinal.</p>' : ''}
    <div id="agCorpo"><p class="sub">Carregando...</p></div></div>`;
  const btCad = document.getElementById('agCadCidade');
  if(btCad) btCad.onclick = ()=> abrirCadastroCidade(main);
  const sel = document.getElementById('agUn');
  if(sel) sel.onchange = e=>{ agendaEstado.unidadeId = e.target.value; agendaEstado.dia = ''; renderAgendaEvento(main); };

  const corpo = document.getElementById('agCorpo');
  let slots = [];
  try{ slots = await api(`/agendas/horarios${agendaEstado.unidadeId ? '?unidade_id='+agendaEstado.unidadeId : ''}`); }
  catch(e){ corpo.innerHTML = `<p class="fieldmsg bad">${esc(e.message)}</p>`; return; }
  // o agendador só vê os dias de exame que ainda vão acontecer, na cidade dele
  if(!ehAdminOuProf){ const h0 = hojeISO(); slots = slots.filter(s=>s.data>=h0); }
  if(!slots.length){
    corpo.innerHTML = `<div class="empty"><div class="ic">📅</div>${ehAdminOuProf ? 'Nenhum horário aberto. Abra os dias do exame de vista em Master, no cartão "Agenda de exame de vista".' : 'O administrador ainda não abriu horários para este exame de vista.'}</div>`;
    return;
  }
  const dias = [...new Set(slots.map(s=>s.data))];
  const hoje = hojeISO();
  if(!dias.includes(agendaEstado.dia)) agendaEstado.dia = dias.find(d=>d>=hoje) || dias[0];
  const doDia = slots.filter(s=>s.data===agendaEstado.dia);
  const ocupados = doDia.filter(s=>s.agendamento).length;
  const confirmados = doDia.filter(s=>s.agendamento?.status==='confirmado').length;
  const abas = dias.map(d=>`<button class="btn ${d===agendaEstado.dia?'btn-primary':'btn-outline'} btn-sm" data-dia="${d}" style="margin:0 6px 6px 0;width:auto;">${['dom','seg','ter','qua','qui','sex','sáb'][new Date(d+'T12:00:00').getDay()]} ${fmtData(d).slice(0,5)}</button>`).join('');
  corpo.innerHTML = `<div style="margin:6px 0 10px;">${abas}</div>
    <p class="sub">${fmtData(agendaEstado.dia)} · ${doDia.length - ocupados} livre(s) · ${ocupados} marcado(s) · ${confirmados} confirmado(s) · ${Math.round(ocupados/doDia.length*100)}% de ocupação${doDia[0].local ? ' · '+esc(doDia[0].local) : ''}</p>
    <div class="check-grid" style="grid-template-columns:repeat(auto-fill,minmax(150px,1fr));">${doDia.map((s,i)=> s.agendamento
      ? `<button class="check-item" data-i="${i}" style="justify-content:flex-start;flex-direction:column;align-items:flex-start;cursor:pointer;background:var(--teal-100);"><b>${s.hora}</b><span style="font-size:12px;">${esc(s.agendamento.paciente_nome)}</span><span style="font-size:11px;color:var(--ink-soft);">${STATUS_AGENDA[s.agendamento.status]||s.agendamento.status}</span></button>`
      : `<button class="check-item" data-i="${i}" style="justify-content:flex-start;flex-direction:column;align-items:flex-start;cursor:pointer;"><b>${s.hora}</b><span style="font-size:12px;color:#116A4F;">Livre</span></button>`).join('')}</div>`;
  corpo.querySelectorAll('button[data-dia]').forEach(b=> b.onclick = ()=>{ agendaEstado.dia = b.dataset.dia; renderAgendaEvento(main); });
  corpo.querySelectorAll('button[data-i]').forEach(b=> b.onclick = ()=>{
    const s = doDia[+b.dataset.i];
    if(s.agendamento) abrirHorarioOcupado(s, main); else abrirMarcarHorario(s, main);
  });
}

function normNome(t){ return String(t||'').normalize('NFD').replace(/[̀-ͯ]/g,'').toLowerCase().replace(/\s+/g,' ').trim(); }
function soDigitos(t){ return String(t||'').replace(/\D/g,''); }

function mensagemConfirmacao(nome, slot){
  const primeiro = String(nome||'').trim().split(/\s+/)[0];
  const un = (unidades.find(u=>u.id===slot.unidade_id)||{}).nome;
  const local = slot.local || clinicaAtual?.local_exame_padrao || '';
  return `Olá, ${primeiro}! Seu exame de vista na ${clinicaAtual?.nome_fantasia||'clínica'} está marcado.${un?` Cidade: ${un}.`:''} Dia ${fmtData(slot.data)} às ${slot.hora}.${local?` Local: ${local}.`:''} Responda SIM para confirmar.`;
}

function abrirMarcarHorario(slot, main){
  openModal(`
    <h2>${fmtData(slot.data)} às ${slot.hora}</h2>
    <p class="sub">${esc(slot.tipo_nome)}${slot.local ? ' · '+esc(slot.local) : ''}</p>
    <div class="foto-atalhos">
      <button type="button" class="btn btn-outline" id="mhFotoDocBtn">📷 Fotografar documento</button>
      <button type="button" class="btn btn-outline" id="mhFotoRecBtn">📷 Fotografar receita</button>
      <input type="file" id="mhFotoDoc" accept="image/*" capture="environment" style="display:none">
      <input type="file" id="mhFotoRec" accept="image/*" capture="environment" style="display:none">
    </div>
    <p class="sub" id="mhFotoMsg">Com a foto do RG ou CNH o sistema preenche o nome. Confira antes de marcar.</p>
    <label>Já é paciente? Digite o nome ou o telefone</label>
    <input type="text" id="mhBusca" placeholder="Comece a digitar..." autocomplete="off">
    <div id="mhAchados"></div>
    <div id="mhEscolhido" style="display:none;" class="sugestao-chip"></div>
    <p class="sub" style="margin:10px 0 2px;" id="mhOuNovo">Se não aparecer, cadastre um novo:</p>
    <label>Nome completo</label><input type="text" id="mhNome" placeholder="Nome do paciente">
    <label>Telefone (WhatsApp)</label><input type="tel" inputmode="tel" id="mhTel" placeholder="(64) 99999-9999">
    <p class="fieldmsg bad" id="mhSemTel" style="display:none;">Sem telefone, este paciente não vai receber lembrete de WhatsApp.</p>
    ${oticaSelectHtml('mhOtica')}
    <label>Observações</label><textarea id="mhObs"></textarea>
    <div class="btn-row"><button class="btn btn-primary" id="mhSalvar">Marcar</button><button class="btn btn-outline" onclick="closeModal()">Cancelar</button></div>
    <p id="mhErr" style="color:#C1462F;font-size:12.5px;margin-top:8px;"></p>`);

  let escolhido = null;   // paciente já cadastrado
  let extras = {};        // dados lidos das fotos (cpf, nascimento, receita)
  const elTel = document.getElementById('mhTel'), elNome = document.getElementById('mhNome');
  elTel.addEventListener('input', e=>{ e.target.value = maskTelefone(e.target.value); avisoTel(); });
  elNome.addEventListener('input', avisoTel);
  function avisoTel(){
    const falta = !escolhido && elNome.value.trim() && soDigitos(elTel.value).length < 10;
    document.getElementById('mhSemTel').style.display = falta ? 'block' : 'none';
  }

  /* busca de paciente por nome ou telefone */
  const achados = document.getElementById('mhAchados'), chip = document.getElementById('mhEscolhido');
  function escolher(p){
    escolhido = p;
    achados.innerHTML = ''; document.getElementById('mhBusca').value = '';
    chip.style.display = 'block';
    chip.innerHTML = `Paciente: <b>${esc(p.nome_completo)}</b>${p.telefone?' · '+esc(p.telefone):''} <button type="button" class="dispensar" id="mhTrocar">trocar</button>`;
    document.getElementById('mhTrocar').onclick = ()=>{ escolhido = null; chip.style.display='none'; avisoTel(); };
    avisoTel();
  }
  document.getElementById('mhBusca').addEventListener('input', e=>{
    const q = normNome(e.target.value), qd = soDigitos(e.target.value);
    if(q.length < 2 && qd.length < 4){ achados.innerHTML = ''; return; }
    const lista = pacientes.filter(p=> normNome(p.nome_completo).includes(q) || (qd.length>=4 && soDigitos(p.telefone).includes(qd))).slice(0,6);
    achados.innerHTML = lista.length
      ? lista.map(p=>`<button type="button" class="btn btn-outline btn-block" data-pid="${p.id}" style="text-align:left;margin-top:6px;">${esc(p.nome_completo)}${p.telefone?'<br><span style="font-size:12px;color:var(--ink-soft);">'+esc(p.telefone)+'</span>':''}</button>`).join('')
      : '<p class="sub">Ninguém com esse nome. Cadastre abaixo.</p>';
    achados.querySelectorAll('button[data-pid]').forEach(b=> b.onclick = ()=> escolher(pacientes.find(p=>p.id===b.dataset.pid)));
  });

  /* fotos */
  const fMsg = document.getElementById('mhFotoMsg');
  function ligarFoto(btnId, inId, tratar){
    const btn = document.getElementById(btnId), inp = document.getElementById(inId);
    btn.onclick = ()=> inp.click();
    inp.onchange = async ()=>{
      const f = inp.files[0]; if(!f) return;
      const rot = btn.textContent; btn.disabled = true; btn.textContent = 'Lendo...';
      fMsg.style.color = ''; fMsg.textContent = 'Lendo a foto. Aguarde alguns segundos.';
      try{ await tratar(await reduzirImagem(f, 1280, 0.7)); }
      catch(e){ fMsg.style.color = '#C1462F'; fMsg.textContent = e.message || 'Não consegui ler a foto.'; }
      btn.disabled = false; btn.textContent = rot; inp.value = '';
    };
  }
  ligarFoto('mhFotoDocBtn','mhFotoDoc', async url=>{
    const d = await lerDocumentoPorFoto(url);
    if(d.cpf_ilegivel){ fMsg.style.color = '#C1462F'; fMsg.textContent = 'O CPF saiu com número errado. Tire a foto de novo.'; return; }
    const jaCadastrado = d.cpf ? pacientes.find(p=>soDigitos(p.cpf)===d.cpf) : null;
    if(jaCadastrado){ escolher(jaCadastrado); fMsg.style.color = '#2e9d5b'; fMsg.textContent = 'Esse paciente já está cadastrado. Selecionei ele.'; return; }
    if(d.nome_completo){ elNome.value = d.nome_completo; elNome.classList.add('campo-lido'); }
    if(d.cpf) extras.cpf = maskCpf(d.cpf);
    if(d.data_nascimento) extras.data_nascimento = d.data_nascimento;
    avisoTel();
    fMsg.style.color = d.nome_completo ? '#2e9d5b' : '#C1462F';
    fMsg.textContent = d.nome_completo ? 'Li o nome'+(d.cpf?' e o CPF':'')+'. Confira com o documento e digite o telefone.' : 'Não consegui ler o nome. Tire a foto de novo, reta e com boa luz, ou digite.';
  });
  ligarFoto('mhFotoRecBtn','mhFotoRec', async url=>{
    extras.foto_receita_url = url;
    let dados = null;
    try{ dados = (await lerPorIA('receita', url)).dados; }
    catch(e){ if(!/não está ligada/i.test(e.message||'')) throw e; }
    const t = dados ? textoReceita(dados) : '';
    extras.receita_status = t ? 'digitar' : 'foto';
    if(t) extras.receita_digitada = t;
    fMsg.style.color = t ? '#2e9d5b' : '#b26a00';
    fMsg.textContent = t ? 'Li o grau e guardei a foto na ficha. Quem for atender confere.' : 'A foto da receita ficou guardada na ficha do paciente.';
  });

  let pidCriado = null; // se o horário falhar depois de criar o paciente, a nova tentativa usa o mesmo paciente
  document.getElementById('mhSalvar').onclick = async (ev)=>{
    const btn = ev.currentTarget; if(btn.disabled) return;
    const err = document.getElementById('mhErr'); err.textContent = '';
    let pid = (escolhido && escolhido.id) || pidCriado;
    const nome = elNome.value.trim();
    const tel = elTel.value.trim();
    if(!pid){
      if(!nome){ err.textContent = 'Escolha um paciente ou digite o nome.'; return; }
      if(tel && ![10,11].includes(soDigitos(tel).length)){ err.textContent = 'Telefone incompleto. Use DDD + número.'; return; }
      // evita cadastro repetido
      const igual = pacientes.find(p=> (soDigitos(tel).length>=10 && soDigitos(p.telefone)===soDigitos(tel)) || normNome(p.nome_completo)===normNome(nome));
      if(igual && confirm(`Já existe "${igual.nome_completo}"${igual.telefone?' ('+igual.telefone+')':''}. Usar esse cadastro?`)){ escolher(igual); pid = igual.id; }
      else if(!tel && !confirm('Sem telefone, o paciente não recebe lembrete de WhatsApp. Marcar mesmo assim?')) return;
    }
    btn.disabled = true;
    try{
      if(!pid){
        const corpo = { nome_completo: nome, telefone: tel||null, agendado_por: usuarioAtual?.nome||'' };
        if(extras.cpf) corpo.cpf = extras.cpf;
        if(extras.data_nascimento) corpo.data_nascimento = extras.data_nascimento;
        if(extras.foto_receita_url){ corpo.foto_receita_url = extras.foto_receita_url; corpo.dados_extras = { receita_status: extras.receita_status, receita_digitada: extras.receita_digitada||'' }; }
        const novo = await api('/pacientes', { method:'POST', body: corpo });
        pacientes.push(novo); pid = novo.id; pidCriado = novo.id;
      }
      const ag = await api('/agendamentos', { method:'POST', body:{ paciente_id: pid, tipo_atendimento_id: slot.tipo_atendimento_id, unidade_id: slot.unidade_id, data_hora: slot.data_hora, local: slot.local || clinicaAtual?.local_exame_padrao || '', agendado_por: usuarioAtual?.nome||'', observacoes: document.getElementById('mhObs').value, otica_parceira_id: (document.getElementById('mhOtica')||{}).value || null } });
      const pac = pacientes.find(p=>p.id===pid) || {};
      mostrarMarcado(slot, pac, ag, main);
    }catch(e){ err.textContent = e.message; btn.disabled = false; }
  };
}

/* depois de marcar: oferece mandar a confirmação pelo WhatsApp na hora */
function mostrarMarcado(slot, pac, ag, main){
  const tel = soDigitos(pac.telefone);
  const auto = !!clinicaAtual?.whatsapp_auto;
  openModal(`
    <h2>Horário marcado</h2>
    <p class="sub"><b>${esc(pac.nome_completo||'')}</b><br>${fmtData(slot.data)} às ${slot.hora}</p>
    ${tel.length>=10 && !auto ? `<button class="btn btn-wpp btn-block" id="mmZap">Enviar confirmação pelo WhatsApp</button>` : ''}
    ${tel.length<10 ? '<p class="fieldmsg bad">Paciente sem telefone. Ele não vai receber lembrete.</p>' : ''}
    ${auto && tel.length>=10 ? '<p class="sub">O WhatsApp automático vai avisar o paciente.</p>' : ''}
    <div class="btn-row" style="margin-top:10px;"><button class="btn btn-primary" id="mmOk">Pronto</button></div>`);
  const fechar = ()=>{ closeModal(); renderAgendaEvento(main); };
  document.getElementById('mmOk').onclick = fechar;
  const z = document.getElementById('mmZap');
  if(z) z.onclick = async ()=>{
    abrirWhatsapp(pac.telefone, mensagemConfirmacao(pac.nome_completo, slot));
    if(ag && ag.id){ try{ await api(`/envios/${ag.id}/marcar`, { method:'POST', body:{ etapa:'confirmacao', enviado:true } }); }catch(e){} }
    toast('WhatsApp aberto. Toque em enviar lá.');
    z.disabled = true; z.textContent = 'Confirmação aberta';
  };
}

function abrirHorarioOcupado(slot, main){
  const a = slot.agendamento;
  const tel = soDigitos(a.telefone);
  openModal(`
    <h2>${slot.hora} · ${esc(a.paciente_nome)}</h2>
    <p class="sub">${fmtData(slot.data)} · ${esc(STATUS_AGENDA[a.status]||a.status)}</p>
    ${tel.length>=10 ? `<p style="margin:4px 0 10px;"><b>${esc(a.telefone)}</b></p>
    <div class="btn-row"><button class="btn btn-wpp" id="hoZap">Chamar no WhatsApp</button><a class="btn btn-outline" href="tel:+55${tel}" style="text-align:center;text-decoration:none;">Ligar</a></div>` : '<p class="fieldmsg bad">Sem telefone cadastrado.</p>'}
    <label style="margin-top:12px;">Situação</label>
    <select id="hoStatus">${Object.entries(STATUS_AGENDA).map(([k,v])=>`<option value="${k}" ${k===a.status?'selected':''}>${v}</option>`).join('')}</select>
    <div class="btn-row"><button class="btn btn-primary" id="hoSalvar">Salvar</button><button class="btn btn-outline" onclick="closeModal()">Fechar</button></div>
    <button class="btn btn-danger btn-block" id="hoCancelar" style="margin-top:14px;">Cancelar este horário</button>
    <p class="sub" style="margin-top:6px;">Cancelar libera o horário para outro paciente.</p>`);
  const zap = document.getElementById('hoZap');
  if(zap) zap.onclick = ()=> abrirWhatsapp(a.telefone, `Olá, ${String(a.paciente_nome||'').split(' ')[0]}! Aqui é da ${clinicaAtual?.nome_fantasia||'clínica'}, sobre o seu exame de vista do dia ${fmtData(slot.data)} às ${slot.hora}.`);
  async function mudar(status, msg){
    try{ await api(`/agendamentos/${a.id}/status`, { method:'PATCH', body:{ status } }); closeModal(); toast(msg); renderAgendaEvento(main); if(status==='cancelado') setTimeout(avisarListaEspera, 2600); }
    catch(e){ erroApi(e); }
  }
  document.getElementById('hoSalvar').onclick = ()=> mudar(document.getElementById('hoStatus').value, 'Situação atualizada.');
  document.getElementById('hoCancelar').onclick = ()=>{ if(confirm('Cancelar o horário de '+a.paciente_nome+'?')) mudar('cancelado', 'Horário cancelado e liberado.'); };
}

/* opções de duração e de intervalo (o valor vazio usa o do tipo de atendimento) */
const DURACOES_EXAME = [10,15,20,25,30,40,45,60];
const INTERVALOS_EXAME = [0,5,10,15];
function opcoesDuracao(sel){
  const v = (sel===null||sel===undefined) ? '' : String(sel);
  const lista = DURACOES_EXAME.slice(); if(v!=='' && !lista.includes(+v)) lista.push(+v);
  return '<option value="">Padrão do tipo de atendimento</option>' + lista.sort((a,b)=>a-b).map(n=>`<option value="${n}" ${String(n)===v?'selected':''}>${n} minutos</option>`).join('');
}
function opcoesIntervalo(sel){
  const v = (sel===null||sel===undefined) ? '' : String(sel);
  const lista = INTERVALOS_EXAME.slice(); if(v!=='' && !lista.includes(+v)) lista.push(+v);
  return '<option value="">Padrão do tipo de atendimento</option>' + lista.sort((a,b)=>a-b).map(n=>`<option value="${n}" ${String(n)===v?'selected':''}>${n===0?'Sem intervalo':n+' minutos'}</option>`).join('');
}
/* conta quantos horários uma agenda gera (mesma regra do servidor) */
function contarHorariosAgenda(ini, fim, dur, buf, alI, alF){
  if(!ini || !fim || !dur) return 0;
  const m = (h)=>{ const [a,b]=h.split(':').map(Number); return a*60+b; };
  const passo = dur + buf, a = m(ini), z = m(fim), temAl = alI && alF, i0 = temAl ? m(alI) : 0, f0 = temAl ? m(alF) : 0;
  let n = 0;
  for(let t=a; t+dur<=z; t+=passo){
    if(temAl && t < f0 && t+dur > i0){ t = Math.max(t, f0-passo); continue; }
    n++;
  }
  return n;
}
function textoPrevAgenda(ini, fim, durSel, bufSel, alI, alF, tipoId){
  const tp = tiposAtendimento.find(t=>t.id===tipoId) || tiposAtendimento[0];
  const dur = durSel!=='' ? +durSel : (tp ? tp.duracao_min : 0);
  const buf = bufSel!=='' ? +bufSel : (tp ? (tp.buffer_min||0) : 0);
  const n = contarHorariosAgenda(ini, fim, dur, buf, alI, alF);
  return n ? `Isso gera ${n} horários (${dur} min cada${buf?' + '+buf+' min de intervalo':', sem intervalo'}).` : 'Esses horários não geram nenhum atendimento. Confira a hora e a duração.';
}

/* cartão do Master: o administrador abre os dias e horários do evento */
function feriadosLocaisCardHtml(){
  return `<div class="card"><h2>Feriados da cidade</h2>
    <p class="sub">Cadastre o aniversário da cidade, folgas e eventos locais. Eles aparecem no calendário. Os feriados nacionais já vêm prontos.</p>
    <div id="flLista"></div>
    <div class="row2"><div><label>Data</label><input type="date" id="flData"></div><div><label>Nome</label><input type="text" id="flNome" placeholder="Aniversário da cidade"></div></div>
    <label>Cidade</label><select id="flUnidade"><option value="">Todas as cidades</option>${unidades.map(u=>`<option value="${u.id}">${esc(u.nome)}</option>`).join('')}</select>
    <button class="btn btn-ghost btn-block" id="flAdd" style="margin-top:10px;">+ Adicionar feriado</button></div>`;
}
function ligarFeriadosLocais(){
  const lista = document.getElementById('flLista'); if(!lista) return;
  const desenhar = ()=>{
    lista.innerHTML = feriadosLocais.length ? feriadosLocais.map(f=>`<div class="list-item"><div><div class="name">${esc(fmtData(f.data))} · ${esc(f.nome)}</div><div class="meta">${esc(f.cidade||'Todas as cidades')}</div></div><button class="btn btn-danger btn-sm" data-fl="${f.id}">Remover</button></div>`).join('') : '<p class="sub">Nenhum feriado local cadastrado.</p>';
    lista.querySelectorAll('[data-fl]').forEach(b=> b.onclick = async ()=>{ try{ await api('/feriados-locais/'+b.dataset.fl, { method:'DELETE' }); feriadosLocais = feriadosLocais.filter(x=>x.id!==b.dataset.fl); desenhar(); }catch(e){ erroApi(e); } });
  };
  desenhar();
  document.getElementById('flAdd').onclick = async ()=>{
    try{
      await api('/feriados-locais', { method:'POST', body:{ data: document.getElementById('flData').value, nome: document.getElementById('flNome').value, unidade_id: document.getElementById('flUnidade').value || null } });
      feriadosLocais = await api('/feriados-locais'); document.getElementById('flNome').value = ''; desenhar(); toast('Feriado adicionado.');
    }catch(e){ erroApi(e); }
  };
}
function agendaMasterCardHtml(){
  return `<div class="card"><h2>Agenda de exame de vista</h2>
    <p class="sub">Abra aqui os dias e horários. O agendador só consegue marcar pacientes dentro deles.</p>
    <div id="listaAgendas"><p class="sub">Carregando...</p></div>
    <div style="border:1px dashed var(--line);border-radius:12px;padding:12px;margin-top:14px;">
      <strong>Exame em outra cidade?</strong>
      <p class="sub" style="margin:4px 0 0;">Cadastre a cidade aqui e abra os dias logo abaixo.</p>
      <label>Cidade</label><input type="text" id="agnCidade" placeholder="Piracanjuba">
      <label>Local do exame <span style="font-weight:400;color:var(--ink-soft);">(opcional)</span></label><input type="text" id="agnLocal" placeholder="Endereço do exame">
      <button class="btn btn-outline btn-block" id="agnCriar" style="margin-top:10px;">+ Cadastrar cidade</button>
    </div>
    ${unidades.length ? `
    <label style="margin-top:12px;">Cidade do exame de vista</label>
    <select id="agmUn">${unidades.map(u=>`<option value="${u.id}">${esc(u.nome)}</option>`).join('')}</select>
    <div class="row2"><div><label>Primeiro dia</label><input type="date" id="agmData"></div><div><label>Último dia <span style="font-weight:400;color:var(--ink-soft);">(opcional)</span></label><input type="date" id="agmDataFim"></div></div>
    <div class="row2"><div><label>Das</label><input type="time" id="agmIni" value="08:00"></div><div><label>Até</label><input type="time" id="agmFim" value="17:00"></div></div>
    <label>Tipo de atendimento</label>
    <select id="agmTipo">${tiposAtendimento.map(t=>`<option value="${t.id}">${esc(t.nome)} · ${t.duracao_min} min</option>`).join('')}</select>
    <label>Duração de cada exame</label>
    <select id="agmDur">${opcoesDuracao('')}</select>
    <label>Intervalo entre os exames</label>
    <select id="agmBuf">${opcoesIntervalo('')}</select>
    <label>Pausa de almoço <span style="font-weight:400;color:var(--ink-soft);">(opcional, não gera horários nesse período)</span></label>
    <div class="row2"><div><input type="time" id="agmAlmIni" placeholder="Início"></div><div><input type="time" id="agmAlmFim" placeholder="Fim"></div></div>
    <p class="sub" id="agmAlmDica">Deixe os dois vazios para não ter pausa.</p>
    <p class="sub" id="agmPrev" style="font-weight:700;"></p>
    <label>Local <span style="font-weight:400;color:var(--ink-soft);">(opcional)</span></label><input type="text" id="agmLocal" value="${esc(clinicaAtual?.local_exame_padrao||'')}">
    <button class="btn btn-ghost btn-block" id="agmCriar" style="margin-top:10px;">+ Abrir horários</button>` : '<p class="sub" style="margin-top:12px;">Cadastre a primeira cidade no quadro acima para abrir os horários.</p>'}
  </div>`;
}
/* muda uma agenda que já existe, sem apagar (só enquanto não houver paciente marcado) */
function editarAgenda(a, recarregar){
  if(!a) return;
  const hh = (t)=> String(t||'').slice(0,5);
  openModal(`<h2>Mudar a agenda de ${fmtData(a.data)}</h2>
    <p class="sub">${esc(a.unidade_nome)}. Só dá para mudar enquanto não houver paciente marcado.</p>
    <div class="row2"><div><label>Das</label><input type="time" id="edIni" value="${hh(a.hora_inicio)}"></div><div><label>Até</label><input type="time" id="edFim" value="${hh(a.hora_fim)}"></div></div>
    <label>Tipo de atendimento</label>
    <select id="edTipo">${tiposAtendimento.map(t=>`<option value="${t.id}" ${t.id===a.tipo_atendimento_id?'selected':''}>${esc(t.nome)} · ${t.duracao_min} min</option>`).join('')}</select>
    <label>Duração de cada exame</label>
    <select id="edDur">${opcoesDuracao(a.duracao_min)}</select>
    <label>Intervalo entre os exames</label>
    <select id="edBuf">${opcoesIntervalo(a.buffer_agenda)}</select>
    <label>Pausa de almoço <span style="font-weight:400;color:var(--ink-soft);">(opcional)</span></label>
    <div class="row2"><div><input type="time" id="edAlIni" value="${hh(a.almoco_inicio)}"></div><div><input type="time" id="edAlFim" value="${hh(a.almoco_fim)}"></div></div>
    <label>Local <span style="font-weight:400;color:var(--ink-soft);">(opcional)</span></label><input type="text" id="edLocal" value="${esc(a.local||'')}">
    <p class="sub" id="edPrev" style="font-weight:700;margin-top:8px;"></p>
    <div class="btn-row"><button class="btn btn-primary" id="edSalvar">Salvar</button><button class="btn btn-outline" onclick="closeModal()">Fechar</button></div>`);
  const v = (id)=> document.getElementById(id).value;
  const prev = ()=>{ document.getElementById('edPrev').textContent = textoPrevAgenda(v('edIni'), v('edFim'), v('edDur'), v('edBuf'), v('edAlIni'), v('edAlFim'), v('edTipo')); };
  ['edIni','edFim','edTipo','edDur','edBuf','edAlIni','edAlFim'].forEach(id=>{ const e=document.getElementById(id); e.addEventListener('input',prev); e.addEventListener('change',prev); });
  prev();
  document.getElementById('edSalvar').onclick = async ()=>{
    if((v('edAlIni') && !v('edAlFim')) || (!v('edAlIni') && v('edAlFim'))){ toast('Preencha o início e o fim do almoço, ou deixe os dois vazios.'); return; }
    try{
      await api('/agendas/'+a.id, { method:'PUT', body:{ hora_inicio:v('edIni'), hora_fim:v('edFim'), tipo_atendimento_id:v('edTipo'), duracao_min:v('edDur'), buffer_min:v('edBuf'), almoco_inicio:v('edAlIni')||null, almoco_fim:v('edAlFim')||null, local:v('edLocal') } });
      closeModal(); toast('Agenda atualizada.'); recarregar();
    }catch(e){ erroApi(e); }
  };
}

async function ligarAgendaMaster(main){
  const lista = document.getElementById('listaAgendas'); if(!lista) return;
  const agnCriar = document.getElementById('agnCriar');
  if(agnCriar) agnCriar.onclick = async ()=>{
    const cidade = document.getElementById('agnCidade').value.trim();
    if(!cidade){ toast('Escreva o nome da cidade.'); return; }
    try{
      const nova = await api('/unidades', { method:'POST', body:{ nome:'Exame de vista', cidade, local: document.getElementById('agnLocal').value.trim() } });
      unidades.push(...normUnidades([nova]));
      toast('Cidade cadastrada. Agora abra os dias do exame.');
      abaMasterAtual = 'Agenda'; renderMaster(main);
      setTimeout(()=>{ const sel = document.getElementById('agmUn'); if(sel){ sel.value = nova.id; sel.scrollIntoView({behavior:'smooth',block:'center'}); } }, 150);
    }catch(e){ erroApi(e); }
  };
  async function carregar(){
    try{
      const ags = await api('/agendas');
      lista.innerHTML = ags.length ? ags.map(a=>`<div class="list-item"><div><div class="name">${fmtData(a.data)} · ${a.hora_inicio.slice(0,5)} às ${a.hora_fim.slice(0,5)}</div><div class="meta">${esc(a.unidade_nome)} · ${esc(a.tipo_nome)} · ${a.total_horarios} horário(s) de ${a.duracao_efetiva} min · ${a.buffer_efetivo?a.buffer_efetivo+' min de intervalo':'sem intervalo'}${a.almoco_inicio?' · almoço '+a.almoco_inicio.slice(0,5)+' às '+a.almoco_fim.slice(0,5):''}</div></div><div style="display:flex;gap:6px;"><button class="btn btn-outline btn-sm" data-edit="${a.id}">Editar</button><button class="btn btn-danger btn-sm" data-del="${a.id}">Apagar</button></div></div>`).join('') : '<p class="sub">Nenhum horário aberto ainda.</p>';
      lista.querySelectorAll('button[data-edit]').forEach(b=> b.onclick = ()=> editarAgenda(ags.find(x=>x.id===b.dataset.edit), carregar));
      lista.querySelectorAll('button[data-del]').forEach(b=> b.onclick = async ()=>{
        if(!confirm('Apagar este dia da agenda?')) return;
        try{ await api(`/agendas/${b.dataset.del}`, { method:'DELETE' }); carregar(); }catch(e){ erroApi(e); }
      });
    }catch(e){ lista.innerHTML = `<p class="fieldmsg bad">${esc(e.message)}</p>`; }
  }
  carregar();
  function atualizarPrev(){
    const el = document.getElementById('agmPrev'); if(!el) return;
    const v = (id)=> document.getElementById(id).value;
    el.textContent = textoPrevAgenda(v('agmIni'), v('agmFim'), v('agmDur'), v('agmBuf'), v('agmAlmIni'), v('agmAlmFim'), v('agmTipo'));
  }
  ['agmIni','agmFim','agmDur','agmBuf','agmAlmIni','agmAlmFim','agmTipo'].forEach(id=>{ const e = document.getElementById(id); if(e){ e.addEventListener('input', atualizarPrev); e.addEventListener('change', atualizarPrev); } });
  atualizarPrev();
  const criar = document.getElementById('agmCriar');
  if(criar) criar.onclick = async ()=>{
    const body = { unidade_id: document.getElementById('agmUn').value, data: document.getElementById('agmData').value, data_fim: document.getElementById('agmDataFim').value || null,
      hora_inicio: document.getElementById('agmIni').value, hora_fim: document.getElementById('agmFim').value, tipo_atendimento_id: document.getElementById('agmTipo').value, local: document.getElementById('agmLocal').value,
      buffer_min: document.getElementById('agmBuf').value, duracao_min: document.getElementById('agmDur').value, almoco_inicio: document.getElementById('agmAlmIni').value || null, almoco_fim: document.getElementById('agmAlmFim').value || null };
    if((body.almoco_inicio && !body.almoco_fim) || (!body.almoco_inicio && body.almoco_fim)){ toast('Preencha o início e o fim do almoço, ou deixe os dois vazios.'); return; }
    if(!body.data){ toast('Escolha o primeiro dia.'); return; }
    try{ await api('/agendas', { method:'POST', body }); toast('Horários abertos.'); carregar(); }catch(e){ erroApi(e); }
  };
}


/* ========================= ENVIOS PROGRAMADOS ========================= */
let enviosAba = 'agora';
async function renderEnvios(main){
  main.innerHTML = `<div class="card"><h2>Envios programados</h2>
    <p class="sub">Mensagens de WhatsApp antes e depois do atendimento. Toque em WhatsApp: a conversa abre com o texto pronto.</p>
    <div id="envAbas" style="margin:6px 0 10px;"></div><div id="envCorpo"><p class="sub">Carregando...</p></div></div>`;
  let dados;
  try{ dados = await api('/envios'); }catch(e){ document.getElementById('envCorpo').innerHTML = `<p class="fieldmsg bad">${esc(e.message)}</p>`; return; }
  const abas = [['agora','Enviar agora',dados.agora],['programados','Programados',dados.programados],['enviados','Enviados',dados.enviados]];
  document.getElementById('envAbas').innerHTML = abas.map(([k,n,l])=>`<button class="btn ${k===enviosAba?'btn-primary':'btn-outline'} btn-sm" data-aba="${k}" style="margin:0 6px 6px 0;width:auto;">${n} (${l.length})</button>`).join('');
  document.querySelectorAll('#envAbas button').forEach(b=> b.onclick = ()=>{ enviosAba = b.dataset.aba; renderEnvios(main); });
  const lista = (abas.find(a=>a[0]===enviosAba) || abas[0])[2];
  const corpo = document.getElementById('envCorpo');
  if(!lista.length){ corpo.innerHTML = `<div class="empty"><div class="ic">📨</div>${enviosAba==='agora' ? 'Nenhuma mensagem para enviar agora.' : 'Nada por aqui.'}</div>`; return; }
  corpo.innerHTML = lista.map((e,i)=>`<div class="list-item"><div><div class="name">${esc(e.paciente_nome)}</div><div class="meta">${esc(e.etapa_nome)} · ${e.etapa==='pos_oculos' ? 'óculos vendido em '+fmtData(e.data_hora) : 'exame '+fmtData(e.data_hora)+' às '+soHora(e.data_hora)}${e.devido_em && enviosAba==='programados' ? ' · sai em '+new Date(e.devido_em).toLocaleString('pt-BR',{day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'}) : ''}${e.telefone ? '' : ' · sem telefone'}</div></div>
    ${enviosAba==='agora' ? `<button class="btn btn-wpp btn-sm" data-i="${i}">WhatsApp</button>` : enviosAba==='enviados' ? `<button class="btn btn-outline btn-sm" data-undo="${i}">Desfazer</button>` : ''}</div>`).join('');
  corpo.querySelectorAll('button[data-i]').forEach(b=> b.onclick = async ()=>{
    const e = lista[+b.dataset.i];
    if(!e.telefone){ toast('Esse paciente está sem telefone.'); return; }
    abrirWhatsapp(e.telefone, e.mensagem);
    try{ await api(`/envios/${e.venda_id||e.agendamento_id}/marcar`, { method:'POST', body:{ etapa:e.etapa, enviado:true } }); renderEnvios(main); }catch(er){ erroApi(er); }
  });
  corpo.querySelectorAll('button[data-undo]').forEach(b=> b.onclick = async ()=>{
    const e = lista[+b.dataset.undo];
    try{ await api(`/envios/${e.venda_id||e.agendamento_id}/marcar`, { method:'POST', body:{ etapa:e.etapa, enviado:false } }); renderEnvios(main); }catch(er){ erroApi(er); }
  });
}

/* ========================= LISTA DE ESPERA ========================= */
async function renderEspera(main){
  main.innerHTML = `<div class="card"><h2>Lista de espera</h2><p class="sub">Pacientes que querem um horário mais cedo. Quando alguém cancelar, ofereça o horário pelo WhatsApp.</p>
    <div class="row2"><div><label>Nome</label><input type="text" id="leNome"></div><div><label>Telefone</label><input type="tel" id="leTel" inputmode="tel" placeholder="(64) 99999-9999"></div></div>
    ${usuarioAtual?.unidadeId ? '' : `<label>Cidade</label><select id="leUn">${cidadeTrabalho() ? '' : '<option value="">Qualquer cidade</option>'}${cidadesVisiveis().map(u=>`<option value="${u.id}">${esc(u.nome)}</option>`).join('')}</select>`}
    <label>Observação (ex.: só de manhã)</label><input type="text" id="leObs">
    <button class="btn btn-primary btn-block" id="leAdd" style="margin-top:10px;">Colocar na lista</button>
    <div id="leLista" style="margin-top:14px;"><p class="sub">Carregando...</p></div></div>`;
  async function carregar(){
    const box = document.getElementById('leLista'); if(!box) return;
    let l; try{ l = await api('/lista-espera'); }catch(e){ box.innerHTML = `<p class="fieldmsg bad">${esc(e.message)}</p>`; return; }
    if(!l.length){ box.innerHTML = '<div class="empty"><div class="ic">⏳</div>Ninguém na lista de espera.</div>'; return; }
    box.innerHTML = l.map(x=>`<div class="list-item"><div><div class="name">${esc(x.nome)}</div><div class="meta">${esc(x.telefone||'sem telefone')}${x.cidade?' · '+esc(x.cidade):''}${x.observacao?' · '+esc(x.observacao):''}</div></div>
      <div style="display:flex;gap:6px;flex-wrap:wrap;">${x.telefone?`<button class="btn btn-wpp btn-sm" data-of="${x.id}">Oferecer horário</button>`:''}<button class="btn btn-outline btn-sm" data-rm="${x.id}">Tirar</button></div></div>`).join('');
    box.querySelectorAll('[data-of]').forEach(b=> b.onclick = ()=>{ const x = l.find(y=>y.id===b.dataset.of); abrirWhatsapp(x.telefone, `Olá, ${String(x.nome).split(' ')[0]}! Aqui é da ${clinicaAtual?.nome_fantasia||'clínica'}. Abriu um horário para o exame de vista${x.cidade?' em '+x.cidade:''}. Você ainda tem interesse? Responda aqui que eu reservo para você.`); });
    box.querySelectorAll('[data-rm]').forEach(b=> b.onclick = async ()=>{ try{ await api('/lista-espera/'+b.dataset.rm, { method:'DELETE' }); carregar(); }catch(e){ erroApi(e); } });
  }
  document.getElementById('leAdd').onclick = async ()=>{
    try{
      await api('/lista-espera', { method:'POST', body:{ nome: document.getElementById('leNome').value, telefone: document.getElementById('leTel').value, observacao: document.getElementById('leObs').value, unidade_id: document.getElementById('leUn')?.value || null } });
      ['leNome','leTel','leObs'].forEach(i=> document.getElementById(i).value=''); toast('Colocado na lista.'); carregar();
    }catch(e){ erroApi(e); }
  };
  carregar();
}
async function avisarListaEspera(){
  try{ const l = await api('/lista-espera'); if(l.length) toast(`Horário liberado. Há ${l.length} pessoa(s) na Lista de espera para oferecer.`); }catch(e){}
}

/* ========================= FILA DO DIA ========================= */
let filaTimer = null;
async function renderFila(main){
  clearInterval(filaTimer);
  const hoje = hojeISO();
  main.innerHTML = `<div class="card"><h2>Fila do dia</h2><p class="sub">Quem já chegou, quem espera e quem está sendo atendido. Atualiza sozinha a cada 30 segundos.</p><div id="filaCorpo"><p class="sub">Carregando...</p></div></div>
    <button class="btn btn-outline btn-block" id="filaEspera">Ver lista de espera</button>`;
  document.getElementById('filaEspera').onclick = ()=> switchView('espera');
  const podeIniciar = usuarioAtual?.papel !== 'atendente';
  async function acao(id, a){ try{ await api('/agendamentos/'+id+'/fila', { method:'POST', body:{ acao:a } }); carregar(); }catch(e){ erroApi(e); } }
  async function finalizar(id){ try{ await api('/agendamentos/'+id+'/status', { method:'PATCH', body:{ status:'realizado' } }); carregar(); }catch(e){ erroApi(e); } }
  async function carregar(){
    const corpo = document.getElementById('filaCorpo');
    if(!corpo){ clearInterval(filaTimer); return; }
    let lista; try{ lista = await api('/agendamentos/fila'); }catch(e){ corpo.innerHTML = `<p class="fieldmsg bad">${esc(e.message)}</p>`; return; }
    if(!lista.length){ corpo.innerHTML = '<div class="empty"><div class="ic">🪑</div>Nenhum paciente marcado para hoje.</div>'; return; }
    const grupos = [['atendendo','Em atendimento'],['aguardando','Aguardando'],['chegada_pendente','Ainda não chegou'],['atendido','Atendidos'],['faltou','Não compareceu']];
    const min = (t)=> Math.max(0, Math.round((Date.now() - new Date(String(t).replace(' ','T').slice(0,19)+'Z').getTime())/60000));
    corpo.innerHTML = grupos.map(([k,t])=>{
      const l = lista.filter(x=>x.fila===k); if(!l.length) return '';
      return `<h3 style="margin:14px 0 4px;font-size:15px;">${t} (${l.length})</h3>` + l.map(x=>{
        let info = soHora(x.data_hora) + (x.tipo_nome? ' · '+esc(x.tipo_nome):'');
        if(k==='aguardando' && x.chegou_em) info += ' · espera há '+min(x.chegou_em)+' min';
        let bts = '';
        if(k==='chegada_pendente') bts = `<button class="btn btn-primary btn-sm" data-f="chegou" data-id="${x.id}">Chegou</button>`;
        else if(k==='aguardando') bts = (podeIniciar? `<button class="btn btn-primary btn-sm" data-f="iniciar" data-id="${x.id}">Iniciar</button>`:'') + `<button class="btn btn-ghost btn-sm" data-f="voltar" data-id="${x.id}">Desfazer</button>`;
        else if(k==='atendendo') bts = podeIniciar ? `<button class="btn btn-primary btn-sm" data-f="finalizar" data-id="${x.id}">Finalizar</button>` : '';
        return `<div class="list-item"><div><div class="name">${esc(x.nome_completo)}</div><div class="meta">${info}</div></div><div style="display:flex;gap:6px;">${bts}</div></div>`;
      }).join('');
    }).join('');
    corpo.querySelectorAll('button[data-f]').forEach(b=> b.onclick = ()=> b.dataset.f==='finalizar' ? finalizar(b.dataset.id) : acao(b.dataset.id, b.dataset.f));
  }
  await carregar();
  filaTimer = setInterval(()=>{ if(document.getElementById('filaCorpo')) carregar(); else clearInterval(filaTimer); }, 30000);
}

/* ========================= RELATÓRIO DO DIA ========================= */
let relatorioData = hojeISO();
async function renderRelatorioDia(main){
  main.innerHTML = `${usuarioAtual?.papel!=='atendente' ? `<div class="card"><h2>Resumo por cidade</h2>
    <div class="row2"><div><label>De</label><input type="date" id="pcDe" value="${hojeISO().slice(0,8)}01"></div><div><label>Até</label><input type="date" id="pcAte" value="${relatorioData}"></div></div>
    <div id="pcCorpo"><p class="sub">Carregando...</p></div></div>` : ''}<div class="card"><h2>Relatório do dia</h2>
    <label>Data</label><input type="date" id="relData" value="${relatorioData}" style="max-width:200px;">
    <div id="relCorpo"><p class="sub">Carregando...</p></div></div>`;
  document.getElementById('relData').onchange = e=>{ relatorioData = e.target.value; renderRelatorioDia(main); };
  if(document.getElementById('pcCorpo')){
    const carregarCidades = async ()=>{
      const corpo = document.getElementById('pcCorpo');
      try{
        const l = await api(`/relatorios/por-cidade?de=${document.getElementById('pcDe').value}&ate=${document.getElementById('pcAte').value}`);
        const adm = usuarioAtual?.papel==='admin';
        corpo.innerHTML = l.length ? `<div style="overflow-x:auto;"><table style="width:100%;font-size:13.5px;border-collapse:collapse;"><tr><th align="left">Cidade</th><th>Marcados</th><th>Atendidos</th><th>Faltas</th><th>Cancel.</th>${adm?'<th>Recebido</th><th>A receber</th>':''}</tr>${l.map(x=>`<tr><td>${esc(x.cidade)}</td><td align="center">${x.marcados}</td><td align="center">${x.atendidos}</td><td align="center">${x.faltas}</td><td align="center">${x.cancelados}</td>${adm?`<td align="right">${fmtMoeda(x.recebido)}</td><td align="right">${fmtMoeda(x.a_receber)}</td>`:''}</tr>`).join('')}</table></div>` : '<div class="empty"><div class="ic">📍</div>Nada nesse período.</div>';
      }catch(e){ corpo.innerHTML = `<p class="fieldmsg bad">${esc(e.message)}</p>`; }
    };
    document.getElementById('pcDe').onchange = carregarCidades; document.getElementById('pcAte').onchange = carregarCidades;
    carregarCidades();
  }
  let lista = [];
  try{ lista = await api(`/agendamentos?de=${relatorioData}&ate=${relatorioData}`); }
  catch(e){ document.getElementById('relCorpo').innerHTML = `<p class="fieldmsg bad">${esc(e.message)}</p>`; return; }
  const corpo = document.getElementById('relCorpo');
  if(!lista.length){ corpo.innerHTML = '<div class="empty"><div class="ic">📋</div>Nenhum agendamento nesse dia.</div>'; return; }
  const cont = st=> lista.filter(a=>a.status===st).length;
  const linhas = lista.map(a=>`<div class="list-item"><div><div class="name">${soHora(a.data_hora)} · ${esc(a.nome_completo)}</div><div class="meta">${esc(a.tipo_nome||'')} · ${esc(a.status)}${a.local? ' · '+esc(a.local):''}</div></div></div>`).join('');
  corpo.innerHTML = `<p class="sub">${lista.length} no total · ${cont('agendado')} agendado(s) · ${cont('confirmado')} confirmado(s) · ${cont('realizado')} realizado(s) · ${cont('cancelado')} cancelado(s)</p>${linhas}
    <button class="btn btn-amber btn-block" id="btnImprimirDia" style="margin-top:14px;">Imprimir relatório</button>`;
  document.getElementById('btnImprimirDia').onclick = ()=>{
    const trs = lista.map(a=>`<tr><td>${soHora(a.data_hora)}</td><td>${esc(a.nome_completo)}</td><td>${esc(a.tipo_nome||'')}</td><td>${esc(a.status)}</td></tr>`).join('');
    imprimirDocumento(paginaDoc('Agenda do dia '+fmtData(relatorioData), `<p style="font-family:Arial,sans-serif;font-size:10.5pt;">${lista.length} no total · ${cont('confirmado')} confirmado(s) · ${cont('realizado')} realizado(s) · ${cont('cancelado')} cancelado(s)</p><table class="lista"><tr><th>Hora</th><th>Paciente</th><th>Atendimento</th><th>Situação</th></tr>${trs}</table>`));
  };
}

/* ========================= RETORNOS E ANIVERSARIANTES ========================= */
/* ========================= PAINEL ========================= */
const fmtMoeda = v => Number(v||0).toLocaleString('pt-BR',{style:'currency',currency:'BRL'});
const ORIGENS = { equipe:'Equipe', whatsapp:'WhatsApp', portal:'Link online', otica:'Ótica parceira' };
function cartaoNumero(rotulo, valor, nota){
  return `<div class="card" style="margin:0;text-align:center;padding:14px 10px;"><div class="display" style="font-size:30px;color:var(--teal-900);line-height:1.1;">${valor}</div><div style="font-size:12.5px;font-weight:600;margin-top:4px;">${rotulo}</div>${nota?`<div class="sub" style="margin:2px 0 0;">${nota}</div>`:''}</div>`;
}
async function renderPainel(main){
  main.innerHTML = '<div class="card"><h2>Painel</h2><p class="sub">Carregando...</p></div>';
  let d;
  try{ d = await api('/relatorios/painel'); }
  catch(e){ main.innerHTML = `<div class="card"><h2>Painel</h2><p class="fieldmsg bad">${esc(e.message)}</p></div>`; return; }
  const grade = 'display:grid;grid-template-columns:repeat(auto-fit,minmax(130px,1fr));gap:10px;margin-bottom:14px;';
  const dias14 = []; { const b = new Date(); b.setDate(b.getDate()-6); for(let i=0;i<14;i++){ const x = new Date(b); x.setDate(b.getDate()+i); dias14.push(dataISO(x)); } }
  const mapa = {}; (d.serie||[]).forEach(s=> mapa[s.dia] = s.qtd);
  const maxq = Math.max(1, ...dias14.map(x=>mapa[x]||0));
  const hojeStr = hojeISO();
  let html = `<div class="card"><h2>Hoje</h2><div class="kpi-grid">
      <div class="kpi"><b>${d.hoje.total}</b><span>Consultas hoje</span></div>
      <div class="kpi c4"><b>${d.hoje.confirmadas}</b><span>Confirmadas</span></div>
      <div class="kpi c3"><b>${d.hoje.aguardando}</b><span>Aguardando</span></div>
      <div class="kpi c2"><b>${d.mes.realizados}</b><span>Atendidos no mês</span></div></div>
      <h3 style="margin:14px 0 0;font-size:15px;">Exames por dia (6 dias atrás até 7 à frente)</h3>
      <div class="barras">${dias14.map(x=>`<div title="${x}: ${mapa[x]||0}"><span>${mapa[x]||0}</span><i style="height:${Math.round((mapa[x]||0)/maxq*100)}%;${x===hojeStr?'background:#E8B04A;':''}"></i><span>${x.slice(8)}</span></div>`).join('')}</div></div>`;
  html += `<div class="card"><h2>Este mês</h2><div style="${grade}">
      ${cartaoNumero('Atendidos', d.mes.realizados)}
      ${cartaoNumero('Ocupação', d.mes.ocupacao==null?'-':d.mes.ocupacao+'%', d.mes.vagas?`${d.mes.marcados} de ${d.mes.vagas} horários`:'abra horários na agenda')}
      ${cartaoNumero('Não compareceram', d.mes.nao_comparecimento+'%', d.mes.faltaram+' faltas')}</div>`;
  if(d.faturamento){
    const f = d.faturamento;
    html += `<div style="${grade}">${cartaoNumero('Recebido no mês', fmtMoeda(f.mes))}${cartaoNumero('Mês passado', fmtMoeda(f.anterior))}${cartaoNumero('A receber', fmtMoeda(f.a_receber))}${cartaoNumero('Projeção do mês', fmtMoeda(f.projecao), 'no ritmo atual')}</div>`;
  }
  html += `</div>`;
  html += `<div class="card"><h2>De onde vêm os agendamentos</h2>${d.origens.length ? d.origens.map(o=>`<div class="list-item"><div class="name">${ORIGENS[o.origem]||esc(o.origem)}</div><div>${o.qtd}</div></div>`).join('') : '<p class="sub">Nenhum agendamento neste mês.</p>'}</div>`;
  html += `<div class="card"><h2>Próximas consultas</h2>${d.proximas.length ? d.proximas.map(a=>`<div class="list-item"><div><div class="name">${esc(a.nome_completo)}</div><div class="meta">${fmtData(a.data_hora)} às ${soHora(a.data_hora)} · ${esc(a.tipo_nome||'')} · ${esc(a.status)}</div></div></div>`).join('') : '<p class="sub">Nada marcado pela frente.</p>'}</div>`;
  html += `<div class="card"><h2>Receitas perto de vencer</h2><p class="sub">Receita emitida há 10 a 12 meses. Vale avisar o paciente.</p><div id="pnReceitas"></div></div>
    <div class="card"><h2>Retornos vencendo</h2><p class="sub">Último exame há 11 a 12 meses e nada marcado.</p><div id="pnRetornos"></div></div>`;
  main.innerHTML = html;
  const lista = (id, itens, dataCampo, texto)=>{
    const box = document.getElementById(id);
    if(!itens.length){ box.innerHTML = '<div class="empty"><div class="ic">✅</div>Ninguém por agora.</div>'; return; }
    box.innerHTML = itens.map((r,i)=>`<div class="list-item"><div><div class="name">${esc(r.nome_completo)}</div><div class="meta">${fmtData(r[dataCampo])} · ${esc(r.telefone||'sem telefone')}</div></div><button class="btn btn-wpp btn-sm" data-i="${i}">WhatsApp</button></div>`).join('');
    box.querySelectorAll('button[data-i]').forEach(b=> b.onclick = ()=>{ const r = itens[+b.dataset.i]; abrirWhatsapp(r.telefone, texto(r)); });
  };
  const nomeCli = clinicaAtual?.nome_fantasia||'clínica';
  lista('pnReceitas', d.receitas_vencendo, 'emissao', r=>`Olá, ${primeiroNome(r.nome_completo)}! Aqui é da ${nomeCli}. Sua receita de óculos está perto de completar 1 ano. Quer marcar um novo exame?`);
  lista('pnRetornos', d.retornos_vencendo, 'ultimo_exame', r=>`Olá, ${primeiroNome(r.nome_completo)}! Aqui é da ${nomeCli}. Seu último exame de vista está perto de completar 1 ano. Quer marcar seu retorno?`);
}

/* ========================= FINANCEIRO (só administrador) ========================= */
const FORMAS_PAG = { dinheiro:'Dinheiro', pix:'Pix', debito:'Débito', credito:'Crédito', convenio:'Convênio' };
let finAba = 'receber', finDe = '', finAte = '';
function periodoMes(){
  const h = new Date(), f = d=>`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
  return [f(new Date(h.getFullYear(),h.getMonth(),1)), f(new Date(h.getFullYear(),h.getMonth()+1,0))];
}
function renderFinanceiro(main){
  if(!finDe){ [finDe, finAte] = periodoMes(); }
  main.innerHTML = `<div class="card"><h2>Financeiro</h2>
    <div class="btn-row" style="margin-bottom:10px;">
      ${[['receber','Recebíveis'],['contas','Contas a pagar'],['nota','Nota (simulador)'],['resumo','Resumo']].map(([k,n])=>`<button class="btn ${finAba===k?'btn-primary':'btn-ghost'}" data-aba="${k}">${n}</button>`).join('')}
    </div>
    ${(finAba==='contas'||finAba==='nota') ? '' : `<div class="row2"><div><label>De</label><input type="date" id="finDe" value="${finDe}"></div><div><label>Até</label><input type="date" id="finAte" value="${finAte}"></div></div>`}
    <div id="finCorpo"><p class="sub">Carregando...</p></div></div>`;
  main.querySelectorAll('button[data-aba]').forEach(b=> b.onclick = ()=>{ finAba = b.dataset.aba; renderFinanceiro(main); });
  const de = document.getElementById('finDe'), ate = document.getElementById('finAte');
  if(de) de.onchange = ()=>{ finDe = de.value; renderFinanceiro(main); };
  if(ate) ate.onchange = ()=>{ finAte = ate.value; renderFinanceiro(main); };
  const corpo = document.getElementById('finCorpo');
  const falha = e=>{ corpo.innerHTML = `<p class="fieldmsg bad">${esc(e.message)}</p>`; };
  if(finAba==='receber') finReceber(main, corpo).catch(falha);
  else if(finAba==='contas') finContas(main, corpo).catch(falha);
  else if(finAba==='nota') finNota(corpo).catch(falha);
  else finResumo(corpo).catch(falha);
}

/* nota fiscal SIMULADA: treina o fluxo; não tem valor fiscal e não vai à prefeitura */
async function finNota(corpo){
  const lista = await api('/financeiro/notas-simuladas');
  const nfHtml = n=>`<div class="nf-sim"><b style="font-size:16px;">NOTA DE SERVIÇO (SIMULAÇÃO) Nº ${String(n.numero).padStart(6,'0')}</b>
    <div style="margin-top:8px;font-size:13.5px;"><div><b>Prestador:</b> ${esc(clinicaAtual?.nome_fantasia||'')}</div><div><b>Cliente:</b> ${esc(n.cliente_nome)}${n.cliente_cpf?' · CPF '+esc(n.cliente_cpf):''}</div>
    <div><b>Serviço:</b> ${esc(n.descricao)}</div><div><b>Valor:</b> ${fmtMoeda(n.valor)}${n.forma?' · '+esc(FORMAS_PAG[n.forma]||n.forma):''}</div><div><b>Data:</b> ${new Date(n.criado_em).toLocaleString('pt-BR')}</div></div></div>`;
  corpo.innerHTML = `<p class="sub">Simulador. A nota abaixo não vale como nota fiscal e não vai à prefeitura. Serve para treinar o fluxo. A nota de verdade entra depois, com o seu contador.</p>
    <label>Cliente</label><input type="text" id="nfNome" placeholder="Nome do cliente">
    <div class="row2"><div><label>CPF (opcional)</label><input type="text" id="nfCpf" inputmode="numeric"></div><div><label>Valor (R$)</label><input type="text" id="nfValor" inputmode="decimal" placeholder="0,00"></div></div>
    <label>Serviço</label><input type="text" id="nfDesc" value="Exame de vista">
    <label>Forma de pagamento</label><select id="nfForma"><option value="">Não informar</option>${Object.entries(FORMAS_PAG).map(([k,n])=>`<option value="${k}">${n}</option>`).join('')}</select>
    <div class="btn-row"><button class="btn btn-primary" id="nfGerar">Gerar simulação</button></div><div id="nfSaida" style="margin-top:14px;"></div>
    <h3 style="margin:18px 0 6px;font-size:15px;">Últimas simulações</h3>${lista.length ? lista.slice(0,15).map(n=>`<div class="list-item"><div><div class="name">Nº ${String(n.numero).padStart(6,'0')} · ${esc(n.cliente_nome)}</div><div class="meta">${esc(n.descricao)} · ${fmtMoeda(n.valor)} · ${new Date(n.criado_em).toLocaleDateString('pt-BR')}</div></div><button class="btn btn-ghost" data-ver="${n.id}">Ver</button></div>`).join('') : '<div class="empty">Nenhuma simulação ainda.</div>'}`;
  const mostrar = n=>{
    document.getElementById('nfSaida').innerHTML = nfHtml(n)+'<div class="btn-row"><button class="btn btn-outline" id="nfImp">Imprimir</button></div>';
    document.getElementById('nfImp').onclick = ()=>{
      const w = window.open('','_blank'); if(!w){ toast('Libere as janelas do navegador para imprimir.'); return; }
      w.document.write(`<html><head><title>Simulação nº ${n.numero}</title><style>body{font-family:Arial,sans-serif;margin:30px}.nf-sim{position:relative;border:2px dashed #C1462F;padding:18px;overflow:hidden}.nf-sim::after{content:'SIMULAÇÃO – SEM VALOR FISCAL';position:absolute;inset:0;display:flex;align-items:center;justify-content:center;font-size:30px;font-weight:800;color:rgba(193,70,47,.18);transform:rotate(-24deg);text-align:center}</style></head><body>${nfHtml(n)}</body></html>`);
      w.document.close(); w.focus(); setTimeout(()=>w.print(),300);
    };
  };
  document.getElementById('nfGerar').onclick = async ()=>{
    try{
      const n = await api('/financeiro/notas-simuladas', { method:'POST', body:{ cliente_nome:document.getElementById('nfNome').value, cliente_cpf:document.getElementById('nfCpf').value, valor:document.getElementById('nfValor').value, descricao:document.getElementById('nfDesc').value, forma:document.getElementById('nfForma').value } });
      toast('Simulação nº '+n.numero+' gerada.'); mostrar(n);
      const l2 = await api('/financeiro/notas-simuladas'); lista.length = 0; l2.forEach(x=>lista.push(x));
    }catch(e){ toast(e.message); }
  };
  corpo.querySelectorAll('button[data-ver]').forEach(b=> b.onclick = ()=> mostrar(lista.find(x=>x.id===b.dataset.ver)));
}
async function finReceber(main, corpo){
  const d = await api(`/financeiro/recebiveis?de=${finDe}&ate=${finAte}`);
  const soma = l=> l.reduce((t,x)=>t+Number(x.valor||0),0);
  const linha = (x, rot)=>`<div class="list-item"><div><div class="name">${esc(x.paciente_nome)}</div><div class="meta">${fmtData(x.data_hora)} · ${esc(x.tipo_nome||'')}${x.otica_nome?' · '+esc(x.otica_nome):''}${x.convenio_nome?' · '+esc(x.convenio_nome):''}${x.forma?' · '+FORMAS_PAG[x.forma]:''}</div></div><div style="text-align:right;">${x.valor!=null?`<div class="name">${fmtMoeda(x.valor)}</div>`:''}<button class="btn btn-ghost btn-sm" data-id="${x.agendamento_id}">${rot}</button></div></div>`;
  const bloco = (titulo, lista, rot, vazio)=>`<h3 style="margin:14px 0 4px;font-size:15px;">${titulo}${lista.length&&lista[0].valor!=null?` · ${fmtMoeda(soma(lista))}`:''}</h3>${lista.length? lista.map(x=>linha(x,rot)).join('') : `<p class="sub">${vazio}</p>`}`;
  corpo.innerHTML = bloco('Sem cobrança registrada', d.sem_cobranca, 'Cobrar', 'Todos os atendimentos já têm cobrança.')
    + bloco('A receber', d.a_receber, 'Receber', 'Nada pendente.')
    + bloco('Recebidos', d.recebidos, 'Ver', 'Nada recebido no período.');
  const todos = [...d.sem_cobranca, ...d.a_receber, ...d.recebidos];
  corpo.querySelectorAll('button[data-id]').forEach(b=> b.onclick = ()=> abrirCobranca(todos.find(x=>x.agendamento_id===b.dataset.id), main));
}
function abrirCobranca(x, main){
  openModal(`<h2>${esc(x.paciente_nome)}</h2><p class="sub">${fmtData(x.data_hora)} · ${esc(x.tipo_nome||'')}</p>
    <label class="req">Valor (R$)</label><input type="text" inputmode="decimal" id="cbValor" value="${x.valor!=null?String(x.valor).replace('.',','):(x.preco_padrao!=null?String(x.preco_padrao).replace('.',','):'')}" placeholder="150,00">
    <label>Forma de pagamento</label>
    <select id="cbForma"><option value="">Não informada</option>${Object.entries(FORMAS_PAG).map(([k,v])=>`<option value="${k}" ${x.forma===k?'selected':''}>${v}</option>`).join('')}</select>
    <label>Convênio</label>
    <select id="cbConv"><option value="">Particular</option>${convenios.map(c=>`<option value="${c.id}" ${x.convenio_nome===c.nome?'selected':''}>${esc(c.nome)}</option>`).join('')}</select>
    <label style="display:flex;gap:8px;align-items:center;margin-top:12px;"><input type="checkbox" id="cbPago" style="width:auto;" ${x.status==='pago'?'checked':''}> Já foi pago</label>
    <div class="btn-row"><button class="btn btn-primary" id="cbSalvar">Salvar</button>${x.pagamento_id?'<button class="btn btn-danger" id="cbRemover">Remover cobrança</button>':''}<button class="btn btn-outline" onclick="closeModal()">Fechar</button></div>
    <p id="cbErr" style="color:#C1462F;font-size:12.5px;margin-top:8px;"></p>`);
  document.getElementById('cbSalvar').onclick = async ()=>{
    try{
      await api('/financeiro/pagamentos', { method:'POST', body:{ agendamento_id:x.agendamento_id, valor:document.getElementById('cbValor').value, forma:document.getElementById('cbForma').value||null, convenio_id:document.getElementById('cbConv').value||null, pago:document.getElementById('cbPago').checked }});
      closeModal(); toast('Cobrança salva.'); renderFinanceiro(main);
    }catch(e){ document.getElementById('cbErr').textContent = e.message; }
  };
  const rem = document.getElementById('cbRemover');
  if(rem) rem.onclick = async ()=>{
    if(!confirm('Remover esta cobrança?')) return;
    try{ await api(`/financeiro/pagamentos/${x.pagamento_id}`, { method:'DELETE' }); closeModal(); renderFinanceiro(main); }catch(e){ erroApi(e); }
  };
}
async function finContas(main, corpo){
  const lista = await api('/financeiro/contas');
  const hoje = hojeISO();
  corpo.innerHTML = `<div class="row2"><div><label>Descrição</label><input type="text" id="ctDesc" placeholder="Ex: aluguel do espaço"></div><div><label>Valor (R$)</label><input type="text" inputmode="decimal" id="ctValor" placeholder="300,00"></div></div>
    <label>Vencimento</label><input type="date" id="ctVenc" style="max-width:200px;">
    <button class="btn btn-ghost btn-block" id="ctAdd" style="margin-top:10px;">+ Adicionar conta</button>
    <div style="margin-top:14px;">${lista.length ? lista.map(c=>`<div class="list-item"><div><div class="name">${esc(c.descricao)} · ${fmtMoeda(c.valor)}</div><div class="meta" style="${!c.pago&&c.vencimento<hoje?'color:#C1462F;font-weight:600;':''}">${c.pago?'Paga em '+fmtData(c.pago_em):(c.vencimento<hoje?'Vencida em ':'Vence em ')+fmtData(c.vencimento)}</div></div><div><button class="btn btn-ghost btn-sm" data-pg="${c.id}" data-pago="${c.pago}">${c.pago?'Desfazer':'Pagar'}</button> <button class="btn btn-outline btn-sm" data-del="${c.id}">Excluir</button></div></div>`).join('') : '<p class="sub">Nenhuma conta cadastrada.</p>'}</div>`;
  document.getElementById('ctAdd').onclick = async ()=>{
    try{ await api('/financeiro/contas', { method:'POST', body:{ descricao:document.getElementById('ctDesc').value.trim(), valor:document.getElementById('ctValor').value, vencimento:document.getElementById('ctVenc').value }}); toast('Conta adicionada.'); renderFinanceiro(main); }
    catch(e){ erroApi(e); }
  };
  corpo.querySelectorAll('button[data-pg]').forEach(b=> b.onclick = async ()=>{
    try{ await api(`/financeiro/contas/${b.dataset.pg}/pagar`, { method:'PATCH', body:{ pago: b.dataset.pago!=='true' }}); renderFinanceiro(main); }catch(e){ erroApi(e); }
  });
  corpo.querySelectorAll('button[data-del]').forEach(b=> b.onclick = async ()=>{
    if(!confirm('Excluir esta conta?')) return;
    try{ await api(`/financeiro/contas/${b.dataset.del}`, { method:'DELETE' }); renderFinanceiro(main); }catch(e){ erroApi(e); }
  });
}

async function finResumo(corpo){
  const r = await api(`/financeiro/resumo?de=${finDe}&ate=${finAte}`);
  const grade = 'display:grid;grid-template-columns:repeat(auto-fit,minmax(130px,1fr));gap:10px;margin:10px 0;';
  const tabela = (t, itens)=>`<h3 style="margin:14px 0 4px;font-size:15px;">${t}</h3>${itens.length? itens.map(i=>`<div class="list-item"><div class="name">${FORMAS_PAG[i.nome]||esc(i.nome)}</div><div>${fmtMoeda(i.total)} <span class="meta">(${i.qtd})</span></div></div>`).join('') : '<p class="sub">Sem valores no período.</p>'}`;
  corpo.innerHTML = `<div style="${grade}">${cartaoNumero('Recebido', fmtMoeda(r.recebido), r.n_recebido+' atendimentos')}${cartaoNumero('A receber', fmtMoeda(r.a_receber), r.n_a_receber+' atendimentos')}${cartaoNumero('Contas a pagar', fmtMoeda(r.contas_a_pagar))}${cartaoNumero('Saldo', fmtMoeda(r.saldo), 'recebido menos contas pagas')}</div>`
    + (r.documentos && (r.documentos.n_recebido||r.documentos.n_pendente) ? `<h3 style="margin:14px 0 4px;font-size:15px;">Receitas e atestados por Pix</h3><div class="list-item"><div class="name">Recebido</div><div>${fmtMoeda(r.documentos.recebido)} <span class="meta">(${r.documentos.n_recebido})</span></div></div><div class="list-item"><div class="name">Cobrado e ainda não pago</div><div>${fmtMoeda(r.documentos.pendente)} <span class="meta">(${r.documentos.n_pendente})</span></div></div>` : '')
    + tabela('Por forma de pagamento', r.por_forma) + tabela('Por ótica parceira', r.por_otica) + tabela('Por convênio', r.por_convenio);
}

/* ========================= TESTE DE VISÃO NA TELA ========================= */
const LETRAS_SLOAN = 'CDHKNORSVZ'.split('');
const LINHAS_AV = [200,100,70,50,40,30,25,20,15,10];
let tt = { pxmm: 3.78, dist: 6000, linha: 7, espelho: false, modo: 'letras', olho: 'AO', letras: [] };
try{ const s = localStorage.getItem('tt_pxmm'); if(s) tt.pxmm = parseFloat(s) || tt.pxmm; }catch(e){}
function sortearLetras(n){
  const l = []; while(l.length<n){ const c = LETRAS_SLOAN[Math.floor(Math.random()*LETRAS_SLOAN.length)]; if(l[l.length-1]!==c) l.push(c); } return l;
}
function alturaMm(den){ // 20/den: letra com 5 minutos de arco x (den/20), na distância escolhida
  const ang = (5/60) * (den/20) * Math.PI/180;
  return 2 * tt.dist * Math.tan(ang/2);
}
function renderTesteTela(main){
  main.innerHTML = `<div class="card"><h2>Teste de visão na tela</h2>
    <p class="sub">Primeiro calibre a tela com um cartão de banco. Depois afaste o paciente na distância escolhida e abra o optotipo. São 19 testes: letras, números, E direcional, C de Landolt, cores, duocromo, dial astigmático, luzes de Worth, desenhos, Amsler, fixação, leitura de perto, contraste, educação ocular, cruz de afinamento, contraste por letras, tabela ETDRS, Amsler vermelho e tabela de Snellen.</p>
    <div class="btn-row"><button class="btn btn-ghost" id="ttCalib">1. Calibrar a tela</button>
    <button class="btn btn-primary" id="ttIniciar">2. Abrir o optotipo</button></div>
    <div style="margin-top:10px;"><label>Distância do paciente</label>
      <select id="ttDist">${[[3000,'3 metros'],[4000,'4 metros'],[5000,'5 metros'],[6000,'6 metros'],[1000,'1 metro'],[400,'40 cm (perto)']].map(([v,n])=>`<option value="${v}" ${tt.dist===v?'selected':''}>${n}</option>`).join('')}</select></div>
    <label style="display:flex;gap:8px;align-items:center;margin-top:10px;"><input type="checkbox" id="ttEsp" style="width:auto;" ${tt.espelho?'checked':''}> Modo espelho (para sala pequena com espelho)</label>
    <p class="sub" id="ttInfo" style="margin-top:8px;"></p>
    <p class="sub">Dentro do optotipo, aperte <b>?</b> para ver os atalhos do teclado. O botão "Conectar celular" mostra um QR Code para controlar o teste pelo celular.</p></div>`;
  const info = ()=>{ document.getElementById('ttInfo').textContent = `Letra 20/20 nesta distância: ${alturaMm(20).toFixed(1)} mm de altura. Calibração atual: ${tt.pxmm.toFixed(2)} pixels por mm.`; };
  document.getElementById('ttDist').onchange = e=>{ tt.dist = +e.target.value; info(); };
  document.getElementById('ttEsp').onchange = e=>{ tt.espelho = e.target.checked; };
  document.getElementById('ttCalib').onclick = ()=> calibrarTela(info);
  document.getElementById('ttIniciar').onclick = ()=> iniciarTeste();
  tt.dist = +document.getElementById('ttDist').value; info();
}
function calibrarTela(depois){
  openModal(`<h2>Calibrar a tela</h2><p class="sub">Encoste um cartão de banco na tela, deitado. Mexa na barra até o retângulo ficar do mesmo tamanho do cartão. O cartão mede 8,56 cm por 5,40 cm.</p>
    <div style="overflow:auto;"><div id="calRet" style="height:${53.98*tt.pxmm}px;width:${85.6*tt.pxmm}px;border:2px solid var(--teal-700);border-radius:8px;background:var(--teal-100);margin:10px 0;"></div></div>
    <input type="range" id="calBar" min="1.5" max="9" step="0.01" value="${tt.pxmm}" style="width:100%;">
    <div class="btn-row"><button class="btn btn-primary" id="calOk">Está do tamanho do cartão</button><button class="btn btn-outline" onclick="closeModal()">Cancelar</button></div>`);
  const bar = document.getElementById('calBar'), ret = document.getElementById('calRet');
  bar.oninput = ()=>{ ret.style.width = (85.6*bar.value)+'px'; ret.style.height = (53.98*bar.value)+'px'; };
  document.getElementById('calOk').onclick = ()=>{
    tt.pxmm = parseFloat(bar.value);
    try{ localStorage.setItem('tt_pxmm', String(tt.pxmm)); }catch(e){}
    closeModal(); toast('Tela calibrada.'); depois();
  };
}
function iniciarTeste(){
  if(typeof abrirOptotipo !== 'function'){ toast('Arquivo optotipo.js não encontrado na pasta do sistema.'); return; }
  abrirOptotipo();
}
function svgE(h){ // E em grade 5x5: traço de 1/5 da altura, como manda o optotipo padrão
  return `<svg viewBox="0 0 5 5" width="${h}" height="${h}" style="display:block;"><path fill="#000" d="M0 0h5v1H1v1h3v1H1v1h4v1H0z"/></svg>`;
}

/* ========================= ÓTICAS PARCEIRAS E CONVÊNIOS (Master) ========================= */
function cadastrosMasterCardHtml(){
  return ['oticas','convenios'].map(k=>{
    const nome = k==='oticas' ? 'Óticas parceiras' : 'Convênios';
    const sub = k==='oticas' ? 'Óticas que indicam pacientes. Aparecem na hora de marcar o horário e nos números do financeiro.' : 'Planos e convênios aceitos. Aparecem na hora de registrar a cobrança.';
    return `<div class="card"><h2>${nome}</h2><p class="sub">${sub}</p><div id="lista_${k}"></div>
      <div class="row2" style="margin-top:8px;"><div><input type="text" id="novo_${k}" placeholder="Nome"></div><div><button class="btn btn-ghost btn-block" id="add_${k}">+ Adicionar</button></div></div></div>`;
  }).join('');
}
function impressaoMasterCardHtml(){
  const c = configImpressao();
  const opt = (v,n,atual)=>`<option value="${v}" ${atual===v?'selected':''}>${n}</option>`;
  return `<div class="card"><h2>Impressão</h2><p class="sub">Tamanho da folha e aparência da receita, do atestado e da declaração.</p>
    <div class="row2"><div><label>Tamanho da folha</label><select id="imPapel">${opt('A4','A4 (folha inteira)',c.papel)}${opt('A5','A5 (meia folha)',c.papel)}${opt('Letter','Carta',c.papel)}</select></div>
      <div><label>Posição</label><select id="imOri">${opt('portrait','Em pé',c.orientacao)}${opt('landscape','Deitada',c.orientacao)}</select></div></div>
    <div class="row2"><div><label>Cor</label><select id="imCor">${opt('colorido','Colorido',c.cor)}${opt('pb','Preto e branco (impressora a laser)',c.cor)}</select></div>
      <div><label>Margem (mm)</label><input type="number" id="imMargem" min="5" max="30" value="${c.margem_mm}"></div></div>
    <label>Texto no rodapé dos documentos <span style="font-weight:400;color:var(--ink-soft);">(opcional)</span></label>
    <input type="text" id="imRodape" maxlength="300" value="${esc(c.rodape)}" placeholder="Ex: Receita válida por 12 meses. Faça revisão anual da visão.">
    <button class="btn btn-ghost btn-block" id="imSalvar" style="margin-top:10px;">Salvar impressão</button></div>`;
}
function ligarImpressaoMaster(){
  const b = document.getElementById('imSalvar'); if(!b) return;
  b.onclick = async ()=>{
    try{
      const cfg = await api('/clinica/impressao', { method:'PUT', body:{ papel:document.getElementById('imPapel').value, orientacao:document.getElementById('imOri').value, cor:document.getElementById('imCor').value, margem_mm:document.getElementById('imMargem').value, rodape:document.getElementById('imRodape').value }});
      clinicaAtual.config_impressao = cfg; toast('Impressão salva.');
    }catch(e){ erroApi(e); }
  };
}
function ligarCadastrosMaster(main){
  [['oticas',()=>oticas,v=>{oticas=v;}],['convenios',()=>convenios,v=>{convenios=v;}]].forEach(([k,get,set])=>{
    const box = document.getElementById('lista_'+k); if(!box) return;
    const desenhar = ()=>{
      const l = get();
      box.innerHTML = l.length ? l.map(x=>`<div class="list-item"><div class="name">${esc(x.nome)}</div><button class="btn btn-outline btn-sm" data-del="${x.id}">Remover</button></div>`).join('') : '<p class="sub">Nenhum cadastrado.</p>';
      box.querySelectorAll('button[data-del]').forEach(b=> b.onclick = async ()=>{
        if(!confirm('Remover da lista?')) return;
        try{ await api(`/cadastros/${k}/${b.dataset.del}`, { method:'DELETE' }); set(get().filter(x=>x.id!==b.dataset.del)); desenhar(); }catch(e){ erroApi(e); }
      });
    };
    desenhar();
    document.getElementById('add_'+k).onclick = async ()=>{
      const inp = document.getElementById('novo_'+k), nome = inp.value.trim(); if(!nome) return;
      try{ const novo = await api(`/cadastros/${k}`, { method:'POST', body:{ nome } }); set([...get(), novo].sort((a,b)=>a.nome.localeCompare(b.nome))); inp.value=''; desenhar(); }catch(e){ erroApi(e); }
    };
  });
}
function oticaSelectHtml(id){
  if(!oticas.length) return '';
  return `<label>Ótica parceira que indicou <span style="font-weight:400;color:var(--ink-soft);">(opcional)</span></label><select id="${id}"><option value="">Nenhuma</option>${oticas.map(o=>`<option value="${o.id}">${esc(o.nome)}</option>`).join('')}</select>`;
}

let retornosMeses = 12, aniversarioMes = new Date().getMonth()+1;
async function renderRetornos(main){
  main.innerHTML = `
    <div class="card"><h2>Retorno vencido</h2>
      <p class="sub">Pacientes que fizeram exame há mais tempo e não têm nada marcado.</p>
      <label>Último exame há mais de</label>
      <select id="retMeses" style="max-width:200px;">${[6,12,18,24].map(m=>`<option value="${m}" ${m===retornosMeses?'selected':''}>${m} meses</option>`).join('')}</select>
      <div id="retLista"><p class="sub">Carregando...</p></div></div>
    <div class="card"><h2>Aniversariantes</h2>
      <label>Mês</label>
      <select id="aniMes" style="max-width:200px;">${['Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'].map((n,i)=>`<option value="${i+1}" ${i+1===aniversarioMes?'selected':''}>${n}</option>`).join('')}</select>
      <div id="aniLista"><p class="sub">Carregando...</p></div></div>`;
  document.getElementById('retMeses').onchange = e=>{ retornosMeses = +e.target.value; carregarRetornos(); };
  document.getElementById('aniMes').onchange = e=>{ aniversarioMes = +e.target.value; carregarAniversarios(); };
  carregarRetornos(); carregarAniversarios();
}
const primeiroNome = n=> (n||'').trim().split(/\s+/)[0];
async function carregarRetornos(){
  const box = document.getElementById('retLista'); if(!box) return;
  try{
    const lista = await api(`/relatorios/retornos?meses=${retornosMeses}`);
    if(!lista.length){ box.innerHTML = '<div class="empty"><div class="ic">✅</div>Nenhum retorno vencido.</div>'; return; }
    box.innerHTML = lista.map((r,i)=>`<div class="list-item"><div><div class="name">${esc(r.nome_completo)}</div><div class="meta">Último exame: ${fmtData(r.ultimo_exame)} · ${esc(r.telefone||'sem telefone')}</div></div><button class="btn btn-wpp btn-sm" data-i="${i}">WhatsApp</button></div>`).join('');
    box.querySelectorAll('button[data-i]').forEach(b=> b.onclick = ()=>{
      const r = lista[+b.dataset.i];
      abrirWhatsapp(r.telefone, `Olá, ${primeiroNome(r.nome_completo)}! Aqui é da ${clinicaAtual?.nome_fantasia||'clínica'}. Já faz mais de ${retornosMeses} meses do seu último exame de vista. Quer marcar seu retorno?`);
    });
  }catch(e){ box.innerHTML = `<p class="fieldmsg bad">${esc(e.message)}</p>`; }
}
async function carregarAniversarios(){
  const box = document.getElementById('aniLista'); if(!box) return;
  try{
    const lista = await api(`/relatorios/aniversariantes?mes=${aniversarioMes}`);
    if(!lista.length){ box.innerHTML = '<div class="empty"><div class="ic">🎂</div>Nenhum aniversariante neste mês. Cadastre a data de nascimento dos pacientes.</div>'; return; }
    box.innerHTML = lista.map((r,i)=>`<div class="list-item"><div><div class="name">${esc(r.nome_completo)}</div><div class="meta">Dia ${r.data_nascimento.slice(8,10)} · ${esc(r.telefone||'sem telefone')}</div></div><button class="btn btn-wpp btn-sm" data-i="${i}">Parabenizar</button></div>`).join('');
    box.querySelectorAll('button[data-i]').forEach(b=> b.onclick = ()=>{
      const r = lista[+b.dataset.i];
      abrirWhatsapp(r.telefone, `Olá, ${primeiroNome(r.nome_completo)}! A equipe da ${clinicaAtual?.nome_fantasia||'clínica'} deseja um feliz aniversário, com muita saúde e boa visão!`);
    });
  }catch(e){ box.innerHTML = `<p class="fieldmsg bad">${esc(e.message)}</p>`; }
}

/* ========================= CONFIRMAÇÃO DO DIA ========================= */
/* ========================= PRONTUÁRIO (só profissional/admin) ========================= */
let prontuarioState = { pacienteId:'', lista:[] };
let gabaritoAtual = gabaritoVazio();
let gabaritoAberto = false; // só mostra o bloco grande quando o profissional pedir
let meuCarimbo = null; // dados de carimbo/assinatura do profissional logado, pro gabarito impresso

function linhaAcuidadeHtml(olho, i, linha){
  const campo = olho==='od' ? gabaritoAtual.linhasOD : gabaritoAtual.linhasOE;
  const v = campo[i];
  return `<div class="gab-linha">
    <span class="gab-linha-faixa">${i+1} - ${linha.faixa}</span>
    <span class="gab-linha-letras">${linha[olho]}</span>
    <label class="gab-radio"><input type="radio" name="gab_${olho}_${i}" value="acertou" ${v===true?'checked':''}> Acertou</label>
    <label class="gab-radio"><input type="radio" name="gab_${olho}_${i}" value="errou" ${v===false?'checked':''}> Errou</label>
  </div>`;
}

function gabaritoHtml(){
  const g = gabaritoAtual;
  return `
    <div class="gab-wrap">
      <h3 style="font-size:14px;margin-top:14px;">Identificação</h3>
      <label>Idade do paciente</label>
      <input type="text" inputmode="numeric" id="gIdade" value="${g.idadePaciente}" style="max-width:120px;">
      <p class="sub" style="margin:4px 0 0;">Dados de empresa, só pra exame admissional; deixe em branco se não for o caso.</p>
      <div class="row3">
        <div><label>Empresa</label><input type="text" id="gEmpresa" value="${g.empresa}"></div>
        <div><label>Função</label><input type="text" id="gFuncao" value="${g.funcao}"></div>
        <div><label>Setor</label><input type="text" id="gSetor" value="${g.setor}"></div>
      </div>

      <h3 style="font-size:14px;margin-top:14px;">Questionário</h3>
      <label>Usa óculos?</label>
      <select id="gUsaOculos"><option value="">Selecione...</option><option value="Sim" ${g.usaOculos==='Sim'?'selected':''}>Sim</option><option value="Não" ${g.usaOculos==='Não'?'selected':''}>Não</option></select>
      <label>Frequência</label>
      <select id="gFrequencia"><option value="">Selecione...</option>${['Sempre','Algumas vezes','Só para leitura'].map(o=>`<option ${g.frequenciaUso===o?'selected':''}>${o}</option>`).join('')}</select>
      <label>Tipo de lente atual</label>
      <select id="gTipoLenteAtual"><option value="">Selecione...</option>${['Visão simples','Multifocal','Bifocal','Lente de contato'].map(o=>`<option ${g.tipoLenteAtual===o?'selected':''}>${o}</option>`).join('')}</select>
      <div class="row2">
        <div><label>Há quanto tempo usa os óculos atuais</label><input type="text" id="gTempoUso" value="${g.tempoUsoAtual}" placeholder="Ex: 2 anos"></div>
        <div><label>Última consulta com especialista</label><input type="text" id="gUltimaConsulta" value="${g.ultimaConsultaEspecialista}" placeholder="Ex: há 1 ano"></div>
      </div>
      <label>Já fez exame com especialista em visão?</label>
      <select id="gJaFezExame"><option value="">Selecione...</option><option ${g.jaFezExameEspecialista==='Sim'?'selected':''}>Sim</option><option ${g.jaFezExameEspecialista==='Não'?'selected':''}>Não</option></select>
      <div class="row2">
        <div><label>Possui doença ocular?</label><select id="gPossuiDoenca"><option value="">Selecione...</option><option ${g.possuiDoencaOcular==='Sim'?'selected':''}>Sim</option><option ${g.possuiDoencaOcular==='Não'?'selected':''}>Não</option></select></div>
        <div><label>Qual</label><input type="text" id="gDoencaQual" value="${g.doencaOcularQual}"></div>
      </div>
      <div class="row2">
        <div><label>Sente dificuldade visual?</label><select id="gDificuldade"><option value="">Selecione...</option><option ${g.senteDificuldadeVisual==='Sim'?'selected':''}>Sim</option><option ${g.senteDificuldadeVisual==='Não'?'selected':''}>Não</option></select></div>
        <div><label>Qual (longe, perto, noite, cores...)</label><input type="text" id="gDificuldadeQual" value="${g.dificuldadeQual}"></div>
      </div>

      <h3 style="font-size:14px;margin-top:14px;">Teste de longe</h3>
      <label>Realizado</label>
      <select id="gComCorrecao"><option value="">Selecione...</option><option value="Com lentes corretivas" ${g.testeComCorrecao==='Com lentes corretivas'?'selected':''}>Com lentes corretivas</option><option value="Sem lentes corretivas" ${g.testeComCorrecao==='Sem lentes corretivas'?'selected':''}>Sem lentes corretivas</option></select>

      <div class="gab-olho-titulo">Olho direito (OD)</div>
      ${LINHAS_ACUIDADE.map((l,i)=>linhaAcuidadeHtml('od',i,l)).join('')}
      <label>Resultado OD <span style="font-weight:400;color:var(--ink-soft);">(20/___)</span></label>
      <input type="text" id="gResultadoOD" value="${g.resultadoOD}" placeholder="Ex: 40">

      <div class="gab-olho-titulo">Olho esquerdo (OE)</div>
      ${LINHAS_ACUIDADE.map((l,i)=>linhaAcuidadeHtml('oe',i,l)).join('')}
      <label>Resultado OE <span style="font-weight:400;color:var(--ink-soft);">(20/___)</span></label>
      <input type="text" id="gResultadoOE" value="${g.resultadoOE}" placeholder="Ex: 40">

      <h3 style="font-size:14px;margin-top:14px;">Resumo do exame</h3>
      <label>AV longe sem correção (OD / OE / AO)</label>
      <div class="row3">
        <input type="text" id="gAvSemOD" value="${g.avLongeSemOD}" placeholder="20/__">
        <input type="text" id="gAvSemOE" value="${g.avLongeSemOE}" placeholder="20/__">
        <input type="text" id="gAvSemAO" value="${g.avLongeSemAO}" placeholder="20/__">
      </div>
      <label>AV longe com correção (OD / OE / AO)</label>
      <div class="row3">
        <input type="text" id="gAvComOD" value="${g.avLongeComOD}" placeholder="20/__">
        <input type="text" id="gAvComOE" value="${g.avLongeComOE}" placeholder="20/__">
        <input type="text" id="gAvComAO" value="${g.avLongeComAO}" placeholder="20/__">
      </div>
      <label>AV perto, Jaeger (OD / OE / AO)</label>
      <div class="row3">
        <input type="text" id="gAvPertoOD" value="${g.avPertoOD}" placeholder="J__">
        <input type="text" id="gAvPertoOE" value="${g.avPertoOE}" placeholder="J__">
        <input type="text" id="gAvPertoAO" value="${g.avPertoAO}" placeholder="J__">
      </div>

      <label>Teste de cores (Ishihara)</label>
      <div class="row2">
        <select id="gTesteCores"><option value="">Selecione...</option>${['Normal','Alterado','Não realizado'].map(o=>`<option ${g.testeCores===o?'selected':''}>${o}</option>`).join('')}</select>
        <input type="text" id="gTesteCoresAcertos" value="${g.testeCoresAcertos}" placeholder="Acertos, ex: 8/10">
      </div>

      <label>Conduta</label>
      <select id="gConduta"><option value="">Selecione...</option>${['Visão dentro do padrão','Indicada correção óptica','Encaminhar ao oftalmologista'].map(o=>`<option ${g.condutaGabarito===o?'selected':''}>${o}</option>`).join('')}</select>
      <label>Observações do gabarito</label>
      <textarea id="gObservacoes">${g.observacoesGabarito}</textarea>

      <button type="button" class="btn btn-ghost btn-block" id="btnImprimirGabarito" style="margin-top:12px;">Imprimir gabarito</button>
      <p class="sub" style="margin-top:6px;">Este exame é uma triagem de acuidade visual. Não substitui consulta com oftalmologista. A aptidão para a função cabe ao médico do trabalho.</p>
    </div>`;
}

/* Gabarito impresso de propósito SEM logo nem nome da clínica: é um documento de
   exame de acuidade visual, usado inclusive pra admissão em empresa, e não é um
   serviço comercial da loja. Só identifica o profissional que assina. */
function gerarHtmlGabarito(paciente){
  const g = gabaritoAtual;
  const linha = (olho,i)=>{
    const v = olho==='od'?g.linhasOD[i]:g.linhasOE[i];
    return `${LINHAS_ACUIDADE[i].faixa}: ${v===true?'Acertou':v===false?'Errou':'-'}`;
  };
  // examinador é quem está logado fazendo o exame agora, não o profissional
  // escolhido na tela de Receita (são contextos diferentes)
  const dadosExaminador = meuCarimbo || (usuarioAtual?.papel==='profissional' ? { nome: usuarioAtual.nome } : null);
  const examinador = dadosExaminador ? `${dadosExaminador.carimbo_texto||dadosExaminador.nome}${dadosExaminador.registro_conselho?' — '+dadosExaminador.registro_conselho:''}` : '____________________';
  return `<h2>Gabarito do Exame de Acuidade Visual</h2>
    <pre style="white-space:pre-wrap;font-family:inherit;">Nome: ${paciente?.nome_completo||''}
Idade: ${g.idadePaciente||'-'}    Data: ${fmtData(hojeISO())}
Empresa: ${g.empresa||'-'}    Função: ${g.funcao||'-'}    Setor: ${g.setor||'-'}

QUESTIONÁRIO
Usa óculos: ${g.usaOculos||'-'}    Frequência: ${g.frequenciaUso||'-'}    Tipo de lente: ${g.tipoLenteAtual||'-'}
Tempo de uso dos óculos atuais: ${g.tempoUsoAtual||'-'}    Última consulta com especialista: ${g.ultimaConsultaEspecialista||'-'}
Já fez exame com especialista: ${g.jaFezExameEspecialista||'-'}
Possui doença ocular: ${g.possuiDoencaOcular||'-'}  Qual: ${g.doencaOcularQual||'-'}
Sente dificuldade visual: ${g.senteDificuldadeVisual||'-'}  Qual: ${g.dificuldadeQual||'-'}

TESTE DE LONGE (${g.testeComCorrecao||'não informado'})
OD: ${LINHAS_ACUIDADE.map((_,i)=>linha('od',i)).join(' | ')}
Resultado OD: 20/${g.resultadoOD||'___'}

OE: ${LINHAS_ACUIDADE.map((_,i)=>linha('oe',i)).join(' | ')}
Resultado OE: 20/${g.resultadoOE||'___'}

RESUMO DO EXAME
AV longe sem correção — OD: ${g.avLongeSemOD||'-'}  OE: ${g.avLongeSemOE||'-'}  AO: ${g.avLongeSemAO||'-'}
AV longe com correção — OD: ${g.avLongeComOD||'-'}  OE: ${g.avLongeComOE||'-'}  AO: ${g.avLongeComAO||'-'}
AV perto (Jaeger) — OD: ${g.avPertoOD||'-'}  OE: ${g.avPertoOE||'-'}  AO: ${g.avPertoAO||'-'}
Teste de cores (Ishihara): ${g.testeCores||'-'}    Acertos: ${g.testeCoresAcertos||'-'}

Conduta: ${g.condutaGabarito||'-'}
Observações: ${g.observacoesGabarito||'-'}</pre>
    <div style="margin-top:34px;display:flex;justify-content:space-between;gap:20px;">
      <div style="flex:1;text-align:center;padding-top:10px;border-top:1px solid #999;">${examinador}<br><span style="font-size:11px;color:#666;">Examinador(a) / registro</span></div>
      <div style="flex:1;text-align:center;padding-top:10px;border-top:1px solid #999;">&nbsp;<br><span style="font-size:11px;color:#666;">Assinatura do(a) examinado(a)</span></div>
    </div>
    <p style="font-size:11px;color:#666;margin-top:14px;">Este exame é uma triagem de acuidade visual. Não substitui consulta com oftalmologista. A aptidão para a função cabe ao médico do trabalho.</p>`;
}

/*VOZ-INICIO*/
/* ===== Comando de voz no exame: transforma o que o profissional fala em valores nos campos ===== */
const VOZ_NUM = { zero:0, um:1, uma:1, dois:2, duas:2, tres:3, quatro:4, cinco:5, seis:6, sete:7, oito:8, nove:9, dez:10, onze:11, doze:12, treze:13, quatorze:14, catorze:14, quinze:15, dezesseis:16, dezessete:17, dezoito:18, dezenove:19 };
const VOZ_DEZ = { vinte:20, trinta:30, quarenta:40, cinquenta:50, sessenta:60, setenta:70, oitenta:80, noventa:90 };
const VOZ_CENT = { cem:100, cento:100, duzentos:200, trezentos:300 };
function vozLimpar(t){
  return String(t||'').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g,'')
    .replace(/(\d),(\d)/g,'$1.$2').replace(/[^a-z0-9.+\- ]/g,' ').replace(/\s+/g,' ').trim().split(' ').filter(Boolean);
}
const vozEhNum = (t)=> /^[+-]?\d+(\.\d+)?$/.test(t);
/* lê um inteiro por extenso ou em dígitos a partir da posição i. Devolve {v, p} ou null */
function vozInteiro(tk, i){
  const t = tk[i]; if(t===undefined) return null;
  if(/^\d+$/.test(t)) return { v:parseInt(t,10), p:i+1 };
  let v = 0, p = i, achou = false;
  if(VOZ_CENT[tk[p]]!==undefined){ v += VOZ_CENT[tk[p]]; p++; achou = true; if(tk[p]==='e' && (VOZ_DEZ[tk[p+1]]!==undefined || VOZ_NUM[tk[p+1]]!==undefined)) p++; }
  if(VOZ_DEZ[tk[p]]!==undefined){ v += VOZ_DEZ[tk[p]]; p++; achou = true; if(tk[p]==='e' && VOZ_NUM[tk[p+1]]!==undefined && VOZ_NUM[tk[p+1]]>0 && VOZ_NUM[tk[p+1]]<10){ v += VOZ_NUM[tk[p+1]]; p += 2; } }
  else if(VOZ_NUM[tk[p]]!==undefined && !(achou && v>0 && VOZ_NUM[tk[p]]>=10)){ v += VOZ_NUM[tk[p]]; p++; achou = true; }
  return achou ? { v, p } : null;
}
/* lê um grau (com sinal e decimais). Ex.: "menos um e vinte e cinco" = -1.25 */
function vozGrau(tk, i){
  let p = i, sinal = 1, temSinal = false;
  while(['mais','menos','positivo','negativo'].includes(tk[p])){ sinal = (tk[p]==='menos'||tk[p]==='negativo') ? -1 : 1; temSinal = true; p++; }
  if(['plano','neutro'].includes(tk[p])) return { v:0, p:p+1 };
  if(tk[p]==='meio' || tk[p]==='meia'){ return { v:sinal*0.5, p:p+1 }; }
  let t = tk[p];
  if(t!==undefined && vozEhNum(t) && /[.]/.test(t)){ const n = parseFloat(t); return { v:(/^[+-]/.test(t) ? n : sinal*n), p:p+1 }; }
  if(t!==undefined && /^[+-]\d+$/.test(t)){ sinal = t[0]==='-' ? -1 : 1; tk = tk.slice(); tk[p] = t.slice(1); temSinal = true; }
  const n1 = vozInteiro(tk, p); if(!n1) return null;
  let v = n1.v; p = n1.p;
  let decimal = null;
  if(tk[p]==='virgula' || tk[p]==='ponto'){
    const d = vozInteiro(tk, p+1);
    if(d){ decimal = d.v<10 ? d.v/10 : d.v/100; p = d.p; }
  } else if(tk[p]==='e' && (tk[p+1]==='meio' || tk[p+1]==='meia')){ decimal = 0.5; p += 2; }
  else if(tk[p]==='e'){ const d = vozInteiro(tk, p+1); if(d && [25,50,75].includes(d.v)){ decimal = d.v/100; p = d.p; } }
  else { const d = vozInteiro(tk, p); if(d && [25,50,75].includes(d.v) && !['mais','menos'].includes(tk[p-1])){ decimal = d.v/100; p = d.p; } }
  if(decimal===null && v>=25 && v%25===0) v = v/100; // "menos cinquenta" = -0,50
  return { v: sinal*(v + (decimal||0)), p };
}
const vozFmtGrau = (v)=> (v>0?'+':'')+v.toFixed(2);
const VOZ_CAMPOS = { ar:['Esf','Cil','Eixo'], fn:['Esf','Cil','Eixo','Add'] };
const VOZ_ROTULO = { Esf:'esférico', Cil:'cilíndrico', Eixo:'eixo', Add:'adição' };
function vozEstadoNovo(etapa){ return { olho:null, grupo: etapa===2 ? 'av' : 'ar', idx:0, avSub:'ls', avDist:'longe' }; }

/* interpreta uma frase. est guarda o contexto (olho, grupo, campo) entre uma frase e outra */
function vozInterpretar(texto, est){
  const tk = vozLimpar(texto);
  const out = { acoes:[], cmd:null, avisos:[] };
  const add = (id, valor, rot)=>{ out.acoes.push({ id, valor, texto:rot+': '+valor }); };
  let i = 0;
  while(i<tk.length){
    const t = tk[i];
    // comandos de tela
    if((t==='proxima'||t==='proximo'||t==='avancar') && (tk.length<=2 || tk[i+1]==='etapa' || tk[i+1]==='passo')){ out.cmd='proximo'; i++; continue; }
    if((t==='voltar'||t==='anterior') && (tk.length<=2 || tk[i+1]==='etapa' || tk[i+1]==='passo')){ out.cmd='voltar'; i++; continue; }
    if(t==='etapa'||t==='passo'){ i++; continue; }
    // observação: o resto da frase é texto livre
    if(['observacao','observacoes','obs','anotacao'].includes(t)){
      const resto = String(texto).split(/observa[cç][aã]o|observa[cç][oõ]es|anota[cç][aã]o|obs\b/i).slice(1).join(' ').trim();
      if(resto) add('tsObs', resto, 'Observação');
      break;
    }
    // grupos
    if(['autorrefrator','autorefrator','refrator','auto'].includes(t)){ est.grupo='ar'; est.idx=0; i++; continue; }
    if(['final','confirmado','definitivo'].includes(t)){ est.grupo='fn'; est.idx=0; i++; continue; }
    if(t==='acuidade'){ est.grupo='av'; i++; continue; }
    if(t==='longe'){ est.grupo='av'; est.avDist='longe'; i++; continue; }
    if(t==='perto'){ est.grupo='av'; est.avDist='perto'; est.avSub='ps'; i++; continue; }
    if(['pinhole','furo','buraco'].includes(t)){ est.grupo='av'; est.avDist='longe'; est.avSub='ph'; i++; continue; }
    if(est.grupo==='av' && (t==='sem'||t==='com') && ['oculos','correcao','lentes'].includes(tk[i+1])){ est.avSub = (est.avDist==='perto' ? (t==='sem'?'ps':'pc') : (t==='sem'?'ls':'lc')); i += 2; continue; }
    if(['pressao','tonometria','pio'].includes(t)){ est.grupo='pio'; i++; continue; }
    if(['ppc','convergencia'].includes(t)){ est.grupo='ppc'; i++; continue; }
    if(['movimento','motilidade','pupilas','cores'].includes(t)){
      const alvo = tk[i+1];
      const mapa = { movimento:['tsMotil','Movimento dos olhos'], motilidade:['tsMotil','Movimento dos olhos'], pupilas:['tsPupilas','Pupilas'], cores:['tsCores','Visão de cores'] }[t];
      const normal = ['normal','normais'].includes(alvo), alterado = ['alterado','alterada','alterados','alteradas'].includes(alvo);
      if(normal||alterado){ const v = t==='pupilas' ? (normal?'Normais':'Alteradas') : t==='cores' ? (normal?'Normal':'Alterada') : (normal?'Normal':'Alterado'); add(mapa[0], v, mapa[1]); i += 2; continue; }
      if(t==='cores' && (alvo==='nao'||alvo==='sem') ){ add('tsCores','Não testado','Visão de cores'); i += 2; continue; }
      i++; continue;
    }
    // olho
    if(['direito','od','direita'].includes(t) || (t==='o' && tk[i+1]==='d')){ est.olho='Od'; est.idx=0; i += (t==='o'?2:1); if(tk[i]==='olho') i++; continue; }
    if(['esquerdo','oe','esquerda'].includes(t) || (t==='o' && tk[i+1]==='e')){ est.olho='Oe'; est.idx=0; i += (t==='o'?2:1); continue; }
    if(t==='olho'||t==='ambos'||t==='do'||t==='no'||t==='de'||t==='o'||t==='e'){ i++; continue; }
    // campos
    const mc = { esferico:'Esf', esfera:'Esf', esf:'Esf', cilindrico:'Cil', cilindro:'Cil', cil:'Cil', eixo:'Eixo', adicao:'Add', add:'Add' }[t];
    if(mc){ const lista = VOZ_CAMPOS[est.grupo]; if(lista){ const k = lista.indexOf(mc); if(k>=0) est.idx = k; } i++; continue; }
    // valores
    if(est.grupo==='ar' || est.grupo==='fn'){
      const lista = VOZ_CAMPOS[est.grupo];
      const campo = lista[est.idx];
      if(!campo){ i++; continue; }
      if(!est.olho){ if(vozGrau(tk, i)) out.avisos.push('Diga o olho: direito ou esquerdo.'); i++; continue; }
      if(campo==='Eixo'){
        const n = vozInteiro(tk, i);
        if(n){ if(n.v>=0 && n.v<=180){ add(`${est.grupo}${est.olho}Eixo`, String(n.v), `${est.grupo==='ar'?'Autorrefrator':'Grau final'} ${est.olho.toUpperCase()} eixo`); est.idx++; } else out.avisos.push('Eixo precisa ficar entre 0 e 180.'); i = n.p; continue; }
      } else {
        const g = vozGrau(tk, i);
        if(g){
          const lim = campo==='Cil' ? 10 : 30;
          if(Math.abs(g.v)>lim){ out.avisos.push(`Valor fora do normal: ${vozFmtGrau(g.v)}. Repita.`); }
          else { add(`${est.grupo}${est.olho}${campo}`, vozFmtGrau(g.v), `${est.grupo==='ar'?'Autorrefrator':'Grau final'} ${est.olho.toUpperCase()} ${VOZ_ROTULO[campo]}`);
            if(campo==='Cil' && g.v===0 && lista[est.idx+1]==='Eixo'){ est.idx += 2; } else est.idx++; }
          i = g.p; continue;
        }
      }
      i++; continue;
    }
    if(est.grupo==='av'){
      if(est.avDist==='perto'){
        let j = i; if(tk[j]==='j'||tk[j]==='jota') j++;
        else if(/^j\d+$/.test(tk[j])){ add(est.avSub==='pc'?'avPcAo':'avPsAo', tk[j].toUpperCase(), 'Perto'); i++; continue; }
        const n = vozInteiro(tk, j);
        if(n && n.v>=1 && n.v<=16 && j>i){ add(est.avSub==='pc'?'avPcAo':'avPsAo', 'J'+n.v, 'Perto '+(est.avSub==='pc'?'com':'sem')+' óculos'); i = n.p; continue; }
        i++; continue;
      }
      if(!est.olho){ out.avisos.push('Diga o olho: direito ou esquerdo.'); i++; continue; }
      const a = vozInteiro(tk, i);
      if(a){
        const b = vozInteiro(tk, a.p);
        const rot = {ls:'Longe sem óculos',lc:'Longe com óculos',ph:'Pinhole'}[est.avSub]||'Acuidade';
        if(b && a.v<=40 && b.v>=10){ add(`av${est.avSub.charAt(0).toUpperCase()+est.avSub.slice(1)}${est.olho}`, `${a.v}/${b.v}`, rot+' '+est.olho.toUpperCase()); i = b.p; }
        else { out.avisos.push('Acuidade: fale dois números, por exemplo vinte quarenta.'); i = a.p; }
        continue;
      }
      i++; continue;
    }
    if(est.grupo==='pio'){
      const n = vozInteiro(tk, i);
      if(n){ if(!est.olho) out.avisos.push('Diga o olho: direito ou esquerdo.'); else if(n.v>=5 && n.v<=80) add('tsPio'+est.olho, String(n.v), 'Pressão '+est.olho.toUpperCase()); else out.avisos.push('Pressão fora do normal: '+n.v); i = n.p; continue; }
    }
    if(est.grupo==='ppc'){
      const n = vozInteiro(tk, i);
      if(n){ add('tsPPC', String(n.v), 'Ponto de convergência'); i = n.p; continue; }
    }
    i++;
  }
  return out;
}
/*VOZ-FIM*/

/* botão de microfone e painel do comando de voz (aparece só na tela de exame) */
function pararVozExame(){
  try{ if(window._vzRec){ window._vzAtivo=false; window._vzRec.onend=null; window._vzRec.stop(); } }catch(e){}
  window._vzRec=null; window._vzAtivo=false;
  document.getElementById('vzFab')?.remove(); document.getElementById('vzPainel')?.remove();
  pararTecladoGrau();
}

/* ---- teclado numérico do app para o grau (voz ou teclado, os dois funcionam juntos) ----
   O teclado decimal do Android quase nunca tem o sinal de menos. Este tem +/−, passo de 0,25
   e vai de campo em campo. Dá para desligar no botão 🔢 e usar o teclado do celular. */
const TC_CAMPOS = ['arOdEsf','arOdCil','arOdEixo','arOeEsf','arOeCil','arOeEixo','fnOdEsf','fnOdCil','fnOdEixo','fnOdAdd','fnOeEsf','fnOeCil','fnOeEixo','fnOeAdd'];
const TC_ROTULO = { Esf:'esférico', Cil:'cilíndrico', Eixo:'eixo', Add:'adição' };
function tcFormatar(id, bruto){
  let v = String(bruto||'').trim().replace(',', '.');
  if(!v || v==='-' || v==='+') return '';
  const n = parseFloat(v); if(isNaN(n)) return '';
  if(/Eixo$/.test(id)) return String(Math.max(0, Math.min(180, Math.round(Math.abs(n)))));
  const x = /Add$/.test(id) ? Math.abs(n) : n;
  return (x>0?'+':'') + x.toFixed(2);
}
function pararTecladoGrau(){
  if(window._tcFoco) document.removeEventListener('focusin', window._tcFoco, true);
  if(window._tcFora) document.removeEventListener('click', window._tcFora, true);
  window._tcFoco = window._tcFora = null;
  document.getElementById('tcFab')?.remove(); document.getElementById('tcPainel')?.remove();
  document.body.classList.remove('tc-aberto');
}
function iniciarTecladoGrau(ap){
  pararTecladoGrau();
  const guardar = (k,v)=>{ try{ localStorage.setItem(k,v); }catch(e){} };
  const ler = k=>{ try{ return localStorage.getItem(k); }catch(e){ return null; } };
  let ativo = ler('agend_teclado_grau') !== '0', alvo = null;
  const fab = document.createElement('button'); fab.id='tcFab'; fab.type='button'; fab.textContent='🔢'; fab.setAttribute('aria-label','Teclado numérico do aplicativo');
  const painel = document.createElement('div'); painel.id='tcPainel'; painel.style.display='none';
  const T = (k,t,cl)=>`<button type="button" class="tc-k ${cl||''}" data-k="${k}">${t}</button>`;
  painel.innerHTML = '<div class="tc-topo"><b id="tcNome"></b><span><button type="button" class="tc-fechar" data-k="voz" aria-label="Falar os valores">🎤 Voz</button><button type="button" class="tc-fechar" data-k="fechar" aria-label="Fechar teclado">Fechar ✕</button></span></div><div class="tc-grade">'
    + T('7','7')+T('8','8')+T('9','9')+T('back','⌫','tc-sec')
    + T('4','4')+T('5','5')+T('6','6')+T('sinal','+/−','tc-sec')
    + T('1','1')+T('2','2')+T('3','3')+T('ponto',',','tc-sec')
    + T('0','0')+T('dec25',',25','tc-sec')+T('dec50',',50','tc-sec')+T('dec75',',75','tc-sec')
    + T('menos','−0,25','tc-sec')+T('mais','+0,25','tc-sec')+T('prox','Próximo campo ›','tc-ok tc-largo')
    + '</div>';
  document.body.append(painel, fab);
  const camposVisiveis = ()=> TC_CAMPOS.map(id=>document.getElementById(id)).filter(Boolean);
  function modoInput(){ camposVisiveis().forEach(el=>{ el.setAttribute('inputmode', ativo ? 'none' : (/Eixo$/.test(el.id)?'numeric':'decimal')); }); }
  function disparar(el){ el.dispatchEvent(new Event('input',{bubbles:true})); }
  function nomeCampo(el){ const m = /^(ar|fn)(Od|Oe)(Esf|Cil|Eixo|Add)$/.exec(el.id); return m ? (m[2]==='Od'?'OD':'OE')+' '+TC_ROTULO[m[3]]+(m[1]==='ar'?' (autorrefrator)':' (grau final)') : ''; }
  function abrir(el){
    alvo = el; document.getElementById('tcNome').textContent = nomeCampo(el);
    painel.style.display = 'block'; document.body.classList.add('tc-aberto');
    const esp = document.getElementById('tcEspaco'); if(esp) esp.style.height = '340px';
    setTimeout(()=>{ try{ el.scrollIntoView({block:'center', behavior:'smooth'}); }catch(e){} }, 60);
    el.classList.add('tc-alvo'); camposVisiveis().forEach(x=>{ if(x!==el) x.classList.remove('tc-alvo'); });
  }
  function fechar(){
    if(alvo){ const f = tcFormatar(alvo.id, alvo.value); if(f!==alvo.value){ alvo.value = f; disparar(alvo); } }
    painel.style.display='none'; document.body.classList.remove('tc-aberto');
    const esp = document.getElementById('tcEspaco'); if(esp) esp.style.height='0';
    camposVisiveis().forEach(x=>x.classList.remove('tc-alvo')); alvo = null;
  }
  function tocar(k){
    if(k==='voz'){ document.getElementById('vzFab')?.click(); return; }
    if(k==='fechar'){ fechar(); if(document.activeElement && document.activeElement.blur) document.activeElement.blur(); return; }
    const el = alvo; if(!el) return;
    if(k==='prox'){
      const f = tcFormatar(el.id, el.value); if(f!==el.value){ el.value = f; disparar(el); }
      const lista = camposVisiveis(), i = lista.indexOf(el);
      if(i>=0 && i<lista.length-1){ const prox = lista[i+1]; prox.focus(); abrir(prox); } else fechar();
      return;
    }
    const eixo = /Eixo$/.test(el.id), soAdd = /Add$/.test(el.id);
    let v = el.value;
    if(k==='back') v = v.slice(0,-1);
    else if(k==='sinal'){ if(eixo || soAdd) return; v = v.startsWith('-') ? '+'+v.slice(1) : v.startsWith('+') ? '-'+v.slice(1) : '-'+v; }
    else if(k==='ponto'){ if(eixo || v.includes('.')) return; if(!v || v==='-' || v==='+') v += '0'; v += '.'; }
    else if(/^dec(25|50|75)$/.test(k)){ if(eixo) return; const base = v.includes('.') ? v.slice(0, v.indexOf('.')) : v; v = ((!base || base==='-' || base==='+') ? base+'0' : base) + '.' + k.slice(3); }
    else if(k==='mais' || k==='menos'){
      if(eixo){ const n = parseInt(v||'0',10) + (k==='mais'?1:-1); v = String(Math.max(0, Math.min(180, n))); }
      else { const n = (parseFloat(v.replace(',', '.')) || 0) + (k==='mais'?0.25:-0.25); v = tcFormatar(el.id, String(Math.round(n*100)/100)) || (soAdd?'':'0.00'); }
    }
    else if(/^\d$/.test(k)){
      if(eixo){ if((v+k).length>3 || +(v+k)>180) return; v += k; }
      else { const i = v.indexOf('.'); if(i>=0){ if(v.length-i>2) return; } else if(v.replace(/[-+]/,'').length>=2) return; v += k; }
    } else return;
    el.value = v; disparar(el);
  }
  painel.addEventListener('mousedown', e=> e.preventDefault());
  painel.addEventListener('click', e=>{ const b = e.target.closest('[data-k]'); if(b) tocar(b.dataset.k); });
  window._tcFoco = e=>{ const el = e.target; if(ativo && ap.etapa()===3 && TC_CAMPOS.includes(el.id)) abrir(el); };
  window._tcFora = e=>{ if(painel.style.display==='none') return; if(painel.contains(e.target) || fab.contains(e.target) || TC_CAMPOS.includes(e.target.id)) return; fechar(); };
  document.addEventListener('focusin', window._tcFoco, true);
  document.addEventListener('click', window._tcFora, true);
  TC_CAMPOS.forEach(id=>{ const el = document.getElementById(id); if(el) el.addEventListener('change', ()=>{ const f = tcFormatar(id, el.value); if(f!==el.value) el.value = f; }); });
  function pintarFab(){ fab.classList.toggle('on', ativo); fab.title = ativo ? 'Teclado do aplicativo ligado. Toque para usar o teclado do celular.' : 'Teclado do celular. Toque para usar o teclado do aplicativo.'; }
  fab.onclick = ()=>{ ativo = !ativo; guardar('agend_teclado_grau', ativo?'1':'0'); modoInput(); pintarFab(); if(!ativo) fechar(); toast(ativo ? 'Teclado do aplicativo ligado.' : 'Teclado do celular ligado.'); };
  window.tecladoGrauEtapa = ()=>{ const e3 = ap.etapa()===3; fab.style.display = e3 ? '' : 'none'; if(!e3) fechar(); modoInput(); pintarFab(); };
  tecladoGrauEtapa();
}
function tecladoGrauEtapa(){ if(typeof window.tecladoGrauEtapa==='function' && window.tecladoGrauEtapa!==tecladoGrauEtapa) window.tecladoGrauEtapa(); }
function iniciarVozExame(ap){
  pararVozExame();
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  const fab = document.createElement('button'); fab.id='vzFab'; fab.type='button'; fab.textContent='🎤'; fab.setAttribute('aria-label','Falar os valores do exame');
  const painel = document.createElement('div'); painel.id='vzPainel'; painel.style.display='none';
  document.body.append(painel, fab);
  let est = vozEstadoNovo(ap.etapa()), chips = [], avisos = [], ouvido = '', status = '';
  const ETAPA_DO_CAMPO = (id)=> /^(ar|fn)/.test(id) ? 3 : /^av/.test(id) ? 2 : /^ts/.test(id) ? 4 : null;
  function desenhar(){
    painel.innerHTML = '<button type="button" class="vz-x" id="vzX" aria-label="Fechar">×</button>'
      + '<div class="vz-status">'+esc(status)+'</div>'
      + (ouvido ? '<div class="vz-ouvi">Ouvi: '+esc(ouvido)+'</div>' : '')
      + (chips.length ? '<div class="vz-chips">'+chips.slice(-6).map(c=>'<span>'+esc(c)+'</span>').join('')+'</div>' : '')
      + (avisos.length ? '<div class="vz-av">'+avisos.map(esc).join('<br>')+'</div>' : '')
      + '<div class="vz-dica">Exemplo: autorrefrator, olho direito, menos um e vinte e cinco, menos meio, eixo cento e oitenta. Diga "olho esquerdo" para trocar de olho, "grau final" para o grau confirmado, "próxima etapa" para avançar. O áudio é processado pelo navegador. Não fale nome nem CPF do paciente.</div>';
    painel.querySelector('#vzX').onclick = ()=>{ parar(); painel.style.display='none'; };
  }
  function aplicar(r, texto){
    r.acoes.forEach(a=>{
      const el = document.getElementById(a.id); if(!el) return;
      const et = ETAPA_DO_CAMPO(a.id); if(et && ap.etapa()!==et) ap.ir(et);
      if(el.tagName==='SELECT'){ const op = [...el.options].find(o=>o.text===a.valor || o.value===a.valor); if(op) el.value = op.value; }
      else if(a.id==='tsObs') el.value = (el.value ? el.value.trim()+' ' : '') + a.valor;
      else el.value = a.valor;
      el.dispatchEvent(new Event('input',{bubbles:true})); el.dispatchEvent(new Event('change',{bubbles:true}));
      el.classList.add('vz-ok'); setTimeout(()=>el.classList.remove('vz-ok'), 2500);
      chips.push(a.texto);
    });
    if(r.cmd==='proximo') ap.ir(ap.etapa()+1);
    if(r.cmd==='voltar') ap.ir(ap.etapa()-1);
    avisos = r.avisos.slice(); ouvido = texto;
    if(!r.acoes.length && !r.cmd && !r.avisos.length) avisos = ['Não entendi. Tente de novo.'];
    desenhar();
  }
  function iniciar(){
    if(!SR){ painel.style.display='block'; status='Este navegador não aceita comando de voz. Use o Chrome.'; desenhar(); return; }
    est = vozEstadoNovo(ap.etapa()); chips = []; avisos = []; ouvido = '';
    const rec = new SR(); rec.lang='pt-BR'; rec.continuous=true; rec.interimResults=true; rec.maxAlternatives=1;
    rec.onresult = (ev)=>{
      for(let i=ev.resultIndex;i<ev.results.length;i++){
        const res = ev.results[i], tx = res[0].transcript;
        if(res.isFinal) aplicar(vozInterpretar(tx, est), tx.trim());
        else { ouvido = tx.trim(); desenhar(); }
      }
    };
    rec.onerror = (e)=>{
      if(e.error==='not-allowed'||e.error==='service-not-allowed'){ status='Permita o microfone nas configurações do navegador.'; window._vzAtivo=false; fab.classList.remove('on'); desenhar(); }
      else if(e.error==='network'){ status='Sem internet para reconhecer a voz.'; desenhar(); }
    };
    rec.onend = ()=>{ if(window._vzAtivo){ try{ rec.start(); }catch(x){} } else fab.classList.remove('on'); };
    window._vzRec = rec; window._vzAtivo = true;
    try{ rec.start(); status='Ouvindo... fale os valores.'; fab.classList.add('on'); }catch(e){ status='Não consegui ligar o microfone.'; }
    painel.style.display='block'; desenhar();
  }
  function parar(){
    window._vzAtivo=false; try{ window._vzRec && window._vzRec.stop(); }catch(e){}
    fab.classList.remove('on'); status='Microfone desligado.'; desenhar();
  }
  fab.onclick = ()=>{ if(window._vzAtivo) parar(); else iniciar(); };
}

function renderProntuario(main){
  const souProfissional = usuarioAtual?.papel === 'profissional' || usuarioAtual?.papel === 'admin';
  if(!souProfissional){
    main.innerHTML = `<div class="card"><h2>Prontuário</h2><p class="sub">Essa área é só para o profissional que faz o exame.</p></div>`;
    return;
  }

  // dados de carimbo/assinatura de quem está logado, pro gabarito impresso puxar
  // o examinador certo (não o profissional escolhido lá na tela de Receita)
  if(usuarioAtual?.papel==='profissional' && !meuCarimbo){
    api('/clinica/usuarios/eu').then(u=> meuCarimbo = u).catch(()=>{});
  }

  // agenda por cidade: agrupa os próximos agendamentos por dia+cidade, pra ele
  // se preparar com antecedência pra onde vai estar e quem já tem marcado
  const hoje = hojeISO();
  const futuros = agendamentos.filter(a=> soData(a.data_hora) >= hoje && a.status!=='cancelado').sort((a,b)=> a.data_hora.localeCompare(b.data_hora));
  const grupos = {};
  futuros.forEach(a=>{
    const dia = soData(a.data_hora);
    const cidadeNome = unidades.find(u=>u.id===a.unidade_id)?.nome || 'Sem cidade definida';
    const chave = dia+'|'+cidadeNome;
    if(!grupos[chave]) grupos[chave] = { dia, cidadeNome, itens:[] };
    grupos[chave].itens.push(a);
  });
  const gruposOrdenados = Object.values(grupos).sort((a,b)=> a.dia.localeCompare(b.dia));

  const agendaHtml = gruposOrdenados.length ? gruposOrdenados.slice(0,15).map(g=>`
    <div class="agenda-cidade-item">
      <div class="agenda-cidade-head"><strong>${fmtData(g.dia)}</strong> · ${g.cidadeNome} <span style="color:var(--ink-soft);">(${g.itens.length} ${g.itens.length===1?'paciente':'pacientes'})</span></div>
      <div class="agenda-cidade-lista">${g.itens.map(a=>`<div class="agenda-item-abrir"><span>${soHora(a.data_hora)} — ${pacienteNome(a.paciente_id)}</span><button type="button" class="link-discreto btn-abrir-prontuario" data-paciente="${a.paciente_id}">abrir prontuário</button></div>`).join('')}</div>
    </div>`).join('') : '<p class="sub">Nenhum agendamento futuro ainda.</p>';

  const pacOpts = pacientes.map(p=>`<option value="${p.id}" ${prontuarioState.pacienteId===p.id?'selected':''}>${esc(p.nome_completo)}</option>`).join('');

  const sintomasHtml = LISTA_SINTOMAS.map((s,i)=>`
    <div class="sintoma-linha ${SINTOMAS_ALERTA.includes(s)?'alerta':''}">
      <span>${s}${SINTOMAS_ALERTA.includes(s)?' <small style="color:#B3261E;">(alerta)</small>':''}</span>
      <label class="sintoma-toggle"><input type="checkbox" class="pntSintoma" data-sintoma="${s}"><span class="sintoma-slider"></span></label>
    </div>`).join('');

  main.innerHTML = `
    <div class="card">
      <h2>Sua agenda por cidade</h2>
      <p class="sub">Veja com antecedência em qual cidade você vai estar e quem já está marcado, pra adiantar o preparo do exame.</p>
      ${agendaHtml}
    </div>
    <div class="card" id="pntCard">
      <h2>Atendimento</h2>
      <p class="sub">Essa área é só sua. Quem agenda não vê o que você escreve aqui.</p>
      <label class="req">Paciente</label>
      <select id="pntPac"><option value="">Selecione...</option>${pacOpts}</select>
      <div id="pntHistorico"></div>
      <div id="pntBanner"></div>
      <h3 style="margin-top:18px;font-size:15px;" id="pntTituloNovo">Novo exame</h3>
      <div class="passos" id="pntPassos">${['História','Visão atual','Grau','Outros testes','Alertas','Conclusão'].map((n,i)=>`<button type="button" class="passo" data-p="${i+1}"><span>${i+1}</span>${n}</button>`).join('')}</div>

      <div class="etapa" data-etapa="1">
        <label>Queixa principal <span style="font-weight:400;color:var(--ink-soft);">(o que o paciente relatou precisar ou sentir)</span></label>
        <textarea id="pntQueixa" placeholder="Ex: dificuldade pra ler de perto, dor de cabeça no fim do dia..."></textarea>
        <label style="margin-top:14px;">Sintomas <span style="font-weight:400;color:var(--ink-soft);">(marque o que o paciente apresenta)</span></label>
        <div class="sintomas-lista">${sintomasHtml}</div>
        <label>Outros sintomas</label>
        <textarea id="pntOutrosSintomas" placeholder="Algo que não está na lista..."></textarea>
        <h3 style="margin-top:18px;font-size:15px;">História do paciente <span style="font-weight:400;color:var(--ink-soft);font-size:12px;">(já vem da ficha. Confirme com o paciente)</span></h3>
        <label>Usa óculos ou lentes hoje?</label><input type="text" id="hxUsa" placeholder="Não usa, óculos, lentes...">
        <label>Último exame de vista</label><input type="text" id="hxUltimo" placeholder="Ex: há 2 anos">
        <label>Doenças <span style="font-weight:400;color:var(--ink-soft);">(diabetes, pressão alta e outras)</span></label><input type="text" id="hxDoencas">
        <label>Remédios que usa</label><input type="text" id="hxRemedios">
        <label>Alergias</label><input type="text" id="hxAlergias">
        <label>Casos na família <span style="font-weight:400;color:var(--ink-soft);">(glaucoma, catarata)</span></label><input type="text" id="hxFamilia">
        <label>Cirurgia nos olhos</label><input type="text" id="hxCirurgia">
        <label>Trabalho e uso de telas</label><input type="text" id="hxTrabalho" placeholder="Ex: escritório, 8 horas no computador">
      </div>

      <div class="etapa" data-etapa="2" style="display:none;">
        <h3 style="margin-top:6px;font-size:15px;">Acuidade visual <span style="font-weight:400;color:var(--ink-soft);font-size:12px;">(escreva como 20/40, 20/20)</span></h3>
        <div class="av-grade">
          <span></span><span class="refr-h">OD</span><span class="refr-h">OE</span>
          <span class="refr-l av-l">Longe sem óculos</span><input class="refr-in" id="avLsOd"><input class="refr-in" id="avLsOe">
          <span class="refr-l av-l">Longe com óculos</span><input class="refr-in" id="avLcOd"><input class="refr-in" id="avLcOe">
          <span class="refr-l av-l">Pinhole (furo)</span><input class="refr-in" id="avPhOd"><input class="refr-in" id="avPhOe">
        </div>
        <div class="row2">
          <div><label>Perto sem óculos <span style="font-weight:400;color:var(--ink-soft);">(os dois olhos)</span></label><input type="text" id="avPsAo" placeholder="J1, J2..."></div>
          <div><label>Perto com óculos</label><input type="text" id="avPcAo" placeholder="J1, J2..."></div>
        </div>
        <p class="sub">Se o paciente não usa óculos, deixe "com óculos" em branco.</p>
      </div>

      <div class="etapa" data-etapa="3" style="display:none;">
      <h3 style="margin-top:18px;font-size:15px;">Autorrefrator <span style="font-weight:400;color:var(--ink-soft);font-size:12px;">(grau sugerido pelo aparelho)</span></h3>
      <div class="refr-grade">
        <span></span><span class="refr-h">Esférico</span><span class="refr-h">Cilíndrico</span><span class="refr-h">Eixo</span>
        <span class="refr-l">OD</span><input class="refr-in" id="arOdEsf" inputmode="decimal" placeholder="-1.25"><input class="refr-in" id="arOdCil" inputmode="decimal" placeholder="-0.50"><input class="refr-in" id="arOdEixo" inputmode="numeric" placeholder="90">
        <span class="refr-l">OE</span><input class="refr-in" id="arOeEsf" inputmode="decimal" placeholder="-1.00"><input class="refr-in" id="arOeCil" inputmode="decimal" placeholder="-0.75"><input class="refr-in" id="arOeEixo" inputmode="numeric" placeholder="85">
      </div>
      <label>Foto do resultado do autorrefrator <span style="font-weight:400;color:var(--ink-soft);">(opcional)</span></label>
      <input type="file" id="arFoto" accept="image/*">
      <div id="arFotoPrev"></div>
      <h3 style="margin-top:18px;font-size:15px;">Grau final confirmado <span style="font-weight:400;color:var(--ink-soft);font-size:12px;">(depois do teste com as lentes)</span></h3>
      <div class="refr-grade refr-grade5">
        <span></span><span class="refr-h">Esférico</span><span class="refr-h">Cilíndrico</span><span class="refr-h">Eixo</span><span class="refr-h">Adição</span>
        <span class="refr-l">OD</span><input class="refr-in" id="fnOdEsf" inputmode="decimal"><input class="refr-in" id="fnOdCil" inputmode="decimal"><input class="refr-in" id="fnOdEixo" inputmode="numeric"><input class="refr-in" id="fnOdAdd" inputmode="decimal">
        <span class="refr-l">OE</span><input class="refr-in" id="fnOeEsf" inputmode="decimal"><input class="refr-in" id="fnOeCil" inputmode="decimal"><input class="refr-in" id="fnOeEixo" inputmode="numeric"><input class="refr-in" id="fnOeAdd" inputmode="decimal">
      </div>
      <h3 style="margin-top:18px;font-size:15px;">Grau de perto <span style="font-weight:400;color:var(--ink-soft);font-size:12px;">(calculado: longe + adição)</span></h3>
      <div class="refr-grade" id="pertoCalc">
        <span></span><span class="refr-h">Esférico</span><span class="refr-h">Cilíndrico</span><span class="refr-h">Eixo</span>
        <span class="refr-l">OD</span><output class="refr-out" id="pcOdEsf">—</output><output class="refr-out" id="pcOdCil">—</output><output class="refr-out" id="pcOdEixo">—</output>
        <span class="refr-l">OE</span><output class="refr-out" id="pcOeEsf">—</output><output class="refr-out" id="pcOeCil">—</output><output class="refr-out" id="pcOeEixo">—</output>
      </div>
      <p class="sub" id="pcNota" style="margin-top:2px;">Digite o grau final e a adição. O perto aparece aqui e vai pronto para a receita, junto com o longe.</p>
      <div id="adPerto" style="margin-top:18px;border:1px solid var(--line,#E4DFD3);border-radius:14px;padding:12px 14px;">
        <h3 style="margin:0 0 6px;font-size:15px;">Adição para perto <span style="font-weight:400;color:var(--ink-soft);font-size:12px;">(sugestão pela idade e pela leitura)</span></h3>
        <div class="row2">
          <div><label>Idade</label><input type="text" inputmode="numeric" id="adIdade" placeholder="Ex: 52" autocomplete="off"></div>
          <div><label>Lê de perto <span style="font-weight:400;color:var(--ink-soft);">(com a correção de longe)</span></label>
            <select id="adJ"><option value="">Sem teste</option><option value="1">J1</option><option value="2">J2</option><option value="3">J3</option><option value="4">J4</option><option value="5">J5</option><option value="6">J6 ou pior</option></select></div>
        </div>
        <label>Como sugerir</label>
        <select id="adModo"><option value="hibrido">Híbrido (leitura e idade)</option><option value="tabela">Só a tabela por idade</option></select>
        <div id="adSug" class="faixa-alerta ok" style="margin-top:10px;"></div>
        <div class="btn-row"><button type="button" class="btn btn-ghost" id="adUsar">Usar nos dois olhos</button></div>
        <details style="margin-top:8px;"><summary style="cursor:pointer;color:var(--teal-700);font-size:13px;">Ver a tabela por idade</summary>
          <table style="font-size:13px;border-collapse:collapse;margin-top:6px;"><tr><th style="text-align:left;padding:2px 12px 2px 0;">Idade</th><th style="text-align:left;">Adição</th></tr>
          <tr><td>40 a 44</td><td>+1,00</td></tr><tr><td>45 a 49</td><td>+1,50</td></tr><tr><td>50 a 54</td><td>+2,00</td></tr><tr><td>55 a 59</td><td>+2,25</td></tr><tr><td>60 a 64</td><td>+2,50</td></tr><tr><td>65 ou mais</td><td>+2,75</td></tr></table>
          <p class="sub" style="margin-top:6px;">Ponto de partida. Confirme com o cartão de leitura a 40 cm: use a menor adição que o paciente lê J1 ou J2 com conforto. Miopes costumam precisar de menos. Quem trabalha de muito perto pode precisar de mais.</p>
        </details>
      </div>
      <div id="tcEspaco" style="height:0;"></div>
      </div>

      <div class="etapa" data-etapa="4" style="display:none;">
        <h3 style="margin-top:6px;font-size:15px;">Outros testes <span style="font-weight:400;color:var(--ink-soft);font-size:12px;">(preencha o que você fez)</span></h3>
        <div class="row2">
          <div><label>Movimento dos olhos</label><select id="tsMotil"><option value=""></option><option>Normal</option><option>Alterado</option></select></div>
          <div><label>Pupilas</label><select id="tsPupilas"><option value=""></option><option>Normais</option><option>Alteradas</option></select></div>
        </div>
        <div class="row2">
          <div><label>Visão de cores</label><select id="tsCores"><option value=""></option><option>Normal</option><option>Alterada</option><option>Não testado</option></select></div>
          <div><label>Ponto próximo de convergência (cm)</label><input type="text" inputmode="decimal" id="tsPPC" placeholder="Ex: 8"></div>
        </div>
        <div class="row2">
          <div><label>Pressão OD (mmHg)</label><input type="text" inputmode="decimal" id="tsPioOd" placeholder="só se tiver tonômetro"></div>
          <div><label>Pressão OE (mmHg)</label><input type="text" inputmode="decimal" id="tsPioOe"></div>
        </div>
        <label>Observações dos testes</label>
        <textarea id="tsObs"></textarea>
      </div>

      <div class="etapa" data-etapa="5" style="display:none;">
        <h3 style="margin-top:6px;font-size:15px;">Alertas</h3>
        <div id="pntAlertas"></div>
        <label style="margin-top:14px;display:flex;align-items:center;gap:8px;"><input type="checkbox" id="enCheck"> Encaminhar ao oftalmologista</label>
        <div id="enBox" style="display:none;">
          <label>Motivo do encaminhamento</label>
          <textarea id="enMotivo" placeholder="Ex: flashes de luz há 2 dias no olho direito"></textarea>
          <div class="btn-row"><button type="button" class="btn btn-amber" id="btnEnImprimir">Imprimir encaminhamento</button><button type="button" class="btn btn-wpp" id="btnEnZap">Enviar por WhatsApp</button></div>
        </div>
      </div>

      <div class="etapa" data-etapa="6" style="display:none;">
        <label>Observações clínicas <span style="font-weight:400;color:var(--ink-soft);">(achados do exame)</span></label>
        <textarea id="pntObs" placeholder="O que você observou durante o exame..."></textarea>
        <label>Conduta <span style="font-weight:400;color:var(--ink-soft);">(orientação dada: óculos, uso, cuidados)</span></label>
        <textarea id="pntConduta" placeholder="O que foi indicado..."></textarea>
        <label>Voltar em quantos meses?</label>
        <input type="text" inputmode="numeric" id="rtMeses" maxlength="3" style="max-width:120px;">
        <div id="rtSugestao"></div>
        <div id="pntResumoAlertas"></div>
        <label style="margin-top:16px;display:flex;align-items:center;gap:8px;">
          <input type="checkbox" id="pntAbrirGabarito" ${gabaritoAberto?'checked':''}> Preencher gabarito de acuidade visual
          <span style="font-weight:400;color:var(--ink-soft);font-size:12px;">(opcional, exame comum ou admissional de empresa)</span>
        </label>
        <div id="gabaritoBox">${gabaritoAberto ? gabaritoHtml() : ''}</div>
        <div id="crBox" style="display:none;"><label class="req">Motivo da correção</label><input type="text" id="crMotivo" placeholder="Ex: erro de digitação no eixo do OE"></div>
      </div>

      <div class="btn-row pnt-nav">
        <button type="button" class="btn btn-outline" id="pntVoltar">Voltar</button>
        <button type="button" class="btn btn-primary" id="pntProximo">Próximo</button>
      </div>
      <div class="btn-row" id="pntFinal" style="display:none;">
        <button type="button" class="btn btn-primary" id="btnSalvarPront">Salvar e fechar o exame</button>
        <button type="button" class="btn btn-outline" id="btnRascunhoPront">Salvar como rascunho</button>
      </div>
      <div class="btn-row" id="pntPosSalvar" style="display:none;"></div>
    </div>
  `;

  function exameDe(p){ return p.exame || {}; }
  function itemHistoricoHtml(p, i){
    const ex = exameDe(p);
    const sintomasMarcados = p.sintomas ? Object.entries(p.sintomas).filter(([,v])=>v===true).map(([k])=>k) : [];
    const quando = `${fmtData(p.data_exame)} ${new Date(p.criado_em).toLocaleTimeString('pt-BR',{hour:'2-digit',minute:'2-digit'})}`;
    const av = ex.av || {};
    const avTxt = (av.lsOd||av.lsOe||av.lcOd||av.lcOe) ? `<div><strong>Acuidade:</strong> sem óculos OD ${esc(av.lsOd||'-')} · OE ${esc(av.lsOe||'-')}${(av.lcOd||av.lcOe)?` · com óculos OD ${esc(av.lcOd||'-')} · OE ${esc(av.lcOe||'-')}`:''}</div>` : '';
    return `
    <div class="pront-item">
      <div class="pront-item-head">${quando} · ${esc(p.profissional_nome||'')} <span class="pront-estado ${p.fechado_em?'fechado':'rascunho'}">${p.fechado_em?'Fechado':'Rascunho'}</span></div>
      ${p.queixa_principal? `<div><strong>Queixa:</strong> ${esc(p.queixa_principal)}</div>`:''}
      ${sintomasMarcados.length? `<div><strong>Sintomas:</strong><div class="pront-sintomas-tags">${sintomasMarcados.map(s=>`<span class="pront-sintoma-tag ${SINTOMAS_ALERTA.includes(s)?'alerta':''}">${esc(s)}</span>`).join('')}</div></div>`:''}
      ${p.sintomas?.['Outros']? `<div><strong>Outros sintomas:</strong> ${esc(p.sintomas['Outros'])}</div>`:''}
      ${avTxt}
      ${refracaoHistoricoHtml(p.refracao)}
      ${ex.testes && Object.values(ex.testes).some(Boolean) ? `<div><strong>Outros testes:</strong> ${esc(Object.entries({motil:'movimento',pupilas:'pupilas',cores:'cores',ppc:'PPC cm',pioOd:'pressão OD',pioOe:'pressão OE',obs:'obs'}).map(([k,r])=>ex.testes[k]?r+' '+ex.testes[k]:'').filter(Boolean).join(' · '))}</div>`:''}
      ${p.observacoes_clinicas? `<div><strong>Observações:</strong> ${esc(p.observacoes_clinicas)}</div>`:''}
      ${p.conduta? `<div><strong>Conduta:</strong> ${esc(p.conduta)}</div>`:''}
      ${ex.encaminhamento?.sim ? `<div class="pront-enc"><strong>Encaminhado ao oftalmologista:</strong> ${esc(ex.encaminhamento.motivo||'')}</div>`:''}
      ${ex.retorno_meses? `<div><strong>Voltar em:</strong> ${esc(ex.retorno_meses)} meses</div>`:''}
      ${p.gabarito_acuidade? `<div><strong>Gabarito de acuidade:</strong> OD 20/${esc(p.gabarito_acuidade.resultadoOD||'-')} · OE 20/${esc(p.gabarito_acuidade.resultadoOE||'-')}
        <button type="button" class="link-discreto pront-reimprimir" data-id="${p.id}" style="display:inline;width:auto;margin-left:8px;">reimprimir</button></div>`:''}
      <div class="btn-row pront-acoes">
        <button type="button" class="btn btn-outline btn-sm" data-ac="corrigir" data-i="${i}">Corrigir</button>
        <button type="button" class="btn btn-outline btn-sm" data-ac="receita" data-i="${i}">Gerar receita</button>
        ${ex.encaminhamento?.sim ? `<button type="button" class="btn btn-outline btn-sm" data-ac="encaminhar" data-i="${i}">Encaminhamento</button>`:''}
        <button type="button" class="btn btn-outline btn-sm" data-ac="versoes" data-i="${i}">Alterações</button>
      </div>
    </div>`;
  }
  async function carregarHistorico(pacId){
    const box = document.getElementById('pntHistorico');
    if(!pacId){ box.innerHTML=''; return; }
    box.innerHTML = '<p class="sub">Carregando histórico...</p>';
    try{
      const lista = await api(`/prontuarios?paciente_id=${pacId}`);
      prontuarioState.lista = lista;
      box.innerHTML = lista.length ? '<h3 style="margin-top:16px;font-size:15px;">Exames anteriores</h3>' + lista.map(itemHistoricoHtml).join('') : '<p class="sub">Nenhum exame registrado ainda para esse paciente.</p>';
      box.querySelectorAll('.pront-reimprimir').forEach(btn=>{
        btn.onclick = ()=>{
          const item = prontuarioState.lista.find(p=>p.id===btn.dataset.id);
          if(!item?.gabarito_acuidade) return;
          gabaritoAtual = { ...gabaritoVazio(), ...item.gabarito_acuidade };
          const paciente = pacientes.find(x=>x.id===pacId);
          imprimir(gerarHtmlGabarito(paciente));
        };
      });
      box.querySelectorAll('button[data-ac]').forEach(btn=>{
        btn.onclick = async ()=>{
          const item = prontuarioState.lista[+btn.dataset.i];
          if(btn.dataset.ac==='corrigir') iniciarCorrecao(item);
          else if(btn.dataset.ac==='receita') levarGrauParaReceita(item.refracao?.final, item.exame?.av, pacId);
          else if(btn.dataset.ac==='encaminhar') documentoEncaminhamento(pacId, item.exame?.encaminhamento?.motivo||'', item, 'imprimir');
          else if(btn.dataset.ac==='versoes'){
            try{
              const v = await api(`/prontuarios/${item.id}/versoes`);
              openModal(`<h2>Alterações deste exame</h2>${v.length ? v.map(x=>`<div class="list-item"><div><div class="name">${esc(x.usuario_nome||'')}</div><div class="meta">${new Date(x.criado_em).toLocaleString('pt-BR')}${x.motivo?' · '+esc(x.motivo):''}</div></div></div>`).join('') : '<p class="sub">Nenhuma correção feita.</p>'}<div class="btn-row" style="margin-top:12px;"><button class="btn btn-outline" onclick="closeModal()">Fechar</button></div>`);
            }catch(e){ erroApi(e); }
          }
        };
      });
    }catch(e){ erroApi(e); box.innerHTML=''; }
  }

  /* ----- etapas ----- */
  let etapa = 1, editandoId = null, editandoFechado = false;
  const TOTAL_ETAPAS = 6;
  const IDS_HX = {usa:'hxUsa',ultimo:'hxUltimo',doencas:'hxDoencas',remedios:'hxRemedios',alergias:'hxAlergias',familia:'hxFamilia',cirurgia:'hxCirurgia',trabalho:'hxTrabalho'};
  const IDS_AV = {lsOd:'avLsOd',lsOe:'avLsOe',lcOd:'avLcOd',lcOe:'avLcOe',phOd:'avPhOd',phOe:'avPhOe',psAo:'avPsAo',pcAo:'avPcAo'};
  const IDS_TS = {motil:'tsMotil',pupilas:'tsPupilas',cores:'tsCores',ppc:'tsPPC',pioOd:'tsPioOd',pioOe:'tsPioOe',obs:'tsObs'};
  const val = id=> (document.getElementById(id)?.value||'').trim();
  const lerGrupo = ids=>{ const o={}; Object.entries(ids).forEach(([k,id])=>{ o[k]=val(id); }); return o; };
  const gravarGrupo = (ids,o)=>{ Object.entries(ids).forEach(([k,id])=>{ const e=document.getElementById(id); if(e) e.value=(o&&o[k])||''; }); };

  function pacienteAtualObj(){ return pacientes.find(x=>x.id===prontuarioState.pacienteId); }
  function preencherHistoriaDaFicha(){
    const pac = pacienteAtualObj(); const ex = (pac && pac.dados_extras) || {};
    gravarGrupo(IDS_HX, { usa:ex.usa_oculos, ultimo:ex.ultimo_exame, doencas:ex.doencas, remedios:ex.medicamentos, alergias:ex.alergias, familia:ex.historico_familiar, cirurgia:ex.cirurgia_ocular, trabalho:ex.profissao });
    if(ex.queixa && !val('pntQueixa')) document.getElementById('pntQueixa').value = ex.queixa;
  }

  function avDen(t){
    t = String(t||'').trim().replace(',','.');
    let m = /^(\d+)\s*\/\s*(\d+)$/.exec(t); if(m && +m[1]>0) return +m[2]/+m[1];
    m = /^(\d*\.?\d+)$/.exec(t); if(m && +m[1]>0 && +m[1]<=2) return 1/+m[1];
    return null;
  }
  function calcularAlertas(){
    const al = [];
    const marcados = [...main.querySelectorAll('.pntSintoma')].filter(c=>c.checked).map(c=>c.dataset.sintoma);
    marcados.filter(x=>SINTOMAS_ALERTA.includes(x)).forEach(x=> al.push({nivel:'urgente', texto:`Sintoma de alerta: ${x}.`}));
    const hx = lerGrupo(IDS_HX);
    if(/diabet|press[aã]o alta|hipertens/i.test(hx.doencas)) al.push({nivel:'atencao', texto:'Diabetes ou pressão alta: confirme que o paciente fez fundo de olho com oftalmologista no último ano.'});
    if(/glaucoma/i.test(hx.familia)) al.push({nivel:'atencao', texto:'Glaucoma na família: sugira avaliação de pressão e nervo óptico com oftalmologista.'});
    if(hx.cirurgia) al.push({nivel:'atencao', texto:'Cirurgia ocular informada: confira se o acompanhamento com oftalmologista está em dia.'});
    const pac = pacienteAtualObj(); const idade = pac ? idadeDe(pac.data_nascimento) : null;
    const ts = lerGrupo(IDS_TS);
    if(idade!==null && idade>=40 && !ts.pioOd && !ts.pioOe) al.push({nivel:'atencao', texto:'Mais de 40 anos sem pressão do olho medida neste exame. Sugira oftalmologista para medir.'});
    const av = lerGrupo(IDS_AV);
    [['OD',av.lcOd||av.lsOd, av.phOd],['OE',av.lcOe||av.lsOe, av.phOe]].forEach(([olho,melhor])=>{
      const d = avDen(melhor); if(d!==null && d>2) al.push({nivel:'atencao', texto:`${olho} enxerga pior que 20/40 mesmo com a melhor correção registrada. Se o grau final não melhora, encaminhe.`});
    });
    if(ts.motil==='Alterado' || ts.pupilas==='Alteradas') al.push({nivel:'urgente', texto:'Movimento dos olhos ou pupilas alterados: encaminhe ao oftalmologista.'});
    return { al, idade };
  }
  function retornoSugerido(al, idade){
    if(idade!==null && (idade<18 || idade>=65)) return 12;
    return al.length ? 12 : 24;
  }
  function desenharAlertas(){
    const { al, idade } = calcularAlertas();
    const html = al.length ? al.map(a=>`<div class="faixa-alerta ${a.nivel}"><b>${a.nivel==='urgente'?'Urgente':'Atenção'}:</b> ${esc(a.texto)}</div>`).join('') : '<div class="faixa-alerta ok">Nenhum sinal de alerta encontrado com o que foi preenchido.</div>';
    document.getElementById('pntAlertas').innerHTML = html;
    const resumo = document.getElementById('pntResumoAlertas'); if(resumo) resumo.innerHTML = al.length ? `<div class="faixa-alerta ${al.some(a=>a.nivel==='urgente')?'urgente':'atencao'}">${al.length} alerta(s) neste exame. Veja a etapa 5.</div>` : '';
    const urg = al.filter(a=>a.nivel==='urgente');
    const chk = document.getElementById('enCheck');
    if(urg.length && !chk.checked && !chk.dataset.mexeu){ chk.checked = true; document.getElementById('enBox').style.display='block'; if(!val('enMotivo')) document.getElementById('enMotivo').value = urg.map(a=>a.texto.replace(/^Sintoma de alerta: /,'')).join(' ').slice(0,300); }
    const sug = retornoSugerido(al, idade);
    document.getElementById('rtSugestao').innerHTML = `<div class="sugestao-chip">Sugestão: voltar em ${sug} meses ${idade!==null&&(idade<18||idade>=65)?'(idade '+idade+' anos)':(al.length?'(há alertas)':'(adulto sem risco)')} <button type="button" id="rtUsar">Usar ${sug}</button></div>`;
    document.getElementById('rtUsar').onclick = ()=>{ document.getElementById('rtMeses').value = sug; };
    return al;
  }
  function mostrarEtapa(n){
    etapa = Math.max(1, Math.min(TOTAL_ETAPAS, n));
    main.querySelectorAll('.etapa').forEach(e=> e.style.display = (+e.dataset.etapa===etapa) ? 'block' : 'none');
    main.querySelectorAll('#pntPassos .passo').forEach(b=>{ b.classList.toggle('ativo', +b.dataset.p===etapa); b.classList.toggle('feito', +b.dataset.p<etapa); });
    document.getElementById('pntVoltar').style.visibility = etapa===1 ? 'hidden' : 'visible';
    document.getElementById('pntProximo').style.display = etapa===TOTAL_ETAPAS ? 'none' : '';
    document.getElementById('pntFinal').style.display = etapa===TOTAL_ETAPAS ? '' : 'none';
    if(etapa===5 || etapa===6) desenharAlertas();
    if(typeof aoMudarEtapaGrau==='function') aoMudarEtapaGrau();
    document.getElementById('pntPassos').scrollIntoView({behavior:'smooth', block:'start'});
  }
  document.getElementById('pntProximo').onclick = ()=>{
    if(etapa===1 && !prontuarioState.pacienteId){ toast('Selecione o paciente.'); return; }
    mostrarEtapa(etapa+1);
  };
  document.getElementById('pntVoltar').onclick = ()=> mostrarEtapa(etapa-1);
  iniciarVozExame({ etapa:()=>etapa, ir:(n)=>mostrarEtapa(n) });

  /* ----- adição para perto: tabela por idade + leitura de perto ----- */
  function atualizarAdicaoPerto(forcarLeitura){
    const idEl = document.getElementById('adIdade'), jEl = document.getElementById('adJ'), mEl = document.getElementById('adModo'), box = document.getElementById('adSug');
    if(!idEl) return;
    if(!idEl.dataset.mexeu){ const pac = pacienteAtualObj(); const id = pac ? idadeDe(pac.data_nascimento) : null; if(id!==null) idEl.value = String(id); }
    if(forcarLeitura || !jEl.dataset.mexeu){
      const j = leituraPertoJ(document.getElementById('avPcAo')?.value) || leituraPertoJ(document.getElementById('avPsAo')?.value);
      if(j) jEl.value = String(j);
    }
    const r = adicaoHibrida(idEl.value, jEl.value ? +jEl.value : null, mEl.value);
    box.className = 'faixa-alerta ' + (r.valor ? 'ok' : 'atencao');
    box.innerHTML = esc(r.texto) + (r.valor ? ' <b>Sugerido: '+esc(r.valor)+'</b>' : '');
    document.getElementById('adUsar').style.display = r.valor ? '' : 'none';
    document.getElementById('adUsar').dataset.valor = r.valor || '';
    document.getElementById('adUsar').textContent = 'Usar ' + (r.valor||'') + ' nos dois olhos';
  }
  ['adIdade','adJ','adModo'].forEach(id=>{ const el = document.getElementById(id); el.addEventListener('input', ()=>{ if(id!=='adModo') el.dataset.mexeu='1'; atualizarAdicaoPerto(); }); el.addEventListener('change', ()=>{ if(id!=='adModo') el.dataset.mexeu='1'; atualizarAdicaoPerto(); }); });
  document.getElementById('adUsar').onclick = ()=>{
    const v = document.getElementById('adUsar').dataset.valor; if(!v) return;
    ['fnOdAdd','fnOeAdd'].forEach(id=>{ const el = document.getElementById(id); el.value = v; el.dispatchEvent(new Event('input',{bubbles:true})); el.classList.add('vz-ok'); setTimeout(()=>el.classList.remove('vz-ok'), 2000); });
    toast('Adição '+v+' colocada nos dois olhos. Confira com o teste de leitura.');
  };
  function atualizarPertoGrau(){
    const g = id=> (document.getElementById(id)?.value||'').trim().replace(',', '.');
    const addOd = g('fnOdAdd'), addOe = g('fnOeAdd');
    let algum = false;
    ['Od','Oe'].forEach(o=>{
      const add = parseFloat((o==='Od' ? (addOd||addOe) : (addOe||addOd)).replace('+',''));
      const esf = g('fn'+o+'Esf'), cil = g('fn'+o+'Cil'), eixo = g('fn'+o+'Eixo');
      const tem = !isNaN(add) && (esf || cil);
      document.getElementById('pc'+o+'Esf').textContent = tem ? (()=>{ const n = (parseFloat(esf.replace('+',''))||0) + add; return (n>0?'+':'') + n.toFixed(2); })() : '—';
      document.getElementById('pc'+o+'Cil').textContent = tem ? (cil || '—') : '—';
      document.getElementById('pc'+o+'Eixo').textContent = tem ? (eixo || '—') : '—';
      if(tem) algum = true;
    });
    document.getElementById('pcNota').textContent = algum
      ? 'Perto = esférico do longe + adição. Cilíndrico e eixo repetem os do longe. Ao levar o grau para a receita, longe e perto saem prontos.'
      : 'Digite o grau final e a adição. O perto aparece aqui e vai pronto para a receita, junto com o longe.';
  }
  ['fnOdEsf','fnOdCil','fnOdEixo','fnOdAdd','fnOeEsf','fnOeCil','fnOeEixo','fnOeAdd'].forEach(id=>{ const el = document.getElementById(id); el.addEventListener('input', atualizarPertoGrau); el.addEventListener('change', atualizarPertoGrau); });
  atualizarPertoGrau();
  iniciarTecladoGrau({ etapa:()=>etapa });
  function aoMudarEtapaGrau(){ atualizarAdicaoPerto(); atualizarPertoGrau(); tecladoGrauEtapa(); }
  main.querySelectorAll('#pntPassos .passo').forEach(b=> b.onclick = ()=>{ if(!prontuarioState.pacienteId){ toast('Selecione o paciente.'); return; } mostrarEtapa(+b.dataset.p); });
  document.getElementById('enCheck').onchange = e=>{ e.target.dataset.mexeu = '1'; document.getElementById('enBox').style.display = e.target.checked ? 'block' : 'none'; };

  /* ----- documentos ----- */
  function prepararDocumento(pacId){
    const pac = pacientes.find(x=>x.id===pacId);
    receitaAtual.pacienteId = pacId;
    const idade = pac ? idadeDe(pac.data_nascimento) : null; if(idade!==null) receitaAtual.idade = String(idade);
    if(usuarioAtual?.papel==='profissional') receitaAtual.profissionalId = usuarioAtual.id;
    return pac;
  }
  function resumoAchados(item){
    const r = item?.refracao?.final, av = item?.exame?.av || {};
    const lin = [];
    if(av.lsOd||av.lsOe) lin.push(`Acuidade sem óculos: OD ${av.lsOd||'-'} · OE ${av.lsOe||'-'}`);
    if(r && (r.odEsf||r.oeEsf)) lin.push(`Grau medido: OD ${[r.odEsf,r.odCil,r.odEixo?'x'+r.odEixo:''].filter(Boolean).join(' ')||'-'} · OE ${[r.oeEsf,r.oeCil,r.oeEixo?'x'+r.oeEixo:''].filter(Boolean).join(' ')||'-'}`);
    return lin;
  }
  function documentoEncaminhamento(pacId, motivo, item, modo){
    const pac = prepararDocumento(pacId);
    const achados = resumoAchados(item);
    if(modo==='imprimir'){
      imprimirDocumento(paginaDoc('Encaminhamento ao oftalmologista', `${pacienteDocHtml()}
        <p style="margin-top:14px;">Encaminho o(a) paciente acima para avaliação com médico oftalmologista.</p>
        <p><b>Motivo:</b> ${esc(motivo||'')}</p>
        ${achados.length?`<p><b>Achados do exame de vista:</b><br>${achados.map(esc).join('<br>')}</p>`:''}
        <div class="rodape">${localDataDocHtml()}${assinaturaDocHtml()}</div>
        <div class="aviso">O exame de vista com refração não substitui a avaliação médica. O diagnóstico e o tratamento de doenças dos olhos são feitos pelo médico oftalmologista.</div>`));
    } else {
      const nome = pac ? primeiroNome(pac.nome_completo) : '';
      abrirWhatsapp(pac?.telefone||'', `Olá, ${nome}! Depois do seu exame de vista na ${clinicaAtual?.nome_fantasia||'clínica'}, recomendamos que você procure um médico oftalmologista. Motivo: ${motivo}. Não deixe para depois.`);
    }
  }
  document.getElementById('btnEnImprimir').onclick = ()=>{ if(!val('enMotivo')){ toast('Escreva o motivo do encaminhamento.'); return; } documentoEncaminhamento(prontuarioState.pacienteId, val('enMotivo'), { refracao:{final:lerRefracaoDoDOM()?.final}, exame:{av:lerGrupo(IDS_AV)} }, 'imprimir'); };
  document.getElementById('btnEnZap').onclick = ()=>{ if(!val('enMotivo')){ toast('Escreva o motivo do encaminhamento.'); return; } documentoEncaminhamento(prontuarioState.pacienteId, val('enMotivo'), null, 'whatsapp'); };

  function levarGrauParaReceita(f, av, pacId){
    if(!f || !(f.odEsf||f.oeEsf||f.odCil||f.oeCil)){ toast('Preencha o grau final confirmado primeiro.'); return; }
    prepararDocumento(pacId);
    ['od','oe'].forEach(o=>{
      const c = o==='od'?'Od':'Oe';
      receitaAtual.longe[o] = { esf:f[o+'Esf']||'', cil:f[o+'Cil']||'', eixo:f[o+'Eixo']||'' };
    });
    const sinal = x=> String(x||'').replace(/^(\d)/,'+$1');
    receitaAtual.adicao = sinal(f.odAdd || f.oeAdd);
    receitaAtual.adicaoOe = (f.odAdd && f.oeAdd && sinal(f.oeAdd)!==sinal(f.odAdd)) ? sinal(f.oeAdd) : '';
    receitaAtual.pertoAuto = true;
    if(av){ receitaAtual.extras.avOd = av.lcOd || av.lsOd || ''; receitaAtual.extras.avOe = av.lcOe || av.lsOe || ''; }
    toast('Grau levado para a receita. Confira e imprima.');
    switchView('receita');
  }

  /* ----- salvar, corrigir ----- */
  function lerExameCompleto(){
    return {
      historia: lerGrupo(IDS_HX), av: lerGrupo(IDS_AV), testes: lerGrupo(IDS_TS),
      encaminhamento: { sim: document.getElementById('enCheck').checked, motivo: val('enMotivo') },
      retorno_meses: val('rtMeses') || null,
      alertas: calcularAlertas().al,
    };
  }
  function limparFormularioExame(){
    ['pntQueixa','pntObs','pntConduta','pntOutrosSintomas','tsObs','enMotivo','rtMeses','crMotivo'].forEach(id=>{ const e=document.getElementById(id); if(e) e.value=''; });
    gravarGrupo(IDS_HX,{}); gravarGrupo(IDS_AV,{}); gravarGrupo(IDS_TS,{});
    main.querySelectorAll('.pntSintoma').forEach(cb=>cb.checked=false);
    const c = document.getElementById('enCheck'); c.checked=false; delete c.dataset.mexeu; document.getElementById('enBox').style.display='none';
    limparRefracaoDOM();
    gabaritoAtual = gabaritoVazio(); gabaritoAberto = false; chkGabarito.checked = false; gabaritoBox.innerHTML = '';
    editandoId = null; editandoFechado = false;
    document.getElementById('pntBanner').innerHTML=''; document.getElementById('pntTituloNovo').textContent='Novo exame'; document.getElementById('crBox').style.display='none';
    document.getElementById('pntPosSalvar').style.display='none';
  }
  function iniciarCorrecao(item){
    limparFormularioExame();
    editandoId = item.id; editandoFechado = !!item.fechado_em;
    const ex = item.exame || {};
    document.getElementById('pntQueixa').value = item.queixa_principal||'';
    document.getElementById('pntObs').value = item.observacoes_clinicas||'';
    document.getElementById('pntConduta').value = item.conduta||'';
    const sint = item.sintomas || {};
    main.querySelectorAll('.pntSintoma').forEach(cb=> cb.checked = sint[cb.dataset.sintoma]===true);
    document.getElementById('pntOutrosSintomas').value = sint['Outros']||'';
    gravarGrupo(IDS_HX, ex.historia); gravarGrupo(IDS_AV, ex.av); gravarGrupo(IDS_TS, ex.testes);
    const r = item.refracao || {};
    Object.entries(r.autorrefrator||{}).forEach(([k,v])=>{ if(k==='foto') return; const e=document.getElementById('ar'+k.charAt(0).toUpperCase()+k.slice(1)); if(e) e.value=v; });
    Object.entries(r.final||{}).forEach(([k,v])=>{ const e=document.getElementById('fn'+k.charAt(0).toUpperCase()+k.slice(1)); if(e) e.value=v; });
    refracaoFoto = r.autorrefrator?.foto || null;
    if(refracaoFoto) document.getElementById('arFotoPrev').innerHTML = `<img class="refr-foto" src="${refracaoFoto}" alt="">`;
    const en = ex.encaminhamento || {}; const c = document.getElementById('enCheck'); c.checked = !!en.sim; c.dataset.mexeu='1'; document.getElementById('enBox').style.display = en.sim ? 'block':'none'; document.getElementById('enMotivo').value = en.motivo||'';
    document.getElementById('rtMeses').value = ex.retorno_meses||'';
    if(item.gabarito_acuidade){ gabaritoAtual = { ...gabaritoVazio(), ...item.gabarito_acuidade }; gabaritoAberto = true; chkGabarito.checked = true; gabaritoBox.innerHTML = gabaritoHtml(); ligarEventosGabarito(); }
    document.getElementById('pntBanner').innerHTML = `<div class="faixa-alerta atencao">Corrigindo o exame de ${fmtData(item.data_exame)}. ${item.fechado_em?'Como já está fechado, informe o motivo na última etapa. A versão anterior fica guardada.':''}</div>`;
    document.getElementById('pntTituloNovo').textContent = 'Corrigir exame';
    document.getElementById('crBox').style.display = item.fechado_em ? 'block' : 'none';
    mostrarEtapa(1);
  }
  async function salvarExame(fechar){
    if(!prontuarioState.pacienteId){ toast('Selecione um paciente.'); return; }
    const queixa = val('pntQueixa'), obs = val('pntObs'), conduta = val('pntConduta'), outros = val('pntOutrosSintomas');
    const sintomas = {};
    main.querySelectorAll('.pntSintoma').forEach(cb=>{ sintomas[cb.dataset.sintoma] = cb.checked; });
    if(outros) sintomas['Outros'] = outros;
    if(gabaritoAberto) lerGabaritoDoDOM();
    const refracao = lerRefracaoDoDOM();
    const exame = lerExameCompleto();
    const algo = queixa||obs||conduta||outros||refracao||Object.values(sintomas).some(v=>v===true)||gabaritoAberto||Object.values(exame.av).some(Boolean)||Object.values(exame.testes).some(Boolean);
    if(!algo){ toast('Escreva ou marque alguma coisa antes de salvar.'); return; }
    if(exame.encaminhamento.sim && !exame.encaminhamento.motivo){ toast('Escreva o motivo do encaminhamento (etapa 5).'); mostrarEtapa(5); return; }
    const corpo = { queixa_principal: queixa||null, sintomas, observacoes_clinicas: obs||null, conduta: conduta||null, gabarito_acuidade: gabaritoAberto ? gabaritoAtual : null, refracao, exame, fechar };
    try{
      let salvo;
      if(editandoId){
        corpo.motivo = val('crMotivo');
        if(editandoFechado && !corpo.motivo){ toast('Informe o motivo da correção.'); return; }
        salvo = await api(`/prontuarios/${editandoId}`, { method:'PUT', body:corpo });
      } else {
        salvo = await api('/prontuarios', { method:'POST', body:{ paciente_id: prontuarioState.pacienteId, ...corpo } });
      }
      toast(fechar ? 'Exame salvo e fechado.' : 'Rascunho salvo.');
      const pacId = prontuarioState.pacienteId;
      const fnGrau = refracao?.final, avSalvo = exame.av;
      limparFormularioExame(); preencherHistoriaDaFicha();
      await carregarHistorico(pacId);
      mostrarEtapa(1);
      const pos = document.getElementById('pntPosSalvar'); pos.style.display = 'flex';
      pos.innerHTML = `<button type="button" class="btn btn-amber" id="psReceita">Gerar receita com este grau</button>${exame.encaminhamento.sim?'<button type="button" class="btn btn-outline" id="psEnc">Imprimir encaminhamento</button>':''}`;
      document.getElementById('psReceita').onclick = ()=> levarGrauParaReceita(fnGrau, avSalvo, pacId);
      const pe = document.getElementById('psEnc'); if(pe) pe.onclick = ()=> documentoEncaminhamento(pacId, exame.encaminhamento.motivo, { refracao:{final:fnGrau}, exame:{av:avSalvo} }, 'imprimir');
    }catch(e){ erroApi(e); }
  }
  document.getElementById('btnSalvarPront').onclick = ()=> salvarExame(true);
  document.getElementById('btnRascunhoPront').onclick = ()=> salvarExame(false);

  document.getElementById('pntPac').onchange = e=>{
    prontuarioState.pacienteId = e.target.value;
    limparFormularioExame(); preencherHistoriaDaFicha(); mostrarEtapa(1);
    carregarHistorico(e.target.value);
  };
  if(prontuarioState.pacienteId){ preencherHistoriaDaFicha(); carregarHistorico(prontuarioState.pacienteId); }

  // atalho de um clique: direto da agenda do dia já abre o prontuário desse paciente,
  // sem precisar procurar na lista toda durante o atendimento
  main.querySelectorAll('.btn-abrir-prontuario').forEach(btn=>{
    btn.onclick = ()=>{
      const pacId = btn.dataset.paciente;
      document.getElementById('pntPac').value = pacId;
      prontuarioState.pacienteId = pacId;
      limparFormularioExame(); preencherHistoriaDaFicha(); mostrarEtapa(1);
      carregarHistorico(pacId);
      document.getElementById('pntPac').scrollIntoView({behavior:'smooth', block:'center'});
    };
  });

  refracaoFoto = null;
  document.getElementById('arFoto').onchange = async e=>{
    const f = e.target.files[0]; const pv = document.getElementById('arFotoPrev');
    if(!f){ refracaoFoto=null; pv.innerHTML=''; return; }
    try{ refracaoFoto = await reduzirImagem(f); pv.innerHTML = `<img class="refr-foto" src="${refracaoFoto}" alt="">`; }
    catch(err){ refracaoFoto=null; pv.innerHTML=''; toast('Não consegui ler essa foto.'); }
  };

  const chkGabarito = document.getElementById('pntAbrirGabarito');
  const gabaritoBox = document.getElementById('gabaritoBox');
  if(chkGabarito) chkGabarito.onchange = ()=>{
    gabaritoAberto = chkGabarito.checked;
    gabaritoBox.innerHTML = gabaritoAberto ? gabaritoHtml() : '';
    if(gabaritoAberto) ligarEventosGabarito();
  };
  if(gabaritoAberto) ligarEventosGabarito();

  function ligarEventosGabarito(){
    const btnImprimir = document.getElementById('btnImprimirGabarito');
    if(btnImprimir) btnImprimir.onclick = ()=>{
      lerGabaritoDoDOM();
      const paciente = pacientes.find(p=>p.id===prontuarioState.pacienteId);
      imprimir(gerarHtmlGabarito(paciente));
    };
  }

  function lerGabaritoDoDOM(){
    const g = gabaritoAtual;
    g.idadePaciente = document.getElementById('gIdade').value;
    g.empresa = document.getElementById('gEmpresa').value;
    g.funcao = document.getElementById('gFuncao').value;
    g.setor = document.getElementById('gSetor').value;
    g.usaOculos = document.getElementById('gUsaOculos').value;
    g.frequenciaUso = document.getElementById('gFrequencia').value;
    g.tipoLenteAtual = document.getElementById('gTipoLenteAtual').value;
    g.tempoUsoAtual = document.getElementById('gTempoUso').value;
    g.ultimaConsultaEspecialista = document.getElementById('gUltimaConsulta').value;
    g.jaFezExameEspecialista = document.getElementById('gJaFezExame').value;
    g.possuiDoencaOcular = document.getElementById('gPossuiDoenca').value;
    g.doencaOcularQual = document.getElementById('gDoencaQual').value;
    g.senteDificuldadeVisual = document.getElementById('gDificuldade').value;
    g.dificuldadeQual = document.getElementById('gDificuldadeQual').value;
    g.testeComCorrecao = document.getElementById('gComCorrecao').value;
    g.linhasOD = LINHAS_ACUIDADE.map((_,i)=>{
      const marcado = main.querySelector(`input[name="gab_od_${i}"]:checked`);
      return marcado ? marcado.value==='acertou' : null;
    });
    g.linhasOE = LINHAS_ACUIDADE.map((_,i)=>{
      const marcado = main.querySelector(`input[name="gab_oe_${i}"]:checked`);
      return marcado ? marcado.value==='acertou' : null;
    });
    g.resultadoOD = document.getElementById('gResultadoOD').value;
    g.resultadoOE = document.getElementById('gResultadoOE').value;
    g.avLongeSemOD = document.getElementById('gAvSemOD').value;
    g.avLongeSemOE = document.getElementById('gAvSemOE').value;
    g.avLongeSemAO = document.getElementById('gAvSemAO').value;
    g.avLongeComOD = document.getElementById('gAvComOD').value;
    g.avLongeComOE = document.getElementById('gAvComOE').value;
    g.avLongeComAO = document.getElementById('gAvComAO').value;
    g.avPertoOD = document.getElementById('gAvPertoOD').value;
    g.avPertoOE = document.getElementById('gAvPertoOE').value;
    g.avPertoAO = document.getElementById('gAvPertoAO').value;
    g.testeCores = document.getElementById('gTesteCores').value;
    g.testeCoresAcertos = document.getElementById('gTesteCoresAcertos').value;
    g.condutaGabarito = document.getElementById('gConduta').value;
    g.observacoesGabarito = document.getElementById('gObservacoes').value;
  }

  mostrarEtapa(1);
}

const REFR_CAMPOS = {
  ar: ['arOdEsf','arOdCil','arOdEixo','arOeEsf','arOeCil','arOeEixo'],
  fn: ['fnOdEsf','fnOdCil','fnOdEixo','fnOdAdd','fnOeEsf','fnOeCil','fnOeEixo','fnOeAdd']
};
let refracaoFoto = null;
function lerRefracaoDoDOM(){
  const v = id=> (document.getElementById(id)?.value||'').trim().replace(',', '.');
  const r = { autorrefrator:{}, final:{} };
  REFR_CAMPOS.ar.forEach(id=>{ r.autorrefrator[id.slice(2,3).toLowerCase()+id.slice(3)] = v(id); });
  REFR_CAMPOS.fn.forEach(id=>{ r.final[id.slice(2,3).toLowerCase()+id.slice(3)] = v(id); });
  if(refracaoFoto) r.autorrefrator.foto = refracaoFoto;
  const tem = o=> Object.values(o).some(x=>x);
  if(!tem(r.autorrefrator) && !tem(r.final)) return null;
  return r;
}
function limparRefracaoDOM(){
  [...REFR_CAMPOS.ar, ...REFR_CAMPOS.fn].forEach(id=>{ const e=document.getElementById(id); if(e) e.value=''; });
  refracaoFoto = null;
  document.getElementById('fnOdEsf')?.dispatchEvent(new Event('input',{bubbles:true}));
  const f=document.getElementById('arFoto'); if(f) f.value='';
  const pv=document.getElementById('arFotoPrev'); if(pv) pv.innerHTML='';
}
function reduzirImagem(file, max=1200, qual=0.7){
  return new Promise((res,rej)=>{
    const img = new Image(); const url = URL.createObjectURL(file);
    img.onload = ()=>{
      const k = Math.min(1, max/Math.max(img.width,img.height));
      const c = document.createElement('canvas'); c.width = Math.round(img.width*k); c.height = Math.round(img.height*k);
      c.getContext('2d').drawImage(img,0,0,c.width,c.height);
      URL.revokeObjectURL(url); res(c.toDataURL('image/jpeg', qual));
    };
    img.onerror = ()=>{ URL.revokeObjectURL(url); rej(new Error('Imagem inválida')); };
    img.src = url;
  });
}
function refracaoHistoricoHtml(r){
  if(!r) return '';
  const bloco = (titulo, o, comAdd)=>{
    if(!o || !Object.entries(o).some(([k,x])=>k!=='foto' && x)) return '';
    const olho = (nome, p)=>`<tr><td><strong>${nome}</strong></td><td style="padding:0 10px;">${esc(o[p+'Esf']||'-')}</td><td style="padding:0 10px;">${esc(o[p+'Cil']||'-')}</td><td style="padding:0 10px;">${esc(o[p+'Eixo']||'-')}</td>${comAdd?`<td style="padding:0 10px;">${esc(o[p+'Add']||'-')}</td>`:''}</tr>`;
    return `<div style="margin-top:6px;"><strong>${titulo}</strong>
      <table style="font-size:13px;border-collapse:collapse;margin-top:4px;"><tr><th></th><th>Esf</th><th>Cil</th><th>Eixo</th>${comAdd?'<th>Adição</th>':''}</tr>${olho('OD','od')}${olho('OE','oe')}</table></div>`;
  };
  const foto = r.autorrefrator?.foto && /^data:image\//.test(r.autorrefrator.foto) ? `<img class="refr-foto" src="${r.autorrefrator.foto}" alt="Autorrefrator">` : '';
  return bloco('Autorrefrator', r.autorrefrator, false) + foto + bloco('Grau final confirmado', r.final, true);
}

function renderConfirmacao(main){
  const hoje = hojeISO();
  const futuros = agendamentos.filter(a=> soData(a.data_hora) >= hoje && a.status!=='cancelado').sort((a,b)=> a.data_hora.localeCompare(b.data_hora));
  if(!futuros.length){ main.innerHTML = `<div class="card"><div class="empty"><div class="ic">✅</div>Nenhum agendamento futuro para confirmar.</div></div>`; return; }
  const opts = futuros.map(a=>`<option value="${a.id}">${fmtData(a.data_hora)} ${soHora(a.data_hora)} — ${pacienteNome(a.paciente_id)}</option>`).join('');
  main.innerHTML = `
    <div class="card"><h2>Confirmação do exame</h2><label>Selecione o agendamento</label><select id="confSel">${opts}</select></div>
    <div class="card" id="confCard" style="text-align:center;"></div>`;
  function draw(){
    const a = agendamentos.find(x=>x.id===document.getElementById('confSel').value);
    if(!a) return;
    document.getElementById('confCard').innerHTML = `
      <p class="sub" style="margin-bottom:2px;">Paciente</p>
      <h2 style="margin:0 0 18px;">${pacienteNome(a.paciente_id)}</h2>
      <p class="display" style="font-size:40px;margin:0;color:var(--teal-900);">${fmtData(a.data_hora)}</p>
      <p class="display" style="font-size:26px;margin:4px 0 16px;color:var(--teal-700);">${soHora(a.data_hora)}</p>
      <p style="font-size:14.5px;color:var(--ink-soft);">${a.local||clinicaAtual?.local_exame_padrao||'Local não informado'}</p>
      <span class="pill-tag status-${a.status}" style="margin-top:10px;display:inline-block;">${a.status}</span>`;
  }
  document.getElementById('confSel').onchange = draw;
  draw();
}

/* ========================= MASTER ========================= */
function mostrarAcessoNovo(u){
  const link = (SERVIDOR_PROPRIO ? location.origin + '/' : (API_BASE || '')) + (u.papel ? `?entrada=${u.papel==='atendente'?'atendente':u.papel}` : '');
  const nomePapel = u.papel==='atendente' ? 'agendador' : (u.papel==='profissional' ? 'profissional' : (u.papel==='gestor' ? 'gestor de vendas' : 'administrador'));
  const texto = `Acesso ao sistema da ${clinicaAtual?.nome_fantasia||'clínica'}\nLink: ${link}\nUsuário (e-mail): ${u.email}\nSenha: ${u.senha}${u.cidade?`\nCidade: ${u.cidade}`:''}\nDepois de entrar, troque a senha em Meu perfil.`;
  openModal(`<h2>Acesso de ${esc(u.nome)} criado</h2><p class="sub">Envie estes dados para ${esc(u.nome)} (${nomePapel}). Esta é a única vez que a senha aparece.</p>
    <textarea id="acNovoTxt" readonly style="width:100%;height:150px;font:14px/1.5 Arial,sans-serif;padding:10px;border:1px solid var(--line);border-radius:8px;">${esc(texto)}</textarea>
    <div class="btn-row" style="margin-top:10px;"><button class="btn btn-primary" id="acCopiar">Copiar</button><a class="btn btn-outline" id="acZap" target="_blank" rel="noopener" href="https://wa.me/?text=${encodeURIComponent(texto)}" style="text-align:center;text-decoration:none;">Enviar pelo WhatsApp</a><button class="btn btn-outline" onclick="closeModal()">Fechar</button></div>`);
  document.getElementById('acCopiar').onclick = async ()=>{
    try{ await navigator.clipboard.writeText(texto); toast('Copiado.'); }
    catch(e){ const t=document.getElementById('acNovoTxt'); t.select(); document.execCommand('copy'); toast('Copiado.'); }
  };
}
/* ========================= BOAS-VINDAS ========================= */
/* Base legal do exame de vista por optometrista: aviso na primeira entrada e consulta a qualquer hora (vigilância sanitária) */
const FONTES_LEGAIS = [
  ['Anvisa, Ofício Circular nº 4/2023/SEI/GGTES/DIRE3/ANVISA (20/04/2023), sobre a ADPF 131 e os optometristas','https://blogdobarreto.com.br/wp-content/uploads/2025/09/Of-Circular-ANVISA-pos-EDAPDF-131.pdf'],
  ['STF, ADPF 131, liminar do ministro Gilmar Mendes (08/10/2021)','https://www.conjur.com.br/wp-content/uploads/2023/09/gilmar-impede-restricoes-atuacao.pdf'],
  ['STJ, ação rescisória 7.106 (13/05/2026)','https://www.migalhas.com.br/quentes/455888/stj-optometrista-com-diploma-superior-pode-realizar-exame-de-vista'],
  ['Procon do Ministério Público de MG, Nota Técnica 03/2025','https://www.mpmg.mp.br/data/files/00/97/28/3F/8483B91002A442B9B9A8F9C2/Nota%20Tecnica%20n%203_Atuacao%20de%20profissionais%20optometristas%20com%20formacao%20em%20curso%20superior%20_Procon-MPMG_19%20de%20dezembro%20de%202025.pdf'],
  ['CFM: STF e a posição dos médicos (2020)','https://portal.cfm.org.br/noticias/cfm-pela-seguranca-do-paciente-stf-garante-que-diagnosticos-e-prescricoes-oftalmologicos-sao-exclusivos-dos-medicos/'],
];
function baseLegalCorpoHtml(){
  const li = t=>`<li style="margin:6px 0;">${t}</li>`;
  return `
    <h3 style="margin:12px 0 4px;font-size:15px;">Orientação da Anvisa à vigilância sanitária</h3>
    <p style="margin:4px 0;"><b>Ofício Circular nº 4/2023/SEI/GGTES/DIRE3/ANVISA</b>, de 20/04/2023, processo 25351.931754/2020-14. A Gerência-Geral de Tecnologia em Serviços de Saúde da Anvisa mandou o ofício aos gestores de vigilância sanitária dos estados e do Distrito Federal e pediu que eles o repassem às vigilâncias municipais.</p>
    <ul style="padding-left:18px;margin:0;">
      ${li('O STF julgou a ADPF 131 improcedente e manteve os decretos 20.931 de 1932 e 24.492 de 1934. Depois, nos embargos de declaração, o STF decidiu que <b>as vedações desses decretos não se aplicam aos optometristas qualificados por instituição de ensino superior</b>.')}
      ${li('Segundo a Anvisa, o optometrista de nível superior pode exercer as atividades nos estritos e limitados termos dessa decisão, até que uma lei específica regulamente a profissão: prescrição de órteses e próteses oftalmológicas que, por suas especificidades, não exigem indicação médica; atribuições da CBO 3223 (ópticos optometristas); e atividades previstas nas portarias e pareceres do Ministério da Educação sobre o curso de optometria.')}
      ${li('A Procuradoria Federal junto à Anvisa (Parecer 00002/2022/CAJUD/PFANVISA/PGF/AGU) diz que a decisão do STF não traz uma lista fechada de atividades e deixa para o legislador regular a matéria.')}
      ${li('<b>Se o fiscal visitar:</b> mostre este documento impresso e cite o número do ofício e o processo acima. A orientação da Anvisa vale para o optometrista com diploma de curso superior reconhecido.')}
    </ul>
    <h3 style="margin:14px 0 4px;font-size:15px;">O que as decisões dizem</h3>
    <ul style="padding-left:18px;margin:0;">
      ${li('<b>08/10/2021, STF (ADPF 131):</b> o ministro Gilmar Mendes excluiu dos efeitos da decisão de 2020 os profissionais formados em curso superior reconhecido pelo Estado.')}
      ${li('<b>13/05/2026, STJ (ação rescisória 7.106):</b> optometrista com curso superior reconhecido pode fazer exame de vista.')}
      ${li('<b>Dezembro de 2025, Procon do Ministério Público de MG:</b> esse profissional pode examinar e prescrever óculos e lentes para erro de refração.')}
    </ul>
    <h3 style="margin:14px 0 4px;font-size:15px;">O que o optometrista não faz</h3>
    <ul style="padding-left:18px;margin:0;">
      ${li('Não diagnostica doença, não prescreve remédio e não faz procedimento invasivo.')}
      ${li('Se suspeitar de doença nos olhos, encaminha o paciente ao oftalmologista.')}
    </ul>
    <h3 style="margin:14px 0 4px;font-size:15px;">O que ter à mão se a vigilância visitar</h3>
    <ul style="padding-left:18px;margin:0;">
      ${li('Diploma de curso superior reconhecido do profissional e o número do registro, quando houver.')}
      ${li('Esta base legal impressa, com o Ofício Circular nº 4/2023 da Anvisa. Use o botão Imprimir para a fiscalização.')}
      ${li('Registro do estabelecimento no CNES.')}
      ${li('Atendimento separado da área de venda de óculos.')}
      ${li('Exame sem obrigar a compra de óculos ou lentes, mesmo quando é gratuito.')}
      ${li('Receita entregue ao paciente, que pode usá-la em qualquer ótica.')}
      ${li('Aviso de que o exame não substitui a consulta com oftalmologista. Ele sai na receita deste sistema.')}
    </ul>
    <h3 style="margin:14px 0 4px;font-size:15px;">Atenção</h3>
    <p style="margin:4px 0;">O CBO e o CFM defendem que exame de vista e prescrição são atos médicos e citam os decretos 20.931 de 1932 e 24.492 de 1934. A Justiça decide de formas diferentes conforme o estado. Para lente de contato, não há decisão de tribunal superior que trate dela de forma expressa. Estas informações não são parecer jurídico. Confirme com um advogado de saúde da sua cidade.</p>
    <h3 style="margin:14px 0 4px;font-size:15px;">Fontes</h3>
    <ul style="padding-left:18px;margin:0;">${FONTES_LEGAIS.map(([t,u])=>`<li style="margin:4px 0;"><a href="${u}" target="_blank" rel="noopener">${esc(t)}</a></li>`).join('')}</ul>`;
}
function abrirBaseLegal(primeira){
  openModal(`<h2>Base legal do exame de vista por optometrista</h2>
    ${primeira?'<p class="sub">Aviso da primeira entrada. Para ler de novo, toque em Base legal na tela Início.</p>':''}
    <div style="max-height:58vh;overflow:auto;font-size:14px;line-height:1.5;">${baseLegalCorpoHtml()}</div>
    <div class="btn-row" style="margin-top:12px;"><button class="btn btn-primary" id="blOk">Entendi</button><button class="btn btn-outline" id="blImp">Imprimir para a fiscalização</button></div>`);
  document.getElementById('blOk').onclick = closeModal;
  document.getElementById('blImp').onclick = ()=> imprimir(`<h1 style="font-size:18pt;">Base legal do exame de vista por optometrista</h1><div style="font-size:11pt;line-height:1.5;">${baseLegalCorpoHtml().replace(/target="_blank"/g,'')}</div><p style="font-size:9pt;color:#666;margin-top:14px;">${esc(clinicaAtual?.nome_fantasia||'')} · impresso em ${fmtData(hojeISO())}</p>`);
}
function baseLegalPrimeira(){
  if(usuarioAtual?.papel==='atendente') return;
  try{ const k='agend_legal_'+(usuarioAtual?.email||''); if(localStorage.getItem(k)) return; localStorage.setItem(k,'1'); }catch(e){ return; }
  setTimeout(()=>abrirBaseLegal(true), 500);
}

function renderInicio(main){
  const nome = (usuarioAtual?.nome||'').split(' ')[0];
  const papel = usuarioAtual?.papel;
  const cidade = minhaUnidade()?.nome;
  const passo = (n,t,d)=>`<div style="display:flex;gap:12px;align-items:flex-start;margin:10px 0;"><div style="flex:0 0 30px;height:30px;border-radius:50%;background:#1F6F8B;color:#fff;font-weight:700;display:flex;align-items:center;justify-content:center;">${n}</div><div><b>${t}</b><div class="sub" style="margin:2px 0 0;">${d}</div></div></div>`;
  const ICS = {
    agenda:'<svg viewBox="0 0 24 24"><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4M8 14h2M14 14h2M8 18h2"/></svg>',
    confirma:'<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M8 12.5l3 3 5-6"/></svg>',
    olho:'<svg viewBox="0 0 24 24"><path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/></svg>',
    ficha:'<svg viewBox="0 0 24 24"><path d="M6 3h8l5 5v13H6z"/><path d="M14 3v5h5M9 13h6M9 17h6"/></svg>'
  };
  const bloco = (ic,t,d)=>`<div class="feat"><div class="feat-ic">${ICS[ic]||''}</div><b>${t}</b><span class="sub" style="margin:0;">${d}</span></div>`;
  let guia = '';
  if(papel==='atendente'){
    guia = `<h3 style="margin:18px 0 4px;font-size:15px;">Como marcar um exame${cidade?' em '+esc(cidade):''}</h3>
      ${passo(1,'Abra a Agenda','Escolha o dia. Os horários livres aparecem em cada dia aberto.')}
      ${passo(2,'Toque em um horário livre','Digite o nome e o telefone do paciente e confirme.')}
      ${passo(3,'No dia do exame, abra a Fila do dia','Toque em Chegou quando o paciente chegar.')}
      ${passo(4,'Use Confirmar e Mensagens','Confirme o comparecimento e envie a mensagem ao paciente.')}
      ${passo(5,'Se alguém cancelar','Veja a Lista de espera e ofereça o horário.')}`;
  } else if(papel==='profissional'){
    guia = `<h3 style="margin:18px 0 4px;font-size:15px;">Seu dia em 5 passos</h3>
      ${passo(1,'Abra a Fila do dia','Veja quem já chegou e quem está esperando.')}
      ${passo(2,'Toque em Iniciar','O paciente passa para Em atendimento.')}
      ${passo(3,'Abra Atendimento e faça o exame','Use o botão do microfone para ditar os valores. Confira cada campo.')}
      ${passo(4,'Emita a receita','Em Receita/Atestado, o grau do exame já vem preenchido.')}
      ${passo(5,'Toque em Finalizar na Fila do dia','O paciente vai para Atendidos e entra nos relatórios.')}`;
  } else {
    guia = `<div id="bvCheck"></div><h3 style="margin:18px 0 4px;font-size:15px;">Para começar</h3>
      ${passo(1,'Cadastre as cidades','Em Master, crie cada cidade onde haverá exame de vista.')}
      ${passo(2,'Abra os dias e horários','Em Agenda de exame de vista, defina dias e horários de cada cidade.')}
      ${passo(3,'Crie os agendadores','Em Usuários da clínica, escolha o papel Agendador e a cidade. Envie o acesso pelo WhatsApp.')}
      ${passo(4,'Acompanhe','No Painel e no Financeiro você vê exames, comparecimento e valores.')}`;
  }
  main.innerHTML = `<div class="card">
    <h2>${saudacao()}${nome?', '+esc(nome):''}!</h2>
    <p class="sub">Clínica de Visão: sistema de agendamento e atendimento de exame de vista em várias cidades. Versão ${esc(versaoSistema?.versao||'')}.</p>
    <p style="margin:10px 0;">Os agendadores marcam os pacientes de qualquer lugar, pelo celular ou pelo computador. Cada agendador vê só a cidade dele. A clínica recebe a agenda pronta e o paciente chega com horário e local confirmados.</p>
    <div style="display:flex;flex-wrap:wrap;gap:10px;margin:14px 0;">
      ${bloco('agenda','Agenda por cidade','Dias e horários de cada cidade, sem choque de horário.')}
      ${bloco('confirma','Confirmação e envios','Confirme o paciente e envie a mensagem com dia, hora e local.')}
      ${bloco('olho','Teste na tela','19 testes de visão: acuidade, Snellen, leitura de perto, daltonismo e educação ocular.')}
      ${bloco('ficha','Ficha do paciente','Dados, receita, atestado, prontuário e retorno em um lugar só.')}
    </div>
    ${guia}
    <button class="btn btn-primary btn-block" id="bvIr" style="margin-top:14px;">${papel==='atendente'?'Ir para a Agenda':'Ir para o Painel'}</button>
    <button class="btn btn-outline btn-block" id="bvLegal" style="margin-top:8px;">Base legal do exame de vista (vigilância)</button>
    <p class="sub" style="margin-top:10px;">Para ver esta tela de novo, toque em Início no menu.</p>
  </div>`;
  document.getElementById('bvLegal').onclick = ()=> abrirBaseLegal(false);
  if(papel!=='atendente') montarChecklistInicio();
  document.getElementById('bvIr').onclick = ()=> switchView(papel==='atendente'?'agenda':'painel');
}
async function montarChecklistInicio(){
  const box = document.getElementById('bvCheck'); if(!box) return;
  let ags=[], us=[];
  try{ ags = await api('/agendas'); }catch(e){}
  try{ us = await api('/clinica/usuarios'); }catch(e){}
  let seg = null; try{ seg = await api('/clinica/seguranca-status'); }catch(e){}
  let bk = null; try{ bk = await api('/clinica/backup-status'); }catch(e){}
  const itens = [
    ['Dados da clínica (endereço e telefone)', !!(clinicaAtual?.endereco && clinicaAtual?.telefone), 'master'],
    ['Pelo menos uma cidade cadastrada', unidades.length>0, 'master'],
    ['Toda cidade com o nome da cidade preenchido', unidades.length>0 && unidades.every(u=>(u.cidade||'').trim()), 'master'],
    ['Toda cidade com dias de exame abertos', unidades.length>0 && Array.isArray(ags) && unidades.every(u=>ags.some(a=>a.unidade_id===u.id)), 'master'],
    ['Tipo de atendimento com duração', tiposAtendimento.length>0, 'master'],
    ['Dias e horários abertos', Array.isArray(ags) && ags.length>0, 'master'],
    ['Pelo menos um agendador criado', Array.isArray(us) && us.some(u=>u.papel==='atendente'), 'master'],
    ['Todo agendador com a sua cidade', Array.isArray(us) && us.filter(u=>u.papel==='atendente').length>0 && us.filter(u=>u.papel==='atendente').every(u=>u.unidades_nomes&&u.unidades_nomes.length), 'master'],
    ...(seg ? [
      ['Backup baixado nos últimos 7 dias', !!(bk && bk.dias!==null && bk.dias<7), 'master'],
      ['Backup semanal por e-mail ligado', !!seg.backup_automatico, 'master'],
      ['Dados criptografados no servidor', seg.criptografia, 'master'],
      ['Código do celular ativo para o Master', seg.com_codigo>0, 'master'],
    ] : []),
  ];
  const feitos = itens.filter(i=>i[1]).length;
  if(feitos===itens.length){ box.innerHTML = '<p class="sub" style="margin:14px 0 0;">Tudo pronto para o piloto.</p>'; return; }
  box.innerHTML = `<div style="margin:16px 0;border:1px solid #E1E6EA;border-radius:12px;padding:14px;background:#F7FAFB;">
    <b>Pronto para o piloto: ${feitos} de ${itens.length}</b>
    <div style="height:6px;background:#E1E6EA;border-radius:4px;margin:8px 0 10px;"><div style="height:6px;width:${feitos*100/itens.length}%;background:#1F6F8B;border-radius:4px;"></div></div>
    ${itens.map(i=>`<div style="margin:6px 0;color:${i[1]?'#2E7D4F':'inherit'};">${i[1]?'✔':'○'} ${i[0]}</div>`).join('')}
    <button class="btn btn-outline btn-block" id="bvMaster" style="margin-top:10px;">Abrir Master</button></div>`;
  document.getElementById('bvMaster').onclick = ()=> switchView('master');
}
async function montarTotpPerfil(){
  const box = document.getElementById('pfTpBox'); if(!box) return;
  let ativo = false; try{ ativo = (await api('/auth/totp')).ativo; }catch(e){ box.innerHTML=''; return; }
  if(ativo){
    box.innerHTML = `<p class="sub" style="color:#2E7D4F;font-weight:600;">Ativo neste usuário.</p><button class="btn btn-outline btn-block" id="pfTpOff">Desligar</button>`;
    document.getElementById('pfTpOff').onclick = async ()=>{
      const s = prompt('Para desligar, digite sua senha:'); if(!s) return;
      try{ await api('/auth/totp', { method:'DELETE', body:{ senha:s } }); toast('Código do celular desligado.'); montarTotpPerfil(); }catch(e){ erroApi(e); }
    };
    return;
  }
  box.innerHTML = `<button class="btn btn-outline btn-block" id="pfTpOn">Ativar</button>`;
  document.getElementById('pfTpOn').onclick = async ()=>{
    try{
      const r = await api('/auth/totp/iniciar', { method:'POST', body:{} });
      let img = ''; try{ const qr = qrcode(0,'M'); qr.addData(r.otpauth); qr.make(); img = qr.createImgTag(5,6); }catch(e){}
      box.innerHTML = `<p class="sub">1. Abra o aplicativo de códigos no celular e escolha adicionar conta.<br>2. Leia este quadro com a câmera, ou digite a chave abaixo.<br>3. Digite aqui os 6 números que aparecerem.</p>
        <div style="text-align:center;margin:8px 0;">${img}</div>
        <p class="sub" style="word-break:break-all;text-align:center;"><b>${esc(r.segredo)}</b></p>
        <input type="text" id="pfTpCod" inputmode="numeric" maxlength="7" placeholder="6 números" style="text-align:center;font-size:20px;">
        <button class="btn btn-primary btn-block" id="pfTpOk" style="margin-top:8px;">Confirmar e ativar</button>`;
      document.getElementById('pfTpOk').onclick = async ()=>{
        try{ await api('/auth/totp/confirmar', { method:'POST', body:{ codigo: document.getElementById('pfTpCod').value } }); toast('Código do celular ativado.'); montarTotpPerfil(); }
        catch(e){ erroApi(e); }
      };
    }catch(e){ erroApi(e); }
  };
}
function renderPerfil(main){
  main.innerHTML = `<div class="card"><h2>Meu perfil</h2>
    <p class="sub">${esc(usuarioAtual?.email||'')} · ${esc(usuarioAtual?.papel==='atendente'?'agendador':usuarioAtual?.papel||'')}${minhasCidadesTexto()? ' · '+esc(minhasCidadesTexto()):''}</p>
    <label>Meu nome</label><input type="text" id="pfNome" value="${esc(usuarioAtual?.nome||'')}">
    <h3 style="margin:16px 0 4px;font-size:15px;">Trocar senha</h3>
    <p class="sub">Deixe em branco se não quer trocar.</p>
    <label>Senha atual</label><input type="password" id="pfAtual" autocomplete="current-password">
    <label>Senha nova (mínimo 6 letras ou números)</label><input type="password" id="pfNova" autocomplete="new-password">
    <button class="btn btn-primary btn-block" id="pfSalvar" style="margin-top:12px;">Salvar</button>
    <div class="btn-instalar" style="display:none;"><h3 style="margin:20px 0 4px;font-size:15px;">Instalar no celular</h3>
    <p class="sub">Coloca o ícone da Clínica de Visão na tela do celular e abre como um aplicativo.</p>
    <button class="btn btn-ghost btn-block" id="pfInstalar" type="button">Instalar o app</button></div>
    ${usuarioAtual?.papel==='admin' && unidades.length ? `<h3 style="margin:20px 0 4px;font-size:15px;">Cidade de trabalho</h3>
    <p class="sub">Escolha a cidade em que você vai agendar neste aparelho. Agenda, fila, confirmação e pacientes mostram só essa cidade. As outras ficam escondidas até você voltar para Todas as cidades.</p>
    <select id="pfCidade"><option value="">Todas as cidades</option>${unidades.map(u=>`<option value="${u.id}" ${cidadeTrabalho()===u.id?'selected':''}>${esc(u.nome)}</option>`).join('')}</select>
    <p class="sub" id="pfCidadeMsg">${cidadeTrabalho() ? 'Agora você vê só: '+esc((unidades.find(u=>u.id===cidadeTrabalho())||{}).nome||'')+'.' : 'Agora você vê todas as cidades.'}</p>` : ''}
    ${(usuarioAtual?.papel==='atendente'||usuarioAtual?.papel==='admin') ? `<h3 style="margin:20px 0 4px;font-size:15px;">Agendador offline</h3>
    <p class="sub">Versão pequena para o celular. Marca horários sem internet e envia sozinha quando a internet voltar.</p>
    <a class="btn btn-ghost btn-block" href="/agendador/" target="_blank" rel="noopener" style="text-align:center;text-decoration:none;">Abrir o agendador offline</a>` : ''}
    <h3 style="margin:20px 0 4px;font-size:15px;">Aparência deste aparelho</h3>
    <div id="pfAp">${aparenciaHtml()}</div>
    <h3 style="margin:20px 0 4px;font-size:15px;">Código do celular (segunda senha)</h3>
    <p class="sub" id="pfTpTxt">Uma segurança a mais: além da senha, o sistema pede 6 números que mudam a cada 30 segundos, de um aplicativo no seu celular.</p>
    <div id="pfTpBox"></div>
    <button class="btn btn-outline btn-block" id="pfSair" style="margin-top:8px;">Sair do sistema</button>
    <button class="btn btn-outline btn-block" id="pfSairTodos" style="margin-top:8px;">Sair de todos os aparelhos</button>
    <p class="sub">Use se perdeu o celular ou acha que alguém usou seu acesso. Todos os aparelhos precisam entrar de novo.</p>
    <p id="pfErr" style="color:#C1462F;font-size:12.5px;margin-top:8px;"></p></div>`;
  ligarAparencia(document.getElementById('pfAp'));
  { const pc = document.getElementById('pfCidade');
    if(pc) pc.onchange = ()=>{
      try{ if(pc.value) localStorage.setItem('agend_cidade_trabalho', pc.value); else localStorage.removeItem('agend_cidade_trabalho'); }catch(e){}
      toast(pc.value ? 'Cidade de trabalho salva. Atualizando.' : 'Mostrando todas as cidades. Atualizando.');
      setTimeout(()=>location.reload(), 700);
    };
  }
  const bInst = document.getElementById('pfInstalar'); if(bInst) bInst.onclick = instalarApp; atualizarBotoesInstalar();
  montarTotpPerfil();
  document.getElementById('pfSair').onclick = sair;
  document.getElementById('pfSairTodos').onclick = async ()=>{
    if(!confirm('Sair de todos os aparelhos? Você também vai precisar entrar de novo.')) return;
    try{ await api('/auth/sair-todos', { method:'POST', body:{} }); }catch(e){}
    sair();
  };
  document.getElementById('pfSalvar').onclick = async ()=>{
    const body = { nome: document.getElementById('pfNome').value.trim() };
    const nova = document.getElementById('pfNova').value;
    if(nova){ body.nova_senha = nova; body.senha_atual = document.getElementById('pfAtual').value; }
    try{
      const r = await api('/auth/eu', { method:'PATCH', body });
      usuarioAtual.nome = r.nome || body.nome;
      try{ localStorage.setItem('agend_usuario', JSON.stringify(usuarioAtual)); }catch(_){}
      document.getElementById('pfAtual').value=''; document.getElementById('pfNova').value='';
      document.getElementById('pfErr').textContent=''; toast('Perfil salvo.');
    }catch(e){ document.getElementById('pfErr').textContent = e.message; }
  };
}
/* cards recolhíveis: toque no título para abrir ou fechar. Poupa espaço na tela Master. */
function recolherCards(main, abertos){
  main.querySelectorAll('.card').forEach(card=>{
    const h = card.querySelector('h2'); if(!h || h.parentElement!==card) return;
    const corpo = document.createElement('div'); corpo.className='card-corpo';
    while(h.nextSibling) corpo.appendChild(h.nextSibling);
    card.appendChild(corpo);
    const aberto = abertos.includes(h.textContent.trim());
    corpo.style.display = aberto ? '' : 'none';
    h.style.cssText='cursor:pointer;display:flex;justify-content:space-between;align-items:center;margin:0;';
    const seta = document.createElement('span'); seta.style.cssText='font-size:14px;color:var(--ink-soft);'; seta.textContent = aberto ? '▾' : '▸';
    h.appendChild(seta);
    h.onclick = ()=>{ const fechado = corpo.style.display==='none'; corpo.style.display = fechado ? '' : 'none'; seta.textContent = fechado ? '▾' : '▸'; if(fechado) corpo.style.marginTop='12px'; };
  });
}
/* Master em abas: cada assunto numa aba, para achar tudo (backup, equipe, agenda) sem rolar a tela */
let abaMasterAtual = 'Clínica';
const ABAS_MASTER = {
  'Guardião': ['Guardião do sistema','Obrigações','Modo treino','Mapa de funções'],
  'Clínica': ['Atualização do sistema','Sessão','Dados da clínica','Ficha do paciente','Tipos de atendimento'],
  'Agenda': ['Agenda de exame de vista','Feriados da cidade'],
  'Equipe': ['Vigia da equipe','Cidades de exame de vista','Cadastro rápido em lote','Atividade da equipe','Usuários da clínica'],
  'Segurança': ['Segurança e dados','Estado da segurança','Licença','Ajuda e status','Versões do sistema','Exportar dados'],
  'Integrações': ['Integração com assistente externo (ex: WhatsApp)','WhatsApp automático','Assistente de IA']
};
function abasMaster(main){
  const cards = [...main.querySelectorAll(':scope > .card')];
  const de = (c)=>{ const h = c.querySelector('h2'); const t = h ? h.firstChild.textContent.trim() : ''; for(const [aba, l] of Object.entries(ABAS_MASTER)) if(l.includes(t)) return aba; return 'Clínica'; };
  cards.forEach(c=> c.dataset.aba = de(c));
  /* dentro de cada aba, os quadros seguem a ordem da lista acima */
  const titulo = (c)=>{ const h = c.querySelector('h2'); return h ? h.firstChild.textContent.trim() : ''; };
  const ordemAbas = Object.keys(ABAS_MASTER);
  const pos = (c)=>{ const l = ABAS_MASTER[c.dataset.aba]||[]; const i = l.indexOf(titulo(c)); return ordemAbas.indexOf(c.dataset.aba)*100 + (i<0?99:i); };
  cards.map((c,i)=>({c,i,p:pos(c)})).sort((a,b)=> a.p-b.p || a.i-b.i).forEach(x=> main.appendChild(x.c));
  const abas = Object.keys(ABAS_MASTER).filter(a=> cards.some(c=>c.dataset.aba===a));
  if(!abas.includes(abaMasterAtual)) abaMasterAtual = abas[0];
  const barra = document.createElement('div'); barra.className = 'abas-master';
  const mostrar = ()=>{ cards.forEach(c=> c.style.display = c.dataset.aba===abaMasterAtual ? '' : 'none'); barra.querySelectorAll('button').forEach(b=> b.classList.toggle('on', b.dataset.aba===abaMasterAtual)); };
  barra.innerHTML = abas.map(a=>`<button type="button" data-aba="${a}">${a}</button>`).join('');
  barra.querySelectorAll('button').forEach(b=> b.onclick = ()=>{ abaMasterAtual = b.dataset.aba; mostrar(); window.scrollTo({top:0}); });
  main.insertBefore(barra, main.firstChild);
  mostrar();
}
function fichaMasterCardHtml(){
  const grupos = [['Dados pessoais',['telefone','cpf','data_nascimento','email','sexo','profissao']],['Endereço',['cep','endereco','bairro']],['Saúde dos olhos',['usa_oculos','queixa','ultimo_exame','cirurgia_ocular']],['Saúde geral',['doencas','alergias','medicamentos','historico_familiar']],['Outros',['indicacao','observacoes']],['Fotos',['foto_receita','foto_armacao']]];
  const opt = (k,v,t)=>`<option value="${v}" ${fichaEstado(k)===v?'selected':''}>${t}</option>`;
  return `<div class="card"><h2>Ficha do paciente</h2>
    <p class="sub">Escolha o que pedir de cada paciente. Vale para o formulário que o paciente preenche e para a ficha interna. O nome é sempre obrigatório. Na ficha do paciente há o botão Imprimir ficha.</p>
    ${grupos.map(([g,ks])=>`<h3 style="margin:14px 0 4px;font-size:14px;color:var(--ink-soft);">${g}</h3>${ks.map(k=>{ const d = FICHA_DEF.find(x=>x[0]===k); return `<div style="display:flex;justify-content:space-between;align-items:center;gap:10px;margin:6px 0;"><span style="font-size:14px;">${d[1]}</span><select id="fc_${k}" style="width:auto;min-width:130px;">${opt(k,'oculto','Não pedir')}${opt(k,'opcional','Opcional')}${opt(k,'obrigatorio','Obrigatório')}</select></div>`; }).join('')}`).join('')}
    <button class="btn btn-ghost btn-block" id="mSalvarFicha" style="margin-top:14px;">Salvar ficha</button></div>`;
}
function ligarSegurancaMaster(){
  const box = document.getElementById('mSegStatus'); if(!box) return;
  (async ()=>{
    try{
      const s = await api('/clinica/seguranca-status');
      const linha = (ok, titulo, ajuda)=>`<div style="margin:8px 0;"><span style="color:${ok?'#2E7D4F':'#B26A00'};font-weight:700;">${ok?'✔':'○'}</span> <b>${titulo}</b>${ok?'':`<div class="sub" style="margin:2px 0 0 18px;">${ajuda}</div>`}</div>`;
      box.innerHTML =
        linha(s.criptografia,'Dados criptografados no banco','Falta a variável CHAVE_CRIPTOGRAFIA no servidor.') +
        linha(s.email,'Envio de e-mail (recuperar senha e avisos)','Falta ligar: SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS e EMAIL_DE na Render.') +
        linha(s.backup_automatico,'Backup semanal por e-mail','Precisa do e-mail ligado, mais BACKUP_EMAIL_PARA e BACKUP_SENHA (8+ caracteres).') +
        linha(s.whatsapp_meta,'WhatsApp automático (chave da Meta)','Faltam WA_TOKEN e WA_PHONE_ID.') +
        linha(s.com_codigo>0,'Código do celular em uso', 'Ative em Meu perfil. ' + s.com_codigo + ' de ' + s.usuarios + ' usuários usam.') +
        `<p class="sub" style="margin-top:10px;">Usuários com código do celular: ${s.com_codigo} de ${s.usuarios}.</p>`;
    }catch(e){ box.innerHTML = `<p class="fieldmsg bad">${esc(e.message)}</p>`; }
  })();
  (async ()=>{
    try{
      const l = await api('/clinica/licenca');
      if(!l.controle) return; // servidor sem controle de licença: esconde o cartão
      document.getElementById('mLicencaCard').style.display = '';
      const t = document.getElementById('mLicencaInfo');
      t.textContent = l.valida ? (l.ate ? `Licença válida até ${fmtData(l.ate)} (${l.dias} dias).` : 'Licença válida.') : (l.motivo==='sem_chave' ? 'Esta clínica ainda não tem chave de licença.' : 'A licença venceu ou é inválida. Cole a chave nova.');
      t.style.color = l.valida ? '' : '#C1462F';
      document.getElementById('mLicencaSalvar').onclick = async ()=>{
        try{ const r = await api('/clinica/licenca', { method:'POST', body:{ chave: document.getElementById('mLicencaChave').value } }); toast('Licença salva. Vale até '+fmtData(r.ate)+'.'); ligarSegurancaMaster(); }
        catch(e){ erroApi(e); }
      };
    }catch(e){}
  })();
}
/* v4.9.26 botão Atualizar sistema (Master) */
function atualizacaoCardHtml(){
  setTimeout(carregarAtualizacao, 50);
  return `<div class="card" id="cardAtualizacao"><h2>Atualização do sistema</h2><div id="atuCorpo"><p class="sub">Conferindo a versão...</p></div></div>`;
}
let atuEsperando = null;
async function carregarAtualizacao(){
  const c = document.getElementById('atuCorpo'); if(!c) return;
  let d; try{ d = await api('/atualizacao'); }catch(e){ c.innerHTML = `<p class="sub">${esc(e.message)}</p>`; return; }
  const linha = `<p style="margin:0 0 6px;">No ar: <strong>${esc(d.no_ar)}</strong>${d.github?` · No GitHub: <strong>${esc(d.github)}</strong>`:''}</p>`;
  if(atuEsperando){ c.innerHTML = linha + `<p class="sub">Instalando a versão nova. Leva de 3 a 5 minutos. Pode continuar usando; a tela avisa quando terminar.</p>`; return; }
  const msg = d.erro_github ? `<p class="sub">${esc(d.erro_github)}</p>` : d.tem_nova ? `<p class="sub" style="color:var(--warn,#9a6700);">Tem versão nova no GitHub esperando para instalar.</p>` : `<p class="sub">O sistema está na versão mais nova.</p>`;
  const botao = d.pode_instalar
    ? `<button class="btn btn-primary btn-block" id="atuBotao" type="button">Atualizar sistema agora</button>`
    : `<p class="sub">Para o botão funcionar, coloque no Render, em Environment, a variável RENDER_DEPLOY_HOOK com o endereço do Deploy Hook (Render, serviço clinica-visao, Settings, Deploy Hook).</p>`;
  c.innerHTML = linha + msg + botao;
  const b = document.getElementById('atuBotao');
  if(b) b.onclick = async ()=>{
    if(!d.tem_nova && !confirm('O sistema já está na versão mais nova. Instalar de novo mesmo assim?')) return;
    b.disabled = true; b.textContent = 'Pedindo ao Render...';
    try{ await api('/atualizacao', { method:'POST', body:{} }); atuEsperando = { de: d.no_ar, desde: Date.now() }; toast('Atualização pedida. Leva de 3 a 5 minutos.'); carregarAtualizacao(); esperarAtualizacao(); }
    catch(e){ b.disabled = false; b.textContent = 'Atualizar sistema agora'; erroApi(e); }
  };
}
function esperarAtualizacao(){
  const t = setInterval(async ()=>{
    if(!atuEsperando){ clearInterval(t); return; }
    try{
      const r = await fetch((API_BASE||'')+'/versao', { cache:'no-store' });
      const v = r.ok ? await r.json() : null;
      if(v && v.versao && v.versao !== atuEsperando.de){
        clearInterval(t); atuEsperando = null;
        try{ if(window.caches){ const ks = await caches.keys(); await Promise.all(ks.map(k=>caches.delete(k))); } }catch(e){}
        alert('Sistema atualizado para a versão '+v.versao+'. A tela vai recarregar.');
        location.reload();
      } else if(Date.now() - atuEsperando.desde > 15*60000){ clearInterval(t); atuEsperando = null; toast('A atualização está demorando. Confira no Render.'); carregarAtualizacao(); }
    }catch(e){}
  }, 20000);
}

function renderMaster(main){
  main.innerHTML = `
    ${usuarioAtual?.papel==='admin' ? atualizacaoCardHtml() : ''}
    ${usuarioAtual?.papel==='admin' ? guardiaoCardsHtml() : ''}
    ${usuarioAtual?.unidadeId ? `<div class="card"><h2>Sessão</h2>
      <p class="sub">Você só vê pacientes e agendamentos de <strong>${esc(minhasCidadesTexto()||'sua cidade')}</strong>.</p></div>` : ''}

    <div class="card">
      <h2>Dados da clínica</h2>
      <label>Nome exibido no topo do app</label>
      <input type="text" id="mNome" value="${clinicaAtual?.nome_fantasia||''}">
      <label>Endereço</label>
      <input type="text" id="mEndereco" value="${clinicaAtual?.endereco||''}">
      <label>Local padrão do exame</label>
      <input type="text" id="mLocal" value="${clinicaAtual?.local_exame_padrao||''}">
      <label>Telefone</label>
      <input type="text" id="mTelefone" value="${clinicaAtual?.telefone||''}">
      <label>Quem pode assinar receita e atestado</label>
      <select id="mPolitica"><option value="medico_e_optometrista" ${clinicaAtual?.politica_profissionais!=='so_medico'?'selected':''}>Médico e optometrista</option><option value="so_medico" ${clinicaAtual?.politica_profissionais==='so_medico'?'selected':''}>Só médico (CRM)</option></select>
      <p class="sub" style="margin:4px 0 0;">Escolha conforme o parecer do seu advogado. Em "só médico", o servidor recusa receita e atestado de quem não tem CRM.</p>
      <label>Link público do site (onde o cadastro-paciente.html está hospedado)</label>
      <input type="text" id="mLinkSite" value="${clinicaAtual?.link_site||(SERVIDOR_PROPRIO?location.origin+'/':'')}" placeholder="https://clinica-visao.onrender.com/">
      <label>Logomarca <span style="font-weight:400;color:var(--ink-soft);">(aparece no topo da receita e do atestado impressos)</span></label>
      ${clinicaAtual?.logo_url ? `<img src="${clinicaAtual.logo_url}" alt="Logo atual" style="max-height:70px;display:block;margin:6px 0;">` : ''}
      <input type="file" id="mLogo" accept="image/*">
      <p class="fieldmsg" id="mLogo_msg"></p>
      <button class="btn btn-ghost btn-block" id="mSalvarDados" style="margin-top:12px;">Salvar dados</button>
    </div>


    <div class="card" id="cardIA">
      <h2>Assistente de IA</h2>
      <p class="sub" id="iaStatus">Verificando...</p>
      <h3 style="margin:10px 0 4px;font-size:15px;">Conversar</h3>
      <p class="sub">Fale ou digite. Ela conhece as funções do sistema e o que o Guardião está avisando. Pergunte, por exemplo: "o que preciso arrumar no Master?" ou "como libero horários em Rondonópolis?". Para arrumar um item, ela explica e espera seu sim.</p>
      <div id="iaChat" style="max-height:280px;overflow:auto;border:1px solid var(--line);border-radius:12px;padding:8px;margin:8px 0;display:none;"></div>
      <div class="btn-row" style="gap:8px;flex-wrap:wrap;">
        <button type="button" class="btn btn-primary" id="iaMic">Falar</button>
        <button type="button" class="btn btn-ghost" id="iaParar">Parar</button>
      </div>
      <label style="display:flex;gap:8px;align-items:center;margin-top:8px;"><input type="checkbox" id="iaVoz" checked> Ela responde falando</label>
      <label style="display:flex;gap:8px;align-items:center;margin-top:4px;"><input type="checkbox" id="iaCont"> Conversa contínua (ela volta a ouvir depois de falar)</label>
      <div style="display:flex;gap:8px;margin-top:8px;"><input type="text" id="iaDigita" placeholder="Ou digite aqui" style="flex:1;min-width:0;"><button type="button" class="btn btn-outline" id="iaEnv">Enviar</button></div>
      <div id="iaAcaoBox"></div>
      <p class="fieldmsg" id="iaChatMsg"></p>
      <p class="sub" id="iaVozAviso" style="margin-top:6px;">No Chrome, a voz que você fala é enviada ao Google para virar texto. Não diga nome, CPF ou dados de paciente.</p>
      <h3 style="margin:16px 0 4px;font-size:15px;">Mandar foto para a IA</h3>
      <p class="sub">Receita, olho, pálpebra ou laudo de exame (OCT, retinografia, campo visual, topografia). A IA lê, compara com os valores de referência, aponta o que está alterado e diz se precisa encaminhar. Quem confirma o diagnóstico é o médico.</p>
      <button type="button" class="btn btn-ghost btn-block" data-foto-ia="1">Mandar foto</button>
      <h3 style="margin:16px 0 4px;font-size:15px;">Gerar um texto</h3>
      <p class="sub">Peça uma mensagem ou explicação e copie o resultado. O sistema apaga CPF, e-mail e telefone do pedido antes de enviar.</p>
      <textarea id="iaPedido" rows="3" maxlength="1500" placeholder="Ex.: Escreva uma mensagem curta lembrando o exame de vista de amanhã."></textarea>
      <button class="btn btn-primary btn-block" id="iaEnviar" style="margin-top:10px;">Gerar texto</button>
      <p class="fieldmsg" id="iaMsg"></p>
      <textarea id="iaResp" rows="6" readonly style="display:none;margin-top:8px;"></textarea>
      <button class="btn btn-ghost btn-block" id="iaCopiar" style="display:none;margin-top:8px;">Copiar texto</button>
    </div>

    ${(usuarioAtual?.papel==='admin' && !usuarioAtual?.unidadeId) ? vigiaCardHtml() : ''}

    <div class="card" id="cardAtividade">
      <h2>Atividade da equipe</h2>
      <p class="sub">Veja quem entrou no sistema, quando usou pela última vez e o que fez. Toque numa pessoa para ver o que ela fez, hora por hora.</p>
      <div class="btn-row" id="atPeriodo" style="margin:6px 0 10px;"><button type="button" class="btn btn-sm btn-primary" data-d="1">24 horas</button><button type="button" class="btn btn-sm btn-ghost" data-d="7">7 dias</button><button type="button" class="btn btn-sm btn-ghost" data-d="30">30 dias</button></div>
      <div id="atLista"><p class="sub">Carregando...</p></div>
      <p class="sub" style="margin-top:10px;">O sistema registra a entrada, o uso e o que a pessoa marca ou altera. Quando o agendador trabalha sem internet no aplicativo offline, o sistema só vê quando ele sincroniza.</p>
    </div>

    <div class="card">
      <h2>Usuários da clínica</h2>
      <p class="sub">Cada atendente entra com seu próprio e-mail e senha.</p>
      <div id="listaUsuarios">Carregando...</div>
      <div class="row2" style="margin-top:12px;">
        <div><label>Nome</label><input type="text" id="uNome"></div>
        <div><label>E-mail</label><input type="text" id="uEmail"></div>
      </div>
      <div class="row2">
        <div><label>Senha</label><input type="password" id="uSenha"></div>
        <div><label>Papel</label><select id="uPapel"><option value="atendente">Agendador (marca os horários)</option><option value="profissional">Profissional (faz exame, acessa o prontuário)</option><option value="gestor">Gestor de vendas (pós-exame e OCO, sem acesso ao resto)</option><option value="admin">Admin</option></select></div>
      </div>
      ${unidades.length ? `<label>Cidades que esta pessoa atende</label>
      <p class="sub" style="margin:0 0 4px;">Agendador: marque uma ou mais cidades. Ele só vê pacientes e horários dessas cidades. Admin, profissional e gestor: sem marcar, veem todas.</p>
      <div id="uCidades">${cidadesCheckboxes([], 'data-cid')}</div>` : ''}
      <div id="blocoProfissional" style="display:none;margin-top:10px;border-top:1px solid var(--line);padding-top:10px;">
        <p class="sub" style="margin-top:0;">Esses dados saem impressos na receita e no atestado.</p>
        <label>Registro no conselho <span style="font-weight:400;color:var(--ink-soft);">(ex: CRO 12345)</span></label>
        <input type="text" id="uRegistro" placeholder="CRO 12345">
        <label>Formação superior <span style="font-weight:400;color:var(--ink-soft);">(curso e instituição reconhecida pelo MEC)</span></label>
        <input type="text" id="uFormacao" maxlength="200" placeholder="Optometria, Centro Universitário Fulano">
        <label>Tipo do curso</label>
        <select id="uFormTipo"><option value="">Não informado</option><option value="bacharelado">Bacharelado</option><option value="tecnologo">Tecnológico (tecnólogo)</option></select>
        <label>Reconhecimento do MEC <span style="font-weight:400;color:var(--ink-soft);">(portaria do curso)</span></label>
        <input type="text" id="uFormPortaria" maxlength="160" placeholder="Portaria nº 123, de 01/02/2020">
        <label>Texto do carimbo</label>
        <input type="text" id="uCarimbo" placeholder="Dr(a) Fulano de Tal - CRO 12345">
        <label>Imagem da assinatura <span style="font-weight:400;color:var(--ink-soft);">(opcional, foto ou print da assinatura)</span></label>
        <input type="file" id="uAssinatura" accept="image/*">
        <p class="fieldmsg" id="uAssinatura_msg"></p>
      </div>
      <button class="btn btn-ghost btn-block" id="mAddUsuario" style="margin-top:10px;">+ Adicionar usuário</button>
    </div>

    ${usuarioAtual?.papel==='admin' ? `<div class="card">
      <h2>Integração com assistente externo (ex: WhatsApp)</h2>
      <p class="sub">Essa chave identifica sua clínica pra um assistente automático consultar horário livre e marcar sozinho, sem precisar de login de atendente. Guarde ela com cuidado, quem tiver essa chave consegue criar agendamentos na sua agenda.</p>
      <label>Identificador da clínica (slug)</label>
      <input type="text" id="mSlugIntegracao" value="${clinicaAtual?.slug||''}" readonly>
      <label>Chave de integração</label>
      <input type="text" id="mChaveIntegracao" value="Carregando..." readonly>
      <button class="btn btn-ghost btn-block" id="mCopiarChave" style="margin-top:10px;">Copiar chave</button>
    </div>` : ''}

    ${usuarioAtual?.papel==='admin' ? `<div class="card">
      <h2>WhatsApp automático</h2>
      <p class="sub">O sistema envia sozinho a confirmação, o lembrete de 24 horas, o de 2 horas e o pós atendimento, entre 8h e 20h. Se o paciente responde SIM, o exame fica confirmado. Se responde NÃO, fica cancelado.</p>
      <label>Número de WhatsApp da clínica (com DDD)</label>
      <input type="text" id="wNumero" inputmode="tel" value="${esc(clinicaAtual?.whatsapp_numero||'64992161203')}" placeholder="(64) 99216-1203">
      <label>Envio automático</label>
      <select id="wAuto"><option value="false" ${clinicaAtual?.whatsapp_auto?'':'selected'}>Desligado (a equipe toca em WhatsApp)</option><option value="true" ${clinicaAtual?.whatsapp_auto?'selected':''}>Ligado</option></select>
      <p class="sub" id="wStatus" style="margin-top:10px;">Conferindo o servidor...</p>
      <button class="btn btn-ghost btn-block" id="wSalvar" style="margin-top:10px;">Salvar WhatsApp</button>
      <label style="margin-top:14px;">Enviar uma mensagem de teste para</label>
      <input type="text" id="wTesteTel" inputmode="tel" placeholder="(64) 99999-9999">
      <button class="btn btn-outline btn-block" id="wTeste" style="margin-top:8px;">Enviar teste</button>
    </div>

    <div class="card">
      <h2>Segurança e dados</h2>
      <p class="sub">Backup: baixa uma cópia completa de todos os dados da clínica. Guarde o arquivo no seu computador e no Google Drive. Registro de acessos: mostra quem abriu ou alterou dados de pacientes, receitas e prontuários.</p>
      <p class="sub" id="mBackupInfo" style="font-weight:600;">Verificando o último backup...</p>
      <button class="btn btn-ghost btn-block" id="mBackup">Baixar backup dos dados</button>
      <button class="btn btn-outline btn-block" id="mAcessos" style="margin-top:8px;">Ver registro de acessos</button>
    </div>` : ''}


    ${usuarioAtual?.papel==='admin' ? `<div class="card">
      <h2>Estado da segurança</h2>
      <p class="sub">O que já está ligado no servidor. O que estiver pendente depende de uma chave que você coloca na Render, em Environment.</p>
      <div id="mSegStatus"><p class="sub">Verificando...</p></div>
    </div>
    <div class="card" id="mLicencaCard" style="display:none;">
      <h2>Licença</h2>
      <p class="sub" id="mLicencaInfo">Verificando...</p>
      <label>Chave de licença</label>
      <input type="text" id="mLicencaChave" placeholder="CV1...">
      <button class="btn btn-ghost btn-block" id="mLicencaSalvar" style="margin-top:10px;">Salvar chave</button>
    </div>` : ''}

    <div class="card">
      <h2>Ajuda e status</h2>
      <p class="sub">O guia mostra o passo a passo de cada perfil. A página de status confere se o servidor e o banco estão no ar.</p>
      <div class="btn-row"><a class="btn btn-ghost" href="/guia.html" target="_blank" rel="noopener" style="text-decoration:none;">Guia por perfil</a><a class="btn btn-ghost" href="/status.html" target="_blank" rel="noopener" style="text-decoration:none;">Status do sistema</a></div>
    </div>

    <div class="card">
      <h2>Versões do sistema</h2>
      <p class="sub">Versão em uso: <strong>${esc(versaoSistema?.versao||'?')}</strong>. Cada atualização nova tem um número maior.</p>
      ${(versaoSistema?.historico||[]).map(v=>`<div class="list-item"><div><div class="name">Versão ${esc(v.versao)} · ${esc(fmtData(v.data))}</div><div class="meta">${esc(v.notas)}</div></div></div>`).join('')}
    </div>

    ${fichaMasterCardHtml()}

    <div class="card">
      <h2>Tipos de atendimento</h2>
      <p class="sub">Cada tipo tem sua duração e o intervalo automático que fica livre depois.</p>
      ${renderTiposList()}
      <div class="row3" style="margin-top:14px;">
        <div><label>Nome</label><input type="text" id="tpNome" placeholder="Ex: Exame completo"></div>
        <div><label>Duração (min)</label><input type="text" id="tpDuracao" inputmode="numeric" placeholder="30"></div>
        <div><label>Intervalo (min)</label><input type="text" id="tpBuffer" inputmode="numeric" placeholder="10"></div>
      </div>
      <label>Preço padrão em R$ <span style="font-weight:400;color:var(--ink-soft);">(opcional, já vem preenchido na cobrança)</span></label>
      <input type="text" id="tpPreco" inputmode="decimal" placeholder="100,00" style="max-width:200px;">
      <button class="btn btn-ghost btn-block" id="mAddTipo" style="margin-top:10px;">+ Adicionar tipo de atendimento</button>
    </div>

    ${usuarioAtual?.papel!=='admin' ? '' : `
    <div class="card">
      <h2>Cidades de exame de vista</h2>
      <p class="sub">Cada cidade tem seu próprio link de cadastro e sua própria agenda. Um atendente vinculado a uma cidade só vê o que é daquela cidade.</p>
      ${renderUnidadesList()}
      <div class="row2" style="margin-top:14px;">
        <div><label>Nome do evento</label><input type="text" id="unNome" placeholder="Ex: Exame de vista Nov 2026"></div>
        <div><label>Identificador do link <span style="font-weight:400;color:var(--ink-soft);">(opcional)</span></label><input type="text" id="unSlug" placeholder="sai sozinho"></div>
      </div>
      <div class="row2">
        <div><label>Cidade (aparece para o agendador e para o paciente)</label><input type="text" id="unCidade" placeholder="Santa Cruz de Goiás"></div>
        <div><label>Local do exame</label><input type="text" id="unLocal" placeholder="Endereço do exame"></div>
      </div>
      <button class="btn btn-ghost btn-block" id="mAddUnidade" style="margin-top:10px;">+ Adicionar cidade</button>
    </div>
    <div class="card" id="cardLote">
      <h2>Cadastro rápido em lote</h2>
      <p class="sub">Cadastre até 20 cidades e até 30 agendadores de uma vez. Escreva um por linha. O sistema cria o acesso e a senha de cada agendador e monta a mensagem para mandar pelo WhatsApp.</p>
      <label>Cidades <span style="font-weight:400;color:var(--ink-soft);">(uma por linha: Cidade; Local do exame)</span></label>
      <textarea id="ltCidades" rows="5" placeholder="Cristianópolis; Espaço odontológico&#10;Piracanjuba; Salão paroquial&#10;Pontalina"></textarea>
      <p class="sub" id="ltCidCont" style="margin:4px 0 0;">0 de 20</p>
      <label>Agendadores <span style="font-weight:400;color:var(--ink-soft);">(um por linha: Nome; Cidade; Telefone)</span></label>
      <textarea id="ltAgend" rows="6" placeholder="Joana da Silva; Cristianópolis; 64 99999-1111&#10;Pedro Souza; Piracanjuba, Pontalina; 64 98888-2222"></textarea>
      <p class="sub" id="ltAgCont" style="margin:4px 0 0;">0 de 30. Para mais de uma cidade, separe com vírgula.</p>
      <button class="btn btn-primary btn-block" id="ltEnviar" style="margin-top:12px;">Cadastrar tudo</button>
      <div id="ltResultado"></div>
    </div>`}

    ${usuarioAtual?.papel==='admin' ? agendaMasterCardHtml() + feriadosLocaisCardHtml() : ''}
    ${usuarioAtual?.papel==='admin' ? cadastrosMasterCardHtml() + impressaoMasterCardHtml() : ''}

    <div class="card">
      <h2>Exportar dados</h2>
      <p class="sub">Backup em CSV de pacientes e agendamentos carregados nesta sessão.</p>
      <button class="btn btn-ghost btn-block" id="mExportCsv">Exportar CSV</button>
    </div>
  `;


  if(document.getElementById('wSalvar')){
    api('/clinica/whatsapp-status').then(st=>{
      const partes = [];
      partes.push(st.servidor_configurado ? 'Chaves da Meta: ligadas no servidor.' : 'Chaves da Meta: ainda não colocadas no servidor (veja o passo a passo).');
      if(st.servidor_configurado){ partes.push(st.modelo_configurado ? 'Modelo de mensagem: configurado.' : 'Modelo de mensagem: falta (a Meta só deixa a clínica começar conversa com modelo aprovado).'); partes.push(st.webhook_configurado ? 'Respostas SIM/NÃO: ligadas.' : 'Respostas SIM/NÃO: faltam WA_VERIFY_TOKEN e WA_APP_SECRET.'); }
      partes.push('Endereço do webhook: '+st.endereco_webhook);
      document.getElementById('wStatus').textContent = partes.join(' ');
    }).catch(()=>{ document.getElementById('wStatus').textContent = ''; });
    document.getElementById('wSalvar').onclick = async ()=>{
      try{
        clinicaAtual = await api('/clinica', { method:'PUT', body:{ nome_fantasia: clinicaAtual.nome_fantasia, endereco: clinicaAtual.endereco, local_exame_padrao: clinicaAtual.local_exame_padrao,
          telefone: clinicaAtual.telefone, link_site: clinicaAtual.link_site, logo_url: clinicaAtual.logo_url || null, campos_obrigatorios: clinicaAtual.campos_obrigatorios,
          whatsapp_numero: document.getElementById('wNumero').value, whatsapp_auto: document.getElementById('wAuto').value==='true' }});
        toast('WhatsApp salvo.');
      }catch(e){ erroApi(e); }
    };
    document.getElementById('wTeste').onclick = async ()=>{
      try{ await api('/clinica/whatsapp-teste', { method:'POST', body:{ telefone: document.getElementById('wTesteTel').value }}); toast('Teste enviado.'); }
      catch(e){ erroApi(e); }
    };
    async function mostrarStatusBackup(){
      const el = document.getElementById('mBackupInfo'); if(!el) return;
      try{
        const st = await api('/clinica/backup-status');
        if(st.dias===null){ el.textContent = 'Nenhum backup feito ainda. Baixe um agora.'; el.style.color = 'var(--danger,#c0392b)'; }
        else if(st.dias>=7){ el.textContent = 'Último backup há '+st.dias+' dias. Baixe um novo.'; el.style.color = 'var(--danger,#c0392b)'; }
        else { el.textContent = st.dias===0 ? 'Último backup: hoje.' : 'Último backup há '+st.dias+(st.dias===1?' dia.':' dias.'); el.style.color = ''; }
      }catch(e){ el.textContent = ''; }
    }
    mostrarStatusBackup();
    document.getElementById('mBackup').onclick = ()=>{
      openModal(`<h2>Backup protegido</h2>
        <p class="sub">Escolha uma senha para trancar o arquivo. Sem ela ninguém abre o backup, nem você. Anote em lugar seguro.</p>
        <label>Senha do backup (mínimo 8 caracteres)</label><input type="password" id="bkSenha" autocomplete="new-password">
        <label>Repita a senha</label><input type="password" id="bkSenha2" autocomplete="new-password">
        <p id="bkErr" style="color:#C1462F;font-size:13px;"></p>
        <div class="btn-row"><button class="btn btn-primary" id="bkGerar">Baixar backup</button><button class="btn btn-outline" onclick="closeModal()">Cancelar</button></div>`);
      document.getElementById('bkGerar').onclick = async ()=>{
        const a = document.getElementById('bkSenha').value, b = document.getElementById('bkSenha2').value, err = document.getElementById('bkErr');
        if(a.length<8){ err.textContent = 'A senha precisa ter pelo menos 8 caracteres.'; return; }
        if(a!==b){ err.textContent = 'As duas senhas não são iguais.'; return; }
        try{
          err.textContent = 'Gerando o backup...';
          const dados = await api('/clinica/backup', { method:'POST', body:{ senha:a } });
          const blob = new Blob([JSON.stringify(dados)], {type:'application/json'});
          const l = document.createElement('a'); l.href = URL.createObjectURL(blob); l.download = 'backup-clinica-'+hojeISO()+'.json'; l.click();
          setTimeout(()=>URL.revokeObjectURL(l.href), 5000);
          closeModal(); toast('Backup baixado. Guarde a senha.'); mostrarStatusBackup();
        }catch(e){ err.textContent = ''; erroApi(e); }
      };
    };
    document.getElementById('mAcessos').onclick = async ()=>{
      try{
        const lista = await api('/clinica/acessos');
        const linhas = lista.map(l=>`<tr><td>${esc(new Date(String(l.criado_em).slice(0,19)+'Z').toLocaleString('pt-BR',{dateStyle:'short',timeStyle:'short'}))}</td><td>${esc(l.usuario_nome||'')}</td><td>${esc(l.acao)} ${esc(l.area)}</td></tr>`).join('');
        openModal(`<h2>Registro de acessos</h2><p class="sub">Últimos 300 acessos a dados de saúde.</p><div style="max-height:55vh;overflow:auto;"><table style="width:100%;font-size:13px;border-collapse:collapse;"><tr><th align="left">Quando</th><th align="left">Quem</th><th align="left">O quê</th></tr>${linhas||'<tr><td colspan="3">Nenhum acesso ainda.</td></tr>'}</table></div><div class="btn-row" style="margin-top:12px;"><button class="btn btn-outline" onclick="closeModal()">Fechar</button></div>`);
      }catch(e){ erroApi(e); }
    };
  }
  ligarFeriadosLocais();
  ligarSegurancaMaster();
  ligarGuardiao();
  recolherCards(main, ['Vigia da equipe','Guardião do sistema','Obrigações','Mapa de funções','Cidades de exame de vista','Agenda de exame de vista','Usuários da clínica','Segurança e dados','Estado da segurança']);
  abasMaster(main);
  const btnCopiarChave = document.getElementById('mCopiarChave');
  if(btnCopiarChave){
    (async ()=>{
      try{
        const r = await api('/clinica/chave-integracao');
        document.getElementById('mChaveIntegracao').value = r.chave_integracao || '';
      }catch(e){ document.getElementById('mChaveIntegracao').value = 'Não foi possível carregar.'; }
    })();
    btnCopiarChave.onclick = async ()=>{
      try{
        await navigator.clipboard.writeText(document.getElementById('mChaveIntegracao').value);
        toast('Chave copiada.');
      }catch(e){ toast('Não consegui copiar. Copie manualmente o texto do campo.'); }
    };
  }

  let novaLogoBase64 = null;
  const mLogoEl = document.getElementById('mLogo');
  if(mLogoEl) mLogoEl.addEventListener('change', e=>{
    const arq = e.target.files[0];
    const msg = document.getElementById('mLogo_msg');
    if(!arq){ novaLogoBase64=null; msg.textContent=''; return; }
    if(arq.size > 1.5*1024*1024){ msg.textContent='Imagem muito grande, escolha uma menor que 1,5 MB.'; msg.className='fieldmsg bad'; e.target.value=''; novaLogoBase64=null; return; }
    const leitor = new FileReader();
    leitor.onload = ()=>{ novaLogoBase64 = leitor.result; msg.textContent='Nova logo carregada, clique em Salvar dados pra confirmar.'; msg.className='fieldmsg ok'; };
    leitor.readAsDataURL(arq);
  });

  document.getElementById('mSalvarDados').onclick = async ()=>{
    try{
      clinicaAtual = await api('/clinica', { method:'PUT', body:{
        nome_fantasia: document.getElementById('mNome').value,
        endereco: document.getElementById('mEndereco').value,
        local_exame_padrao: document.getElementById('mLocal').value,
        telefone: document.getElementById('mTelefone').value,
        link_site: document.getElementById('mLinkSite').value.trim().replace(/\/$/,''),
        campos_obrigatorios: camposObrig(),
        politica_profissionais: document.getElementById('mPolitica').value,
        logo_url: novaLogoBase64 || clinicaAtual.logo_url || null,
      }});
      document.getElementById('hdrNome').textContent = clinicaAtual.nome_fantasia || 'Agenda de Exame de Vista';
      document.getElementById('hdrLocal').textContent = textoLocalTopo();
      toast('Dados salvos.');
      novaLogoBase64 = null;
    }catch(e){ erroApi(e); }
  };

  document.getElementById('mSalvarFicha').onclick = async ()=>{
    try{
      const cfg = {}; FICHA_DEF.forEach(d=>{ cfg[d[0]] = document.getElementById('fc_'+d[0]).value; });
      clinicaAtual = await api('/clinica', { method:'PUT', body:{
        nome_fantasia: clinicaAtual.nome_fantasia, endereco: clinicaAtual.endereco,
        local_exame_padrao: clinicaAtual.local_exame_padrao, telefone: clinicaAtual.telefone, link_site: clinicaAtual.link_site,
        logo_url: clinicaAtual.logo_url || null, campos_obrigatorios: cfg }});
      toast('Ficha do paciente salva.');
    }catch(e){ erroApi(e); }
  };

  document.getElementById('mAddTipo').onclick = async ()=>{
    const nome = document.getElementById('tpNome').value.trim();
    const duracao_min = parseInt(document.getElementById('tpDuracao').value, 10);
    const buffer_min = parseInt(document.getElementById('tpBuffer').value, 10) || 0;
    if(!nome || !duracao_min || duracao_min<=0){ toast('Informe nome e duração válidos.'); return; }
    try{
      const cores = ['#1B5C5A','#2D8C84','#E3A23D','#8E6FB0','#C1462F'];
      const novo = await api('/tipos-atendimento', { method:'POST', body:{ nome, duracao_min, buffer_min, preco_padrao: document.getElementById('tpPreco').value.trim()||null, cor: cores[tiposAtendimento.length % cores.length] } });
      tiposAtendimento.push(novo);
      toast('Tipo de atendimento adicionado.'); renderMaster(main);
    }catch(e){ erroApi(e); }
  };

  carregarUsuarios();
  ligarAtividadeEquipe();
  ligarVigia();
  ligarLote();
  ligarAssistenteIA();
  ligarConversaIA();

  let assinaturaBase64 = '';
  const uPapelEl = document.getElementById('uPapel');
  const blocoProf = document.getElementById('blocoProfissional');
  uPapelEl.onchange = ()=>{ blocoProf.style.display = uPapelEl.value==='profissional' ? 'block' : 'none'; };

  document.getElementById('uAssinatura').addEventListener('change', e=>{
    const arq = e.target.files[0];
    const msg = document.getElementById('uAssinatura_msg');
    if(!arq){ assinaturaBase64=''; msg.textContent=''; return; }
    if(arq.size > 1.5*1024*1024){ msg.textContent='Imagem muito grande, escolha uma menor que 1,5 MB.'; msg.className='fieldmsg bad'; e.target.value=''; assinaturaBase64=''; return; }
    const leitor = new FileReader();
    leitor.onload = ()=>{ assinaturaBase64 = leitor.result; msg.textContent='Assinatura carregada.'; msg.className='fieldmsg ok'; };
    leitor.readAsDataURL(arq);
  });

  document.getElementById('mAddUsuario').onclick = async ()=>{
    const nome = document.getElementById('uNome').value.trim();
    const email = document.getElementById('uEmail').value.trim();
    const senha = document.getElementById('uSenha').value;
    const papel = document.getElementById('uPapel').value;
    const unidades_ids = [...document.querySelectorAll('#uCidades input[data-cid]')].filter(i=>i.checked).map(i=>i.dataset.cid);
    if(!nome || !email || !senha){ toast('Preencha nome, e-mail e senha.'); return; }
    if(papel==='atendente' && !unidades_ids.length){ toast('Marque a cidade do agendador.'); return; }
    const registro_conselho = papel==='profissional' ? document.getElementById('uRegistro').value.trim() : null;
    const carimbo_texto = papel==='profissional' ? document.getElementById('uCarimbo').value.trim() : null;
    const formacao = papel==='profissional' ? document.getElementById('uFormacao').value.trim() : null;
    try{
      await api('/clinica/usuarios', { method:'POST', body:{ nome, email, senha, papel, unidades_ids, registro_conselho, formacao, formacao_tipo: papel==='profissional' ? document.getElementById('uFormTipo').value : null, formacao_portaria: papel==='profissional' ? document.getElementById('uFormPortaria').value.trim() : null, carimbo_texto, assinatura_url: papel==='profissional'? (assinaturaBase64||null) : null } });
      toast('Usuário criado.'); carregarUsuarios();
      mostrarAcessoNovo({ nome, email, senha, papel, cidade: unidades_ids.map(id=>unidades.find(u=>u.id===id)?.nome).filter(Boolean).join(', ') });
      try{ profissionais = await api('/clinica/profissionais'); }catch(e){} // atualiza a lista pra já aparecer na receita
      document.getElementById('uNome').value=''; document.getElementById('uEmail').value=''; document.getElementById('uSenha').value='';
      document.getElementById('uRegistro').value=''; document.getElementById('uFormacao').value=''; document.getElementById('uFormTipo').value=''; document.getElementById('uFormPortaria').value=''; document.getElementById('uCarimbo').value=''; document.getElementById('uAssinatura').value='';
      document.getElementById('uAssinatura_msg').textContent=''; assinaturaBase64='';
      document.querySelectorAll('#uCidades input[data-cid]').forEach(i=>i.checked=false);
    }catch(e){ erroApi(e); }
  };

  const btnAddUnidade = document.getElementById('mAddUnidade');
  if(btnAddUnidade) btnAddUnidade.onclick = async ()=>{
    const nome = document.getElementById('unNome').value.trim();
    const slug = document.getElementById('unSlug').value.trim();
    const cidade = document.getElementById('unCidade').value.trim();
    const local = document.getElementById('unLocal').value.trim();
    if(!nome || !cidade){ toast('Preencha o nome do evento e a cidade.'); return; }
    try{
      const nova = await api('/unidades', { method:'POST', body:{ nome, slug, cidade, local } });
      unidades.push(...normUnidades([nova]));
      toast('Cidade adicionada.'); abaMasterAtual = 'Equipe'; renderMaster(main);
    }catch(e){ erroApi(e); }
  };

  ligarAgendaMaster(main);
  ligarCadastrosMaster(main);
  ligarImpressaoMaster();
  document.getElementById('mExportCsv').onclick = exportarCsv;
}

function renderTiposList(){
  return tiposAtendimento.map(t=>`
    <div class="list-item">
      <div>
        <div class="name"><span style="display:inline-block;width:9px;height:9px;border-radius:50%;background:${t.cor};margin-right:6px;"></span>${esc(t.nome)}</div>
        <div class="meta">${t.duracao_min} min de atendimento + ${t.buffer_min} min de intervalo · ${t.preco_padrao!=null ? 'preço padrão '+fmtMoeda(t.preco_padrao) : 'sem preço padrão'}</div>
      </div>
      <div style="display:flex;gap:6px;"><button class="btn btn-ghost btn-sm" onclick="editarPrecoTipo('${t.id}')">Preço</button>
      ${tiposAtendimento.length>1 ? `<button class="btn btn-danger btn-sm" onclick="removerTipo('${t.id}')">Remover</button>` : ''}</div>
    </div>`).join('');
}

function editarUnidade(id){
  const u = unidades.find(x=>x.id===id); if(!u) return;
  openModal(`<h2>Editar cidade</h2>
    <label>Cidade</label><input type="text" id="euCidade" value="${esc(u.cidade||'')}">
    <label>Nome do evento</label><input type="text" id="euNome" value="${esc(u.nomeBruto||u.nome||'')}">
    <label>Local do exame</label><input type="text" id="euLocal" value="${esc(u.local||'')}">
    <div class="btn-row" style="margin-top:12px;"><button class="btn btn-primary" id="euSalvar">Salvar</button><button class="btn btn-outline" onclick="closeModal()">Cancelar</button></div>`);
  document.getElementById('euSalvar').onclick = async ()=>{
    try{
      const nova = await api(`/unidades/${id}`, { method:'PUT', body:{ cidade: document.getElementById('euCidade').value, nome: document.getElementById('euNome').value, local: document.getElementById('euLocal').value } });
      const i = unidades.findIndex(x=>x.id===id); const n = normUnidades([nova])[0]; if(i>=0 && n) unidades[i] = n;
      closeModal(); toast('Cidade salva.'); abaMasterAtual = 'Equipe'; const m = document.getElementById('main'); if(m) renderMaster(m);
    }catch(e){ erroApi(e); }
  };
}
function renderUnidadesList(){
  if(!unidades.length) return `<p class="sub">Nenhuma cidade cadastrada ainda. Enquanto isso, tudo cai no cadastro geral da clínica.</p>`;
  return unidades.map(u=>`
    <div class="list-item">
      <div>
        <div class="name">${esc(u.nomeBruto||u.nome)}</div>
        <div class="meta">${u.cidade ? esc(u.cidade) : '<strong style="color:#C1462F;">Falta preencher a cidade</strong>'}${u.local? ' · '+esc(u.local) : ''}</div>
      </div>
      <div style="display:flex;gap:6px;">
        <button class="btn btn-ghost btn-sm" onclick="editarUnidade('${u.id}')">Editar</button>
        <button class="btn btn-ghost btn-sm" onclick="copiarLinkUnidade('${u.slug}')">Copiar link</button>
      </div>
    </div>`).join('');
}
/* Endereço base dos links públicos, sempre terminado em barra (o campo é salvo sem a barra final). */
function baseSitePublico(){
  const b = clinicaAtual?.link_site || location.href.replace(/modulo-agendamento\.html.*$/, '').replace(/[?#].*$/, '');
  return b.endsWith('/') ? b : b + '/';
}
function copiarLinkUnidade(slug){
  const base = baseSitePublico();
  const url = `${base}cadastro-paciente.html?api=${encodeURIComponent(API_BASE)}&c=${encodeURIComponent(clinicaAtual.slug)}&u=${encodeURIComponent(slug)}`;
  navigator.clipboard && navigator.clipboard.writeText(url).catch(()=>{});
  toast('Link copiado.');
}

function editarPrecoTipo(id){
  const t = tiposAtendimento.find(x=>x.id===id); if(!t) return;
  openModal(`<h2>Preço de ${esc(t.nome)}</h2><p class="sub">Esse valor já aparece preenchido quando você registra a cobrança. Deixe vazio para tirar o preço.</p>
    <label>Preço padrão (R$)</label><input type="text" inputmode="decimal" id="tpNovoPreco" value="${t.preco_padrao!=null?String(t.preco_padrao).replace('.',','):''}" placeholder="100,00">
    <div class="btn-row"><button class="btn btn-primary" id="tpSalvarPreco">Salvar</button><button class="btn btn-outline" onclick="closeModal()">Cancelar</button></div>
    <p id="tpPrecoErr" style="color:#C1462F;font-size:12.5px;margin-top:8px;"></p>`);
  document.getElementById('tpSalvarPreco').onclick = async ()=>{
    try{
      const novo = await api(`/tipos-atendimento/${id}`, { method:'PATCH', body:{ preco_padrao: document.getElementById('tpNovoPreco').value.trim()||null } });
      Object.assign(t, novo); closeModal(); toast('Preço salvo.'); switchView('master');
    }catch(e){ document.getElementById('tpPrecoErr').textContent = e.message; }
  };
}
async function removerTipo(id){
  if(!confirm('Remover este tipo de atendimento?')) return;
  try{
    await api(`/tipos-atendimento/${id}`, { method:'DELETE' });
    tiposAtendimento = tiposAtendimento.filter(t=>t.id!==id);
    toast('Tipo removido.'); switchView('master');
  }catch(e){ erroApi(e); }
}

function abrirDadosProfissional(u){
  openModal(`<h2>Registro e formação de ${esc(u.nome)}</h2>
    <p class="sub">Esses dados saem impressos na receita. Quem não é médico precisa ter curso superior de optometria reconhecido pelo MEC. Guarde uma cópia do diploma.</p>
    <label>Registro no conselho</label><input type="text" id="dpReg" maxlength="60" value="${esc(u.registro_conselho||'')}" placeholder="Ex.: CROO 12345 ou CRM 12345">
    <label>Formação superior (curso e instituição)</label><input type="text" id="dpForm" maxlength="200" value="${esc(u.formacao||'')}" placeholder="Optometria, Centro Universitário Fulano">
    <label>Tipo do curso</label><select id="dpTipo"><option value="">Não informado</option><option value="bacharelado" ${u.formacao_tipo==='bacharelado'?'selected':''}>Bacharelado</option><option value="tecnologo" ${u.formacao_tipo==='tecnologo'?'selected':''}>Tecnológico (tecnólogo)</option></select>
    <label>Reconhecimento do MEC (portaria do curso)</label><input type="text" id="dpPort" maxlength="160" value="${esc(u.formacao_portaria||'')}" placeholder="Portaria nº 123, de 01/02/2020">
    <div class="btn-row" style="margin-top:12px;"><button class="btn btn-primary" id="dpSalvar">Salvar</button><button class="btn btn-outline" onclick="closeModal()">Cancelar</button></div>`);
  document.getElementById('dpSalvar').onclick = async ()=>{
    const reg = document.getElementById('dpReg').value.trim(), form = document.getElementById('dpForm').value.trim();
    try{ await api(`/clinica/usuarios/${u.id}`, { method:'PUT', body:{ registro_conselho: reg||null, formacao: form, formacao_tipo: document.getElementById('dpTipo').value, formacao_portaria: document.getElementById('dpPort').value.trim(), carimbo_texto: u.carimbo_texto||null } }); closeModal(); toast('Salvo.'); carregarUsuarios(); }
    catch(e){ erroApi(e); }
  };
}
function abrirCidadesUsuario(u){
  const atual = u.unidades_ids || [];
  openModal(`<h2>Cidades de ${esc(u.nome)}</h2>
    <p class="sub">${u.papel==='atendente' ? 'O agendador só vê pacientes, horários e agendamentos das cidades marcadas.' : 'Sem marcar nenhuma, a pessoa vê todas as cidades.'} A mudança vale em até 30 segundos.</p>
    ${cidadesCheckboxes(atual, 'data-cid2')}
    <div class="btn-row"><button class="btn btn-primary" id="cdSalvar">Salvar cidades</button><button class="btn btn-outline" onclick="closeModal()">Cancelar</button></div>`);
  document.getElementById('cdSalvar').onclick = async ()=>{
    const lista = [...document.querySelectorAll('#modalBody input[data-cid2]')].filter(i=>i.checked).map(i=>i.dataset.cid2);
    if(u.papel==='atendente' && !lista.length){ toast('Marque pelo menos uma cidade.'); return; }
    try{ await api(`/clinica/usuarios/${u.id}`, { method:'PUT', body:{ unidades_ids: lista, registro_conselho: u.registro_conselho||null, carimbo_texto: u.carimbo_texto||null } }); closeModal(); toast('Cidades salvas.'); carregarUsuarios(); }
    catch(e){ erroApi(e); }
  };
}

function abrirAcessos(u){
  const perm = u.permissoes || [];
  openModal(`<h2>Acessos de ${esc(u.nome)}</h2>
    <p class="sub">O agendador sempre vê Agenda, Confirmação, Envios e Dia. Marque o que mais ele pode abrir. A mudança vale no próximo login dele.</p>
    ${ACESSOS_EXTRAS.map(a=>`<label style="display:flex;gap:10px;align-items:center;margin:10px 0;font-weight:500;"><input type="checkbox" style="width:auto;" data-ch="${a.chave}" ${perm.includes(a.chave)?'checked':''}> ${a.nome}</label>`).join('')}
    <div class="btn-row"><button class="btn btn-primary" id="acSalvar">Salvar acessos</button><button class="btn btn-outline" onclick="closeModal()">Cancelar</button></div>`);
  document.getElementById('acSalvar').onclick = async ()=>{
    const lista = [...document.querySelectorAll('#modalBody input[data-ch]')].filter(i=>i.checked).map(i=>i.dataset.ch);
    try{ await api(`/clinica/usuarios/${u.id}/permissoes`, { method:'PUT', body:{ permissoes: lista } }); closeModal(); toast('Acessos salvos.'); carregarUsuarios(); }
    catch(e){ erroApi(e); }
  };
}


/* ---- Atividade da equipe (Master, aba Equipe): quem entrou, quando usou e o que fez ---- */
function dataDoServidor(x){ return x ? new Date(String(x).slice(0,19)+'Z') : null; }
function statusDeAtividade(u){
  if(u.ativo===false) return { txt:'Desativado', cl:'cinza' };
  const ult = dataDoServidor(u.ultimo_acesso || u.ultimo_login);
  if(!ult) return { txt:'Nunca entrou', cl:'verm' };
  const agora = new Date(), min = (agora - ult) / 60000;
  const hora = ult.toLocaleTimeString('pt-BR',{hour:'2-digit',minute:'2-digit'});
  if(min < 10) return { txt:'Usando agora', cl:'verde' };
  const d0 = x=>{ const d = new Date(x); d.setHours(0,0,0,0); return d; };
  const dias = Math.round((d0(agora) - d0(ult)) / 86400000);
  if(dias===0) return { txt:'Último uso hoje às '+hora, cl:'verde' };
  if(dias===1) return { txt:'Último uso ontem às '+hora, cl:'amar' };
  return { txt:'Sem entrar há '+dias+' dias', cl: dias>=3 ? 'verm' : 'amar' };
}
/* ---- Conversa por voz com a IA (reconhecimento e fala do próprio navegador, sem custo) ---- */
let iaHist = [], iaAcaoPendente = null, iaOuvindo = null, iaFalando = false;
function iaVozPt(){ const v = (window.speechSynthesis && speechSynthesis.getVoices()) || []; return v.find(x=>/pt-BR/i.test(x.lang)) || v.find(x=>/^pt/i.test(x.lang)) || null; }
function iaFalar(texto, depois){
  if(!window.speechSynthesis || !document.getElementById('iaVoz') || !document.getElementById('iaVoz').checked){ if(depois) depois(); return; }
  try{
    speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(texto); u.lang='pt-BR'; const v = iaVozPt(); if(v) u.voice = v; u.rate = 1;
    iaFalando = true;
    u.onend = u.onerror = ()=>{ iaFalando = false; if(depois) depois(); };
    speechSynthesis.speak(u);
  }catch(e){ iaFalando = false; if(depois) depois(); }
}
function iaPararTudo(){
  try{ if(window.speechSynthesis) speechSynthesis.cancel(); }catch(e){}
  try{ if(iaOuvindo) iaOuvindo.abort(); }catch(e){}
  iaOuvindo = null; iaFalando = false;
  const mic = document.getElementById('iaMic'); if(mic){ mic.textContent='Falar'; }
}
function iaBolha(papel, texto){
  const box = document.getElementById('iaChat'); if(!box) return;
  box.style.display='block';
  const d = document.createElement('div');
  d.style.cssText = 'margin:6px 0;padding:8px 10px;border-radius:12px;max-width:92%;' + (papel==='eu' ? 'background:var(--brand-soft,#fde8e8);margin-left:auto;' : 'background:var(--card-alt,#f3f3f3);');
  d.textContent = texto; box.appendChild(d); box.scrollTop = box.scrollHeight;
}
function iaMostrarAcao(){
  const b = document.getElementById('iaAcaoBox'); if(!b) return;
  if(!iaAcaoPendente){ b.innerHTML=''; return; }
  b.innerHTML = `<div style="border:1px solid var(--line);border-radius:12px;padding:10px;margin-top:8px;"><p style="margin:0 0 8px;font-weight:700;">${esc(iaAcaoPendente.rotulo)}</p><div class="btn-row" style="gap:8px;"><button type="button" class="btn btn-primary" id="iaFazer">Fazer agora</button><button type="button" class="btn btn-ghost" id="iaNaoFazer">Agora não</button></div><p class="sub" style="margin:6px 0 0;">Você também pode falar "sim" ou "não".</p></div>`;
  document.getElementById('iaFazer').onclick = iaExecutarAcao;
  document.getElementById('iaNaoFazer').onclick = ()=>{ iaAcaoPendente = null; iaMostrarAcao(); };
}
async function iaExecutarAcao(){
  const a = iaAcaoPendente; if(!a) return; iaAcaoPendente = null; iaMostrarAcao();
  let msg;
  try{
    const r = String(a.id).startsWith('pedido:') ? await api('/vigia/pedidos/'+String(a.id).slice(7)+'/autorizar', { method:'POST', body:{} }) : await api('/clinica/guardiao/corrigir', { method:'POST', body:{ id:a.id } });
    msg = r.mensagem || 'Pronto.';
    if(String(a.id).startsWith('pedido:')) carregarVigia();
  }
  catch(e){ msg = (e && e.message) || 'Não consegui fazer agora.'; }
  iaBolha('ia', msg); iaHist.push({papel:'ia', texto:msg});
  try{ if(typeof guardiaoSelo==='function') guardiaoSelo(true); }catch(e){}
  iaFalar(msg, iaContinuar);
}
function iaContinuar(){ const c = document.getElementById('iaCont'); if(c && c.checked) iaOuvir(); }
async function iaEnviarMsg(texto){
  texto = String(texto||'').trim(); if(!texto) return;
  const msg = document.getElementById('iaChatMsg'); if(msg) msg.textContent='';
  iaBolha('eu', texto);
  if(iaAcaoPendente){
    if(/^\s*(sim|pode|pode fazer|pode sim|faz|faça|faz sim|confirmo|confirmado|ok|claro|isso)\b/i.test(texto)){ iaHist.push({papel:'eu', texto}); iaExecutarAcao(); return; }
    if(/^\s*(não|nao|agora não|agora nao|cancela|cancelar|deixa|deixa pra lá)\b/i.test(texto)){ iaAcaoPendente = null; iaMostrarAcao(); const t='Certo, não vou fazer.'; iaHist.push({papel:'eu', texto}); iaHist.push({papel:'ia', texto:t}); iaBolha('ia', t); iaFalar(t, iaContinuar); return; }
  }
  iaHist.push({papel:'eu', texto});
  const pens = document.createElement('div'); pens.className='sub'; pens.textContent='Pensando...'; const box = document.getElementById('iaChat'); box.appendChild(pens); box.scrollTop = box.scrollHeight;
  try{
    const r = await api('/ia/conversa', { method:'POST', body:{ mensagens: iaHist.slice(-10) } });
    pens.remove(); iaHist.push({papel:'ia', texto:r.fala}); iaBolha('ia', r.fala);
    iaAcaoPendente = r.acao || null; iaMostrarAcao();
    iaFalar(r.fala, iaContinuar);
  }catch(e){ pens.remove(); iaHist.pop(); if(msg) msg.textContent = (e && e.message) || 'Não consegui agora.'; }
}
function iaOuvir(){
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  const msg = document.getElementById('iaChatMsg'), mic = document.getElementById('iaMic');
  if(!SR){ if(msg) msg.textContent='Este navegador não entende voz. Use o Chrome no celular ou no computador, ou digite.'; return; }
  if(iaOuvindo){ try{ iaOuvindo.stop(); }catch(e){} return; }
  try{ if(window.speechSynthesis) speechSynthesis.cancel(); }catch(e){}
  const r = new SR(); r.lang='pt-BR'; r.interimResults=false; r.continuous=false; r.maxAlternatives=1;
  let texto = '';
  r.onresult = e=>{ texto = Array.from(e.results).map(x=>x[0].transcript).join(' '); };
  r.onerror = e=>{ if(msg) msg.textContent = e.error==='not-allowed' ? 'Libere o microfone no navegador para falar com a IA.' : (e.error==='no-speech' ? 'Não ouvi nada. Toque em Falar e tente de novo.' : 'Não consegui ouvir agora.'); const c=document.getElementById('iaCont'); if(c && e.error!=='no-speech') c.checked=false; };
  r.onend = ()=>{ iaOuvindo = null; if(mic) mic.textContent='Falar'; if(texto.trim()) iaEnviarMsg(texto); };
  iaOuvindo = r; if(mic) mic.textContent='Ouvindo... toque para parar';
  try{ r.start(); }catch(e){ iaOuvindo = null; if(mic) mic.textContent='Falar'; }
}
function ligarConversaIA(){
  const mic = document.getElementById('iaMic'); if(!mic) return;
  iaHist = []; iaAcaoPendente = null;
  if(window.speechSynthesis) try{ speechSynthesis.getVoices(); }catch(e){}
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  if(!SR){ mic.disabled = true; document.getElementById('iaChatMsg').textContent='Este navegador não entende voz. Use o Chrome para falar, ou digite abaixo.'; }
  mic.onclick = iaOuvir;
  document.getElementById('iaParar').onclick = ()=>{ iaPararTudo(); const c=document.getElementById('iaCont'); if(c) c.checked=false; };
  const dig = document.getElementById('iaDigita');
  const enviar = ()=>{ const t = dig.value; dig.value=''; iaEnviarMsg(t); };
  document.getElementById('iaEnv').onclick = enviar;
  dig.addEventListener('keydown', e=>{ if(e.key==='Enter'){ e.preventDefault(); enviar(); } });
}
function ligarAssistenteIA(){
  const st=document.getElementById('iaStatus'); if(!st) return;
  api('/ia/status').then(r=>{ st.textContent = r.ligada ? (r.gratuita ? 'Ligada. Usando o plano gratuito do Google Gemini.' : 'Ligada. Usando a chave da Anthropic (paga por uso).') : 'Desligada. Falta a chave GEMINI_API_KEY no Render.'; }).catch(()=>{ st.textContent='Não consegui verificar.'; });
  const msg=document.getElementById('iaMsg'), resp=document.getElementById('iaResp'), cop=document.getElementById('iaCopiar'), bt=document.getElementById('iaEnviar');
  bt.onclick=async()=>{
    msg.textContent=''; const pedido=document.getElementById('iaPedido').value.trim();
    if(pedido.length<4){ msg.textContent='Escreva o que você quer.'; return; }
    bt.disabled=true; bt.textContent='Gerando...';
    try{ const r=await api('/ia/texto',{method:'POST',body:{pedido}}); resp.value=r.texto; resp.style.display='block'; cop.style.display='block'; }
    catch(e){ msg.textContent=(e&&e.message)||'Não consegui agora.'; }
    bt.disabled=false; bt.textContent='Gerar texto';
  };
  cop.onclick=()=>{ resp.select(); try{ document.execCommand('copy'); toast('Texto copiado.'); }catch(e){} };
}
function ligarAtividadeEquipe(){
  const caixa = document.getElementById('atLista'); if(!caixa) return;
  let dias = 1;
  const nomePapel = p=> ({ atendente:'Agendador', profissional:'Profissional', gestor:'Gestor de vendas' }[p] || p);
  async function carregar(){
    caixa.innerHTML = '<p class="sub">Carregando...</p>';
    try{
      const r = await api('/clinica/atividade-equipe?dias='+dias);
      if(!r.equipe.length){ caixa.innerHTML = '<p class="sub">Nenhum usuário cadastrado ainda.</p>'; return; }
      caixa.innerHTML = r.equipe.map(u=>{
        const s = statusDeAtividade(u), cid = (u.cidades||[]).join(', ');
        return `<div role="button" tabindex="0" class="at-item" data-id="${u.id}">
          <span class="at-topo"><b>${esc(u.nome)}</b><span class="at-chip ${s.cl}">${esc(s.txt)}</span></span>
          <span class="at-sub">${esc(nomePapel(u.papel))}${cid?' · '+esc(cid):(u.papel==='atendente'?' · <b style="color:#C1462F;">sem cidade</b>':'')}</span>
          ${u.loc_lat!=null ? `<span class="at-sub">📍 Última localização: ${esc(dataDoServidor(u.loc_em).toLocaleString('pt-BR',{day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'}))} · <a href="${linkMapa(u.loc_lat,u.loc_lng)}" target="_blank" rel="noopener" onclick="event.stopPropagation()">Ver no mapa</a></span>` : ''}
          <span class="at-nums"><span><b>${u.entradas}</b> entradas</span><span><b>${u.marcou}</b> marcou</span><span><b>${u.pacientes}</b> cadastrou</span><span><b>${u.alteracoes}</b> alterou</span></span>
        </div>`;
      }).join('');
      caixa.querySelectorAll('.at-item').forEach(b=> b.onclick = ()=> abrirAtividadeDe(b.dataset.id, r.equipe.find(x=>x.id===b.dataset.id)));
    }catch(e){ caixa.innerHTML = '<p class="sub">Não consegui carregar. '+esc(e.message||'')+'</p>'; }
  }
  document.querySelectorAll('#atPeriodo button').forEach(b=> b.onclick = ()=>{
    dias = +b.dataset.d;
    document.querySelectorAll('#atPeriodo button').forEach(x=>{ x.classList.toggle('btn-primary', x===b); x.classList.toggle('btn-ghost', x!==b); });
    carregar();
  });
  window._atDias = ()=> dias;
  carregar();
}
async function abrirAtividadeDe(id, u){
  try{
    const dias = (window._atDias && window._atDias()) || 1;
    const r = await api('/clinica/atividade-equipe/'+id+'?dias='+dias);
    const quando = x=>{ const d = dataDoServidor(x); return d ? d.toLocaleString('pt-BR',{day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'}) : ''; };
    const linhas = r.eventos.map(e=>`<tr><td style="white-space:nowrap;padding:5px 8px 5px 0;color:var(--ink-soft);">${esc(quando(e.quando))}</td><td style="padding:5px 0;">${esc(e.texto)}${e.lat!=null?` · <a href="${linkMapa(e.lat,e.lng)}" target="_blank" rel="noopener">📍 mapa</a>`:''}</td></tr>`).join('');
    const s = u ? statusDeAtividade(u) : null;
    openModal(`<h2>${esc(r.usuario.nome)}</h2>
      <p class="sub">${s?esc(s.txt)+'. ':''}O que a pessoa fez ${dias===1?'nas últimas 24 horas':'nos últimos '+dias+' dias'}. Mostra até 80 ações, da mais nova para a mais antiga.</p>
      <div style="max-height:55vh;overflow:auto;"><table style="width:100%;font-size:13.5px;border-collapse:collapse;">${linhas||'<tr><td>Nenhuma ação neste período.</td></tr>'}</table></div>
      <div class="btn-row" style="margin-top:12px;"><button class="btn btn-outline" onclick="closeModal()">Fechar</button></div>`);
  }catch(e){ erroApi(e); }
}

/* ====== Foto para a IA: receita, olho e pálpebra ====== */
document.addEventListener('click', e=>{ const b = e.target.closest('[data-foto-ia]'); if(b){ e.preventDefault(); abrirFotoIA(); } });
function reduzirFoto(arq, max=1600){
  return new Promise((ok, erro)=>{
    const img = new Image(); const url = URL.createObjectURL(arq);
    img.onload = ()=>{ const k = Math.min(1, max/Math.max(img.width, img.height)); const c = document.createElement('canvas'); c.width = Math.round(img.width*k); c.height = Math.round(img.height*k);
      c.getContext('2d').drawImage(img, 0, 0, c.width, c.height); URL.revokeObjectURL(url); ok(c.toDataURL('image/jpeg', 0.86)); };
    img.onerror = ()=>{ URL.revokeObjectURL(url); erro(new Error('Não consegui abrir a foto.')); };
    img.src = url;
  });
}
const FI_URG = {urgente:['Urgente: encaminhar hoje','#B4372A'], prioridade:['Prioridade: encaminhar em até 2 a 4 semanas','#B7791F'], rotina:['Rotina: ver no próximo exame','#145F59'], sem_alerta:['Sem sinal de alerta na foto','#1F7A55']};
const FI_SIT = {normal:['Normal','#1F7A55','#E7F4EE'], limitrofe:['Limítrofe','#8A5A00','#FDF3DC'], alterado:['Alterado','#B4372A','#FBE7E3'], nao_lido:['Não lido','#55625F','#EEF1F0']};
async function abrirFotoIA(){
  let st = null; try{ st = await api('/ia/foto/status'); }catch(e){}
  const desligada = st && !st.ligada;
  openModal(`<h2>Foto para a IA</h2>
    <p class="sub" style="margin-top:0;">Leitura de apoio para o profissional. A IA lê, compara com os valores de referência e lista hipóteses. Quem confirma o diagnóstico é o médico oftalmologista.</p>
    ${desligada ? `<p class="fieldmsg bad" style="font-size:13.5px;">${st.motivo==='gemini_gratis' ? 'Desligada para proteger o paciente: o Gemini grátis pode usar as fotos para treinar. Ligue o faturamento no Google AI Studio e coloque IA_FOTO_PAGA=1 no Render, em Environment.' : 'Desligada: falta a chave da IA no Render.'}</p>` : ''}
    <label>O que é a foto?</label>
    <select id="fiTipo">
      <optgroup label="Atendimento"><option value="receita">Receita ou visor de aparelho (ler o grau)</option><option value="olho">Olho (parte branca, córnea, pupila)</option><option value="palpebra">Pálpebra ou pele em volta do olho</option></optgroup>
      <optgroup label="Laudos de exame"><option value="oct">OCT (nervo óptico, RNFL, mácula)</option><option value="retinografia">Retinografia ou fundo de olho</option><option value="campo_visual">Campo visual (campimetria)</option><option value="topografia">Topografia, tomografia de córnea ou paquimetria</option><option value="exame">Outro exame (pressão, ceratometria, biometria, cores)</option></optgroup>
    </select>
    <label>Fotos <span style="font-weight:400;color:var(--ink-soft);">(até 3, por exemplo as duas telas do mesmo laudo)</span></label>
    <input type="file" id="fiArq" accept="image/*" multiple>
    <div id="fiPrev" style="display:flex;gap:8px;flex-wrap:wrap;margin-top:8px;"></div>
    <p class="sub" id="fiDica" style="margin:6px 0 0;">Fotografe o laudo reto, com luz, sem dedo nem reflexo na frente dos números.</p>
    <label>Pergunta <span style="font-weight:400;color:var(--ink-soft);">(opcional, sem nome do paciente)</span></label>
    <input type="text" id="fiPerg" maxlength="600" placeholder="Ex.: paciente de 62 anos, pressão 24 mmHg, pai com glaucoma">
    <label id="fiConsBox" style="display:none;font-weight:500;align-items:flex-start;gap:8px;margin-top:12px;"><input type="checkbox" id="fiCons" style="margin-top:3px;"> O paciente autorizou enviar a foto para análise por IA. A foto não fica guardada.</label>
    <div id="fiRes"></div>
    <div class="btn-row"><button class="btn btn-primary" id="fiEnviar" ${desligada?'disabled':''}>Analisar</button><button class="btn btn-outline" onclick="closeModal()">Fechar</button></div>`);
  const tipo = document.getElementById('fiTipo'), cons = document.getElementById('fiConsBox');
  const atualiza = ()=>{ cons.style.display = tipo.value==='receita' ? 'none' : 'flex'; };
  tipo.onchange = atualiza; atualiza();
  let fotos = [];
  document.getElementById('fiArq').onchange = async (e)=>{
    const arqs = [...e.target.files].slice(0,3);
    if(e.target.files.length>3) toast('Usei só as 3 primeiras fotos.');
    try{ fotos = await Promise.all(arqs.map(a=>reduzirFoto(a, 2000))); }catch(err){ toast(err.message); fotos = []; }
    document.getElementById('fiPrev').innerHTML = fotos.map(f=>`<img src="${f}" alt="" style="width:31%;min-width:90px;max-height:160px;object-fit:cover;border-radius:10px;border:1px solid var(--line);">`).join('');
  };
  document.getElementById('fiEnviar').onclick = async (ev)=>{
    const res = document.getElementById('fiRes');
    if(!fotos.length){ toast('Escolha ou tire a foto.'); return; }
    if(tipo.value!=='receita' && !document.getElementById('fiCons').checked){ toast('Marque que o paciente autorizou.'); return; }
    const b = ev.currentTarget; b.disabled = true; b.textContent = 'Analisando...';
    try{
      const r = await api('/ia/foto', { method:'POST', body:{ tipo: tipo.value, imagens: fotos, pergunta: document.getElementById('fiPerg').value, consentimento: document.getElementById('fiCons').checked } });
      const u = FI_URG[r.urgencia] || FI_URG.rotina;
      const li = (a)=> a.map(x=>`<li style="margin:3px 0;">${esc(x)}</li>`).join('');
      const g = r.leitura ? ['od','oe'].map(o=>{ const x = r.leitura[o]||{}; return `<tr><td style="padding:4px 8px 4px 0;font-weight:700;">${o.toUpperCase()}</td><td>${esc(x.esf||'-')}</td><td>${esc(x.cil||'-')}</td><td>${esc(x.eixo||'-')}</td><td>${esc(x.dnp||'-')}</td></tr>`; }).join('') : '';
      const vals = (r.valores||[]).map(v=>{ const s = FI_SIT[v.situacao]||FI_SIT.nao_lido; return `<tr style="border-top:1px solid var(--line);"><td style="padding:5px 6px 5px 0;">${esc(v.campo)}${v.referencia?`<div style="font-size:11.5px;color:var(--ink-soft);">ref. ${esc(v.referencia)}</div>`:''}</td><td style="padding:5px 4px;" class="tnum">${esc(v.od||'-')}</td><td style="padding:5px 4px;" class="tnum">${esc(v.oe||'-')}</td><td style="padding:5px 0;"><span style="background:${s[2]};color:${s[1]};border-radius:999px;padding:1px 8px;font-size:11.5px;font-weight:700;white-space:nowrap;">${s[0]}</span></td></tr>`; }).join('');
      res.innerHTML = `<div id="fiLaudo" style="border:1px solid var(--line);border-radius:14px;padding:12px;margin-top:12px;">
        <div style="display:inline-block;background:${u[1]};color:#fff;border-radius:999px;padding:3px 11px;font-size:12.5px;font-weight:700;">${u[0]}</div>
        ${r.exame_identificado ? `<p style="margin:8px 0 0;font-weight:700;">${esc(r.exame_identificado)}</p>` : ''}
        ${r.qualidade ? `<p class="sub" style="margin:2px 0 0;">Qualidade: ${esc(r.qualidade)}</p>` : ''}
        ${r.qualidade_foto==='ruim' ? `<p class="fieldmsg bad" style="font-size:13px;">Foto ruim. ${esc(r.melhorar_foto||'Tire de novo com mais luz e mais perto.')}</p>` : ''}
        ${g ? `<table style="width:100%;font-size:14px;margin:10px 0;border-collapse:collapse;"><tr style="color:var(--ink-soft);font-size:12px;"><td></td><td>Esférico</td><td>Cilíndrico</td><td>Eixo</td><td>DNP</td></tr>${g}</table>${r.leitura.adicao?`<p class="sub" style="margin:0;">Adição: ${esc(r.leitura.adicao)}</p>`:''}` : ''}
        ${vals ? `<div style="overflow-x:auto;margin:10px 0;"><table style="width:100%;font-size:13px;border-collapse:collapse;"><tr style="color:var(--ink-soft);font-size:11.5px;"><td>Medida</td><td>OD</td><td>OE</td><td></td></tr>${vals}</table></div>` : ''}
        ${r.descricao ? `<p style="margin:10px 0 6px;">${esc(r.descricao)}</p>` : ''}
        ${r.sinais.length ? `<b style="font-size:13.5px;">Achados alterados</b><ul style="margin:4px 0 8px;padding-left:18px;font-size:13.5px;">${li(r.sinais)}</ul>` : ''}
        ${r.possibilidades.length ? `<b style="font-size:13.5px;">Hipóteses para o médico confirmar</b><ul style="margin:4px 0 8px;padding-left:18px;font-size:13.5px;">${li(r.possibilidades)}</ul>` : ''}
        ${(r.exames_complementares||[]).length ? `<b style="font-size:13.5px;">Exames que ajudam a confirmar</b><ul style="margin:4px 0 8px;padding-left:18px;font-size:13.5px;">${li(r.exames_complementares)}</ul>` : ''}
        ${r.encaminhar ? `<p style="margin:6px 0;font-weight:700;color:${u[1]};">Encaminhar ao oftalmologista${r.motivo_encaminhamento?': '+esc(r.motivo_encaminhamento):'.'}</p>` : ''}
        ${r.orientacoes.length ? `<b style="font-size:13.5px;">Orientações</b><ul style="margin:4px 0 8px;padding-left:18px;font-size:13.5px;">${li(r.orientacoes)}</ul>` : ''}
        <p class="sub" style="margin:6px 0 0;font-size:12.5px;">${esc(r.aviso||'')}</p>
        <button type="button" class="btn btn-ghost btn-sm" id="fiCopiar" style="margin-top:8px;">Copiar laudo de apoio</button></div>`;
      document.getElementById('fiCopiar').onclick = async ()=>{
        const linhas = [ 'LAUDO DE APOIO (IA) ' + new Date().toLocaleDateString('pt-BR'), r.exame_identificado||'', r.qualidade?('Qualidade: '+r.qualidade):'', u[0], '',
          ...(r.valores||[]).map(v=>`${v.campo}: OD ${v.od||'-'} | OE ${v.oe||'-'}${v.referencia?' (ref. '+v.referencia+')':''} ${ (FI_SIT[v.situacao]||FI_SIT.nao_lido)[0] }`),
          r.descricao||'', ...(r.sinais.length?['Achados: '+r.sinais.join('; ')]:[]), ...(r.possibilidades.length?['Hipóteses: '+r.possibilidades.join('; ')]:[]),
          ...((r.exames_complementares||[]).length?['Exames complementares: '+r.exames_complementares.join('; ')]:[]),
          r.encaminhar?('Encaminhar ao oftalmologista'+(r.motivo_encaminhamento?': '+r.motivo_encaminhamento:'')):'', r.aviso||'' ].filter(x=>x!=='');
        try{ await navigator.clipboard.writeText(linhas.join('\n')); toast('Laudo copiado. Cole no prontuário.'); }catch(e){ toast('Não consegui copiar.'); }
      };
    }catch(e){ res.innerHTML = `<p class="fieldmsg bad" style="font-size:13.5px;">${esc(e.message)}</p>`; }
    b.disabled = false; b.textContent = 'Analisar';
  };
}

/* ====== Cadastro rápido em lote: cidades e agendadores ====== */
function ligarLote(){
  const bt = document.getElementById('ltEnviar'); if(!bt) return;
  const tc = document.getElementById('ltCidades'), ta = document.getElementById('ltAgend');
  const linhas = (t)=> t.value.split('\n').map(x=>x.trim()).filter(Boolean);
  const conta = ()=>{ const a = linhas(tc).length, b = linhas(ta).length;
    const c1 = document.getElementById('ltCidCont'), c2 = document.getElementById('ltAgCont');
    c1.textContent = `${a} de 20`; c1.style.color = a>20 ? 'var(--red)' : '';
    c2.textContent = `${b} de 30. Para mais de uma cidade, separe com vírgula.`; c2.style.color = b>30 ? 'var(--red)' : ''; };
  tc.oninput = conta; ta.oninput = conta;
  bt.onclick = async ()=>{
    const lc = linhas(tc).map(l=>{ const [cidade, local] = l.split(';').map(x=>(x||'').trim()); return { cidade, local }; });
    const la = linhas(ta).map(l=>{ const [nome, cidades, telefone] = l.split(';').map(x=>(x||'').trim()); return { nome, cidades, telefone }; });
    if(!lc.length && !la.length){ toast('Escreva as cidades ou os agendadores.'); return; }
    if(lc.length>20 || la.length>30){ toast('No máximo 20 cidades e 30 agendadores por vez.'); return; }
    bt.disabled = true; bt.textContent = 'Cadastrando...';
    const out = document.getElementById('ltResultado'); let html = '';
    try{
      if(lc.length){
        const r = await api('/unidades/lote', { method:'POST', body:{ linhas: lc } });
        unidades.push(...normUnidades(r.criadas));
        html += `<p style="margin:12px 0 4px;font-weight:700;">${r.criadas.length} cidade(s) cadastrada(s).</p>` + (r.puladas.length ? `<p class="sub" style="margin:0;">Já existiam: ${r.puladas.map(x=>esc(x.cidade)).join(', ')}.</p>` : '');
      }
      if(la.length){
        const r = await api('/clinica/usuarios/lote', { method:'POST', body:{ linhas: la } });
        const link = (SERVIDOR_PROPRIO ? location.origin + '/' : (API_BASE || '')) + '?entrada=atendente';
        const msg = (u)=> `Acesso ao sistema da ${clinicaAtual?.nome_fantasia||'clínica'}\nLink: ${link}\nUsuário: ${u.email}\nSenha: ${u.senha}\nCidade: ${u.cidades.join(', ')}\nDepois de entrar, troque a senha em Meu perfil.`;
        window._loteMsgs = r.criados.map(msg);
        html += `<p style="margin:14px 0 4px;font-weight:700;">${r.criados.length} agendador(es) criado(s). Esta é a única vez que as senhas aparecem.</p>` +
          r.criados.map((u,i)=>`<div style="border:1px solid var(--line);border-radius:12px;padding:10px 12px;margin:8px 0;">
            <b>${esc(u.nome)}</b> · ${esc(u.cidades.join(', '))}
            <div class="sub" style="margin:2px 0 6px;font-family:ui-monospace,monospace;">${esc(u.email)} · senha ${esc(u.senha)}</div>
            <a class="btn btn-ghost btn-sm" target="_blank" rel="noopener" style="text-decoration:none;" href="https://wa.me/${u.telefone?('55'+u.telefone.replace(/^55/,'')):''}?text=${encodeURIComponent(msg(u))}">Enviar pelo WhatsApp</a></div>`).join('') +
          (r.criados.length ? `<button type="button" class="btn btn-outline btn-block" id="ltCopiar" style="margin-top:6px;">Copiar todos os acessos</button>` : '') +
          (r.erros.length ? `<p class="fieldmsg bad" style="font-size:13px;margin-top:10px;">Não criados: ${r.erros.map(x=>esc(x.nome)+' ('+esc(x.motivo)+')').join('; ')}.</p>` : '');
      }
      out.innerHTML = html;
      const cp = document.getElementById('ltCopiar');
      if(cp) cp.onclick = async ()=>{ const t = window._loteMsgs.join('\n\n'); try{ await navigator.clipboard.writeText(t); toast('Copiado.'); }catch(e){ toast('Não consegui copiar.'); } };
      tc.value = ''; ta.value = ''; conta();
      try{ carregarUsuarios(); }catch(e){}
    }catch(e){ out.innerHTML = `<p class="fieldmsg bad" style="font-size:13.5px;">${esc(e.message)}</p>`; }
    bt.disabled = false; bt.textContent = 'Cadastrar tudo';
  };
}

/* ====== Vigia da equipe (IA agente): avisa, pede autorização e abre sindicância ====== */
const VG_COR = {alta:'#C1462F', media:'#B26A00', baixa:'#4B5755'};
const VG_GRAV = {alta:'Grave', media:'Atenção', baixa:'Para saber'};
const VG_STATUS = {aberta:'Aberta', sindicancia:'Em sindicância', arquivada:'Arquivada', procedente:'Procedente'};
const VG_REC = {arquivar:'Arquivar', conversar:'Conversar com a pessoa', sindicancia:'Abrir sindicância', encerrar_sessoes:'Encerrar as sessões', bloquear_usuario:'Bloquear a conta'};
let vgFechadas = false;
function vigiaCardHtml(){
  return `<div class="card" id="cardVigia"><h2>Vigia da equipe</h2>
    <p class="sub">A IA confere a cada hora o que a equipe faz no sistema e avisa quando algo foge do normal: mexer de madrugada, abrir fichas demais, excluir registros, marcar exames em massa, entrar de dois lugares distantes. Ela não bloqueia ninguém sozinha: cada medida espera o seu sim. Um alerta não prova culpa. Use a sindicância para apurar.</p>
    <div id="vgResumo"><p class="sub">Carregando...</p></div>
    <div class="btn-row" style="gap:8px;flex-wrap:wrap;margin:6px 0 4px;"><button type="button" class="btn btn-ghost" id="vgRodar">Conferir agora</button><button type="button" class="btn btn-outline" id="vgFechadas">Ver concluídas</button></div>
    <div id="vgPedidos"></div>
    <div id="vgLista"></div>
  </div>`;
}
function vgQuando(x){ const d = dataDoServidor(x); return d ? d.toLocaleString('pt-BR',{day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'}) : ''; }
async function vgAutorizar(id, rotulo, nome){
  if(!confirm(`${rotulo} de ${nome||'esta pessoa'}? A medida vale na hora e fica registrada com o seu nome.`)) return;
  try{ const r = await api('/vigia/pedidos/'+id+'/autorizar', { method:'POST', body:{} }); toast(r.mensagem || 'Feito.'); }catch(e){ erroApi(e); }
  carregarVigia(); try{ guardiaoSelo(true); }catch(e){}
}
async function vgRecusar(id){
  try{ const r = await api('/vigia/pedidos/'+id+'/recusar', { method:'POST', body:{} }); toast(r.mensagem || 'Recusado.'); }catch(e){ erroApi(e); }
  carregarVigia(); try{ guardiaoSelo(true); }catch(e){}
}
async function vgAnalisar(id, btn){
  if(btn){ btn.disabled = true; btn.textContent = 'A IA está pensando...'; }
  try{ const r = await api('/vigia/ocorrencias/'+id+'/analisar', { method:'POST', body:{} }); toast(r.pedido ? 'A IA sugeriu uma medida. Ela espera o seu sim.' : 'Opinião da IA pronta.'); }
  catch(e){ erroApi(e); }
  carregarVigia();
}
async function vgConcluir(id, status, parecer){
  const txt = status==='procedente' ? 'Concluir como PROCEDENTE? Fica registrado que a suspeita se confirmou.' : 'Arquivar? Fica registrado que não houve nada errado. Os pedidos ligados a este alerta são recusados.';
  if(!confirm(txt)) return false;
  try{ await api('/vigia/ocorrencias/'+id+'/concluir', { method:'POST', body:{ status, parecer } }); toast(status==='procedente'?'Concluída como procedente.':'Arquivada.'); carregarVigia(); try{ guardiaoSelo(true); }catch(e){} return true; }
  catch(e){ erroApi(e); return false; }
}
async function carregarVigia(){
  const box = document.getElementById('vgLista'), res = document.getElementById('vgResumo'), ped = document.getElementById('vgPedidos'); if(!box) return;
  try{
    const r = await api('/vigia'+(vgFechadas?'?status=fechadas':''));
    const s = r.resumo || {};
    res.innerHTML = (s.abertas || s.sindicancias) ? `<p style="font-weight:700;margin:0;color:${s.graves?VG_COR.alta:VG_COR.media};">${s.abertas} alerta(s) aberto(s)${s.graves?`, ${s.graves} grave(s)`:''}${s.sindicancias?` · ${s.sindicancias} em sindicância`:''}.</p>` : `<p style="font-weight:700;margin:0;color:#2E7D4F;">Nenhum alerta aberto.</p>`;
    res.innerHTML += `<p class="sub" style="margin:2px 0 0;">${r.ia ? 'IA ligada: ela dá a opinião em cada alerta.' : 'IA desligada: os alertas aparecem, mas sem a opinião dela. Falta a chave GEMINI_API_KEY no Render.'}</p>`;
    ped.innerHTML = r.pedidos.length ? `<h3 style="margin:12px 0 4px;font-size:15px;">Esperando o seu sim (${r.pedidos.length})</h3>` + r.pedidos.map(p=>`
      <div style="border:2px solid ${VG_COR.media};border-radius:12px;padding:10px;margin:8px 0;">
        <b>${esc(p.rotulo)}: ${esc(p.alvo_nome||'')}</b>
        <div class="sub" style="margin:2px 0 6px;">Motivo: ${esc(p.motivo||'')}. Pedido ${p.origem==='ia'?'da IA':p.origem==='master'?'seu':'do Vigia'} em ${esc(vgQuando(p.criado_em))}.</div>
        <div class="btn-row" style="gap:8px;flex-wrap:wrap;"><button type="button" class="btn btn-primary" data-vg="aut" data-id="${p.id}" data-r="${esc(p.rotulo)}" data-n="${esc(p.alvo_nome||'')}">Autorizar</button><button type="button" class="btn btn-outline" data-vg="rec" data-id="${p.id}">Recusar</button></div>
      </div>`).join('') : '';
    const titulo = vgFechadas ? 'Concluídas' : 'Alertas';
    box.innerHTML = `<h3 style="margin:14px 0 2px;font-size:15px;">${titulo}</h3>` + (r.ocorrencias.length ? r.ocorrencias.map(o=>`
      <div style="border-top:1px solid var(--line);padding:10px 0;">
        <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;"><span style="background:${VG_COR[o.gravidade]};color:#fff;border-radius:999px;padding:1px 9px;font-size:12px;font-weight:700;">${VG_GRAV[o.gravidade]||o.gravidade}</span>${o.status!=='aberta'?`<span style="border:1px solid var(--line);border-radius:999px;padding:1px 9px;font-size:12px;">${VG_STATUS[o.status]||o.status}</span>`:''}<span class="sub" style="margin:0;">${esc(vgQuando(o.criado_em))}</span></div>
        <b style="display:block;margin-top:4px;">${esc(o.titulo)}</b>
        <div class="sub" style="margin:2px 0 0;">${esc(o.detalhe||'')}</div>
        ${o.ia_parecer ? `<div style="background:var(--bg-soft,#F1F5F3);border-radius:10px;padding:8px 10px;margin-top:6px;font-size:13.5px;"><b>Opinião da IA:</b> ${esc(o.ia_parecer)}${o.ia_recomendacao?` <b>Sugestão: ${esc(VG_REC[o.ia_recomendacao]||o.ia_recomendacao)}.</b>`:''}</div>` : ''}
        ${o.parecer_master && vgFechadas ? `<div class="sub" style="margin-top:6px;"><b>Parecer:</b> ${esc(o.parecer_master)} · ${esc(o.decidido_por||'')} em ${esc(vgQuando(o.decidido_em))}</div>` : ''}
        <div style="display:flex;gap:6px;flex-wrap:wrap;margin-top:8px;">
          ${!vgFechadas && r.ia && !o.ia_parecer ? `<button type="button" class="btn btn-ghost btn-sm" data-vg="ia" data-id="${o.id}">Pedir opinião da IA</button>` : ''}
          ${o.usuario_id ? `<button type="button" class="btn ${o.status==='sindicancia'?'btn-primary':'btn-ghost'} btn-sm" data-vg="sind" data-id="${o.id}">${o.status==='sindicancia'?'Abrir a sindicância':(vgFechadas?'Ver o dossiê':'Abrir sindicância')}</button>` : ''}
          ${!vgFechadas ? `<button type="button" class="btn btn-outline btn-sm" data-vg="arq" data-id="${o.id}">Arquivar</button>` : ''}
        </div>
      </div>`).join('') : `<p class="sub">${vgFechadas?'Nada concluído ainda.':'Nada fora do normal.'}</p>`);
    document.getElementById('vgFechadas').textContent = vgFechadas ? 'Ver abertas' : 'Ver concluídas';
    document.querySelectorAll('#cardVigia [data-vg]').forEach(b=> b.onclick = ()=>{
      const k = b.dataset.vg, id = b.dataset.id;
      if(k==='aut') vgAutorizar(id, b.dataset.r, b.dataset.n);
      else if(k==='rec') vgRecusar(id);
      else if(k==='ia') vgAnalisar(id, b);
      else if(k==='sind') abrirSindicancia(id);
      else if(k==='arq') vgConcluir(id, 'arquivada');
    });
  }catch(e){ res.innerHTML = `<p class="fieldmsg bad">${esc(e.message)}</p>`; }
}
function ligarVigia(){
  if(!document.getElementById('cardVigia')) return;
  document.getElementById('vgRodar').onclick = async (ev)=>{
    const b = ev.currentTarget; b.disabled = true; b.textContent = 'Conferindo...';
    try{ const r = await api('/vigia/rodar', { method:'POST', body:{} }); toast(r.novas ? `${r.novas} alerta(s) novo(s).` : 'Nada novo.'); }catch(e){ erroApi(e); }
    b.disabled = false; b.textContent = 'Conferir agora'; carregarVigia();
  };
  document.getElementById('vgFechadas').onclick = ()=>{ vgFechadas = !vgFechadas; carregarVigia(); };
  carregarVigia();
}
async function abrirSindicancia(id){
  let d;
  try{ d = await api('/vigia/ocorrencias/'+id+'/dossie'); }catch(e){ erroApi(e); return; }
  const o = d.ocorrencia, p = d.pessoa, aberta = o.status==='aberta' || o.status==='sindicancia';
  const papel = {atendente:'Agendador',profissional:'Profissional',gestor:'Gestor de vendas',admin:'Master'};
  const linhas = d.eventos.map(e=>`<tr><td style="white-space:nowrap;padding:4px 8px 4px 0;color:var(--ink-soft);vertical-align:top;">${esc(vgQuando(e.quando))}</td><td style="padding:4px 0;">${esc(e.texto)}${e.lat!=null?` · <a href="${linkMapa(e.lat,e.lng)}" target="_blank" rel="noopener">mapa</a>`:''}</td></tr>`).join('');
  const hist = d.historico.map(h=>`<li>${esc(vgQuando(h.criado_em))}: ${esc(h.titulo)} (${esc(VG_STATUS[h.status]||h.status)})</li>`).join('');
  const stPed = {pendente:'esperando o seu sim', executado:'feito', recusado:'recusado'};
  const meds = d.pedidos.map(x=>`<li>${esc(vgQuando(x.criado_em))}: ${esc(x.rotulo)}, ${esc(stPed[x.status]||x.status)}${x.decidido_por?' por '+esc(x.decidido_por):''}</li>`).join('');
  openModal(`<div id="sdDoc">
    <h2>Sindicância</h2>
    <p class="sub" style="margin-top:0;">${esc(VG_STATUS[o.status]||o.status)} · alerta do Vigia em ${esc(vgQuando(o.criado_em))}</p>
    <p style="margin:6px 0;"><b>${esc(o.titulo)}</b></p>
    <p class="sub" style="margin:0 0 6px;">${esc(o.detalhe||'')}</p>
    ${p ? `<p class="sub" style="margin:0 0 6px;">Pessoa: <b>${esc(p.nome)}</b> · ${esc(papel[p.papel]||p.papel)} · conta ${p.ativo?'ativa':'bloqueada'} · último uso ${esc(vgQuando(p.ultimo_acesso))}</p>` : ''}
    ${o.ia_parecer ? `<p style="background:var(--bg-soft,#F1F5F3);border-radius:10px;padding:8px 10px;font-size:13.5px;"><b>Opinião da IA:</b> ${esc(o.ia_parecer)}</p>` : ''}
    <h3 style="font-size:14px;margin:12px 0 4px;">Linha do tempo (12 horas antes e depois)</h3>
    <div style="max-height:34vh;overflow:auto;border:1px solid var(--line);border-radius:10px;padding:6px 8px;"><table style="width:100%;font-size:13px;border-collapse:collapse;">${linhas||'<tr><td>Nenhum registro no período.</td></tr>'}</table></div>
    ${hist ? `<h3 style="font-size:14px;margin:12px 0 4px;">Outros alertas desta pessoa</h3><ul style="margin:0;padding-left:18px;font-size:13px;">${hist}</ul>` : ''}
    ${meds ? `<h3 style="font-size:14px;margin:12px 0 4px;">Medidas pedidas</h3><ul style="margin:0;padding-left:18px;font-size:13px;">${meds}</ul>` : ''}
    <h3 style="font-size:14px;margin:12px 0 4px;">Parecer do Master</h3>
    ${aberta ? `<p class="sub" style="margin:0 0 4px;">Anote o que você apurou: a conversa com a pessoa, a explicação dela, o que conferiu com os pacientes.</p><textarea id="sdParecer" rows="4" maxlength="4000">${esc(o.parecer_master||'')}</textarea>` : `<p style="font-size:13.5px;">${esc(o.parecer_master||'Sem parecer.')}${o.decidido_por?`<br><span class="sub">${esc(VG_STATUS[o.status])} por ${esc(o.decidido_por)} em ${esc(vgQuando(o.decidido_em))}</span>`:''}</p>`}
  </div>
  ${aberta ? `<div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:10px;">
      ${o.status==='aberta' ? `<button class="btn btn-primary" id="sdAbrir">Abrir sindicância</button>` : `<button class="btn btn-primary" id="sdSalvar">Salvar parecer</button>`}
      ${o.usuario_id ? `<button class="btn btn-ghost" id="sdEncerrar">Pedir: encerrar sessões</button><button class="btn btn-ghost" id="sdBloquear">Pedir: bloquear a conta</button>` : ''}
    </div>
    <p class="sub" style="margin:12px 0 4px;">Para concluir, escreva o parecer acima e escolha:</p>
    <div style="display:flex;gap:8px;flex-wrap:wrap;">
      <button class="btn btn-outline" id="sdArquivar">Arquivar (não houve nada errado)</button>
      <button class="btn btn-danger" id="sdProcedente">Procedente (a suspeita se confirmou)</button>
    </div>` : ''}
  <div class="btn-row"><button class="btn btn-ghost" id="sdImprimir">Imprimir</button><button class="btn btn-outline" onclick="closeModal()">Fechar</button></div>`);
  const par = ()=>{ const t = document.getElementById('sdParecer'); return t ? t.value : undefined; };
  const on = (idEl, fn)=>{ const b = document.getElementById(idEl); if(b) b.onclick = fn; };
  on('sdAbrir', async ()=>{ try{ await api('/vigia/ocorrencias/'+id+'/sindicancia', { method:'POST', body:{} }); if(par()) await api('/vigia/ocorrencias/'+id+'/parecer', { method:'PUT', body:{ parecer: par() } }); toast('Sindicância aberta.'); carregarVigia(); abrirSindicancia(id); }catch(e){ erroApi(e); } });
  on('sdSalvar', async ()=>{ try{ await api('/vigia/ocorrencias/'+id+'/parecer', { method:'PUT', body:{ parecer: par() } }); toast('Parecer salvo.'); }catch(e){ erroApi(e); } });
  const pedir = (tipo)=> async ()=>{ try{ const r = await api('/vigia/ocorrencias/'+id+'/pedido', { method:'POST', body:{ tipo } }); toast(r.jaExistia ? 'Esse pedido já está esperando o seu sim no quadro do Vigia.' : 'Pedido criado. Autorize no quadro do Vigia.'); carregarVigia(); }catch(e){ erroApi(e); } };
  on('sdEncerrar', pedir('encerrar_sessoes'));
  on('sdBloquear', pedir('bloquear_usuario'));
  on('sdArquivar', async ()=>{ if(await vgConcluir(id, 'arquivada', par())) closeModal(); });
  on('sdProcedente', async ()=>{ if(await vgConcluir(id, 'procedente', par())) closeModal(); });
  on('sdImprimir', ()=>{
    const doc = document.getElementById('sdDoc').cloneNode(true);
    const t = doc.querySelector('#sdParecer'); if(t){ const div = document.createElement('p'); div.textContent = t.value || 'Sem parecer.'; t.replaceWith(div); }
    const w = window.open('', '_blank'); if(!w){ toast('Libere as janelas do navegador para imprimir.'); return; }
    w.document.write(`<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><title>Sindicância</title><style>body{font-family:Arial,sans-serif;font-size:13px;margin:24px;color:#111}h2{margin:0 0 4px}h3{margin:14px 0 4px;font-size:14px}table{width:100%;border-collapse:collapse}td{border-bottom:1px solid #ddd;padding:3px 6px 3px 0;vertical-align:top}div{max-height:none!important;overflow:visible!important}</style></head><body>${doc.innerHTML}<p style="margin-top:30px;">Impresso em ${new Date().toLocaleString('pt-BR')} por ${esc(usuarioAtual?.nome||'Master')}.</p><p style="margin-top:40px;">______________________________<br>Assinatura do Master</p></body></html>`);
    w.document.close(); w.focus(); setTimeout(()=>{ try{ w.print(); }catch(e){} }, 300);
  });
}

async function carregarUsuarios(){
  const el = document.getElementById('listaUsuarios');
  if(!el) return;
  try{
    const usuarios = await api('/clinica/usuarios');
    const eu = (usuarioAtual?.email||'').toLowerCase();
    el.innerHTML = usuarios.map(u=>{
      const ehEu = eu && String(u.email).toLowerCase()===eu;
      return `
      <div class="list-item" style="flex-wrap:wrap;gap:8px;${u.ativo===false?'opacity:.6;':''}">
        <div style="flex:1 1 220px;"><div class="name">${esc(u.nome)}${u.ativo===false?' (desativado)':''}${ehEu?' (você)':''}</div><div class="meta">${esc(u.email)} · ${esc(u.papel)}${(u.unidades_nomes&&u.unidades_nomes.length)? ' · '+esc(u.unidades_nomes.join(', ')) : (u.papel==='atendente' ? ' · <strong style="color:#C1462F;">sem cidade (não consegue entrar). Toque em Cidades e escolha a cidade.</strong>' : ' · todas as cidades')}${u.papel==='profissional' ? (u.tem_assinatura ? ' · carimbo e assinatura cadastrados' : ' · sem assinatura cadastrada ainda') : ''}${u.papel==='atendente' ? ' · acessos extras: '+((u.permissoes||[]).length||'nenhum') : ''}</div></div>
        <div style="display:flex;gap:6px;flex-wrap:wrap;">
          ${unidades.length ? `<button class="btn btn-ghost btn-sm" data-cidades="${u.id}">Cidades</button>` : ''}
          ${u.papel==='profissional' ? `<button class="btn btn-ghost btn-sm" data-prof="${u.id}">Registro e formação</button>` : ''}
          ${u.papel==='atendente' ? `<button class="btn btn-ghost btn-sm" data-acessos="${u.id}">Acessos</button>` : ''}
          ${u.totp_ativo ? `<button class="btn btn-ghost btn-sm" data-totpoff="${u.id}">Desligar código do celular</button>` : ''}
          <button class="btn btn-ghost btn-sm" data-senha="${u.id}">Trocar senha</button>
          ${ehEu ? '' : `<button class="btn btn-outline btn-sm" data-ativo="${u.id}">${u.ativo===false?'Reativar':'Desativar'}</button><button class="btn btn-danger btn-sm" data-excluir="${u.id}">Excluir</button>`}
        </div>
      </div>`; }).join('') || '<p class="sub">Nenhum usuário além de você.</p>';
    el.querySelectorAll('button[data-totpoff]').forEach(b=> b.onclick = async ()=>{
      if(!confirm('Desligar o código do celular desta pessoa? Ela volta a entrar só com a senha.')) return;
      try{ await api('/auth/totp/usuario/'+b.dataset.totpoff, { method:'DELETE' }); toast('Código desligado.'); const u = usuarios.find(x=>x.id===b.dataset.totpoff); if(u) u.totp_ativo = false; b.remove(); }catch(e){ erroApi(e); }
    });
    el.querySelectorAll('button[data-cidades]').forEach(b=> b.onclick = ()=> abrirCidadesUsuario(usuarios.find(u=>u.id===b.dataset.cidades)));
    el.querySelectorAll('button[data-prof]').forEach(b=> b.onclick = ()=> abrirDadosProfissional(usuarios.find(u=>u.id===b.dataset.prof)));
    el.querySelectorAll('button[data-acessos]').forEach(b=> b.onclick = ()=> abrirAcessos(usuarios.find(u=>u.id===b.dataset.acessos)));
    el.querySelectorAll('button[data-senha]').forEach(b=> b.onclick = ()=> abrirTrocaSenhaUsuario(usuarios.find(u=>u.id===b.dataset.senha)));
    el.querySelectorAll('button[data-ativo]').forEach(b=> b.onclick = async ()=>{
      const u = usuarios.find(x=>x.id===b.dataset.ativo); const desativar = u.ativo!==false;
      if(!confirm(desativar ? `Desativar ${u.nome}? Ele perde o acesso em até 30 segundos e o histórico fica guardado.` : `Reativar ${u.nome}?`)) return;
      try{ await api(`/clinica/usuarios/${u.id}`, { method:'PUT', body:{ ativo: !desativar, registro_conselho: u.registro_conselho||null, carimbo_texto: u.carimbo_texto||null } }); toast(desativar?'Usuário desativado.':'Usuário reativado.'); carregarUsuarios(); }
      catch(e){ erroApi(e); }
    });
    el.querySelectorAll('button[data-excluir]').forEach(b=> b.onclick = async ()=>{
      const u = usuarios.find(x=>x.id===b.dataset.excluir);
      if(!confirm(`Excluir ${u.nome}? Isso não pode ser desfeito. Se ele já tem agendamentos ou receitas, o acesso é só desativado para guardar o histórico.`)) return;
      try{ const r = await api(`/clinica/usuarios/${u.id}`, { method:'DELETE' }); toast(r.excluido ? 'Usuário excluído.' : 'Usuário tem histórico: o acesso foi desativado.'); carregarUsuarios(); }
      catch(e){ erroApi(e); }
    });
  }catch(e){
    el.innerHTML = '<p class="sub">Só o admin pode ver os usuários.</p>';
  }
}
function abrirTrocaSenhaUsuario(u){
  openModal(`<h2>Trocar senha de ${esc(u.nome)}</h2>
    <p class="sub">Mínimo de 10 caracteres, com letras e números. Passe a nova senha para a pessoa.</p>
    <label>Nova senha</label><input type="text" id="nsSenha" autocomplete="off">
    <p class="err" id="nsErr" style="color:#C1462F;font-size:12.5px;"></p>
    <div class="btn-row"><button class="btn btn-primary" id="nsSalvar">Salvar senha</button><button class="btn btn-outline" onclick="closeModal()">Cancelar</button></div>`);
  document.getElementById('nsSalvar').onclick = async ()=>{
    try{ await api(`/clinica/usuarios/${u.id}/senha`, { method:'PUT', body:{ senha: document.getElementById('nsSenha').value } }); closeModal(); toast('Senha trocada.'); }
    catch(e){ document.getElementById('nsErr').textContent = e.message; }
  };
}

function montarCsv(){
  let csv = 'tipo;id;nome;cpf;telefone;cidade;data;hora;status;local\n';
  const csvSeguro = v=>{ v = String(v==null?'':v).replace(/[;\r\n]+/g,' '); return /^[=+\-@\t]/.test(v) ? "'"+v : v; };
  pacientes.forEach(p=>{ csv += `paciente;${p.id};${csvSeguro(p.nome_completo)};${csvSeguro(p.cpf)};${csvSeguro(p.telefone)};${csvSeguro(p.cidade)};;;;\n`; });
  agendamentos.forEach(a=>{ csv += `agendamento;${a.id};${csvSeguro(pacienteNome(a.paciente_id))};;;;${soData(a.data_hora)};${soHora(a.data_hora)};${csvSeguro(a.status)};${csvSeguro(a.local)}\n`; });
  return csv;
}
function exportarCsv(){
  const csv = montarCsv();
  const blob = new Blob([csv], {type:'text/csv;charset=utf-8;'});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = 'backup-agenda-' + hojeISO() + '.csv';
  a.click(); URL.revokeObjectURL(url);
  toast('CSV exportado.');
}

/* ====== Guardião do sistema (só o Master) ====== */
const FUNCOES = [
  {n:'Início',p:['admin','atendente','profissional'],v:'inicio',d:'Roteiro de 5 passos do seu perfil e lista do que falta configurar.',t:'comecar guia roteiro checklist'},
  {n:'Painel',p:['admin','profissional'],v:'painel',d:'Números do dia e da semana: marcados, atendidos e faltas.',t:'numeros resumo dashboard'},
  {n:'Agenda',p:['admin','atendente'],v:'agenda',d:'Escolha a cidade e o dia, veja os horários livres e marque o paciente. Horário ocupado não deixa marcar duas vezes.',t:'marcar agendar horario exame cancelar remarcar'},
  {n:'Calendário',p:['admin','atendente','profissional'],v:'calendario',d:'Visão do mês com os dias abertos e os feriados da cidade.',t:'mes feriado dias'},
  {n:'Pacientes',p:['admin','atendente','profissional'],v:'pacientes',d:'Cadastro, busca, ficha completa, fotos da receita e da armação e impressão da ficha. O CPF fica criptografado no banco.',t:'cadastro cpf telefone ficha foto imprimir buscar paciente'},
  {n:'Cadastro pelo paciente (link e QR)',p:['admin','atendente'],v:'pacientes',d:'O paciente preenche a própria ficha pelo celular, lendo o QR code ou abrindo o link. Aceita o aviso de privacidade.',t:'link qr autocadastro lgpd formulario'},
  {n:'Assistente de agendamento',p:['admin','atendente'],v:'assistente',d:'Marque horário conversando: escreva o que o paciente pediu e o assistente propõe os horários.',t:'chat conversa marcar'},
  {n:'Receita e atestado',p:['admin','profissional'],v:'receita',d:'Receita de óculos, atestado e declaração com carimbo, assinatura, cidade no cabeçalho e diagnóstico (CID). Tudo criptografado.',t:'receita atestado declaracao cid imprimir pdf oculos'},
  {n:'Atendimento (prontuário)',p:['admin','profissional'],v:'prontuario',d:'Prontuário do exame: queixa, acuidade, refração, exame externo e conduta. Ditado por voz, histórico de correções e fechamento.',t:'prontuario exame acuidade refracao voz ditar historico'},
  {n:'Fila do dia',p:['admin','atendente','profissional'],v:'fila',d:'Quem chegou, quem espera e quem está em atendimento, com o tempo de espera de cada um.',t:'chegou espera atendimento fila'},
  {n:'Lista de espera',p:['admin','atendente'],v:'espera',d:'Quem quer um horário mais cedo. Quando alguém cancela, o sistema avisa e o botão Oferecer abre o WhatsApp com a mensagem pronta.',t:'espera cancelou vaga oferecer whatsapp'},
  {n:'Confirmar presença',p:['admin','atendente'],v:'confirmacao',d:'Lista de quem precisa confirmar o comparecimento, com botão para chamar pelo WhatsApp.',t:'confirmar presenca lembrete'},
  {n:'Mensagens',p:['admin','atendente'],v:'envios',d:'Mensagens prontas de lembrete, confirmação e pós-exame, para enviar pelo WhatsApp.',t:'whatsapp mensagem lembrete envio'},
  {n:'Resumo do dia',p:['admin','atendente','profissional'],v:'relatorio',d:'Marcados, atendidos, faltas e cancelados do dia, com o resumo por cidade e valores.',t:'relatorio cidade faltas valores dia'},
  {n:'Teste na tela',p:['admin','atendente','profissional'],v:'teste',d:'Teste de acuidade na tela do computador ou do celular, com tamanho calibrado.',t:'optotipo visao acuidade teste tela snellen'},
  {n:'Retornos',p:['admin','atendente'],v:'retornos',d:'Pacientes que fizeram exame há um ano ou mais e já podem voltar. Aniversariantes também.',t:'retorno recall aniversario voltar'},
  {n:'Financeiro',p:['admin'],v:'financeiro',d:'Pagamentos recebidos, contas a pagar e totais por período.',t:'dinheiro pagamento conta receber pagar valores'},
  {n:'Meu perfil',p:['admin','atendente','profissional'],v:'perfil',d:'Troca de senha, código do celular, letra grande, alto contraste, tema escuro e Sair de todos os aparelhos.',t:'senha codigo totp aparencia letra escuro sair aparelhos'},
  {n:'Dados da clínica',p:['admin'],v:'master',aba:'Clínica',d:'Nome, endereço, logomarca e tipos de atendimento com duração.',t:'clinica tipo atendimento logo'},
  {n:'Cidades de exame de vista',p:['admin'],v:'master',aba:'Equipe',d:'Cadastre, edite ou desative as cidades onde acontece o exame de vista. Depois marque as cidades de cada agendador.',t:'cidade cadastro cidade unidade evento local exame'},
  {n:'Cadastro rápido em lote',p:['admin'],v:'master',aba:'Equipe',d:'Até 20 cidades e 30 agendadores de uma vez, com login, senha e mensagem de WhatsApp prontos.',t:'lote varias cidades agendadores cadastro rapido em massa'},
  {n:'Foto para a IA',p:['admin','profissional'],v:'assistente',d:'Mande a foto da receita, do olho ou da pálpebra. A IA lê o grau ou faz a triagem com sinais de alerta e diz se precisa encaminhar. Não é diagnóstico.',t:'foto ia receita olho palpebra lesao triagem doenca'},
  {n:'Vigia da equipe',p:['admin'],v:'master',aba:'Equipe',d:'A IA confere o que a equipe faz, avisa o que foge do normal e pede a sua autorização antes de encerrar sessões ou bloquear uma conta. Daqui você abre sindicância.',t:'vigia ia agente monitorar sindicancia bloquear suspeita fraude auditoria'},
  {n:'Ficha do paciente (campos)',p:['admin'],v:'master',aba:'Clínica',d:'Escolha o que pedir de cada paciente: obrigatório, opcional ou oculto.',t:'campos obrigatorios ficha'},
  {n:'Agenda de exame e feriados',p:['admin'],v:'master',aba:'Agenda',d:'Abra dias e horários por cidade, com almoço e intervalo. Cadastre os feriados locais.',t:'abrir horarios agenda feriado almoco'},
  {n:'Equipe e permissões',p:['admin'],v:'master',aba:'Equipe',d:'Crie agendadores e profissionais, escolha a cidade de cada um, o que podem abrir, e desative quem saiu. Desligue o código do celular de quem perdeu o aparelho.',t:'usuarios equipe permissao desativar totp'},
  {n:'Backup protegido',p:['admin'],v:'master',aba:'Segurança',clicar:'mBackup',d:'Baixa uma cópia completa dos dados, trancada com a senha que você escolhe. Também sai sozinho toda semana por e-mail, quando o e-mail está ligado.',t:'backup copia seguranca restaurar'},
  {n:'Estado da segurança',p:['admin'],v:'master',aba:'Segurança',d:'O que está ligado no servidor: criptografia, e-mail, backup semanal, WhatsApp e código do celular.',t:'seguranca criptografia estado'},
  {n:'Licença da clínica',p:['admin'],v:'master',aba:'Segurança',d:'Chave de licença por clínica, para quando o sistema for usado por outras clínicas.',t:'licenca chave vender'},
  {n:'Versões do sistema',p:['admin'],v:'master',aba:'Segurança',d:'Histórico do que mudou em cada versão.',t:'versao novidades historico'},
  {n:'Exportar dados',p:['admin'],v:'master',aba:'Segurança',d:'Planilha CSV dos agendamentos.',t:'csv planilha exportar'},
  {n:'Integrações e WhatsApp automático',p:['admin'],v:'master',aba:'Integrações',d:'Chave de integração com assistente externo e lembretes automáticos pelo WhatsApp (precisa da chave da Meta).',t:'whatsapp meta integracao chave automatico'},
  {n:'Guardião do sistema',p:['admin'],v:'master',aba:'Guardião',d:'Vigia saúde do sistema, backup e obrigações, avisa por e-mail e corrige com um clique o que dá.',t:'saude guardiao assistente obrigacoes falhas'},
  {n:'Modo treino',p:['admin'],v:'master',aba:'Guardião',d:'Cria 5 pacientes de mentira para a equipe aprender sem medo e remove tudo depois.',t:'treino praticar aprender equipe'},
  {n:'Cobrar receita por Pix',p:['admin','profissional','atendente'],v:'receita',d:'Na tela de Receita, gere um QR Code Pix para o paciente pagar a receita, o atestado ou a declaração. Depois de pago, envie o documento por WhatsApp.',t:'pix qr code cobrar receita atestado declaracao pagamento whatsapp'},
  {n:'OCO',p:['admin','gestor'],v:'vendasgestor',d:'Sistema OCO do gestor de vendas: vendas, ordens de serviço, estoque, caixa, contas a receber, clientes com bloqueio por dívida, lentes prontas e aniversariantes.',t:'oco vendas gestor os ordem servico estoque caixa receber cliente bloqueio lentes prontas'},
  {n:'OCO no celular',p:['admin','gestor'],url:'/gestor-vendas/',d:'Versão instalável do OCO. Abra o endereço /gestor-vendas/ no celular, entre com seu e-mail e senha e instale na tela inicial. Depois do primeiro acesso, abre mesmo sem internet.',t:'oco gestor vendas celular instalar app offline otica'},
  {n:'Pós-exame',p:['admin','gestor'],v:'posexame',d:'Depois do exame de vista, pergunte ao paciente pelo WhatsApp se ele ficou satisfeito. Quem ficou regular ou insatisfeito vai para a lista de acompanhamento até você resolver.',t:'pos exame satisfeito satisfacao pesquisa paciente gestor acompanhar insatisfeito'},
  {n:'Agendador offline',p:['admin','atendente'],url:'/agendador/',d:'Versão pequena para o celular. Marca horários sem internet e envia sozinha quando a internet voltar. Abra o endereço /agendador/ no celular e instale na tela inicial.',t:'agendador offline sem internet celular marcar horario fila enviar'},
  {n:'Instalar no celular',p:['admin','atendente','profissional'],v:'inicio',d:'No celular, abra o menu do navegador e escolha Adicionar à tela inicial. O sistema vira um app com ícone.',t:'instalar app pwa celular tela inicial'},
  {n:'Recuperar senha',p:['admin','atendente','profissional'],v:'inicio',d:'Na tela de entrada, toque em Esqueci a senha. O link chega por e-mail e vale por 30 minutos (precisa do e-mail ligado).',t:'esqueci senha recuperar email'},
];
const NOME_PAPEL = {admin:'Master',atendente:'Agendador',profissional:'Profissional',gestor:'Gestor de vendas'};
function guardiaoIr(a){
  if(!a) return;
  if(a.url){ window.open(a.url,'_blank','noopener'); return; }
  const view = a.view || a.v;
  if(view==='master'){ if(a.aba) abaMasterAtual = a.aba; switchView('master'); if(a.clicar) setTimeout(()=>{ const b = document.getElementById(a.clicar); if(b) b.click(); }, 900); }
  else switchView(view);
}
function guardiaoCardsHtml(){
  return `<div class="card"><h2>Guardião do sistema</h2>
      <p class="sub">Seu assistente de saúde do programa. Confere o sistema, os backups e as suas obrigações, avisa o que está errado e corrige com um clique o que for possível.</p>
      <div id="gdResumo"><p class="sub">Conferindo...</p></div>
      <button class="btn btn-ghost btn-block" id="gdAtualizar" style="margin:6px 0 10px;">Conferir agora</button>
      <div id="gdLista"></div>
    </div>
    <div class="card"><h2>Obrigações</h2>
      <p class="sub">Tudo o que você precisa lembrar. O Guardião manda um e-mail por dia quando algo vence em até 3 dias, se o e-mail estiver ligado.</p>
      <div id="gdObrigacoes"><p class="sub">Carregando...</p></div>
      <h3 style="margin:16px 0 4px;font-size:14px;">Nova obrigação</h3>
      <label>O que precisa lembrar</label><input type="text" id="gdObrTitulo" maxlength="150" placeholder="Ex.: Pagar o domínio">
      <div class="row2"><div><label>Data</label><input type="date" id="gdObrData"></div><div><label>Repetir a cada (dias, opcional)</label><input type="number" id="gdObrRep" min="1" placeholder="365"></div></div>
      <button class="btn btn-ghost btn-block" id="gdObrAdd" style="margin-top:10px;">Adicionar</button>
    </div>
    <div class="card"><h2>Modo treino</h2>
      <p class="sub">Cria 5 pacientes de mentira, com [TREINO] no nome, para a equipe praticar agenda, ficha, prontuário e receita sem medo de errar. Depois, um toque remove os pacientes e tudo o que foi feito neles. Seus pacientes de verdade não são tocados.</p>
      <div class="btn-row"><button class="btn btn-ghost" id="gdTreinoCriar">Criar pacientes de treino</button><button class="btn btn-outline" id="gdTreinoRemover">Remover treino</button></div>
    </div>
    <div class="card"><h2>Mapa de funções</h2>
      <p class="sub">Todas as funções do sistema, por perfil. Procure pelo que você quer fazer e toque em Abrir. O tour mostra uma função de cada vez.</p>
      <input type="text" id="gdBusca" placeholder="O que você quer fazer? Ex.: backup, receita, feriado" autocomplete="off">
      <div style="display:flex;gap:8px;margin:10px 0;flex-wrap:wrap;">
        <select id="gdPerfil" style="width:auto;"><option value="">Todos os perfis</option><option value="admin">Master</option><option value="atendente">Agendador</option><option value="profissional">Profissional</option></select>
        <button class="btn btn-ghost" id="gdTour" type="button">Fazer o tour</button>
      </div>
      <div id="gdFuncoes"></div>
    </div>`;
}
const gdCor = {erro:'#C1462F', aviso:'#B26A00', ok:'#2E7D4F', info:'#4B5755'};
const gdSimbolo = {erro:'✖', aviso:'▲', ok:'✔', info:'●'};
function gdPassosModal(titulo, passos){
  openModal(`<h2>${esc(titulo)}</h2><ol style="padding-left:20px;line-height:1.55;">${passos.map(p=>`<li style="margin:6px 0;">${esc(p)}</li>`).join('')}</ol><div class="btn-row"><button class="btn btn-primary" onclick="closeModal()">Entendi</button></div>`);
}
async function gdCorrigir(id, confirmar){
  if(confirmar && !window.confirm(confirmar)) return;
  try{
    toast('Corrigindo...');
    const r = await api('/clinica/guardiao/corrigir', { method:'POST', body:{ id } });
    toast(r.mensagem || 'Pronto.');
  }catch(e){ erroApi(e); }
  carregarGuardiao(); guardiaoSelo(true);
}
function gdItemHtml(i){
  const a = i.acao; let botoes = '';
  if(a && a.tipo==='corrigir') botoes = `<button class="btn btn-ghost" data-gd="corrigir" data-id="${esc(a.id)}" data-conf="${esc(a.confirmar||'')}" style="margin-top:6px;">${esc(a.rotulo)}</button>`;
  else if(a && a.tipo==='ir') botoes = `<button class="btn btn-ghost" data-gd="ir" data-a='${esc(JSON.stringify(a))}' style="margin-top:6px;">${esc(a.rotulo)}</button>`;
  else if(a && a.tipo==='passos') botoes = `<button class="btn btn-ghost" data-gd="passos" data-t="${esc(i.titulo)}" data-p='${esc(JSON.stringify(a.passos))}' style="margin-top:6px;">${esc(a.rotulo)}</button>`;
  else if(a && a.tipo==='obrigacao') botoes = `<div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:6px;"><button class="btn btn-ghost" data-gd="feita" data-id="${esc(a.id)}">Já fiz</button><button class="btn btn-outline" data-gd="adiar" data-id="${esc(a.id)}">Adiar 7 dias</button></div>`;
  return `<div style="border-top:1px solid var(--line);padding:10px 0;"><div style="display:flex;gap:10px;align-items:flex-start;"><span style="color:${gdCor[i.nivel]};font-weight:700;flex:0 0 18px;">${gdSimbolo[i.nivel]}</span><div style="flex:1;min-width:0;"><b>${esc(i.titulo)}</b><div class="sub" style="margin:2px 0 0;">${esc(i.detalhe)}</div>${botoes}</div></div></div>`;
}
let gdMostrarOk = false;
async function carregarGuardiao(){
  const box = document.getElementById('gdLista'), res = document.getElementById('gdResumo'); if(!box) return;
  try{
    const v = await api('/clinica/guardiao');
    const r = v.resumo;
    res.innerHTML = r.erros ? `<p style="font-weight:700;color:${gdCor.erro};margin:0;">${r.erros} problema(s) para resolver${r.avisos?` e ${r.avisos} aviso(s)`:''}.</p>` :
      r.avisos ? `<p style="font-weight:700;color:${gdCor.aviso};margin:0;">Nenhum problema grave. ${r.avisos} aviso(s).</p>` : `<p style="font-weight:700;color:${gdCor.ok};margin:0;">Tudo em ordem.</p>`;
    res.innerHTML += `<p class="sub" style="margin:2px 0 0;">Conferido às ${new Date(v.gerado_em).toLocaleTimeString('pt-BR',{hour:'2-digit',minute:'2-digit'})}. O Guardião confere sozinho a cada 6 horas.</p>`;
    const grupos = ['Obrigações','Segurança','Backup','Sistema','Operação'];
    const atencao = v.itens.filter(i=>i.nivel==='erro'||i.nivel==='aviso');
    const resto = v.itens.filter(i=>i.nivel==='ok'||i.nivel==='info');
    let html = '';
    for(const g of grupos){ const it = atencao.filter(i=>i.grupo===g); if(it.length) html += `<h3 style="margin:14px 0 2px;font-size:14px;color:var(--ink-soft);">${g}</h3>` + it.map(gdItemHtml).join(''); }
    if(!atencao.length) html = '<p class="sub">Nada precisa da sua atenção agora.</p>';
    html += `<button class="btn btn-outline btn-block" id="gdVerOk" style="margin-top:12px;">${gdMostrarOk?'Esconder':'Mostrar'} o que está em dia (${resto.length})</button>`;
    if(gdMostrarOk) html += '<div>' + grupos.map(g=>{ const it = resto.filter(i=>i.grupo===g); return it.length ? `<h3 style="margin:14px 0 2px;font-size:14px;color:var(--ink-soft);">${g}</h3>` + it.map(gdItemHtml).join('') : ''; }).join('') + '</div>';
    box.innerHTML = html;
    document.getElementById('gdVerOk').onclick = ()=>{ gdMostrarOk = !gdMostrarOk; carregarGuardiao(); };
    box.querySelectorAll('[data-gd]').forEach(b=> b.onclick = async ()=>{
      const k = b.dataset.gd;
      if(k==='corrigir') gdCorrigir(b.dataset.id, b.dataset.conf);
      else if(k==='ir') guardiaoIr(JSON.parse(b.dataset.a));
      else if(k==='passos') gdPassosModal(b.dataset.t, JSON.parse(b.dataset.p));
      else if(k==='feita' || k==='adiar'){
        try{ await api(`/clinica/guardiao/obrigacoes/${b.dataset.id}/${k}`, { method:'POST', body:{ dias:7 } }); toast(k==='feita'?'Anotado.':'Adiado 7 dias.'); }catch(e){ erroApi(e); }
        carregarGuardiao(); carregarObrigacoes(); guardiaoSelo(true);
      }
    });
  }catch(e){ res.innerHTML = `<p class="fieldmsg bad">${esc(e.message)}</p>`; }
}
async function carregarObrigacoes(){
  const box = document.getElementById('gdObrigacoes'); if(!box) return;
  try{
    const l = await api('/clinica/guardiao/obrigacoes');
    const hoje = hojeISO();
    box.innerHTML = l.length ? l.map(o=>{
      const feita = !!o.feito_em, vencida = !feita && o.vence_em < hoje;
      return `<div style="border-top:1px solid var(--line);padding:9px 0;display:flex;gap:10px;justify-content:space-between;align-items:flex-start;">
        <div style="min-width:0;"><b style="${feita?'text-decoration:line-through;color:var(--ink-soft);':''}">${esc(o.titulo)}</b>
        <div class="sub" style="margin:2px 0 0;${vencida?'color:#C1462F;font-weight:600;':''}">${feita?'Feita':'Vence em '+fmtData(o.vence_em)}${o.repetir_dias?` · repete a cada ${o.repetir_dias} dias`:''}</div>
        ${o.detalhe && !feita ? `<details style="margin-top:4px;"><summary style="cursor:pointer;font-size:13px;color:var(--teal-700,#1F6F8B);">Como fazer</summary><div class="sub" style="margin-top:4px;">${esc(o.detalhe)}</div></details>` : ''}</div>
        <div style="display:flex;gap:6px;flex:0 0 auto;">${feita?'':`<button class="btn btn-ghost" data-ob="feita" data-id="${o.id}">Feito</button>`}<button class="btn btn-outline" data-ob="del" data-id="${o.id}" title="Remover">✕</button></div></div>`;
    }).join('') : '<p class="sub">Nenhuma obrigação.</p>';
    box.querySelectorAll('[data-ob]').forEach(b=> b.onclick = async ()=>{
      try{
        if(b.dataset.ob==='feita') await api(`/clinica/guardiao/obrigacoes/${b.dataset.id}/feita`, { method:'POST', body:{} });
        else { if(!window.confirm('Remover esta obrigação da lista?')) return; await api(`/clinica/guardiao/obrigacoes/${b.dataset.id}`, { method:'DELETE' }); }
      }catch(e){ return erroApi(e); }
      carregarObrigacoes(); carregarGuardiao(); guardiaoSelo(true);
    });
  }catch(e){ box.innerHTML = `<p class="fieldmsg bad">${esc(e.message)}</p>`; }
}
function listarFuncoes(){
  const box = document.getElementById('gdFuncoes'); if(!box) return;
  const q = (document.getElementById('gdBusca').value||'').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g,'');
  const per = document.getElementById('gdPerfil').value;
  const lista = FUNCOES.filter(f=> (!per || f.p.includes(per)) && (!q || (f.n+' '+f.d+' '+f.t).toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g,'').includes(q)));
  box.innerHTML = lista.length ? lista.map(f=>`<div style="border-top:1px solid var(--line);padding:10px 0;"><div style="display:flex;justify-content:space-between;gap:10px;align-items:flex-start;"><div style="min-width:0;"><b>${esc(f.n)}</b><div class="sub" style="margin:2px 0 0;">${esc(f.d)}</div><div class="sub" style="margin:2px 0 0;font-size:12px;">Para: ${f.p.map(x=>NOME_PAPEL[x]).join(', ')}</div></div><button class="btn btn-ghost" data-f="${FUNCOES.indexOf(f)}" style="flex:0 0 auto;">Abrir</button></div></div>`).join('') : '<p class="sub">Nada encontrado. Tente outra palavra.</p>';
  box.querySelectorAll('[data-f]').forEach(b=> b.onclick = ()=>{ const f = FUNCOES[+b.dataset.f]; closeModal(); guardiaoIr(f); });
}
function tourFuncoes(){
  const per = document.getElementById('gdPerfil').value || 'admin';
  const lista = FUNCOES.filter(f=>f.p.includes(per));
  let i = 0;
  const mostrar = ()=>{
    const f = lista[i];
    openModal(`<p class="sub" style="margin:0;">Tour do ${NOME_PAPEL[per]} · ${i+1} de ${lista.length}</p><h2 style="margin-top:4px;">${esc(f.n)}</h2><p style="line-height:1.5;">${esc(f.d)}</p>
      <div class="btn-row"><button class="btn btn-outline" id="trAnt" ${i===0?'disabled':''}>Voltar</button><button class="btn btn-primary" id="trProx">${i===lista.length-1?'Terminar':'Próxima'}</button></div>
      <button class="btn btn-ghost btn-block" id="trAbrir" style="margin-top:8px;">Abrir esta tela</button>`);
    document.getElementById('trAnt').onclick = ()=>{ i--; mostrar(); };
    document.getElementById('trProx').onclick = ()=>{ if(i===lista.length-1) closeModal(); else { i++; mostrar(); } };
    document.getElementById('trAbrir').onclick = ()=>{ closeModal(); guardiaoIr(f); };
  };
  mostrar();
}
function ligarGuardiao(){
  if(!document.getElementById('gdLista')) return;
  carregarGuardiao(); carregarObrigacoes(); listarFuncoes();
  document.getElementById('gdAtualizar').onclick = ()=>{ carregarGuardiao(); guardiaoSelo(true); };
  document.getElementById('gdBusca').oninput = listarFuncoes;
  document.getElementById('gdPerfil').onchange = listarFuncoes;
  document.getElementById('gdTour').onclick = tourFuncoes;
  document.getElementById('gdObrAdd').onclick = async ()=>{
    const titulo = document.getElementById('gdObrTitulo').value.trim(), data = document.getElementById('gdObrData').value, rep = document.getElementById('gdObrRep').value;
    if(!titulo || !data) return toast('Escreva o que lembrar e escolha a data.');
    try{ await api('/clinica/guardiao/obrigacoes', { method:'POST', body:{ titulo, vence_em:data, repetir_dias: rep||null } }); toast('Obrigação adicionada.'); document.getElementById('gdObrTitulo').value=''; carregarObrigacoes(); carregarGuardiao(); }
    catch(e){ erroApi(e); }
  };
  document.getElementById('gdTreinoCriar').onclick = ()=> gdCorrigir('treino_criar');
  document.getElementById('gdTreinoRemover').onclick = ()=> gdCorrigir('treino_remover', 'Remover os pacientes de treino e tudo o que foi feito neles?');
}
/* aviso no Início do Master quando o Guardião achou problema */
let gdObservador = null;
async function guardiaoAvisoInicio(){
  if(gdObservador){ gdObservador.disconnect(); gdObservador = null; }
  if(usuarioAtual?.papel!=='admin') return;
  try{
    const r = await api('/clinica/guardiao/resumo');
    const main = document.getElementById('main'); if(!main || (!r.erros && !r.avisos)) return;
    const pr = ()=>{
      if(document.getElementById('gdAvisoInicio') || !main.firstChild) return;
      const v = document.querySelector('#pillnav button.active')?.dataset.view; if(v!=='inicio' && v!=='painel') return;
      const d = document.createElement('div'); d.className = 'card'; d.id = 'gdAvisoInicio';
      d.innerHTML = `<h2 style="color:${r.erros?gdCor.erro:gdCor.aviso};">Guardião: ${r.erros?r.erros+' problema(s)':r.avisos+' aviso(s)'}</h2><p class="sub">O Guardião achou ${r.erros?'problemas que precisam da sua atenção':'avisos para você olhar'}. Toque para ver e corrigir.</p><button class="btn btn-primary btn-block" id="gdAbrir">Abrir o Guardião</button>`;
      main.insertBefore(d, main.firstChild);
      d.querySelector('#gdAbrir').onclick = ()=> guardiaoIr({view:'master', aba:'Guardião'});
    };
    pr();
    /* a tela do Painel carrega os números depois e refaz o conteúdo: o aviso volta junto */
    gdObservador = new MutationObserver(pr);
    gdObservador.observe(main, { childList:true });
  }catch(e){}
}
/* bolinha vermelha no menu Master com o número de problemas */
let gdSeloEm = 0;
async function guardiaoSelo(forcar){
  if(usuarioAtual?.papel!=='admin') return;
  if(!forcar && Date.now()-gdSeloEm < 60000) return;
  gdSeloEm = Date.now();
  try{
    const r = await api('/clinica/guardiao/resumo');
    const btn = document.getElementById('btnMasterAccess'); if(!btn) return;
    let s = btn.querySelector('.selo-gd'); if(!s){ s = document.createElement('span'); s.className = 'selo-gd'; btn.appendChild(s); }
    const n = r.erros || r.avisos || 0;
    s.textContent = n ? String(n) : ''; s.style.display = n ? '' : 'none';
    s.style.background = r.erros ? '#C1462F' : '#B26A00';
    s.title = r.erros ? r.erros+' problema(s) no Guardião' : n ? n+' aviso(s) no Guardião' : '';
  }catch(e){}
}

if('serviceWorker' in navigator){ window.addEventListener('load', ()=>{ navigator.serviceWorker.register('/sw.js').catch(()=>{}); }); }

/* botão "Mostrar senha" embaixo de todo campo de senha, para conferir o que foi digitado */
(function(){
  function ligar(i){
    if(i.dataset.verSenha) return; i.dataset.verSenha = '1';
    const b = document.createElement('button'); b.type = 'button'; b.className = 'ver-senha'; b.textContent = '👁 Mostrar senha';
    b.onclick = ()=>{ const oculto = i.type === 'password'; i.type = oculto ? 'text' : 'password'; b.textContent = oculto ? '🙈 Esconder senha' : '👁 Mostrar senha'; i.focus(); };
    i.insertAdjacentElement('afterend', b);
  }
  function varrer(){ document.querySelectorAll('input[type=password]:not([data-ver-senha])').forEach(ligar); }
  new MutationObserver(varrer).observe(document.documentElement, { childList:true, subtree:true });
  varrer();
})();
