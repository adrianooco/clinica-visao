const express = require('express');
const { rotulo, cidade } = require('../utils/rotulo');
const bcrypt = require('bcryptjs');
const pool = require('../db/pool');
const { exigirLogin, exigirAdmin, limparCacheUsuario } = require('../middleware/auth');
const { validarSenha } = require('../utils/senha');

const { limparConfig } = require('../utils/ficha');
const router = express.Router();
router.use(exigirLogin);

router.get('/', async (req, res) => {
  // chave_integracao fica fora daqui de propósito: ela dá acesso de escrita na agenda
  // sem precisar de login, então só o admin pode vê-la (rota separada abaixo)
  const r = await pool.query(
    `SELECT id, slug, nome_fantasia, cnpj, endereco, local_exame_padrao, telefone, link_site, logo_url,
            campos_obrigatorios, config_impressao, whatsapp_numero, whatsapp_auto, politica_profissionais, horario_abertura, horario_fechamento, dias_funcionamento, ativa, criado_em, atualizado_em
     FROM clinicas WHERE id=$1`,
    [req.usuario.clinicaId]
  );
  res.json(r.rows[0]);
});

/* só admin: a chave de integração dá acesso de escrita na agenda sem senha de funcionário */
/* preço inicial das armações e garantias mostrados na Vitrine de lentes */
router.get('/vitrine', async (req, res) => {
  if (!['admin', 'gestor'].includes(req.usuario.papel)) return res.status(403).json({ erro: 'Sem permissão.' });
  const r = await pool.query(`SELECT COALESCE(vitrine_preco_armacao,89.90) AS preco, COALESCE(vitrine_garantia_lente_dias,90) AS lente_dias, COALESCE(vitrine_garantia_armacao,'') AS armacao FROM clinicas WHERE id=$1`, [req.usuario.clinicaId]);
  res.json({ preco_armacao: Number(r.rows[0].preco), garantia_lente_dias: Number(r.rows[0].lente_dias), garantia_armacao: r.rows[0].armacao });
});
router.put('/vitrine', exigirAdmin, async (req, res) => {
  const preco = Number(String(req.body.preco_armacao).replace(',', '.'));
  const dias = parseInt(req.body.garantia_lente_dias, 10);
  const texto = String(req.body.garantia_armacao || '').trim().slice(0, 300);
  if (!(preco > 0) || preco > 100000) return res.status(400).json({ erro: 'Informe um preço maior que zero.' });
  if (!(dias >= 0) || dias > 730) return res.status(400).json({ erro: 'Dias de garantia da lente: de 0 a 730.' });
  await pool.query(`UPDATE clinicas SET vitrine_preco_armacao=$1, vitrine_garantia_lente_dias=$2, vitrine_garantia_armacao=$3 WHERE id=$4`, [preco.toFixed(2), dias, texto, req.usuario.clinicaId]);
  res.json({ ok: true, preco_armacao: preco, garantia_lente_dias: dias, garantia_armacao: texto });
});
router.get('/chave-integracao', exigirAdmin, async (req, res) => {
  const r = await pool.query(`SELECT chave_integracao FROM clinicas WHERE id=$1`, [req.usuario.clinicaId]);
  res.json({ chave_integracao: r.rows[0]?.chave_integracao || null });
});

router.put('/', exigirAdmin, async (req, res) => {
  const { nome_fantasia, endereco, local_exame_padrao, telefone, link_site, campos_obrigatorios, logo_url, whatsapp_numero, whatsapp_auto, politica_profissionais } = req.body;
  const politica = ['so_medico', 'medico_e_optometrista'].includes(politica_profissionais) ? politica_profissionais : null;
  const wpp = String(whatsapp_numero || '').replace(/\D/g, '').replace(/^55(?=\d{10,11}$)/, '').slice(0, 11) || null;
  const antes = (await pool.query(`SELECT whatsapp_auto FROM clinicas WHERE id=$1`, [req.usuario.clinicaId])).rows[0];
  const r = await pool.query(
    `UPDATE clinicas SET nome_fantasia=$1, endereco=$2, local_exame_padrao=$3, telefone=$4, link_site=$5, campos_obrigatorios=$6, logo_url=$7,
            whatsapp_numero=COALESCE($9, whatsapp_numero), whatsapp_auto=COALESCE($10, whatsapp_auto), politica_profissionais=COALESCE($11, politica_profissionais)
     WHERE id=$8 RETURNING *`,
    [nome_fantasia, endereco || null, local_exame_padrao || null, telefone || null, link_site || null,
     JSON.stringify(limparConfig(campos_obrigatorios)), logo_url || null, req.usuario.clinicaId,
     whatsapp_numero === undefined ? null : wpp, whatsapp_auto === undefined ? null : !!whatsapp_auto, politica]
  );
  // ao ligar o WhatsApp automático pela primeira vez, quem já estava agendado não recebe uma enxurrada de confirmações
  if (whatsapp_auto === true && antes && !antes.whatsapp_auto) {
    await pool.query(`UPDATE agendamentos SET lembrete_confirmacao_enviado=TRUE WHERE clinica_id=$1 AND criado_em < NOW()`, [req.usuario.clinicaId]);
  }
  res.json(r.rows[0]);
});

/* lista enxuta dos profissionais ativos, pra qualquer usuário logado escolher
   quem atendeu (ex: no formulário de receita). Não expõe dado administrativo. */
router.get('/profissionais', async (req, res) => {
  if (req.usuario.papel === 'atendente' && !(req.usuario.permissoes || []).includes('receita')) return res.json([]);
  // inclui carimbo/assinatura/registro aqui mesmo: é o que vai ser impresso na
  // receita, então quem monta a receita (mesmo sendo atendente) precisa enxergar
  const r = await pool.query(
    `SELECT id, nome, registro_conselho, formacao, formacao_tipo, formacao_portaria, carimbo_texto, assinatura_url
     FROM usuarios WHERE clinica_id=$1 AND papel='profissional' AND ativo=TRUE ORDER BY nome`,
    [req.usuario.clinicaId]
  );
  res.json(r.rows);
});

/* Como imprimir receita, atestado e declaração: tamanho da folha, cor, margem e rodapé */
const PAPEIS_FOLHA = ['A4', 'A5', 'Letter'];
router.put('/impressao', exigirAdmin, async (req, res) => {
  const b = req.body || {};
  const cfg = {
    papel: PAPEIS_FOLHA.includes(b.papel) ? b.papel : 'A4',
    orientacao: b.orientacao === 'landscape' ? 'landscape' : 'portrait',
    cor: b.cor === 'pb' ? 'pb' : 'colorido',
    margem_mm: Math.min(Math.max(parseInt(b.margem_mm, 10) || 14, 5), 30),
    rodape: String(b.rodape || '').slice(0, 300),
  };
  await pool.query(`UPDATE clinicas SET config_impressao=$1 WHERE id=$2`, [JSON.stringify(cfg), req.usuario.clinicaId]);
  res.json(cfg);
});

/* usuários (atendentes, profissionais) da clínica, só o admin gerencia */
router.get('/usuarios', exigirAdmin, async (req, res) => {
  const r = await pool.query(
    `SELECT u.id, u.nome, u.email, u.papel, u.ativo, u.unidade_id, un.nome AS unidade_nome,
            u.registro_conselho, u.formacao, u.formacao_tipo, u.formacao_portaria, u.carimbo_texto, u.permissoes, (u.assinatura_url IS NOT NULL) AS tem_assinatura, u.totp_ativo,
            COALESCE((SELECT json_agg(x.unidade_id ORDER BY x.nome) FROM (SELECT uu.unidade_id, c.nome FROM usuarios_unidades uu JOIN unidades c ON c.id=uu.unidade_id WHERE uu.usuario_id=u.id) x), '[]'::json) AS unidades_ids,
            COALESCE((SELECT json_agg(x.nome ORDER BY x.nome) FROM (SELECT ${rotulo('c')} AS nome FROM usuarios_unidades uu JOIN unidades c ON c.id=uu.unidade_id WHERE uu.usuario_id=u.id) x), '[]'::json) AS unidades_nomes
     FROM usuarios u LEFT JOIN unidades un ON un.id = u.unidade_id
     WHERE u.clinica_id=$1 ORDER BY u.nome`,
    [req.usuario.clinicaId]
  );
  res.json(r.rows);
});

/* cidades de um usuário: aceita lista (unidades_ids) ou uma só (unidade_id); só cidades desta clínica */
async function cidadesDoBody(clinicaId, b) {
  let lista;
  if (Array.isArray(b.unidades_ids)) lista = b.unidades_ids;
  else if (b.unidade_id !== undefined) lista = b.unidade_id ? [b.unidade_id] : [];
  else return null;
  lista = [...new Set(lista.map(String))];
  if (!lista.length) return [];
  const r = await pool.query(`SELECT id FROM unidades WHERE clinica_id=$1 AND id = ANY($2::uuid[])`, [clinicaId, lista.filter((x) => /^[0-9a-f-]{36}$/i.test(x))]);
  return r.rows.map((x) => x.id);
}
async function gravarCidades(usuarioId, ids) {
  await pool.query(`DELETE FROM usuarios_unidades WHERE usuario_id=$1`, [usuarioId]);
  for (const id of ids) await pool.query(`INSERT INTO usuarios_unidades (usuario_id, unidade_id) VALUES ($1,$2) ON CONFLICT DO NOTHING`, [usuarioId, id]);
  await pool.query(`UPDATE usuarios SET unidade_id=$2 WHERE id=$1`, [usuarioId, ids[0] || null]);
}

const PAPEIS_VALIDOS = ['admin', 'atendente', 'profissional', 'gestor'];
const TIPOS_FORMACAO = ['bacharelado', 'tecnologo'];

router.post('/usuarios', exigirAdmin, async (req, res) => {
  const { nome, email, senha, papel, unidade_id, registro_conselho, carimbo_texto, assinatura_url } = req.body;
  const formacao = String(req.body.formacao || '').trim().slice(0, 200) || null;
  const formacaoTipo = TIPOS_FORMACAO.includes(req.body.formacao_tipo) ? req.body.formacao_tipo : null;
  const formacaoPortaria = String(req.body.formacao_portaria || '').trim().slice(0, 160) || null;
  if (!nome || !email || !senha) return res.status(400).json({ erro: 'Preencha nome, e-mail e senha.' });
  { const e = validarSenha(senha); if (e) return res.status(400).json({ erro: e }); }
  const papelFinal = PAPEIS_VALIDOS.includes(papel) ? papel : 'atendente';
  const cidades = (await cidadesDoBody(req.usuario.clinicaId, req.body)) || [];
  if (papelFinal === 'atendente' && !cidades.length) return res.status(400).json({ erro: 'Escolha a cidade do agendador.' });
  try {
    const senhaHash = await bcrypt.hash(senha, 10);
    const r = await pool.query(
      `INSERT INTO usuarios (clinica_id, unidade_id, nome, email, senha_hash, papel, registro_conselho, carimbo_texto, assinatura_url, formacao, formacao_tipo, formacao_portaria)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12) RETURNING id, nome, email, papel, unidade_id, registro_conselho, formacao, carimbo_texto`,
      [req.usuario.clinicaId, cidades[0] || null, nome, email.toLowerCase().trim(), senhaHash, papelFinal,
       papelFinal === 'profissional' ? (registro_conselho || null) : null,
       papelFinal === 'profissional' ? (carimbo_texto || null) : null,
       papelFinal === 'profissional' ? (assinatura_url || null) : null,
       papelFinal === 'profissional' ? formacao : null,
       papelFinal === 'profissional' ? formacaoTipo : null,
       papelFinal === 'profissional' ? formacaoPortaria : null]
    );
    await gravarCidades(r.rows[0].id, cidades);
    res.status(201).json({ ...r.rows[0], unidades_ids: cidades });
  } catch (e) {
    if (e.code === '23505') return res.status(409).json({ erro: 'Já existe um usuário com esse e-mail nesta clínica.' });
    console.error(e); res.status(500).json({ erro: 'Erro ao criar usuário.' });
  }
});

/* editar dados de um usuário, incluindo carimbo/assinatura do profissional */
router.put('/usuarios/:id', exigirAdmin, async (req, res) => {
  const { nome, papel, unidade_id, registro_conselho, carimbo_texto, assinatura_url, ativo, permissoes } = req.body;
  const formacao = req.body.formacao === undefined ? null : String(req.body.formacao || '').trim().slice(0, 200);
  const formacaoTipo = req.body.formacao_tipo === undefined ? null : (TIPOS_FORMACAO.includes(req.body.formacao_tipo) ? req.body.formacao_tipo : '');
  const formacaoPortaria = req.body.formacao_portaria === undefined ? null : String(req.body.formacao_portaria || '').trim().slice(0, 160);
  const CHAVES = ['calendario', 'pacientes', 'assistente', 'receita', 'prontuario', 'retornos'];
  // ninguém desativa a si mesmo nem tira o último admin ativo
  if (ativo === false || (papel && papel !== 'admin')) {
    if (String(req.params.id) === String(req.usuario.usuarioId)) return res.status(400).json({ erro: 'Você não pode desativar nem rebaixar o seu próprio acesso.' });
    const alvo = (await pool.query(`SELECT papel FROM usuarios WHERE id=$1 AND clinica_id=$2`, [req.params.id, req.usuario.clinicaId])).rows[0];
    if (alvo && alvo.papel === 'admin') {
      const outros = (await pool.query(`SELECT COUNT(*)::int AS n FROM usuarios WHERE clinica_id=$1 AND papel='admin' AND ativo=TRUE AND id<>$2`, [req.usuario.clinicaId, req.params.id])).rows[0].n;
      if (!outros) return res.status(400).json({ erro: 'Precisa sobrar pelo menos um administrador ativo.' });
    }
  }
  const permFinal = Array.isArray(permissoes) ? JSON.stringify(permissoes.filter((c) => CHAVES.includes(c))) : null;
  const papelFinal = PAPEIS_VALIDOS.includes(papel) ? papel : null;
  const cidades = await cidadesDoBody(req.usuario.clinicaId, req.body);
  if (cidades && !cidades.length) {
    const alvo = (await pool.query(`SELECT papel FROM usuarios WHERE id=$1 AND clinica_id=$2`, [req.params.id, req.usuario.clinicaId])).rows[0];
    if ((papelFinal || (alvo && alvo.papel)) === 'atendente') return res.status(400).json({ erro: 'Escolha a cidade do agendador.' });
  }
  const r = await pool.query(
    `UPDATE usuarios SET
       nome = COALESCE($1, nome),
       papel = COALESCE($2, papel),
       unidade_id = COALESCE($3::uuid, unidade_id),
       registro_conselho = CASE WHEN COALESCE($2,papel)='profissional' THEN COALESCE($4, registro_conselho) ELSE NULL END,
       carimbo_texto = CASE WHEN COALESCE($2,papel)='profissional' THEN COALESCE($5, carimbo_texto) ELSE NULL END,
       assinatura_url = CASE WHEN COALESCE($2,papel)='profissional' THEN COALESCE($6, assinatura_url) ELSE NULL END,
       ativo = COALESCE($7, ativo),
       formacao = CASE WHEN COALESCE($2,papel)='profissional' THEN COALESCE($11, formacao) ELSE NULL END,
       formacao_tipo = CASE WHEN COALESCE($2,papel)='profissional' THEN (CASE WHEN $12::text IS NULL THEN formacao_tipo WHEN $12::text = '' THEN NULL ELSE $12::text END) ELSE NULL END,
       formacao_portaria = CASE WHEN COALESCE($2,papel)='profissional' THEN COALESCE($13, formacao_portaria) ELSE NULL END,
       permissoes = COALESCE($10::jsonb, permissoes)
     WHERE id=$8 AND clinica_id=$9
     RETURNING id, nome, email, papel, unidade_id, registro_conselho, formacao, formacao_tipo, formacao_portaria, carimbo_texto, ativo`,
    [nome || null, papelFinal, cidades ? (cidades[0] || null) : null, registro_conselho || null, carimbo_texto || null,
     assinatura_url || null, ativo === undefined ? null : ativo, req.params.id, req.usuario.clinicaId, permFinal, formacao, formacaoTipo, formacaoPortaria]
  );
  if (!r.rows.length) return res.status(404).json({ erro: 'Usuário não encontrado.' });
  if (cidades) await gravarCidades(req.params.id, cidades);
  limparCacheUsuario(req.params.id);
  res.json(r.rows[0]);
});

/* Excluir usuário. Se ele já tem registros (agendamentos, receitas), o banco não deixa apagar:
   nesse caso o acesso é desativado e o histórico fica preservado. */
router.delete('/usuarios/:id', exigirAdmin, async (req, res) => {
  if (String(req.params.id) === String(req.usuario.usuarioId)) return res.status(400).json({ erro: 'Você não pode excluir o seu próprio acesso.' });
  const alvo = (await pool.query(`SELECT id, papel FROM usuarios WHERE id=$1 AND clinica_id=$2`, [req.params.id, req.usuario.clinicaId])).rows[0];
  if (!alvo) return res.status(404).json({ erro: 'Usuário não encontrado.' });
  if (alvo.papel === 'admin') {
    const outros = (await pool.query(`SELECT COUNT(*)::int AS n FROM usuarios WHERE clinica_id=$1 AND papel='admin' AND ativo=TRUE AND id<>$2`, [req.usuario.clinicaId, alvo.id])).rows[0].n;
    if (!outros) return res.status(400).json({ erro: 'Precisa sobrar pelo menos um administrador ativo.' });
  }
  try {
    await pool.query(`DELETE FROM usuarios WHERE id=$1 AND clinica_id=$2`, [alvo.id, req.usuario.clinicaId]);
    limparCacheUsuario(alvo.id);
    return res.json({ ok: true, excluido: true });
  } catch (e) {
    if (e.code !== '23503') throw e;
    await pool.query(`UPDATE usuarios SET ativo=FALSE WHERE id=$1 AND clinica_id=$2`, [alvo.id, req.usuario.clinicaId]);
    limparCacheUsuario(alvo.id);
    return res.json({ ok: true, excluido: false, desativado: true });
  }
});

/* Acessos: o administrador escolhe o que cada agendador pode abrir */
router.put('/usuarios/:id/permissoes', exigirAdmin, async (req, res) => {
  const CHAVES = ['calendario', 'pacientes', 'assistente', 'receita', 'prontuario', 'retornos'];
  const lista = (Array.isArray(req.body.permissoes) ? req.body.permissoes : []).filter((c) => CHAVES.includes(c));
  const r = await pool.query(`UPDATE usuarios SET permissoes=$1::jsonb WHERE id=$2 AND clinica_id=$3 RETURNING id, permissoes`, [JSON.stringify(lista), req.params.id, req.usuario.clinicaId]);
  if (!r.rows.length) return res.status(404).json({ erro: 'Usuário não encontrado.' });
  limparCacheUsuario(req.params.id);
  res.json(r.rows[0]);
});

/* o próprio profissional logado consulta seus dados de carimbo/assinatura (pra receita puxar) */
router.get('/usuarios/eu', async (req, res) => {
  const r = await pool.query(
    `SELECT id, nome, papel, registro_conselho, carimbo_texto, assinatura_url FROM usuarios WHERE id=$1 AND clinica_id=$2`,
    [req.usuario.usuarioId, req.usuario.clinicaId]
  );
  if (!r.rows.length) return res.status(404).json({ erro: 'Usuário não encontrado.' });
  res.json(r.rows[0]);
});

router.put('/usuarios/:id/senha', exigirAdmin, async (req, res) => {
  const { senha } = req.body;
  if (!senha) return res.status(400).json({ erro: 'Informe a nova senha.' });
  { const e = validarSenha(senha); if (e) return res.status(400).json({ erro: e }); }
  const senhaHash = await bcrypt.hash(senha, 10);
  const r = await pool.query(
    `UPDATE usuarios SET senha_hash=$1 WHERE id=$2 AND clinica_id=$3 RETURNING id`,
    [senhaHash, req.params.id, req.usuario.clinicaId]
  );
  if (!r.rows.length) return res.status(404).json({ erro: 'Usuário não encontrado.' });
  res.json({ ok: true });
});

/* WhatsApp automático: situação e mensagem de teste (só o admin) */
router.get('/whatsapp-status', exigirAdmin, async (req, res) => {
  const wpp = require('../utils/whatsapp');
  const r = await pool.query(`SELECT whatsapp_numero, whatsapp_auto FROM clinicas WHERE id=$1`, [req.usuario.clinicaId]);
  res.json({
    servidor_configurado: wpp.configurado(),
    modelo_configurado: !!process.env.WA_TEMPLATE,
    webhook_configurado: !!(process.env.WA_VERIFY_TOKEN && process.env.WA_APP_SECRET),
    numero: r.rows[0]?.whatsapp_numero || null,
    automatico: !!r.rows[0]?.whatsapp_auto,
    endereco_webhook: `${req.protocol}://${req.get('host')}/whatsapp/webhook`,
  });
});

router.post('/whatsapp-teste', exigirAdmin, async (req, res) => {
  const wpp = require('../utils/whatsapp');
  if (!wpp.configurado()) return res.status(400).json({ erro: 'O servidor ainda não tem as chaves do WhatsApp (WA_TOKEN e WA_PHONE_ID).' });
  if (!wpp.normalizar(req.body.telefone)) return res.status(400).json({ erro: 'Digite um telefone com DDD.' });
  try {
    await wpp.enviarIniciada(req.body.telefone, 'Teste do WhatsApp automático da Clínica de Visão. Se você recebeu, está funcionando.');
    res.json({ ok: true });
  } catch (e) {
    res.status(502).json({ erro: `A Meta recusou o envio: ${e.message}` });
  }
});

/* Registro de acessos: quem abriu ou mexeu em dado de saúde (só o admin vê) */
router.get('/acessos', exigirAdmin, async (req, res) => {
  const r = await pool.query(
    `SELECT usuario_nome, acao, area, caminho, ip, criado_em FROM acessos_log WHERE clinica_id=$1 ORDER BY criado_em DESC LIMIT 300`,
    [req.usuario.clinicaId]);
  res.json(r.rows);
});

/* Atividade da equipe: quem entrou, quando usou pela última vez e o que fez no período (só o admin vê) */
function diasDoPedido(req) { return Math.max(1, Math.min(90, parseInt(req.query.dias, 10) || 7)); }
router.get('/atividade-equipe', exigirAdmin, async (req, res) => {
  const dias = diasDoPedido(req);
  const r = await pool.query(
    `SELECT u.id, u.nome, u.email, u.papel, u.ativo, u.ultimo_login, u.ultimo_acesso, u.loc_lat, u.loc_lng, u.loc_precisao, u.loc_em,
            COALESCE((SELECT json_agg(x.nome ORDER BY x.nome) FROM (SELECT ${rotulo('c')} AS nome FROM usuarios_unidades uu JOIN unidades c ON c.id=uu.unidade_id WHERE uu.usuario_id=u.id) x), '[]'::json) AS cidades,
            (SELECT COUNT(*)::int FROM entradas_log e WHERE e.usuario_id=u.id AND e.criado_em >= NOW() - make_interval(days => $2)) AS entradas,
            (SELECT COUNT(DISTINCT e.criado_em::date)::int FROM entradas_log e WHERE e.usuario_id=u.id AND e.criado_em >= NOW() - make_interval(days => $2)) AS dias_com_entrada,
            (SELECT COUNT(*)::int FROM agendamentos a WHERE a.usuario_id=u.id AND a.criado_em >= NOW() - make_interval(days => $2)) AS marcou,
            (SELECT COUNT(*)::int FROM acessos_log l WHERE l.usuario_id=u.id AND l.area='paciente' AND l.acao='POST' AND l.criado_em >= NOW() - make_interval(days => $2)) AS pacientes,
            (SELECT COUNT(*)::int FROM acessos_log l WHERE l.usuario_id=u.id AND l.acao<>'GET' AND l.criado_em >= NOW() - make_interval(days => $2)) AS alteracoes
       FROM usuarios u
      WHERE u.clinica_id=$1 AND u.papel <> 'admin'
      ORDER BY (u.papel='atendente') DESC, u.ativo DESC, u.ultimo_acesso DESC NULLS LAST, u.nome`,
    [req.usuario.clinicaId, dias]);
  res.json({ dias, agora: new Date().toISOString().slice(0, 19), equipe: r.rows });
});

const TEXTO_ACAO = {
  paciente: { GET: 'Abriu a ficha de um paciente', POST: 'Cadastrou um paciente', PUT: 'Editou um paciente', PATCH: 'Editou um paciente', DELETE: 'Excluiu um paciente' },
  agendamento: { PUT: 'Mudou um agendamento', PATCH: 'Mudou um agendamento', DELETE: 'Excluiu um agendamento' },
  agenda: { POST: 'Abriu uma agenda', PUT: 'Editou uma agenda', PATCH: 'Editou uma agenda', DELETE: 'Apagou uma agenda' },
};
function textoDoAcesso(l) {
  if (l.area === 'paciente' && l.acao === 'GET' && !/\/pacientes\/[0-9a-f-]{8,}/i.test(l.caminho || '')) return 'Consultou a lista de pacientes';
  if (l.area === 'agendamento' && /\/status/.test(l.caminho || '')) return 'Mudou o status de um agendamento';
  return (TEXTO_ACAO[l.area] && TEXTO_ACAO[l.area][l.acao]) || `${l.acao} ${l.area}`;
}
router.get('/atividade-equipe/:usuarioId', exigirAdmin, async (req, res) => {
  const dias = diasDoPedido(req);
  const uid = req.params.usuarioId;
  if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(uid)) return res.status(400).json({ erro: 'Pessoa inválida.' });
  const u = await pool.query(`SELECT id, nome, papel FROM usuarios WHERE id=$1 AND clinica_id=$2`, [uid, req.usuario.clinicaId]);
  if (!u.rows.length) return res.status(404).json({ erro: 'Pessoa não encontrada.' });
  const desde = `NOW() - make_interval(days => $3)`;
  const [en, ac, ag] = await Promise.all([
    pool.query(`SELECT criado_em, lat, lng FROM entradas_log WHERE usuario_id=$1 AND clinica_id=$2 AND criado_em >= ${desde} ORDER BY criado_em DESC LIMIT 80`, [uid, req.usuario.clinicaId, dias]),
    pool.query(`SELECT acao, area, caminho, criado_em FROM acessos_log WHERE usuario_id=$1 AND clinica_id=$2 AND criado_em >= ${desde} AND NOT (area='agendamento' AND acao='POST') ORDER BY criado_em DESC LIMIT 80`, [uid, req.usuario.clinicaId, dias]),
    pool.query(`SELECT a.criado_em, to_char(a.data_hora,'DD/MM "às" HH24:MI') AS quando_exame, ${cidade('un')} AS cidade FROM agendamentos a LEFT JOIN unidades un ON un.id=a.unidade_id WHERE a.usuario_id=$1 AND a.clinica_id=$2 AND a.criado_em >= ${desde} ORDER BY a.criado_em DESC LIMIT 80`, [uid, req.usuario.clinicaId, dias]),
  ]);
  const eventos = [
    ...en.rows.map(x => ({ quando: x.criado_em, texto: 'Entrou no sistema', tipo: 'entrada', lat: x.lat, lng: x.lng })),
    ...ac.rows.map(x => ({ quando: x.criado_em, texto: textoDoAcesso(x), tipo: 'acao' })),
    ...ag.rows.map(x => ({ quando: x.criado_em, texto: `Marcou um exame para ${x.quando_exame} em ${x.cidade || 'sem cidade'}`, tipo: 'marcou' })),
  ].sort((a, b) => new Date(b.quando) - new Date(a.quando)).slice(0, 80);
  res.json({ usuario: u.rows[0], dias, eventos });
});

/* Backup: o admin baixa uma cópia completa, trancada com uma senha escolhida na hora */
router.post('/backup', exigirAdmin, async (req, res) => {
  const { gerarBackupCompleto, protegerBackup } = require('../utils/backup');
  const senha = String(req.body.senha || '');
  if (senha.length < 8) return res.status(400).json({ erro: 'A senha do backup precisa ter pelo menos 8 caracteres.' });
  const copia = await gerarBackupCompleto(req.usuario.clinicaId);
  await pool.query(`INSERT INTO acessos_log (clinica_id, usuario_id, usuario_nome, acao, area, caminho, ip) VALUES ($1,$2,$3,'POST','backup','/clinica/backup',$4)`,
    [req.usuario.clinicaId, req.usuario.usuarioId, req.usuario.nome, req.ip]).catch(() => {});
  res.setHeader('Cache-Control', 'no-store');
  res.json(protegerBackup(copia, senha));
});

/* Licença da clínica */
router.get('/licenca', exigirAdmin, async (req, res) => {
  const lic = require('../utils/licenca');
  const c = (await pool.query(`SELECT slug, licenca FROM clinicas WHERE id=$1`, [req.usuario.clinicaId])).rows[0];
  const r = lic.conferir(c.licenca, c.slug);
  res.json({ controle: !!process.env.LICENCA_SEGREDO, obrigatoria: lic.obrigatoria(), valida: r.valida, motivo: r.motivo, ate: r.ate || null, dias: r.dias ?? null });
});
router.post('/licenca', exigirAdmin, async (req, res) => {
  const lic = require('../utils/licenca');
  const chave = String(req.body.chave || '').trim();
  const c = (await pool.query(`SELECT slug FROM clinicas WHERE id=$1`, [req.usuario.clinicaId])).rows[0];
  const r = lic.conferir(chave, c.slug);
  if (!process.env.LICENCA_SEGREDO) return res.status(400).json({ erro: 'Este servidor não usa controle de licença.' });
  if (!r.valida) return res.status(400).json({ erro: r.motivo === 'outra_clinica' ? 'Essa chave é de outra clínica.' : r.motivo === 'vencida' ? 'Essa chave já venceu.' : 'Chave inválida.' });
  await pool.query(`UPDATE clinicas SET licenca=$1 WHERE id=$2`, [chave, req.usuario.clinicaId]);
  require('../middleware/auth').limparCacheLicenca(req.usuario.clinicaId);
  res.json({ ok: true, ate: r.ate, dias: r.dias });
});

/* Resumo de segurança para o guia de primeiros passos */
router.get('/seguranca-status', exigirAdmin, async (req, res) => {
  const email = require('../utils/email'), cripto = require('../utils/cripto');
  const q = async (sql) => (await pool.query(sql, [req.usuario.clinicaId])).rows[0];
  const t = await q(`SELECT COUNT(*) FILTER (WHERE totp_ativo)::int AS com_codigo, COUNT(*)::int AS total
      FROM usuarios WHERE clinica_id=$1 AND ativo=TRUE`);
  res.json({ criptografia: cripto.ativa(), email: email.ativo(), backup_automatico: !!(email.ativo() && process.env.BACKUP_EMAIL_PARA && process.env.BACKUP_SENHA),
    whatsapp_meta: !!(process.env.WA_TOKEN && process.env.WA_PHONE_ID), usuarios: t.total, com_codigo: t.com_codigo });
});

/* Quando foi o último backup (o painel avisa se passou de 7 dias) */
router.get('/backup-status', exigirAdmin, async (req, res) => {
  const r = await pool.query(
    `SELECT MAX(criado_em) AS ultimo, FLOOR(EXTRACT(EPOCH FROM (LOCALTIMESTAMP - MAX(criado_em))) / 86400) AS dias FROM acessos_log WHERE clinica_id=$1 AND area='backup'`,
    [req.usuario.clinicaId]);
  const ultimo = r.rows[0].ultimo;
  res.json({ ultimo, dias: ultimo ? Math.max(0, Number(r.rows[0].dias)) : null });
});

/* ---------- Guardião do sistema (só o administrador) ---------- */
const guardiao = require('../utils/guardiao');
let cacheGuardiao = new Map();
router.get('/guardiao', exigirAdmin, async (req, res) => {
  const v = await guardiao.verificar(req.usuario.clinicaId);
  cacheGuardiao.set(req.usuario.clinicaId, { em: Date.now(), resumo: v.resumo });
  res.setHeader('Cache-Control', 'no-store');
  res.json(v);
});
/* só os números, para o aviso vermelho no menu (guarda por 2 minutos) */
router.get('/guardiao/resumo', exigirAdmin, async (req, res) => {
  const c = cacheGuardiao.get(req.usuario.clinicaId);
  if (c && Date.now() - c.em < 120000) return res.json(c.resumo);
  const v = await guardiao.verificar(req.usuario.clinicaId);
  cacheGuardiao.set(req.usuario.clinicaId, { em: Date.now(), resumo: v.resumo });
  res.json(v.resumo);
});
router.post('/guardiao/corrigir', exigirAdmin, async (req, res) => {
  const r = await guardiao.corrigirItem(req.usuario.clinicaId, req.usuario, String(req.body.id || ''));
  cacheGuardiao.delete(req.usuario.clinicaId);
  await pool.query(`INSERT INTO acessos_log (clinica_id, usuario_id, usuario_nome, acao, area, caminho, ip) VALUES ($1,$2,$3,'FIX','guardiao',$4,$5)`,
    [req.usuario.clinicaId, req.usuario.id, req.usuario.nome || null, String(req.body.id || '').slice(0, 150), req.ip]).catch(() => {});
  res.status(r.ok ? 200 : 400).json(r);
});
router.get('/guardiao/obrigacoes', exigirAdmin, async (req, res) => {
  await guardiao.garantirObrigacoes(req.usuario.clinicaId);
  const r = await pool.query(`SELECT id, codigo, titulo, detalhe, vence_em::text AS vence_em, repetir_dias, feito_em FROM assistente_obrigacoes WHERE clinica_id=$1 AND ativo ORDER BY (feito_em IS NOT NULL), vence_em`, [req.usuario.clinicaId]);
  res.json(r.rows);
});
router.post('/guardiao/obrigacoes', exigirAdmin, async (req, res) => {
  const titulo = String(req.body.titulo || '').trim().slice(0, 150), data = String(req.body.vence_em || '');
  if (!titulo || !/^\d{4}-\d{2}-\d{2}$/.test(data)) return res.status(400).json({ erro: 'Informe o título e a data.' });
  const rep = parseInt(req.body.repetir_dias, 10);
  const r = await pool.query(`INSERT INTO assistente_obrigacoes (clinica_id, titulo, detalhe, vence_em, repetir_dias) VALUES ($1,$2,$3,$4,$5) RETURNING id`,
    [req.usuario.clinicaId, titulo, String(req.body.detalhe || '').slice(0, 500) || null, data, rep > 0 ? rep : null]);
  cacheGuardiao.delete(req.usuario.clinicaId);
  res.status(201).json({ id: r.rows[0].id });
});
/* marcar como feita (se repete, a próxima data é calculada a partir de hoje) ou adiar */
router.post('/guardiao/obrigacoes/:id/feita', exigirAdmin, async (req, res) => {
  const r = await pool.query(`UPDATE assistente_obrigacoes SET
      feito_em = CASE WHEN repetir_dias IS NULL THEN NOW() ELSE NULL END,
      vence_em = CASE WHEN repetir_dias IS NULL THEN vence_em ELSE CURRENT_DATE + repetir_dias END,
      lembrado_em = NULL
    WHERE id=$1 AND clinica_id=$2 RETURNING id`, [req.params.id, req.usuario.clinicaId]);
  if (!r.rows.length) return res.status(404).json({ erro: 'Obrigação não encontrada.' });
  cacheGuardiao.delete(req.usuario.clinicaId);
  res.json({ ok: true });
});
router.post('/guardiao/obrigacoes/:id/adiar', exigirAdmin, async (req, res) => {
  const dias = Math.min(Math.max(parseInt(req.body.dias, 10) || 7, 1), 365);
  const r = await pool.query(`UPDATE assistente_obrigacoes SET vence_em = GREATEST(vence_em, CURRENT_DATE) + $3::int, lembrado_em=NULL WHERE id=$1 AND clinica_id=$2 RETURNING id`, [req.params.id, req.usuario.clinicaId, dias]);
  if (!r.rows.length) return res.status(404).json({ erro: 'Obrigação não encontrada.' });
  cacheGuardiao.delete(req.usuario.clinicaId);
  res.json({ ok: true });
});
router.delete('/guardiao/obrigacoes/:id', exigirAdmin, async (req, res) => {
  await pool.query(`UPDATE assistente_obrigacoes SET ativo=FALSE WHERE id=$1 AND clinica_id=$2`, [req.params.id, req.usuario.clinicaId]);
  cacheGuardiao.delete(req.usuario.clinicaId);
  res.json({ ok: true });
});
router.get('/guardiao/historico', exigirAdmin, async (req, res) => {
  const r = await pool.query(`SELECT criado_em, erros, avisos FROM assistente_verificacoes WHERE clinica_id=$1 ORDER BY criado_em DESC LIMIT 28`, [req.usuario.clinicaId]);
  res.json(r.rows);
});

module.exports = router;
