/* Service worker do agendador offline: guarda a casca do app para abrir sem internet.
   Chamadas à API nunca passam por aqui e nunca são guardadas. */
const CACHE = 'agendador-casca-v12';
const CASCA = ['/agendador/', '/agendador/app.js', '/agendador/manifest.json', '/icone-192.png', '/icone-180.png', '/clinica.ico'];
self.addEventListener('install', (e) => { e.waitUntil(caches.open(CACHE).then((c) => Promise.all(CASCA.map((u) => c.add(u).catch(() => {})))).then(() => self.skipWaiting())); });
self.addEventListener('activate', (e) => { e.waitUntil(caches.keys().then((ks) => Promise.all(ks.filter((k) => k !== CACHE).map((k) => caches.delete(k)))).then(() => self.clients.claim())); });
self.addEventListener('fetch', (e) => {
  const r = e.request, u = new URL(r.url);
  if (r.method !== 'GET' || u.origin !== location.origin) return;
  const caminho = u.pathname === '/agendador' ? '/agendador/' : u.pathname;
  if (!CASCA.includes(caminho)) return;
  // tenta a versão nova; sem internet, usa a guardada
  e.respondWith(fetch(r).then((resp) => { if (resp.ok) { const copia = resp.clone(); caches.open(CACHE).then((c) => c.put(caminho, copia)); } return resp; }).catch(() => caches.match(caminho).then((c) => c || Response.error())));
});
