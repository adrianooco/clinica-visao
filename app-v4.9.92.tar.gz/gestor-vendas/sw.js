/* Service worker do gestor de vendas: guarda a casca do app para abrir sem internet.
   Chamadas à API nunca passam por aqui e nunca são guardadas. */
const CACHE = 'gestor-vendas-casca-v44';
const CASCA = ['/gestor-vendas/', '/gestor-vendas/sistema.html', '/gestor-vendas/manifest.json', '/gestor-vendas/icone-192.png', '/gestor-vendas/icone-180.png', '/gestor-vendas/mascote.png'];
self.addEventListener('install', (e) => { e.waitUntil(caches.open(CACHE).then((c) => Promise.all(CASCA.map((u) => c.add(u).catch(() => {})))).then(() => self.skipWaiting())); });
self.addEventListener('activate', (e) => { e.waitUntil(caches.keys().then((ks) => Promise.all(ks.filter((k) => k !== CACHE).map((k) => caches.delete(k)))).then(() => self.clients.claim())); });
self.addEventListener('fetch', (e) => {
  const r = e.request, u = new URL(r.url);
  if (r.method !== 'GET' || u.origin !== location.origin) return;
  const caminho = u.pathname === '/gestor-vendas' ? '/gestor-vendas/' : u.pathname;
  if (!CASCA.includes(caminho)) return;
  // tenta a versão nova; sem internet, usa a guardada
  e.respondWith(fetch(r).then((resp) => { if (resp.ok) { const copia = resp.clone(); caches.open(CACHE).then((c) => c.put(caminho, copia)); } return resp; }).catch(() => caches.match(caminho).then((c) => c || new Response('Sem internet e o app ainda não foi guardado neste aparelho.', { status: 503, headers: { 'Content-Type': 'text/plain; charset=utf-8' } }))));
});
