/* Assistente de textos com IA gratuita (Google Gemini) ou, se não houver, a chave da Anthropic.
   Serve só para texto geral (sem dados de paciente). A leitura de fotos continua em /leitura. */
const express = require('express');
const { exigirLogin } = require('../middleware/auth');

const router = express.Router();
router.use(exigirLogin);

const GEMINI_MODELO = process.env.GEMINI_MODEL || 'gemini-3.5-flash-lite';
const ANTHROPIC_MODELO = process.env.ANTHROPIC_MODEL || 'claude-haiku-4-5-20251001';

function provedor() {
  if (process.env.GEMINI_API_KEY) return 'gemini';
  if (process.env.ANTHROPIC_API_KEY) return 'anthropic';
  return null;
}

/* limite simples por usuário: 40 pedidos por hora, para ficar dentro da cota gratuita */
const usos = new Map();
function dentroDoLimite(id) {
  const agora = Date.now();
  const lista = (usos.get(id) || []).filter((t) => agora - t < 3600000);
  if (lista.length >= 40) { usos.set(id, lista); return false; }
  lista.push(agora); usos.set(id, lista); return true;
}

/* tira o que parece dado pessoal antes de enviar para fora */
function protegerTexto(t) {
  return String(t || '')
    .replace(/\b\d{3}\.?\d{3}\.?\d{3}-?\d{2}\b/g, '[CPF removido]')
    .replace(/[\w.+-]+@[\w-]+\.[\w.-]+/g, '[e-mail removido]')
    .replace(/(\+?55\s?)?\(?\d{2}\)?\s?9?\d{4}[-\s]?\d{4}\b/g, '[telefone removido]');
}

const SISTEMA = 'Você ajuda uma ótica e clínica de exame de vista no Brasil. Responda em português do Brasil, com frases curtas e simples, voz ativa, sem markdown, sem asteriscos, sem hashtags e sem travessões. Não invente dados clínicos. Não dê diagnóstico. Se o pedido for sobre saúde, diga que o profissional responsável decide.';

router.get('/status', (req, res) => {
  const p = provedor();
  res.json({ ligada: !!p, provedor: p, gratuita: p === 'gemini' });
});

router.post('/texto', async (req, res) => {
  const p = provedor();
  if (!p) return res.status(503).json({ erro: 'A IA não está ligada. Falta colocar a chave GEMINI_API_KEY no Render.', semIA: true });
  let pedido = String((req.body || {}).pedido || '').trim().slice(0, 1500);
  if (pedido.length < 4) return res.status(400).json({ erro: 'Escreva o que você quer.' });
  if (!dentroDoLimite(req.usuario.usuarioId)) return res.status(429).json({ erro: 'Muitos pedidos seguidos. Tente de novo mais tarde.' });
  pedido = protegerTexto(pedido);
  try {
    const ctl = new AbortController();
    const timer = setTimeout(() => ctl.abort(), 30000);
    let r, texto = '';
    if (p === 'gemini') {
      r = await fetch((process.env.GEMINI_API_BASE || 'https://generativelanguage.googleapis.com').replace(/\/$/, '') + '/v1beta/models/' + encodeURIComponent(GEMINI_MODELO) + ':generateContent', {
        method: 'POST', signal: ctl.signal,
        headers: { 'content-type': 'application/json', 'x-goog-api-key': process.env.GEMINI_API_KEY },
        body: JSON.stringify({
          systemInstruction: { parts: [{ text: SISTEMA }] },
          contents: [{ role: 'user', parts: [{ text: pedido }] }],
          generationConfig: { maxOutputTokens: 700, temperature: 0.5 },
        }),
      });
      clearTimeout(timer);
      if (!r.ok) { console.error('IA (Gemini) falhou:', r.status); return res.status(r.status === 429 ? 429 : 502).json({ erro: r.status === 429 ? 'O limite gratuito do dia acabou. Tente mais tarde.' : 'Não consegui responder agora. Tente de novo.' }); }
      const d = await r.json();
      texto = ((((d.candidates || [])[0] || {}).content || {}).parts || []).map((x) => x.text || '').join('');
    } else {
      r = await fetch((process.env.ANTHROPIC_API_BASE || 'https://api.anthropic.com').replace(/\/$/, '') + '/v1/messages', {
        method: 'POST', signal: ctl.signal,
        headers: { 'content-type': 'application/json', 'x-api-key': process.env.ANTHROPIC_API_KEY, 'anthropic-version': '2023-06-01' },
        body: JSON.stringify({ model: ANTHROPIC_MODELO, max_tokens: 700, system: SISTEMA, messages: [{ role: 'user', content: pedido }] }),
      });
      clearTimeout(timer);
      if (!r.ok) { console.error('IA (Anthropic) falhou:', r.status); return res.status(502).json({ erro: 'Não consegui responder agora. Tente de novo.' }); }
      const d = await r.json();
      texto = (d.content || []).map((c) => c.text || '').join('');
    }
    texto = texto.replace(/[*#]/g, '').replace(/\s+—\s+/g, ', ').replace(/—/g, ', ').trim();
    if (!texto) return res.status(502).json({ erro: 'A IA não devolveu texto. Tente de novo.' });
    res.json({ ok: true, texto, provedor: p });
  } catch (e) {
    console.error('IA erro:', e.message);
    res.status(502).json({ erro: 'Não consegui responder agora. Tente de novo.' });
  }
});

/* ---------- Conversa (texto ou voz): conhece o sistema e propõe correções do Guardião ---------- */
const fs = require('fs');
const path = require('path');
let FUNCOES_TXT = '';
try { FUNCOES_TXT = fs.readFileSync(path.join(__dirname, '..', 'data', 'funcoes.txt'), 'utf8'); } catch (e) { FUNCOES_TXT = ''; }

const MANUAL_BASE = `Sistema: Clínica de Visão, de exame de vista, usado pela Ótica Centro Oeste em várias cidades. Feito com Node, Postgres e hospedado no Render.
Papéis: administrador (Master, vê tudo), agendador (marca exames na cidade dele), profissional (faz receita, atestado e declaração), gestor.
Área Master (só o administrador): abas Guardião, Clínica, Agenda, Equipe, Segurança e Integrações.
O Guardião confere o sistema a cada 6 horas: obrigações (backup, teste de restauração, trocar senhas e chaves), segurança, backup, sistema e operação. Alguns itens têm botão de correção com um clique.
Variáveis que o administrador coloca no Render, em Environment: GEMINI_API_KEY (IA gratuita), SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS (e-mail), BACKUP_EMAIL_PARA, WA_TOKEN e WA_PHONE_ID (WhatsApp da Meta), CHAVE_CRIPTOGRAFIA (guardar uma cópia fora do sistema).
Limites desta IA: ela não vê dados de pacientes, não altera nada sozinha, e só dispara correção do Guardião quando o administrador confirma.`;

async function chamarIA(sistema, historico, json) {
  const p = provedor();
  const ctl = new AbortController();
  const timer = setTimeout(() => ctl.abort(), 40000);
  try {
    if (p === 'gemini') {
      const r = await fetch((process.env.GEMINI_API_BASE || 'https://generativelanguage.googleapis.com').replace(/\/$/, '') + '/v1beta/models/' + encodeURIComponent(GEMINI_MODELO) + ':generateContent', {
        method: 'POST', signal: ctl.signal,
        headers: { 'content-type': 'application/json', 'x-goog-api-key': process.env.GEMINI_API_KEY },
        body: JSON.stringify({
          systemInstruction: { parts: [{ text: sistema }] },
          contents: historico.map((m) => ({ role: m.papel === 'ia' ? 'model' : 'user', parts: [{ text: m.texto }] })),
          generationConfig: Object.assign({ maxOutputTokens: 900, temperature: 0.4 }, json ? { responseMimeType: 'application/json' } : {}),
        }),
      });
      if (!r.ok) { const e = new Error('http ' + r.status); e.status = r.status; throw e; }
      const d = await r.json();
      return ((((d.candidates || [])[0] || {}).content || {}).parts || []).map((x) => x.text || '').join('');
    }
    const r = await fetch((process.env.ANTHROPIC_API_BASE || 'https://api.anthropic.com').replace(/\/$/, '') + '/v1/messages', {
      method: 'POST', signal: ctl.signal,
      headers: { 'content-type': 'application/json', 'x-api-key': process.env.ANTHROPIC_API_KEY, 'anthropic-version': '2023-06-01' },
      body: JSON.stringify({ model: ANTHROPIC_MODELO, max_tokens: 900, system: sistema, messages: historico.map((m) => ({ role: m.papel === 'ia' ? 'assistant' : 'user', content: m.texto })) }),
    });
    if (!r.ok) { const e = new Error('http ' + r.status); e.status = r.status; throw e; }
    const d = await r.json();
    return (d.content || []).map((c) => c.text || '').join('');
  } finally { clearTimeout(timer); }
}

router.post('/conversa', async (req, res) => {
  if (!provedor()) return res.status(503).json({ erro: 'A IA não está ligada. Falta colocar a chave GEMINI_API_KEY no Render.', semIA: true });
  const bruto = Array.isArray((req.body || {}).mensagens) ? req.body.mensagens.slice(-10) : [];
  const historico = bruto.map((m) => ({ papel: m && m.papel === 'ia' ? 'ia' : 'eu', texto: protegerTexto(String((m && m.texto) || '').slice(0, 1200)) })).filter((m) => m.texto.trim());
  if (!historico.length || historico[historico.length - 1].papel !== 'eu') return res.status(400).json({ erro: 'Escreva ou fale algo.' });
  if (!dentroDoLimite(req.usuario.usuarioId)) return res.status(429).json({ erro: 'Muitos pedidos seguidos. Tente de novo mais tarde.' });
  const ehAdmin = req.usuario.papel === 'admin';
  let estado = 'Estado do Guardião: não disponível para este perfil.';
  const permitidas = new Map();
  if (ehAdmin) {
    try {
      const v = await require('../utils/guardiao').verificar(req.usuario.clinicaId);
      const itens = v.itens.filter((i) => i.nivel === 'erro' || i.nivel === 'aviso');
      estado = itens.length ? 'Itens do Guardião que precisam de atenção agora:\n' + itens.map((i) => {
        let a = '';
        if (i.acao && i.acao.tipo === 'corrigir') { permitidas.set(i.acao.id, i.acao.rotulo); a = ` [correção possível: id=${i.acao.id}, botão "${i.acao.rotulo}"]`; }
        else if (i.acao && i.acao.tipo === 'passos') a = ` [passos manuais: ${(i.acao.passos || []).join(' | ')}]`;
        else if (i.acao && i.acao.tipo === 'obrigacao') a = ' [obrigação: o administrador marca Já fiz ou Adiar na tela do Guardião]';
        else if (i.acao && i.acao.tipo === 'ir') a = ` [tela: ${i.acao.rotulo}]`;
        return `- (${i.nivel}) ${i.titulo}: ${protegerTexto(i.detalhe || '')}${a}`;
      }).join('\n') : 'Estado do Guardião: tudo em ordem, nenhum item precisa de atenção.';
    } catch (e) { estado = 'Estado do Guardião: não consegui ler agora.'; }
  }
  const sistema = SISTEMA + '\n\nVocê é o assistente de voz do administrador. Fale como numa conversa: respostas curtas, de 1 a 4 frases, fáceis de ouvir, sem listas e sem símbolos. Quando indicar onde clicar, diga a tela e a aba. Se a pergunta for sobre o sistema, use só o manual abaixo. Se não estiver no manual, diga que não sabe.\n' +
    'Se um item do Guardião tiver correção possível e o administrador pedir para arrumar, explique em uma frase o que será feito e pergunte se pode fazer. Nesse caso devolva o id da correção em acao_id. Nunca diga que já corrigiu: quem executa é o botão que o sistema mostra depois que ele confirmar. Para itens sem correção possível, explique os passos.\n' +
    'Responda SEMPRE só com um JSON neste formato: {"fala": string, "acao_id": string ou null}.\n\nMANUAL\n' + MANUAL_BASE + '\n\nFUNÇÕES DO SISTEMA\n' + FUNCOES_TXT + '\n\n' + estado;
  try {
    const texto = await chamarIA(sistema, historico, true);
    let fala = '', acao = null;
    const m = /\{[\s\S]*\}/.exec(texto);
    try { const j = JSON.parse(m ? m[0] : texto); fala = String(j.fala || ''); if (j.acao_id && permitidas.has(String(j.acao_id))) acao = { id: String(j.acao_id), rotulo: permitidas.get(String(j.acao_id)) }; }
    catch (e) { fala = texto; }
    fala = fala.replace(/[*#]/g, '').replace(/\s+—\s+/g, ', ').replace(/—/g, ', ').trim();
    if (!fala) return res.status(502).json({ erro: 'A IA não devolveu resposta. Tente de novo.' });
    res.json({ ok: true, fala, acao });
  } catch (e) {
    console.error('IA conversa erro:', e.message);
    res.status(e.status === 429 ? 429 : 502).json({ erro: e.status === 429 ? 'O limite gratuito do dia acabou. Tente mais tarde.' : 'Não consegui responder agora. Tente de novo.' });
  }
});

module.exports = router;
