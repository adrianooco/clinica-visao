/* Respostas dos pacientes no WhatsApp. A Meta chama este endereço quando alguém escreve para o número da clínica.
   "SIM" confirma o próximo agendamento, "NÃO" cancela. Qualquer outra frase recebe o contato humano. */
const express = require('express');
const crypto = require('crypto');
const pool = require('../db/pool');
const wpp = require('../utils/whatsapp');
const ia = require('../utils/iaAtendente');

const router = express.Router();

router.get('/webhook', (req, res) => {
  const ok = process.env.WA_VERIFY_TOKEN && req.query['hub.mode'] === 'subscribe' && req.query['hub.verify_token'] === process.env.WA_VERIFY_TOKEN;
  if (!ok) return res.sendStatus(403);
  res.status(200).send(String(req.query['hub.challenge'] || ''));
});

function assinaturaValida(req) {
  const segredo = process.env.WA_APP_SECRET;
  if (!segredo || !req.rawBody) return false;
  const esperado = 'sha256=' + crypto.createHmac('sha256', segredo).update(req.rawBody).digest('hex');
  const recebido = String(req.headers['x-hub-signature-256'] || '');
  if (esperado.length !== recebido.length) return false;
  return crypto.timingSafeEqual(Buffer.from(esperado), Buffer.from(recebido));
}

/* guarda a resposta de quem recebeu o "como está o óculos" (até 30 dias depois do envio) */
async function registrarRespostaOculos(clinicaId, fim, texto) {
  const r = await pool.query(
    `UPDATE vendas_oculos SET pos_resposta=$3, pos_resposta_em=NOW()
     WHERE id = (SELECT v.id FROM vendas_oculos v JOIN pacientes p ON p.id=v.paciente_id
                 WHERE v.clinica_id=$1 AND v.pos_enviado AND v.pos_enviado_em > NOW() - INTERVAL '30 days'
                   AND RIGHT(REGEXP_REPLACE(COALESCE(p.telefone,''),'\\D','','g'),10)=$2
                 ORDER BY v.pos_enviado_em DESC LIMIT 1) RETURNING id`, [clinicaId, fim, String(texto || '').slice(0, 500)]);
  return r.rows.length > 0;
}

/* ===== Ótica: atendente de IA (v4.9.24) ===== */
async function atendenteDoNumero(numero) {
  if (!numero) return null;
  const r = await pool.query(
    `SELECT a.*, c.nome_fantasia FROM atendente_config a JOIN clinicas c ON c.id=a.clinica_id
     WHERE c.ativa=TRUE AND RIGHT(REGEXP_REPLACE(COALESCE(a.numero_otica,''),'\\D','','g'),10)=$1 LIMIT 1`, [numero.slice(-10)]);
  return r.rows[0] || null;
}

const IA_POR_HORA = 30;
async function atenderOtica(cfg, m, contatos, phoneId) {
  const de = String(m.from || '').replace(/\D/g, '').slice(0, 20);
  if (!de) return;
  const nome = String((contatos || []).find((c) => c.wa_id === m.from)?.profile?.name || '').slice(0, 120) || null;
  let texto;
  if (m.type === 'text') texto = String(m.text?.body || '').slice(0, 4000);
  else if (m.type === 'button') texto = String(m.button?.text || '').slice(0, 500);
  else if (m.type === 'interactive') texto = String(m.interactive?.button_reply?.title || m.interactive?.list_reply?.title || '').slice(0, 500);
  else texto = `[${m.type === 'audio' ? 'áudio' : m.type === 'image' ? 'foto' : m.type === 'video' ? 'vídeo' : m.type === 'document' ? 'documento' : m.type === 'sticker' ? 'figurinha' : m.type}]`;
  if (!texto) return;
  // a Meta às vezes manda a mesma mensagem duas vezes: guarda uma só
  const ins = await pool.query(
    `INSERT INTO wa_mensagens (clinica_id, telefone, autor, texto, wa_id) VALUES ($1,$2,'cliente',$3,$4) ON CONFLICT (wa_id) WHERE wa_id IS NOT NULL DO NOTHING RETURNING id`,
    [cfg.clinica_id, de, texto, m.id ? String(m.id).slice(0, 120) : null]);
  if (!ins.rows.length) return;
  const conv = await pool.query(
    `INSERT INTO wa_conversas (clinica_id, telefone, nome, phone_id, nao_lidas, ultima_em) VALUES ($1,$2,$3,$4,1,NOW())
     ON CONFLICT (clinica_id, telefone) DO UPDATE SET nome=COALESCE(EXCLUDED.nome, wa_conversas.nome), phone_id=EXCLUDED.phone_id,
       nao_lidas=wa_conversas.nao_lidas+1, ultima_em=NOW()
     RETURNING equipe_ate`, [cfg.clinica_id, de, nome, phoneId || null]);
  // IA desligada ou a equipe assumiu a conversa: só guarda, a equipe responde pelo OCO
  if (!cfg.ativo || !ia.configurada()) return;
  const equipeAte = conv.rows[0]?.equipe_ate;
  if (equipeAte && new Date(equipeAte) > new Date()) return;
  const usos = await pool.query(`SELECT COUNT(*)::int n FROM wa_mensagens WHERE clinica_id=$1 AND telefone=$2 AND autor='ia' AND criado_em > NOW() - INTERVAL '1 hour'`, [cfg.clinica_id, de]);
  if (usos.rows[0].n >= IA_POR_HORA) return;
  let resposta, chamarEquipe = false;
  if (m.type !== 'text' && m.type !== 'button' && m.type !== 'interactive') {
    resposta = 'Recebi! Ainda não consigo abrir áudio, foto ou arquivo por aqui. Se puder, escreva sua dúvida. Já avisei a equipe para ver sua mensagem.';
    chamarEquipe = true;
  } else {
    const hist = await pool.query(
      `SELECT autor, texto FROM (SELECT autor, texto, criado_em FROM wa_mensagens WHERE clinica_id=$1 AND telefone=$2 ORDER BY criado_em DESC LIMIT 16) t ORDER BY criado_em`,
      [cfg.clinica_id, de]);
    try {
      ({ resposta, chamarEquipe } = await ia.responderCliente(cfg.clinica_id, hist.rows, cfg));
    } catch (e) {
      console.error('Atendente IA falhou:', e.message);
      resposta = 'Recebi sua mensagem. Já avisei a equipe e logo alguém responde por aqui.';
      chamarEquipe = true;
    }
  }
  try {
    await wpp.responder(de, resposta, phoneId);
    await pool.query(`INSERT INTO wa_mensagens (clinica_id, telefone, autor, texto) VALUES ($1,$2,'ia',$3)`, [cfg.clinica_id, de, resposta]);
  } catch (e) { console.error('Envio da resposta da IA falhou:', e.message); chamarEquipe = true; }
  if (chamarEquipe) await pool.query(`UPDATE wa_conversas SET precisa_equipe=TRUE WHERE clinica_id=$1 AND telefone=$2`, [cfg.clinica_id, de]);
}

/* ===== v4.9.79: Remarcar pelo WhatsApp =====
   O paciente responde 3. O sistema manda até 5 horários livres na mesma cidade, nos próximos 30 dias, com as letras A a E.
   Ele responde a letra e o exame muda para o horário novo, já confirmado. A oferta vale 24 horas. */
const LETRAS = ['a', 'b', 'c', 'd', 'e'];
const SEMANA = ['dom', 'seg', 'ter', 'qua', 'qui', 'sex', 'sáb'];
function rotuloHorario(dh) {
  const [d, h] = String(dh).replace(' ', 'T').split('T'); const [a, m, dia] = d.split('-');
  return `${SEMANA[new Date(d + 'T12:00:00Z').getUTCDay()]} ${dia}/${m} às ${String(h).slice(0, 5)}`;
}
async function oferecerRemarcar(cl, de, fim, agId) {
  const off = require('./agendadorOffline');
  const ag = (await pool.query(`SELECT id, unidade_id, data_hora FROM agendamentos WHERE id=$1`, [agId])).rows[0];
  const hoje = off.agoraBrasilia().slice(0, 10), limite = new Date(Date.now() - 3 * 3600e3 + 60 * 60e3).toISOString().slice(0, 16);
  const livres = (await off.horariosLivres({ clinicaId: cl.id }, hoje, off.somaDias(hoje, 30), ag.unidade_id))
    .filter((s) => s.unidade_id === ag.unidade_id && s.data_hora.slice(0, 16) > limite && s.data_hora.slice(0, 16) !== String(ag.data_hora).replace(' ', 'T').slice(0, 16));
  const porDia = {}, opcoes = [];
  for (const s of livres) { if (opcoes.length >= 5) break; porDia[s.data] = (porDia[s.data] || 0) + 1; if (porDia[s.data] <= 2) opcoes.push({ data_hora: s.data_hora.slice(0, 16), tipo: s.tipo_atendimento_id, local: s.local, duracao: s.duracao_min }); }
  if (!opcoes.length) { await wpp.responder(de, `Ainda não tem outra data aberta na sua cidade. Seu exame continua ${rotuloHorario(ag.data_hora)}. A equipe vai te chamar quando abrir agenda nova.`); return; }
  await pool.query(`INSERT INTO wa_remarcar (clinica_id, telefone_fim, agendamento_id, opcoes) VALUES ($1,$2,$3,$4)`, [cl.id, fim, ag.id, JSON.stringify(opcoes)]);
  await wpp.responder(de, `Escolha o novo horário e responda só a letra:\n${opcoes.map((o, i) => `${LETRAS[i].toUpperCase()}) ${rotuloHorario(o.data_hora)}`).join('\n')}\nSe quiser manter ${rotuloHorario(ag.data_hora)}, não precisa responder.`);
}
async function escolherRemarcar(cl, de, fim, letra) {
  const of = (await pool.query(`SELECT * FROM wa_remarcar WHERE clinica_id=$1 AND telefone_fim=$2 AND usado_em IS NULL AND criado_em > NOW() - INTERVAL '24 hours' ORDER BY criado_em DESC LIMIT 1`, [cl.id, fim])).rows[0];
  if (!of) return false;
  const o = (of.opcoes || [])[LETRAS.indexOf(letra)];
  if (!o) { await wpp.responder(de, 'Essa letra não está na lista. Responda uma das letras enviadas, ou 3 para ver os horários de novo.'); return true; }
  const ag = (await pool.query(`SELECT id, paciente_id, unidade_id, status FROM agendamentos WHERE id=$1 AND clinica_id=$2`, [of.agendamento_id, cl.id])).rows[0];
  if (!ag || !['agendado', 'confirmado'].includes(ag.status)) { await wpp.responder(de, 'Esse exame não está mais marcado. A equipe vai te chamar.'); return true; }
  const off = require('./agendadorOffline');
  const slot = await off.horarioDoEvento(cl.id, ag.unidade_id, o.data_hora);
  const mesmoDia = await pool.query(`SELECT 1 FROM agendamentos WHERE clinica_id=$1 AND paciente_id=$2 AND status <> 'cancelado' AND data_hora::date = $3::timestamp::date AND id <> $4 LIMIT 1`, [cl.id, ag.paciente_id, o.data_hora, ag.id]);
  if (!slot || mesmoDia.rows.length) { await wpp.responder(de, 'Esse horário não está mais livre. Responda 3 para ver outros.'); return true; }
  try {
    await pool.query(
      `UPDATE agendamentos SET data_hora=$1, tipo_atendimento_id=$2, duracao_min=$3, buffer_min=$4, local=COALESCE($5, local), status='confirmado',
         lembrete_confirmacao_enviado=TRUE, lembrete_24h_enviado=FALSE, lembrete_2h_enviado=FALSE, lembrete_pos_consulta_enviado=FALSE,
         observacoes=TRIM(COALESCE(observacoes,'') || ' Remarcado pelo paciente no WhatsApp em ' || to_char(NOW() AT TIME ZONE 'America/Sao_Paulo','DD/MM HH24:MI') || '.'), atualizado_em=NOW()
       WHERE id=$6`, [o.data_hora, slot.tipo_atendimento_id, slot.duracao_min, slot.buffer_min, slot.local || null, ag.id]);
  } catch (e) {
    if (e.code === '23P01') { await wpp.responder(de, 'Alguém marcou esse horário agora há pouco. Responda 3 para ver outros.'); return true; }
    throw e;
  }
  await pool.query(`UPDATE wa_remarcar SET usado_em=NOW() WHERE id=$1`, [of.id]);
  let senha = '';
  try {
    const { SQL_SENHA, regraDaClinica, textoRegra } = require('../utils/senha');
    const cfg = await regraDaClinica(cl.id);
    const s = (await pool.query(`SELECT ${SQL_SENHA('a')} AS senha, a.data_hora FROM agendamentos a WHERE a.id=$1`, [ag.id])).rows[0];
    if (cfg.ligada && s && s.senha) senha = textoRegra(String(s.data_hora), s.senha, cfg, true);
  } catch (e) { /* sem senha na mensagem */ }
  await wpp.responder(de, `Pronto! Seu exame mudou para ${rotuloHorario(o.data_hora)}${o.local ? `, em ${o.local}` : ''}.${senha} Esperamos você!`);
  return true;
}

const semAcento = (t) => String(t || '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().trim();

router.post('/webhook', async (req, res) => {
  if (!assinaturaValida(req)) return res.sendStatus(403);
  res.sendStatus(200); // responde logo; a Meta repete se demorar
  try {
    for (const entrada of req.body.entry || []) {
      for (const mudanca of entrada.changes || []) {
        const v = mudanca.value || {};
        const numeroClinica = String(v.metadata?.display_phone_number || '').replace(/\D/g, '');
        const phoneId = v.metadata?.phone_number_id;
        const otica = await atendenteDoNumero(numeroClinica);
        for (const m of v.messages || []) {
          if (otica) { await atenderOtica(otica, m, v.contacts, phoneId); continue; }
          if (m.type !== 'text') continue;
          const de = String(m.from || '').replace(/\D/g, '');
          const fim = de.slice(-10); // DDD + número, sem o 9 extra ou o 55
          const texto = semAcento(m.text?.body);
          let quer = /^(sim|s|confirmo|confirmado|ok)\b/.test(texto) ? 'confirmado' : /^(nao|n|cancelar|cancela)\b/.test(texto) ? 'cancelado' : null;
          /* v4.9.79: 1 confirma, 2 cancela, 3 remarca; a letra escolhe o novo horário */
          if (!quer) quer = /^1\b/.test(texto) ? 'confirmado' : /^2\b/.test(texto) ? 'cancelado' : /^(3|remarcar|remarca|mudar|trocar)\b/.test(texto) ? 'remarcar' : null;
          const clinica = await pool.query(
            `SELECT id, nome_fantasia, whatsapp_numero FROM clinicas WHERE ativa=TRUE AND RIGHT(REGEXP_REPLACE(COALESCE(whatsapp_numero,''),'\\D','','g'),10)=$1 LIMIT 1`,
            [numeroClinica.slice(-10)]);
          if (!clinica.rows.length) continue;
          const cl = clinica.rows[0];
          if (/^(sair|parar|stop|descadastrar|nao quero (mais )?receber)\b/.test(texto)) {
            await pool.query(
              `UPDATE pacientes SET aceita_promocao=FALSE WHERE clinica_id=$1 AND RIGHT(REGEXP_REPLACE(COALESCE(telefone,''),'\\D','','g'),10)=$2`, [cl.id, fim]);
            await wpp.responder(de, 'Pronto. Você não vai mais receber promoções e avisos de campanha. Continuamos falando sobre seus exames e óculos quando for preciso.');
            continue;
          }
          if (!quer && /^[a-e]$/.test(texto) && await escolherRemarcar(cl, de, fim, texto)) continue;
          if (!quer) {
            if (await registrarRespostaOculos(cl.id, fim, m.text?.body)) { await wpp.responder(de, 'Obrigado por contar! A equipe vai ler sua mensagem e, se precisar ajustar algo, entra em contato.'); continue; }
            await wpp.responder(de, `Olá! Aqui é a ${cl.nome_fantasia}. Sobre o seu exame, responda 1 para confirmar, 2 para cancelar ou 3 para remarcar. Outras dúvidas, a equipe responde em horário comercial.`);
            continue;
          }
          const ag = await pool.query(
            `SELECT a.id FROM agendamentos a JOIN pacientes p ON p.id=a.paciente_id
             WHERE a.clinica_id=$1 AND a.status IN ('agendado','confirmado') AND a.data_hora > (NOW() AT TIME ZONE 'America/Sao_Paulo')
               AND RIGHT(REGEXP_REPLACE(COALESCE(p.telefone,''),'\\D','','g'),10)=$2
             ORDER BY a.data_hora LIMIT 1`, [cl.id, fim]);
          if (!ag.rows.length) {
            if (await registrarRespostaOculos(cl.id, fim, m.text?.body)) { await wpp.responder(de, 'Obrigado por contar! A equipe vai ler sua mensagem e, se precisar ajustar algo, entra em contato.'); continue; }
            await wpp.responder(de, 'Não encontrei um exame marcado para este número. A equipe vai conferir e responder.'); continue;
          }
          if (quer === 'remarcar') { await oferecerRemarcar(cl, de, fim, ag.rows[0].id); continue; }
          await pool.query(`UPDATE agendamentos SET status=$1 WHERE id=$2`, [quer, ag.rows[0].id]);
          await wpp.responder(de, quer === 'confirmado' ? 'Exame confirmado. Esperamos você!' : 'Exame cancelado. Quando quiser marcar de novo, é só chamar.');
        }
      }
    }
  } catch (e) {
    console.error('Webhook do WhatsApp falhou:', e.message);
  }
});

router.registrarRespostaOculos = registrarRespostaOculos;
module.exports = router;
