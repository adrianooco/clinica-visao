const express = require('express');
const bcrypt = require('bcryptjs');
const pool = require('../db/pool');
const { gerarToken, exigirLogin } = require('../middleware/auth');
const { validarSenha } = require('../utils/senha');
const jwt = require('jsonwebtoken');
const { SEGREDO, exigirAdmin } = require('../middleware/auth');
const web = require('@simplewebauthn/server');
const { registrarDispositivo } = require('../utils/dispositivos');

const router = express.Router();

/* Trava de tentativas: 8 erros de senha em 15 minutos bloqueiam aquele e-mail naquele aparelho.
   Fica no banco, então continua valendo mesmo se o servidor reiniciar. */
const JANELA_MS = 15 * 60 * 1000, MAX_ERROS = 8;
const chaveTent = (req, email) => `${req.ip}|${String(email || '').toLowerCase().trim()}`;
async function bloqueado(chave) {
  const r = await pool.query(`SELECT erros FROM login_tentativas WHERE chave=$1 AND inicio > NOW() - INTERVAL '15 minutes'`, [chave]);
  return r.rows.length > 0 && r.rows[0].erros >= MAX_ERROS;
}
async function errou(chave) {
  await pool.query(
    `INSERT INTO login_tentativas (chave, inicio, erros) VALUES ($1, NOW(), 1)
     ON CONFLICT (chave) DO UPDATE SET erros = CASE WHEN login_tentativas.inicio > NOW() - INTERVAL '15 minutes' THEN login_tentativas.erros + 1 ELSE 1 END,
       inicio = CASE WHEN login_tentativas.inicio > NOW() - INTERVAL '15 minutes' THEN login_tentativas.inicio ELSE NOW() END`, [chave]);
}
const limparErros = (chave) => pool.query(`DELETE FROM login_tentativas WHERE chave=$1`, [chave]).catch(() => {});
setInterval(() => { pool.query(`DELETE FROM login_tentativas WHERE inicio < NOW() - INTERVAL '1 hour'`).catch(() => {}); }, 30 * 60 * 1000).unref();

/* Cria a clínica + o primeiro usuário admin. Usado uma única vez, na primeira configuração. */
router.post('/setup', async (req, res) => {
  const { slug, nomeClinica, nomeAdmin, email, senha } = req.body;
  if (!slug || !nomeClinica || !nomeAdmin || !email || !senha) {
    return res.status(400).json({ erro: 'Preencha slug, nome da clínica, nome do admin, e-mail e senha.' });
  }
  { const e = validarSenha(senha); if (e) return res.status(400).json({ erro: e }); }
  // no ar (produção), depois que a primeira clínica existe, ninguém de fora cria outra
  if (process.env.NODE_ENV === 'production' && process.env.LIBERAR_CADASTRO !== 'sim') {
    const n = await pool.query('SELECT COUNT(*)::int AS n FROM clinicas');
    if (n.rows[0].n > 0) return res.status(403).json({ erro: 'O cadastro de novas clínicas está fechado neste servidor. Entre com sua conta.' });
  }
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const clinica = await client.query(
      `INSERT INTO clinicas (slug, nome_fantasia) VALUES ($1,$2) RETURNING *`,
      [slug.toLowerCase().trim(), nomeClinica]
    );
    const senhaHash = await bcrypt.hash(senha, 10);
    const usuario = await client.query(
      `INSERT INTO usuarios (clinica_id, nome, email, senha_hash, papel)
       VALUES ($1,$2,$3,$4,'admin') RETURNING *`,
      [clinica.rows[0].id, nomeAdmin, email.toLowerCase().trim(), senhaHash]
    );
    await client.query(
      `INSERT INTO tipos_atendimento (clinica_id, nome, duracao_min, buffer_min, cor) VALUES
       ($1,'Exame de vista',30,10,'#1B5C5A'),
       ($1,'Retirada de receita',15,5,'#2D8C84'),
       ($1,'Ajuste de armação',15,5,'#E3A23D')`,
      [clinica.rows[0].id]
    );
    await client.query('COMMIT');
    const token = gerarToken(usuario.rows[0]);
    res.status(201).json({ token, clinica: clinica.rows[0] });
  } catch (e) {
    await client.query('ROLLBACK');
    if (e.code === '23505') return res.status(409).json({ erro: 'Esse slug ou e-mail já está em uso.' });
    console.error(e);
    res.status(500).json({ erro: 'Erro ao criar a clínica.' });
  } finally {
    client.release();
  }
});

router.post('/login', async (req, res) => {
  const { email, senha } = req.body;
  if (!email || !senha) return res.status(400).json({ erro: 'Informe e-mail e senha.' });
  const chave = chaveTent(req, email);
  if (await bloqueado(chave)) return res.status(429).json({ erro: 'Muitas tentativas erradas. Espere 15 minutos e tente de novo.' });
  try {
    const r = await pool.query(
      `SELECT u.*, c.nome_fantasia, c.slug FROM usuarios u
       JOIN clinicas c ON c.id = u.clinica_id
       WHERE u.email=$1 AND u.ativo=TRUE`,
      [email.toLowerCase().trim()]
    );
    if (!r.rows.length) { await errou(chave); return res.status(401).json({ erro: 'E-mail ou senha incorretos.' }); }
    const usuario = r.rows[0];
    const ok = await bcrypt.compare(senha, usuario.senha_hash);
    if (!ok) { await errou(chave); return res.status(401).json({ erro: 'E-mail ou senha incorretos.' }); }
    await limparErros(chave);
    // Master com digital/rosto cadastrado: a senha sozinha não basta, falta o segundo passo
    if (usuario.papel === 'admin') {
      const pk = await pool.query('SELECT 1 FROM passkeys WHERE usuario_id=$1 LIMIT 1', [usuario.id]);
      if (pk.rows.length) {
        const pendente = jwt.sign({ fin: 'segundo_passo', uid: usuario.id }, SEGREDO, { expiresIn: '5m' });
        return res.json({ etapa: 'biometria', pendente });
      }
    }
    // código de 6 números do celular, se a pessoa ativou
    if (usuario.totp_ativo) {
      const pendente = jwt.sign({ fin: 'totp', uid: usuario.id }, SEGREDO, { expiresIn: '5m' });
      return res.json({ etapa: 'totp', pendente });
    }
    registrarDispositivo(req, usuario);
    const token = gerarToken(usuario);
    res.json({ token, usuario: { id: usuario.id, email: usuario.email, nome: usuario.nome, papel: usuario.papel, clinica: usuario.nome_fantasia, slug: usuario.slug, unidadeId: usuario.unidade_id || null, permissoes: usuario.permissoes || [] } });
  } catch (e) {
    console.error(e);
    res.status(500).json({ erro: 'Erro ao entrar.' });
  }
});

/* Meu perfil: cada pessoa vê seus dados e troca a própria senha. */
/* encerra a sessão em todos os aparelhos (celular perdido, senha vazada) */
router.post('/sair-todos', exigirLogin, async (req, res) => {
  await pool.query(`UPDATE usuarios SET sessao_versao = sessao_versao + 1 WHERE id=$1`, [req.usuario.usuarioId]);
  require('../middleware/auth').limparCacheUsuario(req.usuario.usuarioId);
  res.json({ ok: true });
});

router.get('/eu', exigirLogin, async (req, res) => {
  const r = await pool.query(
    `SELECT u.nome, u.email, u.papel, u.registro_conselho, un.nome AS cidade FROM usuarios u LEFT JOIN unidades un ON un.id = u.unidade_id WHERE u.id=$1`,
    [req.usuario.usuarioId]);
  if (!r.rows.length) return res.status(404).json({ erro: 'Usuário não encontrado.' });
  res.json(r.rows[0]);
});

router.patch('/eu', exigirLogin, async (req, res) => {
  const { nome, senha_atual, nova_senha } = req.body;
  const r = await pool.query('SELECT * FROM usuarios WHERE id=$1', [req.usuario.usuarioId]);
  const u = r.rows[0];
  if (!u) return res.status(404).json({ erro: 'Usuário não encontrado.' });
  if (nome !== undefined && !String(nome).trim()) return res.status(400).json({ erro: 'O nome não pode ficar vazio.' });
  let hash = u.senha_hash;
  if (nova_senha) {
    { const e = validarSenha(nova_senha); if (e) return res.status(400).json({ erro: e }); }
    if (!senha_atual || !(await bcrypt.compare(senha_atual, u.senha_hash))) return res.status(400).json({ erro: 'A senha atual está errada.' });
    hash = await bcrypt.hash(nova_senha, 10);
  }
  await pool.query('UPDATE usuarios SET nome=$1, senha_hash=$2 WHERE id=$3', [nome !== undefined ? String(nome).trim() : u.nome, hash, u.id]);
  res.json({ ok: true, nome: nome !== undefined ? String(nome).trim() : u.nome });
});

/* ===================== ENTRADA POR DIGITAL OU ROSTO (passkey) =====================
   O celular confere a digital ou o rosto. O servidor guarda só a chave pública. */
function dadosSite(req) {
  const host = req.get('host');
  const proto = process.env.NODE_ENV === 'production' ? 'https' : req.protocol;
  return { rpID: process.env.WEBAUTHN_RP_ID || host.replace(/:\d+$/, ''), origin: process.env.WEBAUTHN_ORIGIN || `${proto}://${host}`, rpName: 'Clínica de Visão' };
}
const emB64 = (buf) => Buffer.from(buf).toString('base64url');
const deB64 = (txt) => Buffer.from(txt, 'base64url');
const estadoNovo = (dados) => jwt.sign(dados, SEGREDO, { expiresIn: '5m' });
function lerEstado(token, fin) {
  try { const d = jwt.verify(String(token || ''), SEGREDO); return d.fin === fin ? d : null; } catch (e) { return null; }
}
const limitePk = new Map();
function limitarPk(req, res) {
  const agora = Date.now(), t = limitePk.get(req.ip);
  if (!t || agora - t.inicio > 15 * 60 * 1000) { limitePk.set(req.ip, { inicio: agora, n: 1 }); return false; }
  t.n += 1;
  if (t.n > 40) { res.status(429).json({ erro: 'Muitas tentativas. Espere alguns minutos.' }); return true; }
  return false;
}
async function respostaDeEntrada(usuarioId, req) {
  const r = await pool.query(`SELECT u.*, c.nome_fantasia, c.slug FROM usuarios u JOIN clinicas c ON c.id=u.clinica_id WHERE u.id=$1 AND u.ativo=TRUE`, [usuarioId]);
  const u = r.rows[0];
  if (!u) return null;
  if (req) registrarDispositivo(req, u);
  return { token: gerarToken(u), usuario: { id: u.id, email: u.email, nome: u.nome, papel: u.papel, clinica: u.nome_fantasia, slug: u.slug, unidadeId: u.unidade_id || null, permissoes: u.permissoes || [] } };
}

/* Cadastrar a digital/rosto deste aparelho (precisa estar logado) */
router.post('/passkey/registrar/opcoes', exigirLogin, async (req, res) => {
  const { rpID, rpName } = dadosSite(req);
  const u = (await pool.query('SELECT id, email, nome FROM usuarios WHERE id=$1', [req.usuario.usuarioId])).rows[0];
  const ja = await pool.query('SELECT credential_id, transportes FROM passkeys WHERE usuario_id=$1', [u.id]);
  const options = await web.generateRegistrationOptions({
    rpName, rpID, userName: u.email, userDisplayName: u.nome, userID: new TextEncoder().encode(u.id),
    attestationType: 'none',
    excludeCredentials: ja.rows.map((p) => ({ id: p.credential_id, transports: p.transportes || undefined })),
    authenticatorSelection: { residentKey: 'required', userVerification: 'required' },
  });
  res.json({ options, estado: estadoNovo({ fin: 'reg', uid: u.id, challenge: options.challenge }) });
});

router.post('/passkey/registrar/verificar', exigirLogin, async (req, res) => {
  const { rpID, origin } = dadosSite(req);
  const est = lerEstado(req.body.estado, 'reg');
  if (!est || est.uid !== req.usuario.usuarioId) return res.status(400).json({ erro: 'O pedido expirou. Tente de novo.' });
  let v;
  try {
    v = await web.verifyRegistrationResponse({ response: req.body.resposta, expectedChallenge: est.challenge, expectedOrigin: origin, expectedRPID: rpID, requireUserVerification: true });
  } catch (e) { return res.status(400).json({ erro: 'Não consegui confirmar a digital ou o rosto. Tente de novo.' }); }
  if (!v.verified || !v.registrationInfo) return res.status(400).json({ erro: 'Não consegui confirmar a digital ou o rosto.' });
  const info = v.registrationInfo;
  const nome = String(req.body.nome_aparelho || '').slice(0, 120) || 'Este aparelho';
  try {
    await pool.query(`INSERT INTO passkeys (usuario_id, credential_id, public_key, contador, transportes, nome_aparelho) VALUES ($1,$2,$3,$4,$5,$6)`,
      [req.usuario.usuarioId, info.credentialID, emB64(info.credentialPublicKey), info.counter, JSON.stringify(req.body.resposta?.response?.transports || []), nome]);
  } catch (e) { if (e.code === '23505') return res.status(409).json({ erro: 'Este aparelho já está cadastrado.' }); throw e; }
  res.json({ ok: true });
});

router.get('/passkeys', exigirLogin, async (req, res) => {
  const r = await pool.query(`SELECT id, nome_aparelho, criado_em, ultimo_uso FROM passkeys WHERE usuario_id=$1 ORDER BY criado_em`, [req.usuario.usuarioId]);
  res.json(r.rows);
});

router.delete('/passkeys/:id', exigirLogin, async (req, res) => {
  await pool.query('DELETE FROM passkeys WHERE id=$1 AND usuario_id=$2', [req.params.id, req.usuario.usuarioId]);
  res.json({ ok: true });
});

/* O Master tira as chaves de um usuário (aparelho perdido) */
router.delete('/passkeys/usuario/:uid', exigirLogin, exigirAdmin, async (req, res) => {
  await pool.query(`DELETE FROM passkeys WHERE usuario_id IN (SELECT id FROM usuarios WHERE id=$1 AND clinica_id=$2)`, [req.params.uid, req.usuario.clinicaId]);
  res.json({ ok: true });
});

/* Entrar só com digital ou rosto (agendador e profissional). O Master também precisa da senha. */
router.post('/passkey/entrar/opcoes', async (req, res) => {
  if (limitarPk(req, res)) return;
  const { rpID } = dadosSite(req);
  const options = await web.generateAuthenticationOptions({ rpID, userVerification: 'required' });
  res.json({ options, estado: estadoNovo({ fin: 'ent', challenge: options.challenge }) });
});

async function conferirAssinatura(req, res, est, usuarioEsperado) {
  const { rpID, origin } = dadosSite(req);
  const resp = req.body.resposta;
  const pk = (await pool.query('SELECT * FROM passkeys WHERE credential_id=$1', [resp && resp.id])).rows[0];
  if (!pk || (usuarioEsperado && pk.usuario_id !== usuarioEsperado)) { res.status(401).json({ erro: 'Este aparelho não está cadastrado.' }); return null; }
  let v;
  try {
    v = await web.verifyAuthenticationResponse({
      response: resp, expectedChallenge: est.challenge, expectedOrigin: origin, expectedRPID: rpID, requireUserVerification: true,
      authenticator: { credentialID: pk.credential_id, credentialPublicKey: deB64(pk.public_key), counter: Number(pk.contador), transports: pk.transportes || undefined },
    });
  } catch (e) { res.status(401).json({ erro: 'Não consegui confirmar a digital ou o rosto.' }); return null; }
  if (!v.verified) { res.status(401).json({ erro: 'Não consegui confirmar a digital ou o rosto.' }); return null; }
  await pool.query('UPDATE passkeys SET contador=$1, ultimo_uso=NOW() WHERE id=$2', [v.authenticationInfo.newCounter, pk.id]);
  return pk;
}

router.post('/passkey/entrar/verificar', async (req, res) => {
  if (limitarPk(req, res)) return;
  const est = lerEstado(req.body.estado, 'ent');
  if (!est) return res.status(400).json({ erro: 'O pedido expirou. Tente de novo.' });
  const pk = await conferirAssinatura(req, res, est, null);
  if (!pk) return;
  const dono = (await pool.query('SELECT papel FROM usuarios WHERE id=$1 AND ativo=TRUE', [pk.usuario_id])).rows[0];
  if (!dono) return res.status(401).json({ erro: 'Usuário desativado.' });
  if (dono.papel === 'admin') return res.status(403).json({ erro: 'O Master entra com e-mail e senha, e depois confirma com a digital ou o rosto.' });
  res.json(await respostaDeEntrada(pk.usuario_id, req));
});

/* Segundo passo do Master: depois da senha, confirma com a digital ou o rosto */
router.post('/passkey/segundo/opcoes', async (req, res) => {
  if (limitarPk(req, res)) return;
  const p = lerEstado(req.body.pendente, 'segundo_passo');
  if (!p) return res.status(400).json({ erro: 'O pedido expirou. Entre com a senha de novo.' });
  const { rpID } = dadosSite(req);
  const lista = await pool.query('SELECT credential_id, transportes FROM passkeys WHERE usuario_id=$1', [p.uid]);
  const options = await web.generateAuthenticationOptions({ rpID, userVerification: 'required', allowCredentials: lista.rows.map((x) => ({ id: x.credential_id, transports: x.transportes || undefined })) });
  res.json({ options, estado: estadoNovo({ fin: 'seg', uid: p.uid, challenge: options.challenge }) });
});

router.post('/passkey/segundo/verificar', async (req, res) => {
  if (limitarPk(req, res)) return;
  const p = lerEstado(req.body.pendente, 'segundo_passo');
  const est = lerEstado(req.body.estado, 'seg');
  if (!p || !est || est.uid !== p.uid) return res.status(400).json({ erro: 'O pedido expirou. Entre com a senha de novo.' });
  const pk = await conferirAssinatura(req, res, est, p.uid);
  if (!pk) return;
  res.json(await respostaDeEntrada(p.uid, req));
});

router.respostaDeEntrada = respostaDeEntrada;
module.exports = router;
