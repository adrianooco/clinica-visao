const fs = require('fs');
const path = require('path');
const pool = require('./pool');

/* Banco novo e vazio (caso de quem coloca o sistema online): cria as tabelas sozinho. */
async function criarTabelasSeFaltar() {
  const r = await pool.query(`SELECT to_regclass('public.clinicas') AS t`);
  if (r.rows[0].t) return;
  const candidatos = [path.join(__dirname, 'schema-agendamento.sql'), path.join(__dirname, '..', '..', 'schema-agendamento.sql')];
  const arq = candidatos.find((c) => fs.existsSync(c));
  if (!arq) throw new Error('Arquivo schema-agendamento.sql não encontrado para criar o banco.');
  console.log('Banco vazio: criando as tabelas...');
  await pool.query(fs.readFileSync(arq, 'utf8'));
  console.log('Tabelas criadas.');
}

/* Ajustes pequenos de banco que rodam sempre que o servidor liga.
   Servem pra quem já tem o banco criado de uma versão anterior: cada comando
   só age se a coluna ainda não existir, então é seguro rodar várias vezes. */
async function migrar() {
  await criarTabelasSeFaltar();
  await pool.query(`ALTER TABLE pacientes ADD COLUMN IF NOT EXISTS data_nascimento DATE`);
  await pool.query(`ALTER TABLE pacientes ADD COLUMN IF NOT EXISTS dados_extras JSONB DEFAULT '{}'::jsonb`);
  // agenda do evento: dia + faixa de horário em que o agendador pode marcar pacientes
  await pool.query(`CREATE TABLE IF NOT EXISTS agendas (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    clinica_id UUID NOT NULL REFERENCES clinicas(id) ON DELETE CASCADE,
    unidade_id UUID NOT NULL REFERENCES unidades(id) ON DELETE CASCADE,
    data DATE NOT NULL,
    hora_inicio TIME NOT NULL,
    hora_fim TIME NOT NULL,
    tipo_atendimento_id UUID NOT NULL REFERENCES tipos_atendimento(id),
    local VARCHAR(255),
    ativa BOOLEAN DEFAULT TRUE,
    criado_em TIMESTAMP DEFAULT NOW()
  )`);
  await pool.query(`CREATE INDEX IF NOT EXISTS idx_agendas_unidade_data ON agendas(unidade_id, data) WHERE ativa`);
  await pool.query(`ALTER TABLE agendas ADD COLUMN IF NOT EXISTS buffer_min INTEGER`);
  await pool.query(`ALTER TABLE agendas ADD COLUMN IF NOT EXISTS almoco_inicio TIME`);
  await pool.query(`ALTER TABLE agendas ADD COLUMN IF NOT EXISTS almoco_fim TIME`);

  // o que cada agendador pode abrir (lista de chaves) e como imprimir os documentos
  await pool.query(`ALTER TABLE usuarios ADD COLUMN IF NOT EXISTS permissoes JSONB DEFAULT '[]'::jsonb`);
  await pool.query(`ALTER TABLE clinicas ADD COLUMN IF NOT EXISTS config_impressao JSONB DEFAULT '{}'::jsonb`);

  // cadastros de apoio
  await pool.query(`CREATE TABLE IF NOT EXISTS oticas_parceiras (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    clinica_id UUID NOT NULL REFERENCES clinicas(id) ON DELETE CASCADE,
    nome VARCHAR(150) NOT NULL, ativa BOOLEAN DEFAULT TRUE, criado_em TIMESTAMP DEFAULT NOW())`);
  await pool.query(`CREATE TABLE IF NOT EXISTS convenios (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    clinica_id UUID NOT NULL REFERENCES clinicas(id) ON DELETE CASCADE,
    nome VARCHAR(150) NOT NULL, ativo BOOLEAN DEFAULT TRUE, criado_em TIMESTAMP DEFAULT NOW())`);

  // de onde veio o agendamento e qual ótica parceira indicou
  await pool.query(`ALTER TABLE agendamentos ADD COLUMN IF NOT EXISTS origem VARCHAR(20) DEFAULT 'equipe'`);
  await pool.query(`ALTER TABLE agendamentos ADD COLUMN IF NOT EXISTS otica_parceira_id UUID REFERENCES oticas_parceiras(id) ON DELETE SET NULL`);

  // preço padrão de cada tipo de atendimento (já vem preenchido na cobrança)
  await pool.query(`ALTER TABLE tipos_atendimento ADD COLUMN IF NOT EXISTS preco_padrao NUMERIC(10,2)`);

  // financeiro
  await pool.query(`CREATE TABLE IF NOT EXISTS pagamentos (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    clinica_id UUID NOT NULL REFERENCES clinicas(id) ON DELETE CASCADE,
    agendamento_id UUID NOT NULL UNIQUE REFERENCES agendamentos(id) ON DELETE CASCADE,
    valor NUMERIC(10,2) NOT NULL CHECK (valor >= 0),
    forma VARCHAR(20),
    convenio_id UUID REFERENCES convenios(id) ON DELETE SET NULL,
    status VARCHAR(10) NOT NULL DEFAULT 'pendente' CHECK (status IN ('pendente','pago')),
    pago_em DATE,
    criado_em TIMESTAMP DEFAULT NOW())`);
  await pool.query(`CREATE TABLE IF NOT EXISTS contas_pagar (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    clinica_id UUID NOT NULL REFERENCES clinicas(id) ON DELETE CASCADE,
    descricao VARCHAR(200) NOT NULL,
    valor NUMERIC(10,2) NOT NULL CHECK (valor >= 0),
    vencimento DATE NOT NULL,
    pago BOOLEAN DEFAULT FALSE,
    pago_em DATE,
    criado_em TIMESTAMP DEFAULT NOW())`);

  // registro de quem abriu ou alterou dado de saúde (LGPD)
  await pool.query(`CREATE TABLE IF NOT EXISTS acessos_log (
    id BIGSERIAL PRIMARY KEY,
    clinica_id UUID NOT NULL REFERENCES clinicas(id) ON DELETE CASCADE,
    usuario_id UUID, usuario_nome VARCHAR(150),
    acao VARCHAR(10), area VARCHAR(30), caminho VARCHAR(200), ip VARCHAR(60),
    criado_em TIMESTAMP DEFAULT NOW())`);
  await pool.query(`CREATE INDEX IF NOT EXISTS idx_acessos_log ON acessos_log(clinica_id, criado_em DESC)`);

  // WhatsApp automático e número da clínica
  await pool.query(`ALTER TABLE clinicas ADD COLUMN IF NOT EXISTS whatsapp_numero VARCHAR(20)`);
  await pool.query(`ALTER TABLE clinicas ADD COLUMN IF NOT EXISTS whatsapp_auto BOOLEAN DEFAULT FALSE`);
  await pool.query(`ALTER TABLE agendamentos ADD COLUMN IF NOT EXISTS whatsapp_ultimo_erro VARCHAR(200)`);
  // v4.0: segurança, lista de espera, licença
  await pool.query(`ALTER TABLE usuarios ADD COLUMN IF NOT EXISTS totp_segredo TEXT`);
  await pool.query(`ALTER TABLE usuarios ADD COLUMN IF NOT EXISTS totp_ativo BOOLEAN NOT NULL DEFAULT FALSE`);
  await pool.query(`ALTER TABLE usuarios ADD COLUMN IF NOT EXISTS totp_ultimo_passo BIGINT NOT NULL DEFAULT 0`);
  await pool.query(`CREATE TABLE IF NOT EXISTS redefinicoes_senha (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    usuario_id UUID NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE,
    token_hash TEXT NOT NULL UNIQUE,
    expira_em TIMESTAMPTZ NOT NULL,
    usado_em TIMESTAMPTZ,
    criado_em TIMESTAMPTZ DEFAULT NOW())`);
  await pool.query(`CREATE TABLE IF NOT EXISTS dispositivos_login (
    usuario_id UUID NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE,
    hash TEXT NOT NULL,
    agente TEXT,
    primeiro_em TIMESTAMPTZ DEFAULT NOW(),
    visto_em TIMESTAMPTZ DEFAULT NOW(),
    PRIMARY KEY (usuario_id, hash))`);
  await pool.query(`ALTER TABLE clinicas ADD COLUMN IF NOT EXISTS licenca TEXT`);
  await pool.query(`CREATE TABLE IF NOT EXISTS lista_espera (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    clinica_id UUID NOT NULL REFERENCES clinicas(id) ON DELETE CASCADE,
    unidade_id UUID REFERENCES unidades(id) ON DELETE CASCADE,
    nome VARCHAR(150) NOT NULL,
    telefone VARCHAR(30),
    observacao VARCHAR(300),
    resolvido_em TIMESTAMP,
    criado_em TIMESTAMP DEFAULT NOW())`);
  // diagnóstico (CID) passa a caber embaralhado
  await pool.query(`DO $$ BEGIN
    IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='receitas' AND column_name='cid_codigo' AND data_type='character varying') THEN
      ALTER TABLE receitas ALTER COLUMN cid_codigo TYPE TEXT;
      ALTER TABLE receitas ALTER COLUMN cid_descricao TYPE TEXT;
    END IF; END $$`);
  await pool.query(`ALTER TABLE agendamentos ADD COLUMN IF NOT EXISTS chegou_em TIMESTAMP`);
  await pool.query(`ALTER TABLE agendamentos ADD COLUMN IF NOT EXISTS inicio_atendimento_em TIMESTAMP`);
  await pool.query(`CREATE TABLE IF NOT EXISTS feriados_locais (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    clinica_id UUID NOT NULL REFERENCES clinicas(id) ON DELETE CASCADE,
    unidade_id UUID REFERENCES unidades(id) ON DELETE CASCADE,
    data DATE NOT NULL,
    nome VARCHAR(100) NOT NULL,
    criado_em TIMESTAMP DEFAULT NOW())`);
  await pool.query(`CREATE UNIQUE INDEX IF NOT EXISTS ux_feriados_locais ON feriados_locais (clinica_id, COALESCE(unidade_id, '00000000-0000-0000-0000-000000000000'::uuid), data)`);
  await pool.query(`ALTER TABLE usuarios ADD COLUMN IF NOT EXISTS sessao_versao INTEGER NOT NULL DEFAULT 0`);
  await pool.query(`CREATE TABLE IF NOT EXISTS login_tentativas (chave TEXT PRIMARY KEY, inicio TIMESTAMPTZ NOT NULL DEFAULT NOW(), erros INTEGER NOT NULL DEFAULT 0)`);
  await pool.query(`ALTER TABLE prontuarios ADD COLUMN IF NOT EXISTS refracao JSONB`);
  await pool.query(`ALTER TABLE prontuarios ADD COLUMN IF NOT EXISTS exame JSONB`);
  await pool.query(`ALTER TABLE prontuarios ADD COLUMN IF NOT EXISTS fechado_em TIMESTAMP`);
  await pool.query(`CREATE TABLE IF NOT EXISTS prontuario_versoes (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    prontuario_id UUID NOT NULL REFERENCES prontuarios(id) ON DELETE CASCADE,
    usuario_id UUID, usuario_nome VARCHAR(150), motivo TEXT, snapshot JSONB,
    criado_em TIMESTAMP DEFAULT NOW())`);
  // duração própria da agenda (vazio = usa a duração do tipo de atendimento)
  await pool.query(`ALTER TABLE agendas ADD COLUMN IF NOT EXISTS duracao_min INTEGER`);
  // chaves de acesso por digital ou rosto (passkeys): o celular guarda a biometria, aqui fica só a chave pública
  await pool.query(`CREATE TABLE IF NOT EXISTS passkeys (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    usuario_id UUID NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE,
    credential_id TEXT NOT NULL UNIQUE,
    public_key TEXT NOT NULL,
    contador BIGINT NOT NULL DEFAULT 0,
    transportes JSONB,
    nome_aparelho VARCHAR(120),
    criado_em TIMESTAMP DEFAULT NOW(),
    ultimo_uso TIMESTAMP)`);
}

module.exports = migrar;
