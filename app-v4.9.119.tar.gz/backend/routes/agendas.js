const express = require('express');
const { rotulo, cidade: cidadeSql } = require('../utils/rotulo');
const pool = require('../db/pool');
const cripto = require('../utils/cripto');
const { exigirLogin, exigirAdmin } = require('../middleware/auth');

const router = express.Router();
router.use(exigirLogin);

const FORMATO_HORA = /^\d{2}:\d{2}(:\d{2})?$/;
const FORMATO_DIA = /^\d{4}-\d{2}-\d{2}$/;
const dois = (n) => String(n).padStart(2, '0');
const minParaHora = (m) => `${dois(Math.floor(m / 60))}:${dois(m % 60)}`;
const { gerarSlots, bufferEfetivo, horaParaMin } = require('../utils/horarios');

/* Horários livres e ocupados das agendas de evento.
   Agendador (atendente) só enxerga a cidade dele. Admin e profissional podem filtrar por ?unidade_id. */
router.get('/horarios', async (req, res) => {
  const { de, ate } = req.query;
  const params = [req.usuario.clinicaId, de || null, ate || null];
  let filtro = '';
  const pedida = req.query.unidade_id ? String(req.query.unidade_id) : null;
  const cidadesFiltro = req.usuario.unidadeId ? (pedida && req.usuario.unidadeIds.includes(pedida) ? [pedida] : req.usuario.unidadeIds) : (pedida ? [pedida] : null);
  if (cidadesFiltro) { params.push(cidadesFiltro); filtro = ` AND a.unidade_id=ANY($4)`; }

  const ags = await pool.query(
    `SELECT a.id, a.unidade_id, a.data, a.hora_inicio, a.hora_fim, a.local, a.tipo_atendimento_id, a.almoco_inicio, a.almoco_fim,
            t.nome AS tipo_nome, t.cor AS tipo_cor, COALESCE(a.duracao_min, t.duracao_min) AS duracao_efetiva, t.buffer_min AS buffer_tipo, a.buffer_min AS buffer_agenda
     FROM agendas a JOIN tipos_atendimento t ON t.id = a.tipo_atendimento_id
     WHERE a.clinica_id=$1 AND a.ativa=TRUE
       AND ($2::date IS NULL OR a.data >= $2) AND ($3::date IS NULL OR a.data <= $3)${filtro}
     ORDER BY a.data, a.hora_inicio`,
    params
  );
  if (!ags.rows.length) return res.json([]);

  const unidades = [...new Set(ags.rows.map((a) => a.unidade_id))];
  const menorData = ags.rows[0].data, maiorData = ags.rows[ags.rows.length - 1].data;
  const ocup = await pool.query(
    `SELECT ag.id, ag.unidade_id, ag.data_hora, ag.status, ag.paciente_id, p.nome_completo AS paciente_nome, p.telefone AS paciente_telefone
     FROM agendamentos ag JOIN pacientes p ON p.id = ag.paciente_id
     WHERE ag.clinica_id=$1 AND ag.status <> 'cancelado' AND ag.unidade_id = ANY($2::uuid[])
       AND ag.data_hora::date BETWEEN $3 AND $4`,
    [req.usuario.clinicaId, unidades, menorData, maiorData]
  );
  const mapa = new Map(ocup.rows.map((o) => [`${o.unidade_id}|${String(o.data_hora).slice(0, 16)}`, o]));

  const saida = [];
  for (const a of ags.rows) {
    for (const sl of gerarSlots(a)) {
      const hora = minParaHora(sl.min);
      const data_hora = `${a.data}T${hora}:00`;
      const o = mapa.get(`${a.unidade_id}|${a.data}T${hora}`);
      saida.push({
        agenda_id: a.id, unidade_id: a.unidade_id, data: a.data, hora, data_hora,
        tipo_atendimento_id: a.tipo_atendimento_id, tipo_nome: a.tipo_nome, tipo_cor: a.tipo_cor, local: a.local, buffer_min: sl.buffer, duracao_min: Number(a.duracao_efetiva),
        agendamento: o ? { id: o.id, status: o.status, paciente_id: o.paciente_id, paciente_nome: o.paciente_nome, telefone: o.paciente_telefone || null } : null,
      });
    }
  }
  res.json(saida);
});

/* lista das agendas criadas (admin e profissional), com contagem de ocupação */
router.get('/', async (req, res) => {
  if (req.usuario.papel === 'atendente') return res.status(403).json({ erro: 'Seu acesso não permite abrir essa parte do sistema.' });
  const r = await pool.query(
    `SELECT a.*, ${rotulo('u')} AS unidade_nome, t.nome AS tipo_nome, t.duracao_min AS duracao_tipo, COALESCE(a.duracao_min, t.duracao_min) AS duracao_efetiva, t.buffer_min AS buffer_tipo, a.buffer_min AS buffer_agenda
     FROM agendas a JOIN unidades u ON u.id = a.unidade_id JOIN tipos_atendimento t ON t.id = a.tipo_atendimento_id
     WHERE a.clinica_id=$1 AND a.ativa=TRUE ORDER BY a.data DESC, a.hora_inicio`,
    [req.usuario.clinicaId]
  );
  res.json(r.rows.map((a) => ({
    ...a,
    buffer_efetivo: bufferEfetivo(a),
    total_horarios: gerarSlots(a).length,
  })));
});

/* Confere os campos que o POST e o PUT têm em comum. Devolve { erro } ou os valores limpos. */
function lerCamposAgenda(b) {
  const bufRaw = b.buffer_min;
  const buf = bufRaw === undefined || bufRaw === null || bufRaw === '' ? null : parseInt(bufRaw, 10);
  if (buf !== null && (isNaN(buf) || buf < 0 || buf > 120)) return { erro: 'Intervalo entre exames inválido.' };
  const durRaw = b.duracao_min;
  const dur = durRaw === undefined || durRaw === null || durRaw === '' ? null : parseInt(durRaw, 10);
  if (dur !== null && (isNaN(dur) || dur < 5 || dur > 180)) return { erro: 'A duração de cada exame precisa ficar entre 5 e 180 minutos.' };
  const alI = b.almoco_inicio || null, alF = b.almoco_fim || null;
  if ((alI && !alF) || (!alI && alF)) return { erro: 'Informe o início e o fim do almoço.' };
  if (alI && (!FORMATO_HORA.test(String(alI)) || !FORMATO_HORA.test(String(alF)) || horaParaMin(alF) <= horaParaMin(alI))) return { erro: 'O fim do almoço precisa ser depois do início.' };
  return { buf, dur, alI, alF };
}

/* Só o admin define a data e os horários do exame de vista. Pode criar vários dias de uma vez (data_fim). */

/* ===== v4.9.76: pacientes de cada dia da agenda e entrega dos óculos =====
   O Master vê quem foi marcado em cada dia, edita a ficha e lança o prontuário depois (com a data do exame).
   Em cada dia, o Master põe o dia, a hora e o local da entrega dos óculos; ele e os agendadores da cidade avisam pelo WhatsApp. */
const ocoCompras = require('../utils/ocoCompras');
const UUID_AG = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const diaIso = (d) => (d instanceof Date ? d.toISOString() : String(d || '')).slice(0, 10);
async function agendaPermitida(req, id) {
  if (!UUID_AG.test(String(id))) return null;
  const r = await pool.query(`SELECT a.*, ${rotulo('u')} AS unidade_nome, ${cidadeSql('u')} AS cidade_nome, u.local AS unidade_local FROM agendas a JOIN unidades u ON u.id=a.unidade_id WHERE a.id=$1 AND a.clinica_id=$2`, [id, req.usuario.clinicaId]);
  const a = r.rows[0]; if (!a) return null;
  if (req.usuario.papel === 'gestor') return null;
  if (req.usuario.unidadeId && Array.isArray(req.usuario.unidadeIds) && req.usuario.unidadeIds.length && !req.usuario.unidadeIds.includes(String(a.unidade_id))) return null;
  return a;
}
/* duração e intervalo efetivos de um dia da agenda, para gerar os horários */
async function configDaAgenda(a) {
  const t = await pool.query(`SELECT duracao_min, buffer_min FROM tipos_atendimento WHERE id=$1`, [a.tipo_atendimento_id]);
  const tp = t.rows[0] || { duracao_min: 20, buffer_min: 0 };
  return { hora_inicio: a.hora_inicio, hora_fim: a.hora_fim, almoco_inicio: a.almoco_inicio, almoco_fim: a.almoco_fim,
    duracao_efetiva: a.duracao_min || tp.duracao_min, buffer_agenda: a.buffer_min, buffer_tipo: tp.buffer_min };
}
/* ===== v4.9.113: passar as agendas futuras para 20 em 20 minutos (sem intervalo) e até as 18h =====
   Quem já está marcado vai para o horário novo mais perto do antigo (no máximo 10 minutos de diferença na maioria).
   O horário antigo fica guardado para o agendador avisar o paciente pelo WhatsApp. */
const VINTE_FIM = '18:00';
/* v4.9.119: dur = minutos de cada exame na grade nova (ex.: 15 para 4 por hora). Sem dur, mantém a duração do dia. */
async function planoVinte(a, dur) {
  const cfg = await configDaAgenda(a);
  const fimNovo = horaParaMin(String(cfg.hora_fim).slice(0, 5)) < horaParaMin(VINTE_FIM) ? VINTE_FIM : String(cfg.hora_fim).slice(0, 5);
  const novoCfg = { ...cfg, buffer_agenda: 0, hora_fim: fimNovo, ...(dur ? { duracao_efetiva: dur } : {}) };
  const novos = gerarSlots(novoCfg).map((x) => x.min);
  const dia = diaIso(a.data);
  const ags = await pool.query(`SELECT g.id, g.status, to_char(g.data_hora,'HH24:MI') AS hora, p.nome_completo AS nome, p.telefone
      FROM agendamentos g JOIN pacientes p ON p.id = g.paciente_id
      WHERE g.clinica_id=$1 AND g.unidade_id=$2 AND g.data_hora::date=$3::date AND g.status<>'cancelado' ORDER BY g.data_hora`, [a.clinica_id, a.unidade_id, dia]);
  const usados = new Set(), lista = [];
  let minimo = -1, falta = 0;
  for (const g of ags.rows) {
    const m = horaParaMin(g.hora);
    let melhor = null;
    for (const n of novos) { if (n <= minimo || usados.has(n)) continue; if (melhor === null || Math.abs(n - m) < Math.abs(melhor - m)) melhor = n; }
    if (melhor === null) { falta += 1; continue; }
    usados.add(melhor); minimo = melhor;
    lista.push({ agendamento_id: g.id, nome: g.nome, telefone: g.telefone, de: g.hora, para: minParaHora(melhor), muda: minParaHora(melhor) !== g.hora });
  }
  return { agenda_id: a.id, data: dia, unidade_id: a.unidade_id, unidade_nome: a.unidade_nome, hora_inicio: String(cfg.hora_inicio).slice(0, 5),
    hora_fim_antes: String(cfg.hora_fim).slice(0, 5), hora_fim: fimNovo, horarios_antes: gerarSlots(cfg).length, horarios_depois: novos.length,
    marcados: ags.rows.length, mudam: lista.filter((x) => x.muda).length, lista, falta, dur_antes: Number(cfg.duracao_efetiva), dur: Number(novoCfg.duracao_efetiva) };
}
async function agendasParaVinte(req, dur) {
  const r = await pool.query(`SELECT a.*, ${rotulo('u')} AS unidade_nome FROM agendas a JOIN unidades u ON u.id=a.unidade_id
      LEFT JOIN tipos_atendimento t ON t.id=a.tipo_atendimento_id
      WHERE a.clinica_id=$1 AND a.ativa=TRUE AND a.data > (now() AT TIME ZONE 'America/Sao_Paulo')::date
        AND (COALESCE(a.buffer_min, t.buffer_min, 0) > 0 OR a.hora_fim < $2::time OR ($3::int IS NOT NULL AND COALESCE(a.duracao_min, t.duracao_min) <> $3::int)) ORDER BY a.data, a.hora_inicio`, [req.usuario.clinicaId, VINTE_FIM, dur || null]);
  return r.rows;
}
const durPedida = (v) => { const n = parseInt(v, 10); return n >= 10 && n <= 60 ? n : null; };
router.get('/vinte/previa', exigirAdmin, async (req, res) => {
  const dias = [], dur = durPedida(req.query.min);
  for (const a of await agendasParaVinte(req, dur)) dias.push(await planoVinte(a, dur));
  res.setHeader('Cache-Control', 'no-store');
  res.json({ fim: VINTE_FIM, dur, dias });
});
router.post('/vinte/aplicar', exigirAdmin, async (req, res) => {
  const so = Array.isArray((req.body || {}).agendas) ? req.body.agendas.map(String) : null;
  const dur = durPedida((req.body || {}).minutos);
  const c = await pool.connect();
  const feitos = [];
  try {
    await c.query('BEGIN');
    for (const a of await agendasParaVinte(req, dur)) {
      if (so && !so.includes(String(a.id))) continue;
      const p = await planoVinte(a, dur);
      if (p.falta) { await c.query('ROLLBACK'); return res.status(400).json({ erro: `Dia ${p.data} tem mais marcados que horários. Nada foi mudado.` }); }
      await c.query(`UPDATE agendas SET buffer_min=0, hora_fim=$1::time, duracao_min=COALESCE($4::int, duracao_min) WHERE id=$2 AND clinica_id=$3`, [p.hora_fim, a.id, req.usuario.clinicaId, dur]);
      const ids = p.lista.map((x) => x.agendamento_id);
      if (ids.length) {
        /* afasta os horários antes de pôr nos novos, para um não esbarrar no outro no meio da troca */
        await c.query(`UPDATE agendamentos SET buffer_min=0, duracao_min=COALESCE($3::int, duracao_min), data_hora = data_hora + interval '500 years' WHERE id = ANY($1::uuid[]) AND clinica_id=$2`, [ids, req.usuario.clinicaId, dur]);
        for (const x of p.lista) {
          await c.query(`UPDATE agendamentos SET data_hora = ($1::date + $2::time),
              horario_anterior = CASE WHEN $4 THEN COALESCE(horario_anterior, ($1::date + $3::time)) ELSE horario_anterior END,
              horario_mudado_em = CASE WHEN $4 THEN now() ELSE horario_mudado_em END,
              mudanca_avisada_em = CASE WHEN $4 THEN NULL ELSE mudanca_avisada_em END
            WHERE id=$5 AND clinica_id=$6`, [p.data, x.para, x.de, x.muda, x.agendamento_id, req.usuario.clinicaId]);
        }
      }
      feitos.push({ data: p.data, unidade_nome: p.unidade_nome, mudam: p.mudam, horarios_depois: p.horarios_depois });
    }
    if ((req.body || {}).padrao !== false) await c.query(`UPDATE tipos_atendimento SET buffer_min=0 WHERE clinica_id=$1 AND buffer_min > 0`, [req.usuario.clinicaId]);
    await c.query('COMMIT');
  } catch (e) {
    await c.query('ROLLBACK').catch(() => {});
    return res.status(400).json({ erro: 'Não consegui passar a agenda para 20 minutos. Nada foi mudado. ' + (e.message || '') });
  } finally { c.release(); }
  res.json({ ok: true, dias: feitos, mudam: feitos.reduce((s, x) => s + x.mudam, 0) });
});
/* pacientes que mudaram de horário e ainda não foram avisados (Master e agendador da cidade) */
router.get('/mudancas', async (req, res) => {
  if (!['admin', 'atendente'].includes(req.usuario.papel)) return res.status(403).json({ erro: 'Seu acesso não permite abrir essa parte do sistema.' });
  const params = [req.usuario.clinicaId];
  let f = '';
  if (req.usuario.unidadeId && Array.isArray(req.usuario.unidadeIds) && req.usuario.unidadeIds.length) { params.push(req.usuario.unidadeIds); f = ` AND g.unidade_id = ANY($2)`; }
  const r = await pool.query(`SELECT g.id, to_char(g.data_hora,'YYYY-MM-DD') AS data, to_char(g.data_hora,'HH24:MI') AS hora, to_char(g.horario_anterior,'HH24:MI') AS hora_antes,
      g.mudanca_avisada_em, g.mudanca_avisada_por, p.nome_completo AS nome, p.telefone, ${rotulo('u')} AS unidade_nome, g.local
    FROM agendamentos g JOIN pacientes p ON p.id=g.paciente_id LEFT JOIN unidades u ON u.id=g.unidade_id
    WHERE g.clinica_id=$1 AND g.horario_anterior IS NOT NULL AND g.status IN ('agendado','confirmado')
      AND g.data_hora::date >= (now() AT TIME ZONE 'America/Sao_Paulo')::date${f}
    ORDER BY (g.mudanca_avisada_em IS NOT NULL), g.data_hora`, params);
  res.setHeader('Cache-Control', 'no-store');
  res.json(r.rows);
});
router.post('/mudancas/:agId/avisado', async (req, res) => {
  if (!['admin', 'atendente'].includes(req.usuario.papel)) return res.status(403).json({ erro: 'Seu acesso não permite.' });
  if (!UUID_AG.test(String(req.params.agId))) return res.status(404).json({ erro: 'Horário não encontrado.' });
  const params = [req.params.agId, req.usuario.clinicaId, req.usuario.nome || req.usuario.email || ''];
  let f = '';
  if (req.usuario.unidadeId && Array.isArray(req.usuario.unidadeIds) && req.usuario.unidadeIds.length) { params.push(req.usuario.unidadeIds); f = ` AND unidade_id = ANY($4)`; }
  const r = await pool.query(`UPDATE agendamentos SET mudanca_avisada_em=now(), mudanca_avisada_por=$3 WHERE id=$1 AND clinica_id=$2${f} RETURNING id`, params);
  if (!r.rows.length) return res.status(404).json({ erro: 'Horário não encontrado.' });
  res.json({ ok: true });
});
router.get('/entregas', async (req, res) => {
  if (req.usuario.papel === 'gestor') return res.status(403).json({ erro: 'Seu acesso não permite abrir essa parte do sistema.' });
  const params = [req.usuario.clinicaId];
  let f = '';
  if (req.usuario.unidadeId && Array.isArray(req.usuario.unidadeIds) && req.usuario.unidadeIds.length) { params.push(req.usuario.unidadeIds); f = ` AND a.unidade_id = ANY($2)`; }
  const r = await pool.query(`SELECT a.id, a.data, a.entrega_data, a.entrega_hora, a.entrega_local, ${rotulo('u')} AS unidade_nome, ${cidadeSql('u')} AS cidade_nome,
      (SELECT COUNT(*)::int FROM agendamentos g WHERE g.clinica_id=a.clinica_id AND g.unidade_id=a.unidade_id AND g.data_hora::date=a.data AND g.status<>'cancelado') AS pacientes,
      (SELECT COUNT(*)::int FROM agendamentos g WHERE g.clinica_id=a.clinica_id AND g.unidade_id=a.unidade_id AND g.data_hora::date=a.data AND g.status<>'cancelado' AND g.entrega_avisada_em IS NOT NULL) AS avisados
    FROM agendas a JOIN unidades u ON u.id=a.unidade_id
    WHERE a.clinica_id=$1 AND a.entrega_data IS NOT NULL AND a.entrega_data >= CURRENT_DATE - INTERVAL '10 days'${f}
    ORDER BY a.entrega_data, a.data`, params);
  res.setHeader('Cache-Control', 'no-store');
  res.json(r.rows.map((x) => ({ ...x, data: diaIso(x.data), entrega_data: diaIso(x.entrega_data) })));
});
router.get('/:id/pacientes', async (req, res) => {
  const a = await agendaPermitida(req, req.params.id);
  if (!a) return res.status(404).json({ erro: 'Dia da agenda não encontrado.' });
  const r = await pool.query(`SELECT g.id, g.paciente_id, g.status, g.nao_atendido_motivo, to_char(g.data_hora,'HH24:MI') AS hora, g.entrega_avisada_em, g.entrega_avisada_por, p.nome_completo, p.telefone, p.cpf,
      EXISTS (SELECT 1 FROM prontuarios pr WHERE pr.clinica_id=g.clinica_id AND pr.paciente_id=g.paciente_id AND pr.data_exame=g.data_hora::date) AS tem_prontuario
    FROM agendamentos g JOIN pacientes p ON p.id=g.paciente_id
    WHERE g.clinica_id=$1 AND g.unidade_id=$2 AND g.data_hora::date=$3::date AND g.status<>'cancelado' ORDER BY g.data_hora`, [req.usuario.clinicaId, a.unidade_id, diaIso(a.data)]);
  let base = null; try { base = await ocoCompras.carregar(req.usuario.clinicaId); } catch (e) { base = null; }
  const completo = ['admin', 'profissional'].includes(req.usuario.papel);
  /* v4.9.107: a folha do dia com todos os horários da agenda (marcados e livres) e a lista de espera do dia */
  const folha = gerarSlots(await configDaAgenda(a)).map((s) => minParaHora(s.min));
  const esp = await pool.query(`SELECT id, nome, telefone, observacao, criado_por, criado_em FROM lista_espera
      WHERE clinica_id=$1 AND unidade_id=$2 AND data=$3::date AND resolvido_em IS NULL ORDER BY criado_em`, [req.usuario.clinicaId, a.unidade_id, diaIso(a.data)]);
  res.setHeader('Cache-Control', 'no-store');
  res.json({
    agenda: { id: a.id, unidade_id: a.unidade_id, data: diaIso(a.data), unidade_nome: a.unidade_nome, cidade: a.cidade_nome, local: a.local || a.unidade_local || '', entrega_data: a.entrega_data ? diaIso(a.entrega_data) : null, entrega_hora: a.entrega_hora || '', entrega_local: a.entrega_local || '',
      hora_inicio: String(a.hora_inicio || '').slice(0, 5), hora_fim: String(a.hora_fim || '').slice(0, 5) },
    folha,
    espera: esp.rows,
    loja: base ? base.loja : '',
    pacientes: r.rows.map((x) => {
      const c = base ? ocoCompras.compraDepois(base, x, diaIso(a.data)) : { comprou: false };
      const o = { agendamento_id: x.id, paciente_id: x.paciente_id, nome: x.nome_completo, telefone: x.telefone, hora: x.hora, status: x.status, comprou: !!c.comprou, entrega_avisada_em: x.entrega_avisada_em, entrega_avisada_por: x.entrega_avisada_por, motivo: x.nao_atendido_motivo || null };
      if (completo) o.tem_prontuario = x.tem_prontuario;
      return o;
    }),
  });
});
/* v4.9.110: abrir mais um horário depois da hora final do dia (o agendador continua marcando depois das 16h).
   Cada toque abre o próximo horário, com a mesma duração e o mesmo intervalo do dia, e estica a hora final da agenda. */
router.post('/:id/mais-horario', async (req, res) => {
  if (!['admin', 'atendente'].includes(req.usuario.papel)) return res.status(403).json({ erro: 'Seu acesso não permite abrir horário.' });
  const a = await agendaPermitida(req, req.params.id);
  if (!a || a.ativa === false) return res.status(404).json({ erro: 'Dia da agenda não encontrado.' });
  const cfg = await configDaAgenda(a);
  const dur = Number(cfg.duracao_efetiva), passo = dur + bufferEfetivo(cfg), sl = gerarSlots(cfg);
  if (!dur) return res.status(400).json({ erro: 'Este dia está sem duração de atendimento.' });
  const novo = sl.length ? sl[sl.length - 1].min + passo : horaParaMin(cfg.hora_inicio);
  const novoFim = novo + dur;
  if (novoFim > 23 * 60 + 30) return res.status(400).json({ erro: 'Não dá para abrir horário depois das 23:30.' });
  const fimAtual = horaParaMin(String(a.hora_fim).slice(0, 5));
  const choque = await pool.query(`SELECT 1 FROM agendas WHERE clinica_id=$1 AND unidade_id=$2 AND data=$3::date AND ativa=TRUE AND id<>$4 AND hora_inicio < $5::time AND hora_fim > $6::time LIMIT 1`,
    [req.usuario.clinicaId, a.unidade_id, diaIso(a.data), a.id, minParaHora(novoFim), minParaHora(Math.min(fimAtual, novo))]);
  if (choque.rows.length) return res.status(400).json({ erro: 'Já existe outra agenda nesta cidade logo depois deste horário.' });
  await pool.query(`UPDATE agendas SET hora_fim=$1::time WHERE id=$2 AND clinica_id=$3`, [minParaHora(Math.max(novoFim, fimAtual)), a.id, req.usuario.clinicaId]);
  res.json({ ok: true, hora: minParaHora(novo), hora_fim: minParaHora(Math.max(novoFim, fimAtual)) });
});
/* v4.9.107: põe quem está na lista de espera do dia num horário.
   Horário livre: entra normal. Horário de quem faltou: entra no lugar dele, e o faltoso continua anotado como faltou.
   Horário com paciente que ainda não foi marcado como faltou: não deixa, para não pôr duas pessoas na mesma hora. */
router.post('/:id/espera/:esperaId/colocar', async (req, res) => {
  const a = await agendaPermitida(req, req.params.id);
  if (!a) return res.status(404).json({ erro: 'Dia da agenda não encontrado.' });
  if (!UUID_AG.test(String(req.params.esperaId))) return res.status(404).json({ erro: 'Pessoa da espera não encontrada.' });
  const hora = String((req.body || {}).hora || '').slice(0, 5);
  if (!/^\d{2}:\d{2}$/.test(hora)) return res.status(400).json({ erro: 'Escolha o horário.' });
  const cfg = await configDaAgenda(a);
  if (!gerarSlots(cfg).some((s) => minParaHora(s.min) === hora)) return res.status(400).json({ erro: 'Esse horário não existe na agenda deste dia.' });
  const dia = diaIso(a.data), dh = `${dia} ${hora}:00`;
  const c = await pool.connect();
  try {
    await c.query('BEGIN');
    const e = await c.query(`SELECT * FROM lista_espera WHERE id=$1 AND clinica_id=$2 AND unidade_id=$3 AND resolvido_em IS NULL FOR UPDATE`, [req.params.esperaId, req.usuario.clinicaId, a.unidade_id]);
    if (!e.rows.length) { await c.query('ROLLBACK'); return res.status(404).json({ erro: 'Essa pessoa não está mais na lista de espera.' }); }
    const esp = e.rows[0];
    const naHora = await c.query(`SELECT id, status FROM agendamentos WHERE clinica_id=$1 AND unidade_id=$2 AND status<>'cancelado' AND data_hora=$3::timestamp AND COALESCE(origem,'')<>'fora'`,
      [req.usuario.clinicaId, a.unidade_id, dh]);
    const ativos = naHora.rows.filter((x) => x.status !== 'faltou');
    if (ativos.length) { await c.query('ROLLBACK'); return res.status(409).json({ erro: `O horário ${hora} está ocupado. Se o paciente faltou, marque Não foi atendido nele primeiro.` }); }
    const noLugar = naHora.rows.length > 0; // só sobrou quem faltou
    // paciente: reaproveita quem tem o mesmo telefone e nome; senão cria cadastro simples
    const dig = String(esp.telefone || '').replace(/\D/g, '');
    let pacienteId = null;
    if (dig) {
      const ja = await c.query(`SELECT id FROM pacientes WHERE clinica_id=$1 AND deletado_em IS NULL AND regexp_replace(COALESCE(telefone,''),'\\D','','g')=$2 AND lower(nome_completo)=lower($3) LIMIT 1`,
        [req.usuario.clinicaId, dig, esp.nome]);
      pacienteId = ja.rows[0] && ja.rows[0].id;
    }
    /* v4.9.114: com o cadastro completo da espera, o paciente já nasce com CPF, RG, CEP, endereço e cidade */
    let cad = null; try { cad = esp.cadastro ? JSON.parse(cripto.decifrar(esp.cadastro)) : null; } catch (e) { cad = null; }
    if (!pacienteId && cad && cad.cpf) {
      const jc = await c.query(`SELECT id FROM pacientes WHERE clinica_id=$1 AND deletado_em IS NULL AND cpf_idx=$2 LIMIT 1`, [req.usuario.clinicaId, cripto.indiceCpf(cad.cpf)]);
      pacienteId = jc.rows[0] && jc.rows[0].id;
    }
    if (!pacienteId && cad) {
      const p = await c.query(`INSERT INTO pacientes (clinica_id, unidade_id, nome_completo, telefone, agendado_por, cpf, cpf_idx, cep, endereco, cidade, data_nascimento, dados_extras)
          VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12) RETURNING id`,
        [req.usuario.clinicaId, a.unidade_id, esp.nome, esp.telefone || null, esp.criado_por || 'Lista de espera', cad.cpf ? cripto.cifrar(cad.cpf) : null, cad.cpf ? cripto.indiceCpf(cad.cpf) : null,
         cad.cep || null, cad.endereco || null, cad.cidade || null, /^\d{4}-\d{2}-\d{2}$/.test(cad.data_nascimento || '') ? cad.data_nascimento : null, JSON.stringify(cad.rg ? { rg: cad.rg } : {})]);
      pacienteId = p.rows[0].id;
    }
    if (!pacienteId) {
      const p = await c.query(`INSERT INTO pacientes (clinica_id, unidade_id, nome_completo, telefone, agendado_por) VALUES ($1,$2,$3,$4,$5) RETURNING id`,
        [req.usuario.clinicaId, a.unidade_id, esp.nome, esp.telefone || null, esp.criado_por || 'Lista de espera']);
      pacienteId = p.rows[0].id;
    }
    const mesmoDia = await c.query(`SELECT 1 FROM agendamentos WHERE clinica_id=$1 AND paciente_id=$2 AND status<>'cancelado' AND data_hora::date=$3::date LIMIT 1`, [req.usuario.clinicaId, pacienteId, dia]);
    if (mesmoDia.rows.length) { await c.query('ROLLBACK'); return res.status(409).json({ erro: 'Essa pessoa já tem exame marcado neste dia.' }); }
    const buf = cfg.buffer_agenda !== null && cfg.buffer_agenda !== undefined ? Number(cfg.buffer_agenda) : Number(cfg.buffer_tipo || 0);
    // no lugar de quem faltou entra com duração zero: o horário continua com o faltoso anotado e não dá choque de horário
    const r = await c.query(
      `INSERT INTO agendamentos (clinica_id, unidade_id, paciente_id, tipo_atendimento_id, usuario_id, data_hora, duracao_min, buffer_min, local, agendado_por, status, observacoes, origem, encaixe)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,'agendado',$11,'espera',$12) RETURNING id`,
      [req.usuario.clinicaId, a.unidade_id, pacienteId, a.tipo_atendimento_id, req.usuario.usuarioId || null, dh,
       noLugar ? 0 : Number(cfg.duracao_efetiva), noLugar ? 0 : buf, a.local || a.unidade_local || null,
       esp.criado_por || String(req.usuario.nome || '').slice(0, 255) || null,
       noLugar ? 'Veio da lista de espera, no lugar de quem faltou' : 'Veio da lista de espera', noLugar]);
    await c.query(`UPDATE lista_espera SET resolvido_em=NOW(), agendamento_id=$1 WHERE id=$2`, [r.rows[0].id, esp.id]);
    await c.query('COMMIT');
    res.status(201).json({ ok: true, agendamento_id: r.rows[0].id, no_lugar_de_quem_faltou: noLugar });
  } catch (err) {
    await c.query('ROLLBACK').catch(() => {});
    if (err.code === '23P01') return res.status(409).json({ erro: `O horário ${hora} acabou de ser ocupado. Escolha outro.` });
    throw err;
  } finally { c.release(); }
});

router.put('/:id/entrega', exigirAdmin, async (req, res) => {
  const a = await agendaPermitida(req, req.params.id);
  if (!a) return res.status(404).json({ erro: 'Dia da agenda não encontrado.' });
  const b = req.body || {};
  const data = b.data ? String(b.data) : null, hora = b.hora ? String(b.hora).slice(0, 5) : null, local = String(b.local || '').trim().slice(0, 255) || null;
  if (data && !FORMATO_DIA.test(data)) return res.status(400).json({ erro: 'Dia da entrega inválido.' });
  if (hora && !/^\d{2}:\d{2}$/.test(hora)) return res.status(400).json({ erro: 'Hora da entrega inválida.' });
  if (data && !hora) return res.status(400).json({ erro: 'Informe a hora da entrega.' });
  if (data && !local) return res.status(400).json({ erro: 'Informe o local da entrega.' });
  await pool.query(`UPDATE agendas SET entrega_data=$1, entrega_hora=$2, entrega_local=$3 WHERE id=$4 AND clinica_id=$5`, [data, data ? hora : null, data ? local : null, a.id, req.usuario.clinicaId]);
  res.json({ ok: true });
});
router.post('/aviso-entrega/:agendamentoId', async (req, res) => {
  if (!UUID_AG.test(String(req.params.agendamentoId)) || req.usuario.papel === 'gestor') return res.status(404).json({ erro: 'Paciente não encontrado.' });
  const params = [req.params.agendamentoId, req.usuario.clinicaId, String(req.usuario.nome || '').slice(0, 120)];
  let f = '';
  if (req.usuario.unidadeId && Array.isArray(req.usuario.unidadeIds) && req.usuario.unidadeIds.length) { params.push(req.usuario.unidadeIds); f = ' AND unidade_id = ANY($4)'; }
  const r = await pool.query(`UPDATE agendamentos SET entrega_avisada_em=NOW(), entrega_avisada_por=$3 WHERE id=$1 AND clinica_id=$2${f} RETURNING id`, params);
  if (!r.rows.length) return res.status(404).json({ erro: 'Paciente não encontrado.' });
  res.json({ ok: true });
});

router.post('/', exigirAdmin, async (req, res) => {
  const { unidade_id, data, data_fim, hora_inicio, hora_fim, tipo_atendimento_id, local } = req.body;
  const campos = lerCamposAgenda(req.body);
  if (campos.erro) return res.status(400).json({ erro: campos.erro });
  const { buf: bufAgenda, dur: durAgenda, alI, alF } = campos;
  if (!unidade_id || !data || !hora_inicio || !hora_fim || !tipo_atendimento_id) {
    return res.status(400).json({ erro: 'Informe a cidade, a data, o horário de início e fim e o tipo de atendimento.' });
  }
  if (!FORMATO_HORA.test(String(hora_inicio)) || !FORMATO_HORA.test(String(hora_fim)) || !FORMATO_DIA.test(String(data)) || (data_fim && !FORMATO_DIA.test(String(data_fim)))) return res.status(400).json({ erro: 'Data ou horário em formato inválido.' });
  if (horaParaMin(hora_fim) <= horaParaMin(hora_inicio)) return res.status(400).json({ erro: 'O horário final precisa ser depois do inicial.' });
  const un = await pool.query(`SELECT id FROM unidades WHERE id=$1 AND clinica_id=$2 AND ativa=TRUE`, [unidade_id, req.usuario.clinicaId]);
  const tp = await pool.query(`SELECT id, duracao_min FROM tipos_atendimento WHERE id=$1 AND clinica_id=$2`, [tipo_atendimento_id, req.usuario.clinicaId]);
  if (!un.rows.length) return res.status(400).json({ erro: 'Cidade inválida.' });
  if (!tp.rows.length) return res.status(400).json({ erro: 'Tipo de atendimento inválido.' });
  if (horaParaMin(hora_fim) - horaParaMin(hora_inicio) < (durAgenda || tp.rows[0].duracao_min)) return res.status(400).json({ erro: 'O intervalo é menor que a duração do atendimento.' });

  const dias = [];
  const ini = new Date(data + 'T12:00:00Z'), fim = new Date((data_fim || data) + 'T12:00:00Z');
  if (fim < ini) return res.status(400).json({ erro: 'A data final precisa ser depois da inicial.' });
  if ((fim - ini) / 86400000 > 60) return res.status(400).json({ erro: 'Crie no máximo 60 dias por vez.' });
  for (let d = new Date(ini); d <= fim; d.setUTCDate(d.getUTCDate() + 1)) dias.push(d.toISOString().slice(0, 10));

  // não deixa abrir duas agendas que se cruzam na mesma cidade e no mesmo dia (os horários apareceriam repetidos)
  const cruzam = await pool.query(
    `SELECT data FROM agendas WHERE clinica_id=$1 AND unidade_id=$2 AND ativa=TRUE AND data = ANY($3::date[])
       AND hora_inicio < $5::time AND hora_fim > $4::time ORDER BY data`,
    [req.usuario.clinicaId, unidade_id, dias, hora_inicio, hora_fim]);
  if (cruzam.rows.length) {
    const lista = cruzam.rows.slice(0, 5).map((x) => String(x.data).split('-').reverse().join('/')).join(', ');
    return res.status(409).json({ erro: `Já existe agenda nessa cidade em horário que se cruza, no dia ${lista}. Apague a anterior ou mude o horário.` });
  }

  const criadas = [];
  for (const dia of dias) {
    const r = await pool.query(
      `INSERT INTO agendas (clinica_id, unidade_id, data, hora_inicio, hora_fim, tipo_atendimento_id, local, buffer_min, almoco_inicio, almoco_fim, duracao_min)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11) RETURNING *`,
      [req.usuario.clinicaId, unidade_id, dia, hora_inicio, hora_fim, tipo_atendimento_id, local || null, bufAgenda, alI, alF, durAgenda]
    );
    criadas.push(r.rows[0]);
  }
  res.status(201).json(criadas);
});

/* Muda uma agenda que já existe (dia, cidade, horário, duração, intervalo, almoço, tipo, local) sem precisar apagar.
   Só vale enquanto não houver paciente marcado nela: senão os horários marcados poderiam sumir. */
/* v4.9.116: mudar a agenda de um dia com paciente marcado e reencaixar todos na grade nova.
   aplicar=false devolve a prévia (horário antigo e novo de cada um); aplicar=true muda a agenda e os horários juntos.
   Quem mudou de horário entra na lista Avisar mudança de horário. O dia e a cidade continuam sem mudar aqui. */
router.post('/:id/reencaixe', exigirAdmin, async (req, res) => {
  const q = await pool.query(`SELECT a.*, ${rotulo('u')} AS unidade_nome FROM agendas a JOIN unidades u ON u.id=a.unidade_id WHERE a.id=$1 AND a.clinica_id=$2 AND a.ativa=TRUE`, [req.params.id, req.usuario.clinicaId]);
  if (!q.rows.length) return res.status(404).json({ erro: 'Agenda não encontrada.' });
  const ag = q.rows[0], b = req.body || {};
  const dia = diaIso(ag.data);
  if ((b.data && String(b.data) !== dia) || (b.unidade_id && String(b.unidade_id) !== String(ag.unidade_id))) return res.status(400).json({ erro: 'Para mudar o dia ou a cidade, use o Salvar normal sem paciente marcado.' });
  const hora_inicio = String(b.hora_inicio || ag.hora_inicio).slice(0, 5), hora_fim = String(b.hora_fim || ag.hora_fim).slice(0, 5);
  const tipoId = b.tipo_atendimento_id || ag.tipo_atendimento_id;
  const campos = lerCamposAgenda(b);
  if (campos.erro) return res.status(400).json({ erro: campos.erro });
  if (!FORMATO_HORA.test(hora_inicio) || !FORMATO_HORA.test(hora_fim) || horaParaMin(hora_fim) <= horaParaMin(hora_inicio)) return res.status(400).json({ erro: 'O horário final precisa ser depois do inicial.' });
  const tp = await pool.query(`SELECT id, duracao_min, buffer_min FROM tipos_atendimento WHERE id=$1 AND clinica_id=$2`, [tipoId, req.usuario.clinicaId]);
  if (!tp.rows.length) return res.status(400).json({ erro: 'Tipo de atendimento inválido.' });
  const dur = Number(campos.dur || tp.rows[0].duracao_min);
  const cfgNovo = { hora_inicio, hora_fim, almoco_inicio: campos.alI, almoco_fim: campos.alF, duracao_efetiva: dur, buffer_agenda: campos.buf, buffer_tipo: tp.rows[0].buffer_min };
  const buf = bufferEfetivo(cfgNovo);
  const novos = gerarSlots(cfgNovo).map((x) => x.min);
  const ags = await pool.query(`SELECT g.id, to_char(g.data_hora,'HH24:MI') AS hora, p.nome_completo AS nome
      FROM agendamentos g JOIN pacientes p ON p.id=g.paciente_id
      WHERE g.clinica_id=$1 AND g.unidade_id=$2 AND g.data_hora::date=$3::date AND g.status<>'cancelado'
        AND COALESCE(g.origem,'')<>'fora' AND NOT COALESCE(g.encaixe,FALSE) ORDER BY g.data_hora`, [req.usuario.clinicaId, ag.unidade_id, dia]);
  const usados = new Set(), lista = [];
  let minimo = -1, falta = 0;
  for (const g of ags.rows) {
    const m = horaParaMin(g.hora);
    let melhor = null;
    for (const n of novos) { if (n <= minimo || usados.has(n)) continue; if (melhor === null || Math.abs(n - m) < Math.abs(melhor - m)) melhor = n; }
    if (melhor === null) { falta += 1; continue; }
    usados.add(melhor); minimo = melhor;
    lista.push({ agendamento_id: g.id, nome: g.nome, de: g.hora, para: minParaHora(melhor), muda: minParaHora(melhor) !== g.hora });
  }
  const resumo = { data: dia, unidade_nome: ag.unidade_nome, horarios_depois: novos.length, marcados: ags.rows.length, mudam: lista.filter((x) => x.muda).length, falta, lista };
  if (!b.aplicar) return res.json(resumo);
  if (falta) return res.status(400).json({ erro: `Com essa agenda, ${falta} paciente(s) ficam sem horário. Aumente o horário final ou diminua a duração.` });
  const cruza = await pool.query(`SELECT 1 FROM agendas WHERE clinica_id=$1 AND unidade_id=$2 AND ativa=TRUE AND data=$3 AND id<>$6 AND hora_inicio < $5::time AND hora_fim > $4::time LIMIT 1`,
    [req.usuario.clinicaId, ag.unidade_id, dia, hora_inicio, hora_fim, ag.id]);
  if (cruza.rows.length) return res.status(409).json({ erro: 'Já existe outra agenda nessa cidade nesse dia em horário que se cruza.' });
  const c = await pool.connect();
  try {
    await c.query('BEGIN');
    await c.query(`UPDATE agendas SET hora_inicio=$1, hora_fim=$2, tipo_atendimento_id=$3, local=$4, buffer_min=$5, almoco_inicio=$6, almoco_fim=$7, duracao_min=$8 WHERE id=$9 AND clinica_id=$10`,
      [hora_inicio, hora_fim, tipoId, b.local !== undefined ? (b.local || null) : ag.local, campos.buf, campos.alI, campos.alF, campos.dur, ag.id, req.usuario.clinicaId]);
    const ids = lista.map((x) => x.agendamento_id);
    if (ids.length) {
      await c.query(`UPDATE agendamentos SET duracao_min=$3, buffer_min=$4, data_hora = data_hora + interval '500 years' WHERE id = ANY($1::uuid[]) AND clinica_id=$2`, [ids, req.usuario.clinicaId, dur, buf]);
      for (const x of lista) {
        await c.query(`UPDATE agendamentos SET data_hora = ($1::date + $2::time),
            horario_anterior = CASE WHEN $4 THEN COALESCE(horario_anterior, ($1::date + $3::time)) ELSE horario_anterior END,
            horario_mudado_em = CASE WHEN $4 THEN now() ELSE horario_mudado_em END,
            mudanca_avisada_em = CASE WHEN $4 THEN NULL ELSE mudanca_avisada_em END
          WHERE id=$5 AND clinica_id=$6`, [dia, x.para, x.de, x.muda, x.agendamento_id, req.usuario.clinicaId]);
      }
    }
    await c.query('COMMIT');
  } catch (e) {
    await c.query('ROLLBACK').catch(() => {});
    return res.status(400).json({ erro: 'Não consegui mudar a agenda. Nada foi mudado. ' + (e.code === '23P01' ? 'Um horário novo esbarrou em outro (encaixe ou paciente de fora).' : (e.message || '')) });
  } finally { c.release(); }
  res.json({ ...resumo, ok: true });
});
router.put('/:id', exigirAdmin, async (req, res) => {
  const a = await pool.query(`SELECT * FROM agendas WHERE id=$1 AND clinica_id=$2 AND ativa=TRUE`, [req.params.id, req.usuario.clinicaId]);
  if (!a.rows.length) return res.status(404).json({ erro: 'Agenda não encontrada.' });
  const ag = a.rows[0];
  const hora_inicio = req.body.hora_inicio || String(ag.hora_inicio).slice(0, 5), hora_fim = req.body.hora_fim || String(ag.hora_fim).slice(0, 5);
  const tipoId = req.body.tipo_atendimento_id || ag.tipo_atendimento_id;
  /* v4.9.63: também dá para mudar o dia e a cidade, sem apagar a agenda */
  const diaAntigo = ag.data instanceof Date ? ag.data.toISOString().slice(0, 10) : String(ag.data).slice(0, 10);
  const novoDia = req.body.data ? String(req.body.data) : diaAntigo;
  if (!FORMATO_DIA.test(novoDia)) return res.status(400).json({ erro: 'Data em formato inválido.' });
  const novaCidade = req.body.unidade_id ? String(req.body.unidade_id) : String(ag.unidade_id);
  if (novaCidade !== String(ag.unidade_id)) {
    const un = await pool.query(`SELECT id FROM unidades WHERE id=$1 AND clinica_id=$2 AND ativa=TRUE`, [novaCidade, req.usuario.clinicaId]);
    if (!un.rows.length) return res.status(400).json({ erro: 'Cidade inválida.' });
  }
  const campos = lerCamposAgenda(req.body);
  if (campos.erro) return res.status(400).json({ erro: campos.erro });
  if (!FORMATO_HORA.test(hora_inicio) || !FORMATO_HORA.test(hora_fim) || horaParaMin(hora_fim) <= horaParaMin(hora_inicio)) return res.status(400).json({ erro: 'O horário final precisa ser depois do inicial.' });
  const tp = await pool.query(`SELECT id, duracao_min, buffer_min FROM tipos_atendimento WHERE id=$1 AND clinica_id=$2`, [tipoId, req.usuario.clinicaId]);
  if (!tp.rows.length) return res.status(400).json({ erro: 'Tipo de atendimento inválido.' });
  if (horaParaMin(hora_fim) - horaParaMin(hora_inicio) < (campos.dur || tp.rows[0].duracao_min)) return res.status(400).json({ erro: 'O intervalo é menor que a duração do atendimento.' });
  /* v4.9.105: com paciente marcado, o Master ainda pode mudar a agenda (ex.: aumentar uma hora no fim).
     Os marcados não mudam de horário. A mudança só passa se cada horário marcado continuar existindo na agenda nova.
     Mudar o dia ou a cidade continua travado enquanto houver paciente marcado. */
  const ocup = await pool.query(
    `SELECT to_char(data_hora, 'HH24:MI') AS hora, COALESCE(origem,'') AS origem, COALESCE(encaixe,FALSE) AS encaixe
       FROM agendamentos WHERE clinica_id=$1 AND unidade_id=$2 AND status <> 'cancelado' AND data_hora::date = $3
       AND data_hora::time >= $4 AND data_hora::time < $5`,
    [req.usuario.clinicaId, ag.unidade_id, ag.data, ag.hora_inicio, ag.hora_fim]);
  if (ocup.rows.length) {
    const n = ocup.rows.length;
    if (novoDia !== diaAntigo || novaCidade !== String(ag.unidade_id)) {
      return res.status(409).json({ erro: `Essa agenda já tem ${n} paciente(s) marcado(s). Para mudar o dia ou a cidade, cancele os agendamentos antes.` });
    }
    const novos = new Set(gerarSlots({
      hora_inicio, hora_fim, almoco_inicio: campos.alI, almoco_fim: campos.alF,
      duracao_efetiva: campos.dur || tp.rows[0].duracao_min, buffer_agenda: campos.buf, buffer_tipo: tp.rows[0].buffer_min,
    }).map((s) => minParaHora(s.min)));
    const fora = ocup.rows.filter((o) => o.origem !== 'fora' && !o.encaixe && !novos.has(o.hora)).map((o) => o.hora);
    if (fora.length) {
      return res.status(409).json({ erro: `Com esse novo horário, ${fora.length} paciente(s) marcado(s) ficariam fora da agenda (${[...new Set(fora)].sort().join(', ')}). Mantenha o início, a duração, o intervalo e o almoço, e mude só o fim.` });
    }
  }
  const cruza = await pool.query(
    `SELECT 1 FROM agendas WHERE clinica_id=$1 AND unidade_id=$2 AND ativa=TRUE AND data=$3 AND id<>$6 AND hora_inicio < $5::time AND hora_fim > $4::time LIMIT 1`,
    [req.usuario.clinicaId, novaCidade, novoDia, hora_inicio, hora_fim, ag.id]);
  if (cruza.rows.length) return res.status(409).json({ erro: `Já existe outra agenda nessa cidade no dia ${novoDia.split('-').reverse().join('/')} em horário que se cruza.` });
  const r = await pool.query(
    `UPDATE agendas SET hora_inicio=$1, hora_fim=$2, tipo_atendimento_id=$3, local=$4, buffer_min=$5, almoco_inicio=$6, almoco_fim=$7, duracao_min=$8, data=$11, unidade_id=$12 WHERE id=$9 AND clinica_id=$10 RETURNING *`,
    [hora_inicio, hora_fim, tipoId, req.body.local !== undefined ? (req.body.local || null) : ag.local, campos.buf, campos.alI, campos.alF, campos.dur, ag.id, req.usuario.clinicaId, novoDia, novaCidade]);
  res.json(r.rows[0]);
});

router.delete('/:id', exigirAdmin, async (req, res) => {
  const a = await pool.query(`SELECT * FROM agendas WHERE id=$1 AND clinica_id=$2 AND ativa=TRUE`, [req.params.id, req.usuario.clinicaId]);
  if (!a.rows.length) return res.status(404).json({ erro: 'Agenda não encontrada.' });
  const ag = a.rows[0];
  const ocup = await pool.query(
    `SELECT COUNT(*)::int AS n FROM agendamentos WHERE clinica_id=$1 AND unidade_id=$2 AND status <> 'cancelado' AND data_hora::date = $3
       AND data_hora::time >= $4 AND data_hora::time < $5`,
    [req.usuario.clinicaId, ag.unidade_id, ag.data, ag.hora_inicio, ag.hora_fim]
  );
  if (ocup.rows[0].n > 0) return res.status(409).json({ erro: `Essa agenda já tem ${ocup.rows[0].n} paciente(s) marcado(s). Cancele os agendamentos antes de apagar.` });
  await pool.query(`UPDATE agendas SET ativa=FALSE WHERE id=$1 AND clinica_id=$2`, [req.params.id, req.usuario.clinicaId]);
  res.json({ ok: true });
});


/* v4.9.88: paciente atendido (ou marcado) fora do sistema, lançado depois na lista do dia.
   Entra com duração zero: não ocupa horário da agenda e não esbarra em quem já está marcado.
   Dia que já chegou: entra como atendido. Dia que ainda vai chegar: entra como marcado (encaixe). */
const UUID_FORA = /^[0-9a-f-]{36}$/i;
router.get('/:id/fora-do-sistema', async (req, res) => {
  const a = await agendaPermitida(req, req.params.id);
  if (!a) return res.status(404).json({ erro: 'Dia da agenda não encontrado.' });
  const { agoraBrasilia } = require('./agendadorOffline');
  const dia = diaIso(a.data), hoje = agoraBrasilia().slice(0, 10);
  const f = await pool.query(`SELECT paciente_id FROM agendamentos WHERE clinica_id=$1 AND unidade_id=$2 AND data_hora::date=$3::date AND origem='fora' AND status<>'cancelado'`, [req.usuario.clinicaId, a.unidade_id, dia]);
  res.setHeader('Cache-Control', 'no-store');
  res.json({ unidade_id: a.unidade_id, data: dia, passou: dia <= hoje, hora_inicio: String(a.hora_inicio || '').slice(0, 5), hora_fim: String(a.hora_fim || '').slice(0, 5), fora: f.rows.map((x) => x.paciente_id) });
});
router.post('/:id/fora-do-sistema', async (req, res) => {
  const a = await agendaPermitida(req, req.params.id);
  if (!a) return res.status(404).json({ erro: 'Dia da agenda não encontrado.' });
  const b = req.body || {};
  const pid = String(b.paciente_id || '');
  if (!UUID_FORA.test(pid)) return res.status(400).json({ erro: 'Escolha o paciente.' });
  const params = [pid, req.usuario.clinicaId];
  let fu = '';
  if (req.usuario.unidadeId && Array.isArray(req.usuario.unidadeIds) && req.usuario.unidadeIds.length) { params.push(req.usuario.unidadeIds); fu = ' AND (unidade_id IS NULL OR unidade_id = ANY($3))'; }
  const p = await pool.query(`SELECT id FROM pacientes WHERE id=$1 AND clinica_id=$2 AND deletado_em IS NULL${fu}`, params);
  if (!p.rows.length) return res.status(404).json({ erro: 'Paciente não encontrado.' });
  const { agoraBrasilia } = require('./agendadorOffline');
  const dia = diaIso(a.data), hoje = agoraBrasilia().slice(0, 10), passou = dia <= hoje;
  let hora = String(b.hora || '').slice(0, 5);
  if (hora && !/^\d{2}:\d{2}$/.test(hora)) return res.status(400).json({ erro: 'Hora inválida.' });
  if (!hora) {
    if (!passou) return res.status(400).json({ erro: 'Informe a hora em que o paciente foi marcado.' });
    hora = String(a.hora_fim || '18:00').slice(0, 5);
  }
  const ja = await pool.query(`SELECT 1 FROM agendamentos WHERE clinica_id=$1 AND paciente_id=$2 AND data_hora::date=$3::date AND status<>'cancelado'`, [req.usuario.clinicaId, pid, dia]);
  if (ja.rows.length) return res.status(409).json({ erro: 'Esse paciente já está na lista deste dia.' });
  const obs = String(b.observacao || '').trim().slice(0, 300);
  const r = await pool.query(
    `INSERT INTO agendamentos (clinica_id, unidade_id, paciente_id, tipo_atendimento_id, usuario_id, data_hora, duracao_min, buffer_min, local, agendado_por, status, observacoes, origem, encaixe)
     VALUES ($1,$2,$3,$4,$5,$6,0,0,$7,$8,$9,$10,'fora',TRUE) RETURNING id, status`,
    [req.usuario.clinicaId, a.unidade_id, pid, a.tipo_atendimento_id, req.usuario.usuarioId || null, `${dia} ${hora}:00`, a.local || a.unidade_local || null,
     String(req.usuario.nome || '').slice(0, 255) || null, passou ? 'realizado' : 'agendado', (passou ? 'Atendido fora do sistema' : 'Marcado fora do sistema') + (obs ? '. ' + obs : '')]);
  res.status(201).json({ ok: true, id: r.rows[0].id, status: r.rows[0].status });
});

module.exports = router;
