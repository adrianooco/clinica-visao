/* Guarda o sistema no aparelho para abrir sem internet. Os dados da ótica ficam no navegador e nunca passam por aqui. */
const CACHE = 'otica-gestao-v4';
const CASCA = ['./', './index.html', './manifest.json', './icone-192.png', './icone-180.png'];
self.addEventListener('install', (e) => { e.waitUntil(caches.open(CACHE).then((c) => Promise.all(CASCA.map((u) => c.add(u).catch(() => {})))).then(() => self.skipWaiting())); });
self.addEventListener('activate', (e) => { e.waitUntil(caches.keys().then((ks) => Promise.all(ks.filter((k) => k !== CACHE).map((k) => caches.delete(k)))).then(() => self.clients.claim())); });
self.addEventListener('fetch', (e) => {
  const r = e.request, u = new URL(r.url);
  if (r.method !== 'GET' || u.origin !== location.origin) return;
  e.respondWith(fetch(r).then((resp) => { if (resp.ok) { const copia = resp.clone(); caches.open(CACHE).then((c) => c.put(r, copia)); } return resp; }).catch(() => caches.match(r, { ignoreSearch: true }).then((c) => c || caches.match('./index.html'))));
});
