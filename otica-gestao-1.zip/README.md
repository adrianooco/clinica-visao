# Ótica Centro Oeste, Gestão

Sistema de vendas, ordens de serviço, estoque, caixa, contas a receber e clientes da Ótica Centro Oeste.
É um sistema separado da Clínica de Visão. Não usa o banco, o login nem o servidor da Clínica.

## Como funciona
- Um arquivo principal (`index.html`), sem servidor e sem banco de dados.
- Os dados ficam no navegador de cada aparelho. Faça backup pela aba Backup toda semana.
- Primeiro acesso: o sistema pede para criar o Administrador Master. Esse usuário vê tudo.
- O Master cadastra os gestores da ótica e escolhe as telas de cada um.

## Instalar no celular
1. Publique esta pasta em um endereço https (GitHub Pages, Render Static Site ou Netlify).
2. Abra o endereço no celular e toque em Instalar (Android) ou Compartilhar, Adicionar à Tela de Início (iPhone).
3. Depois do primeiro acesso, abre sem internet.

## Arquivos
- index.html: o sistema
- manifest.json e sw.js: instalação e uso sem internet
- icone-*.png: ícones do aplicativo
