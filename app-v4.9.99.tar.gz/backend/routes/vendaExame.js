/* v4.9.99: venda marcada na folha do dia e acerto da comissão do agendador.
   - Na folha do dia, o Master ou o profissional marca o que o paciente comprou: não comprou, só lente, só armação ou óculos completo.
   - Essa marcação vale mais que a ligação automática com as vendas da ótica (que continua valendo para quem não foi marcado).
   - "Não comprou" vale R$ do exame; se o paciente voltar e comprar dentro da janela, passa a valer a compra.
   - Acerto: o Master registra o pagamento do mês de cada agendador; o agendador vê se já foi pago. */
const express = require('express');
const pool = require('../db/pool');
const { exigirLogin, exigirAdmin } = require('../middleware/auth');

const router = express.Router();
router.use(exigirLogin);
const RESULTADOS = ['nao', 'lente', 'armacao', 'completo'];
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const MES = /^\d{4}-\d{2}$/;
const podeMarcar = (req) => ['admin', 'profissional'].includes(req.usuario.papel);

/* marcações de uma lista de agendamentos (os da folha do dia) */
router.get('/', async (req, res) => {
  if (!podeMarcar(req)) return res.status(403).json({ erro: 'Seu acesso não permite abrir essa parte do sistema.' });
  const ids = String(req.query.ids || '').split(',').filter((x) => UUID.test(x)).slice(0, 300);
  if (!ids.length) return res.json([]);
  const r = await pool.query(`SELECT id AS agendamento_id, venda_resultado, venda_marcada_por, venda_marcada_em FROM agendamentos WHERE clinica_id=$1 AND id = ANY($2::uuid[])`, [req.usuario.clinicaId, ids]);
  res.setHeader('Cache-Control', 'no-store');
  res.json(r.rows);
});

router.put('/:id', async (req, res) => {
  if (!podeMarcar(req)) return res.status(403).json({ erro: 'Só o Master ou o profissional marca a venda.' });
  if (!UUID.test(req.params.id)) return res.status(400).json({ erro: 'Agendamento inválido.' });
  const resultado = req.body && req.body.resultado ? String(req.body.resultado) : null;
  if (resultado && !RESULTADOS.includes(resultado)) return res.status(400).json({ erro: 'Escolha: não comprou, lente, armação ou completo.' });
  /* marcar a venda é sinal de que o paciente veio: fica como atendido */
  const r = await pool.query(
    `UPDATE agendamentos SET venda_resultado=$1::varchar, venda_marcada_por=$2, venda_marcada_em=CASE WHEN $1::varchar IS NULL THEN NULL ELSE NOW() END,
            status = CASE WHEN $1::varchar IS NOT NULL AND status IN ('agendado','confirmado','faltou') THEN 'realizado' ELSE status END
      WHERE id=$3 AND clinica_id=$4 AND status<>'cancelado'
      RETURNING id AS agendamento_id, status, venda_resultado, venda_marcada_por, venda_marcada_em`,
    [resultado, resultado ? String(req.usuario.nome || '').slice(0, 150) : null, req.params.id, req.usuario.clinicaId]);
  if (!r.rows.length) return res.status(404).json({ erro: 'Agendamento não encontrado.' });
  res.json(r.rows[0]);
});

/* ---------- acerto do mês ---------- */
router.get('/acertos', async (req, res) => {
  const mes = MES.test(String(req.query.mes || '')) ? req.query.mes : null;
  if (!mes) return res.status(400).json({ erro: 'Informe o mês.' });
  const params = [req.usuario.clinicaId, mes];
  let filtro = '';
  if (req.usuario.papel === 'atendente') { params.push(req.usuario.usuarioId); filtro = ' AND usuario_id=$3'; }
  else if (req.usuario.papel !== 'admin') return res.status(403).json({ erro: 'Seu acesso não permite abrir essa parte do sistema.' });
  const r = await pool.query(`SELECT id, usuario_id, mes, valor, pago_em, pago_por, obs FROM comissoes_acertos WHERE clinica_id=$1 AND mes=$2${filtro}`, params);
  res.setHeader('Cache-Control', 'no-store');
  res.json(r.rows.map((x) => ({ ...x, valor: Number(x.valor), pago_em: x.pago_em instanceof Date ? x.pago_em.toISOString().slice(0, 10) : x.pago_em })));
});
router.post('/acertos', exigirAdmin, async (req, res) => {
  const b = req.body || {};
  const valor = Number(String(b.valor).replace(',', '.'));
  if (!UUID.test(String(b.usuario_id || '')) || !MES.test(String(b.mes || '')) || !Number.isFinite(valor) || valor < 0 || valor > 100000) return res.status(400).json({ erro: 'Dados do acerto inválidos.' });
  const u = await pool.query(`SELECT id FROM usuarios WHERE id=$1 AND clinica_id=$2`, [b.usuario_id, req.usuario.clinicaId]);
  if (!u.rows.length) return res.status(404).json({ erro: 'Agendador não encontrado.' });
  const r = await pool.query(
    `INSERT INTO comissoes_acertos (clinica_id, usuario_id, mes, valor, pago_em, pago_por, obs) VALUES ($1,$2,$3,$4,CURRENT_DATE,$5,$6)
     ON CONFLICT (clinica_id, usuario_id, mes) DO UPDATE SET valor=EXCLUDED.valor, pago_em=EXCLUDED.pago_em, pago_por=EXCLUDED.pago_por, obs=EXCLUDED.obs
     RETURNING id, usuario_id, mes, valor, pago_em, pago_por, obs`,
    [req.usuario.clinicaId, b.usuario_id, b.mes, Math.round(valor * 100) / 100, String(req.usuario.nome || '').slice(0, 150), String(b.obs || '').slice(0, 300) || null]);
  const x = r.rows[0];
  res.status(201).json({ ...x, valor: Number(x.valor), pago_em: x.pago_em instanceof Date ? x.pago_em.toISOString().slice(0, 10) : x.pago_em });
});
router.delete('/acertos/:id', exigirAdmin, async (req, res) => {
  if (!UUID.test(req.params.id)) return res.status(400).json({ erro: 'Acerto inválido.' });
  await pool.query(`DELETE FROM comissoes_acertos WHERE id=$1 AND clinica_id=$2`, [req.params.id, req.usuario.clinicaId]);
  res.json({ ok: true });
});

module.exports = router;
