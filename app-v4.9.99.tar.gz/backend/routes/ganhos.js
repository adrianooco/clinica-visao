const express = require('express');
const pool = require('../db/pool');
const cripto = require('../utils/cripto');
const { exigirLogin, exigirAdmin } = require('../middleware/auth');

/* v4.9.64: ganhos do agendador.
   Cada paciente que o agendador marcou e que fez o exame (status realizado) vale um valor só:
   comprou na ótica (OCO) até 60 dias depois do exame o óculos completo (lente e armação), ou só a lente
   ou só a armação, ganha o valor da compra; não comprou nada, ganha o valor do exame. Os valores ficam na clínica e o Master pode mudar.
   O agendador vê só o primeiro nome do paciente, o dia e o que ganhou. Não vê o valor da compra. */
const router = express.Router();
router.use(exigirLogin);

const JANELA_DIAS = 60;
const MES = /^\d{4}-\d{2}$/;
const so = (x) => String(x == null ? '' : x).replace(/\D/g, '');
const semAcento = (t) => String(t || '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().trim();
const nomeCurto = (n) => { const p = String(n || '').trim().split(/\s+/).filter(Boolean); return p.length ? p[0] + (p.length > 1 ? ' ' + p[p.length - 1][0] + '.' : '') : 'Paciente'; };
const dia = (d) => (d instanceof Date ? d.toISOString().slice(0, 10) : String(d || '').slice(0, 10));
const somaDias = (iso, n) => { const d = new Date(iso + 'T12:00:00Z'); d.setUTCDate(d.getUTCDate() + n); return d.toISOString().slice(0, 10); };

async function valores(clinicaId) {
  const r = await pool.query(`SELECT comissao_opcao_a, comissao_opcao_b, ganho_exame FROM clinicas WHERE id=$1`, [clinicaId]);
  const c = r.rows[0] || {};
  return { completo: Number(c.comissao_opcao_b ?? 50), parcial: Number(c.comissao_opcao_a ?? 25), exame: Number(c.ganho_exame ?? 10) };
}

/* o que tem na venda: lente, armação ou os dois */
function tipoVenda(v) {
  let lente = false, armacao = false;
  for (const i of v.itens || []) {
    const d = semAcento(i.descricao);
    if (i.lente || /\blente/.test(d)) lente = true;
    if (/armac/.test(d)) armacao = true;
    if (/oculos (completo|de grau)/.test(d)) { lente = true; armacao = true; }
  }
  return lente && armacao ? 'completo' : (lente || armacao) ? (lente ? 'lente' : 'armacao') : null;
}

async function blocoOco(clinicaId) {
  const r = await pool.query(`SELECT dados FROM gestor_vendas_dados WHERE clinica_id=$1`, [clinicaId]);
  if (!r.rows.length) return { clientes: [], vendas: [] };
  try { const d = JSON.parse(cripto.decifrar(r.rows[0].dados)).dados || {}; return { clientes: d.clientes || [], vendas: d.vendas || [] }; } catch (e) { return { clientes: [], vendas: [] }; }
}

/* calcula o mês de um ou de todos os agendadores. O mês é o do exame. */
async function calcular(clinicaId, mes, usuarioId) {
  const val = await valores(clinicaId);
  const ini = mes + '-01', fim = somaDias(dia(new Date(Date.UTC(+mes.slice(0, 4), +mes.slice(5, 7), 1))), -1);
  const params = [clinicaId, ini, fim];
  let filtro = '';
  if (usuarioId) { params.push(usuarioId); filtro = ' AND a.usuario_id=$4'; }
  const ex = await pool.query(
    `SELECT a.id, a.usuario_id, a.data_hora, p.nome_completo, p.cpf, p.telefone, u.nome AS agendador, a.venda_resultado
       FROM agendamentos a JOIN pacientes p ON p.id=a.paciente_id JOIN usuarios u ON u.id=a.usuario_id
      WHERE a.clinica_id=$1 AND a.status='realizado' AND a.usuario_id IS NOT NULL
        AND a.data_hora::date BETWEEN $2 AND $3 AND u.papel='atendente'${filtro}
      ORDER BY a.data_hora`, params);
  const oco = await blocoOco(clinicaId);
  const porCpf = new Map(), porTel = new Map(), porNome = new Map();
  for (const c of oco.clientes) {
    const cpf = so(c.cpf), tel = so(c.telefone).slice(-8), nome = semAcento(c.nome);
    if (cpf.length === 11) porCpf.set(cpf, c.id);
    if (tel.length === 8) (porTel.get(tel) || porTel.set(tel, []).get(tel)).push(c);
    if (nome) (porNome.get(nome) || porNome.set(nome, []).get(nome)).push(c.id);
  }
  const vendasPorCliente = new Map();
  for (const v of oco.vendas) (vendasPorCliente.get(v.clienteId) || vendasPorCliente.set(v.clienteId, []).get(v.clienteId)).push(v);
  const usadas = new Set(), por = new Map();
  for (const a of ex.rows) {
    let cpf = ''; try { cpf = so(cripto.decifrar(a.cpf)); } catch (e) {}
    const tel = so(a.telefone).slice(-8), nome = semAcento(a.nome_completo), primeiro = nome.split(' ')[0];
    let cliId = cpf.length === 11 ? porCpf.get(cpf) : undefined;
    if (cliId === undefined && tel.length === 8) { const l = (porTel.get(tel) || []).filter((c) => semAcento(c.nome).split(' ')[0] === primeiro); if (l.length === 1) cliId = l[0].id; }
    if (cliId === undefined) { const l = porNome.get(nome) || []; if (l.length === 1) cliId = l[0]; }
    const d0 = dia(a.data_hora), d1 = somaDias(d0, JANELA_DIAS);
    const k = String(a.usuario_id);
    if (!por.has(k)) por.set(k, { usuario_id: k, agendador: a.agendador, exames: [], vendas: [] });
    const g = por.get(k);
    /* v4.9.64: cada paciente vale um valor só. Comprou: o valor da compra (o maior, se comprou mais de uma vez).
       Não comprou nada: o valor do exame. */
    let melhor = null;
    for (const v of (cliId !== undefined ? vendasPorCliente.get(cliId) || [] : [])) {
      const dv = String(v.data || '').slice(0, 10);
      if (usadas.has(v.id) || dv < d0 || dv > d1) continue;
      const t = tipoVenda(v); if (!t) continue;
      const valor = t === 'completo' ? val.completo : val.parcial;
      if (!melhor || valor > melhor.valor) melhor = { id: v.id, data: dv, exame: d0, paciente: nomeCurto(a.nome_completo), tipo: t, valor };
    }
    /* v4.9.99: o que foi marcado na folha do dia vale mais. Marcado "não comprou" e depois comprou na ótica (voltou): vale a compra. */
    const mv = a.venda_resultado;
    if (mv === 'lente' || mv === 'armacao' || mv === 'completo') {
      const valorM = mv === 'completo' ? val.completo : val.parcial;
      if (melhor) usadas.add(melhor.id);
      g.vendas.push(melhor && melhor.valor > valorM ? { data: melhor.data, exame: d0, paciente: melhor.paciente, tipo: melhor.tipo, valor: melhor.valor, marcado: true }
        : { data: d0, exame: d0, paciente: nomeCurto(a.nome_completo), tipo: mv, valor: valorM, marcado: true });
      continue;
    }
    if (melhor && mv === 'nao') melhor.voltou = true;
    if (melhor) { usadas.add(melhor.id); delete melhor.id; g.vendas.push(melhor); }
    else g.exames.push({ data: d0, paciente: nomeCurto(a.nome_completo), valor: val.exame });
  }
  const lista = [...por.values()].map((g) => ({ ...g, total_exames: g.exames.reduce((s, x) => s + x.valor, 0), total_vendas: g.vendas.reduce((s, x) => s + x.valor, 0), total: g.exames.reduce((s, x) => s + x.valor, 0) + g.vendas.reduce((s, x) => s + x.valor, 0) }));
  return { mes, valores: val, janela_dias: JANELA_DIAS, agendadores: lista };
}

router.get('/', async (req, res) => {
  const mes = MES.test(String(req.query.mes || '')) ? req.query.mes : new Date(Date.now() - 3 * 3600000).toISOString().slice(0, 7);
  res.setHeader('Cache-Control', 'no-store');
  if (req.usuario.papel === 'atendente') {
    const r = await calcular(req.usuario.clinicaId, mes, req.usuario.usuarioId);
    const meu = r.agendadores[0] || { exames: [], vendas: [], total_exames: 0, total_vendas: 0, total: 0 };
    return res.json({ mes, valores: r.valores, janela_dias: r.janela_dias, ...meu });
  }
  if (req.usuario.papel !== 'admin') return res.status(403).json({ erro: 'Seu acesso não permite abrir essa parte do sistema.' });
  res.json(await calcular(req.usuario.clinicaId, mes, null));
});

router.put('/valores', exigirAdmin, async (req, res) => {
  const n = (x) => { const v = Number(String(x).replace(',', '.')); return Number.isFinite(v) && v >= 0 && v <= 10000 ? Math.round(v * 100) / 100 : null; };
  const completo = n(req.body.completo), parcial = n(req.body.parcial), exame = n(req.body.exame);
  if (completo === null || parcial === null || exame === null) return res.status(400).json({ erro: 'Valores inválidos.' });
  await pool.query(`UPDATE clinicas SET comissao_opcao_b=$1, comissao_opcao_a=$2, ganho_exame=$3 WHERE id=$4`, [completo, parcial, exame, req.usuario.clinicaId]);
  res.json(await valores(req.usuario.clinicaId));
});

module.exports = router;
