require('dotenv').config();
const express = require('express');
require('express-async-errors'); // erro dentro de rota assíncrona vira resposta 500, em vez de deixar o pedido travado
const cors = require('cors');
const path = require('path');

// no ar, sem segredo próprio qualquer pessoa conseguiria forjar um login: não deixa ligar
if (process.env.NODE_ENV === 'production' && !process.env.JWT_SECRET) {
  console.error('ERRO: defina a variável JWT_SECRET antes de ligar o sistema no ar.');
  process.exit(1);
}

const app = express();
app.set('trust proxy', 1); // atrás do Render/Railway, pra enxergar o IP real de quem acessa
app.disable('x-powered-by');
app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'same-origin');
  res.setHeader('X-Frame-Options', 'SAMEORIGIN');
  res.setHeader('Permissions-Policy', 'camera=(self), microphone=(self), geolocation=(self)');
  if (process.env.NODE_ENV === 'production') res.setHeader('Strict-Transport-Security', 'max-age=31536000');
  res.setHeader('Content-Security-Policy', "default-src 'self'; script-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net; worker-src 'self' blob:; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com data:; img-src 'self' data: blob: https:; connect-src 'self' https://viacep.com.br https://cdn.jsdelivr.net https://tessdata.projectnaptha.com; object-src 'none'; base-uri 'self'; form-action 'self'; frame-ancestors 'self'");
  next();
});
/* CORS: no ar, só o próprio endereço do sistema (e os que você listar em CORS_ORIGENS, separados por vírgula) */
const origensLiberadas = (process.env.CORS_ORIGENS || '').split(',').map((x) => x.trim()).filter(Boolean);
app.use(cors({
  origin: (origem, cb) => {
    if (!origem || process.env.NODE_ENV !== 'production') return cb(null, true);
    cb(null, origensLiberadas.includes(origem) || origem === process.env.URL_PUBLICA);
  },
}));
app.use(require('compression')()); // comprime texto (app.js tem 400 KB) para abrir mais rápido no celular
app.use(express.json({ limit: '8mb', verify: (req, res, buf) => { req.rawBody = buf; } })); // fotos em base64 podem ser grandes; rawBody confere a assinatura do WhatsApp

/* Defesa contra código escondido em texto (XSS): tira os sinais < e > de todo texto que chega,
   menos de senhas e códigos (v4.9.36). Trava por IP: mais de 30 falhas de login na hora bloqueiam 15 minutos. */
const seguranca = require('./utils/seguranca');
app.use(seguranca.travaIp);
app.use(seguranca.contarFalhas);
app.use(seguranca.limparEntrada);

/* Freio no cadastro público: no máximo 30 envios por hora por aparelho (evita lixo e abuso). */
const enviosPublicos = new Map();
app.use('/public', (req, res, next) => {
  if (req.method !== 'POST') return next();
  const agora = Date.now(), t = enviosPublicos.get(req.ip);
  if (!t || agora - t.inicio > 3600000) enviosPublicos.set(req.ip, { inicio: agora, n: 1 });
  else if (++t.n > 30) return res.status(429).json({ erro: 'Muitos envios seguidos. Tente de novo mais tarde.' });
  next();
});
setInterval(() => { const a = Date.now(); for (const [k, t] of enviosPublicos) if (a - t.inicio > 3600000) enviosPublicos.delete(k); }, 600000).unref();

/* Versão do sistema: vem dos arquivos VERSION e versoes.json do pacote */
const fs = require('fs');
function lerVersao() {
  const raiz = path.join(__dirname, '..');
  let versao = '?', historico = [];
  try { versao = fs.readFileSync(path.join(raiz, 'VERSION'), 'utf8').trim(); } catch (e) {}
  try { historico = JSON.parse(fs.readFileSync(path.join(raiz, 'versoes.json'), 'utf8')); } catch (e) {}
  return { versao, historico };
}
const VERSAO_ATUAL = lerVersao();
/* v4.9.112: versão do app do agendador (o celular compara com ela; mudança só no servidor não pede para atualizar o app) */
try { const m = fs.readFileSync(path.join(__dirname, '..', 'agendador', 'app.js'), 'utf8').match(/const VERSAO_APP = '([^']+)'/); if (m) VERSAO_ATUAL.agendador = m[1]; } catch (e) {}
app.get('/ping', (req, res) => { require('./utils/guardiao').registrarPing(req.get('user-agent')); res.type('text').send('ok'); });
app.get('/health', async (req, res) => {
  require('./utils/guardiao').registrarPing(req.get('user-agent'));
  try { await require('./db/pool').query('SELECT 1'); res.json({ ok: true, versao: VERSAO_ATUAL.versao, criptografia: require('./utils/cripto').ativa() }); }
  catch (e) { res.status(503).json({ ok: false, erro: 'banco indisponível' }); }
});
app.get('/versao', (req, res) => { res.setHeader('Cache-Control', 'no-cache'); res.json(VERSAO_ATUAL); });

/* Páginas do sistema: o próprio servidor entrega, então quem abre o endereço já cai na tela de login.
   Só estes arquivos são públicos (nunca a pasta inteira, pra não expor o .env). */
const RAIZ = path.join(__dirname, '..');
const PAGINAS = ['modulo-agendamento.html', 'app.js', 'app.css', 'cadastro-paciente.html', 'verificar.html', 'status.html', 'guia.html', 'teste-visao.html', 'teste-perto.html', 'optotipo.js', 'qrcode.js', 'clinica.ico', 'manifest.json', 'icone-192.png', 'icone-512.png', 'icone-mascara-512.png', 'icone-180.png', 'aviso-badge.png'];
app.get('/', (req, res) => res.redirect('/modulo-agendamento.html'));
app.get('/sw.js', (req, res, next) => { res.setHeader('Cache-Control', 'no-cache'); res.setHeader('Service-Worker-Allowed', '/'); res.type('application/javascript'); res.sendFile(path.join(RAIZ, 'sw.js'), (err) => err && next()); });
PAGINAS.forEach((f) => app.get('/' + f, (req, res, next) => {
  res.setHeader('Cache-Control', 'no-cache');
  res.sendFile(path.join(RAIZ, f), (err) => err && next());
}));

/* Gestor de vendas: sistema de vendas, ordens de serviço, estoque e caixa. Instalável no celular (fica em /gestor-vendas/).
   A aba Vendas da Clínica abre o mesmo sistema dentro dela. */
const PAGINAS_GESTOR = { 'three.min.js': 'application/javascript', 'zxing.min.js': 'application/javascript' /* v4.9.121: leitor de código de barras */, 'index.html': 'text/html', 'sistema.html': 'text/html', 'manifest.json': 'application/manifest+json', 'sw.js': 'application/javascript', 'mascote.png': 'image/png', 'icone-180.png': 'image/png', 'icone-192.png': 'image/png', 'icone-512.png': 'image/png', 'icone-mascara-512.png': 'image/png' };
app.get(['/gestor-vendas/', '/gestor-vendas/:arq'], (req, res, next) => {
  const arq = req.params.arq || 'index.html';
  if (!PAGINAS_GESTOR[arq]) return next();
  res.setHeader('Cache-Control', 'no-cache');
  res.type(PAGINAS_GESTOR[arq]);
  res.sendFile(path.join(RAIZ, 'gestor-vendas', arq), (err) => err && next());
});

/* v4.9.57: as 4 fotos fixas do simulador de tratamentos (gestor-vendas/cenas/). Sem a foto, a tela desenha uma ilustração. */
const CENAS_SIM = new Set(['rua-noite.jpg', 'sol.jpg', 'computador.jpg', 'leitura.jpg']);
app.get('/gestor-vendas/cenas/:arq', (req, res) => {
  if (!CENAS_SIM.has(req.params.arq)) return res.status(404).end();
  res.setHeader('Cache-Control', 'public, max-age=86400');
  res.type('image/jpeg');
  res.sendFile(path.join(RAIZ, 'gestor-vendas', 'cenas', req.params.arq), (err) => err && !res.headersSent && res.status(404).end());
});

/* v4.9.98: reconhecedor de rosto do medidor de montagem (face-api, licença MIT), roda no aparelho, sem mandar a foto para fora. */
const ROSTO_ARQ = { 'face-api.js': 'application/javascript', 'tiny_face_detector_model-weights_manifest.json': 'application/json', 'tiny_face_detector_model.bin': 'application/octet-stream', 'face_landmark_68_model-weights_manifest.json': 'application/json', 'face_landmark_68_model.bin': 'application/octet-stream', 'LICENSE-face-api.txt': 'text/plain' };
app.get('/gestor-vendas/rosto/:arq', (req, res) => {
  const tipo = ROSTO_ARQ[req.params.arq]; if (!tipo) return res.status(404).end();
  res.setHeader('Cache-Control', 'public, max-age=604800');
  res.type(tipo);
  res.sendFile(path.join(RAIZ, 'gestor-vendas', 'rosto', req.params.arq), (err) => err && !res.headersSent && res.status(404).end());
});

/* Agendador offline: página própria e leve, instalável (fica em /agendador/) */
const PAGINAS_AGENDADOR = { 'index.html': 'text/html', 'app.js': 'application/javascript', 'manifest.json': 'application/manifest+json', 'sw.js': 'application/javascript', 'mascote.png': 'image/png', 'icone-180.png': 'image/png', 'icone-192.png': 'image/png', 'icone-512.png': 'image/png', 'icone-mascara-512.png': 'image/png' };
app.get(['/agendador/', '/agendador/:arq'], (req, res, next) => {
  const arq = req.params.arq || 'index.html';
  if (!PAGINAS_AGENDADOR[arq]) return next();
  res.setHeader('Cache-Control', 'no-cache');
  res.type(PAGINAS_AGENDADOR[arq]);
  res.sendFile(path.join(RAIZ, 'agendador', arq), (err) => err && next());
});

/* dados de paciente nunca ficam guardados no navegador nem em intermediários */
app.use((req, res, next) => { res.setHeader('Cache-Control', 'no-store'); next(); });

app.use('/whatsapp', require('./routes/whatsappWebhook'));
app.use('/auth', require('./routes/auth'));
app.use('/auth', require('./routes/auth2'));
app.use('/public', require('./routes/public'));
app.use('/integracao/:slug', require('./routes/integracao'));
app.use('/pacientes', require('./routes/pacientes'));
app.use('/agendamentos', require('./routes/agendamentos'));
app.use('/agendas', require('./routes/agendas'));
app.use('/envios', require('./routes/envios'));
app.use('/cadastros', require('./routes/cadastros'));
app.use('/financeiro', require('./routes/financeiro'));
// venda de óculos, comissão e pós-venda saíram da clínica: ficam só no OCO (as tabelas antigas continuam no banco)
app.use('/posexame', require('./routes/posexame'));
/* v4.9.127: foto do dia a dia do simulador de lentes, gerada pelo Nano Banana Pro */
app.use('/gestor-vendas-api/cenas-ia', require('./routes/cenasIA'));
app.use('/gestor-vendas-api', require('./routes/gestorVendas'));
app.use('/tipos-atendimento', require('./routes/tiposAtendimento'));
app.use('/unidades', require('./routes/unidades'));
app.use('/feriados-locais', require('./routes/feriados'));
app.use('/lista-espera', require('./routes/listaEspera'));
app.use('/agendador-offline', require('./routes/agendadorOffline'));
app.use('/receitas', require('./routes/receitas'));
app.use('/prontuarios', require('./routes/prontuarios'));
app.use('/leitura', require('./routes/leitura'));
app.use('/conversas-clinica', require('./routes/conversasClinica')); /* v4.9.80 */
app.use('/doc-links', require('./routes/docLinks').privado); /* v4.9.87: link da receita para o paciente */
app.use('/d', require('./routes/docLinks').publico);
app.use('/ia', require('./routes/ia'));
app.use('/testes-visao', require('./routes/testesVisao'));
app.use('/clinica', require('./routes/clinica'));
app.use('/atualizacao', require('./routes/atualizacao'));
app.use('/vigia', require('./routes/vigia'));
app.use(['/auditoria', '/api/auditoria'], require('./routes/auditoria'));
app.use('/conversas', require('./routes/conversas'));
app.use('/push', require('./routes/push'));
app.use('/chamadas', require('./routes/chamadas'));
app.use('/ganhos', require('./routes/ganhos')); // v4.9.64 ganhos do agendador
app.use('/venda-exame', require('./routes/vendaExame')); // v4.9.99 venda marcada na folha do dia e acerto da comissão
app.use('/fin-pessoal', require('./routes/finPessoal')); // v4.9.100 Minha planilha (só o Master, com senha separada)
app.use('/senha-regra', require('./routes/senhaRegra')); // v4.9.71 senha do dia e encaixe
app.use('/pastas-exames', require('./routes/pastasExames')); // v4.9.73 pastas de exames por cidade
app.use('/aparelhos', require('./routes/aparelhos'));
app.use('/relatorios', require('./routes/relatorios'));
app.use('/optotipo', require('./routes/optotipo'));

app.use((req, res) => res.status(404).json({ erro: 'Rota não encontrada.' }));
app.use((err, req, res, next) => {
  /* erro de quem chamou (e não do servidor): responde 4xx em vez de 500 */
  if (err && err.type === 'entity.too.large') return res.status(413).json({ erro: 'Arquivo ou texto grande demais.' });
  if (err && err.type === 'entity.parse.failed') return res.status(400).json({ erro: 'Pedido em formato inválido.' });
  if (err && ['22P02', '22003', '22007', '22008', '22001'].includes(err.code)) return res.status(400).json({ erro: 'Dado inválido no pedido.' });
  const cod = require('crypto').randomBytes(3).toString('hex');
  console.error(`[erro ${cod}] ${req.method} ${String(req.originalUrl).split('?')[0]}`, err);
  res.status(500).json({ erro: `Erro interno do servidor. Código ${cod}.` });
});

// um erro numa rota não pode derrubar o sistema inteiro
process.on('unhandledRejection', (e) => console.error('Erro não tratado:', e));

const PORTA = process.env.PORT || 3000;
/* v4.9.38: ao publicar versão nova, o Render avisa (SIGTERM) antes de desligar.
   O servidor para de aceitar pedidos novos, termina os que estão no meio e fecha o banco com calma. */
let servidor = null;
process.on('SIGTERM', () => {
  console.log('Desligando com calma: terminando os pedidos em andamento.');
  setTimeout(() => process.exit(0), 10000).unref();
  if (!servidor) return process.exit(0);
  servidor.close(() => require('./db/pool').end().catch(() => {}).finally(() => process.exit(0)));
  if (servidor.closeIdleConnections) servidor.closeIdleConnections();
});
require('./db/migrar')()
  .catch((e) => console.error('Aviso: não consegui ajustar o banco automaticamente.', e.message))
  .then(() => require('./utils/protegerExistentes')({ reescrever: !!process.env.CHAVE_CRIPTOGRAFIA_ANTIGA }))
  .then((r) => r && (r.prontuarios || r.fotos || r.cpfs) && console.log(`Dados protegidos com a chave: ${r.prontuarios} prontuário(s), ${r.fotos} paciente(s) com foto, ${r.cpfs} CPF(s).`))
  .catch((e) => console.error('Aviso: não consegui proteger os dados antigos.', e.message))
  .then(() => require('./utils/configServidor').carregar())
  .catch((e) => console.error('Aviso: não consegui ler as configurações de e-mail do sistema.', e.message))
  .then(() => require('./utils/recuperarAcesso')())
  .catch((e) => console.error('Aviso: recuperação de acesso falhou.', e.message))
  .finally(() => { servidor = app.listen(PORTA, () => { console.log(`API da agenda, versão ${VERSAO_ATUAL.versao}, rodando na porta ${PORTA}`); require('./utils/lembretes').iniciar(); require('./utils/backupAuto').iniciar(); require('./utils/guardiao').iniciar(); require('./utils/vigia').iniciar(); require('./utils/ocoEspelho').iniciar(); require('./utils/auditoriaVigia').iniciar(); require('./utils/cobrancaLembretes').iniciar(); setTimeout(() => require('./routes/agendas').passarTodasPara15UmaVez(), 8000); /* v4.9.120 */ }); });
