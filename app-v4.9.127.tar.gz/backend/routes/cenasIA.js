const express = require('express');
const pool = require('../db/pool');
const { exigirLogin } = require('../middleware/auth');

/* v4.9.127: foto do dia a dia para o simulador de lentes, gerada pelo Nano Banana Pro (gerador de imagens do Gemini).
   A foto não tem dado de cliente: é uma cena inventada (rua lá longe, computador no meio, leitura embaixo).
   Fica guardada no banco, uma por clínica e por cena. O vendedor só vê; quem gera é o gestor ou o administrador. */
const router = express.Router();
router.use(exigirLogin);
router.use((req, res, next) => {
  if (req.usuario.papel !== 'gestor' && req.usuario.papel !== 'admin') return res.status(403).json({ erro: 'Esta área é do gestor de vendas.' });
  next();
});

const MODELOS = [process.env.GEMINI_IMAGEM_MODELO, 'gemini-3-pro-image-preview', 'gemini-2.5-flash-image'].filter(Boolean);
const NOME_MODELO = { 'gemini-3-pro-image-preview': 'Nano Banana Pro', 'gemini-2.5-flash-image': 'Nano Banana' };

const CENAS = {
  multifocal: 'Foto realista, horizontal, proporção 3:2, vista em primeira pessoa de alguém sentado a uma mesa de trabalho de uma loja, junto de uma janela grande. '
    + 'A imagem tem três faixas bem definidas de cima para baixo. '
    + 'Faixa de cima (40% da altura): pela janela, uma rua de cidade pequena do interior de Goiás num dia claro, casas simples coloridas, árvores e, no centro, uma placa verde de trânsito escrita "CENTRO 2 km" em letras brancas grandes. '
    + 'Faixa do meio (25% da altura): um monitor de computador no centro da mesa, de frente, mostrando uma tabela simples com as colunas "Produto" e "Preço" e valores em reais. '
    + 'Faixa de baixo (35% da altura): bem perto, um livro aberto com texto em português legível e, ao lado, uma mão segurando um celular com uma conversa de mensagens. '
    + 'Tudo nítido, luz natural, cores reais. Sem rostos de pessoas, sem logotipos, sem marcas de produtos ou aplicativos, sem nomes de pessoas.',
};

async function tabela() {
  await pool.query(`CREATE TABLE IF NOT EXISTS oco_cenas_ia (
    clinica_id UUID NOT NULL, cena VARCHAR(40) NOT NULL, mime VARCHAR(40) NOT NULL, imagem BYTEA NOT NULL,
    modelo VARCHAR(80), criado_em TIMESTAMP DEFAULT now(), PRIMARY KEY (clinica_id, cena))`);
}
let pronta = null;
router.use((req, res, next) => { (pronta = pronta || tabela()).then(() => next(), (e) => { pronta = null; next(e); }); });

router.get('/', async (req, res) => {
  const r = await pool.query(`SELECT cena, modelo, criado_em, length(imagem) AS tamanho FROM oco_cenas_ia WHERE clinica_id=$1`, [req.usuario.clinicaId]);
  res.setHeader('Cache-Control', 'no-store');
  res.json({ cenas: r.rows, ia: !!process.env.GEMINI_API_KEY });
});

router.get('/:cena', async (req, res) => {
  const r = await pool.query(`SELECT mime, imagem FROM oco_cenas_ia WHERE clinica_id=$1 AND cena=$2`, [req.usuario.clinicaId, String(req.params.cena)]);
  if (!r.rows.length) return res.status(404).json({ erro: 'Essa foto ainda não foi gerada.' });
  res.setHeader('Content-Type', r.rows[0].mime); res.setHeader('Cache-Control', 'private, max-age=86400');
  res.end(r.rows[0].imagem);
});

router.post('/:cena/gerar', async (req, res) => {
  const cena = String(req.params.cena);
  if (!CENAS[cena]) return res.status(400).json({ erro: 'Cena desconhecida.' });
  if ((req.usuario.permissoes || []).includes('oco_consulta')) return res.status(403).json({ erro: 'Seu perfil é Consulta: você vê tudo, mas não muda nada.' });
  if (!process.env.GEMINI_API_KEY) return res.status(503).json({ erro: 'A IA não está ligada. Falta colocar a chave GEMINI_API_KEY no Render.', semIA: true });
  const base = (process.env.GEMINI_API_BASE || 'https://generativelanguage.googleapis.com').replace(/\/$/, '');
  const erros = [];
  for (const modelo of MODELOS) {
    try {
      const ctrl = new AbortController(); const t = setTimeout(() => ctrl.abort(), 120000);
      const r = await fetch(`${base}/v1beta/models/${encodeURIComponent(modelo)}:generateContent`, {
        method: 'POST', signal: ctrl.signal,
        headers: { 'content-type': 'application/json', 'x-goog-api-key': process.env.GEMINI_API_KEY },
        body: JSON.stringify({ contents: [{ role: 'user', parts: [{ text: CENAS[cena] }] }], generationConfig: { responseModalities: ['IMAGE'], imageConfig: { aspectRatio: '3:2' } } }),
      }).finally(() => clearTimeout(t));
      const d = await r.json().catch(() => ({}));
      if (!r.ok) { erros.push(`${modelo}: ${r.status} ${(d.error && d.error.message || '').slice(0, 160)}`); continue; }
      const parte = ((d.candidates && d.candidates[0] && d.candidates[0].content && d.candidates[0].content.parts) || []).find((p) => p.inlineData && p.inlineData.data);
      if (!parte) { erros.push(`${modelo}: veio sem imagem`); continue; }
      const mime = /^image\/(png|jpeg|webp)$/.test(parte.inlineData.mimeType) ? parte.inlineData.mimeType : 'image/png';
      const buf = Buffer.from(parte.inlineData.data, 'base64');
      if (buf.length < 1000 || buf.length > 15 * 1024 * 1024) { erros.push(`${modelo}: imagem de tamanho estranho`); continue; }
      await pool.query(`INSERT INTO oco_cenas_ia (clinica_id, cena, mime, imagem, modelo, criado_em) VALUES ($1,$2,$3,$4,$5,now())
        ON CONFLICT (clinica_id, cena) DO UPDATE SET mime=EXCLUDED.mime, imagem=EXCLUDED.imagem, modelo=EXCLUDED.modelo, criado_em=now()`,
        [req.usuario.clinicaId, cena, mime, buf, modelo]);
      return res.json({ ok: true, cena, modelo, nome: NOME_MODELO[modelo] || modelo });
    } catch (e) { erros.push(`${modelo}: ${e.name === 'AbortError' ? 'demorou demais' : e.message}`); }
  }
  console.error('Foto do simulador pela IA: ' + erros.join(' | '));
  const cobranca = erros.some((x) => /\b(429|403|400)\b/.test(x) && /quota|billing|free|paid|limit|permission/i.test(x));
  res.status(502).json({ erro: cobranca
    ? 'O Google não liberou o gerador de imagens para esta chave. O Nano Banana Pro precisa do faturamento ligado na conta do Google AI Studio.'
    : 'Não consegui gerar a foto agora. Tente de novo em alguns minutos.', detalhe: erros.join(' | ').slice(0, 600) });
});

module.exports = router;
