const pool = require('../db/pool');

/* v4.9.71: senha do dia e regra de chegada.
   A senha segue a ordem dos horários do dia, em cada cidade: quem marcou às 8h é 01.
   O paciente chega alguns minutos antes. Passou do prazo de atraso, vira encaixe e é atendido no primeiro horário livre. */
const SQL_SENHA = (a) => `(SELECT s.n FROM (SELECT b.id, ROW_NUMBER() OVER (PARTITION BY COALESCE(b.unidade_id::text,''), b.data_hora::date ORDER BY b.data_hora, b.criado_em, b.id) AS n
  FROM agendamentos b WHERE b.clinica_id=${a}.clinica_id AND b.status<>'cancelado' AND COALESCE(b.com_senha,TRUE) AND b.data_hora::date=${a}.data_hora::date) s WHERE s.id=${a}.id AND COALESCE(${a}.com_senha,TRUE))`;

async function regraDaClinica(clinicaId) {
  const r = await pool.query(`SELECT COALESCE(senha_ligada,TRUE) AS ligada, COALESCE(senha_antecedencia_min,10) AS antecedencia, COALESCE(senha_tolerancia_min,5) AS tolerancia FROM clinicas WHERE id=$1`, [clinicaId]);
  const c = r.rows[0] || {};
  return { ligada: c.ligada !== false, antecedencia: Number(c.antecedencia ?? 10), tolerancia: Number(c.tolerancia ?? 5) };
}
const pad2 = (n) => String(n).padStart(2, '0');
function somaMin(hhmm, m) { const [h, mi] = String(hhmm).split(':').map(Number); const t = ((h * 60 + mi + m) % 1440 + 1440) % 1440; return `${pad2(Math.floor(t / 60))}:${pad2(t % 60)}`; }
/* texto da regra para a mensagem ao paciente */
function textoRegra(dataHora, senha, cfg, curto) {
  if (!cfg || !cfg.ligada || !senha) return '';
  const hora = String(dataHora).replace(' ', 'T').slice(11, 16);
  const chegar = somaMin(hora, -cfg.antecedencia), limite = somaMin(hora, cfg.tolerancia);
  if (curto) return ` Sua senha é ${pad2(senha)}. Chegue às ${chegar}.`;
  return ` Sua senha é ${pad2(senha)}. Chegue ${cfg.antecedencia} minutos antes, às ${chegar}. Se chegar depois das ${limite}, você é atendido como encaixe, no primeiro horário livre. O horário pode mudar por imprevistos.`;
}
/* minutos de atraso entre a chegada (agora, Brasília) e o horário marcado */
function minutosDeAtraso(dataHora, agoraIso) {
  const a = new Date(String(dataHora).replace(' ', 'T').slice(0, 16) + ':00Z').getTime();
  const b = new Date(String(agoraIso).slice(0, 16) + ':00Z').getTime();
  return Math.round((b - a) / 60000);
}
module.exports = { SQL_SENHA, regraDaClinica, textoRegra, minutosDeAtraso, pad2 };

/* v4.9.126: regra da senha de entrada de volta (o arquivo da senha do dia, na 4.9.71, ficou por cima dela).
   Sem ela, criar usuário, trocar senha, "esqueci a senha" e a primeira configuração davam erro.
   Regra: no mínimo 10 caracteres, com letra e número. Vale para senhas novas. */
function validarSenha(s) {
  const t = String(s || '');
  if (t.length < 10) return 'A senha precisa ter pelo menos 10 caracteres.';
  if (!/[A-Za-z]/.test(t) || !/[0-9]/.test(t)) return 'A senha precisa ter letras e números.';
  return null;
}
module.exports.validarSenha = validarSenha;
