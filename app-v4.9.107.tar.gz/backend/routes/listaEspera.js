const express = require('express');
const { rotulo, cidade: cidadeSql } = require('../utils/rotulo');
const pool = require('../db/pool');
const { exigirLogin, cidadeEscolhida } = require('../middleware/auth');
const { telefoneValido } = require('../utils/validar');

const router = express.Router();
router.use(exigirLogin);

const FORMATO_DIA = /^\d{4}-\d{2}-\d{2}$/;
const diaIso = (d) => (d instanceof Date ? d.toISOString() : String(d || '')).slice(0, 10);
const filtro = (req, params) => { if (!req.usuario.unidadeId) return ''; params.push(req.usuario.unidadeIds); return ` AND (l.unidade_id=ANY($${params.length}) OR l.unidade_id IS NULL)`; };

/* v4.9.107: ?data=AAAA-MM-DD e ?unidade_id= mostram só a espera daquele dia da agenda */
router.get('/', async (req, res) => {
  const params = [req.usuario.clinicaId];
  let f = filtro(req, params);
  if (FORMATO_DIA.test(String(req.query.data || ''))) { params.push(String(req.query.data)); f += ` AND l.data=$${params.length}::date`; }
  if (req.query.unidade_id) { params.push(String(req.query.unidade_id)); f += ` AND l.unidade_id=$${params.length}::uuid`; }
  const r = await pool.query(
    `SELECT l.id, l.nome, l.telefone, l.observacao, l.unidade_id, ${rotulo('u')} AS cidade, l.data, l.criado_por, l.criado_em
     FROM lista_espera l LEFT JOIN unidades u ON u.id = l.unidade_id
     WHERE l.clinica_id=$1 AND l.resolvido_em IS NULL${f} ORDER BY l.data NULLS LAST, l.criado_em`, params);
  res.setHeader('Cache-Control', 'no-store');
  res.json(r.rows.map((x) => ({ ...x, data: x.data ? diaIso(x.data) : null })));
});

router.post('/', async (req, res) => {
  const nome = String(req.body.nome || '').replace(/[<>]/g, '').replace(/\s+/g, ' ').trim().slice(0, 150);
  if (nome.length < 3) return res.status(400).json({ erro: 'Informe o nome.' });
  const telefone = String(req.body.telefone || '').trim().slice(0, 30);
  const data = req.body.data ? String(req.body.data) : null;
  if (data && !FORMATO_DIA.test(data)) return res.status(400).json({ erro: 'Dia em formato inválido.' });
  // espera de um dia: o telefone é obrigatório, para chamar a pessoa quando abrir a vaga
  if (data && !telefoneValido(telefone)) return res.status(400).json({ erro: 'Telefone inválido. Escreva o DDD e o número.' });
  const unidade_id = cidadeEscolhida(req.usuario, req.body.unidade_id);
  if (data && !unidade_id) return res.status(400).json({ erro: 'Escolha a cidade.' });
  if (unidade_id) {
    const u = await pool.query(`SELECT 1 FROM unidades WHERE id=$1 AND clinica_id=$2`, [unidade_id, req.usuario.clinicaId]);
    if (!u.rows.length) return res.status(400).json({ erro: 'Cidade inválida.' });
  }
  if (data) {
    const ag = await pool.query(`SELECT 1 FROM agendas WHERE clinica_id=$1 AND unidade_id=$2 AND data=$3::date AND ativa=TRUE LIMIT 1`, [req.usuario.clinicaId, unidade_id, data]);
    if (!ag.rows.length) return res.status(400).json({ erro: 'Não há agenda aberta nesse dia nessa cidade.' });
    const dig = telefone.replace(/\D/g, '');
    const ja = await pool.query(`SELECT 1 FROM lista_espera WHERE clinica_id=$1 AND unidade_id=$2 AND data=$3::date AND resolvido_em IS NULL
      AND regexp_replace(COALESCE(telefone,''),'\\D','','g')=$4 AND lower(nome)=lower($5) LIMIT 1`, [req.usuario.clinicaId, unidade_id, data, dig, nome]);
    if (ja.rows.length) return res.status(409).json({ erro: 'Essa pessoa já está na lista de espera desse dia.' });
  }
  const r = await pool.query(
    `INSERT INTO lista_espera (clinica_id, unidade_id, nome, telefone, observacao, data, criado_por, usuario_id) VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING id`,
    [req.usuario.clinicaId, unidade_id, nome, telefone || null, String(req.body.observacao || '').slice(0, 300) || null, data,
     String(req.usuario.nome || '').slice(0, 150) || null, req.usuario.usuarioId || null]);
  res.status(201).json({ id: r.rows[0].id });
});

/* some da lista (agendado ou desistiu) */
router.delete('/:id', async (req, res) => {
  const params = [req.params.id, req.usuario.clinicaId];
  let f = '';
  if (req.usuario.unidadeId) { params.push(req.usuario.unidadeIds); f = ` AND (unidade_id=ANY($3) OR unidade_id IS NULL)`; }
  const r = await pool.query(`UPDATE lista_espera SET resolvido_em=NOW() WHERE id=$1 AND clinica_id=$2 AND resolvido_em IS NULL${f} RETURNING id`, params);
  if (!r.rows.length) return res.status(404).json({ erro: 'Não encontrado.' });
  res.json({ ok: true });
});

module.exports = router;
