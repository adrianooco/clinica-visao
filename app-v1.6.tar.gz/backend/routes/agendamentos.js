const express = require('express');
const pool = require('../db/pool');
const { exigirLogin } = require('../middleware/auth');

const router = express.Router();
router.use(exigirLogin);

const STATUS_VALIDOS = ['agendado', 'confirmado', 'realizado', 'cancelado', 'faltou'];
const FORMATO_DATA_HORA = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}(:\d{2})?$/;
const MSG_CONFLITO = 'Esse horário conflita com outro agendamento já existente nessa cidade (considerando duração e intervalo).';

/* agora, no horário de Brasília, no mesmo formato do campo data_hora */
function agoraBrasilia() {
  const p = Object.fromEntries(new Intl.DateTimeFormat('en-CA', { timeZone: 'America/Sao_Paulo', year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', hour12: false })
    .formatToParts(new Date()).map((x) => [x.type, x.value]));
  return `${p.year}-${p.month}-${p.day}T${p.hour === '24' ? '00' : p.hour}:${p.minute}`;
}

/* a cidade informada pelo admin precisa ser desta clínica */
async function unidadeValida(clinicaId, unidadeId) {
  if (!unidadeId) return true;
  const r = await pool.query(`SELECT 1 FROM unidades WHERE id=$1 AND clinica_id=$2`, [unidadeId, clinicaId]);
  return r.rows.length > 0;
}

/* o mesmo paciente não fica com dois exames ativos no mesmo dia */
async function pacienteJaTemNoDia(clinicaId, pacienteId, dataHora, ignorarId) {
  const r = await pool.query(
    `SELECT 1 FROM agendamentos WHERE clinica_id=$1 AND paciente_id=$2 AND status <> 'cancelado' AND data_hora::date = $3::timestamp::date AND ($4::uuid IS NULL OR id <> $4) LIMIT 1`,
    [clinicaId, pacienteId, dataHora, ignorarId || null]);
  return r.rows.length > 0;
}

/* O agendador (atendente) só marca horários que o admin abriu na agenda de exame de vista.
   Devolve o tipo de atendimento da agenda, ou null se o horário não existe. */
async function horarioDoEvento(clinicaId, unidadeId, dataHora) {
  if (!unidadeId) return null;
  const r = await pool.query(
    `SELECT a.tipo_atendimento_id, a.local FROM agendas a JOIN tipos_atendimento t ON t.id = a.tipo_atendimento_id
     WHERE a.clinica_id=$1 AND a.unidade_id=$2 AND a.ativa=TRUE
       AND a.data = $3::timestamp::date
       AND $3::timestamp::time >= a.hora_inicio
       AND $3::timestamp::time + (t.duracao_min * INTERVAL '1 minute') <= a.hora_fim
       AND (EXTRACT(EPOCH FROM ($3::timestamp::time - a.hora_inicio)) / 60)::int % (t.duracao_min + t.buffer_min) = 0
     LIMIT 1`,
    [clinicaId, unidadeId, dataHora]
  );
  return r.rows[0] || null;
}

/* o paciente precisa ser desta clínica (e da cidade do usuário, quando ele é restrito a uma) */
async function pacienteValido(req, pacienteId) {
  const params = [pacienteId, req.usuario.clinicaId];
  let extra = '';
  if (req.usuario.unidadeId) { params.push(req.usuario.unidadeId); extra = ' AND (unidade_id=$3 OR unidade_id IS NULL)'; }
  const r = await pool.query(`SELECT 1 FROM pacientes WHERE id=$1 AND clinica_id=$2 AND deletado_em IS NULL${extra}`, params);
  return r.rows.length > 0;
}

function filtroUnidade(req, params, proximoIndice) {
  if (!req.usuario.unidadeId) return { sql: '', params };
  params.push(req.usuario.unidadeId);
  return { sql: ` AND a.unidade_id=$${proximoIndice}`, params };
}

/* lista por intervalo de datas (?de=2026-10-01&ate=2026-10-31) */
router.get('/', async (req, res) => {
  const { de, ate } = req.query;
  const params = [req.usuario.clinicaId, de || null, ate || null];
  const f = filtroUnidade(req, params, 4);
  const r = await pool.query(
    `SELECT a.*, p.nome_completo, t.nome AS tipo_nome, t.cor AS tipo_cor
     FROM agendamentos a
     JOIN pacientes p ON p.id = a.paciente_id
     LEFT JOIN tipos_atendimento t ON t.id = a.tipo_atendimento_id
     WHERE a.clinica_id=$1
       AND ($2::date IS NULL OR a.data_hora::date >= $2)
       AND ($3::date IS NULL OR a.data_hora::date <= $3)
       ${f.sql}
     ORDER BY a.data_hora`,
    f.params
  );
  res.json(r.rows);
});

router.post('/', async (req, res) => {
  const { paciente_id, tipo_atendimento_id, data_hora, local, agendado_por, status, observacoes, otica_parceira_id } = req.body;
  if (!paciente_id || !data_hora) return res.status(400).json({ erro: 'Informe paciente e data/horário.' });
  if (!FORMATO_DATA_HORA.test(String(data_hora))) return res.status(400).json({ erro: 'Data e horário em formato inválido.' });
  if (status && !STATUS_VALIDOS.includes(status)) return res.status(400).json({ erro: 'Situação inválida.' });
  // quem está restrito a uma cidade sempre agenda nessa cidade; admin pode escolher (ou deixar em branco = compartilhado)
  const unidade_id = req.usuario.unidadeId || req.body.unidade_id || null;
  try {
    if (!(await unidadeValida(req.usuario.clinicaId, unidade_id))) return res.status(400).json({ erro: 'Cidade inválida.' });
    if (!(await pacienteValido(req, paciente_id))) return res.status(400).json({ erro: 'Paciente não encontrado.' });
    if (req.usuario.papel === 'atendente') {
      if (String(data_hora).slice(0, 16) < agoraBrasilia()) return res.status(400).json({ erro: 'Esse horário já passou. Escolha um horário a partir de agora.' });
      const slot = await horarioDoEvento(req.usuario.clinicaId, unidade_id, data_hora);
      if (!slot) return res.status(403).json({ erro: 'Esse horário não está aberto na agenda de exame de vista. Peça ao administrador para abrir.' });
      req.body.tipo_atendimento_id = slot.tipo_atendimento_id;
    }
    let oticaValida = null;
    if (otica_parceira_id) {
      const o = await pool.query(`SELECT id FROM oticas_parceiras WHERE id=$1 AND clinica_id=$2 AND ativa=TRUE`, [otica_parceira_id, req.usuario.clinicaId]);
      if (o.rows.length) oticaValida = o.rows[0].id;
    }
    const tipo = await pool.query(`SELECT * FROM tipos_atendimento WHERE id=$1 AND clinica_id=$2`, [req.body.tipo_atendimento_id, req.usuario.clinicaId]);
    if (!tipo.rows.length) return res.status(400).json({ erro: 'Tipo de atendimento inválido.' });
    if (await pacienteJaTemNoDia(req.usuario.clinicaId, paciente_id, data_hora, null)) return res.status(409).json({ erro: 'Esse paciente já tem exame marcado nesse dia. Cancele o anterior ou escolha outro paciente.' });
    const r = await pool.query(
      `INSERT INTO agendamentos (clinica_id, unidade_id, paciente_id, tipo_atendimento_id, usuario_id, data_hora, duracao_min, buffer_min, local, agendado_por, status, observacoes, otica_parceira_id, origem)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,COALESCE($11,'agendado'),$12,$13,$14) RETURNING *`,
      [req.usuario.clinicaId, unidade_id, paciente_id, tipo.rows[0].id, req.usuario.usuarioId, data_hora, tipo.rows[0].duracao_min, tipo.rows[0].buffer_min, local || null, agendado_por || null, status || null, observacoes || null, oticaValida, oticaValida ? 'otica' : 'equipe']
    );
    res.status(201).json(r.rows[0]);
  } catch (e) {
    if (e.code === '23P01') { // exclusion_violation: o próprio banco bloqueou a sobreposição (dentro da mesma cidade)
      return res.status(409).json({ erro: MSG_CONFLITO });
    }
    if (['22007', '22008', '22P02', '23503', '23514'].includes(e.code)) return res.status(400).json({ erro: 'Dados do agendamento inválidos.' });
    console.error(e); res.status(500).json({ erro: 'Erro ao criar agendamento.' });
  }
});

/* troca só a situação (confirmado, realizado, faltou, cancelado), sem mexer no resto */
router.patch('/:id/status', async (req, res) => {
  const { status } = req.body;
  if (!STATUS_VALIDOS.includes(status)) return res.status(400).json({ erro: 'Situação inválida.' });
  const params = [status, req.params.id, req.usuario.clinicaId];
  const f = filtroUnidade(req, params, 4);
  try {
    const r = await pool.query(`UPDATE agendamentos a SET status=$1, atualizado_em=NOW() WHERE id=$2 AND clinica_id=$3${f.sql} RETURNING id, status`, f.params);
    if (!r.rows.length) return res.status(404).json({ erro: 'Agendamento não encontrado.' });
    res.json(r.rows[0]);
  } catch (e) {
    // reativar um cancelado cujo horário já foi ocupado por outro paciente
    if (e.code === '23P01') return res.status(409).json({ erro: 'Esse horário já foi ocupado por outro paciente. Escolha outro horário para esse agendamento.' });
    throw e;
  }
});

router.put('/:id', async (req, res) => {
  const { paciente_id, tipo_atendimento_id, data_hora, local, agendado_por, status, observacoes } = req.body;
  if (!data_hora || !FORMATO_DATA_HORA.test(String(data_hora))) return res.status(400).json({ erro: 'Data e horário em formato inválido.' });
  if (status && !STATUS_VALIDOS.includes(status)) return res.status(400).json({ erro: 'Situação inválida.' });
  try {
    if (!(await pacienteValido(req, paciente_id))) return res.status(400).json({ erro: 'Paciente não encontrado.' });
    if (req.usuario.papel === 'atendente') {
      const slot = await horarioDoEvento(req.usuario.clinicaId, req.usuario.unidadeId, data_hora);
      if (!slot) return res.status(403).json({ erro: 'Esse horário não está aberto na agenda de exame de vista.' });
    }
    const tipo = await pool.query(`SELECT * FROM tipos_atendimento WHERE id=$1 AND clinica_id=$2`, [tipo_atendimento_id, req.usuario.clinicaId]);
    if (!tipo.rows.length) return res.status(400).json({ erro: 'Tipo de atendimento inválido.' });
    if (await pacienteJaTemNoDia(req.usuario.clinicaId, paciente_id, data_hora, req.params.id)) return res.status(409).json({ erro: 'Esse paciente já tem exame marcado nesse dia.' });
    const params = [paciente_id, tipo.rows[0].id, data_hora, tipo.rows[0].duracao_min, tipo.rows[0].buffer_min, local || null, agendado_por || null, status || null, observacoes || null, req.params.id, req.usuario.clinicaId];
    const f = filtroUnidade(req, params, params.length + 1);
    // mudou o dia ou a hora: os lembretes já enviados não valem mais, o paciente recebe os do novo horário
    const r = await pool.query(
      `UPDATE agendamentos a SET paciente_id=$1, tipo_atendimento_id=$2,
        lembrete_confirmacao_enviado = CASE WHEN a.data_hora <> $3::timestamp THEN FALSE ELSE a.lembrete_confirmacao_enviado END,
        lembrete_24h_enviado = CASE WHEN a.data_hora <> $3::timestamp THEN FALSE ELSE a.lembrete_24h_enviado END,
        lembrete_2h_enviado = CASE WHEN a.data_hora <> $3::timestamp THEN FALSE ELSE a.lembrete_2h_enviado END,
        lembrete_pos_consulta_enviado = CASE WHEN a.data_hora <> $3::timestamp THEN FALSE ELSE a.lembrete_pos_consulta_enviado END,
        data_hora=$3, duracao_min=$4, buffer_min=$5,
        local=$6, agendado_por=$7, status=COALESCE($8, a.status), observacoes=$9, atualizado_em=NOW()
       WHERE id=$10 AND clinica_id=$11${f.sql} RETURNING *`,
      f.params
    );
    if (!r.rows.length) return res.status(404).json({ erro: 'Agendamento não encontrado.' });
    res.json(r.rows[0]);
  } catch (e) {
    if (e.code === '23P01') {
      return res.status(409).json({ erro: MSG_CONFLITO });
    }
    if (['22007', '22008', '22P02', '23503', '23514'].includes(e.code)) return res.status(400).json({ erro: 'Dados do agendamento inválidos.' });
    console.error(e); res.status(500).json({ erro: 'Erro ao atualizar agendamento.' });
  }
});

router.delete('/:id', async (req, res) => {
  if (req.usuario.papel === 'atendente') return res.status(403).json({ erro: 'Para liberar o horário, mude a situação para Cancelado.' });
  const params = [req.params.id, req.usuario.clinicaId];
  const f = filtroUnidade(req, params, params.length + 1);
  const r = await pool.query(`DELETE FROM agendamentos a WHERE id=$1 AND clinica_id=$2${f.sql} RETURNING id`, f.params);
  if (!r.rows.length) return res.status(404).json({ erro: 'Agendamento não encontrado.' });
  res.json({ ok: true });
});

module.exports = router;
