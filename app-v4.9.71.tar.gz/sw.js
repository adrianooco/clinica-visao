/* Service worker simples: deixa o app instalável e guarda só a tela de entrada para abrir mais rápido.
   Nada de dados de pacientes passa por aqui: chamadas à API nunca são guardadas. */
const CACHE = 'clinica-visao-casca-v65';
const CASCA = ['/modulo-agendamento.html', '/app.js', '/app.css', '/optotipo.js', '/teste-perto.html', '/qrcode.js', '/icone-192.png?v=2', '/manifest.json', '/gestor-vendas/mascote.png', '/agendador/', '/agendador/app.js', '/agendador/manifest.json'];
self.addEventListener('install', (e) => { e.waitUntil(caches.open(CACHE).then((c) => c.addAll(CASCA)).catch(() => {})); self.skipWaiting(); });
self.addEventListener('activate', (e) => { e.waitUntil(caches.keys().then((ks) => Promise.all(ks.filter((k) => k !== CACHE).map((k) => caches.delete(k)))).then(() => self.clients.claim())); });
self.addEventListener('fetch', (e) => {
  const r = e.request, u = new URL(r.url);
  if (r.method !== 'GET' || u.origin !== location.origin || !CASCA.includes(u.pathname)) return;
  // sempre tenta a versão nova primeiro; sem internet, usa a guardada
  e.respondWith(fetch(r).then((resp) => { const copia = resp.clone(); caches.open(CACHE).then((c) => c.put(r, copia)); return resp; }).catch(() => caches.match(r)));
});

/* v4.9.49: aviso no celular quando chega mensagem nova na conversa. O aviso nunca leva o texto da mensagem. */
self.addEventListener('push', (e) => {
  let d = {};
  try { d = e.data ? e.data.json() : {}; } catch (x) { d = { corpo: e.data ? e.data.text() : '' }; }
  e.waitUntil(self.registration.showNotification(d.titulo || 'Clínica de Visão', {
    body: d.corpo || 'Você tem uma novidade na Clínica.',
    icon: '/icone-192.png?v=2', badge: '/aviso-badge.png', tag: d.tag || 'clinica', renotify: true,
    requireInteraction: /^cham-/.test(d.tag || '') && /ligando/.test(d.corpo || ''), vibrate: /ligando/.test(d.corpo || '') ? [500, 250, 500, 250, 500, 250, 500] : [200],
    data: { url: d.url || '/modulo-agendamento.html' },
  }));
});
self.addEventListener('notificationclick', (e) => {
  e.notification.close();
  const url = new URL((e.notification.data && e.notification.data.url) || '/modulo-agendamento.html', self.location.origin).href;
  e.waitUntil(self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((lista) => {
    const aberta = lista.find((c) => new URL(c.url).pathname === '/modulo-agendamento.html');
    if (aberta) { aberta.postMessage({ tipo: 'abrir', url }); return aberta.focus(); }
    return self.clients.openWindow(url);
  }));
});
