/* Agendador offline da Clínica de Visão.
   Funciona sem internet: baixa os horários livres, guarda pedidos no celular (trancados com PIN) e envia quando a internet volta.
   O servidor sempre decide: horário já ocupado volta como conflito, com outros horários do mesmo dia. */
(function () {
  'use strict';
  const $ = (id) => document.getElementById(id);
  const esc = (v) => String(v == null ? '' : v).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  const MAX_TENTATIVAS_PIN = 8, VALIDADE_PEDIDO_DIAS = 7, BLOQUEIO_MS = 5 * 60 * 1000, DIAS_HORARIOS = 21;

  /* ---------- armazenamento local (IndexedDB) ---------- */
  let _db = null;
  function abrirDb() {
    if (_db) return Promise.resolve(_db);
    return new Promise((ok, falha) => {
      const r = indexedDB.open('agendador-offline', 1);
      r.onupgradeneeded = () => r.result.createObjectStore('kv');
      r.onsuccess = () => { _db = r.result; ok(_db); };
      r.onerror = () => falha(r.error);
    });
  }
  async function kv(modo, chave, valor) {
    const db = await abrirDb();
    return new Promise((ok, falha) => {
      const t = db.transaction('kv', modo === 'get' ? 'readonly' : 'readwrite'), s = t.objectStore('kv');
      const q = modo === 'get' ? s.get(chave) : modo === 'set' ? s.put(valor, chave) : modo === 'del' ? s.delete(chave) : s.clear();
      q.onsuccess = () => ok(q.result);
      q.onerror = () => falha(q.error);
    });
  }
  const kvGet = (k) => kv('get', k), kvSet = (k, v) => kv('set', k, v), kvDel = (k) => kv('del', k), kvLimpar = () => kv('clear');

  /* ---------- criptografia do cofre (PIN → chave AES-GCM) ---------- */
  const enc = new TextEncoder(), dec = new TextDecoder();
  const b64 = (buf) => { let s = ''; const a = new Uint8Array(buf); for (let i = 0; i < a.length; i++) s += String.fromCharCode(a[i]); return btoa(s); };
  const unb64 = (t) => Uint8Array.from(atob(t), (c) => c.charCodeAt(0));
  async function derivar(pin, salt) {
    const base = await crypto.subtle.importKey('raw', enc.encode(pin), 'PBKDF2', false, ['deriveKey']);
    return crypto.subtle.deriveKey({ name: 'PBKDF2', salt, iterations: 200000, hash: 'SHA-256' }, base, { name: 'AES-GCM', length: 256 }, false, ['encrypt', 'decrypt']);
  }
  async function cifrar(chave, obj) {
    const iv = crypto.getRandomValues(new Uint8Array(12));
    const ct = await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, chave, enc.encode(JSON.stringify(obj)));
    return { iv: b64(iv), ct: b64(ct) };
  }
  async function decifrar(chave, p) {
    const pt = await crypto.subtle.decrypt({ name: 'AES-GCM', iv: unb64(p.iv) }, chave, unb64(p.ct));
    return JSON.parse(dec.decode(pt));
  }
  const novoId = () => (crypto.randomUUID ? crypto.randomUUID() : '10000000-1000-4000-8000-100000000000'.replace(/[018]/g, (c) => (c ^ crypto.getRandomValues(new Uint8Array(1))[0] & 15 >> c / 4).toString(16)));

  /* ---------- estado ---------- */
  let chave = null;            // chave do cofre, só na memória
  let dados = null;            // { token, usuario, fila:[], enviados:[] }, só na memória (no disco fica trancado)
  let horarios = { gerado_em: null, horarios: [] };
  let online = navigator.onLine;
  let abaAtual = 'marcar', diaEscolhido = null, unidadeEscolhida = null;
  let sincronizando = false, precisaLogin = false, saiuEm = 0;
  /* Master pode fixar uma cidade neste celular: horários, pendentes e enviados mostram só ela */
  const cidadeFixa = () => (dados && dados.usuario && dados.usuario.papel === 'admin' && dados.cidadeTrabalho) || '';
  const nomeCidadeFixa = () => { const c = (dados && dados.cidades || []).find((x) => x.id === cidadeFixa()); return c ? c.nome : ''; };

  async function salvar() { if (chave && dados) await kvSet('cofre', await cifrar(chave, dados)); }

  /* ---------- rede ---------- */
  /* v4.9.44: número deste aparelho (o mesmo do sistema principal, porque fica no mesmo endereço) */
  function aparelhoId(){ try{ let x = localStorage.getItem('agend_aparelho_id'); if(!x || !/^[A-Za-z0-9_-]{20,100}$/.test(x)){ const a = new Uint8Array(24); crypto.getRandomValues(a); x = btoa(String.fromCharCode.apply(null, a)).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,''); localStorage.setItem('agend_aparelho_id', x); } return x; }catch(e){ return ''; } }
  async function api(caminho, { method = 'GET', body, semToken = false } = {}) {
    const ctl = new AbortController(), t = setTimeout(() => ctl.abort(), 20000);
    try {
      const r = await fetch(caminho, {
        method, signal: ctl.signal, cache: 'no-store',
        headers: { 'Content-Type': 'application/json', ...(!semToken && dados && dados.token ? { Authorization: 'Bearer ' + dados.token } : {}), ...(!semToken && cidadeFixa() ? { 'X-Cidade-Trabalho': cidadeFixa() } : {}) },
        body: body ? JSON.stringify(body) : undefined,
      });
      let j = null; try { j = await r.json(); } catch (e) { /* sem corpo */ }
      setRede(true);
      if (!r.ok) { const e = new Error((j && j.erro) || 'Algo deu errado.'); e.status = r.status; e.corpo = j; throw e; }
      return j;
    } catch (e) {
      if (e.status) throw e;
      setRede(false);
      const x = new Error('Sem conexão com o sistema.'); x.rede = true; throw x;
    } finally { clearTimeout(t); }
  }
  function setRede(v) {
    online = v;
    const c = $('chipRede'); c.textContent = v ? 'Online' : 'Sem internet'; c.classList.toggle('off', !v);
  }

  /* ---------- utilidades de tela ---------- */
  const diaSem = ['dom', 'seg', 'ter', 'qua', 'qui', 'sex', 'sáb'];
  const fmtDia = (iso) => { const [a, m, d] = iso.split('-').map(Number); const w = new Date(Date.UTC(a, m - 1, d)).getUTCDay(); return { sem: diaSem[w], dm: `${String(d).padStart(2, '0')}/${String(m).padStart(2, '0')}` }; };
  const fmtDH = (dh) => { const f = fmtDia(dh.slice(0, 10)); return `${f.sem} ${f.dm} às ${dh.slice(11, 16)}`; };
  const fmtQuando = (iso) => { const d = new Date(iso); return d.toLocaleString('pt-BR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' }); };
  function toast(t) {
    const e = document.createElement('div'); e.className = 'toast'; e.textContent = t; document.body.appendChild(e);
    setTimeout(() => e.remove(), 3200);
  }
  const mascaraTel = (v) => {
    const d = v.replace(/\D/g, '').slice(0, 11);
    if (d.length <= 2) return d ? '(' + d : '';
    if (d.length <= 6) return `(${d.slice(0, 2)}) ${d.slice(2)}`;
    if (d.length <= 10) return `(${d.slice(0, 2)}) ${d.slice(2, 6)}-${d.slice(6)}`;
    return `(${d.slice(0, 2)}) ${d.slice(2, 7)}-${d.slice(7)}`;
  };
  const telOk = (v) => { const d = String(v).replace(/\D/g, ''); return d.length >= 10 && d.length <= 11; };
  const tela = () => $('tela');
  function mostrarAbas(v) { $('abas').classList.toggle('hide', !v); const sb = $('btnSairTopo'); if (sb) { sb.classList.toggle('hide', !v); sb.onclick = sairTudo; } }
  function sheet(html) {
    fecharSheet();
    const s = document.createElement('div'); s.className = 'sheet'; s.id = 'sheet'; s.innerHTML = `<div>${html}</div>`;
    s.addEventListener('click', (e) => { if (e.target === s) fecharSheet(); });
    document.body.appendChild(s); return s;
  }
  function fecharSheet() { const s = $('sheet'); if (s) s.remove(); }

  /* ---------- instalação ---------- */
  let eventoInstalar = null;
  const jaInstalado = () => (window.matchMedia && matchMedia('(display-mode: standalone)').matches) || window.navigator.standalone === true;
  const ehIphone = () => /iphone|ipad|ipod/i.test(navigator.userAgent) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
  window.addEventListener('beforeinstallprompt', (e) => { e.preventDefault(); eventoInstalar = e; if (abaAtual === 'mais' && dados) renderAba(); });
  window.addEventListener('appinstalled', () => { eventoInstalar = null; toast('App instalado.'); });
  async function instalar() {
    if (eventoInstalar) { eventoInstalar.prompt(); try { await eventoInstalar.userChoice; } catch (e) { /* ignorado */ } eventoInstalar = null; return; }
    const p = ehIphone()
      ? ['Abra este endereço no Safari.', 'Toque em Compartilhar, o quadrado com a seta para cima.', 'Toque em Adicionar à Tela de Início.', 'Toque em Adicionar.']
      : ['Abra este endereço no Chrome.', 'Toque nos três pontinhos no canto de cima.', 'Toque em Instalar app ou Adicionar à tela inicial.', 'Confirme.'];
    sheet(`<h2>Instalar o agendador</h2><ol style="padding-left:20px;">${p.map((x) => `<li style="margin:6px 0;">${x}</li>`).join('')}</ol><button class="b1 blk" id="shOk">Entendi</button>`);
    $('shOk').onclick = fecharSheet;
  }

  /* ---------- entrada: login ---------- */
  /* v4.9.28 aproveita o login do sistema principal neste mesmo celular (sem digitar senha de novo) */
  function sessaoDoSistema() {
    try {
      const token = localStorage.getItem('agend_token'), usuario = JSON.parse(localStorage.getItem('agend_usuario') || 'null');
      if (!token || !usuario || !usuario.id || !['atendente', 'admin'].includes(usuario.papel)) return null;
      const p = JSON.parse(atob(token.split('.')[1].replace(/-/g, '+').replace(/_/g, '/')));
      if (!p.exp || p.exp * 1000 < Date.now() + 60000) return null;
      return { token, usuario };
    } catch (e) { return null; }
  }
  function telaLogin(reentrada) {
    mostrarAbas(false);
    tela().innerHTML = `<div class="brand">👁️</div>
      ${!reentrada && sessaoDoSistema() ? `<div class="card"><p class="sub">Você já entrou no sistema neste celular como <b>${esc(sessaoDoSistema().usuario.nome || sessaoDoSistema().usuario.email)}</b>.</p><button class="b1 blk" id="lgSistema">Continuar com essa conta</button></div>` : ''}
      <div class="card"><h2>${reentrada ? 'Entre de novo para enviar' : 'Entrar'}</h2>
      <p class="sub">${reentrada ? 'Seus pedidos continuam guardados no celular. Entre com sua senha para enviá-los.' : 'Entre com o e-mail e a senha que você usa no sistema. É preciso estar com internet nesta primeira vez.'}</p>
      <div id="loginMsg"></div>
      <label for="lgEmail">E-mail</label><input id="lgEmail" type="email" autocomplete="username" autocapitalize="none" value="${esc(reentrada && dados && dados.usuario ? dados.usuario.email : '')}">
      <label for="lgSenha">Senha</label><input id="lgSenha" type="password" autocomplete="current-password">
      <button class="b1 blk" id="lgOk">Entrar</button>
      ${reentrada ? '<button class="b3 blk" id="lgCancela">Agora não</button>' : ''}</div>`;
    if ($('lgSistema')) $('lgSistema').onclick = async () => { const s = sessaoDoSistema(); if (!s) return telaLogin(false); try { await entrou(s, false); } catch (e) { msg(e.message); } };
    const msg = (t, tipo) => { $('loginMsg').innerHTML = t ? `<div class="msg ${tipo || 'erro'}">${esc(t)}</div>` : ''; };
    $('lgOk').onclick = async () => {
      const email = $('lgEmail').value.trim(), senha = $('lgSenha').value;
      if (!email || !senha) return msg('Escreva o e-mail e a senha.');
      $('lgOk').disabled = true; msg('Entrando...', 'aviso');
      try {
        const r = await api('/auth/login', { method: 'POST', body: { email, senha, aparelho: aparelhoId() }, semToken: true });
        if (r.etapa === 'totp') return telaCodigo(r.pendente, reentrada);
        if (r.etapa) { $('lgOk').disabled = false; return msg(r.etapa === 'codigo_email' ? 'Este aparelho é novo para a sua conta. Entre uma vez pelo sistema principal, digite o código do e-mail e depois volte aqui.' : 'Sua conta usa código do celular. Entre pelo sistema principal.'); }
        await entrou(r, reentrada);
      } catch (e) { $('lgOk').disabled = false; msg(e.rede ? 'Sem internet. Conecte e tente de novo.' : e.message); }
    };
    if (reentrada) $('lgCancela').onclick = () => { precisaLogin = false; telaPrincipal(); };
  }
  function telaCodigo(pendente, reentrada) {
    tela().innerHTML = `<div class="brand">🔐</div><div class="card"><h2>Código do celular</h2><p class="sub">Digite os 6 números do aplicativo de código.</p><div id="cdMsg"></div>
      <input id="cdNum" inputmode="numeric" maxlength="6" class="pin" autocomplete="one-time-code"><button class="b1 blk" id="cdOk">Confirmar</button></div>`;
    $('cdNum').focus();
    $('cdOk').onclick = async () => {
      try {
        const r = await api('/auth/totp/entrar', { method: 'POST', body: { pendente, codigo: $('cdNum').value.trim(), aparelho: aparelhoId() }, semToken: true });
        await entrou(r, reentrada);
      } catch (e) { $('cdMsg').innerHTML = `<div class="msg erro">${esc(e.rede ? 'Sem internet.' : e.message)}</div>`; }
    };
  }
  async function entrou(r, reentrada) {
    if (!r || !r.token) throw new Error('Não consegui entrar.');
    if (!['atendente', 'admin'].includes(r.usuario.papel)) { tela().innerHTML = '<div class="card"><h2>Sem acesso</h2><p>Este app é só para quem marca horários.</p></div>'; return; }
    if (reentrada && dados) {
      if (dados.usuario && dados.usuario.id !== r.usuario.id && dados.fila.length) { toast('Há pedidos de outra pessoa neste celular. Envie com a conta dela primeiro.'); return telaLogin(true); }
      dados.token = r.token; dados.usuario = r.usuario; precisaLogin = false; await salvar();
      telaPrincipal(); baixarHorarios(); sincronizar(); return;
    }
    telaCriarPin(r);
  }

  /* ---------- PIN ---------- */
  function telaCriarPin(r) {
    mostrarAbas(false);
    tela().innerHTML = `<div class="brand">🔒</div><div class="card"><h2>Crie um PIN</h2>
      <p class="sub">O PIN tranca os pedidos guardados neste celular. Use de 4 a 6 números. Sem o PIN ninguém abre o app, nem você. Se esquecer, é preciso entrar de novo e os pedidos não enviados se perdem.</p>
      <div id="pnMsg"></div>
      <label for="pn1">PIN</label><input id="pn1" type="password" inputmode="numeric" maxlength="6" class="pin" autocomplete="new-password">
      <label for="pn2">Repita o PIN</label><input id="pn2" type="password" inputmode="numeric" maxlength="6" class="pin" autocomplete="new-password">
      <button class="b1 blk" id="pnOk">Salvar PIN</button></div>`;
    $('pnOk').onclick = async () => {
      const a = $('pn1').value, b = $('pn2').value, m = $('pnMsg');
      if (!/^\d{4,6}$/.test(a)) return (m.innerHTML = '<div class="msg erro">O PIN precisa ter de 4 a 6 números.</div>');
      if (a !== b) return (m.innerHTML = '<div class="msg erro">Os dois PINs não são iguais.</div>');
      $('pnOk').disabled = true; m.innerHTML = '<div class="msg aviso">Trancando...</div>';
      const salt = crypto.getRandomValues(new Uint8Array(16));
      chave = await derivar(a, salt);
      dados = { token: r.token, usuario: r.usuario, fila: [], enviados: [] };
      await kvSet('meta', { salt: b64(salt), tentativas: 0 });
      await salvar();
      iniciarSessao();
    };
  }
  async function telaPin(msg) {
    mostrarAbas(false);
    const meta = await kvGet('meta');
    const restam = MAX_TENTATIVAS_PIN - (meta ? meta.tentativas || 0 : 0);
    tela().innerHTML = `<div class="brand">🔒</div><div class="card"><h2>Digite seu PIN</h2>
      <p class="sub">Seus pedidos estão trancados neste celular.</p>
      <div id="pnMsg">${msg ? `<div class="msg erro">${esc(msg)}</div>` : ''}</div>
      <input id="pn1" type="password" inputmode="numeric" maxlength="6" class="pin" autocomplete="off">
      <button class="b1 blk" id="pnOk">Abrir</button>
      <p class="sub center" style="margin-top:12px;">${restam < MAX_TENTATIVAS_PIN ? `Restam ${restam} tentativa(s). Depois disso os pedidos guardados são apagados.` : ''}</p>
      <button class="b3 blk" id="pnSair">Entrar com outra conta</button></div>`;
    $('pn1').focus();
    const abrir = async () => {
      const pin = $('pn1').value;
      if (!/^\d{4,6}$/.test(pin)) return;
      $('pnOk').disabled = true;
      const m = (await kvGet('meta')) || {}, cofre = await kvGet('cofre');
      try {
        const k = await derivar(pin, unb64(m.salt));
        dados = await decifrar(k, cofre); chave = k;
        m.tentativas = 0; await kvSet('meta', m);
        iniciarSessao();
      } catch (e) {
        m.tentativas = (m.tentativas || 0) + 1;
        if (m.tentativas >= MAX_TENTATIVAS_PIN) { await kvLimpar(); return telaLogin(false), toast('PIN errado demais. Os pedidos guardados foram apagados.'); }
        await kvSet('meta', m); telaPin('PIN incorreto.');
      }
    };
    $('pnOk').onclick = abrir;
    $('pn1').addEventListener('keydown', (e) => { if (e.key === 'Enter') abrir(); });
    $('pnSair').onclick = sairTudo;
  }
  function bloquear() { chave = null; dados = null; fecharSheet(); telaPin(); }
  async function sairTudo() {
    const n = dados && dados.fila ? dados.fila.length : null;
    const aviso = n ? `Há ${n} pedido(s) não enviados. Eles serão perdidos. Continuar?` : 'Sair apaga os dados guardados neste celular e pede e-mail e senha de novo. Continuar?';
    if (!window.confirm(aviso)) return;
    await kvLimpar(); chave = null; dados = null; horarios = { gerado_em: null, horarios: [] };
    telaLogin(false);
  }

  /* ---------- sessão ---------- */
  async function iniciarSessao() {
    const c = await kvGet('horarios'); if (c) horarios = c;
    // pedidos com mais de 7 dias não valem mais: o horário já passou ou foi desfeito
    const lim = Date.now() - VALIDADE_PEDIDO_DIAS * 86400000, antes = dados.fila.length;
    dados.fila = dados.fila.filter((i) => new Date(i.criado_em).getTime() > lim);
    if (dados.fila.length < antes) { await salvar(); toast(`${antes - dados.fila.length} pedido(s) velho(s) foram apagados.`); }
    telaPrincipal();
    if (online) { baixarHorarios(); sincronizar(); }
  }
  function telaPrincipal() { mostrarAbas(true); $('subTopo').textContent = (dados.usuario.nome ? dados.usuario.nome.split(' ')[0] + ' · Clínica de Visão' : 'Clínica de Visão') + (nomeCidadeFixa() ? ' · ' + nomeCidadeFixa() : ''); renderAba(); atualizarNum(); }
  function atualizarNum() {
    const n = dados ? dados.fila.length : 0, e = $('numPend');
    e.textContent = n; e.classList.toggle('hide', !n);
  }
  document.querySelectorAll('#abas button').forEach((b) => b.addEventListener('click', () => {
    abaAtual = b.dataset.aba;
    document.querySelectorAll('#abas button').forEach((x) => x.classList.toggle('on', x === b));
    renderAba(); window.scrollTo(0, 0);
  }));
  function renderAba() {
    if (!dados) return;
    if (abaAtual === 'marcar') renderMarcar();
    else if (abaAtual === 'pendentes') renderPendentes();
    else if (abaAtual === 'enviados') renderEnviados();
    else renderMais();
  }

  /* ---------- horários ---------- */
  async function baixarHorarios(silencioso) {
    if (!dados) return;
    try {
      const r = await api(`/agendador-offline/horarios?dias=${DIAS_HORARIOS}`);
      horarios = { gerado_em: r.gerado_em, horarios: r.horarios };
      await kvSet('horarios', horarios);
      if (dados.usuario && dados.usuario.papel === 'admin') { try { const cs = await api('/unidades'); dados.cidades = (cs || []).map((c) => ({ id: c.id, nome: c.nome })); await salvar(); } catch (e) { /* mantém a lista antiga */ } }
      if (abaAtual === 'marcar') renderMarcar();
      if (!silencioso) toast('Horários atualizados.');
    } catch (e) {
      if (e.status === 401) { precisaLogin = true; avisoLogin(); }
      else if (!silencioso && !e.rede) toast(e.message);
    }
  }
  function avisoLogin() { if (dados && precisaLogin) { const a = abaAtual; renderAba(); if (a) { /* a faixa aparece no topo de cada aba */ } } }
  const faixaLogin = () => precisaLogin ? '<div class="msg erro">Sua entrada venceu. <button class="b2" id="btnReentrar" style="padding:8px 12px;font-size:15px;">Entrar de novo</button></div>' : '';
  function ligarFaixa() { const b = $('btnReentrar'); if (b) b.onclick = () => telaLogin(true); }

  const reservadoNaFila = () => new Set(dados.fila.filter((i) => i.estado !== 'invalido').map((i) => `${i.unidade_id}|${i.data_hora.slice(0, 16)}`));
  function renderMarcar() {
    const lista = (horarios.horarios || []).filter((h) => !cidadeFixa() || h.unidade_id === cidadeFixa());
    const unidades = [...new Map(lista.map((h) => [h.unidade_id, h.unidade_nome])).entries()];
    if (!unidadeEscolhida || !unidades.some((u) => u[0] === unidadeEscolhida)) unidadeEscolhida = unidades[0] ? unidades[0][0] : null;
    const reservados = reservadoNaFila();
    const doLocal = lista.filter((h) => h.unidade_id === unidadeEscolhida);
    const dias = [...new Set(doLocal.map((h) => h.data))];
    if (!diaEscolhido || !dias.includes(diaEscolhido)) diaEscolhido = dias[0] || null;
    const idade = horarios.gerado_em ? Date.now() - new Date(horarios.gerado_em).getTime() : null;
    let html = faixaLogin();
    html += `<div class="topo"><div class="sub" style="margin:0;">${horarios.gerado_em ? 'Horários de ' + fmtQuando(horarios.gerado_em) : 'Ainda sem horários baixados'}</div><button class="b2" id="btnAtualizar" ${online ? '' : 'disabled'}>Atualizar</button></div>`;
    if (!horarios.gerado_em) html += `<div class="msg aviso">Conecte à internet para baixar os horários livres. Depois você pode marcar sem internet.</div>`;
    else if (idade > 24 * 3600000) html += `<div class="msg aviso">Esta lista tem mais de 1 dia e pode estar velha. Se possível, atualize antes de marcar.</div>`;
    if (!online && horarios.gerado_em) html += `<div class="msg aviso">Sem internet. O pedido fica guardado e é enviado quando a internet voltar. O horário só vale depois do envio.</div>`;
    if (unidades.length > 1) html += `<label for="selCidade">Cidade</label><select id="selCidade">${unidades.map((u) => `<option value="${esc(u[0])}" ${u[0] === unidadeEscolhida ? 'selected' : ''}>${esc(u[1])}</option>`).join('')}</select>`;
    if (horarios.gerado_em && !dias.length) html += `<div class="card"><p>Não há horários livres nos próximos ${DIAS_HORARIOS} dias.</p></div>`;
    if (dias.length) {
      html += `<div class="dias" id="dias">${dias.map((d) => { const f = fmtDia(d), n = doLocal.filter((h) => h.data === d && !reservados.has(`${h.unidade_id}|${h.data_hora.slice(0, 16)}`)).length; return `<button class="dia ${d === diaEscolhido ? 'on' : ''}" data-dia="${d}"><b>${f.dm}</b><span>${f.sem} · ${n} livre${n === 1 ? '' : 's'}</span></button>`; }).join('')}</div>`;
      const doDia = doLocal.filter((h) => h.data === diaEscolhido);
      html += `<div class="horas">${doDia.map((h) => { const r = reservados.has(`${h.unidade_id}|${h.data_hora.slice(0, 16)}`); return `<button class="hora" data-dh="${esc(h.data_hora)}" ${r ? 'disabled' : ''}>${r ? 'Seu pedido' : esc(h.hora)}</button>`; }).join('')}</div>`;
    }
    tela().innerHTML = html; ligarFaixa();
    const at = $('btnAtualizar'); if (at) at.onclick = () => baixarHorarios();
    const sc = $('selCidade'); if (sc) sc.onchange = () => { unidadeEscolhida = sc.value; diaEscolhido = null; renderMarcar(); };
    document.querySelectorAll('.dia').forEach((b) => b.onclick = () => { diaEscolhido = b.dataset.dia; renderMarcar(); });
    document.querySelectorAll('.hora').forEach((b) => b.onclick = () => abrirPedido(doLocal.find((h) => h.data_hora === b.dataset.dh)));
  }

  function abrirPedido(h, trocarItem) {
    if (!h) return;
    sheet(`<h2>${esc(fmtDH(h.data_hora))}</h2><p class="sub">${esc(h.unidade_nome)}${h.local ? ' · ' + esc(h.local) : ''}</p>
      <div id="pdMsg"></div>
      <label for="pdNome">Nome do paciente</label><input id="pdNome" autocomplete="off" autocapitalize="words" value="${esc(trocarItem ? trocarItem.nome : '')}">
      <label for="pdTel">Telefone com DDD</label><input id="pdTel" inputmode="tel" autocomplete="off" placeholder="(62) 99999-9999" value="${esc(trocarItem ? trocarItem.telefone : '')}">
      <button class="b1 blk" id="pdOk">Salvar pedido</button><button class="b3 blk" id="pdCancela">Cancelar</button>`);
    $('pdTel').oninput = (e) => { e.target.value = mascaraTel(e.target.value); };
    $('pdCancela').onclick = fecharSheet;
    $('pdNome').focus();
    $('pdOk').onclick = async () => {
      const nome = $('pdNome').value.replace(/\s+/g, ' ').trim(), tel = $('pdTel').value.trim(), m = $('pdMsg');
      if (nome.length < 3) return (m.innerHTML = '<div class="msg erro">Escreva o nome do paciente.</div>');
      if (!telOk(tel)) return (m.innerHTML = '<div class="msg erro">Telefone inválido. Escreva o DDD e o número.</div>');
      if (reservadoNaFila().has(`${h.unidade_id}|${h.data_hora.slice(0, 16)}`)) return (m.innerHTML = '<div class="msg erro">Você já tem um pedido neste horário.</div>');
      const item = { id: novoId(), unidade_id: h.unidade_id, unidade_nome: h.unidade_nome, data_hora: h.data_hora, tipo_nome: h.tipo_nome, nome, telefone: tel, criado_em: new Date().toISOString(), estado: 'aguardando' };
      if (trocarItem) dados.fila = dados.fila.filter((i) => i.id !== trocarItem.id);
      dados.fila.push(item);
      await salvar(); atualizarNum(); fecharSheet();
      toast(online ? 'Pedido salvo. Enviando...' : 'Pedido salvo. Será enviado quando houver internet.');
      if (abaAtual === 'marcar') renderMarcar(); else renderAba();
      if (online) sincronizar();
    };
  }

  /* ---------- pendentes ---------- */
  function renderPendentes() {
    const f = dados.fila.filter((i) => !cidadeFixa() || i.unidade_id === cidadeFixa()).slice().sort((a, b) => a.data_hora.localeCompare(b.data_hora));
    let html = faixaLogin();
    html += `<div class="topo"><div class="sub" style="margin:0;">${f.length ? f.length + ' pedido(s) no celular' : ''}</div><button class="b2" id="btnEnviar" ${online && f.length ? '' : 'disabled'}>Enviar agora</button></div>`;
    if (!f.length) html += '<div class="card"><p>Nenhum pedido pendente. Tudo o que você marcou já foi enviado.</p></div>';
    else html += '<div class="card">' + f.map((i) => {
      const tag = i.estado === 'conflito' ? '<span class="tag r">Precisa de outro horário</span>' : i.estado === 'invalido' ? '<span class="tag r">Corrigir</span>' : i.estado === 'duplicado' ? '<span class="tag r">Já marcado</span>' : '<span class="tag w">Aguardando envio</span>';
      const alts = i.alternativas && i.alternativas.length ? `<div class="sub" style="margin-top:6px;">Horários livres no mesmo dia:</div><div class="alts">${i.alternativas.map((a) => `<button class="b2" data-troca="${esc(i.id)}" data-dh="${esc(a.data_hora)}">${esc(a.hora)}</button>`).join('')}</div>` : '';
      return `<div class="item"><div class="t">${esc(i.nome)}${tag}</div><div class="d">${esc(fmtDH(i.data_hora))} · ${esc(i.unidade_nome || '')}</div><div class="d">${esc(i.telefone)}</div>
        ${i.mensagem ? `<div class="msg erro" style="margin:8px 0 0;">${esc(i.mensagem)}</div>` : ''}${alts}
        <div style="margin-top:8px;"><button class="bx" data-rem="${esc(i.id)}" style="padding:8px 12px;font-size:14px;">Apagar pedido</button></div></div>`;
    }).join('') + '</div>';
    tela().innerHTML = html; ligarFaixa();
    const be = $('btnEnviar'); if (be) be.onclick = () => sincronizar(true);
    document.querySelectorAll('[data-rem]').forEach((b) => b.onclick = async () => {
      if (!window.confirm('Apagar este pedido? O paciente não será agendado.')) return;
      dados.fila = dados.fila.filter((i) => i.id !== b.dataset.rem); await salvar(); atualizarNum(); renderPendentes();
    });
    document.querySelectorAll('[data-troca]').forEach((b) => b.onclick = () => {
      const item = dados.fila.find((i) => i.id === b.dataset.troca), alt = (item.alternativas || []).find((a) => a.data_hora === b.dataset.dh);
      if (item && alt) abrirPedido({ ...alt, unidade_nome: item.unidade_nome }, item);
    });
  }

  /* ---------- enviados ---------- */
  function renderEnviados() {
    const l = (dados.enviados || []).filter((e) => !cidadeFixa() || !nomeCidadeFixa() || e.unidade_nome === nomeCidadeFixa());
    tela().innerHTML = faixaLogin() + `<div class="card"><h2>Enviados</h2><p class="sub">Só o horário e o resultado ficam aqui. O nome do paciente não fica guardado no celular depois do envio. Para ver o paciente, abra o sistema.</p>` +
      (l.length ? l.map((e) => `<div class="item"><div class="t">${esc(fmtDH(e.data_hora))}<span class="tag g">Agendado</span></div><div class="d">${esc(e.unidade_nome || '')} · enviado ${esc(fmtQuando(e.enviado_em))}</div></div>`).join('') : '<p>Nada enviado ainda.</p>') + '</div>';
    ligarFaixa();
  }

  /* ---------- mais ---------- */
  function renderMais() {
    tela().innerHTML = faixaLogin() + `<div class="card"><h2>${esc(dados.usuario.nome || '')}</h2><p class="sub">${esc(dados.usuario.email || '')}</p>
      ${dados.usuario.papel === 'admin' ? `<label for="mxCidade">Cidade de trabalho</label><select id="mxCidade"><option value="">Todas as cidades</option>${(dados.cidades || []).map((c) => `<option value="${esc(c.id)}" ${c.id === cidadeFixa() ? 'selected' : ''}>${esc(c.nome)}</option>`).join('')}</select><p class="sub">Neste celular você vê e marca só a cidade escolhida. ${(dados.cidades || []).length ? '' : 'A lista de cidades aparece depois que o app baixar os horários com internet.'}</p>` : ''}
      <button class="b2 blk" id="mxBloq">Bloquear agora</button>
      ${jaInstalado() ? '' : '<button class="b2 blk" id="mxInst">Instalar o app no celular</button>'}
      <button class="b3 blk" id="mxPrinc">Abrir o sistema completo</button>
      <button class="bx blk" id="mxSair">Sair e apagar dados do celular</button></div>
      <div class="card"><h2>Como funciona</h2><p class="sub">1. Com internet, o app baixa os horários livres dos próximos ${DIAS_HORARIOS} dias.<br>2. Sem internet, você marca. O pedido fica guardado e trancado com seu PIN.<br>3. Quando a internet volta, o app envia sozinho.<br>4. Se o horário foi ocupado por outra pessoa, o pedido aparece em Pendentes com outros horários do dia.<br>5. O horário só vale depois do envio. Avise o paciente.</p></div>`;
    ligarFaixa();
    $('mxBloq').onclick = bloquear; $('mxSair').onclick = sairTudo; $('mxPrinc').onclick = () => { location.href = '/modulo-agendamento.html'; };
    const mi = $('mxInst'); if (mi) mi.onclick = instalar;
    const mc = $('mxCidade'); if (mc) mc.onchange = async () => {
      dados.cidadeTrabalho = mc.value || ''; await salvar();
      $('subTopo').textContent = (dados.usuario.nome ? dados.usuario.nome.split(' ')[0] + ' · Clínica de Visão' : 'Clínica de Visão') + (nomeCidadeFixa() ? ' · ' + nomeCidadeFixa() : '');
      toast(mc.value ? 'Cidade de trabalho salva.' : 'Mostrando todas as cidades.');
      if (online) baixarHorarios(true);
    };
  }

  /* ---------- envio da fila ---------- */
  async function sincronizar(manual) {
    if (!dados || sincronizando) return;
    const pend = dados.fila.filter((i) => i.estado === 'aguardando' || i.estado === 'erro');
    if (!pend.length) { if (manual) toast('Nada para enviar.'); return; }
    if (precisaLogin) { if (manual) telaLogin(true); return; }
    sincronizando = true;
    try {
      const r = await api('/agendador-offline/enviar', { method: 'POST', body: { itens: pend.slice(0, 50).map(({ id, unidade_id, data_hora, nome, telefone }) => ({ id, unidade_id, data_hora, nome, telefone })) } });
      let ok = 0, problemas = 0;
      for (const res of r.resultados) {
        const item = dados.fila.find((i) => i.id === res.id); if (!item) continue;
        if (res.status === 'ok') {
          ok++;
          dados.enviados = [{ data_hora: item.data_hora, unidade_nome: item.unidade_nome, enviado_em: new Date().toISOString() }, ...(dados.enviados || [])].slice(0, 30);
          dados.fila = dados.fila.filter((i) => i.id !== item.id);
        } else if (res.status === 'erro') { item.estado = 'aguardando'; item.mensagem = res.mensagem; }
        else { problemas++; item.estado = res.status === 'duplicado' ? 'duplicado' : res.status === 'invalido' ? 'invalido' : 'conflito'; item.mensagem = res.mensagem; item.alternativas = res.alternativas || []; }
      }
      await salvar(); atualizarNum();
      if (ok) toast(`${ok} pedido(s) enviados e agendados.`);
      if (problemas) toast(`${problemas} pedido(s) precisam de atenção em Pendentes.`);
      baixarHorarios(true);
    } catch (e) {
      if (e.status === 401) { precisaLogin = true; if (manual || abaAtual === 'pendentes') telaLogin(true); else renderAba(); }
      else if (manual) toast(e.rede ? 'Sem internet. Tento de novo quando voltar.' : e.message);
    } finally { sincronizando = false; renderAba(); }
  }

  /* ---------- eventos do aparelho ---------- */
  window.addEventListener('online', () => { setRede(true); if (dados) { sincronizar(); baixarHorarios(true); } });
  window.addEventListener('offline', () => { setRede(false); if (dados) renderAba(); });
  document.addEventListener('visibilitychange', () => {
    if (document.hidden) saiuEm = Date.now();
    else if (dados && saiuEm && Date.now() - saiuEm > BLOQUEIO_MS) bloquear();
    else if (dados && online) sincronizar();
  });
  setInterval(() => { if (dados && online && dados.fila.some((i) => i.estado === 'aguardando')) sincronizar(); }, 45000);

  /* ---------- aviso de versão nova ---------- */
  let versaoCarregada = null, avisoAdiadoAte = 0;
  async function conferirNovaVersao() {
    if (!online || Date.now() < avisoAdiadoAte) return;
    try {
      const r = await fetch('/versao', { cache: 'no-store' }); if (!r.ok) return;
      const v = await r.json(); if (!v.versao) return;
      if (!versaoCarregada) { versaoCarregada = v.versao; return; }
      if (v.versao !== versaoCarregada) mostrarAvisoVersao(v.versao);
    } catch (e) { /* sem rede: tenta depois */ }
  }
  function mostrarAvisoVersao(nova) {
    if ($('avisoVersao')) return;
    const d = document.createElement('div'); d.id = 'avisoVersao'; d.setAttribute('role', 'status');
    d.innerHTML = `<span>Nova versão ${esc(nova)} pronta. Seus pedidos continuam guardados. Toque em Atualizar.</span><button type="button" id="avisoVersaoOk">Atualizar</button><button type="button" id="avisoVersaoNao" aria-label="Agora não">×</button>`;
    document.body.appendChild(d);
    $('avisoVersaoOk').onclick = () => location.reload();
    $('avisoVersaoNao').onclick = () => { d.remove(); avisoAdiadoAte = Date.now() + 30 * 60 * 1000; };
  }
  setInterval(conferirNovaVersao, 5 * 60 * 1000);
  document.addEventListener('visibilitychange', () => { if (!document.hidden) conferirNovaVersao(); });
  window.addEventListener('online', conferirNovaVersao);

  /* ---------- partida ---------- */
  async function iniciar() {
    conferirNovaVersao();
    setRede(navigator.onLine);
    if ('serviceWorker' in navigator) navigator.serviceWorker.register('/agendador/sw.js').catch(() => {});
    if (!window.crypto || !crypto.subtle || !window.indexedDB) {
      tela().innerHTML = '<div class="card"><h2>Abra pelo endereço seguro</h2><p>Este celular ou endereço não permite guardar dados trancados. Abra o sistema pelo endereço que começa com https.</p></div>'; return;
    }
    const meta = await kvGet('meta'), cofre = await kvGet('cofre');
    if (meta && cofre) telaPin(); else telaLogin(false);
  }
  iniciar();
})();

/* botão "Mostrar senha" embaixo de todo campo de senha, para conferir o que foi digitado */
(function(){
  function ligar(i){
    if(i.dataset.verSenha) return; i.dataset.verSenha = '1';
    const b = document.createElement('button'); b.type = 'button'; b.className = 'ver-senha'; b.textContent = '👁 Mostrar senha';
    b.onclick = ()=>{ const oculto = i.type === 'password'; i.type = oculto ? 'text' : 'password'; b.textContent = oculto ? '🙈 Esconder senha' : '👁 Mostrar senha'; i.focus(); };
    i.insertAdjacentElement('afterend', b);
  }
  function varrer(){ document.querySelectorAll('input[type=password]:not([data-ver-senha])').forEach(ligar); }
  new MutationObserver(varrer).observe(document.documentElement, { childList:true, subtree:true });
  varrer();
})();

/* A− e A+: tamanho da letra do agendador offline (guardado neste celular) */
(function(){
  const NIVEIS = ['', 'grande', 'enorme', 'gigante'];
  const ler = ()=>{ try{ return localStorage.getItem('agendador_fonte') || ''; }catch(e){ return ''; } };
  function aplicar(){
    const f = ler(), i = Math.max(0, NIVEIS.indexOf(f));
    if(f) document.documentElement.setAttribute('data-fonte', f); else document.documentElement.removeAttribute('data-fonte');
    document.querySelectorAll('[data-fonte-mais="-1"]').forEach(b=> b.disabled = i<=0);
    document.querySelectorAll('[data-fonte-mais="1"]').forEach(b=> b.disabled = i>=NIVEIS.length-1);
  }
  document.addEventListener('click', (e)=>{
    const b = e.target.closest && e.target.closest('button[data-fonte-mais]'); if(!b || b.disabled) return;
    const n = Math.min(NIVEIS.length-1, Math.max(0, Math.max(0, NIVEIS.indexOf(ler())) + Number(b.dataset.fonteMais)));
    try{ localStorage.setItem('agendador_fonte', NIVEIS[n]); }catch(_){}
    aplicar();
  });
  aplicar();
})();
