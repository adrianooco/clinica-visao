/* Agendador offline: o celular baixa os horários livres e, sem internet, guarda pedidos de agendamento
   (nome, telefone e horário). Quando a internet volta, o app envia a fila e o servidor decide.
   Regras: o servidor sempre manda. Horário já ocupado vira "conflito" e devolve outros horários do mesmo dia.
   Cada pedido tem um número criado no celular: se o envio for repetido, o servidor devolve o mesmo resultado e não duplica. */
const express = require('express');
const { rotulo, cidade: cidadeSql } = require('../utils/rotulo');
const pool = require('../db/pool');
const { exigirLogin, cidadeEscolhida } = require('../middleware/auth');
const { gerarSlots, bufferEfetivo, horaParaMin } = require('../utils/horarios');
const { conferirContato, telefoneValido } = require('../utils/validar');

const router = express.Router();
router.use(exigirLogin);
/* só quem marca horário: agendador e administrador */
router.use((req, res, next) => {
  if (req.usuario.papel === 'profissional') return res.status(403).json({ erro: 'Seu acesso não permite abrir essa parte do sistema.' });
  next();
});

const FORMATO_DATA_HORA = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}(:\d{2})?$/;
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const dois = (n) => String(n).padStart(2, '0');
const minParaHora = (m) => `${dois(Math.floor(m / 60))}:${dois(m % 60)}`;

function agoraBrasilia() {
  const p = Object.fromEntries(new Intl.DateTimeFormat('en-CA', { timeZone: 'America/Sao_Paulo', year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', hour12: false })
    .formatToParts(new Date()).map((x) => [x.type, x.value]));
  return `${p.year}-${p.month}-${p.day}T${p.hour === '24' ? '00' : p.hour}:${p.minute}`;
}
const somaDias = (iso, d) => { const t = new Date(iso + 'T12:00:00Z'); t.setUTCDate(t.getUTCDate() + d); return t.toISOString().slice(0, 10); };

/* horários livres (sem nenhum dado de paciente) */
async function horariosLivres(usuario, de, ate, unidadeId) {
  const params = [usuario.clinicaId, de, ate];
  let filtro = '';
  const pedida = unidadeId ? String(unidadeId) : null;
  const un = usuario.unidadeId ? (pedida && usuario.unidadeIds.includes(pedida) ? [pedida] : usuario.unidadeIds) : (pedida ? [pedida] : null);
  if (un) { params.push(un); filtro = ' AND a.unidade_id=ANY($4)'; }
  const ags = await pool.query(
    `SELECT a.id, a.unidade_id, a.data, a.hora_inicio, a.hora_fim, a.local, a.tipo_atendimento_id, a.almoco_inicio, a.almoco_fim,
            ${rotulo('u')} AS unidade_nome, t.nome AS tipo_nome, COALESCE(a.duracao_min, t.duracao_min) AS duracao_efetiva, t.buffer_min AS buffer_tipo, a.buffer_min AS buffer_agenda
     FROM agendas a JOIN tipos_atendimento t ON t.id = a.tipo_atendimento_id JOIN unidades u ON u.id = a.unidade_id
     WHERE a.clinica_id=$1 AND a.ativa=TRUE AND a.data BETWEEN $2 AND $3${filtro}
     ORDER BY a.data, a.hora_inicio`, params);
  if (!ags.rows.length) return [];
  const unidades = [...new Set(ags.rows.map((a) => a.unidade_id))];
  const ocup = await pool.query(
    `SELECT unidade_id, data_hora FROM agendamentos WHERE clinica_id=$1 AND status <> 'cancelado' AND unidade_id = ANY($2::uuid[]) AND data_hora::date BETWEEN $3 AND $4`,
    [usuario.clinicaId, unidades, de, ate]);
  const ocupados = new Set(ocup.rows.map((o) => `${o.unidade_id}|${String(o.data_hora).slice(0, 16)}`));
  const agora = agoraBrasilia(), saida = [];
  for (const a of ags.rows) {
    for (const sl of gerarSlots(a)) {
      const hora = minParaHora(sl.min), dh = `${a.data}T${hora}`;
      if (dh < agora || ocupados.has(`${a.unidade_id}|${dh}`)) continue;
      saida.push({ agenda_id: a.id, unidade_id: a.unidade_id, unidade_nome: a.unidade_nome, data: a.data, hora, data_hora: dh + ':00',
        tipo_atendimento_id: a.tipo_atendimento_id, tipo_nome: a.tipo_nome, duracao_min: Number(a.duracao_efetiva), local: a.local || null });
    }
  }
  return saida;
}

router.get('/horarios', async (req, res) => {
  const hoje = agoraBrasilia().slice(0, 10);
  const dias = Math.min(Math.max(parseInt(req.query.dias, 10) || 21, 1), 45);
  const horarios = await horariosLivres(req.usuario, hoje, somaDias(hoje, dias), null);
  res.setHeader('Cache-Control', 'no-store');
  res.json({ gerado_em: new Date().toISOString(), de: hoje, ate: somaDias(hoje, dias), horarios });
});

/* confere se o horário existe na agenda aberta pelo Master (mesma regra do agendamento normal) */
async function horarioDoEvento(clinicaId, unidadeId, dataHora) {
  if (!unidadeId) return null;
  const r = await pool.query(
    `SELECT a.tipo_atendimento_id, a.local, a.hora_inicio, a.hora_fim, a.almoco_inicio, a.almoco_fim, a.buffer_min AS buffer_agenda,
            COALESCE(a.duracao_min, t.duracao_min) AS duracao_efetiva, t.buffer_min AS buffer_tipo
     FROM agendas a JOIN tipos_atendimento t ON t.id = a.tipo_atendimento_id
     WHERE a.clinica_id=$1 AND a.unidade_id=$2 AND a.ativa=TRUE AND a.data = $3::timestamp::date`, [clinicaId, unidadeId, dataHora]);
  const min = horaParaMin(String(dataHora).slice(11, 16));
  for (const a of r.rows) {
    if (gerarSlots(a).some((s) => s.min === min)) return { tipo_atendimento_id: a.tipo_atendimento_id, local: a.local, buffer_min: bufferEfetivo(a), duracao_min: Number(a.duracao_efetiva) };
  }
  return null;
}

const soNumeros = (t) => String(t || '').replace(/\D/g, '');
const limparNome = (t) => String(t || '').replace(/[<>]/g, '').replace(/\s+/g, ' ').trim().slice(0, 150);

/* processa um pedido. Devolve { status, mensagem, agendamento_id?, alternativas? } */
async function processar(req, item) {
  const u = req.usuario;
  const nome = limparNome(item.nome), telefone = String(item.telefone || '').trim();
  if (!UUID.test(String(item.id || ''))) return { status: 'invalido', mensagem: 'Pedido sem identificação.' };
  if (nome.length < 3) return { status: 'invalido', mensagem: 'Nome muito curto.' };
  if (!telefoneValido(telefone)) return { status: 'invalido', mensagem: 'Telefone inválido.' };
  const msgContato = conferirContato({ telefone }); if (msgContato) return { status: 'invalido', mensagem: msgContato };
  if (!FORMATO_DATA_HORA.test(String(item.data_hora || ''))) return { status: 'invalido', mensagem: 'Horário em formato inválido.' };
  const dh = String(item.data_hora).slice(0, 16);
  const unidadeId = u.unidadeId ? cidadeEscolhida(u, item.unidade_id) : (item.unidade_id || null);
  if (!unidadeId || !UUID.test(String(unidadeId))) return { status: 'invalido', mensagem: 'Cidade não informada.' };
  const un = await pool.query(`SELECT 1 FROM unidades WHERE id=$1 AND clinica_id=$2`, [unidadeId, u.clinicaId]);
  if (!un.rows.length) return { status: 'invalido', mensagem: 'Cidade inválida.' };

  const alternativas = async () => {
    const dia = dh.slice(0, 10);
    const l = await horariosLivres(u, dia, dia, unidadeId);
    return l.filter((x) => x.unidade_id === unidadeId).slice(0, 12).map((x) => ({ agenda_id: x.agenda_id, unidade_id: x.unidade_id, data: x.data, hora: x.hora, data_hora: x.data_hora, tipo_atendimento_id: x.tipo_atendimento_id, tipo_nome: x.tipo_nome, duracao_min: x.duracao_min, local: x.local }));
  };
  if (dh < agoraBrasilia()) return { status: 'passou', mensagem: 'Esse horário já passou.', alternativas: await alternativas() };
  const slot = await horarioDoEvento(u.clinicaId, unidadeId, dh);
  if (!slot) return { status: 'indisponivel', mensagem: 'Esse horário não está mais aberto na agenda.', alternativas: await alternativas() };

  const c = await pool.connect();
  try {
    await c.query('BEGIN');
    // paciente: reaproveita quem já tem esse telefone e o mesmo nome; senão cria um cadastro simples
    const ja = await c.query(
      `SELECT id FROM pacientes WHERE clinica_id=$1 AND deletado_em IS NULL AND regexp_replace(COALESCE(telefone,''),'\\D','','g') = $2 AND lower(nome_completo) = lower($3) LIMIT 1`,
      [u.clinicaId, soNumeros(telefone), nome]);
    let pacienteId = ja.rows[0] && ja.rows[0].id;
    if (!pacienteId) {
      const p = await c.query(`INSERT INTO pacientes (clinica_id, unidade_id, nome_completo, telefone, agendado_por) VALUES ($1,$2,$3,$4,$5) RETURNING id`,
        [u.clinicaId, unidadeId, nome, telefone, 'Agendador offline']);
      pacienteId = p.rows[0].id;
    }
    const mesmoDia = await c.query(`SELECT 1 FROM agendamentos WHERE clinica_id=$1 AND paciente_id=$2 AND status <> 'cancelado' AND data_hora::date = $3::timestamp::date LIMIT 1`, [u.clinicaId, pacienteId, dh]);
    if (mesmoDia.rows.length) { await c.query('ROLLBACK'); return { status: 'duplicado', mensagem: 'Esse paciente já tem exame marcado nesse dia.' }; }
    const a = await c.query(
      `INSERT INTO agendamentos (clinica_id, unidade_id, paciente_id, tipo_atendimento_id, usuario_id, data_hora, duracao_min, buffer_min, local, agendado_por, status, origem)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,'agendado','offline') RETURNING id`,
      [u.clinicaId, unidadeId, pacienteId, slot.tipo_atendimento_id, u.usuarioId, dh + ':00', slot.duracao_min, slot.buffer_min, slot.local || null, u.nome || 'Agendador offline']);
    await c.query('COMMIT');
    return { status: 'ok', mensagem: 'Agendado.', agendamento_id: a.rows[0].id };
  } catch (e) {
    await c.query('ROLLBACK').catch(() => {});
    if (e.code === '23P01') return { status: 'conflito', mensagem: 'Outra pessoa já marcou esse horário.', alternativas: await alternativas() };
    if (['22007', '22008', '22P02', '23503', '23514'].includes(e.code)) return { status: 'invalido', mensagem: 'Dados do pedido inválidos.' };
    console.error('Agendador offline:', e.message);
    return { status: 'erro', mensagem: 'Não consegui processar agora. Tente de novo.' };
  } finally { c.release(); }
}

/* recebe a fila do celular (até 50 pedidos por vez) */
router.post('/enviar', async (req, res) => {
  const itens = Array.isArray(req.body.itens) ? req.body.itens : null;
  if (!itens || !itens.length) return res.status(400).json({ erro: 'Nada para enviar.' });
  if (itens.length > 50) return res.status(400).json({ erro: 'No máximo 50 pedidos por envio.' });
  const resultados = [];
  for (const item of itens) {
    const id = item && String(item.id || '');
    if (!UUID.test(id)) { resultados.push({ id: id.slice(0, 40), status: 'invalido', mensagem: 'Pedido sem identificação.' }); continue; }
    const antigo = await pool.query(`SELECT resultado FROM agendamentos_offline WHERE clinica_id=$1 AND cliente_id=$2`, [req.usuario.clinicaId, id]);
    if (antigo.rows.length) { resultados.push({ id, ...antigo.rows[0].resultado, repetido: true }); continue; }
    const r = await processar(req, item);
    // só resultados finais ficam guardados; "erro" pode ser tentado de novo
    if (r.status !== 'erro') {
      const { alternativas, ...guardar } = r;
      await pool.query(`INSERT INTO agendamentos_offline (clinica_id, cliente_id, usuario_id, resultado) VALUES ($1,$2,$3,$4) ON CONFLICT DO NOTHING`, [req.usuario.clinicaId, id, req.usuario.usuarioId, JSON.stringify(guardar)]);
    }
    resultados.push({ id, ...r });
  }
  res.setHeader('Cache-Control', 'no-store');
  res.json({ resultados });
});

/* v4.9.42: a marcação pelo teste público usa as mesmas regras de horário */
router.horariosLivres = horariosLivres;
router.horarioDoEvento = horarioDoEvento;
router.agoraBrasilia = agoraBrasilia;
router.somaDias = somaDias;
module.exports = router;
